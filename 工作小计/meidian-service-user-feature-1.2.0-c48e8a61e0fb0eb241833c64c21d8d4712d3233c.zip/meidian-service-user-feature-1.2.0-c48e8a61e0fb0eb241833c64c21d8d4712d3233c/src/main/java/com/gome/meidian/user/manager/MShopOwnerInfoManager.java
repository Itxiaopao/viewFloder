package com.gome.meidian.user.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.gome.boot.adapter.config.aspect.annotation.Cacheable;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.meidian.user.constant.BizConstant;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.dto.MShopOwnerInfoDto;
import com.gome.meidian.user.dto.MShopPerformanceDto;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MeidianVshopSummaryDto;
import com.gome.meidian.user.dto.MshopSolicitingVo;
import com.gome.meidian.user.entity.MeidianVshopSummary;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.enums.UserIdentityEnum;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.MShopShareRecordService;
import com.gome.meidian.user.service.MShopWechatService;
import com.gome.meidian.user.service.UserRelationCacheService;
import com.gome.meidian.user.service.VshopSummaryService;
import com.gome.meidian.user.utils.DateUtil;
import com.gome.meidian.user.utils.MeidianUserTypeEnum;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import com.gome.userBase.model.weChat.GomeShopBasicInfoModel;
import com.gome.userCenter.facade.userservice.profile.IEmailMobileFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.primitives.Longs;
import lombok.extern.slf4j.Slf4j;

/**
 * @author limenghui-ds
 * @create 2019-06-10 16:07
 */
@Slf4j
@Component("mshopOwnerInfoManager")
public class MShopOwnerInfoManager implements IMShopOwnerInfoManager {
    public static final String GOME_SHOP = "gomeShop";
    @Autowired
    private MShopShareBindingService mShopShareBindingService;
    @Autowired
    private MShopShareRecordService mShopShareRecordService;
    @Autowired
    private MShopWechatService mShopWechatService;
    @Autowired
    private IGomeShopWeChatFacade gomeShopWeChatFacade;
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private IEmailMobileFacade emailMobileFacade;
    @Autowired
    private VshopSummaryService vshopSummaryService;
    @Autowired
    private UserRelationCacheService relationCacheService;

    @Override
    @Cacheable(value = "通过ID获取店主头像昵称等基本信息", prefix = CacheConstant.MSHOPOWNER_INFO_PREFIX, suffix = "#userId", seconds = 120)
    public MapResults<MShopOwnerInfoDto> queryMshopOwnerIndexByUserId(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "userId参数不能为空");
        }
        try {
            // 店主 基本信息
            List<MShopOwnerInfoDto> mShopOwnerInfoDtos = converInfoWithHaveAccountBatch(Lists.newArrayList(String.valueOf(userId)));
            if (CollectionUtils.isEmpty(mShopOwnerInfoDtos)) {
                return new MapResults<>();
            }
            MShopOwnerInfoDto ownerInfoDto = mShopOwnerInfoDtos.get(0);
            VshopInfo vshopInfo = getVshopInfo(userId);
            if (vshopInfo == null) {
                ownerInfoDto.setUserIdentity(MeidianUserTypeEnum.MSHOP_IDENTITY_OWNER.getTypeCode());
                return new MapResults<>(ownerInfoDto);
            }
            ownerInfoDto.setUserIdentity(Optional.ofNullable(vshopInfo.getVshopIdentity()).orElse(1));
            ownerInfoDto.setCertificationTime(DateUtil.formatDate(vshopInfo.getActivityTime(), "YYYY-MM-dd HH:mm:ss"));
            ownerInfoDto.setInvitationCode(String.valueOf(vshopInfo.getVshopId()));
            ownerInfoDto.setMid(vshopInfo.getVshopId());
            ownerInfoDto.setUserStatus(MeidianUserTypeEnum.MSHOP_IDENTITY_OWNER.getTypeCode());
            return new MapResults<>(ownerInfoDto);
        } catch (Exception e) {
            log.error("MShopOwnerInfoManager.queryMshopOwnerIndexByUserId is faild, param userId is {} ", userId, e);
            return new MapResults<>(-1, "异常");
        }
    }


    @Override
    @SneakyLog("统计下级店主数和客户数")
    public MapResults<MeidianVshopSummaryDto> selectByUserId(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "userId参数不能为空");
        }
        MeidianVshopSummaryDto dto = new MeidianVshopSummaryDto(userId, 0L, 0L);
        MeidianVshopSummary meidianVshopSummary = vshopSummaryService.selectByUserId(userId);
        if (null != meidianVshopSummary) {
            dto.setCustomNum(meidianVshopSummary.getCustomNum());
            dto.setShopNum(meidianVshopSummary.getShopNum());
        }
        return new MapResults<>(dto);
    }

    /**
     * 【新客，游客，首单，忠粉数量】
     *
     * @param userId
     * @return
     */
    @Override
    @SneakyLog("统计新客,游客,首单,忠粉数量")
    public MapResults<Map<Integer, Integer>> queryOfflineCount(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "userId参数不能为空");
        }
        Map<Integer, Integer> customerCount = Maps.newHashMap();
        //走游客缓存
        Long youkeCacheCount = relationCacheService.getSubordinateCount(userId, BizConstant.SHARE_RECORD_TYPE, null);
        Integer visitorCount = youkeCacheCount == null ? mShopShareRecordService.queryMyVisitorCount(userId, MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode()) : youkeCacheCount.intValue();
        customerCount.put(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode(), visitorCount);

        //新客 走缓存
        Integer xinkeType = MeidianUserTypeEnum.USER_TYPE_NEWCONSUMER.getTypeCode();
        Long xinkeCount = relationCacheService.getSubordinateCount(userId, BizConstant.USER_RELATION_CUSTOMER_TYPE, xinkeType);
        Long newCustomerCount = ObjectUtils.defaultIfNull(xinkeCount, mShopShareBindingService.queryCountByParam(buildQueryCountParam(userId, xinkeType)));
        customerCount.put(xinkeType, newCustomerCount.intValue());

        //首单 走缓存
        Integer firstOrderType = MeidianUserTypeEnum.USER_TYPE_FIRST_ORDER.getTypeCode();
        Long shoudanCount = relationCacheService.getSubordinateCount(userId, BizConstant.USER_RELATION_CUSTOMER_TYPE, firstOrderType);
        Long firstOrderCount = ObjectUtils.defaultIfNull(shoudanCount, mShopShareBindingService.queryCountByParam(buildQueryCountParam(userId, firstOrderType)));
        customerCount.put(firstOrderType, firstOrderCount.intValue());

        //忠粉 走缓存
        Integer moreOrderType = MeidianUserTypeEnum.USER_TYPE_MORE_ORDER.getTypeCode();
        Long zhongfenCount = relationCacheService.getSubordinateCount(userId, BizConstant.USER_RELATION_CUSTOMER_TYPE, moreOrderType);
        Long moreOrderCount = ObjectUtils.defaultIfNull(zhongfenCount, mShopShareBindingService.queryCountByParam(buildQueryCountParam(userId, moreOrderType)));
        customerCount.put(moreOrderType, moreOrderCount.intValue());

        return new MapResults<>(customerCount);
    }

    private MshopShareBinding buildQueryCountParam(Long userId, Integer firstOrderType) {
        MshopShareBinding param = new MshopShareBinding();
        param.setUpuserId(userId);
        param.setIdentity(0);
        param.setType(firstOrderType);
        return param;
    }

    /**************客户管理*针对的都是客户****************/
    @Override
    @SneakyLog("客户管理-新客,首单,忠粉列表信息")
    public MapResults<List<MShopOwnerInfoDto>> queryOfflineInfoOfOtherType(Long userId, String type, Integer pageSize, Integer pageNum) {
        if (Strings.isNullOrEmpty(type) || null == userId) {
            return new MapResults<>(1, "入参不正确");
        }
        try {
            //我下面的新客/首单/忠粉
            pageSize = Optional.ofNullable(pageSize).orElse(10);
            pageNum = Optional.ofNullable(pageNum).orElse(1);
            Integer pageIndex = (pageNum - 1) * pageSize;
            Set<String> subordinatePage = relationCacheService.getSubordinatePage(userId, UserIdentityEnum.custom.getCode(), Integer.valueOf(type), pageIndex, pageSize);
            List<MshopShareBinding> list = relationCacheService.multiGetUserRelation(subordinatePage);
            List<MShopShareBindingDto> bindingDtoList;
            if (CollectionUtils.isEmpty(list)) {
                bindingDtoList = mShopShareBindingService.queryMyShareBindingByType(userId, type, pageSize, pageIndex);
            } else {
                bindingDtoList = list.stream().map(input -> mShopShareBindingService.convert(input)).collect(Collectors.toList());
            }

            if (CollectionUtils.isEmpty(bindingDtoList)) {
                return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
            }
            List<MShopOwnerInfoDto> resultList = Lists.newArrayList();
            List<String> allUserIds = getAllUserId(bindingDtoList);
            List<MShopOwnerInfoDto> mShopOwnerInfoDtos = converInfoWithHaveAccountBatch(allUserIds);
            Map<Long, MShopOwnerInfoDto> userId_OwnerInfo = convertToMap(mShopOwnerInfoDtos, owner -> owner.getUserId());
            handlerOwnerInfo(resultList, bindingDtoList, userId_OwnerInfo);
            return new MapResults<>(resultList);
        } catch (Exception e) {
            log.error("MShopOwnerInfoManager.queryOfflineInfoOfOtherType execute is fail userId {},type {} ", userId, type, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }


    @Override
    @SneakyLog("客户列表-游客列表")
    public MapResults<List<MShopOwnerInfoDto>> queryOfflineInfoOfVisitor(Long userId, String type, Integer pageSize, Integer pageNum) {
        if (null == userId || !"2".equals(type)) {
            return new MapResults<>(1, "参数不符合要求");
        }
        try {
            //查找我的游客信息 先走缓存
            pageSize = Optional.ofNullable(pageSize).orElse(10);
            pageNum = Optional.ofNullable(pageNum).orElse(1);
            Integer pageIndex = (pageNum - 1) * pageSize;

            //走缓存
            List<MShopOwnerInfoDto> list = getVisitorListFromCache(userId, pageSize, pageIndex);
            if (CollectionUtils.isNotEmpty(list)) {
                return new MapResults<>(list);
            }
            //走数据库
            List<MshopWechatUserInfo> visitorInfoList = mShopWechatService.queryMyNextWeChatInfoByUserIdWithPage(userId, pageSize, pageIndex);
            if (CollectionUtils.isEmpty(visitorInfoList)) {
                return new MapResults<>(Lists.newArrayList());
            }
            List<MShopOwnerInfoDto> list2 = new ArrayList<>(visitorInfoList.size());
            for (MshopWechatUserInfo dto : visitorInfoList) {
                MShopOwnerInfoDto mshopInfo = new MShopOwnerInfoDto();
                mshopInfo.setUserType(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode());
                mshopInfo.setUserStatus(MeidianUserTypeEnum.USER_CONSUMER.getTypeCode());
                mshopInfo.setUniqueId(dto.getUniqueId());
                mshopInfo.setWeiXinNickName(dto.getNickname());
                mshopInfo.setImagePath(dto.getImage());
                list2.add(mshopInfo);
            }
            return new MapResults<>(list2);
        } catch (Exception e) {
            log.error("MShopOwnerInfoManager.queryOfflineInfoOfVisitor 游客列表查询失败, userId {}", userId, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }

    }

    private List<MShopOwnerInfoDto> getVisitorListFromCache(Long userId, Integer pageSize, Integer pageIndex) {
        Set<String> uniqueIDs = relationCacheService.getSubordinatePage(userId, BizConstant.SHARE_RECORD_TYPE, null, pageIndex, pageSize);
        if (CollectionUtils.isEmpty(uniqueIDs)) {
            return Lists.newArrayList();
        }
        Map<String, MshopWechatUserInfo> mshopWechatUserInfoMap = relationCacheService.multiGetWechatUserInfo(0, uniqueIDs);
        List<MShopOwnerInfoDto> list = new ArrayList<>(uniqueIDs.size());
        for (String uniqueId : uniqueIDs) {
            MShopOwnerInfoDto mshopInfo = new MShopOwnerInfoDto();
            mshopInfo.setUserType(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode());
            mshopInfo.setUserStatus(MeidianUserTypeEnum.USER_CONSUMER.getTypeCode());
            mshopInfo.setUniqueId(uniqueId);
            MshopWechatUserInfo mshopWechatUserInfo = mshopWechatUserInfoMap.get(uniqueId);
            if (mshopWechatUserInfo != null) {
                mshopInfo.setWeiXinNickName(mshopWechatUserInfo.getNickname());
                mshopInfo.setImagePath(mshopWechatUserInfo.getImage());
            }
            list.add(mshopInfo);
        }
        return list;
    }

    @Override
    @SneakyLog
    public MapResults<List<MShopOwnerInfoDto>> queryOfflineInfoByWeiXinNickName(Long myUserId, String nickName) {
        if (null == myUserId || null == nickName) {
            return new MapResults<>(1, "当前用户ID和昵称都不能为空参");
        }

        List<MShopOwnerInfoDto> resultList = Lists.newArrayList();
        nickName = com.vdurmont.emoji.EmojiParser.parseToAliases(nickName);
        //游客信息
        MshopWechatUserInfo wechatUserInfo = mShopWechatService.queryMyNextWeChatInfoByNickName(myUserId, nickName);
        if (null != wechatUserInfo) {
            MShopOwnerInfoDto dto = new MShopOwnerInfoDto();
            dto.setUserStatus(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode());
            dto.setUserType(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode());
            dto.setWeiXinNickName(wechatUserInfo.getNickname());
            dto.setImagePath(wechatUserInfo.getImage());
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
            String currentDate = df.format(new Date());// new Date()为获取当前系统时间
            dto.setBrowsLatestDate(StringUtils.isNotEmpty(wechatUserInfo.getBrowsLatestDate()) ?
                    wechatUserInfo.getBrowsLatestDate() :
                    currentDate);
            dto.setUniqueId(wechatUserInfo.getUniqueId());
            resultList.add(dto);
        }

        // 【有账号的用户】  会员接口  通过昵称查找用户Id
        List<Long> userIdList = getUserIdByWeChatNickName(nickName);
        if (CollectionUtils.isEmpty(userIdList)) {
            return new MapResults(resultList);
        }

        //过滤出和当前用户绑定的userid集合
        Map<String, Object> param = new HashMap<>();
        param.put("userIdList", userIdList);
        param.put("upUserId", myUserId);
        List<MShopShareBindingDto> shareBindings = mShopShareBindingService.queryListByParamWithMap(param);

        //查询userId和PuserId对应的会员的数据,混到一起一块查询
        List<String> allUserId = getAllUserId(shareBindings);

        List<MShopOwnerInfoDto> ownerInfoDtos = converInfoWithHaveAccountBatch(allUserId);

        Map<Long, MShopOwnerInfoDto> userId_OwnerInfo = convertToMap(ownerInfoDtos, owner -> owner.getUserId());

        handlerOwnerInfo(resultList, shareBindings, userId_OwnerInfo);
        //list按照最近浏览时间进行降序
        Collections.sort(resultList, (o1, o2) -> o2.getBrowsLatestDate().compareTo(o1.getBrowsLatestDate()));

        return new MapResults<>(resultList);
    }

    private void handlerOwnerInfo(List<MShopOwnerInfoDto> resultList, List<MShopShareBindingDto> shareBindings,
            Map<Long, MShopOwnerInfoDto> userId_OwnerInfo) {

        for (MShopShareBindingDto shareBindingDto : shareBindings) {
            MShopOwnerInfoDto ownerInfoDto = userId_OwnerInfo.get(shareBindingDto.getUserId());
            if (ownerInfoDto == null) {
                continue;
            }

            ownerInfoDto.setUserType(shareBindingDto.getType());
            ownerInfoDto.setUserStatus(MeidianUserTypeEnum.USER_CONSUMER.getTypeCode());
            ownerInfoDto.setBrowsLatestDate(shareBindingDto.getInsertTime());
            ownerInfoDto.setUserStatus(MeidianUserTypeEnum.USER_CONSUMER.getTypeCode());

            int authorization = Optional.ofNullable(shareBindingDto.getAuthorization()).orElse(0).intValue();
            ownerInfoDto.setAuthorization(authorization);

            String phone = ownerInfoDto.getPhone();
            //有手机号，并且没有授权，隐藏手机号
            if (StringUtils.isNotEmpty(phone) && 0 == authorization) {
                phone = phone.substring(0, 3) + "****" + phone.substring(7, phone.length());
                ownerInfoDto.setPhone(phone);
            }

            String weixinNum = ownerInfoDto.getWeixinNum();
            if (StringUtils.isNotEmpty(weixinNum) && 0 == authorization) {
                ownerInfoDto.setWeixinNum(weixinNum.substring(0, 1) + "****" + weixinNum.substring(weixinNum.length() - 1));
            }

            MShopOwnerInfoDto p_mshopInfo = userId_OwnerInfo.get(shareBindingDto.getPUserId());
            if (p_mshopInfo != null) {
                ownerInfoDto.setNickNameOfInvitation(p_mshopInfo.getWeiXinNickName());
                ownerInfoDto.setImagePathOfInvitation(p_mshopInfo.getImagePath());
            }

            resultList.add(ownerInfoDto);
        }
    }

    private List<String> getAllUserId(List<MShopShareBindingDto> mShopShareBindingDtos) {
        Set<String> bindUserIds = mShopShareBindingDtos.parallelStream().map(i -> String.valueOf(i.getUserId())).collect(Collectors.toSet());
        Set<String> bindPUserIds = mShopShareBindingDtos.parallelStream().map(i -> String.valueOf(i.getPUserId())).collect(Collectors.toSet());
        List<String> userIds = Lists.newArrayList();
        userIds.addAll(bindPUserIds);
        userIds.addAll(bindUserIds);
        return userIds;
    }

    @Override
    @SneakyLog
    public MapResults<MShopOwnerInfoDto> queryOfflineInfoByPhone(Long myUserId, String paramPhone) {
        if (null == myUserId) {
            return new MapResults<>(1, "参数不能为空");
        }
        MShopOwnerInfoDto invitionDto = new MShopOwnerInfoDto();

        Map<String, Object> paramMap = Maps.newHashMap();
        paramMap.put("companyName", "gomeOnLine");
        paramMap.put("isCheckLogin", false);
        paramMap.put("isSearchAll", false);
        UserResult<List<UnifyUserInfoExt>> gomeShop = emailMobileFacade.queryUserInfoListByMobile(paramPhone, "gomeShop", paramMap);
        if (gomeShop.isSuccess() && CollectionUtils.isNotEmpty(gomeShop.getBuessObj())) {
            //成功
            String id = gomeShop.getBuessObj().get(0).getId();
            log.info("MShopOwnerInfoManager.queryOfflineInfoByPhone param  myUserId is {},phone is {}, 33member id is {} ", myUserId, paramPhone, id);
            //手机号对应的有账户
            if (StringUtils.isNotEmpty(id)) {
                invitionDto = converInfoWithHaveAccount(Long.valueOf(id));
                invitionDto.setUserStatus(MeidianUserTypeEnum.USER_CONSUMER.getTypeCode());

                //有账户，判断该用户是否是我的游客
                MshopShareRecord param = new MshopShareRecord();
                param.setUpuserId(myUserId);
                param.setUserId(Long.valueOf(id));
                param.setType(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode());
                List<MshopShareRecord> mshopShareRecords = mShopShareRecordService.queryListByParam(param);
                //记录表存在，是游客
                if (CollectionUtils.isNotEmpty(mshopShareRecords)) {
                    invitionDto.setUserType(MeidianUserTypeEnum.USER_TYPE_VISITOR.getTypeCode());
                    invitionDto.setBrowsLatestDate(DateUtil.formatDate(mshopShareRecords.get(0).getUpdateTime(), "YYYY-MM-dd HH:mm:ss"));
                    return new MapResults<>(invitionDto);
                }
                // 是否是其他类型
                MShopShareBindingDto mShopShareBindingDto = mShopShareBindingService.queryShareBindingByUserIdAndUpUserid(Long.valueOf(id), myUserId);
                if (null != mShopShareBindingDto) {
                    invitionDto.setUserType(mShopShareBindingDto.getType());
                    invitionDto.setBrowsLatestDate(mShopShareBindingDto.getUpdateTime());

                    Integer authorization = mShopShareBindingDto.getAuthorization();
                    invitionDto.setAuthorization(null == authorization ? 0 : authorization);

                    String phone = invitionDto.getPhone();
                    //有手机号，并且没有授权，隐藏手机号
                    if (StringUtils.isNotEmpty(phone) && NumberUtils.isNullOrZero(authorization)) {
                        phone = phone.substring(0, 3) + "****" + phone.substring(7, phone.length());
                    }
                    invitionDto.setPhone(phone);

                    String weixinNum = invitionDto.getWeixinNum();
                    if (StringUtils.isNotEmpty(weixinNum) && NumberUtils.isNullOrZero(authorization)) {
                        invitionDto.setWeixinNum(weixinNum.substring(0, 1) + "****" + weixinNum.substring(weixinNum.length() - 1));
                    }

                    Long pUserId = mShopShareBindingDto.getPUserId();
                    if (null != pUserId) {
                        // 得到邀请人的微信昵称
                        MShopOwnerInfoDto pInvitionDto = converInfoWithHaveAccount(pUserId);
                        if (null != pInvitionDto) {
                            invitionDto.setNickNameOfInvitation(pInvitionDto.getWeiXinNickName());
                            invitionDto.setImagePathOfInvitation(pInvitionDto.getImagePath());
                        }
                    }
                } else {
                    //不是当前人下属
                    invitionDto = new MShopOwnerInfoDto();
                }
            }
        }
        return new MapResults<>(invitionDto);
    }

    /**
     * 李彬彬，任意100条数据，新客，首单，忠粉
     *
     * @param userId
     * @return
     */
    @Override
    @SneakyLog
    public MapResults<List<String>> queryUserIdList(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "参数不能为空");
        }
        List<String> list = mShopShareBindingService.queryUserIdList(userId);
        return new MapResults<>(list);
    }

    @Override
    @SneakyLog("查找二维码")
    public MapResults<MshopSolicitingVo> queryMshopSolicitingInfo(Long currentUserId, Long invitionUserId) {
        if (null == currentUserId) {
            return new MapResults<>(1, "当前用户不能为空");
        }
        List<String> pramUserIdList = Lists.newArrayList(String.valueOf(currentUserId));
        if (null != invitionUserId) {
            pramUserIdList.add(String.valueOf(invitionUserId));
        }
        // 先封装currentUserId，invitionUserId和上级的用户id
        Long upUserId = null;
        MShopShareBindingDto mShopShareBindingDto = mShopShareBindingService.queryShareBindingByUserId(currentUserId);
        if (null != mShopShareBindingDto && null != mShopShareBindingDto.getUpUserId()) {
            upUserId = mShopShareBindingDto.getUpUserId();
            pramUserIdList.add(String.valueOf(upUserId));
        }
        Map<String, GomeShopBasicInfoModel> map = Maps.newLinkedHashMap();
        UserResult<List<GomeShopBasicInfoModel>> currentGomeShop = gomeShopWeChatFacade
                .batchQueryUserBasicInfo(pramUserIdList, "gomeShop");
        if (null != currentGomeShop && CollectionUtils.isNotEmpty(currentGomeShop.getBuessObj())) {
            for (GomeShopBasicInfoModel basicInfoModel : currentGomeShop.getBuessObj()) {
                map.put(basicInfoModel.getUserId(), basicInfoModel);
            }
        }

        MshopSolicitingVo dto = new MshopSolicitingVo();
        if (MapUtils.isNotEmpty(map)) {
            // 当前人微信昵称和头像
            GomeShopBasicInfoModel currentUser = map.get(String.valueOf(currentUserId));
            if (null != currentUser) {
                dto.setSelfUrl(StringUtils.isNotEmpty(currentUser.getWeixinImg()) ? currentUser.getWeixinImg()
                        : currentUser.getGomeImg());
                dto.setSelfNickname(
                        StringUtils.isNotEmpty(currentUser.getWeixinNickName()) ? currentUser.getWeixinNickName()
                                : currentUser.getGomeNickName());
            }
        }
        // 查找当前人的二维码和微信号
        MshopWechatUserInfo wechatUserInfo = new MshopWechatUserInfo();
        wechatUserInfo.setUserId(currentUserId);
        wechatUserInfo.setType(1);
        MshopWechatUserInfo weChatInfo = mShopWechatService.queryWechatInfoByParam(wechatUserInfo);
        if (null != weChatInfo) {
            // 二维码和微信号
            dto.setSelfImag(weChatInfo.getQrCode());
            dto.setSelfWeChartNum(null != weChatInfo.getWechatNum() ? String.valueOf(weChatInfo.getWechatNum()) : null);
        }

        // 邀请人的微信昵称和头像
        if (null != invitionUserId) {
            if (MapUtils.isNotEmpty(map)) {
                GomeShopBasicInfoModel inviUser = map.get(String.valueOf(invitionUserId));
                if (null != inviUser) {
                    dto.setInvitationUrl(StringUtils.isNotEmpty(inviUser.getWeixinImg()) ? inviUser.getWeixinImg() : inviUser.getGomeImg());
                    dto.setInvitationNickname(StringUtils.isNotEmpty(inviUser.getWeixinNickName()) ? inviUser.getWeixinNickName() : inviUser.getGomeNickName());
                }
            }
        }
        // 上级的
        if (null != upUserId) {
            dto.setHigherUserId(String.valueOf(upUserId));
            dto.setIsSamePerson(upUserId.equals(invitionUserId));
            // 封装上级用户 的二维码+微信号,直接通过上级userid去微信表查询
            MshopWechatUserInfo param = new MshopWechatUserInfo();
            param.setUserId(upUserId);
            param.setType(1);
            MshopWechatUserInfo weChat = mShopWechatService.queryWechatInfoByParam(param);
            if (null != weChat) {
                // 上级的二维码和微信号
                dto.setHigherWeChartNum(null != weChat.getWechatNum() ? String.valueOf(weChat.getWechatNum()) : null);
                dto.setHigherImag(weChat.getQrCode());
            }
            if (null != mShopShareBindingDto.getUpMid() && mShopShareBindingDto.getUpMid() != 0) {
                dto.setHigherMid(String.valueOf(mShopShareBindingDto.getUpMid()));
            } else {
                VshopInfo vshopInfo = getVshopInfo(mShopShareBindingDto.getUpUserId());
                if (null != vshopInfo) {
                    dto.setHigherMid(String.valueOf(vshopInfo.getVshopId()));
                }
            }
            if (MapUtils.isNotEmpty(map)) {
                GomeShopBasicInfoModel upUser = map.get(String.valueOf(upUserId));
                // 上级的微信昵称和头像
                if (null != upUser) {
                    dto.setHigherUrl(StringUtils.isNotEmpty(upUser.getWeixinImg()) ? upUser.getWeixinImg() : upUser.getGomeImg());
                    dto.setHigherNickname(StringUtils.isNotEmpty(upUser.getWeixinNickName()) ? upUser.getWeixinNickName() : upUser.getGomeNickName());
                }
            }
        }
        return new MapResults<>(dto);
    }

    /**
     * 【渠道管理】查询下一级邀请数据   todo 加入缓存
     *
     * @param myUserId
     * @param pageSize
     * @param pageNum
     * @return
     */
    @Override
    @SneakyLog("渠道管理列表查询")
    public MapResults<List<MShopPerformanceDto>> getInviteList(Long myUserId, Integer pageSize, Integer pageNum) {
        if (myUserId == null) {
            return new MapResults<>(1, "userId不能为空");
        }
        try {
            pageNum = Optional.ofNullable(pageNum).orElse(1);
            pageSize = Optional.ofNullable(pageSize).orElse(10);
            Integer pageIndex = (pageNum - 1) * pageSize;

            Set<String> userIds = relationCacheService.getSubordinatePage(myUserId, BizConstant.USER_RELATION_PUSHERS_TYPE, null, pageIndex, pageSize);
            List<MshopShareBinding> bindings = relationCacheService.multiGetUserRelation(userIds);

            if (CollectionUtils.isEmpty(bindings)) {
                bindings = mShopShareBindingService.queryInviteList(myUserId, pageSize, pageIndex);
            } else {
                //按照插入时间降序排列
                Collections.sort(bindings, (o1, o2) -> o2.getInsertTime().compareTo(o1.getInsertTime()));
            }
            if (CollectionUtils.isEmpty(bindings)) {
                return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
            }
            List<String> userIdStrs = bindings.parallelStream().map(i -> String.valueOf(i.getUserId())).collect(Collectors.toList());
            List<MShopOwnerInfoDto> mShopOwnerInfoDtos = converInfoWithHaveAccountBatch(userIdStrs);
            Map<Long, MShopOwnerInfoDto> userId_ownerInfo = mShopOwnerInfoDtos.parallelStream().collect(Collectors.toMap(MShopOwnerInfoDto::getUserId, input -> input));

            List<Long> userIdList = bindings.parallelStream().map(i -> i.getUserId()).collect(Collectors.toList());
            List<MeidianVshopSummary> countList = vshopSummaryService.selectByUserIdList(userIdList);
            Map<Long, MeidianVshopSummary> customerOrMhsopCount = countList.parallelStream().collect(Collectors.toMap(MeidianVshopSummary::getUserId, input -> input));


            List<MShopPerformanceDto> resultList = new ArrayList<>();
            for (MshopShareBinding binding : bindings) {
                MShopPerformanceDto mShopPerformanceDto = new MShopPerformanceDto();
                MShopOwnerInfoDto info = userId_ownerInfo.get(binding.getUserId());
                if (info != null) {
                    info.setUserStatus(MeidianUserTypeEnum.MSHOP_IDENTITY_OWNER.getTypeCode());
                    info.setUserIdentity(binding.getIdentity());

                    info.setCertificationTime(DateFormatUtils.format(binding.getInsertTime(), "yyyy-MM-dd HH:mm:ss"));

                    int authorization = Optional.ofNullable(binding.getAuthorization()).orElse(0);
                    info.setAuthorization(authorization);

                    String phone = info.getPhone();
                    //有手机号，并且没有授权，隐藏手机号
                    if (StringUtils.isNotEmpty(phone) && authorization == 0) {
                        phone = phone.substring(0, 3) + "****" + phone.substring(7, phone.length());
                        info.setPhone(phone);
                    }

                    String weixinNum = info.getWeixinNum();
                    if (StringUtils.isNotEmpty(weixinNum) && authorization == 0) {
                        info.setWeixinNum(weixinNum.substring(0, 1) + "****" + weixinNum.substring(weixinNum.length() - 1));
                    }
                    mShopPerformanceDto.setMShopOwnerInfoDto(info);

                    MeidianVshopSummary countVO = customerOrMhsopCount.get(info.getUserId());
                    if (countVO != null) {
                        mShopPerformanceDto.setConsumerCount(countVO.getCustomNum() == null ? 0 : countVO.getCustomNum().intValue());
                        mShopPerformanceDto.setMshopOwnerCount(countVO.getShopNum() == null ? 0 : countVO.getShopNum().intValue());
                    }
                    resultList.add(mShopPerformanceDto);
                }
            }
            return new MapResults<>(resultList);
        } catch (Exception e) {
            log.error("MShopOwnerInfoManager.getInviteList is faild, myUserId:{}", myUserId, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    /**
     * @param userId
     * @return
     */
    @Override
    @SneakyLog("根据用户id查询美店id")
    public MapResults<String> queryMidByUserId(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "参数userId不能为空");
        }
        MShopShareBindingDto dto = mShopShareBindingService.queryShareBindingByUserId(userId);
        if (null == dto || NumberUtils.isNullOrZero(dto.getMid())) {
            VshopInfo vshopInfo = getVshopInfo(userId);
            String mid = null != vshopInfo ? String.valueOf(vshopInfo.getVshopId()) : null;
            return new MapResults<>(mid);
        } else {
            return new MapResults<>(String.valueOf(dto.getMid()));
        }
    }

    /**
     * 店主/客户，微信昵称，手机号，头像，微信号
     *
     * @param userId
     * @return
     */
    @Override
    @Cacheable(value = "根据用户id查询用户基础信息", prefix = "MShopOwnerInfoManager.queryMShopBasicInfoByUserId", suffix = "#userId", seconds = 300)
    public MapResults<MShopOwnerInfoDto> queryMShopBasicInfoByUserId(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "参数userId不能为空");
        }
        //走数据库
        MShopOwnerInfoDto dto = converInfoWithHaveAccount(userId);
        return new MapResults<>(dto);
    }


    @Override
    @SneakyLog
    public MapResults<List<MShopOwnerInfoDto>> queryMShopBasicInfoByUserIdBatch(List<Long> userIdList) {
        if (CollectionUtils.isEmpty(userIdList)) {
            return new MapResults<>(1, "参数不能为空");
        }
        List<String> collect = new ArrayList<>();
        for (Long userId : userIdList) {
            collect.add(String.valueOf(userId));
        }
        //一次性获取微信基本信息
        List<MShopOwnerInfoDto> mShopOwnerInfoDtos = converInfoWithHaveAccountBatch(collect);
        if (CollectionUtils.isNotEmpty(mShopOwnerInfoDtos)) {
            for (MShopOwnerInfoDto dto : mShopOwnerInfoDtos) {
                //默认店主：
                dto.setUserIdentity(MeidianUserTypeEnum.MSHOP_IDENTITY_OWNER.getTypeCode());
                dto.setUserStatus(MeidianUserTypeEnum.MSHOP_IDENTITY_OWNER.getTypeCode());
                VshopInfo vshopInfo = getVshopInfo(dto.getUserId());
                if (null != vshopInfo) {
                    dto.setUserIdentity(null == vshopInfo.getVshopIdentity() ? 1 : vshopInfo.getVshopIdentity());
                    dto.setCertificationTime(DateUtil.formatDate(vshopInfo.getActivityTime(), "YYYY-MM-dd"));
                }
                log.info("MShopOwnerInfoManager.queryMShopBasicInfoByUserIdBatch param userId is {},data is {} ", dto.getUserId(), dto);
            }
        }
        return new MapResults<>(mShopOwnerInfoDtos);
    }

    /**
     * 电话号，微信号，微信昵称，微信头像，店主/普通用户 通过一个userId转换
     *
     * @param userId
     * @return
     */
    public MShopOwnerInfoDto converInfoWithHaveAccount(Long userId) {
        //查询用户昵称，电话号
        MShopOwnerInfoDto dto = new MShopOwnerInfoDto();
        UserResult<List<GomeShopBasicInfoModel>> gomeShop = gomeShopWeChatFacade.batchQueryUserBasicInfo(Lists.newArrayList(String.valueOf(userId)), "gomeShop");
        List<GomeShopBasicInfoModel> buessObj = gomeShop.getBuessObj();
        log.info("MShopOwnerInfoManager.converInfoWithHaveAccount  data {}", buessObj);
        if (CollectionUtils.isNotEmpty(buessObj)) {
            dto.setWeiXinNickName(StringUtils.isNotEmpty(buessObj.get(0).getWeixinNickName()) ?
                    buessObj.get(0).getWeixinNickName() :
                    buessObj.get(0).getGomeNickName());
            dto.setImagePath(
                    StringUtils.isNotEmpty(buessObj.get(0).getWeixinImg()) ? buessObj.get(0).getWeixinImg() : buessObj.get(0).getGomeImg());
            dto.setPhone(buessObj.get(0).getMobile());
            dto.setWeixinNum(buessObj.get(0).getWeixinNum());
            dto.setRegistrationTime(DateUtil.formatDate(buessObj.get(0).getRegisterDate(), "YYYY-MM-dd HH:mm:ss"));
            dto.setCertificationTime(DateUtil.formatDate(buessObj.get(0).getRegisterDate(), "YYYY-MM-dd HH:mm:ss"));
            dto.setUserId(userId);
            log.info("MShopOwnerInfoManager.converInfoWithHaveAccount param userid is {},33member data is {}", userId, dto);
        }
        return dto;
    }

    /**
     * 批量转换userId的对象
     *
     * @param userIdList
     * @return
     */
    public List<MShopOwnerInfoDto> converInfoWithHaveAccountBatch(List<String> userIdList) {
        long startTime = System.currentTimeMillis();
        List<MShopOwnerInfoDto> list = Lists.newArrayList();
        UserResult<List<GomeShopBasicInfoModel>> gomeShop = null;
        try {
            gomeShop = gomeShopWeChatFacade.batchQueryUserBasicInfo(userIdList, GOME_SHOP);
        } catch (Exception e) {
            log.error("MShopOwnerInfoManager.converInfoWithHaveAccountBatch.batchQueryUserBasicInfo 异常，入参是 {}", userIdList, e);
        } finally {
            log.info("MShopOwnerInfoManager.converInfoWithHaveAccountBatch.batchQueryUserBasicInfo 入参是 {},结果是 {} ,运行时间是{}", userIdList, JSON.toJSONString(gomeShop), System.currentTimeMillis() - startTime);
        }
        if (gomeShop == null || CollectionUtils.isEmpty(gomeShop.getBuessObj())) {
            return list;
        }
        for (GomeShopBasicInfoModel model : gomeShop.getBuessObj()) {
            //查询用户昵称，电话号
            MShopOwnerInfoDto dto = new MShopOwnerInfoDto();
            dto.setWeiXinNickName(StringUtils.isNotEmpty(model.getWeixinNickName()) ? model.getWeixinNickName() : model.getGomeNickName());
            dto.setImagePath(StringUtils.isNotEmpty(model.getWeixinImg()) ? model.getWeixinImg() : model.getGomeImg());
            dto.setPhone(model.getMobile());
            dto.setWeixinNum(model.getWeixinNum());
            dto.setRegistrationTime(DateUtil.formatDate(model.getRegisterDate(), "YYYY-MM-dd HH:mm:ss"));
            dto.setCertificationTime(DateUtil.formatDate(model.getRegisterDate(), "YYYY-MM-dd HH:mm:ss"));
            dto.setUserId(Long.valueOf(model.getUserId()));
            list.add(dto);
        }
        return list;
    }

    //T转成R
    private <T, R> Map<R, T> convertToMap(List<T> list, java.util.function.Function<T, R> keyFunction) {
        Map<R, T> map = new HashMap<R, T>(list.size());
        for (T item : list) {
            R key = keyFunction.apply(item);
            if(!map.containsKey(key)){
                map.put(key, item);
            }
        }
        return map;
    }

    private List<Long> getUserIdByWeChatNickName(String nickName) {
        long startTime = System.currentTimeMillis();
        List<String> userIds = null;
        try {
            userIds = Optional.ofNullable(gomeShopWeChatFacade.getUserIdByWeChatNickName(nickName, GOME_SHOP))
                    .map(i -> i.getBuessObj()).orElseGet(() -> {
                        log.warn("MShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName.getUserIdByWeChatNickName 通过昵称查询用户ID返回结果是null，nickName is {} ", nickName);
                        return Collections.EMPTY_LIST;
                    });
            userIds = (null != userIds) ? userIds : Collections.EMPTY_LIST;
        } catch (Exception e) {
            log.error("MShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName.getUserIdByWeChatNickName 通过昵称查询用户ID，nickName is {},error is ", nickName, e);
        } finally {
            log.info(
                    "MShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName.getUserIdByWeChatNickName 通过昵称查询用户ID，nickName is {},结果是 {},接口调用时间 {}  ",
                    nickName, userIds, System.currentTimeMillis() - startTime);
        }

        List<Long> collect = userIds.stream().map(i -> Longs.tryParse(i)).filter(aLong -> null != aLong).collect(Collectors.toList());
        log.info("MShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName.getUserIdByWeChatNickName 转成Long类型的用户ID集合是 {},nickName 是 {}", collect, nickName);
        return collect;
    }

    @SneakyLog("查找美店主信息")
    private VshopInfo getVshopInfo(Long userId) {
        CommonResultEntity<VshopInfo> result = vshopFacade.queryVshopByuserId(String.valueOf(userId));
        if (result != null) {
            return result.getBusinessObj();
        }
        return null;
    }

}
