package com.gome.meidian.user.enums;

public enum SkRoleEnum {

    //1.电器员工店主,2.非电器员工店主,3.发展社会店主,4.外部美店主
    EAEmployee(1, "电器员工店主"),
    unEAEmployee(2, "非电器员工店主"),
    developSociety(3, "发展社会店主"),
    outside(4, "外部美店主"),
    unknown(-1, "未知角色"),
    ;

    private Integer code;

    private String desc;

    private SkRoleEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
