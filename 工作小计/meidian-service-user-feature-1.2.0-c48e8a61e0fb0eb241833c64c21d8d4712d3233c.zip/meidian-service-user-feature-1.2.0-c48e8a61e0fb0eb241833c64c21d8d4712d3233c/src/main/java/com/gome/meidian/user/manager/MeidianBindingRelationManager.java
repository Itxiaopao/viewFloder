package com.gome.meidian.user.manager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.config.DiamondEnv;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.user.constant.BizConstant;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.constant.DiamondConstant;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MeidianBindingRelationDto;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.enums.DiamondEnum;
import com.gome.meidian.user.enums.UserBizMgrEnum;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.IMeidianBindingRelationService;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.UserRelationFactory;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

/**
 * @author chenchen56
 */
@Slf4j
@Component("meidianBindingRelationManager")
public class MeidianBindingRelationManager implements IMeidianBindingRelationManager, UserRelationFactory {

    @Autowired
    private Gcache gcache;
    @Autowired
    private DiamondEnv diamondEnv;
    @Autowired
    private IMeidianBindingRelationService meidianBindingRelationService;
    @Autowired
    private MShopShareBindingService mShopShareBindingService;
    @Autowired
    private RedisLockUtils redisLockUtils;

    @Override
    @SneakyLog("小美帮帮查询绑定关系")
    public MapResults<MeidianBindingRelationDto> getRelationByUserId(Long userId, String invokeFrom) {
        if (StringUtils.isBlank(invokeFrom)) {
            return new MapResults<>(ExceptionCodeEnum.NO_INVOKE_FROM);
        }
        if (NumberUtils.isNullOrZero(userId)) {
            return new MapResults<>(ExceptionCodeEnum.ERROR_PARAM);
        }
        try {
            MeidianBindingRelationDto meidianBindingRelationDto = meidianBindingRelationService.queryBindingRelationByUserId(userId);
            if (meidianBindingRelationDto == null) {
                MShopShareBindingDto mShopShareBindingDto = mShopShareBindingService.queryShareBindingByUserId(userId);
                if (mShopShareBindingDto == null) {
                    return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
                }
                MeidianBindingRelationDto model = new MeidianBindingRelationDto();
                model.setUserId(mShopShareBindingDto.getUserId());
                model.setPuserId(mShopShareBindingDto.getUpUserId());
                model.setChannel(UserBizMgrEnum.CPA.getBizName());
                MapResults<Integer> addBindingRelationResult = this.addBindingRelation(model, "meidian-service-user-compensate");
                if (addBindingRelationResult.getSuccess()) {
                    return new MapResults<>(meidianBindingRelationService.queryBindingRelationByUserId(userId));
                }
            }

            return new MapResults<>(meidianBindingRelationDto);
        } catch (Exception e) {
            log.error("小美帮帮查询绑定关系 发生异常,userId:{},invokeFrom:{},异常堆栈如下:", userId, invokeFrom, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    @Override
    @SneakyLog("小美帮帮建立绑定关系")
    public MapResults<Integer> addBindingRelation(MeidianBindingRelationDto meidianBindingRelationDto, String invokeFrom) {
        if (StringUtils.isBlank(invokeFrom)) {
            return new MapResults<>(ExceptionCodeEnum.NO_INVOKE_FROM);
        }
        if (NumberUtils.isNullOrZero(meidianBindingRelationDto.getUserId()) || NumberUtils.isNullOrZero(meidianBindingRelationDto.getPuserId())) {
            return new MapResults<>(ExceptionCodeEnum.ERROR_PARAM);
        }
        String redisKey = CommUtils.getRedisKey(CacheConstant.BIZ_USER_RELATION_MUTEX_LOCK_PREFIX, meidianBindingRelationDto.getChannel(), meidianBindingRelationDto.getUserId());
        boolean resubmitLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisKey);
            if (!resubmitLock) {
                return new MapResults<>(ExceptionCodeEnum.CHANG_TYPE_QUICKLY);
            }
            MeidianBindingRelationDto userResult = meidianBindingRelationService.queryBindingRelationByUserId(meidianBindingRelationDto.getUserId());
            if (userResult != null) {
                return new MapResults<>(ExceptionCodeEnum.ADD_USER_EXISTS);
            }
            String activityId = diamondEnv.getValue(DiamondEnum.MEIDIAN_CPA_ACTIVITY, DiamondConstant.MEIDIAN_CPA_ACTIVITY_ACTIVITYID);
            meidianBindingRelationDto.setActivityId(activityId);
            int i = meidianBindingRelationService.addBindingRelation(meidianBindingRelationDto);
            return new MapResults<>(i);
        } catch (Exception e) {
            log.error("小美帮帮建立绑定关系 发生异常,meidianBindingRelationDto:{},invokeFrom:{},异常堆栈如下:", meidianBindingRelationDto, invokeFrom, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        } finally {
            redisLockUtils.unlock(resubmitLock, redisKey);
        }
    }

    @Override
    @SneakyLog("更新用户状态")
    public MapResults<Integer> updateRelationStatus(Long userId, Integer status, String invokeFrom) {
        if (StringUtils.isBlank(invokeFrom)) {
            return new MapResults<>(ExceptionCodeEnum.NO_INVOKE_FROM);
        }
        if (NumberUtils.isNullOrZero(userId) || null == status) {
            return new MapResults<>(ExceptionCodeEnum.ERROR_PARAM);
        }
        try {
            int i = meidianBindingRelationService.updateRelationStatus(userId, status);
            return new MapResults<>(i);
        } catch (Exception e) {
            log.error("更新用户状态 发生异常,userId:{},status:{},invokeFrom:{},异常堆栈如下:", userId, status, invokeFrom, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    @Override
    @SneakyLog("根据筛选条件获取用户列表")
    public MapResults<List<MeidianBindingRelationDto>> getListByParam(Map<String, Object> param) {
        if (null == param) {
            return new MapResults<>(400, "入参那不能为null");
        }
        try {
            String activityId = diamondEnv.getValue(DiamondEnum.MEIDIAN_CPA_ACTIVITY, DiamondConstant.MEIDIAN_CPA_ACTIVITY_ACTIVITYID);
            param.put("activityId", activityId);
            List<MeidianBindingRelationDto> listByParam = meidianBindingRelationService.getListByParam(param);
            return new MapResults<>(listByParam);
        } catch (Exception e) {
            log.error("根据筛选条件获取用户列表 发生异常,param:{},异常堆栈如下:", param, e);
            return new MapResults<>(new ArrayList<>());
        }

    }

    @Override
    @SneakyLog("根据筛选条件获取用户数量")
    public MapResults<List<MeidianBindingRelationDto>> getCountByStatus(Map<String, Object> param) {
        if (null == param) {
            return new MapResults<>(400, "入参那不能为null");
        }
        try {
            String activityId = diamondEnv.getValue(DiamondEnum.MEIDIAN_CPA_ACTIVITY, DiamondConstant.MEIDIAN_CPA_ACTIVITY_ACTIVITYID);
            param.put("activityId", activityId);
            List<MeidianBindingRelationDto> listByParam = meidianBindingRelationService.getCountByStatus(param);
            return new MapResults<>(listByParam);
        } catch (Exception e) {
            log.error("根据筛选条件获取用户数量 发生异常,param:{},异常堆栈如下:", param, e);
            return new MapResults<>(new ArrayList<>());
        }

    }

    @Override
    @SneakyLog("根据上级id统计下级用户数量")
    public MapResults<List<MeidianBindingRelationDto>> getCountByPuserId(Map<String, Object> param) {
        if (null == param) {
            return new MapResults<>(400, "入参那不能为null");
        }
        try {
            String activityId = diamondEnv.getValue(DiamondEnum.MEIDIAN_CPA_ACTIVITY, DiamondConstant.MEIDIAN_CPA_ACTIVITY_ACTIVITYID);
            param.put("activityId", activityId);
            List<MeidianBindingRelationDto> listByParam = meidianBindingRelationService.getCountByPuserId(param);
            return new MapResults<>(listByParam);
        } catch (Exception e) {
            log.error("根据上级id统计下级用户数量 发生异常,param:{},异常堆栈如下:", param, e);
            return new MapResults<>(new ArrayList<>());
        }

    }

    @Override
    public void process(String msgId, String msgBody) {
        MshopShareRecordDto mshopShareRecordDto = JSONObject.parseObject(msgBody, MshopShareRecordDto.class);
        if (!BizConstant.BING_USER_RELATION.equals(mshopShareRecordDto.getNewUser())) {
            return;
        }
        MeidianBindingRelationDto meidianBindingRelationDto = new MeidianBindingRelationDto();
        meidianBindingRelationDto.setUserId(mshopShareRecordDto.getUserId());
        meidianBindingRelationDto.setPuserId(mshopShareRecordDto.getPuserId());
        meidianBindingRelationDto.setChannel(UserBizMgrEnum.CPA.getBizName());
        MeidianBindingRelationManager meidianBindingRelationManager = (MeidianBindingRelationManager) AopContext.currentProxy();
        MapResults<Integer> addBindingRelationResult = meidianBindingRelationManager.addBindingRelation(meidianBindingRelationDto, mshopShareRecordDto.getInvokeFrom());
        if (!addBindingRelationResult.getSuccess() && gcache.increx(CacheConstant.USER_RELATION_MQ_CHANNEL_RETRY_INCR_PREFIX + msgId, CacheConstant.CACHE_TIME_ONE_DAY) <= 3) {
            process(msgId, msgBody);
        }
    }
}
