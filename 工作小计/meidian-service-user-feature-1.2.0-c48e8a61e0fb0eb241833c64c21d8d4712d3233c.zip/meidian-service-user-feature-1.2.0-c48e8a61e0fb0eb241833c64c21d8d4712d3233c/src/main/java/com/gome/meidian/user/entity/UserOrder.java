package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 用户订单信息表
 * table:md_user_center.user_order
 *
 */
public class UserOrder implements Serializable {
	private static final long serialVersionUID = -5026787169261944088L;
	private Long id;
	/**
	 * 用户ID
	 */
	private String userId;
    /**
     * 订单累计数量
     */
	private Long orderCount;
	/**
	 * 最近一次购买时间
	 */
	private Date utime;
	/**
	 * 首单时间
	 */
	private Date ctime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Long getOrderCount() {
		return orderCount;
	}
	public void setOrderCount(Long orderCount) {
		this.orderCount = orderCount;
	}
	public Date getUtime() {
		return utime;
	}
	public void setUtime(Date utime) {
		this.utime = utime;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	@Override
	public String toString() {
		return "UserOrder [id=" + id + ", userId=" + userId + ", orderCount=" + orderCount + ", utime=" + utime
				+ ", ctime=" + ctime + "]";
	}

	
	

}
