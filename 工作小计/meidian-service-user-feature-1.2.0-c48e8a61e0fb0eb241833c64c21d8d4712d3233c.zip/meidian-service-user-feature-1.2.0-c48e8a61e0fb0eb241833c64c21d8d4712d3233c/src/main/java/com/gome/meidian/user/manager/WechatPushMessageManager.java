package com.gome.meidian.user.manager;

import java.util.ArrayList;
import java.util.List;

import com.gome.meidian.user.exception.ExceptionCodeEnum;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.WechatMsgDto;

import cn.binarywang.wx.miniapp.api.WxMaService;
import cn.binarywang.wx.miniapp.api.impl.WxMaServiceImpl;
import cn.binarywang.wx.miniapp.bean.WxMaTemplateData;
import cn.binarywang.wx.miniapp.bean.WxMaTemplateMessage;
import cn.binarywang.wx.miniapp.bean.WxMaUniformMessage;
import cn.binarywang.wx.miniapp.config.WxMaInMemoryConfig;
import me.chanjar.weixin.common.error.WxErrorException;

@SuppressWarnings("rawtypes")
@Component("wechatPushMessageManager")
public class WechatPushMessageManager implements WechatManager{
	
	private static Logger logger = LoggerFactory.getLogger(UserGomeInfoManager.class);
    
	/**
	 * 发送微信小程序消息
	 * wechatMsgDto 消息内容
	 * sendType 0:统一服务消息  1:模板消息
	 */
    @Override
    public MapResults pushWxSmallMessage(WechatMsgDto wechatMsgDto){
    	logger.info("pushWxSmallMessage,wechatMsgDto:{}",wechatMsgDto.toString());
    	//判断参数
    	int sendType = wechatMsgDto.getSendType();
    	if(sendType!=0||sendType!=1){
    		MapResults mapResults = new MapResults(10900,"消息类型不正确");
    		return mapResults;
    	}
    	String openid = wechatMsgDto.getOpenid();
    	String formId = wechatMsgDto.getFormId();
    	String templateId = wechatMsgDto.getTemplateId();
    	List<String> keywords = wechatMsgDto.getKeywords();
    	String appId = wechatMsgDto.getAppId();
    	String appSecret = wechatMsgDto.getAppSecret();
        if(StringUtils.isBlank(openid)||StringUtils.isBlank(formId)||StringUtils.isBlank(templateId)||
        		CollectionUtils.isEmpty(keywords)||StringUtils.isBlank(appId)||StringUtils.isBlank(appSecret)){
            MapResults mapResults = new MapResults(10900,"消息参数不能为空");
            return mapResults;
        }
        //消息数据封装
        List<WxMaTemplateData> wxMaTemplateDatas = this.templateDataListSetting(wechatMsgDto);
        //配置信息封装
        WxMaService wxMaService = this.wxServiceSetting(wechatMsgDto);
        //发送消息内容  0:统一服务消息  1:模板消息
        if(sendType==0){
        	return this.pushServerMsg(wechatMsgDto,wxMaTemplateDatas,wxMaService);
        }else{
        	return this.pushTempleteMsg(wechatMsgDto,wxMaTemplateDatas,wxMaService);
        }
    }
    
    //发送模版消息
    private MapResults pushTempleteMsg(WechatMsgDto wechatMsgDto,List<WxMaTemplateData> wxMaTemplateDatas,WxMaService wxMaService){
    	MapResults mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    	WxMaTemplateMessage templateMessage = WxMaTemplateMessage.builder()
                .toUser(wechatMsgDto.getOpenid())//要推送的用户openid
                .formId(wechatMsgDto.getFormId())//收集到的formid
                .templateId(wechatMsgDto.getTemplateId())//推送的模版id（在小程序后台设置）dFtKg5UfE694Vq2Qgn-vk5S-9SVDIcTW26HKI5kFrXo
                .data(wxMaTemplateDatas)//模版信息
                .page(wechatMsgDto.getPageIndex())//要跳转到小程序那个页面 pages/index/index
                .emphasisKeyword(wechatMsgDto.getEmphasiskeyword())
                .build();
        //发送推送
        try{
            wxMaService.getMsgService().sendTemplateMsg(templateMessage);
        }catch(WxErrorException w){
        	mapResults = new MapResults(w.getError().getErrorCode(), w.getError().getErrorMsg());
        }catch(Exception e) {
            mapResults = new MapResults(10500,"模板消息推送异常");
        }
        return mapResults;
    }
    
    //发送统一服务消息
    private MapResults pushServerMsg(WechatMsgDto wechatMsgDto,List<WxMaTemplateData> wxMaTemplateDatas,WxMaService wxMaService){
    	MapResults mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    	WxMaUniformMessage wxMaUniformMessage = WxMaUniformMessage.builder()
                .isMpTemplateMsg(false)
                .appid(wechatMsgDto.getAppId())
                .toUser(wechatMsgDto.getOpenid())//要推送的用户openid
                .formId(wechatMsgDto.getFormId())//收集到的formid
                .templateId(wechatMsgDto.getTemplateId())//推送的模版id（在小程序后台设置）dFtKg5UfE694Vq2Qgn-vk5S-9SVDIcTW26HKI5kFrXo
                .data(wxMaTemplateDatas)//模版信息
                .page(wechatMsgDto.getPageIndex())//要跳转到小程序那个页面 pages/index/index
                .emphasisKeyword(wechatMsgDto.getEmphasiskeyword())
                .build();
        //发送推送
        try {
            wxMaService.getMsgService().sendUniformMsg(wxMaUniformMessage);
        }catch(WxErrorException w){
        	mapResults = new MapResults(w.getError().getErrorCode(), w.getError().getErrorMsg());
        }catch(Exception e) {
            mapResults = new MapResults(10500,"统一服务消息推送异常");
        }
        return mapResults;
    }
    
    //消息数据封装   设置模版信息（keyword1:类型，keyword2:内容）
    private List<WxMaTemplateData> templateDataListSetting(WechatMsgDto wechatMsgDto) {
        List<WxMaTemplateData> templateDataList = new ArrayList<>(10);
    	List<String> keywords = wechatMsgDto.getKeywords();
    	for (int i = 0; i < keywords.size(); i++) {
    		WxMaTemplateData keyword = new WxMaTemplateData("keyword"+i,keywords.get(i));
            templateDataList.add(keyword);
		}
    	return templateDataList;
    }
    
	//配置信息封装
    private WxMaService wxServiceSetting(WechatMsgDto wechatMsgDto) {
        WxMaService wxMaService = new WxMaServiceImpl();
        WxMaInMemoryConfig wxMaInMemoryConfig = new WxMaInMemoryConfig();
        wxMaInMemoryConfig.setAppid(wechatMsgDto.getAppId());//小程序appid wx76e7d2df90003848
        wxMaInMemoryConfig.setSecret(wechatMsgDto.getAppSecret());//小程序AppSecret
        wxMaService.setWxMaConfig(wxMaInMemoryConfig);
        return wxMaService;
    }
    
}
