package com.gome.meidian.user.service;

import java.io.Serializable;

import com.gome.meidian.user.mapper.BaseMapper;
/**
 * 服务层抽象类
 *
 * @param <T>
 * @param <ID>
 */
public abstract class AbstractService<T, ID extends Serializable> implements BaseService<T, ID> {
	protected BaseMapper<T, ID> baseMapper;
	public abstract void setBaseMapper();
	@Override
	public int add(T t) {
		// TODO Auto-generated method stub
		this.setBaseMapper();
		return baseMapper.add(t);
	}

	@Override
	public int deleteById(ID id) {
		// TODO Auto-generated method stub
		this.setBaseMapper();
		return baseMapper.deleteById(id);
	}

	@Override
	public int update(T t) {
		// TODO Auto-generated method stub
		this.setBaseMapper();
		return baseMapper.update(t);
	}

	@Override
	public T findById(ID id) {
		// TODO Auto-generated method stub
		this.setBaseMapper();
		return baseMapper.findById(id);
	}


}
