package com.gome.meidian.user.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.AbsenteeismCount;
import com.gome.meidian.user.entity.UserGomeInfo;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.AbsenteeismCountService;
import com.gome.meidian.user.service.UserGomeInfoService;
import com.gome.memberCore.lang.MapResult;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;

import redis.Gcache;

@Component
public class AbsenteeismCountManager implements IAbsenteeismCountManager{
	private static Logger logger = LoggerFactory.getLogger(AbsenteeismCountManager.class);
	private static final String absenteeismCountKey = "user.center.absenteeismCount.manager";//存储矿工信息的缓存key
	private static final String defaulSysGiveCountCache ="user.center.absenteeismCount.defaulSysGiveCountCache";
	@Value("${gome.userCenter.absenteeismCount.sysGiveCount}")
	private String defaulSysGiveCount;
	@Autowired
	private Gcache gcache;
	@Autowired
	private AbsenteeismCountService absenteeismCountService;
	@Autowired
	private UserGomeInfoService userGomeInfoService;
	private String userGomeInfoKey = "user.center.userGomeInfo.manager";
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	//调用会员组公共参数  invokeFrom
	public static final String INVOKE_FROM = "gomeShop";
    /**
     * 获取用户（矿工）助力信息
     * @param userId
     * @return
     */
	public MapResults<AbsenteeismCount> findAbsenteeismCountByUserId(String userId) {
		MapResults<AbsenteeismCount> result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
		if(StringUtils.isBlank(userId)) {
			logger.error("获取用户（矿工）助力信息，userId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			//逻辑如下
			//1、获取矿工信息（先从缓存信息，如果缓存不存在从数据库查询）
			//2、判断当前日期是否为 系统最近一次赠送时间，如果是 则认为有效,返回助理信息，如果不是，重置系统助理次数（先从缓存读取，如果缓存不存在设置默认数据）
			AbsenteeismCount absenteeismCount = null;
			String key = absenteeismCountKey+ ":" + userId;
			String absenteeismCountStr = gcache.get(key);
			if(StringUtils.isNotBlank(absenteeismCountStr)) {
				absenteeismCount = JSONObject.parseObject(absenteeismCountStr, AbsenteeismCount.class);
			}else{
				absenteeismCount = absenteeismCountService.findByUserId(userId);
			}
			if(absenteeismCount != null){
					SimpleDateFormat formatdate = new SimpleDateFormat("YYYY-MM-dd");//日期算换格式
					String sysUtime = formatdate.format(absenteeismCount.getSysUtime());
					String nowDate = formatdate.format(new Date());
					if(sysUtime.equals(nowDate)){
						gcache.set(absenteeismCountKey+ ":" + userId,JSONObject.toJSONString(absenteeismCount));
						//如果相等有效，封装助力信息返回
						result.setBuessObj(absenteeismCount);
					}else{
	                    //否则无效，当前覆盖之前
							absenteeismCount = updateAbsenteeismCountSysCount(userId);
							result.setBuessObj(absenteeismCount);
					}
			}else{
				absenteeismCount = insertAbsenteeismCount(userId);
				result.setBuessObj(absenteeismCount);
			}
		}catch(Exception e) {
			logger.error("获取用户（矿工）助力信息异常，userId:{}，message:{}", userId,e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		
		return result;
	}
	
    /**
     * 更新助力次数
     * @param userId
     * @param operate 操作类型 0:增加 1:减少
     * @param helpType 助力类型 0:系统 1:购买
     * @return
     */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public MapResults<Boolean> updateAbsenteeismCountByUserId(String userId, Integer operate,Integer helpType) {
		MapResults<Boolean> result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
		if(StringUtils.isBlank(userId)) {
			logger.error("获取用户（矿工）助力信息，userId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		if(operate == null || helpType == null){
			logger.error("获取用户（矿工）助力信息，操作类型和运算类型为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		
		try{
			AbsenteeismCount absenteeismCount = absenteeismCountService.findByUserId(userId);
			if(absenteeismCount == null){
				result.setBuessObj(false);
				return result;
			}
	        if(operate == 0){
	        	if(helpType == 0 && absenteeismCount.getSysGiveCount() != null ){
	        		absenteeismCount.setSysGiveCount(absenteeismCount.getSysGiveCount()+1);
	        		absenteeismCount.setUserBuyCount(null);
	        	}else if(helpType == 1 && absenteeismCount.getUserBuyCount() != null  ){
	        		absenteeismCount.setUserBuyCount(absenteeismCount.getUserBuyCount()+1);
	        		absenteeismCount.setSysGiveCount(null);
	        	}else{
	        		result.setBuessObj(false);
	        		return result;
	        	}
	        }else if(operate == 1){
	        	if(helpType == 0 && absenteeismCount.getSysGiveCount() != null && absenteeismCount.getSysGiveCount()>0){
	        		absenteeismCount.setSysGiveCount(absenteeismCount.getSysGiveCount()-1);
	        		absenteeismCount.setUserBuyCount(null);
	        	}else if(helpType == 1 && absenteeismCount.getUserBuyCount() != null && absenteeismCount.getUserBuyCount()>0){
	        		absenteeismCount.setUserBuyCount(absenteeismCount.getUserBuyCount()-1);
	        		absenteeismCount.setSysGiveCount(null);
	        	}else{
	        		result.setBuessObj(false);
	        		return result;
	        	}
	        }else{
        		result.setBuessObj(false);
        		return result;
	        }
	        absenteeismCount.setUtime(new Date());
	        int flag = absenteeismCountService.updateCount(absenteeismCount);
	        if(flag > 0){
	        	refreshCache(userId);
	        	result.setBuessObj(true);
	        }else{
	        	result.setBuessObj(false);
	        }
		}catch(Exception e) {
			logger.error("更新助力次数信息异常，userId:{}，operate{}，helpType{}，message:{}", userId,operate,helpType,e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
        return result;
	}
	/**
	 * 刷新缓存
	 * @param userId
	 */
	private AbsenteeismCount refreshCache(String userId){
		String key = absenteeismCountKey+ ":" + userId;
		AbsenteeismCount absenteeismCount = absenteeismCountService.findByUserId(userId);
		gcache.set(key,JSONObject.toJSONString(absenteeismCount));
		return absenteeismCount;
	}
	
	/**
	 * 更新助力信息
	 * @param absenteeismCount
	 * @return
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	private int updateAbsenteeismCount(AbsenteeismCount absenteeismCount){
		return absenteeismCountService.update(absenteeismCount);
	}

	/**
	 * 添加系统助力信息
	 * @param userId
	 * @return
	 * @throws ParseException 
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public AbsenteeismCount insertAbsenteeismCount(String userId) {
		AbsenteeismCount resultAbsenteeismCount = null;
		//查询是否有该用户
		UserGomeInfo userGomeInfo = null;
		String key = userGomeInfoKey + ":" + userId;
		String userStr = gcache.get(key);
		//查询缓存
		if(StringUtils.isNotBlank(userStr)) {
		   userGomeInfo = JSONObject.parseObject(userStr, UserGomeInfo.class);
		}
		//查询数据库
		if(userGomeInfo == null){
			userGomeInfo = userGomeInfoService.findByUserId(userId);
		}
		if(userGomeInfo == null){
			try {
				//查询会员组服务
				Map<String, Object> param = new HashMap<>();
				param.put("companyName", "gomeOnLine");
				MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(userId, INVOKE_FROM, param);
				if(null != userResult && userResult.isSuccess()) {
					UnifyUserInfoExt info = userResult.getBuessObj();
					if(null != info && StringUtils.isNotBlank(info.getRegisterDateSting())) {
						UserGomeInfo addUserGomeInfo = new UserGomeInfo();
						addUserGomeInfo.setUserId(userId);
						addUserGomeInfo.setRegisterTime(new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(info.getRegisterDateSting()));
						Date date = new Date();
						addUserGomeInfo.setCtime(date);
						addUserGomeInfo.setUtime(date);
						int flag = userGomeInfoService.insertUserGomeInfo(addUserGomeInfo);
						if(flag > 0){
							gcache.set(key, JSONObject.toJSONString(addUserGomeInfo));
							userGomeInfo = addUserGomeInfo;
						}
					}
				}
			}catch(Exception e){
				logger.error("获取用户注册信息异常，userId"+userId,e);
			}
		}
		if(userGomeInfo != null){
			try {
				// 否则无效，当前覆盖之前
				String sysGiveCount = gcache.get(defaulSysGiveCountCache);
				if (StringUtils.isBlank(sysGiveCount)) {
					sysGiveCount = defaulSysGiveCount;// 缓存没有，从默认配置项取值
				}
				AbsenteeismCount absenteeismCount = new AbsenteeismCount();
				// 增加操作
				Date inDate = new Date();
				absenteeismCount = new AbsenteeismCount();
				absenteeismCount.setUserId(userId);
				absenteeismCount.setSysGiveCount(Integer.valueOf(sysGiveCount));
				absenteeismCount.setCtime(inDate);
				absenteeismCount.setUtime(inDate);
				absenteeismCount.setSysCtime(inDate);
				absenteeismCount.setSysUtime(inDate);
				int flag1 = absenteeismCountService.add(absenteeismCount);
				if (flag1 > 0) {
					String keyq = absenteeismCountKey+ ":" + userId;
					gcache.set(keyq,JSONObject.toJSONString(absenteeismCount));
					resultAbsenteeismCount = absenteeismCount;
				}
			}catch (Exception e) {
				logger.error("添加用户（矿工）助力信息异常"+userId, e);
			}
		}
		return resultAbsenteeismCount;
	}
	/**
	 * 更新购买系统购买次数
	 * @param userId
	 * @return
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public AbsenteeismCount updateAbsenteeismCountSysCount(String userId){
        //否则无效，当前覆盖之前
		String sysGiveCount = gcache.get(defaulSysGiveCountCache);
		if(StringUtils.isBlank(sysGiveCount)){
			sysGiveCount = defaulSysGiveCount;//缓存没有，从默认配置项取值
		}
		AbsenteeismCount absenteeismCount = new AbsenteeismCount();
		Date upDate = new Date();
		absenteeismCount.setUserId(userId);
		absenteeismCount.setSysUtime(new Date());
		absenteeismCount.setUtime(upDate);
		absenteeismCount.setSysGiveCount(Integer.valueOf(sysGiveCount));
		int flag = updateAbsenteeismCount(absenteeismCount);
		if(flag > 0){
			absenteeismCount = refreshCache(userId);
		}else{
			absenteeismCount = null;
		}
		return absenteeismCount;
	}

}
