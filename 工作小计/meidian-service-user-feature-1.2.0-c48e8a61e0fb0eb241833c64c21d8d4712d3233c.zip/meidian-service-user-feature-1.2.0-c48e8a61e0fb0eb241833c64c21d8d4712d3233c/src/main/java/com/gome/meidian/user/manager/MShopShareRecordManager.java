package com.gome.meidian.user.manager;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.entity.MeidianShareChangeBind;
import com.gome.meidian.service.IUserRelationService;
import com.gome.meidian.user.constant.BizConstant;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.constant.TaskCommonConstant;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.dto.SharedBindFusionDTO;
import com.gome.meidian.user.entity.MShopShareMessage;
import com.gome.meidian.user.entity.MeidianShareBindingCtx;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.enums.UserIdentityEnum;
import com.gome.meidian.user.enums.UserType;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.mapper.MeidianShareBindingCtxMapper;
import com.gome.meidian.user.mq.MQProducer;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.MShopShareRecordService;
import com.gome.meidian.user.service.MShopWechatService;
import com.gome.meidian.user.service.UserRelationCacheService;
import com.gome.meidian.user.utils.UploadPicThread;
import com.gome.meidian.user.utils.UrlUtils;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import com.gome.userBase.model.weChat.GomeShopBasicInfoModel;
import com.gome.userCenter.facade.login.ISNSLoginFacade;
import com.gome.userCenter.model.UserInfo;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.exceptions.BizException;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.google.common.collect.Lists;
import redis.Gcache;

/**
 * @author chenchen-ds6
 */
@Component("mShopShareRecordManager")
public class MShopShareRecordManager implements IMShopShareRecordManager {
    private static Logger logger = LoggerFactory.getLogger(MShopShareRecordManager.class);
    @Autowired
    MShopShareRecordService mshopShareRecordService;
    @Autowired
    MShopShareBindingService mshopShareBindingService;
    @Autowired
    MShopShareRecordMapper mShopShareRecordMapper;
    //会员接口
    @Autowired
    ISNSLoginFacade ISNSLoginFacade;
    @Autowired
    MShopWechatService mShopWechatService;
    //美店主
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private RedisLockUtils redisLockUtils;
    @Autowired
    ThreadPoolExecutor threadPoolExecutor;
    @Autowired
    IGomeShopWeChatFacade gomeShopWeChatFacade;
    @Autowired
    IUserRelationService iUserRelationService;
    @Autowired
    MShopShareMessageManager mShopShareMessageManager;
    @Autowired
    private Gcache gcache;
    @Autowired
    private UserRelationCacheService relationCacheService;
    @Autowired
    private MeidianShareBindingCtxMapper ctxMapper;
    @Autowired
    private UploadPicThread uploadPicThread;

    @Value("${mq.bigdata.topic}")
    private String topic;
    @Value("${mq.meidian.job.addCTag}")
    private String executeTaskAddC;
    @Value("${mq.meidian.job.invateCToB}")
    private String executeTaskAddB;
    @Value("${business.meidian.pianzong_userid}")
    private Long topLeaderUserId;
    @Value("${business.meidian.pianzong_mid}")
    private Long topLeaderMid;
    private String CACHE_PREFIX = "MEIDIAN_USER_RELATION_";

    /**
     * 用户链分享保存
     *
     * @param requestParam
     */
    @Override
    @SneakyLog("新建绑定或者分享链关系")
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults<MshopShareRecordDto> addMshopShareRecord(MshopShareRecordDto requestParam) {
        if (null == requestParam) {
            return new MapResults<>(ExceptionCodeEnum.SHARE_USERID_UNIQUEID_PARAM);
        }
        if (null == requestParam.getNewUser()) {
            return new MapResults<>(ExceptionCodeEnum.SHARE_NEWUSER_PARAM);
        }
        if (NumberUtils.isNullOrZero(requestParam.getPuserId())) {
            return new MapResults<>(ExceptionCodeEnum.SHARE_USERID_UNIQUEID_PARAM);
        }
        if (null != requestParam.getUserId() && requestParam.getUserId().equals(requestParam.getPuserId())) {
            return new MapResults<>(ExceptionCodeEnum.SAME_SHARE);
        }
        if (StringUtils.isNotBlank(requestParam.getUniqueId()) && requestParam.getPuserId().equals(queryUserIdByUniqueId(requestParam.getUniqueId()))) {
            return new MapResults<>(ExceptionCodeEnum.SAME_SHARE);
        }
        try {
            //授权
            if (BizConstant.BING_SHARE_RECORD.equals(requestParam.getNewUser()) && StringUtils.isNotBlank(requestParam.getUniqueId())) {
                dealWithShareRecord(requestParam);
                return new MapResults<>();
            }
            //注册
            if (BizConstant.BING_USER_RELATION.equals(requestParam.getNewUser()) && requestParam.getUserId() != null) {
                if (StringUtils.isBlank(requestParam.getUniqueId())) {
                    requestParam.setUniqueId(queryUniqueIdByUserId(requestParam.getUserId()));
                }
                MapResults<MshopShareBinding> results = addBindingRelationOfMZ(requestParam);
                return new MapResults<>(results.getCode(), results.getMessage());
            }
            return new MapResults<>(ExceptionCodeEnum.ERROR_PARAM);

        } catch (Exception e) {
            logger.error("保存分享链或者绑定关系发生异常, requestParam:{} ,异常堆栈如下：", requestParam, e);
            throw e;
        }
    }


    /**
     * 用户链分享保存
     *
     * @param mshopShareRecordDto
     */
    @Override
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults<MshopShareRecordDto> logOnAddMshopShareRecord(MshopShareRecordDto mshopShareRecordDto) {
        return new MapResults<>(ExceptionCodeEnum.INTERFACE_CLOSED);
    }

    /**
     * 用户授权
     *
     * @param mshopShareRecordDto
     * @return
     */
    @Override
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults userAuthorization(MshopShareRecordDto mshopShareRecordDto) {
        return null;
    }

    @Override
    @SneakyLog("修改用户首单、忠粉的状态")
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults updateUserRecord(MshopShareRecordDto mshopShareRecordDto) {
        try {
            MshopShareBinding mshopShareBinding = new MshopShareBinding();
            mshopShareBinding.setUserId(mshopShareRecordDto.getUserId());
            MshopShareBinding rtnMshopShareBinding = mshopShareBindingService.queryByParam(mshopShareBinding);
            if (rtnMshopShareBinding == null || !rtnMshopShareBinding.getType().equals(mshopShareRecordDto.getType())) {
                return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
            }
            if (UserType.NewCustom.getType().equals(mshopShareRecordDto.getType())) {
                mshopShareBinding.setType(UserType.FirstOrder.getType());
            } else if (UserType.FirstOrder.getType().equals(mshopShareRecordDto.getType())) {
                mshopShareBinding.setType(UserType.Fans.getType());
            }
            mshopShareBindingService.updateMshopShareBinding(mshopShareBinding);
            relationCacheService.refreshUserRelation(rtnMshopShareBinding);
            return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        } catch (Exception e) {
            logger.info("修改用户首单、忠粉的状态发生异常,mshopShareRecordDto:{},异常堆栈如下:", mshopShareRecordDto, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    @Override
    @SneakyLog("建立绑定关系，融合原有的会员关系")
    public MapResults<Boolean> createBindRelation(SharedBindFusionDTO sharedBindFusionDTO) {
        boolean resubmitLock = Boolean.FALSE;
        MshopShareBinding model = new MshopShareBinding();
        String redisKey = CommUtils.getRedisKey(CacheConstant.USER_BIND_RELATION_INCR_PREFIX, sharedBindFusionDTO.getUserId());
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisKey);
            if (!resubmitLock) {
                return new MapResults<>(400, "关系创建中...");
            }
            org.springframework.beans.BeanUtils.copyProperties(sharedBindFusionDTO, model);
            return new MapResults<>(mshopShareBindingService.createBindRelation(model));
        } catch (BizException e) {
            return new MapResults<>(e.getCode(), e.getMessage());
        } catch (Exception e) {
            return new MapResults<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, redisKey);
        }

    }

    @Override
    @SneakyLog("查找下级的uniqueId集合")
    public List<String> queryUniqueIdListByUpUserId(Long upUserId) {
        if (null == upUserId) {
            return null;
        }
        List<String> list = mshopShareRecordService.queryUniqueIdListByUpUserId(upUserId);
        List<String> uniqueList = Lists.newArrayList();
        if (CollectionUtils.isNotEmpty(list)) {
            for (String i : list) {
                if (StringUtils.isNotEmpty(i)) {
                    uniqueList.add(i);
                }
            }
        }
        return uniqueList;

    }

    /**
     * 处理微信头像信息
     *
     * @param mshopShareRecordDto
     */
    public void dealWithWechatInfo(MshopShareRecordDto mshopShareRecordDto) {
        boolean resubmitLock = Boolean.FALSE;
        String redisKey = CacheConstant.DEAL_WITH_WECHAT_INFO_RESUBMIT_LOCK_PREFIX + mshopShareRecordDto.getUniqueId();
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisKey);
            if (!resubmitLock) {
                return;
            }
            String imageUrlDecoded = UrlUtils.dealWithUrl(mshopShareRecordDto.getImage());
            String nickName = UrlUtils.dealWithUrl(mshopShareRecordDto.getNickname());
            mshopShareRecordDto.setImage(imageUrlDecoded);
            mshopShareRecordDto.setNickname(nickName);
            MshopWechatUserInfo wechatInfoModel = new MshopWechatUserInfo();
            copyBeanUtils(wechatInfoModel, mshopShareRecordDto);
            wechatInfoModel.setType(0);
            wechatInfoModel.setOriginalImage(imageUrlDecoded);

            MshopWechatUserInfo query = new MshopWechatUserInfo();
            query.setUniqueId(mshopShareRecordDto.getUniqueId());
            query.setType(0);
            MshopWechatUserInfo wechatInfoDB = mShopWechatService.queryWechatInfoByParam(query);
            logger.info("查询微信表记录,query:{},数据库内容:{}", JSON.toJSON(query), JSON.toJSON(wechatInfoDB));
            if (null == wechatInfoDB) {
                wechatInfoModel.setInsertTime(new Date());
                MshopWechatUserInfo copyWechatInfoModel = new MshopWechatUserInfo();
                copyBeanUtils(copyWechatInfoModel, wechatInfoModel);
                mShopWechatService.insertMShopWechatInfo(wechatInfoModel);
                uploadPicThread.upload(copyWechatInfoModel);
            } else {
                wechatInfoModel.setId(wechatInfoDB.getId());
                wechatInfoModel.setVersion(wechatInfoDB.getVersion());
                if (StringUtils.isNotBlank(wechatInfoModel.getImage()) && !wechatInfoModel.getImage().equals(wechatInfoDB.getOriginalImage())) {
                    uploadPicThread.upload(wechatInfoModel);
                } else {
                    wechatInfoModel.setImage(wechatInfoDB.getImage());
                    mShopWechatService.updateByUniqueId(wechatInfoModel);
                }
            }
        } catch (Exception e) {
            logger.error("处理微信用户信息异常,mshopShareRecordDto:{},异常堆栈如下:", mshopShareRecordDto, e);
        } finally {
            redisLockUtils.unlock(resubmitLock, redisKey);
        }
    }

    /**
     * 处理无登录态的
     *
     * @param request 入参dto
     * @return
     */
    private void dealWithShareRecord(MshopShareRecordDto request) {
        MshopShareRecord recordParam = new MshopShareRecord();
        copyBeanUtils(recordParam, request);
        logger.info("---------------------------保存分享链---------------------,param:{}", JSON.toJSON(recordParam));

        MshopShareRecord shareRecord = mshopShareRecordService.queryByUniqueIdAndPuserId(recordParam);
        if (null != shareRecord) {
            logger.info("shareRecord表中已经存在此次邀请关系, puserId {},uniqueid {} ", recordParam.getPuserId(), recordParam.getUniqueId());
            recordParam.setId(shareRecord.getId());
            mshopShareRecordService.updateMShopShareRecordById(recordParam);
            //relationCacheService.resetShareRecord(recordParam);
            return;
        }

        Long pMid = checkMidByUserId(request.getPuserId());
        if (isNullOrZero(pMid)) {
            logger.info("该邀请人不是美店主，不对分享关系进行记录，邀请人ID {} ", request.getPuserId());
            return;
        }

        if (isNullOrZero(recordParam.getUserId())) {
            recordParam.setUserId(queryUserIdByUniqueId(recordParam.getUniqueId()));
        }

        if (isNullOrZero(recordParam.getUserId())) {
            handlerB_Xiaobai(request, recordParam, pMid);
            return;
        }
        Long mid = checkMidByUserId(recordParam.getUserId());
        if (isNotNullAndZero(mid)) {
            handlerB_B(recordParam, pMid, mid);
            return;
        }
        handlerB_C(request, recordParam, pMid);
    }

    private void handlerB_Xiaobai(MshopShareRecordDto request, MshopShareRecord recordParam, Long pMid) {
        logger.info("-----邀请关系B_小白-------,puserId 是店主{} , uniqueid 是小白 {} ", request.getPuserId(), request.getUniqueId());
        recordParam.setUpuserId(recordParam.getPuserId());
        recordParam.setPmid(pMid);
        recordParam.setUpmid(pMid);
        recordParam.setType(2);
        recordParam.setInsertTime(new Date());
        logger.info("记录分享关系：B--> 小白,记录游客信息，最终入库数据是{} ", recordParam);
        insertGuest(recordParam);
        dealWithWechatInfo(request);
    }

    private void handlerB_C(MshopShareRecordDto request, MshopShareRecord recordParam, Long pMid) {
        logger.info("-----邀请关系B_C-------,puserId 是店主 {} , userId 是普通用户{} ", recordParam.getPuserId(), recordParam.getUserId());
        MshopShareBinding reqMshopShareBinding = new MshopShareBinding();
        reqMshopShareBinding.setUserId(recordParam.getUserId());
        MshopShareBinding mshopShareBinding = mshopShareBindingService.queryByParam(reqMshopShareBinding);
        logger.info("puserId {} , 查找被邀请人 userId {} 的绑定关系,绑定表查询结果 {}", recordParam.getPuserId(), recordParam.getUserId(), mshopShareBinding);
        if (null != mshopShareBinding) {
            return;
        }
        recordParam.setPmid(pMid);
        recordParam.setUpmid(pMid);
        recordParam.setUpuserId(recordParam.getPuserId());
        recordParam.setType(2);
        recordParam.setInsertTime(new Date());
        logger.info("记录分享关系: B --> C(C没有绑定关系)，记录游客,最终入库数据是 {} ", recordParam);
        insertGuest(recordParam);
        dealWithWechatInfo(request);
    }

    private void handlerB_B(MshopShareRecord recordParam, Long pMid, Long mid) {
        logger.info("-----邀请关系B_B-------,puserId 是店主 {} , userId 是店主{} ", recordParam.getPuserId(), recordParam.getUserId());
        recordParam.setType(1);
        recordParam.setPmid(pMid);
        recordParam.setMid(mid);
        recordParam.setInsertTime(new Date());
        logger.info("记录分享关系：B --> B,最终入库数据是 {} ", recordParam);
        insertGuest(recordParam);
    }

    public boolean isNullOrZero(Long userId) {
        return NumberUtils.isNullOrZero(userId);
    }

    public boolean isNotNullAndZero(Long userId) {
        return !NumberUtils.isNullOrZero(userId);
    }

    /**
     * 邀请或者切换店主
     *
     * @param mshopShareRecord
     * @return
     */
    @SneakyLog("切换店主")
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults invateUserOrChangeUpper(MshopShareRecord mshopShareRecord) {
        try {
            MshopShareBinding mshopShareBinding = new MshopShareBinding();
            copyBeanUtils(mshopShareBinding, mshopShareRecord);
            MshopShareBinding rtnMshopShareBinding = mshopShareBindingService.queryByParam(mshopShareBinding);
            if (null == rtnMshopShareBinding) {
                logger.info("绑定关系表中不存在绑定关系，requestParam:{}", mshopShareRecord);
                mshopShareBinding.setUpuserId(null);
                logger.info("查询关系表中当前用户的绑定关系，requesParam:{}", mshopShareRecord);
                MshopShareBinding thisMshopShareBinding = mshopShareBindingService.queryByParam(mshopShareBinding);
                logger.info("查询邀请者的绑定信息,requestPram:{}", mshopShareRecord.getUpuserId());
                mshopShareBinding.setUpuserId(mshopShareRecord.getUpuserId());
                mshopShareBinding.setUserId(null);
                MshopShareBinding invateMshopShareBinding = mshopShareBindingService.queryByParam(mshopShareBinding);
                if (null == invateMshopShareBinding) {
                    logger.info("邀请人的绑定信息，resultParam:{}", invateMshopShareBinding);
                    return new MapResults<>(ExceptionCodeEnum.INVATE_USER_EMPTY);
                }
                logger.info("查询关系表中当前用户的绑定关系，result:{}", thisMshopShareBinding);
                if (null == thisMshopShareBinding) {
                    logger.info("查询当前用户的绑定关系为空,直接进行绑定");
                    mshopShareBinding.setShareChain(mshopShareRecord.getUpuserId().toString());
                    mshopShareBinding.setUpuserId(invateMshopShareBinding.getUpuserId());
                    mshopShareBinding.setPuserId(mshopShareRecord.getUpuserId());
                    mshopShareBinding.setPmid(invateMshopShareBinding.getMid());
                    mshopShareBinding.setTopLeaderUserId(mshopShareRecord.getUpuserId());
                    mshopShareBinding.setTopLeaderMid(invateMshopShareBinding.getMid());
                    logger.info("查询当前用户的绑定关系为空,直接进行插入绑定,requestParam:{}", mshopShareBinding);
                    mshopShareBindingService.insertMShopShareBinding(mshopShareBinding);
                    return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
                } else {
                    logger.info("查询当前用户的绑定关系不为空");
                    String thisUserShareChain = thisMshopShareBinding.getShareChain();
                    if (StringUtils.isBlank(thisUserShareChain)) {
                        mshopShareBinding.setShareChain(mshopShareRecord.getUpuserId().toString());
                    } else {
                        logger.info("当前用户原始联调,shareChain:{}", thisUserShareChain);
                        String newShareChain = thisUserShareChain.replace(thisMshopShareBinding.getUpuserId().toString(), mshopShareRecord.getUpuserId().toString());
                        logger.info("分享绑定新链,shareChain:{}", newShareChain);
                        mshopShareBinding.setShareChain(newShareChain);
                    }
                    mshopShareBinding.setUpuserId(mshopShareRecord.getUpuserId());
                    mshopShareBinding.setUpmid(invateMshopShareBinding.getMid());
                    mshopShareBinding.setPmid(invateMshopShareBinding.getMid());
                    mshopShareBinding.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
                    mshopShareBinding.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
                    mshopShareBinding.setVersion(invateMshopShareBinding.getVersion());
                    logger.info("查询当前用户的绑定关系为空,直接进行更新绑定,requestParam:{}", mshopShareBinding);
                    mshopShareBindingService.changeUpuser(mshopShareBinding);
                    return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
                }

            } else {
                logger.info("绑定关系表中存在绑定关系");
            }
            return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    }

    /**
     * 建立绑定关系
     *
     * @param mshopShareRecord rtnMshopShareBinding
     * @return
     */
    @Deprecated
    public MapResults<MshopShareRecordDto> createMshopShareBinging(MshopShareRecord mshopShareRecord) {
        logger.info("进入绑定关系操作，requestParam:{}", mshopShareRecord);
        try {
            Integer isExist = mshopShareBindingService.selectCountByUserId(mshopShareRecord.getUserId());
            if (null != isExist && isExist.equals(1)) {
                logger.info("当前绑定关系已在绑定表中存在,reqestParam:{},result:{}", mshopShareRecord, isExist);
                return new MapResults<>(ExceptionCodeEnum.INVATE_USER_EXISTING);
            }
            logger.info("绑定表中关系不存在");
            Long midByUnique = checkMidByUnique(mshopShareRecord.getPuniqueId(), mshopShareRecord.getPuserId());
            if (NumberUtils.isNullOrZero(midByUnique)) {
                logger.info("B--C1--C2进行注册");
                logger.info("邀请者不是美店主");
                return dealCtoB(mshopShareRecord);
            }
            logger.info("邀请者是美店主");
            if (NumberUtils.isNullOrZero(mshopShareRecord.getPuserId())) {
                mshopShareRecord.setPuserId(queryUserIdByUniqueId(mshopShareRecord.getPuniqueId()));
            }
            if (NumberUtils.isNullOrZero(mshopShareRecord.getUserId())) {
                mshopShareRecord.setUserId(queryUserIdByUniqueId(mshopShareRecord.getUniqueId()));
            }
            MshopShareBinding mshopShareBinding = new MshopShareBinding();
            Long thisUserMid = checkMidByUserId(mshopShareRecord.getUserId());//
            copyBeanUtils(mshopShareBinding, mshopShareRecord);
            MshopShareBinding pReqmshopShareBinding = new MshopShareBinding();
            MshopShareBinding rtnMshopShareBinding = mshopShareBindingService.getInvateShopInfo(mshopShareRecord.getPuserId());
            if (null != rtnMshopShareBinding) {
                logger.info("邀请者在原始绑定关系表中作为下级存在,requestParam:{}", pReqmshopShareBinding);
                mshopShareBinding.setUpuniqueId(mshopShareRecord.getPuniqueId());
                mshopShareBinding.setUpuserId(rtnMshopShareBinding.getUserId());
                mshopShareBinding.setUpmid(rtnMshopShareBinding.getMid());
                mshopShareBinding.setPmid(midByUnique);
                mshopShareBinding.setTopLeaderMid(rtnMshopShareBinding.getTopLeaderMid());
                mshopShareBinding.setTopLeaderUserId(rtnMshopShareBinding.getTopLeaderUserId());
                String shareChain = rtnMshopShareBinding.getShareChain();
                if (!NumberUtils.isNullOrZero(thisUserMid)) {
                    mshopShareBinding.setShareChain(shareChain + "-" + mshopShareBinding.getUserId());
                } else {
                    mshopShareBinding.setShareChain(shareChain);
                }
            } else {
                logger.info("上级在原绑定表中作为下线存在,result:{}", rtnMshopShareBinding);
                mshopShareBinding.setUpuserId(mshopShareRecord.getPuserId());
                mshopShareBinding.setUpmid(midByUnique);
                mshopShareBinding.setPmid(midByUnique);
                mshopShareBinding.setMid(thisUserMid);
                logger.info("上线前赋值为大锤");
                mshopShareBinding.setTopLeaderUserId(mshopShareRecord.getPuserId());
                mshopShareBinding.setTopLeaderMid(midByUnique);
                logger.info("*************需要注意片总*************");
                if (!NumberUtils.isNullOrZero(thisUserMid)) {
                    mshopShareBinding.setShareChain(mshopShareRecord.getPuserId() + "-" + mshopShareRecord.getUserId());
                } else {
                    mshopShareBinding.setShareChain(mshopShareRecord.getPuserId().toString());
                }
            }
            //            }
            mshopShareBinding.setType(1);//新客
            mshopShareBinding.setInsertTime(new Date());
            mshopShareBindingService.insertMShopShareBinding(mshopShareBinding);
            pushJobMessage(mshopShareBinding.getUserId(), mshopShareBinding.getUpuserId(), 0);
            mshopShareRecord.setUserId(null);
            updateMshopShareRecord(3, mshopShareRecord);
            dealWithStatistic(mshopShareBinding);
            MshopShareRecordDto resultObj = new MshopShareRecordDto();
            resultObj.setUpuserId(mshopShareBinding.getUpuserId());
            logger.info("注册后的返回值,userId:{}", resultObj.getUpuserId());
            return new MapResults<>(resultObj);
        } catch (Exception e) {
            logger.error("进入绑定关系操作发生异常,mshopShareRecord:{},异常堆栈如下:", JSON.toJSON(mshopShareRecord), e);
            return new MapResults<>(ExceptionCodeEnum.BINDING_ERROR);
        }
    }

    /**
     * 更新分享记录
     *
     * @return
     */
    public void updateMshopShareRecord(Integer type, MshopShareRecord mshopShareRecord) {
        logger.info("更新游客信息,type:{},requestParam:{}", type, mshopShareRecord);
        MshopShareRecord updateMshopShareRecord = new MshopShareRecord();
        updateMshopShareRecord.setType(2);
        updateMshopShareRecord.setUniqueId(mshopShareRecord.getUniqueId());
        List<MshopShareRecord> mshopShareRecords = mshopShareRecordService.queryListByParam(updateMshopShareRecord);
        for (MshopShareRecord rtnMshopShareRecord : mshopShareRecords) {
            rtnMshopShareRecord.setType(type);
            mshopShareRecordService.updateMShopShareRecord(rtnMshopShareRecord);
            logger.info("更新游客数据库,type:{},requestParam:{}", type, mshopShareRecord);
        }
        relationCacheService.removeShareRecord(mshopShareRecord.getUniqueId(), mshopShareRecord.getUserId());
    }

    @SneakyLog("通过userId获取uniqueId")
    public String queryUniqueIdByUserId(Long userId) {
        String cachePuniqueId = gcache.get(CACHE_PREFIX + "queryUniqueIdByUserId_" + userId);
        if (StringUtils.isBlank(cachePuniqueId)) {
            ArrayList<String> pUserIdList = new ArrayList<>();
            pUserIdList.add(userId.toString());
            UserResult<List<GomeShopBasicInfoModel>> gomeShop = gomeShopWeChatFacade.batchQueryUserBasicInfo(pUserIdList, "gomeShop");
            if (null != gomeShop) {
                List<GomeShopBasicInfoModel> buessObj = gomeShop.getBuessObj();
                if (null != buessObj && buessObj.size() > 0) {
                    GomeShopBasicInfoModel gomeShopBasicInfoModel = buessObj.get(0);
                    if (StringUtils.isNotBlank(gomeShopBasicInfoModel.getSnsUnionId())) {
                        gcache.setex(CACHE_PREFIX + "queryUniqueIdByUserId_" + userId, 5, gomeShopBasicInfoModel.getSnsUnionId());
                    }
                    return gomeShopBasicInfoModel.getSnsUnionId();
                }
            }
        }
        return cachePuniqueId;
    }

    /**
     * 插入游客   解决   b-->c1-->c2
     * b-->c3-->c2 游客重复记的bug
     *
     * @param mshopShareRecord
     */
    public void insertGuest(MshopShareRecord mshopShareRecord) {
        logger.info("处理插入游客逻辑，reqeustParam:{}", mshopShareRecord);
        if (null != mshopShareRecord && mshopShareRecord.getType().equals(2) && null != mshopShareRecord.getUpuserId()) {
            MshopShareRecord queryRequest = new MshopShareRecord();
            queryRequest.setType(2);
            queryRequest.setUpuserId(mshopShareRecord.getUpuserId());
            queryRequest.setUniqueId(mshopShareRecord.getUniqueId());
            queryRequest.setUserId(mshopShareRecord.getUserId());
            List<MshopShareRecord> list = mshopShareRecordService.queryListByParam(queryRequest);
            if (CollectionUtils.isNotEmpty(list)) {
                logger.info("处理插入游客逻辑,查询数据库中存在响应的数据,数据库返回的值:{}", JSON.toJSON(list));
                return;
            }
        }
        mshopShareRecordService.insertMShopShareRecord(mshopShareRecord);
        relationCacheService.resetShareRecord(mshopShareRecord);
    }

    /**
     * 通过userId获取mid
     *
     * @param userId
     * @return
     */
    private Long checkMidByUserId(Long userId) {
        logger.info("通过userId获取mid，requestParam:{}", userId);
        CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(userId.toString());
        if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
            return vshopInfoCommonResultEntity.getBusinessObj().getVshopId();
        }
        return null;
    }

    private VshopInfo queryVshopInfo(Long userId) {
        CommonResultEntity<VshopInfo> vshopInfo = null;
        try {
            vshopInfo = vshopFacade.queryVshopByuserId(userId.toString());
            if (null != vshopInfo) {
                return vshopInfo.getBusinessObj();
            }
        } catch (Exception e) {
            logger.error("查询美店主数据异常，当前userId {} ", userId, e);
        } finally {
            logger.info("查询美店主数据结果是 {} ，当前userId {} ", JSON.toJSONString(vshopInfo), userId);
        }
        return null;
    }


    /**
     * 通过uniqueId校验是否是美店主
     * userId不为空，查找美店主接口，返回MID，如果没有MID返回null
     * userid为空，uniqueId不为空，掉会员接口拿到uniqueId对应的userID，调用美店接口，返回MID
     *
     * @param uniqueId
     * @return
     */
    public Long checkMidByUnique(String uniqueId, Long userId) {
        Long rtnUserId;
        if (null != userId && !userId.equals(0L)) {
            logger.info("userId不等于空，requestParam:{}", userId);
            String cacheUserId = gcache.get(CACHE_PREFIX + "checkMidByUnique_" + userId);
            if (StringUtils.isBlank(cacheUserId)) {
                CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(userId.toString());
                if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
                    rtnUserId = vshopInfoCommonResultEntity.getBusinessObj().getVshopId();
                    gcache.setex(CACHE_PREFIX + "checkMidByUnique_" + userId, 5, rtnUserId.toString());
                    return rtnUserId;
                }
            } else {
                rtnUserId = Long.parseLong(cacheUserId);
                return rtnUserId;
            }
        }
        if (StringUtils.isNotBlank(uniqueId)) {
            logger.info("调用会员接口通过uniqueId查询用户信息，param:{}", uniqueId);
            HashMap<String, Object> reqMap = new HashMap<>(1);
            reqMap.put("SNSUnionId", uniqueId);
            String cacheUserId = gcache.get(CACHE_PREFIX + "checkMidByUnique_" + uniqueId);
            if (StringUtils.isBlank(cacheUserId)) {
                MapResult<UserInfo> shareSnsInfoById = ISNSLoginFacade.getSnsInfoById(uniqueId, "wechat", "gomeShop", reqMap);
                logger.info("调用会员接口返回值，responseParam:{}", shareSnsInfoById);
                if (null != shareSnsInfoById && shareSnsInfoById.getBuessObj() != null) {
                    UserInfo shareUserInfo = shareSnsInfoById.getBuessObj();
                    CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(shareUserInfo.getId());
                    if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
                        rtnUserId = vshopInfoCommonResultEntity.getBusinessObj().getVshopId();
                        gcache.setex(CACHE_PREFIX + "checkMidByUnique_" + uniqueId, 5, rtnUserId.toString());
                        return rtnUserId;
                    }
                }
            } else {
                rtnUserId = Long.parseLong(cacheUserId);
                return rtnUserId;
            }
        }
        return null;
    }

    /**
     * 通过uniqueId查询userId
     *
     * @param uniqueId
     * @return
     */
    public Long queryUserIdByUniqueId(String uniqueId) {
        logger.info("调用会员接口通过uniqueId查询用户信息，param:{}", uniqueId);
        Long userId;
        String catchResult = gcache.get(CACHE_PREFIX + "queryUserIdByUniqueId_" + uniqueId);
        if (StringUtils.isBlank(catchResult)) {
            HashMap<String, Object> reqMap = new HashMap<>(1);
            reqMap.put("SNSUnionId", uniqueId);
            MapResult<UserInfo> shareSnsInfoById = ISNSLoginFacade.getSnsInfoById(uniqueId, "wechat", "gomeShop", reqMap);
            if (null != shareSnsInfoById && shareSnsInfoById.getBuessObj() != null) {
                logger.info("调用会员接口通过uniqueId查询用户信息返回结果，result:{}", shareSnsInfoById.getBuessObj());
                UserInfo userInfo = shareSnsInfoById.getBuessObj();
                userId = Long.parseLong(userInfo.getId());
                logger.info("调用会员通过：{},查询得到userId:{}", uniqueId, userId);
                gcache.setex(CACHE_PREFIX + "queryUserIdByUniqueId_" + uniqueId, 5, userId.toString());
                return userId;
            }
        } else {
            userId = Long.parseLong(catchResult);
            return userId;
        }
        return null;
    }

    /**
     * 处理c变为B
     *
     * @param mshopShareRecord
     * @return
     */
    @Deprecated
    public MapResults<MshopShareRecordDto> dealCtoB(MshopShareRecord mshopShareRecord) {
        MapResults<MshopShareRecordDto> mapResults = null;
        try {
            logger.info("说明是C分享出来进行注册的，不记绑定关系,查分享链路表,requesParam:{}", mshopShareRecord);
            if (null == mshopShareRecord.getPuserId()) {
                mshopShareRecord.setPuserId(queryUserIdByUniqueId(mshopShareRecord.getPuniqueId()));
            }
            if (null != mshopShareRecord.getPuserId()) {
                logger.info("dealCtoB方法puserId不等于空，先去binding表中查询");
                MshopShareBinding mshopShareBinding = new MshopShareBinding();
                mshopShareBinding.setUserId(mshopShareRecord.getPuserId());
                MshopShareBinding rtnMshopShareBinding = mshopShareBindingService.queryByParam(mshopShareBinding);
                if (null != rtnMshopShareBinding) {
                    logger.info("邀请人c在绑定表中存在绑定关系，result:{}", rtnMshopShareBinding);
                    MshopShareBinding createMshopBinding = new MshopShareBinding();
                    createMshopBinding.setUserId(mshopShareRecord.getUserId());
                    createMshopBinding.setPuserId(mshopShareRecord.getPuserId());
                    createMshopBinding.setUpuserId(rtnMshopShareBinding.getUpuserId());
                    createMshopBinding.setUniqueId(mshopShareRecord.getUniqueId());
                    createMshopBinding.setPuniqueId(mshopShareRecord.getPuniqueId());
                    createMshopBinding.setUpmid(rtnMshopShareBinding.getUpmid());
                    createMshopBinding.setUpuniqueId(rtnMshopShareBinding.getUpuniqueId());
                    createMshopBinding.setTopLeaderMid(rtnMshopShareBinding.getTopLeaderMid());
                    createMshopBinding.setTopLeaderUserId(rtnMshopShareBinding.getTopLeaderUserId());
                    createMshopBinding.setAuthorization(mshopShareRecord.getAuthorization());
                    if (null == mshopShareRecord.getUserId()) {
                        Long userIdByUniqueId = queryUserIdByUniqueId(mshopShareRecord.getUniqueId());
                        mshopShareRecord.setUserId(userIdByUniqueId);
                        createMshopBinding.setUserId(userIdByUniqueId);
                    }
                    if (null != createMshopBinding.getUserId()) {
                        Long thisUserMid = checkMidByUserId(mshopShareRecord.getUserId());
                        createMshopBinding.setMid(thisUserMid);
                        if (null != thisUserMid && !thisUserMid.equals(0L)) {
                            createMshopBinding.setShareChain(rtnMshopShareBinding.getShareChain() + "-" + mshopShareRecord.getUserId());
                        } else {
                            createMshopBinding.setShareChain(rtnMshopShareBinding.getShareChain());
                        }
                    }
                    logger.info("插入到绑定关系表，requestParam:{}", createMshopBinding);
                    createMshopBinding.setInsertTime(new Date());
                    mshopShareBindingService.insertMShopShareBinding(createMshopBinding);
                    pushJobMessage(createMshopBinding.getUserId(), createMshopBinding.getUpuserId(), 0);
                    MshopShareRecord updateMshopShareRecord = new MshopShareRecord();
                    updateMshopShareRecord.setUserId(mshopShareRecord.getUserId());
                    updateMshopShareRecord.setUniqueId(mshopShareRecord.getUniqueId());
                    updateMshopShareRecord(3, updateMshopShareRecord);
                    dealWithStatistic(createMshopBinding);
                    MshopShareRecordDto resultObj = new MshopShareRecordDto();
                    resultObj.setUpuserId(createMshopBinding.getUpuserId());
                    logger.info("注册后的返回值,upuserId:{}", resultObj.getUpuserId());
                    mapResults = new MapResults<>(resultObj);
                    //pushAuthorization(createMshopBinding.getUserId(),createMshopBinding.getAuthorization(),gomeShopWeChatFacade);
                } else {
                    mapResults = ctoBCreateBinding(mshopShareRecord);
                }
            } else {
                mapResults = ctoBCreateBinding(mshopShareRecord);
            }

        } catch (Exception e) {
            logger.info("C注册失败,mshopShareRecord:{},Exception:", JSON.toJSON(mshopShareRecord), e);
            mapResults = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
        return mapResults;
    }

    /**
     * cToB建立绑定关系
     *
     * @param mshopShareRecord
     * @return
     */
    @Deprecated
    public MapResults<MshopShareRecordDto> ctoBCreateBinding(MshopShareRecord mshopShareRecord) {
        try {
            logger.info("绑定表中不存在，去record表中查询，requesParam:{}", mshopShareRecord);
            MshopShareRecord reqMshopShareRecord = new MshopShareRecord();
            reqMshopShareRecord.setUniqueId(mshopShareRecord.getPuniqueId());
            reqMshopShareRecord.setUserId(mshopShareRecord.getPuserId());
            List<MshopShareRecord> mshopShareRecords = mshopShareRecordService.queryByUniqueIdOrUserId(reqMshopShareRecord);
            if (mshopShareRecords.size() == 0) {
                logger.info("C的邀请上级没有上级M");
                return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
            }
            MshopShareRecord resultRecord = mshopShareRecords.get(0);
            logger.info("通过邀请者的上级去绑定表中查询是否存在绑定关系(一绑定表中作为上级存在，二绑定表中作为下级存在)，requestParam:{}", resultRecord);
            MshopShareBinding mshopShareBinding1 = mshopShareBindingService.getInvateShopInfo(resultRecord.getUpuserId());
            if (null != mshopShareBinding1) {
                logger.info("邀请关系中作为别人的下级存在，result:{}", mshopShareBinding1);
                MshopShareBinding mshopShareBinding2 = new MshopShareBinding();
                copyBeanUtils(mshopShareBinding2, mshopShareRecord);
                if (null != mshopShareRecord.getUniqueId() && null == mshopShareRecord.getUserId()) {
                    mshopShareBinding2.setUserId(queryUserIdByUniqueId(mshopShareRecord.getUniqueId()));
                }
                mshopShareBinding2.setPuserId(mshopShareBinding1.getUpuserId());
                mshopShareBinding2.setUpuserId(mshopShareBinding1.getUserId());
                mshopShareBinding2.setUpmid(mshopShareBinding1.getMid());
                mshopShareBinding2.setTopLeaderUserId(mshopShareBinding1.getTopLeaderUserId());
                mshopShareBinding2.setTopLeaderMid(mshopShareBinding1.getTopLeaderMid());
                mshopShareBinding2.setShareChain(mshopShareBinding1.getShareChain());
                mshopShareBinding2.setInsertTime(new Date());
                logger.info("插入到绑定关系表，requestParam:{}", mshopShareBinding2);
                mshopShareBindingService.insertMShopShareBinding(mshopShareBinding2);
                pushJobMessage(mshopShareBinding2.getUserId(), mshopShareBinding2.getUpuserId(), 0);
                MshopShareRecord updateMshopShareRecord = new MshopShareRecord();
                updateMshopShareRecord.setUserId(mshopShareRecord.getUserId());
                updateMshopShareRecord.setUniqueId(mshopShareRecord.getUniqueId());
                updateMshopShareRecord(3, updateMshopShareRecord);
                dealWithStatistic(mshopShareBinding2);
                MshopShareRecordDto resultObj = new MshopShareRecordDto();
                resultObj.setUpuserId(mshopShareBinding2.getUpuserId());
                logger.info("注册后的返回值,userId:{}", resultObj.getUpuserId());
                return new MapResults<>(resultObj);
            } else {
                return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
            }
        } catch (Exception e) {
            logger.info("C注册失败，Exception:{}", e.getMessage());
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    /**
     * 处理统计(关系同步到mongodb)
     *
     * @param mshopShareBinding
     */
    public void dealWithStatistic(MshopShareBinding mshopShareBinding) {
        logger.info("插入成功处理统计客户");
        try {
            MeidianShareChangeBind bind = new MeidianShareChangeBind();
            copyBeanUtils(bind, mshopShareBinding);
            bind.setIdentity(0);
            logger.info("B->C 记录联调 ,修改绑定数据{}", bind);
            iUserRelationService.saveUserRelation(bind);
        } catch (Exception ex) {
            logger.error("保存mogdb关系链条错误", ex);
        }
    }

    /**
     * 任务体系推送mq
     *
     * @param userId  当前用户userId
     * @param puserId 邀请者userId
     * @param type    0 拉C消息推送形成绑定  1  B邀请C成为美店主
     */
    public void pushJobMessage(Long userId, Long puserId, Integer type) {
        try {
            String jobTag = "";
            JSONObject jsonObject = new JSONObject();
            jsonObject.fluentPut("userId", userId)
                    .fluentPut("puserId", puserId)
                    .fluentPut("timestamp", System.currentTimeMillis());
            String key = UUID.randomUUID().toString();
            if (type.equals(0)) {
                jobTag = executeTaskAddC;
            }
            if (type.equals(1)) {
                jobTag = executeTaskAddB;
            }
            SendResult sendResult = MQProducer.sendMessage(topic, jobTag, key, jsonObject.toString().getBytes());
            logger.info("push message to rocket,topic:{},tag:{},key:{},messageId:{},messageBody:{}", topic, jobTag, key, sendResult.getMsgId(), jsonObject);
            insertMessageToDB(sendResult.getMsgId(), topic, jobTag, key, jsonObject.toString(), sendResult.getSendStatus().toString());
        } catch (Exception e) {
            logger.error("任务推送消息失败，Exception:{}", e.getMessage());
        }
    }

    /**
     * @param messageId
     * @param topic
     * @param tag
     * @param key
     * @param messageBody
     * @param sendStatus
     */
    public void insertMessageToDB(String messageId, String topic, String tag, String key, String messageBody, String sendStatus) {
        MShopShareMessage mShopShareMessage = new MShopShareMessage();
        mShopShareMessage.setMessageId(messageId);
        mShopShareMessage.setTopic(topic);
        mShopShareMessage.setTag(tag);
        mShopShareMessage.setMessageKey(key);
        mShopShareMessage.setMessageBody(messageBody);
        mShopShareMessage.setSendStatus(sendStatus);
        mShopShareMessageManager.insertMShopMessage(mShopShareMessage);
    }

    /**
     * 优化点：之前使用的apache的copyBean转为spring的copyBean
     *
     * @param toObj   目标对象
     * @param fromObj 原始对象
     */
    public void copyBeanUtils(Object toObj, Object fromObj) {
        org.springframework.beans.BeanUtils.copyProperties(fromObj, toObj);
    }

    /**
     * 跟随提成系统上线新增注册绑定关系
     *
     * @return
     */
    public MapResults<MshopShareBinding> addBindingRelationOfMZ(MshopShareRecordDto mshopShareRecordDto) {
        logger.info("---------------------------保存绑定关系---------------------,param:{}", JSON.toJSON(mshopShareRecordDto));
        if (null == mshopShareRecordDto.getUserId() || null == mshopShareRecordDto.getPuserId()) {
            return new MapResults<>(ExceptionCodeEnum.PUSERID_USERID_IS_EMPTY);
        }
        VshopInfo pVashopInfo = queryVshopInfo(mshopShareRecordDto.getPuserId());
        if (pVashopInfo == null) {
            logger.info("邀请人不是推手,无法建立绑定关系,mshopShareRecordDto:{}", JSON.toJSON(mshopShareRecordDto));
            return new MapResults<>(ExceptionCodeEnum.INVITE_USER_NOT_MATCH);
        }

        MshopShareBinding checkRepeat = new MshopShareBinding();
        checkRepeat.setUserId(mshopShareRecordDto.getUserId());
        MshopShareBinding shareBinding = mshopShareBindingService.queryByParam(checkRepeat);
        if (null != shareBinding) {
            logger.info("此次邀请关系已经在绑定表中 已存在 userId {},puserId {}", mshopShareRecordDto.getUserId(), mshopShareRecordDto.getPuserId());
            return new MapResults<>(ExceptionCodeEnum.EXISTS_RELATION);
        }
        MshopShareBinding param = new MshopShareBinding();
        param.setUserId(mshopShareRecordDto.getUserId());
        param.setPuserId(mshopShareRecordDto.getPuserId());
        param.setUpuserId(mshopShareRecordDto.getPuserId());

        param.setUpmid(pVashopInfo.getVshopId());
        if (TaskCommonConstant.USER_IS_PIAN.equals(pVashopInfo.getVshopIdentity())) {
            //邀请人是片总推手
            param.setTopLeaderUserId(pVashopInfo.getUserId());
            param.setTopLeaderMid(pVashopInfo.getVshopId());
            param.setShareChain(String.valueOf(pVashopInfo.getUserId()));
        } else {
            //邀请人是B推手
            MshopShareBinding reqMshopShopBinding = new MshopShareBinding();
            reqMshopShopBinding.setUserId(mshopShareRecordDto.getPuserId());
            reqMshopShopBinding.setType(TaskCommonConstant.VSHOP_IDENTITY_1);
            MshopShareBinding pShareBinding = mshopShareBindingService.queryByParam(reqMshopShopBinding);
            if (null == pShareBinding) {
                param.setTopLeaderUserId(topLeaderUserId);
                param.setTopLeaderMid(topLeaderMid);
                param.setShareChain(topLeaderUserId + "-" + param.getUpuserId());
            } else {
                param.setTopLeaderUserId(pShareBinding.getTopLeaderUserId());
                param.setTopLeaderMid(pShareBinding.getTopLeaderMid());
                param.setShareChain(pShareBinding.getShareChain());
            }
        }
        param.setInsertTime(new Date());
        param.setIdentity(UserIdentityEnum.custom.getCode());
        param.setType(UserType.NewCustom.getType());
        logger.info("邀请人puserId {} , userId {},绑定关系的入库数据是 {} ", mshopShareRecordDto.getPuserId(), mshopShareRecordDto.getUserId(), param);
        mshopShareBindingService.insertMShopShareBinding(param);
        relationCacheService.resetUserRelation(param.getUserId());
        MeidianShareBindingCtx ctx = new MeidianShareBindingCtx();
        ctx.setUserId(mshopShareRecordDto.getUserId());
        ctx.setCtx(mshopShareRecordDto.getCtx());
        ctxMapper.insertSelective(ctx);

        //将游客表的type状态变更
        if (StringUtils.isNotBlank(mshopShareRecordDto.getUniqueId())) {
            MshopShareRecord mshopShareRecord = new MshopShareRecord();
            copyBeanUtils(mshopShareRecord, mshopShareRecordDto);
            updateMshopShareRecord(3, mshopShareRecord);
        }

        pushJobMessage(param.getUserId(), param.getUpuserId(), 0);
        dealWithStatistic(param);
        return new MapResults<>(param);
    }
}
