package com.gome.meidian.user.mq;

import java.util.HashMap;
import java.util.List;

import com.alibaba.rocketmq.client.producer.MessageQueueSelector;
import com.alibaba.rocketmq.common.message.Message;
import com.alibaba.rocketmq.common.message.MessageQueue;

public class PianZongMessageQueueSelector implements MessageQueueSelector{
	@Override
    public MessageQueue select(List<MessageQueue> mqs, Message msg,
            Object arg) {
        int hashResult = getIndex(arg);
        int size = mqs.size();
        int index = (int) (hashResult % size);
        //取绝对值
        int absIndex = Math.abs(index);
        return mqs.get(absIndex);
    }

    /**
     * 处理hash运算
     * @param args
     * @return
     */
    private int getIndex(Object args){
        String key = args.toString();
        int h;
        return (key == null) ? 0 : (h = key.hashCode()) ^ (h >>> 16);
    }
}
