package com.gome.meidian.user.service.impl;

import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.dto.UserRightsDto;
import com.gome.meidian.user.entity.UserRights;
import com.gome.meidian.user.entity.UserRightsRecord;
import com.gome.meidian.user.enums.UserRightsOperateEnum;
import com.gome.meidian.user.enums.UserRightsSceneEnum;
import com.gome.meidian.user.mapper.UserRightsRecordMapper;
import com.gome.meidian.user.service.UserRightsAsyncService;
import com.gome.meidian.user.utils.CommonUtils;
import com.gome.meidian.user.utils.Constants;
import com.gome.meidian.user.utils.RedisKeyUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import redis.Gcache;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

@Slf4j
@Service
public class UserRightsAsyncServiceImpl implements UserRightsAsyncService {

    /**
     * 缓存
     */
    @Autowired
    private Gcache gcache;
    /**
     * 用户权益履历
     */
    @Autowired
    private UserRightsRecordMapper userRightsRecordMapper;

    @Async("threadPoolExecutor")
    @Override
    public Boolean insertRewardRecord(Long userId, Integer type, Integer rewardOpenCount, Integer rewardJoinCount, Integer scene, UserRights model) {
        try {
            UserRightsRecord record = new UserRightsRecord();
            record.setUserId(userId);
            record.setType(type);
            record.setState(1);
            record.setInsertTime(new Date());
            if (rewardOpenCount != null && !Constants.zero.equals(rewardOpenCount)) {
                record.setValue(rewardOpenCount);
                record.setCost(model == null ? 0 : model.getRewardOpenCount());
                record.setScene(UserRightsSceneEnum.sysRewardOpenGroup.getScene().equals(scene) ?
                        UserRightsSceneEnum.sysRewardOpenGroup.getCode() :
                        UserRightsSceneEnum.taskRewardOpenGroup.getCode());
                userRightsRecordMapper.insert(record);
            }
            if (rewardJoinCount != null && !Constants.zero.equals(rewardJoinCount)) {
                record.setValue(rewardJoinCount);
                record.setCost(model == null ? 0 : model.getRewardJoinCount());
                record.setScene(UserRightsSceneEnum.sysRewardJoinGroup.getScene().equals(scene) ?
                        UserRightsSceneEnum.sysRewardJoinGroup.getCode() :
                        UserRightsSceneEnum.taskRewardJoinGroup.getCode());
                userRightsRecordMapper.insert(record);
            }
            return Boolean.TRUE;
        } catch (Exception e) {
            log.error("UserRightsAsyncServiceImpl.insertRewardRecord,保存用户权益履历发生异常，异常堆栈如下", e);
            return Boolean.TRUE;
        }
    }

    @Async("threadPoolExecutor")
    @Override
    public Boolean insertConsumeRecord(UserRightsDto dto, Integer scene, Integer operate, String txId) {
        try {
            UserRightsRecord record = new UserRightsRecord();
            record.setUserId(dto.getUserId());
            record.setType(dto.getType());
            record.setScene(scene);
            record.setTxId(txId);
            record.setCost(UserRightsSceneEnum.openGroup.getCode().equals(scene) ? dto.getAlreadyOpenCount() : dto.getAlreadyJoinCount());
            record.setValue(UserRightsOperateEnum.incr.getCode().equals(operate) ? 1 : -1);
            //操作回滚，状态失效
            record.setState(UserRightsOperateEnum.incr.getCode().equals(operate) ? 1 : 0);
            record.setInsertTime(new Date());
            userRightsRecordMapper.insert(record);
            //逻辑删除流水表
            if (UserRightsOperateEnum.subtraction.getCode().equals(operate)) {
                UserRightsRecord rollback = new UserRightsRecord();
                rollback.setUserId(dto.getUserId());
                rollback.setType(dto.getType());
                rollback.setTxId(txId);
                rollback.setScene(scene);
                rollback.setState(0);
                userRightsRecordMapper.update(rollback);
            }
            return Boolean.TRUE;
        } catch (Exception e) {
            log.error("UserRightsAsyncServiceImpl.insertConsumeRecord,保存用户权益履历发生异常，异常堆栈如下", e);
            return Boolean.FALSE;
        }
    }

    @Async("threadPoolExecutor")
    @Override
    public void synUserRightsCache(List<UserRights> userRightsList, CountDownLatch downLatch) {
        for (UserRights userRights : userRightsList) {
            String redisKey = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_HASH_PREFIX, userRights.getUserId(), userRights.getType());
            //加入缓存
            Map<String, String> map = CommonUtils.obj2Map(userRights);
            gcache.hmset(redisKey, map);
            gcache.sadd(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + userRights.getType(), redisKey);
        }
        downLatch.countDown();
    }

}
