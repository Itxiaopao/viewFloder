package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.MeidianVshopSummary;

import java.util.List;

public interface VshopSummaryService {

    /**
     * 批量插入任务
     *
     * @param pageCount
     * @param pageSize
     * @return
     */
    void task(Integer pageCount, Integer pageSize);

    /**
     * 批量插入
     *
     * @param list
     * @return
     */
    Boolean batchOperation(List<MeidianVshopSummary> list);

    MeidianVshopSummary selectByUserId(Long userId);

    List<MeidianVshopSummary> selectByUserIdList(List<Long> userIdList);

    String shareBindSync(Integer pageCount, Integer pageSize);

}
