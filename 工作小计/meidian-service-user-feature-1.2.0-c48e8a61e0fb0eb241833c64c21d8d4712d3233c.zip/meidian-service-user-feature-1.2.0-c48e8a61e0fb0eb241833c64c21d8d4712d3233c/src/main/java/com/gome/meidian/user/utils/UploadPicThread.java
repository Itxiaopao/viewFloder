package com.gome.meidian.user.utils;

import com.alibaba.fastjson.JSON;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.user.service.UserRelationCacheService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import cn.com.gome.gis.dto.GisResultDto;
import cn.com.gome.gis.dubbo.CommonUploadService;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.service.MShopWechatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.util.concurrent.Future;

@Slf4j
@Service("uploadPicThread")
public class UploadPicThread {

    /**
     * 微信service
     */
    @Autowired
    MShopWechatService mShopWechatService;
    /**
     * gfs上传对象
     */
    @Autowired
    private CommonUploadService commonUploadService;
    /**
     * 用户缓存
     */
    @Autowired
    private UserRelationCacheService userRelationCacheService;
    /**
     * gfsKey
     */
    @Value("${upload.gfs.key}")
    private String gfsKey;

    @Async("threadPoolExecutor")
    @SneakyLog("异步上传用户头像")
    public Future<String> upload(MshopWechatUserInfo mshopWechatUserInfo) {
        if (mshopWechatUserInfo == null) {
            return null;
        }
        try {
            GisResultDto gisResultDto = commonUploadService.uploadURLImage(mshopWechatUserInfo.getImage(), gfsKey);
            if (gisResultDto == null || StringUtils.isBlank(gisResultDto.getUrl())) {
                return new AsyncResult<>(mshopWechatUserInfo.getImage());
            }
            String rtnStr = gisResultDto.getUrl();
            mshopWechatUserInfo.setImage(rtnStr);
            mShopWechatService.updateByUniqueId(mshopWechatUserInfo);
            userRelationCacheService.setWechatUserInfo(mshopWechatUserInfo);
            return new AsyncResult<>(rtnStr);
        } catch (Exception e) {
            log.error("上传图片到gfs发生异常,mshopWechatUserInfo：{},异常堆栈如下:", JSON.toJSON(mshopWechatUserInfo), e);
            return new AsyncResult<>(mshopWechatUserInfo.getImage());
        }

    }
}
