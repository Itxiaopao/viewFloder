package com.gome.meidian.user.mq;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.gome.meidian.user.entity.MeidianUserBindWechatRecord;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.service.MShopShareRecordService;
import com.gome.meidian.user.service.MeidianUserBindWechatRecordService;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * 用户切换微信消费者
 */
@Slf4j
@Component
public class UserChangeWechatConsumer {

    @Value("${mq.user.changeWechat.topic}")
    private String topic;

    @Value("${mq.user.changeWechat.group}")
    private String group;

    @Value("${mq.user.changeWechat.tags}")
    private String tags;

    @Value("${mq.address}")
    private String address;

    @Autowired
    private MShopShareRecordService mShopShareRecordService;

    @Autowired
    private MeidianUserBindWechatRecordService meidianUserBindWechatRecordService;

    @PostConstruct
    @SneakyThrows(MQClientException.class)
    public void init() {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(group);
        consumer.setNamesrvAddr(address);
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET);
        consumer.subscribe(topic, tags);
        consumer.registerMessageListener((MessageListenerConcurrently) (msgList, context) -> {
            MessageExt msg = msgList.get(0);
            StringBuilder sb = new StringBuilder(128);
            try {
                String str = new String(msg.getBody(), StandardCharsets.UTF_8);
                sb.append("接收微信解绑消息,msgId:").append(msg.getMsgId()).append(",消息体:").append(str);
                JSONObject jsonObject = JSONObject.parseObject(str);
                MshopShareRecord mshopShareRecord = new MshopShareRecord();
                String uniqueId = jsonObject.getString("snsUserId");
                mshopShareRecord.setUniqueId(uniqueId);
                int count = mShopShareRecordService.queryCountByBiz(mshopShareRecord);
                if (count <= 0) {
                    //非美店用户不记录关系
                    sb.append("消息没有被记录,原因:非美店用户不会被记录");
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }
                MeidianUserBindWechatRecord record = new MeidianUserBindWechatRecord();
                record.setUniqueId(uniqueId);
                record.setUserId(jsonObject.getLong("userId"));
                record.setState(1);
                record.setMsgId(msg.getMsgId());
                record.setMsgBody(str);
                record.setCreateTime(new Date());
                meidianUserBindWechatRecordService.save(record);
            } catch (Exception e) {
                sb.append("用户切换微信消费发生异常，异常堆栈如下:").append(e.getMessage());
                log.error(sb.toString(), e);
                //重试三次后抛弃
                return msg.getReconsumeTimes() > 3 ? ConsumeConcurrentlyStatus.CONSUME_SUCCESS : ConsumeConcurrentlyStatus.RECONSUME_LATER;
            } finally {
                log.info(sb.toString());
            }
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        });
        consumer.start();
        System.out.println("consumer start...");
    }
}
