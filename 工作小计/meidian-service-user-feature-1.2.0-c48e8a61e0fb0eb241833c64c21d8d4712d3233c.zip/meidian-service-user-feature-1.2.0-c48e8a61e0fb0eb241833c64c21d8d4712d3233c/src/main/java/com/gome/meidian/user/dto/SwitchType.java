package com.gome.meidian.user.dto;

public enum SwitchType {

	Change_Shop(1,"切换上级店主"),
    Upper_Shop(2,"升级成为店总"),
    Upper_Pian(3,"升级片总"),
    Bind_Custom(4,"绑定店主或者用户"),
    Bind_Shop(5,"绑定店主"),
    Down_Pian(6,"片总降级"),;

    private int status;

    private String statusName;

    private SwitchType(int status, String statusName){
        this.status = status;
        this.statusName = statusName;
    }

    public int getType() {
        return status;
    }

    public String getTypeName() {
        return statusName;
    }

}
