package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.MshopWechatUserInfo;

import java.util.List;

/**
 * @author chenchen-ds6
 * 微信表处理
 */
public interface MShopWechatService {
    /**
     * 查询
     * @param mshopWechatUserInfo
     * @return
     */
    MshopWechatUserInfo queryWechatInfoByParam(MshopWechatUserInfo mshopWechatUserInfo);

    /**
     * 插入微信信息
     * @param mshopWechatUserInfo
     * @return
     */
    int insertMShopWechatInfo(MshopWechatUserInfo mshopWechatUserInfo);

    /**
     * 修改微信信息
     * @param mshopWechatUserInfo
     * @return
     */
    int updateWechatUserInfo(MshopWechatUserInfo mshopWechatUserInfo);

    List<MshopWechatUserInfo> queryWeChatInfoByUniqueId(String uniqueId);

    /**
     * 查找我的下级用户，通过微信昵称查询
     * @param myUserId
     * @param nickName
     * @return
     */
    MshopWechatUserInfo queryMyNextWeChatInfoByNickName(Long myUserId, String nickName);

    /**
     * 查看上级的二维码信息
     * @param upUserId
     * @return
     */
    MshopWechatUserInfo queryMyWeChatInfoByUserId(Long upUserId);

    /**
     * 通过uniqueID更新纯游客的头像昵称信息
     * @param mshopWechatUserInfo
     * @return
     */
    int updateByUniqueId(MshopWechatUserInfo mshopWechatUserInfo);

    List<MshopWechatUserInfo> queryMyNextWeChatInfoByUserIdWithPage(Long userId, Integer pageSize, Integer pageIndex);
}
