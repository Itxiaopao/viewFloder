package com.gome.meidian.user.mapper;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.UserInfo;

import java.util.List;
import java.util.Map;

/**
 * 用户信息数据层
 *
 */
public interface UserInfoMapper extends BaseMapper<UserInfo, Long>{
	/**
	 * 根据userID获取用户信息
	 * @param userId
	 * @return
	 */
	UserInfo findByUserId(@Param("userId")String userId);


	/**
	 * 条件查询
	 * @param map
	 * @return
	 */
	public List<UserInfo> findByQuery(Map<String, Object> map);


	/**
	 * 查询数据条数
	 * @return
	 */
	public Integer findCountUserInfo();

}
