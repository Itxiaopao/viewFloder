package com.gome.meidian.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.Role;
import com.gome.meidian.user.mapper.RoleMapper;
import com.gome.meidian.user.service.AbstractService;
import com.gome.meidian.user.service.RoleService;
@Service
public class RoleServiceImpl extends AbstractService<Role, Short> implements RoleService {
	@Autowired
	private RoleMapper roleMapper;


	@Override
	public void setBaseMapper() {
		// TODO Auto-generated method stub
		super.baseMapper = roleMapper;
	}

	/**
	 * 获取所有角色
	 */
	@Override
	public List<Role> findAll() {
		// TODO Auto-generated method stub
		return roleMapper.findAll();
	}

}
