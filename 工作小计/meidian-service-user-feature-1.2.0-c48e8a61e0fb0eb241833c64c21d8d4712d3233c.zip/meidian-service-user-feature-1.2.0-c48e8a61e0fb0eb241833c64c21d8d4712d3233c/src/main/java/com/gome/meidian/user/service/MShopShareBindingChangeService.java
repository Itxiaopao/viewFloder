package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.MshopShareChangeBinding;

import java.util.List;

public interface MShopShareBindingChangeService {
    public List<MshopShareChangeBinding> queryChangeListByParam(MshopShareChangeBinding mshopShareChangeBinding);
}
