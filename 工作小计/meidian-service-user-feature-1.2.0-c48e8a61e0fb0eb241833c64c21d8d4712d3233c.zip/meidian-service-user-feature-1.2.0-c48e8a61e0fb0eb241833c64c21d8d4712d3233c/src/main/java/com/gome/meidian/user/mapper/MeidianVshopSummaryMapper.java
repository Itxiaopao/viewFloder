package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MeidianVshopSummary;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 美店主客户数量管理
 */
public interface MeidianVshopSummaryMapper {

    /**
     * 删除
     *
     * @param userId
     * @return
     */
    int delete(Long userId);

    /**
     * 新增
     *
     * @param record
     * @return
     */
    int insert(MeidianVshopSummary record);

    /**
     * 根据userId查询
     *
     * @param userId
     * @return
     */
    MeidianVshopSummary selectByUserId(Long userId);

    /**
     * 更新
     *
     * @param record
     * @return
     */
    int update(MeidianVshopSummary record);

    /**
     * 批量操作表   
     *
     * @param recordList
     * @return
     */
    int batchOperation(@Param("list") List<MeidianVshopSummary> recordList);

    List<MeidianVshopSummary> selectByUserIdList(@Param("userIdList") List<Long> userIdList);
}
