package com.gome.meidian.user.service.impl;

import com.gome.meidian.user.entity.MshopShareChangeBinding;
import com.gome.meidian.user.mapper.MShopShareChangeBindingMapper;
import com.gome.meidian.user.service.MShopShareBindingChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author limenghui-ds
 * @create 2019-08-19 11:55
 */
@Service
public class MShopShareBindingChangeServiceImpl implements MShopShareBindingChangeService {
    @Autowired
    private MShopShareChangeBindingMapper changeBindingMapper;

    @Override
    public List<MshopShareChangeBinding> queryChangeListByParam(
            MshopShareChangeBinding mshopShareChangeBinding) {
        return changeBindingMapper.queryChangeListByParam(mshopShareChangeBinding);
    }

}
