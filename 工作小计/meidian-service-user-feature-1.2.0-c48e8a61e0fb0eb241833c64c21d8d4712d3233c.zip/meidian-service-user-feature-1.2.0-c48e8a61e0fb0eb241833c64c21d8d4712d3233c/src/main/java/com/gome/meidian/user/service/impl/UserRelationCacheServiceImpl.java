package com.gome.meidian.user.service.impl;

import java.util.*;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.manager.MShopShareRecordManager;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.meidian.user.constant.BizConstant;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.service.UserRelationCacheService;
import redis.Gcache;

@Slf4j
@Service("userRelationCacheService")
public class UserRelationCacheServiceImpl implements UserRelationCacheService {

    @Autowired
    private Gcache gcache;
    @Autowired
    private MShopShareBindingMapper mShopShareBindingMapper;
    @Autowired
    private MShopShareRecordMapper mShopShareRecordMapper;
    @Autowired
    private MShopShareRecordManager mShopShareRecordManager;

    @Override
    public void setUserRelation(MshopShareBinding record) {
        if (record == null) {
            return;
        }
        String subordinateRedisKey = this.getSubordinateRedisKey(record.getUpuserId(), record.getIdentity(), record.getType());
        Date insertTime = Optional.ofNullable(record.getInsertTime()).orElse(new Date());
        gcache.set(CacheConstant.USER_RELATION_RECORD_STR_PREFIX + record.getUserId(), JSON.toJSONString(record));
        gcache.zadd(subordinateRedisKey, insertTime.getTime(), String.valueOf(record.getUserId()));
    }

    @Override
    public MshopShareBinding getUserRelation(Long userId) {
        String val = gcache.get(CacheConstant.USER_RELATION_RECORD_STR_PREFIX + userId);
        return JSONObject.parseObject(val, MshopShareBinding.class);
    }

    @Override
    public List<MshopShareBinding> multiGetUserRelation(Set<String> userIdSet) {
        if (CollectionUtils.isEmpty(userIdSet)) {
            return new ArrayList<>();
        }
        String[] keys = new String[userIdSet.size()];
        int i = 0;
        for (String key : userIdSet) {
            keys[i] = CacheConstant.USER_RELATION_RECORD_STR_PREFIX + key;
            i++;
        }
        Map<String, String> map = gcache.multiGet(keys);
        if (map == null || map.isEmpty()) {
            return new ArrayList<>();
        }
        List<MshopShareBinding> list = new ArrayList<>(map.size());
        for (String key : map.keySet()) {
            String val = map.get(key);
            if (StringUtils.isNotEmpty(val)) {
                list.add(JSONObject.parseObject(val, MshopShareBinding.class));
            }
        }
        return list;
    }

    @Override
    public void removeUserRelation(Long userId, Long upUserId, Integer identity, Integer type) {
        String subordinateRedisKey = this.getSubordinateRedisKey(upUserId, identity, type);
        gcache.del(CacheConstant.USER_RELATION_RECORD_STR_PREFIX + userId);
        gcache.zrem(subordinateRedisKey, String.valueOf(userId));
    }

    @Override
    public MshopShareBinding resetUserRelation(Long userId) {
        MshopShareBinding model = mShopShareBindingMapper.queryShareBindingByUserId(userId);
        this.setUserRelation(model);
        return model;
    }

    @Override
    public void refreshUserRelation(MshopShareBinding mshopShareBinding) {
        this.removeUserRelation(mshopShareBinding.getUserId(), mshopShareBinding.getUpuserId(), mshopShareBinding.getIdentity(), mshopShareBinding.getType());
        this.resetUserRelation(mshopShareBinding.getUserId());
    }


    @Override
    public void setShareRecord(MshopShareRecord record) {
        if (record == null) {
            return;
        }
        String subordinateRedisKey = this.getSubordinateRedisKey(record.getUpuserId(), BizConstant.SHARE_RECORD_TYPE, null);
        Date insertTime = Optional.ofNullable(record.getInsertTime()).orElse(new Date());
        gcache.zadd(subordinateRedisKey, insertTime.getTime(), record.getUniqueId());
    }

    @Override
    @SneakyLog("删除分享关系缓存")
    public void removeShareRecord(String uniqueId, Long userId) {
        if (StringUtils.isEmpty(uniqueId) && userId != null) {
            uniqueId = mShopShareRecordManager.queryUniqueIdByUserId(userId);
        }
        if (StringUtils.isEmpty(uniqueId)) {
            return;
        }
        MshopShareRecord mshopShareRecord = new MshopShareRecord();
        mshopShareRecord.setUniqueId(uniqueId);
        List<MshopShareRecord> mshopShareRecords = mShopShareRecordMapper.queryByUniqueIdOrUserId(mshopShareRecord);
        log.info("删除分享关系缓存,uniqueId:{},userId:{},mshopShareRecords:{}", uniqueId, userId, JSON.toJSON(mshopShareRecords));
        if (CollectionUtils.isEmpty(mshopShareRecords)) {
            return;
        }
        for (MshopShareRecord item : mshopShareRecords) {
            String subordinateRedisKey = this.getSubordinateRedisKey(item.getUpuserId(), BizConstant.SHARE_RECORD_TYPE, null);
            Long zrem = gcache.zrem(subordinateRedisKey, uniqueId);
            log.info("正在删除分享关系缓存,subordinateRedisKey:{},uniqueId:{},redisResult:{}", subordinateRedisKey, uniqueId, zrem);
        }
    }

    @Override
    public MshopShareRecord resetShareRecord(MshopShareRecord record) {
        MshopShareRecord query = new MshopShareRecord();
        String uniqueId = record.getUniqueId();
        if (StringUtils.isEmpty(uniqueId) && record.getUserId() != null) {
            uniqueId = mShopShareRecordManager.queryUniqueIdByUserId(record.getUserId());
        }
        if (StringUtils.isEmpty(uniqueId)) {
            return null;
        }
        query.setUniqueId(uniqueId);
        query.setUpuserId(record.getUpuserId());
        MshopShareRecord mshopShareRecord = mShopShareRecordMapper.queryByParam(query);
        if (mshopShareRecord == null) {
            return null;
        }
        this.setShareRecord(mshopShareRecord);
        return mshopShareRecord;
    }

    @Override
    public void refreshShareRecord(String uniqueId, Long userId, Long upUserId) {
        this.removeShareRecord(uniqueId, upUserId);
        MshopShareRecord record = new MshopShareRecord();
        record.setUniqueId(uniqueId);
        record.setUpuserId(upUserId);
        this.resetShareRecord(record);

    }

    @Override
    public Long getSubordinateCount(Long userId, Integer identity, Integer type) {
        String subordinateRedisKey = this.getSubordinateRedisKey(userId, identity, type);
        return gcache.zcard(subordinateRedisKey);
    }

    @Override
    public Long getSubordinateCountByScore(Long userId, Double startTime, Double endTime, Integer identity, Integer type) {
        String subordinateRedisKey = this.getSubordinateRedisKey(userId, identity, type);
        return gcache.zcount(subordinateRedisKey, startTime, endTime);
    }

    @Override
    public Set<String> getSubordinateListByScore(Long userId, Double startTime, Double endTime, Integer identity, Integer type) {
        String subordinateRedisKey = this.getSubordinateRedisKey(userId, identity, type);
        return gcache.zrangeByScore(subordinateRedisKey, startTime, endTime);
    }

    @Override
    public Set<String> getSubordinatePage(Long userId, Integer identity, Integer type, Integer pageIndex, Integer pageSize) {
        String subordinateRedisKey = this.getSubordinateRedisKey(userId, identity, type);
        return gcache.zrevrangeByScore(subordinateRedisKey, "+inf", "-inf", pageIndex, pageSize);
    }

    @Override
    public void setWechatUserInfo(MshopWechatUserInfo record) {
        if (record == null) {
            return;
        }
        String redisKey = CommUtils.getRedisKey(CacheConstant.WECHAT_USER_INFO_STR_PREFIX, record.getType(), record.getUniqueId());
        gcache.set(redisKey, JSON.toJSONString(record));
    }

    @Override
    public MshopWechatUserInfo getWechatUserInfo(Integer type, String uniqueId) {
        String redisKey = CommUtils.getRedisKey(CacheConstant.WECHAT_USER_INFO_STR_PREFIX, type, uniqueId);
        String val = gcache.get(redisKey);
        return JSONObject.parseObject(val, MshopWechatUserInfo.class);
    }

    @Override
    public Map<String, MshopWechatUserInfo> multiGetWechatUserInfo(Integer type, Set<String> uniqueIdSet) {
        if (CollectionUtils.isEmpty(uniqueIdSet)) {
            return Maps.newHashMap();
        }
        String[] keys = new String[uniqueIdSet.size()];
        int i = 0;
        for (String key : uniqueIdSet) {
            keys[i] = CommUtils.getRedisKey(CacheConstant.WECHAT_USER_INFO_STR_PREFIX, type, key);
            i++;
        }
        Map<String, String> map = gcache.multiGet(keys);
        if (map == null || map.isEmpty()) {
            return Maps.newHashMap();
        }
        Map<String, MshopWechatUserInfo> result = new HashMap<>(map.size());
        for (String key : map.keySet()) {
            String val = map.get(key);
            if (StringUtils.isNotEmpty(val)) {
                MshopWechatUserInfo mshopWechatUserInfo = JSONObject.parseObject(val, MshopWechatUserInfo.class);
                result.put(mshopWechatUserInfo.getUniqueId(), mshopWechatUserInfo);
            }
        }
        return result;
    }


    public <T> String getSubordinateRedisKey(T upUserId, Integer identity, Integer type) {
        return CommUtils.getRedisKey(CacheConstant.USER_SUBORDINATE_RELATION_ZSET_PREFIX, identity, type, upUserId);
    }
}
