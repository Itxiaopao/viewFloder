package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.AbsenteeismCount;



/**
 * 矿工信息服务层
 *
 */
public interface AbsenteeismCountService extends BaseService<AbsenteeismCount, Long> {
	/**
	 * 根据userID获取矿工信息
	 * @param userId
	 * @return
	 */
	AbsenteeismCount findByUserId(String userId);
    /**
     * 添加国美用户信息
     * @param userGomeInfo
     * @return
     */
    int insertAbsenteeismCount(AbsenteeismCount absenteeismCount);
    /**
     * 更新助力次数
     * @param absenteeismCount
     * @return
     */
    int updateCount(AbsenteeismCount absenteeismCount);
    /**
     * 更新矿工信息
     * @param absenteeismCount
     * @return
     */
    int updateAbsenteeismCount(AbsenteeismCount absenteeismCount);

}
