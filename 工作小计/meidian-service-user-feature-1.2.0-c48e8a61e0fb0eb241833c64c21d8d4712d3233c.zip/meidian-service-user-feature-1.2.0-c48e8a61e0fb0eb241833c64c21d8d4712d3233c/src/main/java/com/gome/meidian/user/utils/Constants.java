package com.gome.meidian.user.utils;

import java.util.HashMap;
import java.util.Map;


/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 常量类
 */
public class Constants {

	/**逻辑删除状态 */
	public final static int DEL_STATUS = 1;
	/**client type */
	public final static String CLIENT_OS_HEADER = "clientOs";
	/**phone type */
	public final static String PHONE_TYPE_HEADER = "phoneType";
	/**device id */
	public final static String DEV_ID_HEADER = "devId";
	/**app version */
	public final static String APP_VERSION_HEADER = "appVersion";
	/**ios device */
	public final static String IOS_CLIENT = "1";
	/**android device */
	public final static String ANDROID_CLIENT = "2";
	/**web device */
	public final static String WEB_CLIENT = "3";
	/**h5 device */
	public final static String H5_CLIENT = "4";
	/**mac device */
	public final static String MAC_CLIENT = "5";
	/**windows device */
	public final static String WINDOWS_CLIENT = "6";
	/**other device */
	public final static String OTHER = "other";

	private static final Map<String, String> phoneTypeMap = new HashMap<>();

	static {
		phoneTypeMap.put(IOS_CLIENT, "ios");
		phoneTypeMap.put(ANDROID_CLIENT, "android");
		phoneTypeMap.put(WEB_CLIENT, "web");
		phoneTypeMap.put(H5_CLIENT, "h5");
		phoneTypeMap.put(MAC_CLIENT, "mac");
		phoneTypeMap.put(WINDOWS_CLIENT, "windows");
	}

	public static String getPhoneTypeValue(String phoneType) {
		return phoneTypeMap.get(phoneType);
	}
	
	/**
	 * 调用会员组公共参数  invokeFrom
	 */
	public final static String GOME_SHOP_INVOKE_FROM = "gomeShop";
	/**
	 * 微信SCN延长时间
	 */
	public final static int GOME_SHOP_WECHAT_SCN_TIMEOUT = 7 * 24 * 60 *60;
	
	public final static int GOME_SHOP_SERVICE_RESPONSE_PARAMERROR_CODE = 1;
	
	public final static String GOME_SHOP_SERVICE_RESPONSE_PARAMERROR_DESC = "参数错误";
	
	public final static int GOME_SHOP_SERVICE_RESPONSE_EXCEPTION_CODE = -1;
	
	public final static String GOME_SHOP_SERVICES_RESPONSES_EXCEPTIO_DESC = "接口服务异常";

	public final static Integer zero = 0;
	
	//消息类型
	public final static int MSG_NOMAL = 0;//可用
	public final static int MSG_NO_NOMAL = 1;//不可用
	
}
 
