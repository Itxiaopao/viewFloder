package com.gome.meidian.user.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author limenghui-ds
 * @create 2019-06-11 16:07
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class MShopStatisticDto {
    /**
     * 用户的mid
     */
    private Long mid;
    /**
     * 上级用户mid
     */
    private Long upMid;
    /**
     * 人员类型：1新客 2游客 4首单 5忠粉
     */
    private Integer type;
    /**
     * 状态的个数统计
     */
    private Integer count;
}
