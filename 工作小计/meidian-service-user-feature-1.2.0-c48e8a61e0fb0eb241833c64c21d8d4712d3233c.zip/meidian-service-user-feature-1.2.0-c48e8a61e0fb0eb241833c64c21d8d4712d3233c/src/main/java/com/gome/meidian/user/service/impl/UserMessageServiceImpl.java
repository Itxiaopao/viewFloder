package com.gome.meidian.user.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.MeidianUserMessage;
import com.gome.meidian.user.mapper.UserMessageMapper;
import com.gome.meidian.user.service.UserMessageService;

@Service
public class UserMessageServiceImpl implements UserMessageService {
	
	@Autowired
	private UserMessageMapper userMessageMapper;

	@Override
	public int insert(MeidianUserMessage meidianUserMessage) {
		return userMessageMapper.insert(meidianUserMessage);
	}

	@Override
	public int updateById(MeidianUserMessage meidianUserMessage) {
		return userMessageMapper.updateById(meidianUserMessage);
	}

	@Override
	public MeidianUserMessage findOneByUserIdFormId(Long userId, String formId) {
		return userMessageMapper.findOneByUserIdFormId(userId, formId);
	}

	@Override
	public List<MeidianUserMessage> findByUserIdFormTypeStatus(Long userId,Long orderId,Integer formType,Integer status,Date nowDate) {
		return userMessageMapper.findByUserIdFormTypeStatus(userId,orderId,formType,status,nowDate);
	}
	
}
