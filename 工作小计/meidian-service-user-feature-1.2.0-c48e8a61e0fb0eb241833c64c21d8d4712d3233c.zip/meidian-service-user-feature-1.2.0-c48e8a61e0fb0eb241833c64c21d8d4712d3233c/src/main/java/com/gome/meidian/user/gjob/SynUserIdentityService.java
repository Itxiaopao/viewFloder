package com.gome.meidian.user.gjob;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.MeidianReportUserIdentity;
import com.gome.meidian.user.enums.EmployeeTypeEnum;
import com.gome.meidian.user.enums.SkRoleEnum;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MeidianReportUserIdentityMapper;
import com.google.common.collect.Lists;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * 把店主的user_id信息的类型，同步到表：meidian_report_user_identity
 *
 * @author hushengdong
 * @create 2019-10-21 14:56:00
 */
@Service
public class SynUserIdentityService extends AbstractGjobService {

    private static Logger logger = LoggerFactory.getLogger(SynUserIdentityService.class);

    @Autowired
    private MShopShareBindingMapper mShopShareBindingMapper;

    @Autowired
    private MeidianReportUserIdentityMapper meidianReportUserIdentityMapper;

    @Autowired
    private RestTemplate restTemplate;

    /**
     * 员工身份http地址
     */
    @Value("${http.employeeType.url}")
    private String employeeTypeUrl;

    @Value("${business.meidian.pianzong_userid}")
    private String sledgeHammerUserId;

    @Override
    public MapResults<String> execute(String param) {

        long start = System.currentTimeMillis();
        logger.info("[同步用户身份] start param:{} ", param);
        //一部分是数据是meidian_report_user_identity没有，meidian_share_binding表有的，所以执行插入或者更新操作
        syncUnknownUserIdentity(param);
        //一部分是数据是meidian_report_user_identity有，meidian_share_binding表没有的，所以执行删除操作
        deleteNotExistUserIdentity(param);
        long end = System.currentTimeMillis();
        logger.info("[同步用户身份] end param:{} , 耗时:{}ms", param, (end - start));
        //插入到表里身份信息
        return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    }

    private MapResults deleteNotExistUserIdentity(String param) {

        //一部分是数据是meidian_report_user_identity有，meidian_share_binding表没有的，所以执行删除操作
        List<Long> notExistUserIdList = meidianReportUserIdentityMapper.selectNotExistUserIdList();
        int totalCount = notExistUserIdList.size();
        logger.info("[同步用户身份] param:{} total delete user_id size:{} ", param, totalCount);
        if (totalCount == 0) {
            return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        }
        //分批次，一次100个删除
        List<List<Long>> batchNotExistUserIdList = Lists.partition(notExistUserIdList, 100);
        int currentCount = 0;
        for (List<Long> subList : batchNotExistUserIdList) {
            currentCount += subList.size();
            logger.info("[同步用户身份] param:{} total delete user_id size:{} process percent:{}", param, totalCount, currentCount);
            meidianReportUserIdentityMapper.batchDeleteMeidianReportUserIdentity(subList);
        }
        logger.info("[同步用户身份] delete end param:{} total delete user_id size:{} real delete:", param, totalCount, currentCount);
        return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    }

    private MapResults syncUnknownUserIdentity(String param) {
        //先把需要同步的user_id拿到
        List<MeidianReportUserIdentity> meidianReportUserIdentityList = getDistinctUpUserId();
        //为了预防太多，分批处理
        int totalCount = meidianReportUserIdentityList.size();
        logger.info("[同步用户身份] param:{} total user_id size:{} ", param, totalCount);
        //拿到大锤的user_id集合
        Set<String> sledgeHammerSet = getSledgeHammerSet();
        List<MeidianReportUserIdentity> insertList = new LinkedList<>();
        List<MeidianReportUserIdentity> updateList = new LinkedList<>();
        Date today = new Date();
        int ignoreCount = 0;
        int insertCount = 0;
        int updateCount = 0;
        for (MeidianReportUserIdentity meidianReportUserIdentity : meidianReportUserIdentityList) {
            if(meidianReportUserIdentity == null) {
                logger.error("[同步用户身份] -----------error 对象空-----------");
                continue;
            }
            Long upUserId = meidianReportUserIdentity.getUpUserId();
            String pid = String.valueOf(meidianReportUserIdentity.getTopLeaderUserid());
            String employeeType = getEmployeeType(upUserId);
            int newIdentity = getSkRole(employeeType, pid, sledgeHammerSet);
            Integer oldIdentity = meidianReportUserIdentity.getIdentity();
            if (oldIdentity != null && oldIdentity.equals(newIdentity)) {
                //2个身份ID没变化,直接忽略
                ignoreCount++;
                continue;
            }
            //身份ID不相等，就是有变化
            if (oldIdentity == null) {
                // 表里没有，做insert操作
                meidianReportUserIdentity.setInsertTime(today);
                meidianReportUserIdentity.setUpdateTime(today);
                meidianReportUserIdentity.setIdentity(newIdentity);
                meidianReportUserIdentity.setUserId(upUserId);
                insertList.add(meidianReportUserIdentity);
            } else {
                // 表里有，但是身份发生了变化
                meidianReportUserIdentity.setUpdateTime(today);
                meidianReportUserIdentity.setIdentity(newIdentity);
                meidianReportUserIdentity.setUserId(upUserId);
                updateList.add(meidianReportUserIdentity);
                updateCount++;
            }
            // 100个一批次
            if (insertList.size() >= 100) {
                batchInsert(insertList);
                insertCount += insertList.size();
                insertList = new LinkedList<>();
                logger.info("[同步用户身份] batch insert param:{} total count:{} ignore count:{} insert count:{} update count:{} ", param, totalCount, ignoreCount, insertCount, updateCount);
            }
            if (updateList.size() >= 100) {
                batchUpdate(updateList);
                updateCount += updateList.size();
                updateList = new LinkedList<>();
                logger.info("[同步用户身份] batch update param:{} total count:{} ignore count:{} insert count:{} update count:{} ", param, totalCount, ignoreCount, insertCount, updateCount);
            }
        }
        //插入和更新
        if (insertList.size() > 0) {
            batchInsert(insertList);
            insertCount += insertList.size();
        }
        if (updateList.size() > 0) {
            batchUpdate(updateList);
            updateCount += updateList.size();
        }
        logger.info("[同步用户身份] batch update param:{} total count:{} ignore count:{} insert count:{} update count:{} ", param, totalCount, ignoreCount, insertCount, updateCount);
        return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    }

    //因为更新的数量应该是少数，所以可以不考虑性能
    private void batchUpdate(List<MeidianReportUserIdentity> updateList) {

        for (MeidianReportUserIdentity meidianReportUserIdentity : updateList) {
            meidianReportUserIdentityMapper.updateMeidianReportUserIdentity(meidianReportUserIdentity);
        }
    }

    private void batchInsert(List<MeidianReportUserIdentity> insertList) {

        meidianReportUserIdentityMapper.batchInsertMeidianReportUserIdentity(insertList);
    }

    private List<MeidianReportUserIdentity> getDistinctUpUserId() {

        return mShopShareBindingMapper.selectDistinctUpUserId();
    }

    private String getEmployeeType(Long userId) {
        try {
            JSONObject result = restTemplate.getForObject(employeeTypeUrl, JSONObject.class, userId);
            if (result.getIntValue("code") != 200) {
                logger.info("[同步用户身份]调用无线接口成功但不是200，userId:{} 信息如下:{}", userId, result.getString("msg"));
                return null;
            }
            String type = result.getJSONObject("data").getString("type");
            logger.info("[同步用户身份]调用无线接口成功，userId:{} type:{}", userId, type);
            return type;
        } catch (Exception e) {
            logger.error("[同步用户身份]调用无线接口失败，服务异常，userId: " + userId + "异常堆栈如下", e);
            return null;
        }
    }

    private String getEmployeeTypeMock(Long userId) {
        try {
            //Thread.sleep(20);
            return "hlwl";
        } catch (Exception e) {
            return null;
        }
    }

    private int getSkRole(String employeeType, String pid, Set<String> sledgeHammerSet) {

        if (StringUtils.equalsIgnoreCase(EmployeeTypeEnum.dql.name(),employeeType)) {
            //电器员工店主：员工接口返回是电器员工的；（dql：电器员工）
            return SkRoleEnum.EAEmployee.getCode();
        } else if (StringUtils.equalsIgnoreCase(EmployeeTypeEnum.hlwl.name(),employeeType) || StringUtils.equalsIgnoreCase(EmployeeTypeEnum.gsl.name(),employeeType)) {
            //非电器员工店主：员工接口返回是公司员工或者互联网员工；（hlwl：互联网员工，gsl:公司员工）
            return SkRoleEnum.unEAEmployee.getCode();
        } else if (!sledgeHammerSet.contains(pid)) {
            //发展社会店主：员工接口返回无信息，且Pid不是大锤的；
            return SkRoleEnum.developSociety.getCode();
        } else if (sledgeHammerSet.contains(pid)) {
            //外部美店主：员工接口返回无信息，且Pid是大锤的；
            return SkRoleEnum.outside.getCode();
        } else {
            //默认返回-1
            return SkRoleEnum.unknown.getCode();
        }
    }

    private Set<String> getSledgeHammerSet() {

        if (StringUtils.isBlank(sledgeHammerUserId)) {
            sledgeHammerUserId = "77818001982";
        }
        String[] strArray = sledgeHammerUserId.split(",");
        Set<String> strSet = new HashSet<>();
        for (int i = 0; i < strArray.length; i++) {
            strSet.add(strArray[i]);
        }
        return strSet;
    }


}
