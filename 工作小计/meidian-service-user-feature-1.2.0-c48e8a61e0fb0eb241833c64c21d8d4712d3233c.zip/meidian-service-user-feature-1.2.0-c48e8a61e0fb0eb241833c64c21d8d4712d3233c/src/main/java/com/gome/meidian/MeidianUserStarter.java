package com.gome.meidian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 启动类
 */
@SpringBootApplication
@ServletComponentScan    // 扫描加载filter
@EnableTransactionManagement(proxyTargetClass = true)
@EnableAspectJAutoProxy(proxyTargetClass = true, exposeProxy = true)
public class MeidianUserStarter {
    public static void main(String args[]) {
        long starTime = System.currentTimeMillis();
        SpringApplication.run(MeidianUserStarter.class, args);
        long endTime = System.currentTimeMillis();
        long Time = endTime - starTime;
        System.out.println("\nStart Time:" + Time / 1000 + "秒");
        System.out.println("...............................................................");
        System.out.println("..................Service starts successfully..................");
        System.out.println("...............................................................");
    }
}
 