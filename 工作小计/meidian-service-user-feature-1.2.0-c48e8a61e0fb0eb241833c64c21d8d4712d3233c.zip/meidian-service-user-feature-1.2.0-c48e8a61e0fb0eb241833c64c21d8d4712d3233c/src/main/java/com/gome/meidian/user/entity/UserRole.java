package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 用户角色
 * table:md_user_center.user_role
 *
 */
public class UserRole implements Serializable {

	private static final long serialVersionUID = -376911241366751832L;
	private Long id;
	/**
	 * 用户ID
	 */
	private String userId;
	/**
	 * 角色列表
	 */
	private Short roleId;
	/**
	 * 创建时间
	 */
	private Date ctime;
	/**
	 * 更新时间
	 */
	private Date utime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public Date getUtime() {
		return utime;
	}
	public void setUtime(Date utime) {
		this.utime = utime;
	}
	public Short getRoleId() {
		return roleId;
	}
	public void setRoleId(Short roleId) {
		this.roleId = roleId;
	}
	
}
