package com.gome.meidian.user.mq.data;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString
public class ShopChangePianData  extends MQData{

	// 新的片总ID(可选)
    private Long newAreaOwnerUserId;
    
    //0 升级  1 降级
    private int type;


}
