package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MshopWechatUserInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface MShopWeChatMapper {
    List<MshopWechatUserInfo> queryWeChatInfoByUserId(@Param("userIdList") List<String> userIdList);
    int insertMShopWechatInfo(MshopWechatUserInfo mshopWechatUserInfo);
    MshopWechatUserInfo queryWechatInfoByParam(MshopWechatUserInfo mshopWechatUserInfo);

    List<MshopWechatUserInfo> queryWeChatInfoByUniqueId(@Param("uniqueId") String uniqueId);

    /**
     * 修改信息
     * @param mshopWechatUserInfo
     * @return
     */
    int updateWechatUserInfo(MshopWechatUserInfo mshopWechatUserInfo);

    MshopWechatUserInfo queryMyNextWeChatInfoByNickName(@Param("myUserId") Long myUserId, @Param("nickName")String nickName);

    List<MshopWechatUserInfo> queryMyNextWeChatInfoByUserIdWithPage(@Param("myUserId") Long myUserId,@Param("pageSize") Integer pageSize,@Param("pageIndex") Integer pageIndex );

    MshopWechatUserInfo queryMyWeChatInfoByUserId(@Param("upUserId") Long upUserId);

    /**
     * 通过uniqueId更新纯游客的状态
     * @param mshopWechatUserInfo
     * @return
     */
    int updateByUniqueId(MshopWechatUserInfo mshopWechatUserInfo);

    List<MshopWechatUserInfo> queryWeChatInfoListByUniqueIdList(@Param("uniqueIdList") List<String> uniqueIdList);
}
