package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.MeidianUserBindWechatRecord;

public interface MeidianUserBindWechatRecordService {

    Boolean save(MeidianUserBindWechatRecord record);

}
