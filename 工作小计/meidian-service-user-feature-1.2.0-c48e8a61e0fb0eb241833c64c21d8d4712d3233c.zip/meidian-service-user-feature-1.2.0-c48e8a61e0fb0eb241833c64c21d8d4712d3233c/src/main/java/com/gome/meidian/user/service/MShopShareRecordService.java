package com.gome.meidian.user.service;

import java.util.List;

import com.gome.meidian.user.entity.MshopShareRecord;

/**
 * @author chenchen-ds6
 * 分享链服务层
 */
public interface MShopShareRecordService {
    /**
     * 不定条件查询用户的分享记录
     * @param mshopShareRecord
     * @return
     */
    MshopShareRecord queryByParam(MshopShareRecord mshopShareRecord);

    /**
     * 通过uniqueId和userId查询结果
     * @param mshopShareRecord
     * @return
     */
    MshopShareRecord queryByUniqueIdAndPuserId(MshopShareRecord mshopShareRecord);
    /**
     * 插入分享链记录
     * @param mshopShareRecord
     * @return
     */
    int insertMShopShareRecord(MshopShareRecord mshopShareRecord);

    /**
     * 修改分享链路状态
     * @param mshopShareRecord
     * @return
     */
    int updateMShopShareRecord(MshopShareRecord mshopShareRecord);
   

    /**
     * 返回指定游客的集合
     * @param mshopShareRecord
     * @return
     */
    List<MshopShareRecord> queryListByParam(MshopShareRecord mshopShareRecord);

    Integer queryMyVisitorCount(Long userId, Integer type);

    /**
     * 通过uniqueId或者userId查询
     * @param mshopShareRecord
     * @return
     */
    List<MshopShareRecord> queryByUniqueIdOrUserId(MshopShareRecord mshopShareRecord);

    /**
     * 通过uniqueId和puniqueId查询规避游客状态下的重复分享
     * @param mshopShareRecord
     * @return
     */
    MshopShareRecord queryByUniqueIdAndPuniqueId(MshopShareRecord mshopShareRecord);

    /**
     * 通过upuserid查找下级的uniqueid列表
     * @param upUserId
     * @return
     */
    List<String> queryUniqueIdListByUpUserId(Long upUserId);

    /**
     * 通过id修改分享链记录
     * @param mshopShareRecord
     * @return
     */
    int updateMShopShareRecordById(MshopShareRecord mshopShareRecord);

    /**
     * 根据筛选条件获取存在条数
     * @param mshopShareRecord
     * @return
     */
    int queryCountByBiz(MshopShareRecord mshopShareRecord);
}
