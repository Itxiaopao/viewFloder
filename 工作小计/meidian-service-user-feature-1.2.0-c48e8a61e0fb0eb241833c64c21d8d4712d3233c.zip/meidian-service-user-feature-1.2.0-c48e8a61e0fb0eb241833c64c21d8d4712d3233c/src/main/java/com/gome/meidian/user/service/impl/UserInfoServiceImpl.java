package com.gome.meidian.user.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.UserInfo;
import com.gome.meidian.user.mapper.UserInfoMapper;
import com.gome.meidian.user.service.AbstractService;
import com.gome.meidian.user.service.UserInfoService;

import java.util.List;
import java.util.Map;

@Service
public class UserInfoServiceImpl extends AbstractService<UserInfo, Long> implements UserInfoService {
	@Autowired
	private UserInfoMapper userInfoMapper;
	@Override
	public void setBaseMapper() {
		// TODO Auto-generated method stub
		super.baseMapper = userInfoMapper;
	}
	
	/**
	 * 根据userID获取用户信息
	 */
	@Override
	public UserInfo findByUserId(String userId) {
		// TODO Auto-generated method stub
		return userInfoMapper.findByUserId(userId);
	}

	@Override
	public List<UserInfo> findByQuery(Map<String, Object> map) {
		return userInfoMapper.findByQuery(map);
	}

	@Override
	public Integer findCountUserInfo() {
		return userInfoMapper.findCountUserInfo();
	}
}
