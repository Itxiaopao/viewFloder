package com.gome.meidian.user.service;

import com.gome.meidian.user.dto.UserRightsDto;
import com.gome.meidian.user.entity.UserRights;

import java.util.List;
import java.util.concurrent.CountDownLatch;

public interface UserRightsAsyncService {

    /**
     * 新增用户权益奖励履历
     *
     * @param userId          用户id
     * @param type            活动类型，1.瓜分团
     * @param rewardOpenCount 奖励开团次数
     * @param rewardJoinCount 奖励参团次数
     * @param scene           场景
     * @param model           用户权益
     * @return
     */
    Boolean insertRewardRecord(Long userId, Integer type, Integer rewardOpenCount, Integer rewardJoinCount, Integer scene, UserRights model);

    /**
     * 新增用户权益消费履历
     * @param dto 数据传输对象
     * @param scene 场景
     * @param operate 操作
     * @param txId 事务id
     * @return
     */
    Boolean insertConsumeRecord(UserRightsDto dto, Integer scene, Integer operate, String txId);


    /**
     * 同步用户权益缓存
     *
     * @param userRightsList 用户权益
     * @param downLatch      线程等待策略
     * @return
     */
    void synUserRightsCache(List<UserRights> userRightsList, CountDownLatch downLatch);
}
