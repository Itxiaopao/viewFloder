package com.gome.meidian.user.manager;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.MeidianUserMessage;
import com.gome.meidian.user.entity.UserMessage;
import com.gome.meidian.user.service.UserMessageService;
import com.gome.meidian.user.utils.Constants;
import com.gome.meidian.user.utils.DateUtil;
import com.gome.meidian.user.utils.MobileDES;

@SuppressWarnings("rawtypes")
@Component("userFormIdManager")
public class UserFormIdManager implements IUserFormIdManager{
	
	private static Logger logger = LoggerFactory.getLogger(MShopShareRecordManager.class);
	
	@Autowired
	private UserMessageService userMessageService;
	
	@Override
	public MapResults pushUserMinFormId(UserMessage userMessage) {
		Long userId = userMessage.getUserId();
		String formId = userMessage.getFormId();
		MeidianUserMessage meidianUserMessage = userMessageService.findOneByUserIdFormId(userId, formId);
		if(meidianUserMessage!=null){ return new MapResults(95001,"FormId重复推送");}
		//保存消息属性
		MeidianUserMessage meidianUserMessage2 = new MeidianUserMessage();
		meidianUserMessage2.setUserId(userId);
		meidianUserMessage2.setOrderId(userMessage.getOrderId());
		meidianUserMessage2.setFormId(formId);
		meidianUserMessage2.setFormType(userMessage.getFormType());
		meidianUserMessage2.setStatus(Constants.MSG_NOMAL);
		Date nowDate = DateUtil.getNowDate();
		long afterTime = 7*24*60;
		meidianUserMessage2.setCreateTime(nowDate);
		meidianUserMessage2.setActiveTime(DateUtil.plusMintius(nowDate,afterTime));
		meidianUserMessage2.setUpdateTime(nowDate);
		userMessageService.insert(meidianUserMessage2);
		return new MapResults(0, "success");
	}
	
	@Override
	public MapResults sendUserMinMessage(UserMessage userMessage) {
		//获取参数
		Date nowDate = DateUtil.getNowDate();
		//参数校验
		if(userMessage.getUserId()==null||userMessage.getTemplateId()==null||userMessage.getTemplateId().equals("")||userMessage.getMessages()==null||userMessage.getMessages().size()==0||userMessage.getFormType()==null){
			logger.info("小程序消息-请求参数不能为空");
			return new MapResults(10900, "请求参数不能为空");
		}
		if(!userMessage.getFormType().equals(0)){
			if(userMessage.getOrderId()==null){
				logger.info("小程序消息-支付消息订单号不能为空,userId:{},orderId:{}",userMessage.getUserId(),userMessage.getOrderId());
				return new MapResults(10901, "支付消息订单号不能为空");
			}
		}
		//查找可用FormId
		List<MeidianUserMessage> list = userMessageService.findByUserIdFormTypeStatus(userMessage.getUserId(),userMessage.getOrderId(),userMessage.getFormType(),Constants.MSG_NOMAL,nowDate);
		if(list==null||list.size()==0){
			logger.info("小程序消息-暂无该类型可用FormId,userId:{},orderId:{}",userMessage.getUserId(),userMessage.getOrderId());
			return new MapResults(10902, "暂无该类型可用FormId");
		}
		//发送消息
		MeidianUserMessage meidianUserMessage = list.get(0);
		logger.info("小程序消息-发送消息内容,userId:{},formId:{}",userMessage.getUserId(),meidianUserMessage.getFormId());
		//生成token
		String appid = "wxMiniprogramMshop";
		String appSercet = "vapsqasekabua1frkx7seyt5yjj9d52956";
		String gzNo = "ServiceMiniprogramMshop";
		String token = MobileDES.createToken(appid, appSercet);
		//请求url
		String url = "http://wx.wireless.api/"+gzNo+"/miniprogramTemplate/push?appid="+appid+"&token="+token;
		//请求参数
		Map<String, Object> mapResult = this.sendMessageByHttp(url,this.handleBodyParam(userMessage, meidianUserMessage));
		if(mapResult==null||mapResult.size()<1){
			logger.info("小程序消息-消息发送失败,mapResult:{}",mapResult);
			return new MapResults(10902,"消息发送请求失败");
		}else{
			int code = (int) mapResult.get("code");
			String message = (String) mapResult.get("message");
			if(code!=0){
				logger.info("小程序消息-消息发送失败,userId:{},fromId:{},orderId:{},code:{},message:{}",userMessage.getUserId(),meidianUserMessage.getFormId(),userMessage.getOrderId(),code,message);
				return new MapResults(code,message);
			}
		}
		//更新状态
		MeidianUserMessage mum = new MeidianUserMessage();
		mum.setId(meidianUserMessage.getId());
		mum.setStatus(Constants.MSG_NO_NOMAL);
		userMessageService.updateById(mum);
		return new MapResults(0, "success");
	}
	
	//发送消息
	private Map<String, Object> sendMessageByHttp(String url, Map<String, Object> map) {
		Map<String, Object> json = new HashMap<>();
		json.put("body",JSON.toJSONString(map));
        String result = this.doFromPost(url, json);
        Map<String, Object> mapBody = JSON.parseObject(result);
        return mapBody;
	}
	
	//post请求form表单提交
	public String doFromPost(String url, Map<String, Object> map){
		CloseableHttpClient httpClient = HttpClients.createDefault();
		// 声明httpPost请求
		HttpPost httpPost = new HttpPost(url);
		// 判断map是否为空，不为空则进行遍历，封装from表单对象
		if(map != null) {
			List<NameValuePair> list = new ArrayList<NameValuePair>();
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
			}
			// 构造from表单对象
			UrlEncodedFormEntity urlEncodedFormEntity = null;
			try{
				urlEncodedFormEntity = new UrlEncodedFormEntity(list, "UTF-8");
			}catch (UnsupportedEncodingException e) {
				logger.error("构造from表单对象异常",e);
				return null;
			}
			// 把表单放到post里
			httpPost.setEntity(urlEncodedFormEntity);
		}
		CloseableHttpResponse response = null;
		try{//发起请求
			response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			String result = EntityUtils.toString(entity, "utf-8");
			// 关闭内容流和关闭响应之间的区别是：前者将尝试通过消耗实体内容来保持底层连接活动，而后者立即关闭并丢弃连接
			// 把底层的流给关闭了,可以看源码，
			EntityUtils.consume(entity);
			return result;
		}catch (IOException e) {
			logger.error("doFromPost请求异常",e);
			return null;
		}finally{
			try{//关闭响应,立即关闭并丢弃连接
				if(response != null){ response.close();}
			}catch (IOException e) {
				logger.error("关闭响应异常",e);
			}
		}
	}
	
	//body参数封装
	private Map<String, Object> handleBodyParam(UserMessage userMessage,MeidianUserMessage meidianUserMessage){
		Map<String, Object> map = new HashMap<>();
		map.put("user_id", String.valueOf(userMessage.getUserId()));
		map.put("templateId", userMessage.getTemplateId());
		if(userMessage.getPage()!=null&&!userMessage.getPage().equals("")){
			map.put("page", userMessage.getPage());
		}
		map.put("formId", meidianUserMessage.getFormId());
		Map<String,Object> mapData = new HashMap<>();
		for (int i=0; i < userMessage.getMessages().size(); i++) {
			Map<String,Object> mapVal = new HashMap<>();
			mapVal.put("value", userMessage.getMessages().get(i));
			mapData.put("keyword"+(i+1), mapVal);
		}
		map.put("data", mapData);
		return map;
	}
	
}
