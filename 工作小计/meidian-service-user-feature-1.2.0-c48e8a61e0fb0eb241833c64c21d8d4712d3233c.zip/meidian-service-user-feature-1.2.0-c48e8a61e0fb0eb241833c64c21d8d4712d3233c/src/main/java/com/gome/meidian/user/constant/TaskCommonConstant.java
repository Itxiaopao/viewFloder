package com.gome.meidian.user.constant;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 任务常量
 */
public class TaskCommonConstant {

    //发送的地址
    public static final String HTTP_URL = "url";

    //请求类型
    public static final String HTTP_METHOD = "httpMethod";

    //定时应用名称
    public static final String quartzScheduleName = "meidian-user";

    //服务启动后多少秒后执行 任务 默认是立即执行 此处设置为了10后执行
    public static final int quartzStartupDelay = 5;
    //片总
    public static final Integer USER_IS_PIAN = 3;
    //新客
    public static final Integer NEW_GUEST = 1;
    //店主身份 类型
    public static final Integer VSHOP_IDENTITY_1 = 1;
}
