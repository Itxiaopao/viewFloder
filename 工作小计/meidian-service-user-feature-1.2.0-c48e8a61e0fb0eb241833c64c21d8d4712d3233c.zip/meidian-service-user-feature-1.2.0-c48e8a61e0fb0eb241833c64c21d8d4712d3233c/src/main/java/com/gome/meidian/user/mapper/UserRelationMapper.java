package com.gome.meidian.user.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.UserRelation;
/**
 * 用户绑定关系数据层
 *
 */
public interface UserRelationMapper extends BaseMapper<UserRelation, Long> {
	/**
	 * 根据用户ID查询所有绑定关系
	 * @param userId
	 * @return
	 */
	List<UserRelation> findListByUserId(@Param("userId")String userId);

	/**
	 * 根据openId获取所有绑定关系
	 * @param openId
	 * @return
	 */
	List<UserRelation> findListByOpenId(@Param("openId")String openId);
}
