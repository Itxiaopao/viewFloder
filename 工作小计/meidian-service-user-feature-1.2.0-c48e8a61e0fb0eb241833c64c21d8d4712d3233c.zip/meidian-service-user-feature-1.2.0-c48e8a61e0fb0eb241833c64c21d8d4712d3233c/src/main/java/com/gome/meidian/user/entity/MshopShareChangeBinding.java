package com.gome.meidian.user.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * @author chenchen-ds6
 * 美店主绑定管理entity
 */
@Getter
@Setter
@ToString
public class MshopShareChangeBinding implements Serializable {
    private static final long serialVersionUID = 6227977189864267708L;
    private Long id;

    /**
     * 用户userId
     */
    private Long userId;

    /**
     * 上级userId
     */
    private Long upuserId;
    /**
     * 上次的上级userId
     */
    private Long lastUpuserId;
    /**
     * 新的邀请链条
     */
    private String shareChain;
    /**
     * 上次的邀请链条
     */
    private String lastShareChain;
    
    /**
     * 创建时间
     */
    private Date createTime;
    
    /**
     * 切换类型 0 切上级  1 升级操作
     */
    private Integer type;
    /**
     * 片总ID
     */
    private Long topLeaderUserId;
    /**
     * 上次片总Id
     */
    private Long lastTopLeaderUserId;
}
