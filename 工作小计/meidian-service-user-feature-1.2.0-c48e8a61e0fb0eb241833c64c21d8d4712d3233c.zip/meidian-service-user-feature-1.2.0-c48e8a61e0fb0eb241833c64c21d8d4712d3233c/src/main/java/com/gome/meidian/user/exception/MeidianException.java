package com.gome.meidian.user.exception;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description  异常处理基类
 */
public class MeidianException  extends  Exception{

    private String errorCode;
    private Object[] args;
    private static final long serialVersionUID = -5662172559536606637L;

    protected MeidianException(String errorCode) {
        super("ERROR CODE: " + errorCode);
        this.errorCode = errorCode;
    }

    protected MeidianException(String errorCode, Object... args) {
        super("ERROR CODE: " + errorCode + " ARGS:" + args);
        this.errorCode = errorCode;
        this.args = args;
    }

    protected MeidianException() {
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public Object[] getArgs() {
        return this.args;
    }

    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
