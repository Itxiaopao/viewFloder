package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.UserRights;
import com.gomeo2o.common.page.PageParam;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserRightsMapper {

    int delete(@Param("userId") Long userId, @Param("type") Integer type);

    int insert(UserRights record);

    /**
     * 保存用户权益，此方法如果主键冲突直接做更新
     *
     * @param record
     * @return
     */
    int save(UserRights record);

    UserRights selectByBiz(@Param("userId") Long userId, @Param("type") Integer type);

    Integer selectCountByBiz(@Param("type") Integer type);

    List<UserRights> selectPageByBiz(@Param("page") PageParam page, @Param("type") Integer type);

    int update(UserRights record);

}