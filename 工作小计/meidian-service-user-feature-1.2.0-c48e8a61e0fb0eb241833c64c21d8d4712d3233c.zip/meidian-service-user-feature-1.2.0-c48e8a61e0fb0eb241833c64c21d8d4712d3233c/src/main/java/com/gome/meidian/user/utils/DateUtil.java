package com.gome.meidian.user.utils;


import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description DateUtil工具类
 */
public class DateUtil {
	/**
	 * @Fields DEFAULT_PATTERN:默认格式 HHmmssSSS
	 */
	private final static String DEFAULT_PATTERN = "HHmmssSSS";

	/**
	 * @Title: getNowDate
	 * @return
	 * @Description: 获取当前时间
	 */
	public static Date getNowDate() {
		return Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * @Title: getNowLocalDate
	 * @return
	 * @Description: 获取当前时间
	 */
	public static LocalDateTime getNowLocalDate() {
		return LocalDateTime.now();
	}

	/**
	 * @Title: convertDate
	 * @param localDateTime
	 * @return
	 * @Description: LocalDateTime 转换为 Date
	 */
	public static Date convert2Date(LocalDateTime localDateTime) {
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * @Title: convert2LocalDateTime
	 * @param date
	 * @return
	 * @Description: Date 转换为 LocalDateTime
	 */
	public static LocalDateTime convert2LocalDateTime(Date date) {
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	/**
	 * @Title: plusMintius
	 * @param date
	 * @param minutes
	 * @return
	 * @Description: 当前时间 新增分钟数
	 */
	public static Date plusMintius(Date date, Long minutes) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusMinutes(minutes));
	}

	/**
	 * @Title: plusHours
	 * @param date
	 * @param hours
	 * @return
	 * @Description: 新增小时
	 */
	public static Date plusHours(Date date, Long hours) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusHours(hours));
	}

	/**
	 * @Title: plusDays
	 * @param date
	 * @param days
	 * @return
	 * @Description: 新增天数
	 */
	public static Date plusDays(Date date, Long days) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusDays(days));
	}

	/**
	 * @Title: plusMonths
	 * @param date
	 * @param months
	 * @return
	 * @Description: 新增月份
	 */
	public static Date plusMonths(Date date, Long months) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(plusMonth(date, months));
	}

	public static LocalDateTime plusMonth(Date date, Long months) {
		return convert2LocalDateTime(date).plusMonths(months);
	}

	/**
	 * @Title: plusYear
	 * @param date
	 * @param years
	 * @return
	 * @Description: 新增年
	 */
	public static Date plusYear(Date date, Long years) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusYears(years));
	}

	/**
	 * @Title: minusMinutes
	 * @param date
	 * @param minutes
	 * @return
	 * @Description: 减去分钟数
	 */
	public static Date minusMinutes(Date date, Long minutes) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusMinutes(minutes));
	}

	/**
	 * @Title: minusHours
	 * @param date
	 * @param hours
	 * @return
	 * @Description: 减去小时
	 */
	public static Date minusHours(Date date, Long hours) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusHours(hours));
	}

	/**
	 * @Title: minusDays
	 * @param date
	 * @param days
	 * @return
	 * @Description: 减去天数
	 */
	public static Date minusDays(Date date, Long days) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusDays(days));
	}

	/**
	 * @Title: minusMonths
	 * @param date
	 * @param months
	 * @return
	 * @Description: 减去月份
	 */
	public static Date minusMonths(Date date, Long months) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusMonths(months));
	}

	/**
	 * @Title: formatLocalDateTime
	 * @param localDateTime
	 * @param pattern
	 * @return
	 * @Description: 格式化 默认格式 yyyyMMddHHmmssSSS
	 */
	public static String formatLocalDateTime(LocalDateTime localDateTime, String pattern) {
		if (StringUtils.isEmpty(pattern)) {
			pattern = DEFAULT_PATTERN;
		}
		if (null == localDateTime) {
			localDateTime = getNowLocalDate();
		}
		return DateTimeFormatter.ofPattern(pattern).format(localDateTime);
	}

	/**
	 * @Title: formatDate
	 * @param date
	 * @param pattern
	 * @return
	 * @Description: 格式化 默认格式 yyyyMMddHHmmssSSS
	 */
	public static String formatDate(Date date, String pattern) {
		if (StringUtils.isEmpty(pattern)) {
			pattern = DEFAULT_PATTERN;
		}
		if (null == date) {
			date = getNowDate();
		}
		return DateTimeFormatter.ofPattern(pattern).format(convert2LocalDateTime(date));
	}

	/**
	 * @Title: formate
	 * @param strDate
	 * @param pattern
	 * @return
	 * @Description: 解析字符串为时间类型
	 */
	public static Date formate(String strDate, String pattern) {
		return convert2Date(LocalDateTime.parse(strDate, DateTimeFormatter.ofPattern(pattern)));
	}

}
