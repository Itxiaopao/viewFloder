package com.gome.meidian.user.manager;

import java.util.Date;
import java.util.List;

import com.gome.meidian.user.utils.RedisKeyUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.UserRelation;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.UserRelationService;

import redis.Gcache;

@Component
public class UserRelationManager implements IUserRelationManager {
	private static Logger logger = LoggerFactory.getLogger(UserRelationManager.class);
	@Autowired
	private UserRelationService userRelationService;
	@Autowired
	private Gcache gcache;
	
	private String relationKey = "user.center.userRelation.manager";
	
	/**
	 * 添加绑定关系
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public MapResults<Object> addUserRelation(UserRelation userRelation) {
		MapResults<Object> result = null;
		if(userRelation == null || StringUtils.isBlank(userRelation.getUserId())) {
			logger.error("添加绑定关系失败，参数userRelation为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {

			Date date = new Date();
			userRelation.setCtime(date);
			userRelation.setUtime(date);
			userRelationService.add(userRelation);
			
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			this.refreshRelation(userRelation.getOpenId());
		}catch(Exception e) {
			logger.error("添加绑定关系异常，userId:{}，messge:{}", userRelation.getUserId(), e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 删除绑定关系
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public MapResults<Object> deleteUserRelation(Long id) {
		MapResults<Object> result = null;			
		if(id == null) {
			logger.error("删除绑定关系失败，参数id为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			UserRelation relation = userRelationService.findById(id);
			if(relation == null) {
				return result;
			}
			userRelationService.deleteById(id);
			this.refreshRelation(relation.getOpenId());
		}catch(Exception e) {
			logger.error("删除绑定关系异常，id:{}，messge:{}", id, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 修改绑定关系
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public MapResults<Object> updateUserRelation(UserRelation userRelation) {
		MapResults<Object> result = null;			
		if(userRelation == null) {
			logger.error("修改绑定关系失败，参数userRelation为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {

			Date date = new Date();
			userRelation.setUtime(date);
			userRelationService.update(userRelation);
			this.refreshRelation(userRelation.getOpenId());
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
		}catch(Exception e) {
			logger.error("修改绑定关系异常，userId:{}，id:{}，messge:{}", userRelation.getUserId(), userRelation.getId(), e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 根据userId获取绑定关系
	 */
	public MapResults<List<UserRelation>> findByUserId(String userId){
		MapResults<List<UserRelation>> result = null;			
		if(null == userId) {
			logger.error("获取绑定关系失败，参数userId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			List<UserRelation> list = null;
//			String key = relationKey + ":" + RedisKeyUtils.getHKey(userId);
//			String relationStr = gcache.hget(key, userId);
//			if(StringUtils.isNotBlank(relationStr)) {
//				list = JSONObject.parseArray(relationStr, UserRelation.class);
//			}
			
//			if(null == list || list.isEmpty()) {
				list = userRelationService.findListByUserId(userId);
//				if(list != null && list.size() > 0) {
//					gcache.hset(key, userId, JSONObject.toJSONString(list));
//				}
//			}
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			result.setBuessObj(list);
		}catch(Exception e) {
			logger.error("根据userId获取绑定关系异常，userId:{}，messge:{}", userId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}


	/**
	 * 根据openId获取绑定关系
	 */
	public MapResults<List<UserRelation>> findByOpenId(String openId){
		MapResults<List<UserRelation>> result = null;
		if(null == openId) {
			logger.error("获取绑定关系失败，参数openId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			List<UserRelation> list = null;
			String key = relationKey + ":" + RedisKeyUtils.getHKey(openId);
			String relationStr = gcache.hget(key, openId);
			if(StringUtils.isNotBlank(relationStr)) {
				list = JSONObject.parseArray(relationStr, UserRelation.class);
			}

			if(null == list || list.isEmpty()) {
				list = userRelationService.findListByOpenId(openId);
				if(list != null && list.size() > 0) {
					gcache.hset(key, openId, JSONObject.toJSONString(list));
				}
			}
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			result.setBuessObj(list);
		}catch(Exception e) {
			logger.error("根据openId获取绑定关系异常，openId:{}，messge:{}", openId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	private void refreshRelation(String openId) {
		String key = relationKey + ":" + RedisKeyUtils.getHKey(openId);
		gcache.hdel(key, openId);
		this.findByOpenId(openId);
	}
}
