package com.gome.meidian.user.service;

import java.util.List;

import com.gome.meidian.user.entity.UserRelation;
/**
 * 用户绑定关系服务层
 *
 */
public interface UserRelationService extends BaseService<UserRelation, Long> {
	/**
	 * 根据userID获取所有绑定关系
	 * @param userId
	 * @return
	 */
	List<UserRelation> findListByUserId(String userId);

	/**
	 * 根据openId获取所有绑定关系
	 * @param openId
	 * @return
	 */
	List<UserRelation> findListByOpenId(String openId);
}
