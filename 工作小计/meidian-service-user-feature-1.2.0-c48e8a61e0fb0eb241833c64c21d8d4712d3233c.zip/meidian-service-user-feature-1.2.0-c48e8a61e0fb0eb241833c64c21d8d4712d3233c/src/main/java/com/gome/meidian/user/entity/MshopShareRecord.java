package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author chenchen-ds6
 * 美店主改版分享链
 */
@Getter
@Setter
@ToString
public class MshopShareRecord implements Serializable {

    private static final long serialVersionUID = -1171877807385587152L;
    private Long id;//主键id
    private String uniqueId;//当前授权人的uniqueId（必传）
    private Long userId;//当前授权人userId
    private Long mid;//当前授权人的mid
    private String puniqueId;//分享人的uniqueId（必传）
    private Long pmid;//分享人的mid
    private Long puserId;//分享人的userId
    private Integer ptype;//分享人的type
    private Integer type;//当前授权人的type
    private Date insertTime;//插入时间
    private Date updateTime;//更新时间
    private Long upmid;//上级美店id
    private Long upuserId;//上级用户id
    private Integer version;//版本号
    private Integer authorization;//授权类型

}
