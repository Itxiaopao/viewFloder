package com.gome.meidian.user.mq.data;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
@Data
@EqualsAndHashCode(callSuper=false)
@ToString
public class CustomUpperShopData extends MQData {

    private Long inviteUserId;

    private Boolean gomeOldUser;
}
