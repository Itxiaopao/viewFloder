package com.gome.meidian.user.constant;

/**
 * 缓存业务常量
 */
public class CacheConstant {

    /**
     * 缓存时间1分钟
     */
    public static final int CACHE_TIME_ONE_MINUTE = 60;

    /**
     * 缓存时间1小时
     */
    public static final int CACHE_TIME_ONE_HOUR = CACHE_TIME_ONE_MINUTE * 60;

    /**
     * 缓存时间1天
     */
    public static final int CACHE_TIME_ONE_DAY = CACHE_TIME_ONE_HOUR * 24;

    /**
     * 缓存时间1周
     */
    public static final int CACHE_TIME_ONE_WEEK = CACHE_TIME_ONE_DAY * 7;

    /**
     * 缓存时间30天
     */
    public static final int CACHE_TIME_ONE_MONTH = CACHE_TIME_ONE_DAY * 30;

    /**
     * 用户权益str前缀
     */
    public static final String USER_RIGHTS_HASH_PREFIX = "user_rights_hash_prefix";

    /**
     * 用户权益缓存key管理set前缀
     */
    public static final String USER_RIGHTS_CACHE_MGT_SET_PREFIX = "user_rights_cache_mgt_set_prefix";

    /**
     * 分布式锁工具类公用前缀
     */
    public static final String DISTRIBUTED_LOCK_PREFIX = "distributed_lock_prefix";

    /**
     * 用户关系链同步redis锁前缀
     */
    public static final String USER_BIND_RELATION_INCR_PREFIX = "user_bind_relation_incr_prefix";

    /**
     * 用户权益保存奖励redis锁前缀
     */
    public static final String USER_RIGHTS_SAVE_REWARDS_INCR_PREFIX = "user_rights_save_rewards_incr_prefix";

    /**
     * 用户权益消费权益redis锁前缀
     */
    public static final String USER_RIGHTS_CONSUME_RIGHTS_INCR_PREFIX = "user_rights_consume_rights_incr_prefix";

    /**
     * 用户权益重置缓存redis锁前缀
     */
    public static final String USER_RIGHTS_RESET_INCR_PREFIX = "user_rights_reset_incr_prefix";

    /**
     * 用户权益数据去清理redis锁前缀
     */
    public static final String USER_RIGHTS_CLEAR_INCR_PREFIX = "user_rights_clear_incr_prefix";

    /**
     * 用户关系MQ消费重试次数
     */
    public static final String USER_RELATION_MQ_CHANNEL_RETRY_INCR_PREFIX = "user_relation_mq_channel_retry_incr_prefix_";

    /**
     * 用户关系记录string缓存
     */
    public static final String USER_RELATION_RECORD_STR_PREFIX = "user_relation_record_str_prefix_";

    /**
     * 用户分享记录String缓存
     */
    public static final String USER_SHARE_RECORD_STR_PREFIX = "user_share_record_str_prefix";

    /**
     * 微信用户String缓存
     */
    public static final String WECHAT_USER_INFO_STR_PREFIX = "wechat_user_info_str_prefix";

    /**
     * 用户下属关系zset缓存前缀
     */
    public static final String USER_SUBORDINATE_RELATION_ZSET_PREFIX = "user_subordinate_relation_zset_prefix";

    /**
     * 业务用户关系互斥锁
     */
    public static final String BIZ_USER_RELATION_MUTEX_LOCK_PREFIX = "biz_user_relation_mutex_lock_prefix";

    /**
     * 处理微信用户信息防重复提交锁
     */
    public static final String DEAL_WITH_WECHAT_INFO_RESUBMIT_LOCK_PREFIX = "dealWithWechatInfo_";


    public static final String MSHOPOWNER_INFO_PREFIX = "MShopOwnerInfoManager.queryMshopOwnerIndexByUserId_";


}
