package com.gome.meidian.user.service;

import java.io.Serializable;
/**
 * 服务层基类
 *
 * @param <T>
 * @param <ID>
 */
public interface  BaseService<T, ID extends Serializable> {
	int add(T t);
	
	int deleteById(ID id);
	
	int update(T t);
	
	T findById(ID id);	
}
