package com.gome.meidian.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.service.MShopShareRecordService;

/**
 * @author chenchen-ds6
 * 分享链服务层实现
 */
@Service
public class MShopShareRecordServiceImpl implements MShopShareRecordService {
    @Autowired
    MShopShareRecordMapper mshopShareRecordMapper;

    @Override
    public MshopShareRecord queryByParam(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.queryByParam(mshopShareRecord);
    }

    @Override
    public MshopShareRecord queryByUniqueIdAndPuserId(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.queryByUniqueIdAndPuserId(mshopShareRecord);
    }

    /**
     * 插入分享链关系
     * @param mshopShareRecord
     * @return
     */
    @Override
    public int insertMShopShareRecord(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.insertMShopShareRecord(mshopShareRecord);
    }

    /**
     * 修改分享链路
     * @param mshopShareRecord
     * @return
     */
    @Override
    public int updateMShopShareRecord(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.updateMShopShareRecord(mshopShareRecord);
    }

    /**
     * 返回指定游客的集合
     * @param mshopShareRecord
     * @return
     */
    @Override
    public List<MshopShareRecord> queryListByParam(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.queryListByParam(mshopShareRecord);
    }


    @Override
    public Integer queryMyVisitorCount(Long userId, Integer type) {
        Integer integer = mshopShareRecordMapper.queryMyVisitorCount(userId, type);
        return integer == null ? 0 : integer;
    }

    /**
     * 通过uniqueId或者userId查询
     * @param mshopShareRecord
     * @return
     */
    @Override
    public List<MshopShareRecord> queryByUniqueIdOrUserId(MshopShareRecord mshopShareRecord){
        return mshopShareRecordMapper.queryByUniqueIdOrUserId(mshopShareRecord);
    }

    @Override
    public MshopShareRecord queryByUniqueIdAndPuniqueId(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.queryByUniqueIdAndPuniqueId(mshopShareRecord);
    }

    @Override
    public List<String> queryUniqueIdListByUpUserId(Long upUserId) {
        if(null!=upUserId){
            return mshopShareRecordMapper.queryUniqueIdListByUpUserId(upUserId);
        }
        return null;
    }

    @Override
    public int updateMShopShareRecordById(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.updateMShopShareRecordById(mshopShareRecord);
    }

    @Override
    public int queryCountByBiz(MshopShareRecord mshopShareRecord) {
        return mshopShareRecordMapper.queryCountByBiz(mshopShareRecord);
    }

}
