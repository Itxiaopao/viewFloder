package com.gome.meidian.user.service.impl;

import com.gome.meidian.user.dto.LayerCmsConfigDto;
import com.gome.meidian.user.mapper.equities.LayerCmsConfigMapper;
import com.gome.meidian.user.service.equities.LayerCmsConfigService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class LayerCmsConfigServiceImpl implements LayerCmsConfigService {

    @Resource
    private LayerCmsConfigMapper layerCmsConfigMapper;

    @Override
    public int deleteByPrimaryKey(Long id){
        return layerCmsConfigMapper.deleteByPrimaryKey(id);
    }
    @Override
    public int insert(LayerCmsConfigDto record){
        return layerCmsConfigMapper.insert(record);
    }
    @Override
    public int insertSelective(LayerCmsConfigDto record){
        return layerCmsConfigMapper.insertSelective(record);
    }
    @Override
    public LayerCmsConfigDto selectByPrimaryKey(Long id){
        return layerCmsConfigMapper.selectByPrimaryKey(id);
    }
    @Override
    public List<LayerCmsConfigDto> selectByParam(Map<String, Object> map){
        return layerCmsConfigMapper.selectByParam(map);
    }
    @Override
    public Long queryCountByParam(Map<String,Object> map){
        return layerCmsConfigMapper.queryCountByParam(map);
    }
    @Override
    public int updateByPrimaryKeySelective(LayerCmsConfigDto record){
        return layerCmsConfigMapper.updateByPrimaryKeySelective(record);
    }
    @Override
    public int updateByPrimaryKey(LayerCmsConfigDto record){
        return layerCmsConfigMapper.updateByPrimaryKey(record);
    }

}
