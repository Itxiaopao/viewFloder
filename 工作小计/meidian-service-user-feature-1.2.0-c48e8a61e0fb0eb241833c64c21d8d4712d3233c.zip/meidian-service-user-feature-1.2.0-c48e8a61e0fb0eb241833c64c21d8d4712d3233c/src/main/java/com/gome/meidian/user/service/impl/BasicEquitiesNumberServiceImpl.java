package com.gome.meidian.user.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;
import com.gome.meidian.user.mapper.equities.BasicEquitiesNumberMapper;
import com.gome.meidian.user.service.equities.BasicEquitiesNumberService;
import com.gome.meidian.user.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import redis.Gcache;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class BasicEquitiesNumberServiceImpl implements BasicEquitiesNumberService {

    @Resource
    private BasicEquitiesNumberMapper basicEquitiesNumberMapper;
    @Resource
    private Gcache gcache;

    private static final String KEY = "BasicEquitiesNumber_queryByType";



    @Override
    public List<UserBasicEquitiesNumberDto> queryAllListGroupBYType() {
//        try {
//            List<UserBasicEquitiesNumberDto> list = Lists.newArrayList();
//            Map<String, String> map = gcache.hgetAll(KEY);
//            if(MapUtils.isNotEmpty(map)){
//                for (String jsonStr : map.values()) {
//                    UserBasicEquitiesNumberDto userBasicEquitiesNumberDto = JSON.parseObject(jsonStr, new TypeReference<UserBasicEquitiesNumberDto>() {});
//                    list.add(userBasicEquitiesNumberDto);
//                }
//                return list;
//            }
//        } catch (Exception e) {
//            log.error("BasicEquitiesNumberManager.queryAllListGroupBYType get cache is fail ", e);
//        }
//        //数据库
//        log.info("BasicEquitiesNumberManager.queryAllListGroupBYType 查找数据库获取列表数据...........");
        return basicEquitiesNumberMapper.queryAllListGroupBYType();
    }

    @Override
    public UserBasicEquitiesNumberDto queryByType(Integer type) {
        log.info("BasicEquitiesNumberManager.BasicEquitiesNumberService.queryByType param type {}", type);
        if (null == type) {
            return null;
        }
        UserBasicEquitiesNumberDto result = null;
        try {
            String cache = gcache.hget(KEY, type + "");
            log.info("BasicEquitiesNumberManager.BasicEquitiesNumberService.queryByType param type {},cache {} ", type, cache);
            if (StringUtils.isNotEmpty(cache)) {
                result = JSON.parseObject(cache, new TypeReference<UserBasicEquitiesNumberDto>() {});
            }
        } catch (Exception e) {
            log.error("BasicEquitiesNumberManager.BasicEquitiesNumberService.queryByType get redis cache data is fail,param type is {}", type, e);
        }
        if (null == result) {
            //数据库
            UserBasicEquitiesNumberDto param = new UserBasicEquitiesNumberDto();
            param.setType(type);
            result =  basicEquitiesNumberMapper.queryOneByParam(param);
        }
        if (null == result) {
            result = new UserBasicEquitiesNumberDto();
            result.setTotalOpenCount(0);
            result.setTotalJoinCount(0);
            result.setOpenCount(0);
            result.setJoinCount(0);
            result.setRewardOpenCount(0);
            result.setRewardJoinCount(0);
            result.setType(type);
            return result;
        }

        //进行最终结果的计算
        long localTime = System.currentTimeMillis();
        Date rewardBeginTime = result.getRewardBeginTime();
        Date rewardEndTime = result.getRewardEndTime();
        if (null != rewardBeginTime && null != rewardEndTime && localTime >= rewardBeginTime.getTime()
                && localTime <= rewardEndTime.getTime()) {
            result.setTotalJoinCount(result.getJoinCount() + result.getRewardJoinCount());
            result.setTotalOpenCount(result.getOpenCount() + result.getRewardOpenCount());
        }else{
            result.setTotalOpenCount(result.getOpenCount());
            result.setTotalJoinCount(result.getJoinCount());
        }
        log.info("BasicEquitiesNumberManager.BasicEquitiesNumberService.queryByType param type {},result {}", type, result);
        return result;
    }

    /**
     * 一次性插入4条数据
     * @param list
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    public int insertBatch(List<UserBasicEquitiesNumberDto> list){
        for (UserBasicEquitiesNumberDto dto : list) {
            UserBasicEquitiesNumberDto dataDto = queryByType(dto.getType());
            if (null != dataDto) {
                dto.setInsertTime(DateUtil.formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                dto.setUpdateTime(DateUtil.formatDate(new Date(),"yyyy-MM-dd HH:mm:ss"));
                dto.setRewardOpenCount(null == dataDto.getRewardOpenCount() ? 0 : dataDto.getRewardOpenCount());
                dto.setRewardJoinCount(null ==dataDto.getRewardJoinCount()? 0 : dataDto.getRewardJoinCount());
                dto.setRewardBeginTime(dataDto.getRewardBeginTime());
                dto.setRewardEndTime(dataDto.getRewardEndTime());
            }
            basicEquitiesNumberMapper.insert(dto);
            log.info("BasicEquitiesNumberManager.BasicEquitiesNumberService.insertBatch 更新缓存数据");
            gcache.hset(KEY, dto.getType() + "", JSON.toJSONString(dto));
        }
        return 1;
    }

    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    public void updateBatch(List<UserBasicEquitiesNumberDto> list) {
        for (UserBasicEquitiesNumberDto vo : list) {
            basicEquitiesNumberMapper.updateWithParam(vo);
            log.info("BasicEquitiesNumberManager.BasicEquitiesNumberService.updateBatch 开始更新缓存数据");
            gcache.hset(KEY, vo.getType() + "", JSON.toJSONString(vo));
        }
    }
}
