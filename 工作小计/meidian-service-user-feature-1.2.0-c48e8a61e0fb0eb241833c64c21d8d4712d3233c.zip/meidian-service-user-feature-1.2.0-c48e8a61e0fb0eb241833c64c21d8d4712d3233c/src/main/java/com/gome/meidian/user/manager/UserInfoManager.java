package com.gome.meidian.user.manager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gome.meidian.user.page.Page;
import com.gome.meidian.user.utils.RedisKeyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.UserInfo;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.UserInfoService;
import com.gome.meidian.user.utils.MobileUtil;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userCenter.facade.userservice.profile.IEmailMobileFacade;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.GomeRegisterInfo;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gome.userCenter.model.enu.RegisterSource;
import com.gomeo2o.common.entity.CommonResultEntity;

import cn.com.gome.user.service.QueryUserInfoFacade;
import cn.com.gome.user.v2.model.StaffInfoVo;
import redis.Gcache;

@Component
public class UserInfoManager implements IUserInfoManager{
	private static Logger logger = LoggerFactory.getLogger(UserInfoManager.class);
	@Autowired
	private UserInfoService userInfoService;
	@Autowired
	private Gcache gcache;
	
	@Autowired
	private IEmailMobileFacade iEmailMobileFacade;
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	@Autowired
	private IUserRoleManager iUserRoleManager;
	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	
	private String userInfoKey = "user.center.userInfo.manager";

	/**
	 * 添加用户信息
	 * @param user
	 * @param phone
	 * @param invokeFrom
	 * @return 
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public MapResults<Object> addUserInfoByInviteUser(UserInfo user, String phone, String invokeFrom){
		MapResults<Object> result = null;
		if(user == null || StringUtils.isBlank(user.getUserId())) {
			logger.error("添加用户信息失败，参数user为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		
		try {
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());

			UserInfo ouser = this.getUserInfoByUserId(user.getUserId());
			if (null != ouser) {
				logger.info("添加用户信息失败，用户已存在，userId:{}，addType:{}", user.getUserId(), user.getAddType());
				result = new MapResults<>(ExceptionCodeEnum.ADD_USER_EXISTS);
				return result;
			}
			
			//邀请人ID
			logger.info("邀请人ID处理,手机号：{},邀请人ID：{}", phone, user.getParentInviteUserId());
			if(StringUtils.isNotBlank(phone)) {
				String inviterUserId = this.getInviteUserId(phone, invokeFrom);
				if(StringUtils.isBlank(inviterUserId)) {
					logger.error("添加用户信息失败，邀请人不存在，phone:{}", phone);
					result = new MapResults<>(ExceptionCodeEnum.ADD_USER_INVITEUSER_NOTEXISTS);
					return result;
				}
				user.setParentInviteUserId(inviterUserId);
			}
			
			// 处理注册时间
			logger.info("添加用户信息，处理注册时间，userId:{}", user.getUserId());
			Map<String, Object> param = new HashMap<>();
			param.put("companyName", "gomeOnLine");
			MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(user.getUserId(), invokeFrom, param);
			if(null != userResult && userResult.isSuccess()) {
				UnifyUserInfoExt info = userResult.getBuessObj();
				if(null != info && StringUtils.isNotBlank(info.getRegisterDateSting())) {
					user.setRegisterTime(new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(info.getRegisterDateSting()));
				}
			}
			// 处理注册IP、渠道来源
			logger.info("添加用户信息，处理注册IP、渠道来源，userId:{}", user.getUserId());
			UserResult<GomeRegisterInfo> IPResult = iUserInfoFacade.queryUserRegInfoById(user.getUserId(), invokeFrom);
			if(null != IPResult && IPResult.isSuccess()) {
				GomeRegisterInfo info = IPResult.getBuessObj();
				if(null != info){
					user.setRegisterIp(info.getRegisterIp());
					if(NumberUtils.isNumber(info.getRegisterSource())) {
						user.setRefrenceType(RegisterSource.getRegisterSourceByCode(Integer.parseInt(info.getRegisterSource())).getEnName());
					}
				}
			}


			//是否员工
			logger.info("添加用户信息，处理是否员工，userId:{}", user.getUserId());
			CommonResultEntity<StaffInfoVo> staffInfo = queryUserInfoFacade.getStaffInfoByUserId(user.getUserId());
			if(staffInfo != null && staffInfo.isSuccess()) {
				StaffInfoVo staff = staffInfo.getBusinessObj();
				if(null != staff){
					if(staff.isStoreStaff()) {
						user.setEmployeeType("1");
					}else {
						user.setEmployeeType("0");
					}
				}
			}
			
			Date date = new Date();
			user.setCtime(date);
			user.setUtime(date);
			userInfoService.add(user);

			this.refreshUserInfo(user.getUserId());
		}catch(Exception e) {
			logger.error("添加用户信息异常，userId:{}，messge:{}", user.getUserId(), e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 获取用户信息
	 */
	public MapResults<UserInfo> findUserInfoByUserId(String userId){
		MapResults<UserInfo> result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
		if(StringUtils.isBlank(userId)) {
			logger.error("获取用户信息失败，userId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			UserInfo userInfo = this.getUserInfoByUserId(userId);
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			result.setBuessObj(userInfo);
		}catch(Exception e) {
			logger.error("获取用户信息异常，userId:{}，messge:{}", userId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 根据userID获取用户信息
	 * @param userId
	 * @return
	 */
	private UserInfo getUserInfoByUserId(String userId) {
		UserInfo userInfo = null;
		if(StringUtils.isBlank(userId)) {
			return userInfo;
		}
		String key = userInfoKey + ":" + RedisKeyUtils.getHKey(userId);
		String userStr = gcache.hget(key, userId);
		if(StringUtils.isNotBlank(userStr)) {
			userInfo = JSONObject.parseObject(userStr, UserInfo.class);
		}
		
		if(null == userInfo){
			userInfo = userInfoService.findByUserId(userId);
			if(null != userInfo) {
				gcache.hset(key, userId, JSONObject.toJSONString(userInfo));
			}
		}
		return userInfo;
	}
	
	/**
	 * 同步mid
	 * @param userId
	 * @param mid
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	public MapResults<Object> modifyUserInfo(String userId, String mid) {
		MapResults<Object> result = null;
		if(StringUtils.isBlank(userId) || StringUtils.isBlank(mid)) {
			logger.error("同步mid失败，参数为空，userId:{}，mid:{}", userId, mid);
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			UserInfo userInfo = this.getUserInfoByUserId(userId);
			if(userInfo == null) {
				return result;
			}
			userInfo.setUserId(userId);
			userInfo.setMid(mid);
			userInfoService.update(userInfo);
			iUserRoleManager.modifyMDUserRole(userId);
			// 缓存
			this.refreshUserInfo(userId);
		}catch(Exception e) {
			logger.error("同步mid异常，userId:{}，mid:{}，messge:{}", userId, mid, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 刷新缓存
	 * @param userId
	 */
	private void refreshUserInfo(String userId) {
		String key = userInfoKey + ":" + RedisKeyUtils.getHKey(userId);
		gcache.hdel(key, userId);
		this.getUserInfoByUserId(userId);
	}
	/**
	 * 根据邀请手机号获取邀请人userID
	 * @param phoneNum
	 * @return
	 * @throws ServiceException
	 */
	private String getInviteUserId(String phoneNum, String invokeFrom) throws ServiceException {

		logger.info("添加用户信息，根据手机号获取用户userId，phoneNum:{}", phoneNum);
		if(StringUtils.isBlank(phoneNum)) {
			return null;
		}
		
		if(!MobileUtil.isPhone(phoneNum)) {
			return null;
		}
		// 调用接口获取对应的userID
		Map<String, Object> param = new HashMap<>();
		param.put("companyName", "gomeOnLine");

		String userId = null;

		UserResult<List<UnifyUserInfoExt>> userResult = iEmailMobileFacade.queryUserInfoListByMobile(phoneNum, invokeFrom, param);
		if(userResult != null && userResult.isSuccess() && userResult.getCode() == 200) {
			List<UnifyUserInfoExt> list = userResult.getBuessObj();
			if(null != list && list.size() > 0) {
				UnifyUserInfoExt ext = list.get(0);
				userId = ext.getId();
			}
		}
		
		return userId;
	}


	/**
	 * 条件查询
	 * @param pageNo pageSize
	 * @return
	 */
	public List<UserInfo> findByQuery(int pageNo,int pageSize){
		Map<String, Object> map=new HashMap<String,Object>();
		if(pageSize>10000){
			pageSize=10000;
		}
		Page page=Page.newBuilder(pageNo,pageSize,"user_info");
		map.put("page",page);
		return userInfoService.findByQuery(map);
	}


	/**
	 * 查询数据条数
	 * @return
	 */
	public Integer findCountUserInfo(){
		return userInfoService.findCountUserInfo();
	}


}
