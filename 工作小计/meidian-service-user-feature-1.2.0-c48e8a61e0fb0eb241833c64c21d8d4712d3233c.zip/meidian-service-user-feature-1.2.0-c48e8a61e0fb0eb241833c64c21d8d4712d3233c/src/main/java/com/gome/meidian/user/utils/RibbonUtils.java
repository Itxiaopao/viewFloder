package com.gome.meidian.user.utils;

import com.gome.meidian.user.exception.MeidianRestClientException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.io.InputStream;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description RibbonUtils工具类
 */
@Service
public class RibbonUtils {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    @Resource
    @Qualifier("restTemplate")
    private RestTemplate restTemplate;

    public RibbonUtils() {
    }

    /**
     * HTTP Get方法
     * @param url
     * @param responseType
     * @param uriVariables
     * @param <T>
     * @return
     * @throws MeidianRestClientException
     */
    public <T> T executeGetRequest(String url, Class<T> responseType, Object... uriVariables) throws MeidianRestClientException {
        try {
            ResponseEntity<T> responseEntity = this.restTemplate.getForEntity(url, responseType, uriVariables);
            if (responseEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
                T t = responseEntity.getBody();
                return t;
            } else {
                this.logger.error("Ribbon Get请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, responseEntity.getBody()});
                throw new MeidianRestClientException((String)((String)responseEntity.getBody()));
            }
        } catch (RestClientException var6) {
            this.logger.error("Ribbon Get请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, var6});
            throw new MeidianRestClientException(var6);
        }
    }

    /**
     * HTTP Post方法
     * @param url
     * @param request
     * @param responseType
     * @param uriVariables
     * @param <T>
     * @return
     * @throws MeidianRestClientException
     */
    public <T> T executePostRequest(String url, Object request, Class<T> responseType, Object... uriVariables) throws MeidianRestClientException {
        try {
            ResponseEntity<T> responseEntity = this.restTemplate.postForEntity(url, request, responseType, uriVariables);
            if (responseEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
                T t = responseEntity.getBody();
                return t;
            } else {
                this.logger.error("Ribbon Post请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, responseEntity.getBody()});
                throw new MeidianRestClientException((String)((String)responseEntity.getBody()));
            }
        } catch (RestClientException var7) {
            this.logger.error("Ribbon Post请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, var7});
            throw new MeidianRestClientException(var7);
        }
    }

    /**
     * HTTP Delete方法
     * @param url
     * @param uriVariables
     * @throws MeidianRestClientException
     */
    public void executeDeleteRequest(String url, Object... uriVariables) throws MeidianRestClientException {
        try {
            this.restTemplate.delete(url, uriVariables);
        } catch (RestClientException var4) {
            this.logger.error("Ribbon Delete请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, var4});
            throw new MeidianRestClientException(var4);
        }
    }

    /**
     * HTTP Put方法
     * @param url
     * @param request
     * @param uriVariables
     * @throws MeidianRestClientException
     */
    public void executePutRequest(String url, Object request, Object... uriVariables) throws MeidianRestClientException {
        try {
            this.restTemplate.put(url, request, uriVariables);
        } catch (RestClientException var5) {
            this.logger.error("Ribbon put请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, var5});
            throw new MeidianRestClientException(var5);
        }
    }

    /**
     * Http 流请求
     * @param url
     * @param uriVariables
     * @return
     * @throws MeidianRestClientException
     */
	public InputStream executeRequestStream(String url, Object... uriVariables) throws MeidianRestClientException {
        try {
            ResponseEntity<org.springframework.core.io.Resource> responseEntity = this.restTemplate.exchange(url, HttpMethod.GET, (HttpEntity)null, org.springframework.core.io.Resource.class, uriVariables);
            if (responseEntity.getStatusCodeValue() == HttpStatus.OK.value()) {
                InputStream inputStream = ((org.springframework.core.io.Resource)responseEntity.getBody()).getInputStream();
                return inputStream;
            } else {
                this.logger.error("Ribbon GET 远程数据流 请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, responseEntity.getBody()});
                throw new MeidianRestClientException("Ribbon 获取流异常");
            }
        } catch (Exception var5) {
            this.logger.error("Ribbon GET 远程数据流 请求异常请求URL{},请求参数{},异常信息", new Object[]{url, uriVariables, var5});
            throw new MeidianRestClientException(var5);
        }
    }


}
