package com.gome.meidian.user.service.impl;

import com.gome.meidian.user.entity.MeidianUserBindWechatRecord;
import com.gome.meidian.user.mapper.MeidianUserBindWechatRecordMapper;
import com.gome.meidian.user.service.MeidianUserBindWechatRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MeidianUserBindWechatRecordServiceImpl implements MeidianUserBindWechatRecordService {

    @Autowired
    private MeidianUserBindWechatRecordMapper meidianUserBindWechatRecordMapper;

    @Override
    public Boolean save(MeidianUserBindWechatRecord record) {
        return meidianUserBindWechatRecordMapper.insert(record) == 1;
    }
}
