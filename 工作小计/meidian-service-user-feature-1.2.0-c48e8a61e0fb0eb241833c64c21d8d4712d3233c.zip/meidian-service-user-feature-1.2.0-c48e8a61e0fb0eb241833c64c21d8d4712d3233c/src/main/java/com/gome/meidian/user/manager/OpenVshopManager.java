package com.gome.meidian.user.manager;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component("openVshopManager")
public class OpenVshopManager implements IOpenVshopManager {

    @Autowired
    private VshopInfoExternalFacade vshopInfoExternalFacade;

    @Autowired
    private VshopFacade vshopFacade;

    @Autowired
    private UserShareBindingManager userShareBindingManager;

    @Override
    public MapResults<Long> savaInitTaskShop(Long inviteUserId, Long userId) {
        MapResults<Long> rtnMapResult = null;
        log.info("用户id:{},邀请人id:{}", userId, inviteUserId);
        if (null == inviteUserId || inviteUserId == 0) {
            rtnMapResult = new MapResults<>(ExceptionCodeEnum.CHANGE_MID_EMPTY);
            return rtnMapResult;
        }
        if(null == userId || userId == 0){
            rtnMapResult = new MapResults<>(ExceptionCodeEnum.USERID_EMPTY);
            return rtnMapResult;
        }
        //判定登录人是否开店
        CommonResultEntity<VshopInfo> userShopInfo = vshopInfoExternalFacade.queryVshopInfoByUserId(userId);
        if (userShopInfo != null && userShopInfo.getCode() == 0) {
            VshopInfo vshopInfo = userShopInfo.getBusinessObj();
            if (vshopInfo != null && vshopInfo.getVshopId() != 0) {//已开通店铺
                log.info("当前用户已经开店，userId:{}", userId);
                rtnMapResult = new MapResults<>(ExceptionCodeEnum.INVATED_USER_ERROR);
                rtnMapResult.setBuessObj(new Long(vshopInfo.getVshopId()));
                return rtnMapResult;
            }
        }
        //邀请开店 - 邀请人是否开通店铺
        Long initVShopId = null;
        CommonResultEntity<VshopInfo> initUserShopInfo = vshopInfoExternalFacade.queryVshopInfoByUserId(inviteUserId);
        if (initUserShopInfo != null && initUserShopInfo.getCode() == 0) {
            VshopInfo vshopInfo = initUserShopInfo.getBusinessObj();
            if (vshopInfo == null || vshopInfo.getVshopId() == 0) {//未开通
                rtnMapResult = new MapResults<>(ExceptionCodeEnum.INVITE_USER_NOT_MATCH);
                return rtnMapResult;
            } else {
                initVShopId = vshopInfo.getVshopId();
            }
        }
        //记录邀请关系-创建店铺
        VshopInfo vshopInfo = new VshopInfo();
        vshopInfo.setVshopType(1);
        vshopInfo.setVshopBgimage("1");
        vshopInfo.setUserId(userId);
        StringBuilder vshopName = new StringBuilder(userId.toString()).append("的美店");
        vshopInfo.setVshopName(vshopName.toString());
        //创建店铺
        Long shopId = 0L;
        try {
            CommonResultEntity<String> commonResultEntity = vshopFacade.createVshop2(vshopInfo);
            if (commonResultEntity != null && commonResultEntity.getCode() == 0) {
                String shopIdStr = commonResultEntity.getBusinessObj();
                if (shopIdStr != null && !shopIdStr.equals("")) {
                    shopId = Long.valueOf(shopIdStr);
//                    this.saveVshopInvitationRelation(userId, shopId, inviteUserId, initVShopId);
                    synInvitateRelate(userId, shopId, inviteUserId);
                }
            } else {
                //创建店铺失败
                rtnMapResult = new MapResults<>(ExceptionCodeEnum.OPEN_VSHOP_ERROR);
                return rtnMapResult;
            }
        } catch (Exception e) {
            log.info("保存店铺信息失败,用户id:{},手机号:{}", userId, vshopInfo.getPhoneNo());
            rtnMapResult = new MapResults<>(ExceptionCodeEnum.OPEN_VSHOP_EXCEPTION);
            return rtnMapResult;
        }
        //返回美店信息
        CommonResultEntity<VshopInfo> vshopInfoBak = vshopFacade.queryVshopById(shopId);
        VshopInfo businessObj = vshopInfoBak.getBusinessObj();
        rtnMapResult = new MapResults<>(businessObj.getVshopId());
        return rtnMapResult;
    }

    /**
     * 同步邀请拉新数据
     *
     * @param userId
     * @param userMid
     * @param inviteUserId
     * @throws MeidianException
     */
    public void synInvitateRelate(long userId, long userMid, long inviteUserId) throws MeidianException {
        //同步邀请关系数据
        MshopShareRecordDto mshopShareRecord = new MshopShareRecordDto();
        mshopShareRecord.setUserId(userId);
        mshopShareRecord.setMid(userMid);
        mshopShareRecord.setUpuserId(inviteUserId);
        userShareBindingManager.changeVShop(mshopShareRecord);
    }
}