package com.gome.meidian.user.utils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;

/**
 * 公用工具类
 */
@Slf4j
public class CommonUtils {

    /**
     * String转int
     *
     * @param obj 对象
     * @param defaultVal 默认值
     * @return
     */
    public static Integer str2Int(String obj, Integer defaultVal) {
        return obj == null ? defaultVal : Integer.valueOf(obj);
    }

    /**
     * map转obj
     *
     * @param map       集合
     * @param beanClass 对象
     * @return
     */
    public static <T> T map2Obj(Map<String, String> map, Class<T> beanClass) {
        try {
            T obj = beanClass.newInstance();
            BeanUtils.populate(obj, map);
            return obj;
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException e) {
            throw new RuntimeException("CommonUtils.map2Obj 发生异常，异常堆栈如下", e);
        }
    }

    /**
     * bean转obj
     * @param obj bean
     * @return
     */
    public static Map<String, String> obj2Map(Object obj) {
        if (null == obj) {
            return null;
        }
        Map<String, String> map = new HashMap<>();
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(obj.getClass());
            PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
            for (PropertyDescriptor property : propertyDescriptors) {
                String key = property.getName();
                Method getter = property.getReadMethod();
                if (key.compareToIgnoreCase("class") == 0 || getter == null) {
                    //key 是class 或 没有get方法的不转换
                    continue;
                }
                Object invoke = getter.invoke(obj);
                if (invoke != null) {
                    map.put(key, JSON.toJSONString(invoke));
                }
            }
            return map;
        } catch (Exception e) {
            throw new RuntimeException("CommonUtils.obj2Map4Intros 发生异常，异常堆栈如下：", e);
        }
    }

    public static int getTotalPage(int pageSize,int totalCount) {
        //总页数
        int totalPage = totalCount / pageSize;
        if (totalCount == 0 || totalCount % pageSize != 0) {
            totalPage++;
        }
        return totalPage;
    }

}
