package com.gome.meidian.user.service.equities;

import com.gome.meidian.user.dto.LayerCmsConfigDto;

import java.util.List;
import java.util.Map;

public interface LayerCmsConfigService {

    public int deleteByPrimaryKey(Long id);

    public int insert(LayerCmsConfigDto record);

    public int insertSelective(LayerCmsConfigDto record);

    public LayerCmsConfigDto selectByPrimaryKey(Long id);

    public List<LayerCmsConfigDto> selectByParam(Map<String, Object> map);

    Long queryCountByParam(Map<String, Object> map);

    public int updateByPrimaryKeySelective(LayerCmsConfigDto record);

    public int updateByPrimaryKey(LayerCmsConfigDto record);

}
