package com.gome.meidian.user.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
/**
 * 读取dubbo配置文件
 *
 */
@Configuration
@ImportResource({"classpath*:dubbo/*.xml"})
public class DubboConfig {

}
