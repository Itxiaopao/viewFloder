package com.gome.meidian.user.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.UserAuthDto;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareRecord;

/**
 * @author chenchen-ds6
 * 用户绑定关系
 */
public interface MShopShareBindingService {
    /*通过userId查找绑定表*/
    MShopShareBindingDto queryShareBindingByUserId(Long userId);

    /**
     * 不定条件查询
     * @param mshopShareBinding
     * @return
     */
    MshopShareBinding queryByParam(MshopShareBinding mshopShareBinding);
    /**
     * 不定条件查询集合
     * @param mshopShareBinding
     * @return
     */
    List<MshopShareBinding> queryListByParam(MshopShareBinding mshopShareBinding);

    public Long queryCountByParam(MshopShareBinding mshopShareBinding);

    /**
     * 插入
     * @param mshopShareBinding
     * @return
     */
    int insertMShopShareBinding(MshopShareBinding mshopShareBinding);

    /**
     * 更新
     * @param mshopShareBinding
     * @return
     */
    int updateMshopShareBinding(MshopShareBinding mshopShareBinding);

    /**
     * 切换上级店主
     * @param mshopShareBinding
     * @return
     */
    int changeUpuser(MshopShareBinding mshopShareBinding);
    List<MshopShareBinding> queryMyNotVisitorCount(Long userId);

    MShopShareBindingDto queryShareBindingByUserIdAndUpUserid(Long aLong, Long myUserId);

    Integer queryMidCount(Long userId);

    Integer queryCustomerCount(Long userId);

    List<MShopShareBindingDto> queryMyShareBindingByType(Long userId, String type, Integer pageSize, Integer pageIndex);

    List<MshopShareBinding> queryInviteList(Long userId, Integer pageSize, Integer pageIndex);

    List<String> queryUserIdList(Long userId);

    Boolean checkAccessAuthority(Long userId, Long upUserId);

    /**
     * 新增一条绑定记录
     * @param mshopShareBinding
     * @return
     */
    Boolean createBindRelation(MshopShareBinding mshopShareBinding);
    
    MapResults bindingUserRelation(MshopShareRecord mshopShareRecord);

    MshopShareBinding getInvateShopInfo(Long pUserId) ;

    /**
     * 获取用户授权列表
     *
     * @param userIds
     * @return
     */
    List<UserAuthDto> getUserAuthList(Set<Long> userIds);

    /**
     * 通过userId查询库中条目数
     * @param userId
     * @return
     */
    Integer selectCountByUserId(Long userId);

    List<MShopShareBindingDto> queryListByParamWithMap(Map<String, Object> map);

    MShopShareBindingDto convert(MshopShareBinding model);
}
