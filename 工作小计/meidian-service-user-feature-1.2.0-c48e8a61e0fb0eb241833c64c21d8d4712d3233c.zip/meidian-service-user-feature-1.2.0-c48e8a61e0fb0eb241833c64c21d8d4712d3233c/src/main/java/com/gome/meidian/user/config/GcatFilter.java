package com.gome.meidian.user.config;

import com.gome.track.filter.TrackFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

@Order(1)//过滤顺序，值越小，越先执行
@WebFilter(filterName = "gcatFilter", urlPatterns = "/*")
public class GcatFilter extends TrackFilter{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		// cat处理
		super.doFilter(servletRequest, servletResponse, filterChain);
	}

}
