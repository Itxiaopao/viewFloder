package com.gome.meidian.user.enums;

/**
 * 员工类型枚举
 */
public enum EmployeeTypeEnum {

    //dql：电器员工，hlwl：互联网员工，gsl:公司员工
    dql("电器员工店主"),
    hlwl("互联网员工"),
    gsl("公司员工");

    private String desc;

    private EmployeeTypeEnum(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
