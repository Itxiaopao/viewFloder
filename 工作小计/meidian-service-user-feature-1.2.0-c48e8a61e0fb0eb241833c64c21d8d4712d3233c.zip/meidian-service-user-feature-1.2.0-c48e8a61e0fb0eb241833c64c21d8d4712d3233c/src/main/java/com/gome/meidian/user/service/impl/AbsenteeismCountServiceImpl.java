package com.gome.meidian.user.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.AbsenteeismCount;
import com.gome.meidian.user.mapper.AbsenteeismCountMapper;
import com.gome.meidian.user.service.AbsenteeismCountService;
import com.gome.meidian.user.service.AbstractService;

@Service
public class AbsenteeismCountServiceImpl extends AbstractService<AbsenteeismCount, Long> implements AbsenteeismCountService {
	@Autowired
	private AbsenteeismCountMapper absenteeismCountMapper;
	@Override
	public void setBaseMapper() {
		super.baseMapper = absenteeismCountMapper;
	}
	@Override
	public AbsenteeismCount findByUserId(String userId) {
		return absenteeismCountMapper.findByUserId(userId);
	}
	@Override
	public int insertAbsenteeismCount(AbsenteeismCount absenteeismCount) {
		return absenteeismCountMapper.add(absenteeismCount);
	}
	@Override
	public int updateCount(AbsenteeismCount absenteeismCount) {
		return absenteeismCountMapper.updateCount(absenteeismCount);
	}
	@Override
	public int updateAbsenteeismCount(AbsenteeismCount absenteeismCount) {
		return absenteeismCountMapper.update(absenteeismCount);
	}
	

}
