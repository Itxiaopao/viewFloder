package com.gome.meidian.user.mq.data;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class CommonData {

	 private Long userId;
	 private Long invertUserId;
	 private Long oldShopUserId;


}
