package com.gome.meidian.user.entity;

import java.io.Serializable;

public class MeidianVshopSummary implements Serializable {

    private static final long serialVersionUID = 7646514673380809036L;

    private Long userId;

    private Long shopNum;

    private Long customNum;

    public MeidianVshopSummary() {
    }

    public MeidianVshopSummary(Long userId, Long shopNum, Long customNum) {
        this.userId = userId;
        this.shopNum = shopNum;
        this.customNum = customNum;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getShopNum() {
        return shopNum == null ? 0L : shopNum;
    }

    public void setShopNum(Long shopNum) {
        this.shopNum = shopNum;
    }

    public Long getCustomNum() {
        return customNum == null ? 0L : customNum;
    }

    public void setCustomNum(Long customNum) {
        this.customNum = customNum;
    }
}
