package com.gome.meidian.user.mq.data;

import lombok.Data;
import lombok.ToString;

import java.util.Date;

@ToString
@Data
public class MQData {
	
	public MQData()
	{
		timestamp=new Date().getTime();
	}

	private Long userId;
	
    private Long timestamp;
}
