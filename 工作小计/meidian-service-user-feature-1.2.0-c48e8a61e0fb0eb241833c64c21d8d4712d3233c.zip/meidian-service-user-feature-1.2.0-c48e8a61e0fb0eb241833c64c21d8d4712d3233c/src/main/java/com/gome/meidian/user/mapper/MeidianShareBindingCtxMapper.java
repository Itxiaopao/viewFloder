package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MeidianShareBindingCtx;

public interface MeidianShareBindingCtxMapper {

    int insertSelective(MeidianShareBindingCtx record);

    MeidianShareBindingCtx selectByPrimaryKey(Long id);

}