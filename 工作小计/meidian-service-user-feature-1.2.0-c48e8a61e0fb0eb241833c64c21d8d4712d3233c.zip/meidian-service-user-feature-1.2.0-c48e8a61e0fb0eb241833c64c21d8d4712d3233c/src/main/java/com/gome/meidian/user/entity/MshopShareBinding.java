package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author chenchen-ds6
 * 美店主绑定管理entity
 */
@Getter
@Setter
@ToString
public class MshopShareBinding implements Serializable {
    private static final long serialVersionUID = 6227977189864267708L;

    private Long id;//主键id
    private Long mid;//美店id
    private Long userId;//用户userId
    private String uniqueId;//用户uniqueId
    private Long upmid;//上级美店id
    private Long upuserId;//上线userId
    private String upuniqueId;//上级uniqueId
    private Long puserId;//邀请人用户Id
    private Long pmid;//邀请人美店id
    private String puniqueId;//邀请人uniqueId
    private Date insertTime;//创建时间
    private Date updateTime;//更新时间
    private String businessCode1;
    private String businessCode2;
    private Long topLeaderMid;//片总美店id
    private Long topLeaderUserId;//片总userId
    private Integer type;//1.新客，4首单 5忠粉
    private Integer count;//新客，首单，忠粉的数量
    private String shareChain;//关系链
    private Integer authorization;//授权
    private Integer version;//版本
    private Integer identity;//身份  0 用户  1店主

}
