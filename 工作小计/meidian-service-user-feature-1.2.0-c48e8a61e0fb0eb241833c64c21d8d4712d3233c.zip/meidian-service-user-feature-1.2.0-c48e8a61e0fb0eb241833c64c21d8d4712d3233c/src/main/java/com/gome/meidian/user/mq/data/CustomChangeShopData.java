package com.gome.meidian.user.mq.data;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString
public class CustomChangeShopData  extends MQData{
	
    private Long targetUserId;
    
    private Long sourceUserId;


}


