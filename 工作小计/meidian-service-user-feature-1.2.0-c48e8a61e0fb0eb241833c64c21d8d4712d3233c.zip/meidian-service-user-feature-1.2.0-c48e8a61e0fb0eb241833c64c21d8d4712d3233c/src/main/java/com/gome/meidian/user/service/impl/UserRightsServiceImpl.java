package com.gome.meidian.user.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;
import com.gome.meidian.user.dto.UserRightsDto;
import com.gome.meidian.user.entity.UserRights;
import com.gome.meidian.user.enums.UserRightsOperateEnum;
import com.gome.meidian.user.enums.UserRightsSceneEnum;
import com.gome.meidian.user.mapper.UserRightsMapper;
import com.gome.meidian.user.mapper.UserRightsRecordMapper;
import com.gome.meidian.user.service.UserRightsAsyncService;
import com.gome.meidian.user.service.UserRightsService;
import com.gome.meidian.user.service.equities.BasicEquitiesNumberService;
import com.gome.meidian.user.utils.CommonUtils;
import com.gome.meidian.user.utils.RedisKeyUtils;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.exceptions.BizException;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;

import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

@Slf4j
@Service("userRightsService")
public class UserRightsServiceImpl implements UserRightsService {

    /**
     * 缓存
     */
    @Autowired
    private Gcache gcache;
    /**
     * 店主服务
     */
    @Autowired
    private VshopFacade vshopFacade;
    /**
     * 用户权益orm
     */
    @Autowired
    private UserRightsMapper userRightsMapper;
    /**
     * 用户权益线程池处理
     */
    @Autowired
    private UserRightsAsyncService userRightsAsyncService;
    /**
     * 用户权益基础配置
     */
    @Autowired
    private BasicEquitiesNumberService basicEquitiesNumberService;
    /**
     * 用户权益履历
     */
    @Autowired
    private UserRightsRecordMapper userRightsRecordMapper;
    /**
     * 单线程处理条数
     */
    private static final Integer EACH_THREAD_PAGE_NUM = 1000;

    @Override
    public Boolean saveRewards(Long userId, Integer type, Integer rewardOpenCount, Integer rewardJoinCount, Integer scene) {
        //查询是否存在用户
        UserRights userRights = this.getUserRights(userId, type);
        int count; //成功条数
        String redisKey = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_HASH_PREFIX, userId, type);
        UserRights model = new UserRights();//用户权益entity
        model.setUserId(userId);//用户id
        model.setType(type);//活动类型
        if (userRights == null) {
            //新增
            model.setRewardOpenCount(rewardOpenCount);
            model.setRewardJoinCount(rewardJoinCount);
            count = userRightsMapper.save(model);
            //维护缓存
            Map<String, String> map = CommonUtils.obj2Map(model);
            gcache.hmset(redisKey, map);
            gcache.sadd(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type, redisKey);
        } else {
            //更新
            Integer dbRewardOpenCount = ObjectUtils.defaultIfNull(userRights.getRewardOpenCount(), 0);
            Integer dbRewardJoinCount = ObjectUtils.defaultIfNull(userRights.getRewardJoinCount(), 0);
            model.setRewardOpenCount(dbRewardOpenCount + rewardOpenCount);
            model.setRewardJoinCount(dbRewardJoinCount + rewardJoinCount);
            count = userRightsMapper.update(model);
            gcache.hincrBy(redisKey, "rewardOpenCount", rewardOpenCount);
            gcache.hincrBy(redisKey, "rewardJoinCount", rewardJoinCount);
        }
        //异步保存用户履历
        userRightsAsyncService.insertRewardRecord(userId, type, rewardOpenCount, rewardJoinCount, scene, userRights);
        return count > 0;
    }

    @Override
    public Boolean consumeRights(Long userId, Integer type, Integer scene, Integer operate, String txId) {
        //查询是否存在用户信息
        UserRightsDto dto = this.getUserRightsActivitieCount(userId, type);
        if (UserRightsSceneEnum.openGroup.getScene().equals(scene) && dto.getSurplusOpenCount() <= 0) {
            throw new BizException(400, "该用户已没有剩余的开团次数");
        } else if (UserRightsSceneEnum.joinGroup.getScene().equals(scene) && dto.getSurplusJoinCount() <= 0) {
            throw new BizException(400, "该用户已没有剩余的参团次数");
        }
        int count;
        UserRights model = new UserRights();
        model.setUserId(userId);
        model.setType(type);
        String redisKey = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_HASH_PREFIX, userId, type);
        if (dto.getExistUser()) {
            //更新
            int value = UserRightsOperateEnum.incr.getCode().equals(operate) ? 1 : -1;
            if (UserRightsSceneEnum.openGroup.getScene().equals(scene)) {
                model.setAlreadyOpenCount(dto.getAlreadyOpenCount() + value);
                gcache.hincrBy(redisKey, "alreadyOpenCount", value);
                if (dto.getBasicOpenCount() < model.getAlreadyOpenCount()) {
                    //系统赠送的次数已用光,扣除赠送开团次数
                    model.setRewardOpenCount(dto.getRewardOpenCount() - value);
                    gcache.hincrBy(redisKey, "rewardOpenCount", -value);
                }
            } else if (UserRightsSceneEnum.joinGroup.getScene().equals(scene)) {
                model.setAlreadyJoinCount(dto.getAlreadyJoinCount() + value);
                gcache.hincrBy(redisKey, "alreadyJoinCount", value);
                if (dto.getBasicJoinCount() < model.getAlreadyJoinCount()) {
                    //系统赠送的次数已用光,扣除赠送参团次数
                    model.setRewardJoinCount(dto.getRewardJoinCount() - value);
                    gcache.hincrBy(redisKey, "rewardJoinCount", -value);
                }
            }
            count = userRightsMapper.update(model);
        } else {
            //新增
            if (UserRightsSceneEnum.openGroup.getScene().equals(scene)) {
                model.setAlreadyOpenCount(1);
            } else if (UserRightsSceneEnum.joinGroup.getScene().equals(scene)) {
                model.setAlreadyJoinCount(1);
            }
            count = userRightsMapper.save(model);
            Map<String, String> map = CommonUtils.obj2Map(model);
            gcache.hmset(redisKey, map);
            gcache.sadd(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type, redisKey);
        }
        //异步保存用户履历
        userRightsAsyncService.insertConsumeRecord(dto, scene, operate, txId);
        return count > 0;
    }

    @Override
    public UserRights getUserRights(Long userId, Integer type) {
        //用户权益缓存key
        String redisKey = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_HASH_PREFIX, userId, type);
        Map<String, String> val = gcache.hgetAll(redisKey);
        if (MapUtils.isNotEmpty(val)) {
            //优先缓存
            Boolean redisKeyIsInSet = gcache.sismember(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type, redisKey);
            if (!redisKeyIsInSet) {
                //缓存重置逻辑
                Map<String, String> map = new HashMap<>(2);
                map.put("alreadyOpenCount", "0");
                map.put("alreadyJoinCount", "0");
                gcache.hmset(redisKey, map);
                gcache.sadd(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type, redisKey);
                val.put("alreadyOpenCount", "0");
                val.put("alreadyJoinCount", "0");
            }
            return CommonUtils.map2Obj(val, UserRights.class);
        }
        //db
        UserRights userRights = userRightsMapper.selectByBiz(userId, type);
        if (userRights != null) {
            //加入缓存
            Map<String, String> map = CommonUtils.obj2Map(userRights);
            gcache.hmset(redisKey, map);
            //集中管理缓存key
            gcache.sadd(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type, redisKey);
        }
        return userRights;
    }

    @Override
    public UserRightsDto getUserRightsActivitieCount(Long userId, Integer type) {
        //获取用户身份
        Integer userIdentity = getUserIdentity(userId);
        //获取用户权益基础配置
        UserBasicEquitiesNumberDto basic = basicEquitiesNumberService.queryByType(userIdentity);
        //获取用户权益信息
        UserRights userRights = this.getUserRights(userId, type);
        //用户权益出参传输对象
        UserRightsDto dto = new UserRightsDto();
        dto.setUserId(userId);
        dto.setType(type);
        dto.setBasicOpenCount(basic.getTotalOpenCount());
        dto.setBasicJoinCount(basic.getTotalJoinCount());
        if (userRights == null) {
            dto.setRewardOpenCount(0);
            dto.setRewardJoinCount(0);
            dto.setAlreadyOpenCount(0);
            dto.setAlreadyJoinCount(0);
            dto.setSurplusOpenCount(basic.getTotalOpenCount());
            dto.setSurplusJoinCount(basic.getTotalJoinCount());
            dto.setExistUser(Boolean.FALSE);
        } else {
            Integer rewardOpenCount = ObjectUtils.defaultIfNull(userRights.getRewardOpenCount(), 0);
            Integer rewardJoinCount = ObjectUtils.defaultIfNull(userRights.getRewardJoinCount(), 0);
            Integer alreadyOpenCount = ObjectUtils.defaultIfNull(userRights.getAlreadyOpenCount(), 0);
            Integer alreadyJoinCount = ObjectUtils.defaultIfNull(userRights.getAlreadyJoinCount(), 0);
            dto.setRewardOpenCount(rewardOpenCount);
            dto.setRewardJoinCount(rewardJoinCount);
            dto.setAlreadyOpenCount(alreadyOpenCount);
            dto.setAlreadyJoinCount(alreadyJoinCount);
            /**
             * 剩余开参团次数逻辑：
             * 总的开团次数 - 已开团次数
             * 如果出现负数或等于0 奖励开团次数就是剩余开团次数
             * 如果未出现负数，则 基础开团次数+剩余开团次数就是剩余开团次数
             */
            Integer openCount = basic.getTotalOpenCount() - alreadyOpenCount;
            dto.setSurplusOpenCount(openCount <= 0 ? (rewardOpenCount < 0 ? 0 : rewardOpenCount) : (openCount + rewardOpenCount));
            Integer joinCount = basic.getTotalJoinCount() - alreadyJoinCount;
            dto.setSurplusJoinCount(joinCount <= 0 ? (rewardJoinCount < 0 ? 0 : rewardJoinCount) : (joinCount + rewardJoinCount));
            dto.setExistUser(Boolean.TRUE);
        }
        return dto;
    }

    @Override
    public Boolean resetExercisePower(Integer type) {
        UserRights userRights = new UserRights();
        userRights.setType(type);
        userRights.setAlreadyOpenCount(0);
        userRights.setAlreadyJoinCount(0);
        try {
            //删除缓存
            gcache.del(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type);
            userRightsMapper.update(userRights);
            return Boolean.TRUE;
        } catch (Exception e) {
            return Boolean.FALSE;
        }
    }

    @Override
    public Integer getUserRightsCount(Integer type) {
        return userRightsMapper.selectCountByBiz(type);
    }

    @Override
    public Boolean synUserRightsCache(Integer type, Integer pageNo, Integer pageSize) {
        PageParam pageParam = new PageParam(pageNo, pageSize);
        try {
            List<UserRights> UserRightsList = userRightsMapper.selectPageByBiz(pageParam, type);
            if (CollectionUtils.isEmpty(UserRightsList)) {
                return Boolean.TRUE;
            }
            int totalPageNum = (UserRightsList.size() + EACH_THREAD_PAGE_NUM - 1) / EACH_THREAD_PAGE_NUM;
            final CountDownLatch downLatch = new CountDownLatch(totalPageNum);
            for (int i = 1; i <= totalPageNum; i++) {
                int startNo = (i - 1) * EACH_THREAD_PAGE_NUM;
                int endNo = i * EACH_THREAD_PAGE_NUM;
                List<UserRights> subList = UserRightsList.subList(startNo, endNo > UserRightsList.size() ? UserRightsList.size() : endNo);
                userRightsAsyncService.synUserRightsCache(subList, downLatch);
            }
            downLatch.await();
            return Boolean.TRUE;
        } catch (Exception e) {
            log.error("UserRightsServiceImpl.synUserRightsCache 发生异常,异常堆栈如下", e);
            return Boolean.FALSE;
        }
    }

    @Override
    public Boolean clear(Long userId, Integer type) {
        try {
            String redisKey = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_HASH_PREFIX, userId, type);
            gcache.srem(CacheConstant.USER_RIGHTS_CACHE_MGT_SET_PREFIX + type, redisKey);
            gcache.del(redisKey);
            userRightsMapper.delete(userId, type);
            userRightsRecordMapper.delete(userId, type);
            return Boolean.TRUE;
        } catch (Exception e) {
            log.error("UserRightsServiceImpl.clear 发生异常,异常堆栈如下", e);
            return Boolean.FALSE;
        }
    }

    /**
     * 获取用户身份
     *
     * @param userId 用户id
     * @return
     */
    private Integer getUserIdentity(Long userId) {
        try {
            //获取用户身份
            CommonResultEntity<VshopInfo> vshopInfoResult = vshopFacade.queryVshopByuserId(String.valueOf(userId));
            if (vshopInfoResult == null || vshopInfoResult.getBusinessObj() == null) {
                //查不到用户，默认普通用户
                return 0;
            }
            Integer vshopIdentity = vshopInfoResult.getBusinessObj().getVshopIdentity();
            return ObjectUtils.defaultIfNull(vshopIdentity, 1);
        } catch (Exception e) {
            log.error("UserRightsServiceImpl.getUserIdentity,获取用户身份发生异常,异常堆栈如下：", e);
            throw new BizException(500, "系统繁忙,请稍后重试");
        }
    }

}
