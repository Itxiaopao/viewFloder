package com.gome.meidian.user.service;

import com.gome.meidian.user.dto.UserRightsDto;
import com.gome.meidian.user.entity.UserRights;

public interface UserRightsService {

    /**
     * 保存奖励
     *
     * @param userId          用户id
     * @param type            活动类型 1.瓜分团
     * @param rewardOpenCount 奖励开团次数
     * @param rewardJoinCount 奖励参团次数
     * @param scene           场景描述 3.系统奖励(权益系统),4.任务奖励（任务系统）
     * @return
     */
    Boolean saveRewards(Long userId, Integer type, Integer rewardOpenCount, Integer rewardJoinCount, Integer scene);


    /**
     * 消费权益
     *
     * @param userId  用户id
     * @param type    活动类型 1.瓜分团
     * @param scene   场景 1.开团,2.参团
     * @param operate 操作 1.自增，2.自减
     * @return
     */
    Boolean consumeRights(Long userId, Integer type, Integer scene, Integer operate, String txId);

    /**
     * 获取用户权益
     *
     * @param userId 用户id
     * @param type   活动类型 1.瓜分团
     * @return
     */
    UserRights getUserRights(Long userId, Integer type);

    /**
     * 获取用户权益活动次数
     *
     * @param userId 用户id
     * @param type   1.瓜分团
     * @return
     */
    UserRightsDto getUserRightsActivitieCount(Long userId, Integer type);

    /**
     * 重置用户行使权益
     *
     * @param type 活动类型 1.瓜分团
     * @return
     */
    Boolean resetExercisePower(Integer type);

    /**
     * 根据活动类型获取用户权益总数
     *
     * @param type 活动类型 1.瓜分团
     * @return
     */
    Integer getUserRightsCount(Integer type);

    /**
     * 同步用户权益缓存（异步调用）
     *
     * @param type     活动类型 1.瓜分团
     * @param pageNo   页码
     * @param pageSize 页面大小
     * @return
     */
    Boolean synUserRightsCache(Integer type, Integer pageNo, Integer pageSize);

    /**
     *
     * @param userId 用户id
     * @param type 活动类型 1.瓜分团
     * @return
     */
    Boolean clear(Long userId, Integer type);

}
