package com.gome.meidian.user.utils;

import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.Callable;

public class PushAuthorizationThread implements Callable {
    private static Logger logger = LoggerFactory.getLogger(PushAuthorizationThread.class);
    private Long userId;
    private Integer authorization;
    IGomeShopWeChatFacade gomeShopWeChatFacade;
    public PushAuthorizationThread(Long reqUserId,Integer authorization,IGomeShopWeChatFacade reqGomeShopWeChatFacade){
        this.userId = reqUserId;
        this.authorization = authorization;
        this.gomeShopWeChatFacade = reqGomeShopWeChatFacade;
    }

    @Override
    public Object call() throws Exception {
        logger.info("推员工授权信息到会员，保持与会员的授权状态同步，requestParam:{}",userId);
        try {
            UserResult<Boolean> gomeShop = gomeShopWeChatFacade.updatePrivacyAuth(userId.toString(), authorization.toString(), "gomeShop");
            logger.info("调用会员返回值，result:{}",gomeShop.isSuccess());
        }catch (Exception e){
            e.printStackTrace();
            logger.error("推送用户授权信息到会员出现异常");
        }
        return null;
    }
}
