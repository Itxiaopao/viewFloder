package com.gome.meidian.user.enums;

/**
 * 用户渠道枚举
 */
public enum UserChannelEnum {

    meidian("meidian","美店"),
    shangcheng("shangcheng","商城"),
    laigou("laigou","来购"),
    guanjia("guanjia","管家"),
    jinli("jinli","金力"),
    zongheti("zongheti","综合体"),
    dazhong("dazhong","大中"),
    jinrong("jinrong","金融"),
    bangbang("bangbang","小美帮帮"),
    GJSF("GJSF","管家师傅"),
    WLSF("WLSF","物流师傅"),
    ;

    private String code;

    private String desc;

    public static UserChannelEnum valueOfByCode(String code) {
        if (code == null) {
            return null;
        }
        for (UserChannelEnum enu : UserChannelEnum.values()) {
            if (enu.getCode().equals(code)) {
                return enu;
            }
        }
        return null;
    }

    private UserChannelEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
