package com.gome.meidian.user.service.impl;

import com.gome.meidian.user.entity.MShopShareMessage;
import com.gome.meidian.user.mapper.MShopShareMessageMapper;
import com.gome.meidian.user.service.MShopShareMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MShopShareMessageServiceImpl implements MShopShareMessageService {
    @Autowired
    MShopShareMessageMapper mShopShareMessageMapper;
    @Override
    public int insertMShopMessage(MShopShareMessage mShopShareMessage) {
        return mShopShareMessageMapper.insertMShopMessage(mShopShareMessage);
    }
}
