package com.gome.meidian.user.manager;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.UserRole;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.UserRoleService;


@Component
public class UserRoleManager implements IUserRoleManager {
	private static Logger logger = LoggerFactory.getLogger(UserRoleManager.class);
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 根据userID获取用户角色
	 * @param userId
	 * @return
	 */
	@Override
	public MapResults<List<UserRole>> getRolesByUserId(String userId) {
		MapResults<List<UserRole>> result = null;
		if(StringUtils.isBlank(userId)) {
			logger.error("获取用户角色失败，参数userId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			List<UserRole> roles = userRoleService.findByUserId(userId);
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			result.setBuessObj(roles);
		}catch(Exception e) {
			logger.error("获取用户角色异常，userId:{}, message:{}", userId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 添加用户角色关系
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	@Override
	public MapResults<Object> addUserRole(String userId, String roleId) {
		MapResults<Object> result = null;
		if(StringUtils.isBlank(userId) || StringUtils.isBlank(roleId)) {
			logger.error("添加用户角色关系失败，参数userId或roleId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		
		try {
			List<UserRole> roles = userRoleService.findByUserId(userId);
			for(UserRole role: roles) {
				if(role.getRoleId().toString().equals(roleId)) {
					logger.info("添加用户角色关系，userId:{}，roleId:{}已存在", userId, roleId);
					return result;
				}
			}
			UserRole r = new UserRole();
			r.setUserId(userId);
			r.setRoleId(Short.valueOf(roleId));
			Date t = new Date();
			r.setCtime(t);
			r.setUtime(t);
			userRoleService.add(r);

			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			result.setBuessObj(r);
		}catch(Exception e) {
			logger.error("添加用户角色关系异常，userId:{}，roleId:{}，message:{}", userId, roleId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}

		return result;
	}
	
	/**
	 * 修改用户角色关系
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	@Override
	public MapResults<Object> modifyUserRole(String userId, Long userRoleId, String roleId) {
		MapResults<Object> result = null;
		if(StringUtils.isBlank(userId) || StringUtils.isBlank(roleId)) {
			logger.error("修改用户角色关系失败，参数userId、userRoleId或roleId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			userRoleService.deleteById(userRoleId);
			result = this.addUserRole(userId, roleId);
		}catch(Exception e) {
			logger.error("修改用户角色关系异常，userId:{}，userRoleId:{}，roleId:{}，message", userId, userRoleId, roleId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	/**
	 * 普通用户提升为美店主
	 * @param userId
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	@Override
	public void modifyMDUserRole(String userId) {
		MapResults<List<UserRole>> roles = this.getRolesByUserId(userId);
		if(roles != null) {
			Long roleId = null;
			for(UserRole role: roles.getBuessObj()) {
				if(role.getRoleId() == 2) {
					logger.info("普通用户提升为美店主，userId:{}已经是美店主", userId);
					return;
				}
				if(role.getRoleId() == 1) {
					roleId = role.getId();
					break;
				}
			}
			this.modifyUserRole(userId, roleId, "2");
		}
	}
}
