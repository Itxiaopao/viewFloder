package com.gome.meidian.user.dto;

import java.io.Serializable;

import com.gome.meidian.user.exception.ExceptionCodeEnum;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MapResults<T> implements Serializable {

    private static final long serialVersionUID = 6608195587158797908L;
    private int code;//0-成功，-1 异常，1-参数错误
    private String message;//错误信息
    private Boolean success;//是否成功
    private T buessObj;

    public MapResults() {
        this.code = 0;
        this.message = ExceptionCodeEnum.SUCCESS.getErrorMessage();
        this.success = Boolean.TRUE;
    }

    public MapResults(T buessObj) {
        this.code = 0;
        this.message = ExceptionCodeEnum.SUCCESS.getErrorMessage();
        this.buessObj = buessObj;
        this.success = Boolean.TRUE;
    }

    public MapResults(ExceptionCodeEnum exceptionCode) {
        this.code = exceptionCode.getErrorCode();
        this.message = exceptionCode.getErrorMessage();
        this.success = Boolean.FALSE;
    }

    public MapResults(int code, String message) {
        this.code = code;
        this.message = message;
        this.success = Boolean.TRUE;
    }

}
