package com.gome.meidian.user.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.dto.MeidianBindingRelationDto;

/**
 * @author chenchen56
 *
 */
public interface MeidianBindingRelationMapper {
    /**
     * 插入绑定关系
     * @param meidianBindingRelation
     * @return
     */
    int addBindingRelation(MeidianBindingRelationDto meidianBindingRelation);

    /**
     * 查询绑定关系
     * @param userId
     * @return
     */
    MeidianBindingRelationDto queryBindingRelationByUserId(@Param("userId")Long userId);

    /**
     * 更改用户状态
     * @param userId
     * @param status
     */
    int updateRelationStatus(@Param("userId")Long userId, @Param("status")Integer status);

    MeidianBindingRelationDto selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(MeidianBindingRelationDto record);

    List<MeidianBindingRelationDto> getListByParam(Map<String, Object> param);

    List<MeidianBindingRelationDto> getCountByStatus(Map<String, Object> param);

    List<MeidianBindingRelationDto> getCountByPuserId(Map<String, Object> param);
}
