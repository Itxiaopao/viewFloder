package com.gome.meidian.user.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.MshopShareRecord;

/**
 * @author limenghui-ds
 * @create 2019-06-10 16:07
 */
public interface MShopShareRecordMapper {

    Integer queryMyVisitorCount(@Param("userId")Long userId, @Param("type")Integer type) ;


    /**
     * 不定条件查询分享链
     * @param mshopShareRecord
     * @return
     */
    MshopShareRecord queryByParam(MshopShareRecord mshopShareRecord);

    /**
     * 通过unqiue和puserId来查询
     * @param mshopShareRecord
     * @return
     */
    MshopShareRecord queryByUniqueIdAndPuserId(MshopShareRecord mshopShareRecord);
    /**
     * 插入分享链
     * @param mshopShareRecord
     * @return
     */
    int insertMShopShareRecord(MshopShareRecord mshopShareRecord);
    /**
     * 修改分享链
     * @param mshopShareRecord
     * @return
     */
    int updateMShopShareRecord(MshopShareRecord mshopShareRecord);
    
    ///修改状态
    int updateMShopShareRecordType(@Param("type") Integer type,@Param("userId")Long userId);

    /**
     * 返回游客指定游客的List
     * @param mshopShareRecord
     * @return
     */
    List<MshopShareRecord> queryListByParam(MshopShareRecord mshopShareRecord);

    /**
     * 通过uniqueId或者userId查询
     * @param mshopShareRecord
     * @return
     */
    List<MshopShareRecord> queryByUniqueIdOrUserId(MshopShareRecord mshopShareRecord);

    /**
     * 通过puniqueId和uniqueId去查询是否存在（规避游客状态下的重复分享）
     * @param mshopShareRecord
     * @return
     */
    MshopShareRecord queryByUniqueIdAndPuniqueId(MshopShareRecord mshopShareRecord);

    /**
     * 通过upUserId查找uniqueid
     * @param upUserId
     * @return
     */
    List<String> queryUniqueIdListByUpUserId(@Param("upUserId") Long upUserId);

    /**
     * 重复点击分享  更新分享链记录操作（通过id查询修改）
     * @param mshopShareRecord
     */
    int updateMShopShareRecordById(MshopShareRecord mshopShareRecord);

    /**
     * 根据筛选条件获取数量
     * @param mshopShareRecord
     * @return
     */
    int queryCountByBiz(MshopShareRecord mshopShareRecord);
}
