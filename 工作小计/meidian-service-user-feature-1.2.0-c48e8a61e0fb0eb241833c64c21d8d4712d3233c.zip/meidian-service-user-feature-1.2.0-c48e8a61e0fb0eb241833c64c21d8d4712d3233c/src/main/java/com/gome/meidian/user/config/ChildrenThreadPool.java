package com.gome.meidian.user.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Configuration
@EnableAsync
public class ChildrenThreadPool {
    private static Logger logger = LoggerFactory.getLogger(ChildrenThreadPool.class);
    @Value("${threadpool.core-pool-size}")
    private int corePoolSize;

    @Value("${threadpool.max-pool-size}")
    private int maximumPoolSize;

    @Value("${threadpool.keep-alive-seconds}")
    private int keepAliveTime;

    @Value("${threadpool.queue-size}")
    private int queueSize;

    @Bean(name="threadPoolExecutor")
    public ThreadPoolExecutor threadPoolTaskExecutor(){
        LinkedBlockingQueue arrayBlockingQueue = new LinkedBlockingQueue(queueSize);
        ThreadPoolExecutor pool = new ThreadPoolExecutor(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.SECONDS, arrayBlockingQueue, new RejectedExecutionHandler() {
            @Override
            public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
                try {
                    executor.getQueue().put(r);
                    logger.info("线程池拒绝执行，param:{}", r);
                }catch (Exception e){
                    e.printStackTrace();
                    logger.error("线程池异常，Exception:{}",e.getMessage());
                }
            }
        });
        return pool;
    }

}
