package com.gome.meidian.user.reponse;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 通用异常状态码
 */
public enum StatusCode {
	// TODO 待完善，需要和前端协商
	SUCCESS(0, "OK"),
	// 非法操作
	ILLEGAL_OPERATION(10001, "illegal operation"),
	// 系统错误，所有为止错误均返回此状态码
	SYSTEM_ERROR(10500, "System error"),
	// request not found
	NOT_FOUND(10404, "Not found"),
	// 校验字段信息错误
	VALIDATION_FAILED(10999,"Volidate failed"),
	/*********************************/

	// 参数类型匹配错误
	TYPE_MISMATH(11001, "Parameter type mismath:[%s]"),
	// 缺少必要参数
	MISSING_REQUEST_PARAMETER(11002, "Missing request parameter:[%s]"),
	// 参考HttpMessageNotReadableException 请求错误
	HTTP_MESSAGE_NOT_READABLE(11003, "Check parameter");


	/**
	 * 错误代码
	 */
	private int code;
	/**
	 * 简短描述
	 */
	private String msg;

	private StatusCode(int code, String msg) {

		this.code = code;
		this.msg = msg;
	}

	public int getCode() {
		return this.code;
	}

	public String getMsg() {
		return this.msg;
	}

}
