package com.gome.meidian.user.entity;

import com.vdurmont.emoji.EmojiParser;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * @author chenchen-ds6
 * 用户信息entity
 */
@Getter
@Setter
@ToString
public class MshopWechatUserInfo implements Serializable {
    private static final long serialVersionUID = 2974143875310425821L;
    private Long id;
    /**
     * 微信uniqueId
     */
    private String uniqueId;
    /**
     * 用户手机号码
     */
    private Long phoneMobile;
    private Long userId;
    /**
     * 用户mid
     */
    private Long mid;
    /**
     * 用户头像
     */
    private String image;
    /**
     * 原始头像链接
     */
    private String originalImage;
    /**
     * 用户昵称
     */
    private String nickname;
    private Date insertTime;
    private Date updateTime;
    /**
     * 微信号码
     */
    private String wechatNum;
    /**
     * 二维码
     */
    private String qrCode;
    /**
     * 版本
     */
    private Integer version;
    /**
     * type 默认0 绑定中的用户userId
     */
    private Integer type;
    /**
     * 最近浏览时间，记录表中的更改时间
     */
    private String browsLatestDate;
    public String getNickname(){
        if(nickname!=null) {
            return EmojiParser.parseToUnicode(nickname);
        }
        return nickname;
    }
}
