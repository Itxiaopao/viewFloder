package com.gome.meidian.user.service;

import java.util.Date;
import java.util.List;

import com.gome.meidian.user.entity.MeidianUserMessage;

public interface UserMessageService {
	
	/**
	 * 保存消息属性
	 * @param meidianUserMessage
	 * @return
	 */
	int insert(MeidianUserMessage meidianUserMessage);
	
	/**
	 * 更新消息属性
	 * @param meidianUserMessage
	 * @return
	 */
	int updateById(MeidianUserMessage meidianUserMessage);
	
	/**
	 * 查询消息属性
	 * @param userId
	 * @param formId
	 * @return
	 */
	MeidianUserMessage findOneByUserIdFormId(Long userId, String formId);
	
	/**
	 * 查询消息属性
	 * @param userId
	 * @param formType
	 * @param status
	 * @return
	 */
	List<MeidianUserMessage> findByUserIdFormTypeStatus(Long userId,Long orderId,Integer formType,Integer status,Date nowDate);
	
}
