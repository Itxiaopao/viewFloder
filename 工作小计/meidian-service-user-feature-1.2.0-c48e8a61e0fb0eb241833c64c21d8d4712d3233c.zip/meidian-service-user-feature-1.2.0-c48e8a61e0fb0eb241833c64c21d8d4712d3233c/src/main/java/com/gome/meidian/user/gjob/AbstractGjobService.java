package com.gome.meidian.user.gjob;

import com.gome.meidian.user.dto.MapResults;

/**
 * gjob定时执行任务的抽象父类。
 *
 * @author hushengdong
 * @create 2019-10-21 14:45:00
 */
public abstract class AbstractGjobService {

    /**
     * 如果是简单的gjob任务，只需要继承这个类，然后在gjob平台以GLUE模式(Java)开发即可。
     * @param param
     * @return
     */
    public abstract MapResults<String> execute(String param);
}
