package com.gome.meidian.user.enums;

/**
 * 用户身份枚举
 */
public enum UserIdentityEnum {

    custom(0, "用户"),
    shopkeeper(1, "店主"),
    shopowner(2, "店总"),
    topLeaderUser(3, "片总");

    private Integer code;

    private String desc;

    private UserIdentityEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
