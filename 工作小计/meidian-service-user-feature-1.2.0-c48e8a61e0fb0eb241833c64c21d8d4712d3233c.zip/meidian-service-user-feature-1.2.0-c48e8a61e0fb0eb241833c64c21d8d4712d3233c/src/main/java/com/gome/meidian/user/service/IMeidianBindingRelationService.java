package com.gome.meidian.user.service;

import java.util.List;
import java.util.Map;

import com.gome.meidian.user.dto.MeidianBindingRelationDto;

public interface IMeidianBindingRelationService {
    public List<MeidianBindingRelationDto> getListByParam(Map<String, Object> param);

    List<MeidianBindingRelationDto> getCountByStatus(Map<String, Object> param);

    MeidianBindingRelationDto queryBindingRelationByUserId(Long userId);

    int addBindingRelation(MeidianBindingRelationDto meidianBindingRelationDto);

    int updateRelationStatus(Long userId, Integer status);

    List<MeidianBindingRelationDto> getCountByPuserId(Map<String, Object> param);
}
