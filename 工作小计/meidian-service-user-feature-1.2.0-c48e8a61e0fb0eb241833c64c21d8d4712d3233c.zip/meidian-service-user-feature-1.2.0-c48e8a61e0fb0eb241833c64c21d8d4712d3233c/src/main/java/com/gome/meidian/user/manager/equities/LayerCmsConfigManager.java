package com.gome.meidian.user.manager.equities;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.gome.meidian.user.dto.LayerCmsConfigDto;
import com.gome.meidian.user.manager.ILayerCmsConfigManager;
import com.gome.meidian.user.service.equities.LayerCmsConfigService;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author limenghui-ds
 * @create 2019-07-22 20:45
 */
@Component("layerCmsManager")
@Slf4j
public class LayerCmsConfigManager implements ILayerCmsConfigManager{
    private static final String VISITOR = "2";
    private static final String NEW_CLIENT ="1";
    private static final String ONE_ORDER ="4";
    private static final String MORE_ORDER = "5";
    private static final String chooseCmsLayerKey = "CMS_LAYER_DATE_TIME_KEY";

    @Autowired
    private LayerCmsConfigService layerCmsConfigService;
    @Autowired
    private Gcache gcache;
    @Override
    public int deleteByPrimaryKey(Long id){
        //将缓存的弹层时间清除
        gcache.del(chooseCmsLayerKey);
        return layerCmsConfigService.deleteByPrimaryKey(id);
    }
    @Override
    public int insert(LayerCmsConfigDto record){
        //将缓存的弹层时间清除
        gcache.del(chooseCmsLayerKey);
        return layerCmsConfigService.insert(record);
    }
    @Override
    public int insertSelective(LayerCmsConfigDto record){
        //将缓存的弹层时间清除
        gcache.del(chooseCmsLayerKey);
        return layerCmsConfigService.insertSelective(record);
    }
    @Override
    public LayerCmsConfigDto selectByPrimaryKey(Long id){
        return layerCmsConfigService.selectByPrimaryKey(id);
    }
    @Override
    public List<LayerCmsConfigDto> selectByParam(Map<String, Object> map){
        List<LayerCmsConfigDto> layerCmsConfigDtos = layerCmsConfigService.selectByParam(map);
        log.info("LayerCmsConfigManager.selectByParam result {}", layerCmsConfigDtos);
        return layerCmsConfigDtos;
    }
    @Override
    public Long queryCountByParam(Map<String, Object> map){
        Long aLong = layerCmsConfigService.queryCountByParam(map);
        log.info("LayerCmsConfigManager.queryCountByParam result {}", aLong);
        return aLong;

    }
    @Override
    public int updateByPrimaryKeySelective(LayerCmsConfigDto record){
        //将缓存的弹层时间清除
        gcache.del(chooseCmsLayerKey);
        int i = layerCmsConfigService.updateByPrimaryKeySelective(record);
        log.info("LayerCmsConfigManager.updateByPrimaryKeySelective result {}", i);
        return i;
    }
    @Override
    public int updateByPrimaryKey(LayerCmsConfigDto record){
        //将缓存的弹层时间清除
        gcache.del(chooseCmsLayerKey);
        return layerCmsConfigService.updateByPrimaryKey(record);
    }
    @Override
    public Map<String, String> chooseCmsLayer(Map<String, Object> param) {
        log.info("LayerCmsConfigManager.chooseCmsLayer userId {},param {}", param.get("userId"), param);
        Map<String, String> map = JudgeWhichCmsLayer(param);
        log.info("LayerCmsConfigManager.chooseCmsLayer userId {},data {}", param.get("userId"),map);
        if (null != map) {
            //有弹层，判断redis中的时间是否到期
            Long localTime = System.currentTimeMillis();
            String userId = String.valueOf(param.get("userId"));
            String redisStrTime = gcache.hget(chooseCmsLayerKey,userId);
            Long lastTime = null;
            if (StringUtils.isNotEmpty(redisStrTime)) {
                lastTime = JSON.parseObject(redisStrTime, new TypeReference<Long>() {});
                Long frequency = (Long.valueOf(map.get("frequency")) * 24 * 60 * 60 * 1000);
                log.info("LayerCmsConfigManager.chooseCmsLayer userId {} localTime {},lastTime {},frequency {} ",
                        param.get("userId"), localTime, lastTime, frequency);
                if (localTime >= lastTime + frequency) {
                    //到期，更改redis时间，并返回前端数据
                    gcache.hset(chooseCmsLayerKey,userId , String.valueOf(localTime));
                    return map;
                } else {
                    //没有到期，返回null,不进行弹层
                    log.info("LayerCmsConfigManager.chooseCmsLayer userId {},时间不符合，不进行弹层", param.get("userId"));
                    return null;
                }
            }else{
                //没有弹过，直接返回弹层
                gcache.hset(chooseCmsLayerKey,userId , String.valueOf(localTime));
                return map;
            }
        }
        log.info("LayerCmsConfigManager.chooseCmsLayer userId {},条件不符合,不进行弹层", param.get("userId"));
        return null;
    }

    public Map<String, String> JudgeWhichCmsLayer(Map<String, Object> param){
        //按照优先级排序查询
        HashMap<String, Object> selectParam = new HashMap<>();
        selectParam.put("identity", 1);
        selectParam.put("isSort", 0);
        selectParam.put("disable", 0);//查找启用的弹层
        List<LayerCmsConfigDto> layerCmsConfigDtos = layerCmsConfigService.selectByParam(selectParam);
        //按照优先级放
        List<Map<String, String>> beanMapList = Lists.newArrayList();
        for (LayerCmsConfigDto info : layerCmsConfigDtos) {
            Map<String, String> describe = null;
            try {
                describe = BeanUtils.describe(info);
            } catch (Exception e) {
                log.info("LayerCmsConfigManager.JudgeWhichCmsLayer BeanUtils.describe is fail", e);
            }
            beanMapList.add(describe);
        }
        log.info("LayerCmsConfigManager.JudgeWhichCmsLayer.beanMapList {}", beanMapList);
        Map<String, String> result = new HashMap<>();
        //按照优先级取数据
        for (Map<String, String> map : beanMapList) {
            String dataType = map.get("type");
            String dataNumber = map.get("number");
            int paramValue = Integer.parseInt((String) param.get(dataType));
            if (Integer.parseInt(dataNumber) <= paramValue) {
                result.put("imageUrl", map.get("image"));
                result.put("pathUrl", map.get("pathurl"));
                result.put("type", dataType);
                result.put("frequency", map.get("frequency"));
                return result;
            }
        }
        return null;
    }
}
