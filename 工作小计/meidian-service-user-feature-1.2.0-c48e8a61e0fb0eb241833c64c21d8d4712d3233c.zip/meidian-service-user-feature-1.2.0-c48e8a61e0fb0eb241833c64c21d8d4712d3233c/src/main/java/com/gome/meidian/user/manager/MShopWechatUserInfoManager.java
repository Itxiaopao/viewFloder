package com.gome.meidian.user.manager;

import com.gome.meidian.user.dto.MShopWeChatInfo;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.mapper.MShopWeChatMapper;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author chenchen-ds6
 * 微信处理
 */
@Slf4j
@Component("mshopWeChatInfoManager")
public class MShopWechatUserInfoManager implements IMshopWeChatInfoManager{
    @Autowired
    MShopWeChatMapper mShopWeChatMapper;


    public List<MshopWechatUserInfo> queryWeChatInfoByUserId(List<String> userIdList){
        List<MshopWechatUserInfo> mShopWeChatInfos = mShopWeChatMapper.queryWeChatInfoByUserId(userIdList);
        return mShopWeChatInfos;
    }
    int insertMShopWechatInfo(MshopWechatUserInfo mshopWechatUserInfo){
        int i = mShopWeChatMapper.insertMShopWechatInfo(mshopWechatUserInfo);
        return i;
    }
    MshopWechatUserInfo queryByParam(MshopWechatUserInfo mshopWechatUserInfo){
        return mShopWeChatMapper.queryWechatInfoByParam(mshopWechatUserInfo);
    }

    @Override
    public List<MShopWeChatInfo> queryWeChatInfoListByUniqueIdList(List<String> uniqueIdList) {
        log.info("MShopWechatUserInfoManager.queryWeChatInfoListByUniqueIdList param uniqueIdList {} ",uniqueIdList );
        if(CollectionUtils.isNotEmpty(uniqueIdList)){
            List<MshopWechatUserInfo> mShopWeChatInfos = mShopWeChatMapper.queryWeChatInfoListByUniqueIdList(uniqueIdList);
            log.info(
                    "MShopWechatUserInfoManager.queryWeChatInfoListByUniqueIdList param uniqueIdList {} ,result data {} ",
                    uniqueIdList, mShopWeChatInfos);
            if(CollectionUtils.isNotEmpty(mShopWeChatInfos)){
                List<MShopWeChatInfo> list = Lists.newArrayList();
                for(MshopWechatUserInfo info : mShopWeChatInfos){
                    MShopWeChatInfo weChatInfo = new MShopWeChatInfo();
                    BeanUtils.copyProperties(info,weChatInfo);
                    list.add(weChatInfo);
                }
                return list;
            }
        }
        return null;
    }

    /**
     * 李彬彬游客信息
     * @param uniqueId
     * @return
     */
    @Override
    public List<MShopWeChatInfo> queryWeChatInfoByUniqueId(String uniqueId) {
        log.info("MShopWechatUserInfoManager.queryWeChatInfoByUniqueId param uniqueId {} ",uniqueId );
        if(StringUtils.isNotEmpty(uniqueId)){
            List<MshopWechatUserInfo> mShopWeChatInfos = mShopWeChatMapper.queryWeChatInfoByUniqueId(uniqueId);
            log.info("MShopWechatUserInfoManager.queryWeChatInfoByUniqueId param uniqueId {} ,result data {} ",
                    uniqueId, mShopWeChatInfos);
            if (CollectionUtils.isNotEmpty(mShopWeChatInfos)) {
                List<MShopWeChatInfo> list = Lists.newArrayList();
                for(MshopWechatUserInfo info : mShopWeChatInfos){
                    MShopWeChatInfo weChatInfo = new MShopWeChatInfo();
                    weChatInfo.setImage(info.getImage());
                    weChatInfo.setNickname(info.getNickname());
                    weChatInfo.setUserId(info.getUserId());
                    weChatInfo.setUniqueId(info.getUniqueId());
                    weChatInfo.setWechatNum(info.getWechatNum());
                    list.add(weChatInfo);
                }
                return list;
            }
        }
        return null;
    }
}
