package com.gome.meidian.user.config;

import com.gome.boot.adapter.config.DiamondEnv;
import com.gome.boot.adapter.config.aspect.CacheableAspect;
import com.gome.boot.adapter.config.aspect.RedisLockAspect;
import com.gome.boot.adapter.config.aspect.SneakyLogAspect;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.user.enums.DiamondEnum;
import com.gomeo2o.common.exceptions.BizException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.StandardEnvironment;
import redis.Gcache;

import java.util.Collections;

@Configuration
public class AdapterConfig {

    @Autowired
    Gcache gcache;

    @Bean(name = "sneakyLogAspect")
    public SneakyLogAspect sneakyLogAspect() {
        return new SneakyLogAspect(Collections.singletonList(BizException.class));
    }

    @Bean(name = "cacheableAspect")
    public CacheableAspect cacheableAspect() {
        return new CacheableAspect(gcache);
    }

    @Bean(name = "diamondEnv", initMethod = "init")
    public DiamondEnv diamondEnv(@Autowired StandardEnvironment env) {
        return new DiamondEnv(env, DiamondEnum.values());
    }

    @Bean(name = "redisLockAspect")
    public RedisLockAspect redisLockAspect() {
        return new RedisLockAspect(gcache, BizException.class);
    }

    @Bean(name = "redisLockUtils")
    public RedisLockUtils redisLockUtils() {
        return new RedisLockUtils(gcache);
    }

}
