package com.gome.meidian.user.mapper;


import com.gome.meidian.user.entity.UserRightsRecord;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface UserRightsRecordMapper {

    int delete(@Param("userId") Long userId, @Param("type") Integer type);

    int insert(UserRightsRecord record);

    List<UserRightsRecord> selectByBiz(UserRightsRecord example);

    int update(UserRightsRecord record);
}