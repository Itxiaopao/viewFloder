package com.gome.meidian.user.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.gome.meidian.entity.MeidianShareChangeBind;
import com.gome.meidian.entity.OrderInfo;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.service.IUserRelationService;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.UserAuthDto;
import com.gome.meidian.user.entity.MeidianVshopSummary;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareChangeBinding;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MShopShareChangeBindingMapper;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.mapper.MeidianVshopSummaryMapper;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.UserRelationCacheService;
import com.gome.meidian.user.service.VshopSummaryService;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.exceptions.BizException;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import redis.Gcache;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class MShopShareBindingServiceImpl implements MShopShareBindingService {

    private final int NEW_USER_TYPE = 1;

    @Value("${business.meidian.pianzong_userid}")
    private Long pianzong_userId;

    @Value("${business.meidian.pianzong_mid}")
    private Long pianzong_mId;

    @Autowired
    private UserRelationCacheService userRelationCacheService;

    @Autowired
    MShopShareBindingMapper mShopShareBindingMapper;

    @Autowired
    MShopShareChangeBindingMapper mShopShareChangeBindingMapper;

    @Autowired
    INewOrderService newOrderService;

    @Autowired
    MShopShareRecordMapper mShopShareRecordMapper;

    @Autowired
    IUserRelationService userRelationService;

    @Autowired
    VshopSummaryService vshopSummaryService;

    @Autowired
    VshopFacade vshopFacade;
    @Autowired
    MeidianVshopSummaryMapper meidianVshopSummaryMapper;

    @Autowired
    Gcache gcache;

    private static Logger logger = LoggerFactory.getLogger(MShopShareBindingServiceImpl.class);

    //@Override
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults<?> bindingCustomRelation(MshopShareRecord mshopShareRecord) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        try {
            Long userId = mshopShareRecord.getUserId(); // 当前用户
            Long vshopId = mshopShareRecord.getMid(); // 当前美店Id
            Long pUserId = mshopShareRecord.getUpuserId(); // 上级邀请编码

            MshopShareBinding invateMshopShareBinding = getInvateShopInfo(pUserId);// 查询邀请人信息
            if (invateMshopShareBinding == null) {
                logger.info("绑定美店主，查找上级美店主为空，上级id 为{}", pUserId);
                mapResults = new MapResults<>(ExceptionCodeEnum.INVATE_USER_EMPTY);
                return mapResults;
            }
            MshopShareBinding mshopShareBindingVo = new MshopShareBinding();
            mshopShareBindingVo.setUserId(userId);
            MshopShareBinding thisCustomBind = this.queryByParam(mshopShareBindingVo); // 查询当前用户的绑定联调
            if (vshopId == null || vshopId.equals(0L)) // 普通用户拉新
            {
                if (thisCustomBind == null) // B->C 常规流程
                {
                    int res = addBindingRelation(userId, vshopId, pUserId, mshopShareBindingVo, invateMshopShareBinding);
                    if (res > 0)
                        updateShareRecord(userId, pUserId, 3);
                } else // C 切换B 非常规流程
                    mapResults = customChangeUpper(userId, vshopId, pUserId, invateMshopShareBinding, thisCustomBind);
            } else // 店主拉新行为
            {
                if (thisCustomBind == null) // B->B 常规流程
                {
                    int res = addBindingRelation(userId, vshopId, pUserId, mshopShareBindingVo,
                            invateMshopShareBinding);
                    if (res > 0)
                        updateShareRecord(userId, pUserId, 3);
                } else // C升级B 非常规流程
                    mapResults = customUpUpper(userId, vshopId, pUserId, invateMshopShareBinding, thisCustomBind);
            }
        } catch (Exception ex) {
            logger.error("bindingUserRelation 执行异常.", ex);
        }

        return mapResults;
    }

    @Override
    @Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
    public MapResults<?> bindingUserRelation(MshopShareRecord mshopShareRecord) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        try {
            Long userId = mshopShareRecord.getUserId(); // 当前用户
            Long vshopId = mshopShareRecord.getMid(); // 当前美店Id
            Long pUserId = mshopShareRecord.getUpuserId(); // 上级邀请编码

            MshopShareBinding invateMshopShareBinding = getInvateShopInfo(pUserId);// 查询邀请人信息
            if (invateMshopShareBinding == null) {
                logger.info("绑定美店主，查找上级美店主为空，上级id 为{}", pUserId);
                mapResults = new MapResults<>(ExceptionCodeEnum.INVATE_USER_EMPTY);
                return mapResults;
            }
            MshopShareBinding mshopShareBindingVo = new MshopShareBinding();
            mshopShareBindingVo.setUserId(userId);
            MshopShareBinding thisCustomBind = this.queryByParam(mshopShareBindingVo); // 查询当前用户的绑定联调
            if (vshopId == null || vshopId.equals(0L)) // 普通用户拉新
            {
                if (thisCustomBind == null) // B->C 常规流程
                {
                    int res = addBindingRelation(userId, vshopId, pUserId, mshopShareBindingVo, invateMshopShareBinding);
                    if (res > 0)
                        updateShareRecord(userId, pUserId, 3);
                } else // C 切换B 非常规流程
                    mapResults = customChangeUpper(userId, vshopId, pUserId, invateMshopShareBinding, thisCustomBind);
            } else // 店主拉新行为
            {
                if (thisCustomBind == null) // B->B 常规流程
                {
                    int res = addBindingRelation(userId, vshopId, pUserId, mshopShareBindingVo,
                            invateMshopShareBinding);
                    if (res > 0)
                        updateShareRecord(userId, pUserId, 3);
                } else // C升级B 非常规流程
                    mapResults = customUpUpper(userId, vshopId, pUserId, invateMshopShareBinding, thisCustomBind);
            }
        } catch (Exception ex) {
            logger.error("bindingUserRelation 执行异常.", ex);
        }

        return mapResults;
    }

    private MapResults<?> customUpUpper(Long userId, Long vshopId, Long pUserId,
                                        MshopShareBinding invateMshopShareBinding, MshopShareBinding thisCustomBind) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        if (thisCustomBind.getMid() == null || thisCustomBind.getMid().equals(0L)) {
            MshopShareBinding oldShareBinding = new MshopShareBinding();
            try {
                BeanUtils.copyProperties(oldShareBinding, thisCustomBind);
            } catch (Exception e) {
                e.printStackTrace();
            } // 先拿到老的对象 	// 修改 当前用户 为 B
            thisCustomBind.setMid(vshopId);
            thisCustomBind.setType(3);
            thisCustomBind.setIdentity(1);
            thisCustomBind.setPmid(0L);
            thisCustomBind.setPuserId(0L);// 与上级脱离 邀请关系
            thisCustomBind.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
            thisCustomBind.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
            thisCustomBind.setUpuserId(invateMshopShareBinding.getUserId());
            thisCustomBind.setInsertTime(new Date());
            thisCustomBind.setUpmid(invateMshopShareBinding.getMid());
            String shareChain = invateMshopShareBinding.getShareChain();
            if (StringUtils.isNotBlank(shareChain) && !shareChain.contains(userId.toString()))
                shareChain = shareChain + "-" + userId;// 直接将新的上级链条更替过来
            thisCustomBind.setShareChain(shareChain); // 修改关系链
            logger.info("MShopShareBindingServiceImpl--customUpUpper-C升级B： 修改当前C 为B 修改的对象为{}", thisCustomBind);
            int res = mShopShareBindingMapper.updateOnlyMshopShareBinding(thisCustomBind);
            if (res > 0) {
                this.saveMogoRelation(thisCustomBind);
                // 操作所有直接下级关系
                bulkUpdateRealtions(userId, vshopId, oldShareBinding, thisCustomBind);
                // 修改关系链记录数据
                updateShareRecord(userId, pUserId, 6); // 修改成6 的状态
                try {
                    addChangeRecord(oldShareBinding, thisCustomBind, 1); // 记录切换记录
                } catch (Exception ex) {
                    logger.error("MShopShareBindingServiceImpl--customUpUpper-C升级B：记录切换记录时异常.", ex);
                }
            }
        } else {
            logger.info("MShopShareBindingServiceImpl--customUpUpper-C升级B： 查询当前的用户不是普通用户。用户id 为{}", userId);
            mapResults = new MapResults<>(ExceptionCodeEnum.INVATED_USER_ERROR);
        }
        return mapResults;
    }

    private MapResults<?> customChangeUpper(Long userId, Long vshopId, Long pUserId,
                                            MshopShareBinding invateMshopShareBinding, MshopShareBinding thisCustomBind) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        if (!thisCustomBind.getUpuserId().equals(pUserId))// 还是以前的人 不做操作
        {
            // 查看绑定次数是否超过两次
            int count = mShopShareChangeBindingMapper.queryChangeCount(userId);
            if (count >= 2)
                return new MapResults<>(ExceptionCodeEnum.CHANG_UPPER_COUNT_MORE);
            else {
                MshopShareBinding oldShareBinding = new MshopShareBinding();
                try {
                    BeanUtils.copyProperties(oldShareBinding, thisCustomBind);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                String shareChain = invateMshopShareBinding.getShareChain();
                thisCustomBind.setUpuserId(pUserId);
                thisCustomBind.setUpmid(invateMshopShareBinding.getMid());
                thisCustomBind.setPmid(0L);
                thisCustomBind.setType(NEW_USER_TYPE); // 身份变成新客
                thisCustomBind.setPuserId(0L);// 与上级脱离 邀请关系
                thisCustomBind.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
                thisCustomBind.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
                thisCustomBind.setShareChain(shareChain);

                logger.info("MShopShareBindingServiceImpl--customChangeUpper-C切换B： 修改的对象为{}", thisCustomBind);
                int res = mShopShareBindingMapper.updateOnlyMshopShareBinding(thisCustomBind);
                // 修改下级
                if (res > 0) {
                    addChangeRecord(oldShareBinding, thisCustomBind, 0); // 记录切换记录
                    mShopShareBindingMapper.spiltRelationByPuserId(userId); // 上下级脱钩
                    logger.info("MShopShareBindingServiceImpl-customChangeUpper spiltRelationByPuserId 分离下一级用户的关系，分离结果为{}",res);
                    this.saveMogoRelation(thisCustomBind);
                }
            }
        } else
            mapResults = new MapResults<>(ExceptionCodeEnum.CHANG_UPPER_SHOP_ERROR);
        return mapResults;
    }

    // 记录切换历史
    private int addChangeRecord(MshopShareBinding oldShareBinding, MshopShareBinding thisCustomBind, Integer type) {
        // 修改当前的用户 以及下级用户的链条
        MshopShareChangeBinding changBindingVo = new MshopShareChangeBinding();
        changBindingVo.setLastUpuserId(oldShareBinding.getUpuserId());
        changBindingVo.setLastShareChain(oldShareBinding.getShareChain());
        changBindingVo.setLastTopLeaderUserId(oldShareBinding.getTopLeaderUserId());
        changBindingVo.setUserId(thisCustomBind.getUserId());
        changBindingVo.setUpuserId(thisCustomBind.getUpuserId());
        changBindingVo.setShareChain(thisCustomBind.getShareChain());
        changBindingVo.setTopLeaderUserId(thisCustomBind.getTopLeaderUserId());
        changBindingVo.setType(type);
        logger.info("MShopShareBindingServiceImpl-addChangeRecord 用户切换上级美店主成功.对象为 {}", changBindingVo);
        int res = mShopShareChangeBindingMapper.addRecord(changBindingVo);
        return res;
    }


    // 批量修改下一级的关系
    private void bulkUpdateRealtions(Long userId, Long vshopId, MshopShareBinding oldShareBinding,
                                     MshopShareBinding thisCustomBind) {
        MshopShareBinding mshopShareBindingVo;
        mshopShareBindingVo = new MshopShareBinding();
        mshopShareBindingVo.setPuserId(userId);
        mshopShareBindingVo.setIdentity(0); //身份一定是用户
        List<MshopShareBinding> shopShareBindings = queryListByParam(mshopShareBindingVo);
        logger.info("MShopShareBindingServiceImpl--bindingUserRelation-C升级B 获取C下面所有的邀请用户，用户Id为{}", userId);

        if (shopShareBindings != null && shopShareBindings.size() > 0) {
            for (MshopShareBinding share : shopShareBindings) {
                //修改当前用户的 上级链条
                share.setUpmid(vshopId);
                share.setUpuserId(userId);
                share.setTopLeaderMid(thisCustomBind.getTopLeaderMid());
                share.setTopLeaderUserId(thisCustomBind.getTopLeaderUserId());
                share.setType(NEW_USER_TYPE); //下游身份全部变成新客
                share.setShareChain(thisCustomBind.getShareChain());//记录新的链条
                mShopShareBindingMapper.updateOnlyMshopShareBinding(share);
                this.saveMogoRelation(share);
                logger.info("MShopShareBindingServiceImpl-bulkUpdateRealtions 修改下一级的关系，修改对象为{}", share);
                int res = mShopShareBindingMapper.spiltRelationByPuserId(share.getUserId());
                logger.info("MShopShareBindingServiceImpl-bulkUpdateRealtions spiltRelationByPuserId 分离下一级用户的关系，分离结果为{}", res);

            }
        }

    }


    // 更新分享记录
    private void updateShareRecord(Long userId, Long pUserId, Integer status) {
        mShopShareRecordMapper.updateMShopShareRecordType(status, userId);
        logger.info("MShopShareBindingServiceImpl-invateUserOrChangeUpper 绑定完成后修改分享记录：{}-{}-{}", pUserId, userId,
                status);
    }

    // 绑定关系
    private int addBindingRelation(Long userId, Long vshopId, Long pUserId, MshopShareBinding mshopShareBindingVo,
                                   MshopShareBinding invateMshopShareBinding) {
        String shareChain = invateMshopShareBinding.getShareChain();
        if (vshopId != null && vshopId > 0) {
            if (StringUtils.isNotBlank(shareChain) && !shareChain.contains(userId.toString())) {
                shareChain = shareChain + "-" + userId;
            } // 拼凑好链条
            mshopShareBindingVo.setType(0);
            mshopShareBindingVo.setMid(vshopId);
            mshopShareBindingVo.setIdentity(1);
        } else {
            if (StringUtils.isNotBlank(shareChain) && !shareChain.contains(pUserId.toString())) {
                shareChain = shareChain + "-" + pUserId;
            } // 拼凑好链条
            mshopShareBindingVo.setMid(0L);
            mshopShareBindingVo.setType(1);// 新客
            mshopShareBindingVo.setIdentity(0);
        }
        mshopShareBindingVo.setShareChain(shareChain);
        // 针对C的话
        mshopShareBindingVo.setUserId(userId);
        mshopShareBindingVo.setUpuserId(invateMshopShareBinding.getUserId()); // 上一级
        mshopShareBindingVo.setUpmid(invateMshopShareBinding.getMid());
        mshopShareBindingVo.setPuserId(invateMshopShareBinding.getUserId());
        mshopShareBindingVo.setPmid(invateMshopShareBinding.getMid());
        mshopShareBindingVo.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
        mshopShareBindingVo.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
        logger.info("MShopShareBindingServiceImpl--invateUserOrChangeUpper 插入绑定关系表的入参为requestParam:{}", mshopShareBindingVo);
        int res = insertMShopShareBinding(mshopShareBindingVo);
        if (res > 0) {
            this.saveMogoRelation(mshopShareBindingVo);
        }
        return res;

    }

    public MshopShareBinding getInvateShopInfo(Long pUserId) {
        MshopShareBinding shopShareBindingVo = new MshopShareBinding();
        shopShareBindingVo.setUserId(pUserId);
        shopShareBindingVo.setIdentity(1);
        MshopShareBinding invateMshopShareBinding = queryByParam(shopShareBindingVo);
        if (null == invateMshopShareBinding) {
            // 查询是否是美店主信息
            CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade
                    .queryVshopByuserId(pUserId.toString());
            if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
                VshopInfo info = vshopInfoCommonResultEntity.getBusinessObj();
                invateMshopShareBinding = new MshopShareBinding();
                invateMshopShareBinding.setMid(info.getVshopId());
                invateMshopShareBinding.setUserId(info.getUserId());
                if (info.getVshopIdentity() != null && info.getVshopIdentity().equals(3)) {
					// 如果是片总
                    invateMshopShareBinding.setTopLeaderMid(info.getVshopId());
                    // 如果自身 是片总的 那就设置为片总
                    invateMshopShareBinding.setTopLeaderUserId(info.getUserId());
                    invateMshopShareBinding.setUpuserId(info.getUserId());
                    invateMshopShareBinding.setUpmid(info.getVshopId());
                    invateMshopShareBinding.setShareChain(info.getUserId() + "");
                } else {
					// 如果不是片总 设置上级
                    invateMshopShareBinding.setTopLeaderMid(pianzong_mId);
                    invateMshopShareBinding.setTopLeaderUserId(pianzong_userId);
                    invateMshopShareBinding.setUpuserId(pianzong_userId);
                    invateMshopShareBinding.setUpmid(pianzong_mId);
                    invateMshopShareBinding.setShareChain(pianzong_userId + "-" + info.getUserId());
                }
            }
        }
        return invateMshopShareBinding;
    }

    @Override
    public List<UserAuthDto> getUserAuthList(Set<Long> userIds) {
        String reidsKey = "key_user_auth_list_str_prefix_" + JSON.toJSON(userIds);
        String val = gcache.get(reidsKey);
        if (StringUtils.isNotEmpty(val)) {
            return JSONArray.parseArray(val, UserAuthDto.class);
        }
        List<UserAuthDto> userAuthList = mShopShareBindingMapper.getUserAuthList(userIds);
        //如果查询不到数据，默认授权
        if (userIds.size() != userAuthList.size()) {
            for (UserAuthDto userAuthDto : userAuthList) {
                userIds.remove(userAuthDto.getUserId());
            }
            for (Long userId : userIds) {
                userAuthList.add(new UserAuthDto(userId, 1));
            }
        }
        gcache.setex(reidsKey, 30, JSON.toJSONString(userAuthList));
        return userAuthList;
    }

    @Override
    public Integer selectCountByUserId(Long userId) {
        return mShopShareBindingMapper.selectCountByUserId(userId);
    }

    @Override
    public List<MShopShareBindingDto> queryListByParamWithMap(Map<String, Object> map) {
        return mShopShareBindingMapper.queryListByParamWithMap(map);
    }

    @Override
    public MShopShareBindingDto queryShareBindingByUserId(Long userId) {
        MshopShareBinding userRelation = userRelationCacheService.getUserRelation(userId);
        if (userRelation != null) {
            return this.convert(userRelation);
        }
        MshopShareBinding mshopShareBinding = userRelationCacheService.resetUserRelation(userId);
        return this.convert(mshopShareBinding);
    }

    @Override
    public List<MshopShareBinding> queryMyNotVisitorCount(Long userId) {
        return mShopShareBindingMapper.queryMyNotVisitorCount(userId);
    }

    @Override
    public List<MShopShareBindingDto> queryMyShareBindingByType(Long userId, String type, Integer pageSize,
                                                                Integer pageIndex) {
        return mShopShareBindingMapper.queryMyShareBindingByType(userId, type, pageSize, pageIndex);
    }

    @Override
    public List<MshopShareBinding> queryInviteList(Long userId, Integer pageSize, Integer pageIndex) {
        return mShopShareBindingMapper.queryInviteList(userId, pageSize, pageIndex);
    }

    @Override
    public List<String> queryUserIdList(Long userId) {
        return mShopShareBindingMapper.queryUserIdList(userId);
    }

    @Override
    public Boolean checkAccessAuthority(Long orderId, Long upUserId) {
        // 订单服务，获取订单基础信息
        ResultEntity<OrderInfo> orderResult = newOrderService.getOrderInfo(orderId);
        if (orderResult.getCode() != 0) {
            throw new BizException(orderResult.getCode(), orderResult.getMessage());
        }
        OrderInfo orderInfo = orderResult.getBusinessObj();
        if (orderInfo != null && CollectionUtils.isNotEmpty(orderInfo.getUserIdRelation())
                && !orderInfo.getUserIdRelation().contains(upUserId)) {
            // 如果当前用户不在订单链条中，则直接反会没有权限
            return Boolean.FALSE;
        }
        if (orderInfo.getUserId().equals(upUserId)) {
            // 若果当前用户是购买人 直接反会有权限查看
            return Boolean.TRUE;
        }
        return mShopShareBindingMapper.getAccessAuthority(orderInfo.getUserId()) > 0;

    }

    @Override
    public Boolean createBindRelation(MshopShareBinding mshopShareBinding) {
        MshopShareBinding param = new MshopShareBinding();
        param.setUserId(mshopShareBinding.getUserId());
        MshopShareBinding model = mShopShareBindingMapper.queryByParam(param);
        if (model != null) {
            throw new BizException(400, "绑定关系已建立");
        }
        return mShopShareBindingMapper.insertMShopShareBinding(mshopShareBinding) > 0;
    }

    @Override
    public MshopShareBinding queryByParam(MshopShareBinding mshopShareBinding) {
        return mShopShareBindingMapper.queryByParam(mshopShareBinding);
    }

    @Override
    public List<MshopShareBinding> queryListByParam(MshopShareBinding mshopShareBinding) {
        return mShopShareBindingMapper.queryListByParam(mshopShareBinding);
    }

    @Override
    public Long queryCountByParam(MshopShareBinding mshopShareBinding) {
        return mShopShareBindingMapper.queryCountByParam(mshopShareBinding);
    }

    @Override
    public int insertMShopShareBinding(MshopShareBinding mshopShareBinding) {
        return mShopShareBindingMapper.insertMShopShareBinding(mshopShareBinding);
    }

    @Override
    public int updateMshopShareBinding(MshopShareBinding mshopShareBinding) {
        return mShopShareBindingMapper.updateMshopShareBinding(mshopShareBinding);
    }

    @Override
    public int changeUpuser(MshopShareBinding mshopShareBinding) {
        return 0;
    }

    /**
     * 查找我的下级客户信息
     *
     * @param userId
     * @param myUserId
     * @return
     */
    @Override
    public MShopShareBindingDto queryShareBindingByUserIdAndUpUserid(Long userId, Long myUserId) {
        return mShopShareBindingMapper.queryShareBindingByUserIdAndUpUserid(userId, myUserId);
    }

    @Override
    public Integer queryMidCount(Long userId) {
        Integer count = 0;
        MeidianVshopSummary meidianVshopSummary = meidianVshopSummaryMapper.selectByUserId(userId);
        if (null != meidianVshopSummary) {
            Long shopNum = meidianVshopSummary.getShopNum();
            if (null != shopNum) {
                count = Integer.valueOf(String.valueOf(shopNum));
            }
        }
        return count;

        // Integer count = 0;
        // //判断当前用户如果是片总，直接统计数量
        // if(isTopLeader(userId)){
        // //直接统计片总下面店主的数量
        // count = mShopShareBindingMapper.queryMidCountWithTopLeader(userId);
        // logger.info("MShopOwnerInfoManager.queryMidCount userid = {}, is
        // topLeader,MidCount is {}", userId, count);
        // }else{
        // count = mShopShareBindingMapper.queryMidCount(userId);
        // logger.info("MShopOwnerInfoManager.queryMidCount userid = {}, MidCount is
        // {}", userId, count);
        // }
        // return count;
    }

    @Override
    public Integer queryCustomerCount(Long userId) {
        Integer count = 0;
        MeidianVshopSummary meidianVshopSummary = meidianVshopSummaryMapper.selectByUserId(userId);
        if (null != meidianVshopSummary) {
            Long customNum = meidianVshopSummary.getCustomNum();
            if (null != customNum) {
                count = Integer.valueOf(String.valueOf(customNum));
            }
        }
        return count;

        // Integer count = 0;
        // //判断当前用户如果是片总，直接统计数量
        // if(isTopLeader(userId)){
        // //直接统计片总下面店主的数量
        // count = mShopShareBindingMapper.queryConsumerCountWithTopLeader(userId);
        // logger.info("MShopOwnerInfoManager.queryCustomerCount userid ={}, is
        // topLeader,ConusmerCount is {}", userId, count);
        //
        // }else{
        // count = mShopShareBindingMapper.queryCustomerCount(userId);
        // logger.info("MShopOwnerInfoManager.queryCustomerCount userid ={}
        // ,ConusmerCount is {}", userId, count);
        // }
        // return count;

    }

    private boolean isTopLeader(Long userId) {
        MShopShareBindingDto mShopShareBindingDto = this.queryShareBindingByUserId(userId);
        if (null != mShopShareBindingDto) {
            if (mShopShareBindingDto.getIdentity().equals(3)) {
                return true;
            }
        } else {
            // vshop_info表中确认片总的身份
            CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(String.valueOf(userId));
            if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
                Integer vshopIdentity = vshopInfoCommonResultEntity.getBusinessObj().getVshopIdentity();
                if (null != vshopIdentity && vshopIdentity.equals(3)) {
                    return true;
                }
            }
        }
        return false;
    }

    // 保存Modb
    private void saveMogoRelation(MshopShareBinding binding) {
        try {
            MeidianShareChangeBind bind = new MeidianShareChangeBind();
            BeanUtils.copyProperties(bind, binding);
            userRelationService.saveUserRelation(bind);
        } catch (Exception ex) {
            logger.error("保存mogoDb 出现异常", ex);
        }
    }

    public MShopShareBindingDto convert(MshopShareBinding model) {
        if (model == null) {
            return null;
        }
        MShopShareBindingDto dto = new MShopShareBindingDto();
        dto.setId(model.getId());
        dto.setMid(model.getMid());
        dto.setUserId(model.getUserId());
        dto.setUpMid(model.getUpmid());
        dto.setPMid(model.getPmid());
        dto.setUniqueId(model.getUniqueId());
        dto.setUpUniqueId(model.getUpuniqueId());
        dto.setPUniqueId(model.getPuniqueId());
        dto.setAuthorization(model.getAuthorization());
        dto.setUpUserId(model.getUpuserId());
        dto.setPUserId(model.getPuserId());
        dto.setCount(model.getCount());
        dto.setInsertTime(DateFormatUtils.format(model.getInsertTime(), "yyyy-MM-dd HH:mm:ss"));
        dto.setUpdateTime(DateFormatUtils.format(model.getUpdateTime(), "yyyy-MM-dd HH:mm:ss"));
        dto.setTopLeaderMid(model.getTopLeaderMid());
        dto.setTopLeaderUserid(model.getTopLeaderUserId());
        dto.setShareChain(model.getShareChain());
        dto.setType(model.getType());
        dto.setIdentity(model.getIdentity());
        return dto;
    }

}
