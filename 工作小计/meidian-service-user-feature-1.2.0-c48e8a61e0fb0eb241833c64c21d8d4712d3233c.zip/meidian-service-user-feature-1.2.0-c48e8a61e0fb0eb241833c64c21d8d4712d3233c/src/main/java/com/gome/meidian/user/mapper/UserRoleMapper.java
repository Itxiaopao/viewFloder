package com.gome.meidian.user.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.UserRole;
/**
 * 用户角色数据层
 *
 */
public interface UserRoleMapper extends BaseMapper<UserRole, Long> {
	/**
	 * 根据userID查询所有角色信息
	 * @param userId
	 * @return
	 */
	List<UserRole> findByUserId(@Param("userId")String userId);
}
