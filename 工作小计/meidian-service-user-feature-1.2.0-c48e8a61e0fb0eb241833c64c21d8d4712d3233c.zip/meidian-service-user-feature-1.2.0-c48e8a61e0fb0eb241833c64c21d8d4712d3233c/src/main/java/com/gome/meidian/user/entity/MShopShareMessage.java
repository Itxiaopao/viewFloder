package com.gome.meidian.user.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * @author chenchen-ds6
 */
@Setter
@Getter
@ToString
public class MShopShareMessage {
    private Long id;
    private String messageId;
    private String messageBody;
    private String topic;
    private String tag;
    private String messageKey;
    private Date insertTime;
    private Date updateTime;
    private Integer repeatTimes;
    private String sendStatus;
    private Integer isDelete;
}
