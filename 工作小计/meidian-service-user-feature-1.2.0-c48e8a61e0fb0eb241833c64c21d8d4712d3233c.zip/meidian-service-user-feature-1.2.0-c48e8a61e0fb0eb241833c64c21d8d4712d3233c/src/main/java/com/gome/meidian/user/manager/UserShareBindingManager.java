package com.gome.meidian.user.manager;

import java.util.*;
import java.util.concurrent.ThreadPoolExecutor;

import com.gome.boot.adapter.config.aspect.annotation.Cacheable;
import com.gome.boot.adapter.config.aspect.annotation.RedisLock;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.gome.boot.adapter.config.DiamondEnv;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.user.constant.DiamondConstant;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopOrderUserInfoDto;
import com.gome.meidian.user.dto.MshopRebateDto;
import com.gome.meidian.user.dto.MshopShareChangeBindingDto;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.dto.UserAuthDto;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareChangeBinding;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.enums.DiamondEnum;
import com.gome.meidian.user.enums.UserIdentityEnum;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.MShopShareBindingChangeService;
import com.gome.meidian.user.service.MShopShareBindingHandleService;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.MShopWechatService;
import com.gome.meidian.user.service.VshopSummaryService;
import com.gome.meidian.user.utils.MeidianUserTypeEnum;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.exceptions.BizException;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoDescFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

import javax.annotation.Resource;

/**
 * @author limenghui-ds
 * @create 2019-06-12 10:49
 */
@Slf4j
@Component("userShareBindingManager")
public class UserShareBindingManager implements IUserShareBindingManager {
    private static Logger logger = LoggerFactory.getLogger(MShopShareRecordManager.class);
    @Autowired
    private MShopShareBindingService mShopShareBindingService;
    @Autowired
    private MShopShareBindingHandleService mShopShareBindingHandleService;
    @Autowired
    private VshopInfoExternalFacade vshopInfoExternalFacade;
    @Autowired
    private MShopWechatService mShopWechatService;
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private MShopShareRecordManager mShopShareRecordManager;
    @Autowired
    private MShopShareBindingChangeService changeService;
    //片总
    @Value("${business.meidian.pianzong_userid}")
    private Long topLeaderUserId;
    @Value("${business.meidian.pianzong_mid}")
    private Long topLeaderMid;
    // 分布式锁的时间 5秒钟
    private final int LOCK_TIME = 5;

    private final String DISLOCK_KEY = "MEIDIAN:BINDING_USER_";
    @Autowired
    private VshopInfoDescFacade vshopInfoDescFacade;
    @Autowired
    private VshopSummaryService vshopSummaryService;
    @Autowired
    private Gcache gcache;
    @Autowired
    DiamondEnv diamondEnv;
    @Autowired
    private RedisLockUtils redisLockUtils;
    @Resource(name = "threadPoolExecutor")
    private ThreadPoolExecutor threadPoolExecutor;

    /**
     * B 邀请C绑定  分两种场景
     * 1 存在关系表   相当于C切换B 限制两次
     * 2 不存在关系表 直接绑定
     * <p>
     * 直接切换上级的接口
     */
    //todo 小美帮帮不走    认证员工 走李立兴，30分钟扫数据进行切换片总
    @Override
    @SneakyLog("切换上级店主")
    @Deprecated
    public MapResults changeMLeader(MshopShareRecordDto mshopShareRecordDto) {
        if (true) {
            return new MapResults<>(ExceptionCodeEnum.INTERFACE_DEPRECATED);
        }
        if (null == mshopShareRecordDto) {
            return new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
        }
        if (NumberUtils.isNullOrZero(mshopShareRecordDto.getUserId())) {
            return new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
        }
        String lock = DISLOCK_KEY + "changeMLeader_" + mshopShareRecordDto.getUserId();
        boolean resubmitLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(lock);
            if (!resubmitLock) {
                return new MapResults<>(ExceptionCodeEnum.CHANG_TYPE_QUICKLY);
            }
            if (NumberUtils.isNullOrZero(mshopShareRecordDto.getMid()) && mShopShareBindingService.getInvateShopInfo(mshopShareRecordDto.getUserId()) != null) {
                return new MapResults<>(ExceptionCodeEnum.CHANG_USER_ERROR);
            }
            Long pUserId = mshopShareRecordDto.getUpuserId();
            Long userId = mshopShareRecordDto.getUserId();
            MshopShareBinding invateMshopShareBinding = mShopShareBindingService.getInvateShopInfo(pUserId);// 查询邀请人信息
            if (invateMshopShareBinding == null) {
                return new MapResults<>(ExceptionCodeEnum.INVATE_USER_EMPTY);
            }
            return handleCustomBinding(pUserId, userId, invateMshopShareBinding);
        } catch (Exception ex) {
            logger.error("切换上级店主 发生异常,mshopShareRecordDto:{},异常堆栈如下:", JSON.toJSON(mshopShareRecordDto), ex);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        } finally {
            redisLockUtils.unlock(resubmitLock, lock);
        }

    }

    /**
     * C 升级B
     * 1 存在关系表， 带走下一级，下下级脱离关系
     * 2 不存在关系，直接绑定
     */
    @Override
    @SneakyLog("邀请开店")
    public MapResults changeVShop(MshopShareRecordDto mshopShareRecordDto) {
        if (null == mshopShareRecordDto || NumberUtils.isNullOrZero(mshopShareRecordDto.getUserId()) || NumberUtils.isNullOrZero(mshopShareRecordDto.getMid())) {
            return new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
        }
        String lock = DISLOCK_KEY + "changeVShop_" + mshopShareRecordDto.getUserId();
        boolean resubmitLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(lock);
            if (!resubmitLock) {
                return new MapResults<>(ExceptionCodeEnum.CHANG_TYPE_QUICKLY);
            }
            Long pUserId = mshopShareRecordDto.getUpuserId();
            Long userId = mshopShareRecordDto.getUserId();
            MshopShareBinding invateMshopShareBinding = mShopShareBindingService.getInvateShopInfo(pUserId);// 查询邀请人信息
            if (invateMshopShareBinding == null) {
                return new MapResults<>(ExceptionCodeEnum.INVATE_USER_EMPTY);
            }
            return handleShopBinding(pUserId, userId, mshopShareRecordDto.getMid(), invateMshopShareBinding);
        } catch (Exception ex) {
            logger.error("邀请开店 发生异常,mshopShareRecordDto:{},异常堆栈如下:", mshopShareRecordDto, ex);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        } finally {
            redisLockUtils.unlock(resubmitLock, lock);
        }

    }

    @SneakyThrows
    private MapResults handleCustomBinding(Long pUserId, Long userId, MshopShareBinding invateMshopShareBinding) {
        MapResults mapResults;
        MshopShareBinding mshopShareBindingVo = new MshopShareBinding();
        mshopShareBindingVo.setUserId(userId);
        MshopShareBinding thisCustomBind = mShopShareBindingService.queryByParam(mshopShareBindingVo);
        if (null == thisCustomBind) {
            // B直接绑定C
            logger.info("切换店主当前用户在绑定表中不存在，puserId:{},userId:{},requestParam:{}", pUserId, userId, invateMshopShareBinding);
            mapResults = mShopShareBindingHandleService.shopBindUser(invateMshopShareBinding, mshopShareBindingVo, true);
            if (mapResults.getCode() == ExceptionCodeEnum.SUCCESS.getErrorCode()) {
                mShopShareRecordManager.pushJobMessage(userId, pUserId, 0);
            }
        } else if (null != thisCustomBind.getUpuserId() && thisCustomBind.getUpuserId().equals(pUserId)) {
            logger.info("目的上级和原来上级相同，不能进行切换上级,puserId:{},userId:{},requestParam:{}", pUserId, userId, invateMshopShareBinding);
            mapResults = new MapResults<>(ExceptionCodeEnum.CHANG_UPPER_SHOP_ERROR);
        } else {// C切换了B
            logger.info("切换店主当前用户在绑定表中存在，puserId:{},userId:{},requestParam:{}", pUserId, userId, invateMshopShareBinding);
            mapResults = mShopShareBindingHandleService.customChangeUpper(invateMshopShareBinding, thisCustomBind);
        }
        return mapResults;
    }

    /**
     * c升级b  库中数据处理
     *
     * @param pUserId                 邀请人
     * @param userId                  当前用户
     * @param userMid                 当前用户mid
     * @param invateMshopShareBinding 上级（或者是片总）
     * @return
     */
    @SneakyThrows
    private MapResults handleShopBinding(Long pUserId, Long userId, Long userMid, MshopShareBinding invateMshopShareBinding) {
        MapResults mapResults;
        MshopShareBinding mshopShareBindingVo = new MshopShareBinding();
        mshopShareBindingVo.setUserId(userId);
        MshopShareBinding thisCustomBind = mShopShareBindingService.queryByParam(mshopShareBindingVo);
        if (null == thisCustomBind) {
            // 直接绑定关系
            mshopShareBindingVo.setMid(userMid);
            mapResults = mShopShareBindingHandleService.shopBindUser(invateMshopShareBinding, mshopShareBindingVo, false);
        } else {
            // C升级成为B,更改本身和下级的upUserId
            mapResults = mShopShareBindingHandleService.customUpToShop(userMid, invateMshopShareBinding, thisCustomBind);
        }
        mShopShareRecordManager.pushJobMessage(userId, pUserId, 1);
        String switchFlag = gcache.get(DISLOCK_KEY + "SWITCH");
        if (StringUtils.isNotBlank(switchFlag) && switchFlag.equals("true")) {
            insertVshopDescInfo(userId);
        }
        return mapResults;
    }

    /**
     * B升级为片总
     * 1 关系表中存在， 搜索所有的下级 ，删除当前，修改其余的片总和链条，最后修改vshopinfo 身份
     * 2 关系表中不存，直接修改vshop_info 表身份
     */
    @Override
    @RedisLock
    @SneakyLog("修改片总身份")
    public MapResults changePianZong(Long userId, int userStatus) {
        if (userId == null) {
            return new MapResults<>(HttpStatus.SC_BAD_REQUEST, "修改片总身份失败,原因：用户id不能为空");
        }
        try {
            CommonResultEntity<VshopInfo> vshopInfoResult = vshopFacade.queryVshopByuserId(String.valueOf(userId));
            if (vshopInfoResult == null || vshopInfoResult.getBusinessObj() == null) {
                return new MapResults<>(HttpStatus.SC_BAD_REQUEST, "修改片总身份失败,原因：查不到该用户");
            }
            VshopInfo vshopInfo = vshopInfoResult.getBusinessObj();
            Integer identity = ObjectUtils.defaultIfNull(vshopInfo.getVshopIdentity(), UserIdentityEnum.shopkeeper.getCode());
            if (userStatus == 1 && UserIdentityEnum.shopkeeper.getCode().equals(identity)) {
                boolean b = mShopShareBindingHandleService.pzUpgrade(userId, vshopInfo.getVshopId());
                return new MapResults<>(b);
            } else if (userStatus == 0 && UserIdentityEnum.topLeaderUser.getCode().equals(identity)) {
                // 员工离职 以及解绑 p->B p 下面的所有人的片总换成大锤
                return new MapResults<>(HttpStatus.SC_BAD_REQUEST, "功能待开发...");
            }
            return new MapResults<>(HttpStatus.SC_BAD_REQUEST, "不符合片总身份的修改");
        } catch (BizException e) {
            return new MapResults<>(e.getCode(), e.getMsg());
        } catch (Exception e) {
            log.info("修改片总身份发生异常,userId:{},userStatus:{},异常堆栈如下:", userId, userStatus, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }

    }

    @Override
    @SneakyLog("批量升级片总")
    public MapResults<Boolean> pzUpgrade(List<Long> userIdList) {
        try {
            if (CollectionUtils.isEmpty(userIdList)) {
                return new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
            }
            threadPoolExecutor.execute(() -> {
                for (Long item : userIdList) {
                    MapResults<?> mapResults = this.changePianZong(item, 1);
                    log.info("执行升级片总接口,userId:{},处理结果:{}", item, JSON.toJSON(mapResults));
                }
            });
            return new MapResults<>(Boolean.TRUE);
        } catch (Exception e) {
            log.error("批量升级片总发生异常,userIdList:{},异常堆栈如下:", userIdList, e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    @Override
    @SneakyLog("用户隐私授权")
    public MapResults authorizationPrivacy(MshopShareRecordDto mshopShareRecordDto) {
        try {
            MshopShareBinding mshopShareBinding = new MshopShareBinding();
            mshopShareBinding.setUserId(mshopShareRecordDto.getUserId());
            MshopShareBinding rtnMshopShareBinding = mShopShareBindingService.queryByParam(mshopShareBinding);
            if (null != rtnMshopShareBinding) {
                rtnMshopShareBinding.setAuthorization(mshopShareRecordDto.getAuthorization());
                mShopShareBindingService.updateMshopShareBinding(rtnMshopShareBinding);
                return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
            }
        } catch (Exception e) {
            logger.error("用户隐私授权 发生异常,mshopShareRecordDto:{},异常堆栈如下", JSON.toJSON(mshopShareRecordDto), e);
        }
        return null;

    }

    /**
     * 提奖明细 添加销售组织字段：3种情况：允许为null，大锤，员工店主 通过userId 查找 直属上级信息，片总信息，分享连信息
     *
     * @param mshopRebateDto
     * @return
     */
    @Override
    @SneakyLog("根据用户id或美店id查询用户关系")
    public MapResults<MshopRebateDto> queryMshopRebateDtoByUserIdOrMid(MshopRebateDto mshopRebateDto) {
        if (null == mshopRebateDto || null == mshopRebateDto.getUserId()) {
            return new MapResults<>(ExceptionCodeEnum.USERID_EMPTY);
        }
        MshopRebateDto dto = new MshopRebateDto();
        try {
            MShopShareBindingDto mShopShareBindingDto = mShopShareBindingService.queryShareBindingByUserId(mshopRebateDto.getUserId());
            if (null != mShopShareBindingDto) {
                dto.setTopLeaderMid(mShopShareBindingDto.getTopLeaderMid());
                dto.setTopLeaderUserid(mShopShareBindingDto.getTopLeaderUserid());
                dto.setPshareChain(mShopShareBindingDto.getShareChain());
                dto.setUserId(mshopRebateDto.getUserId());
                Long mid = mShopShareBindingDto.getMid();
                // 如果自己是店主,受益人自己
                if (null != mid && mid != 0) {
                    dto.setUpMid(mid);
                    dto.setUpUserId(mShopShareBindingDto.getUserId());
                } else {
                    // 自己不是店主，受益人上级
                    dto.setUpMid(mShopShareBindingDto.getUpMid());
                    dto.setUpUserId(mShopShareBindingDto.getUpUserId());
                }
            } else {
                CommonResultEntity<VshopInfo> vResult = vshopInfoExternalFacade.queryVshopInfoByUserId(mshopRebateDto.getUserId());
                if (vResult != null && vResult.getBusinessObj() != null) {
                    VshopInfo info = vResult.getBusinessObj();
                    dto = new MshopRebateDto();
                    dto.setUpMid(info.getVshopId());
                    dto.setMid(info.getVshopId());
                    dto.setUserId(mshopRebateDto.getUserId());
                    dto.setUpUserId(mshopRebateDto.getUserId());
                    dto.setPshareChain(mshopRebateDto.getUserId().toString());
                    if (info.getVshopIdentity() != null && info.getVshopIdentity().equals(3)) {
                        // 片总为自己 // 店主身份状态 1.店主2.店总3.片总
                        dto.setTopLeaderUserid(mshopRebateDto.getUserId());
                        dto.setTopLeaderMid(info.getVshopId());
                    }
                }
            }
            return new MapResults<>(dto);
        } catch (Exception e) {
            logger.error("根据用户id或美店id查询用户关系发生异常 mshopRebateDto:{},异常堆栈如下:", JSON.toJSON(mshopRebateDto), e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    @Override
    public MapResults<MShopShareBindingDto> queryShareBindingByUserId(Long userId) {
        if (null == userId) {
            return new MapResults<>(1, "userId不能为空");
        }
        MShopShareBindingDto mShopShareBindingDto = mShopShareBindingService.queryShareBindingByUserId(userId);
        return new MapResults<>(mShopShareBindingDto);
    }

    @Override
    public List<MShopShareBindingDto> queryListByParam(Map<String, Object> map) {
        return mShopShareBindingService.queryListByParamWithMap(map);
    }

    /**
     * 用户的二维码上传
     *
     * @param mShopShareBindingDto
     * @return
     */
    @Override
    @SneakyLog("上传二维码")
    public MapResults uploadQrCode(MShopShareBindingDto mShopShareBindingDto) {
        try {
            if (null == mShopShareBindingDto.getUserId()) {
                return new MapResults<>(ExceptionCodeEnum.USERID_EMPTY);
            }
            if (StringUtils.isBlank(mShopShareBindingDto.getQrCode())) {
                return new MapResults<>(ExceptionCodeEnum.QR_EMPTY);
            }
            if (StringUtils.isBlank(mShopShareBindingDto.getWechatNum())) {
                return new MapResults<>(ExceptionCodeEnum.WECHAT_NUM_EMPTY);
            }
            MshopWechatUserInfo mshopWechatUserInfo = new MshopWechatUserInfo();
            mshopWechatUserInfo.setUserId(mShopShareBindingDto.getUserId());
            mshopWechatUserInfo.setType(1);
            MshopWechatUserInfo rtnMshopWechatUserInfo = mShopWechatService.queryWechatInfoByParam(mshopWechatUserInfo);
            if (null == rtnMshopWechatUserInfo) {
                copyBeanUtils(mshopWechatUserInfo, mShopShareBindingDto);
                mshopWechatUserInfo.setType(1);
                mshopWechatUserInfo.setUniqueId(String.valueOf(mShopShareBindingDto.getUserId()));
                mShopWechatService.insertMShopWechatInfo(mshopWechatUserInfo);
            } else {
                copyBeanUtils(mshopWechatUserInfo, mShopShareBindingDto);
                mshopWechatUserInfo.setType(1);
                mShopWechatService.updateWechatUserInfo(mshopWechatUserInfo);
            }
            return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        } catch (Exception e) {
            logger.info("上传二维码 发生异常,mShopShareBindingDto:{},异常信息堆栈如下:", JSON.toJSON(mShopShareBindingDto), e);
            return new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
        }
    }

    /**
     * 通过userId查询关系链
     *
     * @param userId
     * @return
     */
    @Override
    public MapResults<MshopOrderUserInfoDto> queryMshopOrderDtoByUserId(Long userId) {
        MapResults<MshopOrderUserInfoDto> result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        if (userId == null) {
            result.setBuessObj(null);
            return result;
        }
        MshopOrderUserInfoDto dto = null;
        MShopShareBindingDto mShopShareBindingDto = mShopShareBindingService.queryShareBindingByUserId(userId);
        StringBuilder sb = new StringBuilder(64);
        sb.append("根据userId获取下单关系链, 入参 :").append(userId).append(" 绑定表反回值:").append(JSON.toJSON(mShopShareBindingDto));
        if (null != mShopShareBindingDto) {
            dto = new MshopOrderUserInfoDto();
            dto.setShareChain(mShopShareBindingDto.getShareChain());
            Long mid = mShopShareBindingDto.getMid();
            if (NumberUtils.isNullOrZero(mid)) {
                dto.setPmid(mShopShareBindingDto.getUpMid());
                dto.setPUserId(mShopShareBindingDto.getUpUserId());
                dto.setUserIdentity(0);
            } else {
                dto.setPmid(mid);
                dto.setPUserId(userId);
                dto.setUserIdentity(1);
            }
            dto.setUserId(userId);
            dto.setPianUserId(mShopShareBindingDto.getTopLeaderUserid());
            dto.setUserType(mShopShareBindingDto.getType());
        } else {
            CommonResultEntity<VshopInfo> vResult = vshopInfoExternalFacade.queryVshopInfoByUserId(userId);
            sb.append("店主库返回值:").append(JSON.toJSON(vResult));
            if (vResult != null && vResult.getBusinessObj() != null) {
                VshopInfo info = vResult.getBusinessObj();
                dto = new MshopOrderUserInfoDto();
                dto.setMid(info.getVshopId());
                dto.setUserId(userId);
                dto.setUserIdentity(info.getVshopIdentity());
                dto.setPUserId(userId);
                dto.setPmid(info.getVshopId());
                dto.setUserType(0);
                if (MeidianUserTypeEnum.MSHOP_IDENTITY_STAFF.getTypeCode().equals(info.getVshopIdentity())) {
                    dto.setShareChain(userId.toString());
                    dto.setPianUserId(userId);// 片总为自己 // 店主身份状态 1.店主2.店总3.片总
                } else {
                    dto.setShareChain(topLeaderUserId + "-" + userId.toString());
                    dto.setPianUserId(topLeaderUserId);
                }
            }
        }
        result.setBuessObj(dto);
        log.info(sb.append("出参:").append(JSON.toJSON(result)).toString());
        return result;
    }

    @Override
    @SneakyLog("校验隐私授权")
    public MapResults<Boolean> checkAccessAuthority(Long orderId, Long upUserId) {
        if (orderId == null) {
            return new MapResults<>(400, "订单id不能为空");
        }
        if (upUserId == null) {
            return new MapResults<>(400, "上级用户id不能为空");
        }
        try {
            return new MapResults<>(mShopShareBindingService.checkAccessAuthority(orderId, upUserId));
        } catch (BizException e) {
            return new MapResults<>(e.getCode(), e.getMsg());
        } catch (Exception e) {
            return new MapResults<>(500, "系统内部异常");
        }
    }

    @Override
    public Boolean dataSync(Map<String, Object> param) {
        Integer pageCount = (Integer) param.get("pageCount");
        Integer pageSize = (Integer) param.get("pageSize");
        vshopSummaryService.task(pageCount, pageSize);
        return Boolean.TRUE;

    }

    @Deprecated
    @Override
    @Cacheable(prefix = "UserShareBindingManager.queryMidCount", suffix = "#userId", seconds = 30)
    public Integer queryMidCount(Long userId) {
        if (null != userId) {
            return 0;
        }
        return mShopShareBindingService.queryMidCount(userId);
    }

    @Deprecated
    @Override
    @Cacheable(prefix = "UserShareBindingManager.queryCustomerCount", suffix = "#userId", seconds = 30)
    public Integer queryCustomerCount(Long userId) {
        if (null != userId) {
            return 0;
        }
        return mShopShareBindingService.queryCustomerCount(userId);
    }

    @Override
    public Boolean shareBindSync(Map map) {
        Integer pageCount = Integer.valueOf(String.valueOf(map.get("pageCount")));
        Integer pageSize = Integer.valueOf(String.valueOf(map.get("pageSize")));
        vshopSummaryService.shareBindSync(pageCount, pageSize);
        return Boolean.TRUE;
    }

    @Override
    @SneakyLog("获取用户授权列表")
    public MapResults<List<UserAuthDto>> getUserAuthList(Set<Long> userIds) {
        if (CollectionUtils.isEmpty(userIds)) {
            return new MapResults<>(400, "userId不能为空");
        }
        return new MapResults<>(mShopShareBindingService.getUserAuthList(userIds));
    }

    @Override
    @SneakyLog("根userId获取用户权限")
    public MapResults<UserAuthDto> getUserAuth(Long userId) {
        if (userId == null) {
            return new MapResults<>(400, "userId不能为空");
        }
        MShopShareBindingDto dto = mShopShareBindingService.queryShareBindingByUserId(userId);
        if (dto == null) {
            // 默认授权
            MapResults mapResults = new MapResults(new UserAuthDto(userId, 1));
            mapResults.setMessage("未查到用户信息,默认授权");
            return mapResults;
        }
        return new MapResults<>(new UserAuthDto(dto.getUserId(), dto.getAuthorization() == null ? 0 : dto.getAuthorization()));
    }

    /**
     * 查询绑定切换记录表的历史记录
     *
     * @param mshopShareChangeBinding
     * @return
     */
    @Override
    @SneakyLog("查询绑定切换记录表的历史记录")
    public List<MshopShareChangeBindingDto> queryChangeListByParam(MshopShareChangeBindingDto mshopShareChangeBinding) {
        if (null == mshopShareChangeBinding) {
            return null;
        }
        List<MshopShareChangeBindingDto> result = Lists.newArrayList();
        try {
            MshopShareChangeBinding param = new MshopShareChangeBinding();
            copyBeanUtils(param, mshopShareChangeBinding);
            List<MshopShareChangeBinding> list = changeService.queryChangeListByParam(param);
            for (MshopShareChangeBinding shareChangeBinding : list) {
                MshopShareChangeBindingDto dto = new MshopShareChangeBindingDto();
                copyBeanUtils(dto, shareChangeBinding);
                result.add(dto);
            }
        } catch (Exception e) {
            log.error("查询绑定切换记录表的历史记录发生异常,mshopShareChangeBinding:{},异常堆栈如下:", JSON.toJSON(mshopShareChangeBinding), e);
        }
        return result;
    }

    /**
     * @param toObj   目标对象
     * @param fromObj 原始对象
     */
    private void copyBeanUtils(Object toObj, Object fromObj) {
        org.springframework.beans.BeanUtils.copyProperties(fromObj, toObj);
    }

    /**
     * 开店之后的门店归属
     *
     * @param userId
     */
    public void insertVshopDescInfo(Long userId) {
        //开店，同步vshop_info_desc表中数据，查找上级片总的门店信息,数据
        List<VshopInfoDesc> descList = new ArrayList<>(1);
        VshopInfoDesc desc = new VshopInfoDesc();
        MapResults<MShopShareBindingDto> shareBindingDtoMapResults = queryShareBindingByUserId(userId);
        if (null != shareBindingDtoMapResults && null != shareBindingDtoMapResults.getBuessObj()) {
            Long topLeaderUserid = shareBindingDtoMapResults.getBuessObj().getTopLeaderUserid();
            if (getPianZongUserId().contains(topLeaderUserid)) {
                desc.setStoreCode(diamondEnv.getValue(DiamondEnum.DEFAULT_HAMMER_LIST, DiamondConstant.PIANZONG_STID));
                desc.setOrganization(diamondEnv.getValue(DiamondEnum.DEFAULT_HAMMER_LIST, DiamondConstant.PIANZONG_ORANID));
            } else {
                VshopInfoDesc vshopInfoDesc = vshopInfoDescFacade.getVshopInfoDesc(topLeaderUserid);
                if (null != vshopInfoDesc) {
                    desc.setStoreCode(vshopInfoDesc.getStoreCode());
                    desc.setOrganization(vshopInfoDesc.getOrganization());
                }
            }
        }
        desc.setUserId(userId);
        desc.setRewardStatus(1);
        descList.add(desc);
        vshopInfoDescFacade.synVshopInfoDesc(descList);
    }

    /**
     * 处理片总字符串为set
     *
     * @return
     */
    @SneakyLog("获取所有配置的片总数据")
    public Set<Long> getPianZongUserId() {
        String pianzongUserIds = diamondEnv.getValue(DiamondEnum.DEFAULT_HAMMER_LIST, DiamondConstant.PIANZONG_USERID);
        Set<Long> set = Sets.newHashSet();
        for (String s : pianzongUserIds.split(",")) {
            set.add(Long.valueOf(s));
        }
        return set;
    }
}
