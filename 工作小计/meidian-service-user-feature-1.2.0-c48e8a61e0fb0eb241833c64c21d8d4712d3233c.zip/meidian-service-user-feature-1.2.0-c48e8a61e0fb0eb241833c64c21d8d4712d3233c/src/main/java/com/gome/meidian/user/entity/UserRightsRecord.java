package com.gome.meidian.user.entity;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户权益记录
 */
@Data
public class UserRightsRecord implements Serializable {

    private static final long serialVersionUID = 81796743339706422L;
    private Long id;//主键
    private Long userId;//用户id
    private Integer type;//活动类型，1.瓜分团
    private Integer scene;//场景 1:开团,2:参团,3:奖励开团(系统),4:奖励参团(系统),5:奖励开团(任务),6:奖励参团(任务),7:事务
    private Integer cost;//原值
    private Integer value;//操作值
    private String txId;//事务id
    private Integer state;//逻辑删除，0失效，1，有效
    private Date insertTime;//创建时间
    private Date updateTime;//修改时间

}