package com.gome.meidian.user.mapper;

import java.io.Serializable;
/**
 * 数据层基类
 *
 * @param <T>
 * @param <ID>
 */
public interface BaseMapper<T, ID extends Serializable> {
	int add(T t);
	
	int deleteById(ID id);
	
	int update(T t);
	
	T findById(ID id);
}
