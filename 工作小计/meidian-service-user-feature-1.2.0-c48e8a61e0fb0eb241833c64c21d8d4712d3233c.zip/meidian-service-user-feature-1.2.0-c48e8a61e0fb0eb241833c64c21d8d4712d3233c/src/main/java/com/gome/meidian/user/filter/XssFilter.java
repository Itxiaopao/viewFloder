package com.gome.meidian.user.filter;

import com.gome.meidian.user.utils.Constants;
import com.gome.meidian.user.utils.MeidianEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Enumeration;
import java.util.UUID;


/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description xss 过滤
 */
@Component
public class XssFilter implements Filter {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
    @Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;

         /* 过滤非法字符*/
        httpServletRequest = new MHttpServletRequest(httpServletRequest);

        parseRequestHeader(httpServletRequest);
        //HTTP Header
        Enumeration<String> headerNames = httpServletRequest.getHeaderNames();
        String headerName;
        StringBuilder sb = new StringBuilder();
        while (headerNames.hasMoreElements()) {
            headerName = headerNames.nextElement();
            sb.append(headerName).append(":").append(httpServletRequest.getHeader(headerName)).append(", ");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("request head [{}]", sb.substring(0, sb.length() - 1));
        }

        chain.doFilter(request, response);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

    private void parseRequestHeader(HttpServletRequest request) {
        // client OS is APP request
        String client = request.getHeader(Constants.CLIENT_OS_HEADER) == null ? Constants.OTHER : request.getHeader(Constants.CLIENT_OS_HEADER);
        String phoneType = request.getHeader(Constants.PHONE_TYPE_HEADER) == null ? Constants.OTHER : request.getHeader(Constants.PHONE_TYPE_HEADER);
        String devId = request.getHeader(Constants.DEV_ID_HEADER) == null ? Constants.OTHER : request.getHeader(Constants.DEV_ID_HEADER);
        String appVersion = request.getHeader(Constants.APP_VERSION_HEADER) == null ? Constants.OTHER : request.getHeader(Constants.APP_VERSION_HEADER);

        MeidianEnvironment.putClient(client);
        MeidianEnvironment.putPhoneType(phoneType);
        MeidianEnvironment.putDevId(devId);
        MeidianEnvironment.putTraceId(UUID.randomUUID().toString().replaceAll("-", ""));
        MeidianEnvironment.putRemoteAddr(getIpAddress(request));
        MeidianEnvironment.putAppVersion(appVersion);

        if (logger.isDebugEnabled()) {
            logger.debug("clientOS:{}, phoneType:{}, devId:{}, appVersion:{}", client, phoneType, devId, appVersion);
        }
    }

    /**
     * 根据请求对象获取ip地址
     * @param request
     */
    private static String getIpAddress(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

}
