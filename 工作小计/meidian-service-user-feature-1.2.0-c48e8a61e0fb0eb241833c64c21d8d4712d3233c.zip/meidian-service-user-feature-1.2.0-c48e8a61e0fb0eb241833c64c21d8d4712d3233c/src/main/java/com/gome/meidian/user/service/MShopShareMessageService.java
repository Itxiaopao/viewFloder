package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.MShopShareMessage;

import java.util.HashMap;

/**
 *
 */
public interface MShopShareMessageService {
    int insertMShopMessage(MShopShareMessage mShopShareMessage);
}
