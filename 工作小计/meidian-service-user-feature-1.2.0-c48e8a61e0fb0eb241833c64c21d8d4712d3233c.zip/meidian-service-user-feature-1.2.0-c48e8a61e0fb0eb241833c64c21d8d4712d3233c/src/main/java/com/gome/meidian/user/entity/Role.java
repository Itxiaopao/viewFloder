package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 角色
 * table:md_user_center.role
 */
public class Role implements Serializable {

	private static final long serialVersionUID = 7013589089712411618L;
	private Short id;
	/**
	 * 角色名
	 */
	private String roleName;
	/**
	 * 创建时间
	 */
	private Date ctime;
	/**
	 * 更新时间
	 */
	private Date utime;
	public Short getId() {
		return id;
	}
	public void setId(Short id) {
		this.id = id;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public Date getUtime() {
		return utime;
	}
	public void setUtime(Date utime) {
		this.utime = utime;
	}
	
}
