
package com.gome.meidian.user.mq;

import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.gome.meidian.user.manager.MShopShareMessageManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Created by lipengfei on 2019/07/10.
 */
@Component
public class MQProducer {

	private static DefaultMQProducer producer;
	private static String mm = "";// 延时消费 messageDelayLevel=1s 5s 10s 30s 1m 2m 3m 4m 5m 6m 7m 8m 9m 10m 20m 30m
									// 40m 50m 1h 2h 6h
	private static Logger logger = LoggerFactory.getLogger(MQProducer.class);

	@Value("${mq.queues}")
	private int queueTmp;
	@Value("${mq.address}")
	private String serverAddressTmp;
	@Autowired
	MShopShareMessageManager mShopShareMessageManager;

	@PostConstruct
	public void init() {
		DefaultMQProducer producerNew = null;
		try {
			producerNew = new DefaultMQProducer("DragonToPopProducer");
			producerNew.setNamesrvAddr(serverAddressTmp);
			producerNew.setInstanceName("Instace_");
			producerNew.setDefaultTopicQueueNums(queueTmp);
			producerNew.start();
			logger.info("MQProducer 初始化成功！.....");
		} catch (Exception ex) {
			logger.error("MQProducer 初始化异常。", ex);
		}
		/** 这里很重要：先替换老实例再关闭老实例;如果先关闭老实例,有可能它在被程序调用着 */
		DefaultMQProducer oldInsetance = producer;
		producer = producerNew;
		if (oldInsetance != null) {
			oldInsetance.shutdown();
		}
	}

	// 发送消息
	public static SendResult sendMessage(String topic, String tag, String key, byte[] bytes)
			throws MQClientException{
		try {
			Message message = new Message(topic, tag, key, bytes);
			SendResult result = producer.send(message);
			return result;
		} catch (Exception e) {
			logger.info("MQProducer 消息发送失败！失败原因:{},topic:{},tag:{},key:{}", e.getMessage(), topic, tag, key);
			/** 这里很重要：一定要把消息上抛,用于业务代码的事务控制 */
			throw new MQClientException("rocketmq message send failed", e);
		}
	}

	//
	public static SendResult sendMessage(String topic, String tag, String key, String bodyMessage)
			throws MQClientException {
		try {
			Message message = new Message(topic, tag, key, bodyMessage.getBytes("UTF-8"));
			if (!("".equals(mm) || mm == null)) {
				message.setDelayTimeLevel(Integer.parseInt(getMm()));// 延时消费
			}
			SendResult result = producer.send(message);
			logger.info("MQProducer 消息发送成功！msgId:{},topic:{},tag:{},key:{}", result.getMsgId(), topic, tag, key);
			return result;
		} catch (Exception e) {
			logger.info("MQProducer 消息发送失败！失败原因:{},topic:{},tag:{},key:{}", e.getMessage(), topic, tag, key);
			throw new MQClientException("rocketmq message send failed", e);
		}
	}


	public static SendResult sendMessageSelectQueue(String topic, String tag, String key, String bodyMessage, String selectorParam)
			throws MQClientException {
		try {
			Message message = new Message(topic, tag, key, bodyMessage.getBytes("UTF-8"));
			if (!("".equals(mm) || mm == null)) {
				message.setDelayTimeLevel(Integer.parseInt(getMm()));// 延时消费
			}
			PianZongMessageQueueSelector selector = new PianZongMessageQueueSelector();
			SendResult result = producer.send(message,selector,selectorParam);
			logger.info("MQProducer 消息发送成功！msgId:{},topic:{},tag:{},key:{}", result.getMsgId(), topic, tag, key);
			return result;
		} catch (Exception e) {
			logger.info("MQProducer 消息发送失败！失败原因:{},topic:{},tag:{},key:{}", e.getMessage(), topic, tag, key);
			throw new MQClientException("rocketmq message send failed", e);
		}
	}

	public static String getMm() {
		return mm;
	}

	public static void setMm(String mm) {
		MQProducer.mm = mm;
	}

}
