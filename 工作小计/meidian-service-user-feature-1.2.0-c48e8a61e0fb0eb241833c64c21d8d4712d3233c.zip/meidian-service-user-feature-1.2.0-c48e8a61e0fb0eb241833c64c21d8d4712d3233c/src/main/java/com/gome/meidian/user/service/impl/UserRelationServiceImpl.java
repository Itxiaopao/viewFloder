package com.gome.meidian.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.UserRelation;
import com.gome.meidian.user.mapper.UserRelationMapper;
import com.gome.meidian.user.service.AbstractService;
import com.gome.meidian.user.service.UserRelationService;
@Service
public class UserRelationServiceImpl extends AbstractService<UserRelation, Long> implements UserRelationService {
	@Autowired
	private UserRelationMapper userRelationMapper;

	/**
	 * 根据userID获取所有绑定关系
	 */
	@Override
	public List<UserRelation> findListByUserId(String userId) {
		// TODO Auto-generated method stub
		return userRelationMapper.findListByUserId(userId);
	}

	/**
	 * 根据openId获取所有绑定关系
	 * @param openId
	 * @return
	 */
	@Override
	public List<UserRelation> findListByOpenId(String openId) {
		return userRelationMapper.findListByOpenId(openId);
	}

	@Override
	public void setBaseMapper() {
		// TODO Auto-generated method stub
		super.baseMapper = userRelationMapper;
	}

}
