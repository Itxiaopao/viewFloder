package com.gome.meidian.user.manager;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.UserRightsDto;
import com.gome.meidian.user.enums.UserRightsSceneEnum;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.UserRightsService;
import com.gome.meidian.user.utils.RedisKeyUtils;
import com.gomeo2o.common.exceptions.BizException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 用户权益服务
 */
@Slf4j
@Component
public class UserRightsManager implements IUserRightsManager {

    @Resource(name = "userRightsService")
    private UserRightsService userRightsService;

    @Autowired
    private RedisLockUtils redisLockUtils;

    @Override
    public MapResults<Boolean> saveRewards(Long userId, Integer type, Integer rewardOpenCount, Integer rewardJoinCount, Integer scene) {
        if (userId == null) {
            return new MapResults<>(400, "用户id不能为空");
        }
        if (type == null) {
            return new MapResults<>(400, "活动类型不能为空");
        }
        if (!UserRightsSceneEnum.contain(scene)) {
            return new MapResults<>(400, "业务场景违规");
        }
        if (rewardOpenCount == null) {
            rewardOpenCount = 0;
        }
        if (rewardJoinCount == null) {
            rewardJoinCount = 0;
        }
        String redisLock = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_SAVE_REWARDS_INCR_PREFIX, userId, type, rewardOpenCount, rewardJoinCount, scene);
        boolean resubmitLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisLock);
            if (!resubmitLock) {
                return new MapResults<>(400, "请勿重复提交...");
            }
            return new MapResults<>(userRightsService.saveRewards(userId, type, rewardOpenCount, rewardJoinCount, scene));
        } catch (BizException e) {
            return new MapResults<>(e.getCode(), e.getMsg());
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.saveRewards 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, redisLock);
        }
    }

    @Override
    public MapResults<Boolean> consumeRights(Long userId, Integer type, Integer scene, Integer operate, String txId) {
        if (userId == null) {
            return new MapResults<>(400, "用户id不能为空");
        }
        if (type == null) {
            return new MapResults<>(400, "活动类型不能为空");
        }
        if (!UserRightsSceneEnum.contain(scene)) {
            return new MapResults<>(400, "业务场景违规");
        }
        if (operate == null) {
            return new MapResults<>(400, "操作类型不能为空");
        }
        boolean resubmitLock = false;
        String redisLock = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_CONSUME_RIGHTS_INCR_PREFIX, userId, type, scene, operate, txId);
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisLock);
            if (!resubmitLock) {
                return new MapResults<>(400, "请勿重复提交");
            }
            return new MapResults<>(userRightsService.consumeRights(userId, type, scene, operate, txId));
        } catch (BizException e) {
            return new MapResults<>(e.getCode(), e.getMsg());
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.consumeRights 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, redisLock);
        }
    }


    @Override
    @SneakyLog("获取用户权益")
    public MapResults<UserRightsDto> getUserRightsActivitieCount(Long userId, Integer type) {
        if (userId == null) {
            return new MapResults<>(400, "用户id不能为空");
        }
        if (type == null) {
            return new MapResults<>(400, "活动类型不能为空");
        }
        try {
            return new MapResults<>(userRightsService.getUserRightsActivitieCount(userId, type));
        } catch (BizException e) {
            return new MapResults<>(e.getCode(), e.getMsg());
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.getUserRightsActivitieCount 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        }

    }

    @Override
    @SneakyLog("重置用户行使权益")
    public MapResults<Boolean> resetExercisePower(Integer type) {
        if (type == null) {
            return new MapResults<>(400, "重置活动类型不能为空");
        }
        boolean resubmitLock = false;
        String redisLock = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_RESET_INCR_PREFIX, type);
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisLock);
            if (!resubmitLock) {
                return new MapResults<>(ExceptionCodeEnum.CHANG_TYPE_QUICKLY);
            }
            return new MapResults<>(userRightsService.resetExercisePower(type));
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.resetExercisePower 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, redisLock);
        }
    }

    @Override
    @SneakyLog("根据活动类型获取用户权益总数")
    public MapResults<Integer> getUserRightsCount(Integer type) {
        if (type == null) {
            return new MapResults<>(400, "重置活动类型不能为空");
        }
        try {
            return new MapResults<>(userRightsService.getUserRightsCount(type));
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.getUserRightsCount 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("同步用户权益缓存")
    public MapResults<Boolean> synUserRightsCache(Integer type, Integer pageNo, Integer pageSize) {
        if (type == null) {
            return new MapResults<>(400, "重置活动类型不能为空");
        }
        if (pageNo == null) {
            return new MapResults<>(400, "重置活动页码不能为空");
        }
        if (pageSize == null) {
            return new MapResults<>(400, "重置活动页面大小不能为空");
        }

        boolean resubmitLock = false;
        String redisLock = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_RESET_INCR_PREFIX, type, pageNo, pageSize);
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisLock);
            if (!resubmitLock) {
                return new MapResults<>(400, "请勿重复提交");
            }
            return new MapResults<>(userRightsService.synUserRightsCache(type, pageNo, pageSize));
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.synUserRightsCache 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, redisLock);
        }
    }

    @Override
    public MapResults<Boolean> clear(Long userId, Integer type) {
        if (userId == null) {
            return new MapResults<>(400, "用户id不能为空");
        }
        if (type == null) {
            return new MapResults<>(400, "活动类型不能为空");
        }
        boolean resubmitLock = false;
        String redisLock = RedisKeyUtils.getRedisKey(CacheConstant.USER_RIGHTS_CLEAR_INCR_PREFIX, userId, type);
        try {
            resubmitLock = redisLockUtils.resubmitLock(redisLock);
            if (!resubmitLock) {
                return new MapResults<>(400, "请勿重复提交");
            }
            return new MapResults<>(userRightsService.clear(userId, type));
        } catch (Exception e) {
            log.error("com.gome.meidian.user.manager.UserRightsManager.clear 发生异常，异常堆栈如下:", e);
            return new MapResults<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, redisLock);
        }
    }

}
