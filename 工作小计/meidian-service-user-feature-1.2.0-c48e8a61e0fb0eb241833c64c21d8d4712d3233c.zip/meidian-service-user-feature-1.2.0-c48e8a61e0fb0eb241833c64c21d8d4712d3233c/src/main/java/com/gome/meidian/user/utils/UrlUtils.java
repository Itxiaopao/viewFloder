package com.gome.meidian.user.utils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.net.URLDecoder;
@Slf4j
public class UrlUtils {
    public static String dealWithUrl(String imageUrl) {
        String image = "";
        try {
            if (StringUtils.isNotBlank(imageUrl)) {
                image = URLDecoder.decode(imageUrl, "UTF-8");
               //处理http%253A%252F%252F开头的需要decode两次
                image = URLDecoder.decode(image, "UTF-8");
            }
        }catch(Exception e){
            log.error("处理url异常，requestParam:{},exception:{}",imageUrl,e);
        }
        return image;
    }
}
