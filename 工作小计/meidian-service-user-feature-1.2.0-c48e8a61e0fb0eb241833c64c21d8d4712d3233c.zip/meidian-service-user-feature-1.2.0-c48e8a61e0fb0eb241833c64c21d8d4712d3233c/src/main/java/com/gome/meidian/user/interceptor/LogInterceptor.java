package com.gome.meidian.user.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gome.meidian.user.utils.MeidianEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.WebUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 请求日志记录
 */
public class LogInterceptor {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static ObjectMapper objectMapper = new ObjectMapper();

    public static String getRequest(HttpServletRequest httpServletRequest) throws IOException {
        //请求日志
        Map<String, Object> requestLogMap = new HashMap<>();
        requestLogMap.put("remote", MeidianEnvironment.getRemoteAddr());
        //HTTP Header
        Enumeration<String> headerNames = httpServletRequest.getHeaderNames();

        Map<String, Object> headerMap = new HashMap<>();
        String headerName;
        while (headerNames.hasMoreElements()) {
            headerName = headerNames.nextElement();
            headerMap.put(headerName, httpServletRequest.getHeader(headerName));
        }

        if (!headerMap.isEmpty()) {
            requestLogMap.put("header", headerMap);
        }

        requestLogMap.put("URI", httpServletRequest.getRequestURI());
        requestLogMap.put("queryString", httpServletRequest.getQueryString());

        if (httpServletRequest instanceof ContentCachingRequestWrapper) {
            ContentCachingRequestWrapper wrapper =
                    WebUtils.getNativeRequest(httpServletRequest, ContentCachingRequestWrapper.class);
            requestLogMap.put("body", new String(wrapper.getContentAsByteArray()));
        }

        return objectMapper.writeValueAsString(requestLogMap);
    }
}
