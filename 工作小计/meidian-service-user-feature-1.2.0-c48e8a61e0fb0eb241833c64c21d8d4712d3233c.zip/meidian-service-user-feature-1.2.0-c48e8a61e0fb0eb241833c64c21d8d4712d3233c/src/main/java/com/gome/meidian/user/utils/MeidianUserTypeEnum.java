package com.gome.meidian.user.utils;

public enum MeidianUserTypeEnum {
    MSHOP_IDENTITY_OWNER(1, "店主"),
    MSHOP_IDENTITY_TOTAL(2, "店总"),
    MSHOP_IDENTITY_STAFF(3, "片总"),
    USER_CONSUMER(2, "普通用户"),
    USER_TYPE_NEWCONSUMER(1, "新客"),
    USER_TYPE_VISITOR(2, "游客"),
    USER_TYPE_FIRST_ORDER(4, "首单"), USER_TYPE_MORE_ORDER(5, "忠粉");

    private Integer typeCode;
    private String message;

    MeidianUserTypeEnum(Integer typeCode, String message) {
        this.typeCode = typeCode;
        this.message = message;
    }

    public Integer getTypeCode() {
        return typeCode;
    }

    public void setTypeCode(Integer typeCode) {
        this.typeCode = typeCode;
    }
}
