package com.gome.meidian.user.mapper.equities;

import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;

import java.util.List;

public interface BasicEquitiesNumberMapper {

    List<UserBasicEquitiesNumberDto> queryAllListGroupBYType();

    void updateWithParam(UserBasicEquitiesNumberDto vo);

    UserBasicEquitiesNumberDto queryOneByParam(UserBasicEquitiesNumberDto param);

    int insert(UserBasicEquitiesNumberDto dto);
}