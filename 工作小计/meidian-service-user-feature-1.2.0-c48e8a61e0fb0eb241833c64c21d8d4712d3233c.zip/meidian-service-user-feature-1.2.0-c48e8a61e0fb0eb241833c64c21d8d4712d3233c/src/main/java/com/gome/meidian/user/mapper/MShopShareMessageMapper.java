package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MShopShareMessage;
import com.gome.meidian.user.entity.Role;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * @author chenchen-ds6
 */
public interface MShopShareMessageMapper {
	/**
	 * 插入
	 * @param mShopShareMessage
	 * @return
	 */
	int insertMShopMessage(MShopShareMessage mShopShareMessage);

	/**
	 * 查询
	 * @param map
	 * @return
	 */
	MShopShareMessage selectByMessageId(HashMap<String,Object> map);

	/**
	 * 查询是否存在
	 * @param map
	 * @return
	 */
	int selectCountByMessageId(HashMap<String,Object> map);
}
