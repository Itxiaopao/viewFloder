package com.gome.meidian.user.mapper;


import com.gome.meidian.user.entity.MshopShareChangeBinding;

import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author limenghui-ds
 * @create 2019-06-10 16:07
 */
public interface MShopShareChangeBindingMapper {
	
	 /**
     * 查看切换记录
     *
     */
    public int queryChangeCount(@Param("userId")Long userId) ;

    /**
     * 新增记录
     *
     */
    int addRecord(MshopShareChangeBinding mshopShareChangeBinding);

    List<MshopShareChangeBinding> queryChangeListByParam(MshopShareChangeBinding mshopShareChangeBinding);
}
