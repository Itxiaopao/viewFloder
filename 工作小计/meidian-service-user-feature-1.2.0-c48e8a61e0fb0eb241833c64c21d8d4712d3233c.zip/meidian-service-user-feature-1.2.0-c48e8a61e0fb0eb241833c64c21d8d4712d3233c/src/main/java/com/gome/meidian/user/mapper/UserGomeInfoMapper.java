package com.gome.meidian.user.mapper;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.UserGomeInfo;
/**
 * 国美用户信息数据层
 * @author lishouxu-ds
 *
 */
public interface UserGomeInfoMapper extends BaseMapper<UserGomeInfo, Long>{
    /**
     * 根据用户Id查询国美用户信息
     * @param userId
     * @return
     */
	UserGomeInfo findByUserId(@Param("userId")String userId);

}
