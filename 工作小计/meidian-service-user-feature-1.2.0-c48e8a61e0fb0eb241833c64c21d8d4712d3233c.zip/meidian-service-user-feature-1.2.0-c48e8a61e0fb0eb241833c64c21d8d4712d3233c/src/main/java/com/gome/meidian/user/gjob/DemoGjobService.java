package com.gome.meidian.user.gjob;

import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 展示任务
 *
 * @author hushengdong
 * @create 2019-10-21 14:56:00
 */
@Service
public class DemoGjobService extends AbstractGjobService {

    private static Logger logger = LoggerFactory.getLogger(DemoGjobService.class);

    @Override
    public MapResults<String> execute(String param) {
        logger.info("DemoGjobService start param:{} ", param);
        return new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
    }

}
