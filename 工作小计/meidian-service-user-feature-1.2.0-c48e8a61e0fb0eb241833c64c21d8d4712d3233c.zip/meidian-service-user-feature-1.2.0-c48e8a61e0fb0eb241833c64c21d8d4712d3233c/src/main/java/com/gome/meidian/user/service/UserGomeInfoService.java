package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.UserGomeInfo;



/**
 * 国美用户信息服务层
 *
 */
public interface UserGomeInfoService extends BaseService<UserGomeInfo, Long> {
	/**
	 * 根据userID获取用户信息
	 * @param userId
	 * @return
	 */
	UserGomeInfo findByUserId(String userId);
    /**
     * 添加国美用户信息
     * @param userGomeInfo
     * @return
     */
    int insertUserGomeInfo(UserGomeInfo userGomeInfo);
}
