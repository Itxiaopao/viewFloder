package com.gome.meidian.user.mapper;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.UserAuthDto;
import com.gome.meidian.user.entity.MeidianReportUserIdentity;
import com.gome.meidian.user.entity.MshopShareBinding;

/**
 * @author limenghui-ds
 * @create 2019-06-10 16:07
 */
public interface MShopShareBindingMapper {
    /**我下级首单、新客、忠粉的个数*/
    public List<MshopShareBinding> queryMyNotVisitorCount(@Param("userId")Long userId) ;

    /**
     * 查询单挑记录
     *
     */
    MshopShareBinding queryByParam(MshopShareBinding mshopShareBinding);
    
    /**
     * 查询记录列表
     *
     */
    List<MshopShareBinding> queryListByParam(MshopShareBinding mshopShareBinding);

    Long queryCountByParam(MshopShareBinding mshopShareBinding);
    /**
     * 查询隔级用户关系
     * @param mshopShareBinding 上级用户信息
     * @return
     */
    List<MshopShareBinding> queryListByChains(MshopShareBinding mshopShareBinding);

    /**
     * 插入绑定关系
     * @param mshopShareBinding
     * @return
     */
    int insertMShopShareBinding(MshopShareBinding mshopShareBinding);

    /**
     * 修改绑定关系
     * @param mshopShareBinding
     * @return
     */
    int updateMshopShareBinding(MshopShareBinding mshopShareBinding);

    /**
     * 切换上级
     * @param mshopShareBinding
     * @return
     */
    int updateOnlyMshopShareBinding(MshopShareBinding mshopShareBinding);
    
    int removeShareBinding(@Param("id")Long id);

    /**
     * 已邀店主数
     * @param userId
     * @return
     */
    Integer queryMidCount(@Param("userId")Long userId) ;

    /**
     * 客户数量
     * @param userId
     * @return
     */
    Integer queryCustomerCount(@Param("userId")Long userId) ;

    List<MshopShareBinding> queryInviteList(@Param("userId") Long userId, @Param("pageSize") Integer pageSize, @Param("pageIndex")Integer pageIndex) ;

    /**
     * 绑定表中，查找新客/首单/忠粉
     **/
    public List<MShopShareBindingDto> queryMyShareBindingByType(@Param("userId")Long userId, @Param("type")String type,
            @Param("pageSize")Integer pageSize, @Param("pageIndex")Integer pageIndex);

    /**通过userId查找绑定表*/
//    public MShopShareBindingDto queryShareBindingByUserId(Long userId);  queryShareBindingByUserId
    /**通过该用户ID，上级userId查找绑定表数据*/
    public MShopShareBindingDto queryShareBindingByUserIdAndUpUserid(@Param("userId")Long userId,@Param("upUserid")Long upUserid);

    /**通过userId查找绑定表信息*/
    public MshopShareBinding queryShareBindingByUserId(Long userId);

    List<String> queryUserIdList(@Param("userId")Long userId);

    /**
     *
     * @param userId
     * @return
     */
    Integer getAccessAuthority(@Param("userId") Long userId);

    /**
     * 通过片总的userid，计算统计下面的所有店主数量
     * @param userId
     * @return
     */

    Integer queryMidCountWithTopLeader(Long userId);
    /**
     * 通过片总的userid，计算统计下面的所有普通客户的数量
     * @param userId
     * @return
     */
    Integer queryConsumerCountWithTopLeader(Long userId);
    /**
     * 通过分享的userid，进行数据脱钩
     * @param userId
     * @return
     */
    Integer spiltRelationByPuserId(Long userId);

    /**
     * 分页获取用户绑定关系
     * @param pageIndex
     * @param pageSize
     * @return
     */
    List<MshopShareBinding> queryByPage(@Param("pageIndex") Integer pageIndex,@Param("pageSize") Integer pageSize);

    /**
     * 根据userId集合获取用户权限
     *
     * @param userIds 用户id集合
     * @return
     */
    List<UserAuthDto> getUserAuthList(@Param("userIds") Set<Long> userIds);

    /**
     * 通过userId查询条目数
     * @param userId
     * @return
     */
    Integer selectCountByUserId(Long userId);

    List<MShopShareBindingDto> queryListByParamWithMap(Map<String, Object> map);


    /**
     * 拿到没有身份标示的user_id
     * @return
     */
    List<MeidianReportUserIdentity> selectDistinctUpUserId();
}
