package com.gome.meidian.user.entity;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserRights implements Serializable {

    private static final long serialVersionUID = -2153150824631103260L;
    private Long userId;//用户id
    private Integer type;//活动类型 1.瓜分团
    private Integer rewardOpenCount;//奖励用户开团次数
    private Integer rewardJoinCount;//奖励用户参团次数
    private Integer alreadyOpenCount;//已开团次数
    private Integer alreadyJoinCount;//已参团次数


}