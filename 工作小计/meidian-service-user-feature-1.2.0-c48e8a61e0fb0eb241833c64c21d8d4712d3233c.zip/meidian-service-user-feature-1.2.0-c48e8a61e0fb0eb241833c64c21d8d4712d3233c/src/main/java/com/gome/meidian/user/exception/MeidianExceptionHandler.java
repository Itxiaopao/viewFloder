package com.gome.meidian.user.exception;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.user.interceptor.LogInterceptor;
import com.gome.meidian.user.reponse.ResponseJson;
import com.gome.meidian.user.reponse.StatusCode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.support.RequestContext;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description  全局异常处理
 */
@ControllerAdvice
public class MeidianExceptionHandler {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@ExceptionHandler(value = Throwable.class)
	@ResponseBody
	public ResponseJson handleException(HttpServletRequest request, Throwable ex) {
		ResponseJson json = ResponseJson.getFailedResponse();
		if (ex instanceof TypeMismatchException) {
			TypeMismatchException typeEx = (TypeMismatchException) ex;
			json = new ResponseJson(StatusCode.TYPE_MISMATH.getCode());
			json.setMsg(String.format(StatusCode.TYPE_MISMATH.getMsg(), typeEx.getValue()));
		} else if (ex instanceof MissingServletRequestParameterException) {
			MissingServletRequestParameterException missingEx = (MissingServletRequestParameterException) ex;
			json = new ResponseJson(StatusCode.MISSING_REQUEST_PARAMETER.getCode());
			json.setMsg(String.format(StatusCode.MISSING_REQUEST_PARAMETER.getMsg(), missingEx.getParameterName()));
		} else if (ex instanceof HttpMessageNotReadableException) {
			return new ResponseJson(StatusCode.HTTP_MESSAGE_NOT_READABLE);
		} else if (ex instanceof MethodArgumentNotValidException) {
			MethodArgumentNotValidException manve = (MethodArgumentNotValidException) ex;
			json = produceJson(manve.getBindingResult().getFieldErrors());
		} else if (ex instanceof BindException) {
			BindException be = (BindException) ex;
			json = produceJson(be.getBindingResult().getFieldErrors());
		} else if (ex instanceof ConstraintViolationException) {
			ConstraintViolationException cve = (ConstraintViolationException) ex;
			json = produceJson(cve.getConstraintViolations()
					.toArray(new ConstraintViolation[cve.getConstraintViolations().size()]));
		} else if (ex instanceof MeidianException) {
			// 业务异常
			MeidianException MeiproException = (MeidianException) ex;
			String errorCode = MeiproException.getErrorCode();
			Object[] args = MeiproException.getArgs();
			if (errorCode != null) {
				json = produceJson(errorCode, args, request);
			}
			// } else if (ex instanceof UnauthorizedException) {
			// json = new ResponseJson(StatusCode.NO_PERMISSION.getCode());
			// json.setMsg(StatusCode.NO_PERMISSION.getMsg());

			// }
		}

		try {
			logger.error("error log, request:{}, response:{}", LogInterceptor.getRequest(request), json);
		} catch (IOException e) {
			logger.error("Get Request Error", e);
		}
		logger.error("error stackTrace log", ex);

		return json;

	}

	/**
	 * 根据验证结果，构建异常返回 默认错误编码： 默认错误提示信息：
	 *
	 * @param constraintViolations
	 * @return
	 */
	private ResponseJson produceJson(ConstraintViolation<?>[] constraintViolations) {
		ResponseJson responseJson = new ResponseJson(StatusCode.VALIDATION_FAILED);
		Map<String, Object> data = new HashMap<>();
		Map<String, String> fields;
		List<Map<String, String>> errorList = Lists.newArrayList();
		PathImpl path;
		for (ConstraintViolation<?> v : constraintViolations) {
			path = (PathImpl) v.getPropertyPath();
			fields = Maps.newHashMap();
			fields.put("field", path.getLeafNode().getName());
			fields.put("msg", v.getMessage());
			errorList.add(fields);
		}
		if (errorList.size() != 0) {
			responseJson.setMsg(errorList.get(0).get("msg"));
		}
		data.put("errors", errorList);
		responseJson.setData(data);
		return responseJson;
	}

	private ResponseJson produceJson(List<FieldError> fieldError) {
		ResponseJson responseJson = new ResponseJson(StatusCode.VALIDATION_FAILED);
		Map<String, Object> data = new HashMap<>();
		Map<String, String> fields;
		List<Map<String, String>> errorList = Lists.newArrayList();
		for (FieldError e : fieldError) {
			fields = Maps.newHashMap();
			fields.put("field", e.getField());
			fields.put("msg", e.getDefaultMessage());
			errorList.add(fields);
		}
		if (errorList.size() != 0) {
			responseJson.setMsg(errorList.get(0).get("msg"));
		}
		data.put("errors", errorList);
		responseJson.setData(data);
		return responseJson;
	}

	private ResponseJson produceJson(String errorCode, Object[] args, HttpServletRequest request) {
		RequestContext requestContext = new RequestContext(request);
		String msg = requestContext.getMessage(errorCode, args);
		String[] msgToArray = msg.split("#");
		ResponseJson responseJson = new ResponseJson();
		if (msgToArray.length == 2) {
			responseJson.setCode(Integer.valueOf(msgToArray[0]));
			responseJson.setMsg(msgToArray[1]);
		} else if (msgToArray.length == 1) {
			responseJson.setCode(StatusCode.VALIDATION_FAILED.getCode());
			responseJson.setMsg(msgToArray[0]);
		} else {
			responseJson.setCode(StatusCode.SYSTEM_ERROR.getCode());
			responseJson.setMsg(StatusCode.SYSTEM_ERROR.getMsg());
		}
		return responseJson;
	}

	/**
	 * @param errorCode
	 * @param args
	 * @param request
	 * @return
	 */
	public static String getMessage(String errorCode, Object[] args, HttpServletRequest request) {
		RequestContext requestContext = new RequestContext(request);
		String msg = requestContext.getMessage(errorCode, args);
		if (msg != null) {
			String[] msgToArray = msg.split("#");
			if (msgToArray.length == 2) {
				return msgToArray[1];
			} else {
				return msg;
			}
		}
		return null;
	}

}