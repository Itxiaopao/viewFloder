package com.gome.meidian.user.enums;

import com.gome.meidian.user.manager.MeidianBindingRelationManager;
import com.gome.meidian.user.service.UserRelationFactory;

/**
 * 用户业务关系
 */
public enum UserBizMgrEnum {

    CPA("cpa", MeidianBindingRelationManager.class, "CPA渠道用户"),
    ;

    /**
     * 业务名称
     */
    private String bizName;
    /**
     * 名
     */
    private Class<? extends UserRelationFactory> className;
    /**
     * 描述
     */
    private String desc;

    UserBizMgrEnum(String bizName, Class<? extends UserRelationFactory> className, String desc) {
        this.bizName = bizName;
        this.className = className;
        this.desc = desc;
    }

    public static UserBizMgrEnum valueOfByBizName(String bizName) {
        if (bizName == null) {
            return null;
        }
        for (UserBizMgrEnum enu : UserBizMgrEnum.values()) {
            if (enu.getBizName().equals(bizName)) {
                return enu;
            }
        }
        return null;
    }

    public static Class<? extends UserRelationFactory> getNameByBizName(String channel) {
        UserBizMgrEnum userBizMgrEnum = valueOfByBizName(channel);
        return userBizMgrEnum == null ? null : userBizMgrEnum.getClassName();
    }

    public String getBizName() {
        return bizName;
    }

    public Class<? extends UserRelationFactory> getClassName() {
        return className;
    }

    public String getDesc() {
        return desc;
    }
}
