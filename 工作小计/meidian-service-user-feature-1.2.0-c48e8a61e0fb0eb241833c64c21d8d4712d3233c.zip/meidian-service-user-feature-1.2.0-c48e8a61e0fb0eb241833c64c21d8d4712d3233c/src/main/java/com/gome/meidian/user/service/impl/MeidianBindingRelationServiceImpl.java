package com.gome.meidian.user.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.dto.MeidianBindingRelationDto;
import com.gome.meidian.user.mapper.MeidianBindingRelationMapper;
import com.gome.meidian.user.service.IMeidianBindingRelationService;

/**
 * @author limenghui
 * @create 2020-02-07 18:05
 */
@Service("meidianBindingRelationService")
public class MeidianBindingRelationServiceImpl implements IMeidianBindingRelationService {

    @Autowired MeidianBindingRelationMapper meidianBindingRelationMapper;

    @Override
    public List<MeidianBindingRelationDto> getListByParam(Map<String, Object> param) {
        return meidianBindingRelationMapper.getListByParam(param);
    }

    @Override
    public List<MeidianBindingRelationDto> getCountByStatus(Map<String, Object> param) {
        return meidianBindingRelationMapper.getCountByStatus(param);
    }

    @Override
    public MeidianBindingRelationDto queryBindingRelationByUserId(Long userId) {
        return meidianBindingRelationMapper.queryBindingRelationByUserId(userId);
    }

    @Override
    public int addBindingRelation(MeidianBindingRelationDto meidianBindingRelationDto) {
        return meidianBindingRelationMapper.addBindingRelation(meidianBindingRelationDto);
    }

    @Override
    public int updateRelationStatus(Long userId, Integer status) {
        return meidianBindingRelationMapper.updateRelationStatus(userId,status);
    }

    @Override public List<MeidianBindingRelationDto> getCountByPuserId(Map<String, Object> param) {
        return meidianBindingRelationMapper.getCountByPuserId(param);
    }

}
