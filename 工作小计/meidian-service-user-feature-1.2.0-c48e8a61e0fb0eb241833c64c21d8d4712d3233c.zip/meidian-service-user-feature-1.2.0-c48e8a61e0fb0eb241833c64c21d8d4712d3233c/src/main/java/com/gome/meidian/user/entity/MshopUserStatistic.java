package com.gome.meidian.user.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author chenchen-ds6
 * 用户管理同喜
 */
@Setter
@Getter
@ToString
public class MshopUserStatistic implements Serializable {

    private static final long serialVersionUID = 991839458426495643L;
    private Long id;
    private Long userId;
    private Long mid;
    private Long orderNum;
    private BigDecimal gmv;
    /**
     * 忠粉
     */
    private Long fidelityUser;
    /**
     * 首单
     */
    private Long firstOrder;
    private Date insertTime;
    private Date updateTime;
}
