package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 矿工信息表
 * table:md_user_center.absenteeism_count
 *
 */
public class AbsenteeismCount implements Serializable {
	private static final long serialVersionUID = 5732904926713042947L;
	private Long id;
	/**
	 * 用户ID
	 */
	private String userId;
	/**
	 * 系统赠送数量
	 */
	private Integer sysGiveCount;
	/**
	 * 用户购买数量
	 */
	private Integer userBuyCount;
	/**
	 * 系统最近一次赠送时间
	 */
	private Date sysUtime;
	/**
	 * 系统首次赠送时间
	 */
	private Date sysCtime;
	/**
	 * 购买时间
	 */
	private Date buyCtime;
	/**
	 * 更新时间
	 */
	private Date utime;
	/**
	 * 创建时间
	 */
	private Date ctime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getUtime() {
		return utime;
	}
	public void setUtime(Date utime) {
		this.utime = utime;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public Integer getSysGiveCount() {
		return sysGiveCount;
	}
	public void setSysGiveCount(Integer sysGiveCount) {
		this.sysGiveCount = sysGiveCount;
	}
	public Integer getUserBuyCount() {
		return userBuyCount;
	}
	public void setUserBuyCount(Integer userBuyCount) {
		this.userBuyCount = userBuyCount;
	}
	public Date getSysUtime() {
		return sysUtime;
	}
	public void setSysUtime(Date sysUtime) {
		this.sysUtime = sysUtime;
	}
	public Date getSysCtime() {
		return sysCtime;
	}
	public void setSysCtime(Date sysCtime) {
		this.sysCtime = sysCtime;
	}
	public Date getBuyCtime() {
		return buyCtime;
	}
	public void setBuyCtime(Date buyCtime) {
		this.buyCtime = buyCtime;
	}
	@Override
	public String toString() {
		return "AbsenteeismCount [id=" + id + ", userId=" + userId + ", sysGiveCount=" + sysGiveCount
				+ ", userBuyCount=" + userBuyCount + ", sysUtime=" + sysUtime + ", sysCtime=" + sysCtime + ", buyTime="
				+ buyCtime + ", utime=" + utime + ", ctime=" + ctime + "]";
	}

}
