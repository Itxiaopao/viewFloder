package com.gome.meidian.user.service;

import java.util.List;

import com.gome.meidian.user.entity.UserRole;
/**
 * 用户角色服务层
 *
 */
public interface UserRoleService extends BaseService<UserRole, Long> {
	/**
	 * 根据userID获取所有角色
	 * @param userId
	 * @return
	 */
	List<UserRole> findByUserId(String userId);
}
