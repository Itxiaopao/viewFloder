//package com.gome.meidian.user.config;
//
//import java.util.List;
//import java.util.Map;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.alibaba.fastjson.JSONObject;
//import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
//import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
//import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
//import com.alibaba.rocketmq.common.message.MessageExt;
//import com.gome.meidian.user.dto.MapResults;
//import com.gome.meidian.user.entity.UserInfo;
//import com.gome.meidian.user.manager.UserInfoManager;
//import com.gome.meidian.user.utils.Constants;
//
//public class MessageListener implements MessageListenerConcurrently {
//	private static Logger logger = LoggerFactory.getLogger(MessageListener.class);
//
//	@Autowired
//	private UserInfoManager userInfoManager;
//
//	public void setMessageProcessor(UserInfoManager userInfoManager) {
//		this.userInfoManager = userInfoManager;
//	}
//
//	@Override
//	public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
//		// TODO Auto-generated method stub
//        for (MessageExt msg : msgs){
////        	System.out.println("=============");
////        	System.out.println(msgs);
//        	String str = new String(msg.getBody());
////        	System.out.println(str);
//    		Map<String, Object> map = JSONObject.parseObject(str);
//    		String uStr = JSONObject.toJSONString(map.get("user"));
//
//        	UserInfo info = JSONObject.parseObject(uStr, UserInfo.class);
//        	logger.info("通过消息注册用户信息：{}", JSONObject.toJSONString(info));
//            MapResults<Object> result = userInfoManager.addUserInfoByInviteUser(info, null, Constants.GOME_SHOP_INVOKE_FROM);
//            if (!result.getSuccess()){
//            	logger.error("消息添加用户信息失败，userId:{}，异常信息:{}", info.getUserId(), result.getMessage());
//                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//            }
//        }
//        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
//    }
//
//}
