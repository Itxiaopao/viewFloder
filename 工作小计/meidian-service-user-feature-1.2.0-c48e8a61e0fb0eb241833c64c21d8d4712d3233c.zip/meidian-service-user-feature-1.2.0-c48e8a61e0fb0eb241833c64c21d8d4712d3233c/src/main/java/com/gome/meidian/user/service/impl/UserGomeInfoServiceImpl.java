package com.gome.meidian.user.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.UserGomeInfo;
import com.gome.meidian.user.mapper.UserGomeInfoMapper;
import com.gome.meidian.user.service.AbstractService;
import com.gome.meidian.user.service.UserGomeInfoService;

@Service
public class UserGomeInfoServiceImpl extends AbstractService<UserGomeInfo, Long> implements UserGomeInfoService {
	@Autowired
	private UserGomeInfoMapper userGomeInfoMapper;
	@Override
	public void setBaseMapper() {
		// TODO Auto-generated method stub
		super.baseMapper = userGomeInfoMapper;
	}
	
	/**
	 * 根据userID获取用户信息
	 */
	@Override
	public UserGomeInfo findByUserId(String userId) {
		// TODO Auto-generated method stub
		return userGomeInfoMapper.findByUserId(userId);
	}

	@Override
	public int insertUserGomeInfo(UserGomeInfo userGomeInfo) {
		return userGomeInfoMapper.add(userGomeInfo);
	}


}
