package com.gome.meidian.user.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.MeidianUserMessage;

public interface UserMessageMapper {
	
	/**
	 * 保存消息属性
	 * @param meidianUserMessage
	 * @return
	 */
	int insert(MeidianUserMessage meidianUserMessage);
	
	/**
	 * 更新消息属性
	 * @param meidianUserMessage
	 * @return
	 */
	int updateById(MeidianUserMessage meidianUserMessage);
	
	/**
	 * 查询消息属性
	 * @param userId
	 * @param formId
	 * @return
	 */
	MeidianUserMessage findOneByUserIdFormId(@Param("userId")Long userId,@Param("formId")String formId);
	
	/**
	 * 查询用户消息
	 * @param userId
	 * @param formType
	 * @param status
	 * @return
	 */
	List<MeidianUserMessage> findByUserIdFormTypeStatus(@Param("userId")Long userId,@Param("orderId")Long orderId,@Param("formType")Integer formType,@Param("status")Integer status,@Param("nowDate")Date nowDate);
	
}
