package com.gome.meidian.user.config;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.alibaba.fastjson.JSON;
import com.dianping.cat.Cat;
import com.dianping.cat.CatConstants;
import com.dianping.cat.message.Event;
import com.dianping.cat.message.Message;
import com.dianping.cat.message.Transaction;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.sql.Connection;
import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;
import java.util.StringTokenizer;

/**
 * mybatis cat扩展
 * 重写的CatMybatisInterceptor类
 * 目的是解决mybatis版本3.4.0以后的接口StatementHandler的prepare方法是两个参数（Connection connection, Integer transactionTimeout）
 * 而之前的版本该方法只有一个参数（Connection connection）
 * 除此之外，与架构组提供的包cat-client内的类没有任何区别
 *
 * @author bing.xu
 */


@Intercepts({@Signature(type = StatementHandler.class, method = "prepare", args = {Connection.class, Integer.class})
        , @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class})
        , @Signature(type = Executor.class, method = "query", args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class}),
        @Signature(type = Executor.class, method = "update", args = {MappedStatement.class, Object.class})})
public class MeidianCatMybatisInterceptor implements Interceptor {

    private static final ThreadLocal<Transaction> DB_TRANSACTION = new ThreadLocal<Transaction>();

    private static Transaction createTransaction(String method) {
        Transaction t = DB_TRANSACTION.get();
        if (t != null) {
            return t;
        } else {
            t = Cat.newTransaction(CatConstants.TYPE_SQL, StringUtils.isEmpty(method) ? "DB_ERROR" : method);
            DB_TRANSACTION.set(t);
            return t;
        }


    }

    private static String getParameterValue(Object obj) {
        String value = "null";
        if (obj instanceof String) {
            value = "'" + obj.toString() + "'";
        } else if (obj instanceof Date) {
            DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.CHINA);
            value = "'" + formatter.format((Date) obj) + "'";
        } else {
            if (obj != null) {

                value = JSON.toJSONString(obj);
            }
        }
        return value;
    }

    public static void logError(Throwable cause) {
        if (cause instanceof Error) {
            Cat.logEvent("Error", cause.getClass().getSimpleName(), "ERROR", cause.getMessage());
        } else if (cause instanceof RuntimeException) {
            Cat.logEvent("RuntimeException", cause.getClass().getSimpleName(), "ERROR", cause.getMessage());
        } else {
            Cat.logEvent("Exception", cause.getClass().getSimpleName(), "ERROR", cause.getMessage());
        }
    }

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
       /* if(!Cat.isEnable()){
            return invocation.proceed();
        }*/

        if (StatementHandler.class.isAssignableFrom(invocation.getTarget()
                .getClass())
                && "prepare".equals(invocation.getMethod().getName())) {

            StatementHandler handler = (StatementHandler) invocation
                    .getTarget();
            BoundSql boundSql = handler.getBoundSql();
            String sql = removeBreakingWhitespace(boundSql.getSql());
            String sqlParams = getParameterValue(boundSql
                    .getParameterObject());
            String method = getSqlMethod(sql);
            Connection connection = (Connection) invocation.getArgs()[0];
            String url = connection.getMetaData().getURL();
            createTransaction(invocation.getTarget().getClass()
                    .getSimpleName()
                    + ":" + method);

				/* Transaction t = DB_TRANSACTION.get();
				 if(t==null) {
					 t  = Cat.newTransaction(CatConstants.TYPE_SQL,invocation.getTarget().getClass()
								.getSimpleName()
								+ ":" + method);
					 DB_TRANSACTION.set(t);
					}*/

            Event dbEvent = Cat.newEvent("SQL.Database", url);
            dbEvent.setStatus(Message.SUCCESS);
            dbEvent.complete();
            //t.addChild(dbEvent);

            Event methodEvent = Cat.newEvent("SQL.Method", method);
            methodEvent.setStatus(Message.SUCCESS);
            methodEvent.complete();
            //t.addChild(methodEvent);

            Event sqlEvent = Cat.newEvent("SQL.Name", sql);
            sqlEvent.setStatus(Message.SUCCESS);
            sqlEvent.complete();
            //t.addChild(sqlEvent);

            Event sqlParamEvent = Cat.newEvent(CatConstants.TYPE_SQL_PARAM,
                    sqlParams);
            sqlParamEvent.setStatus(Message.SUCCESS);
            sqlParamEvent.complete();
            //t.addChild(sqlParamEvent);

            try {
                return invocation.proceed();
            } catch (Throwable throwable) {
                logError(throwable);
                createTransaction("DB_ERROR").setStatus("DB_ERROR");
                createTransaction("DB_ERROR").complete();
                reset();
                throw throwable;
            }
        } else if (Executor.class.isAssignableFrom(invocation.getTarget()
                .getClass())) {

            try {
                return invocation.proceed();
            } catch (Throwable throwable) {
                logError(throwable);
                createTransaction("DB_ERROR").setStatus("DB_ERROR");
                createTransaction("DB_ERROR").complete();
                reset();
                throw throwable;
            } finally {
                createTransaction("Default").setStatus(Message.SUCCESS);
                createTransaction("Default").complete();
                reset();
            }
        }

        return invocation.proceed();

    }

    // 请求完成后清理当前线程栈
    private void reset() {
        // destroy current thread local data
        Transaction t = DB_TRANSACTION.get();
        if (t != null) {
            DB_TRANSACTION.remove();

        }
    }

    private String getSqlMethod(String sql) {
        int firstIndexOfBlank = sql.indexOf(" ");
        return sql.substring(0, firstIndexOfBlank);
    }

    private String removeBreakingWhitespace(String original) {
        StringTokenizer whitespaceStripper = new StringTokenizer(original);
        StringBuilder builder = new StringBuilder();

        while (whitespaceStripper.hasMoreTokens()) {
            builder.append(whitespaceStripper.nextToken());
            builder.append(" ");
        }

        return builder.toString();
    }

    @Override
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    @Override
    public void setProperties(Properties properties) {

    }
}