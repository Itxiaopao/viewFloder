package com.gome.meidian.user.service.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.exceptions.BizException;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoDescFacade;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.meidian.entity.MeidianShareChangeBind;
import com.gome.meidian.service.IUserRelationService;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.SwitchType;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareChangeBinding;
import com.gome.meidian.user.enums.UserIdentityEnum;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.manager.MShopShareRecordManager;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MShopShareChangeBindingMapper;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.mq.MQProducer;
import com.gome.meidian.user.mq.data.CustomChangeShopData;
import com.gome.meidian.user.mq.data.CustomUpperShopData;
import com.gome.meidian.user.mq.data.ShopBindCustomData;
import com.gome.meidian.user.mq.data.ShopChangePianData;
import com.gome.meidian.user.service.MShopShareBindingHandleService;
import com.gome.meidian.user.service.UserRelationCacheService;
import lombok.SneakyThrows;

@Service
public class MShopShareBindingHandleServcieImpl implements MShopShareBindingHandleService {

    private static Logger logger = LoggerFactory.getLogger(MShopShareBindingServiceImpl.class);

    private final int NEW_USER_TYPE = 1;

    @Value("${mq.bigdata.topic}")
    private String TOPIC_BIGDATA;

    @Value("${mq.bigdata.switch.tag_identity}")
    private String TAG_CHANGE_SHOP; // 切换店主

    @Value("${mq.bigdata.upper.tag_custom}")
    private String TAG_UPPER_SHOP;// 升级店主

    @Value("${mq.bigdata.upper.tag_shop}")
    private String TAG_UPPER_PIAN;// 升级、降级片总

    @Value("${mq.bigdata.binding.tag}")
    private String TAG_BIND_CUSTOM;// 绑定店主

    @Autowired
    MShopShareBindingMapper mShopShareBindingMapper;

    @Autowired
    MShopShareChangeBindingMapper mShopShareChangeBindingMapper;

    @Autowired
    MShopShareRecordMapper mShopShareRecordMapper;

    @Autowired
    IUserRelationService userRelationService;

    @Autowired
    MShopShareRecordManager mShopShareRecordManager;

    @Autowired
    private UserRelationCacheService userRelationCacheService;

    @Autowired
    private VshopFacade vshopFacade;

    // 片总切换关系
    @Override
    @SneakyThrows
    @Transactional(rollbackFor = Throwable.class)
    public boolean pzUpgrade(Long userId, Long vshopId) {
        //1.自身关系
        MshopShareBinding query = new MshopShareBinding();
        query.setUserId(userId);
        MshopShareBinding mshopShareBinding = mShopShareBindingMapper.queryByParam(query);
        if (mshopShareBinding == null) {
            throw new BizException(HttpStatus.SC_BAD_REQUEST, "修改片总身份失败,原因：查不到当前店主的用户id");
        }
        mShopShareBindingMapper.removeShareBinding(mshopShareBinding.getId());
        MshopShareBinding oldShareBinding = new MshopShareBinding();
        BeanUtils.copyProperties(oldShareBinding, mshopShareBinding);
        //2.隔级店主
        query.setShareChain(mshopShareBinding.getShareChain());
        query.setIdentity(UserIdentityEnum.shopkeeper.getCode());
        List<MshopShareBinding> shopkeeperShareBindingList = mShopShareBindingMapper.queryListByChains(query);
        this.handleSubordinateRelationship(userId, vshopId, shopkeeperShareBindingList);
        //3.隔级用户
        query.setIdentity(UserIdentityEnum.custom.getCode());
        List<MshopShareBinding> customShareBindingList = mShopShareBindingMapper.queryListByChains(query);
        this.handleSubordinateRelationship(userId, vshopId, customShareBindingList);
        //4.mongodb
        mshopShareBinding.setShareChain("0");
        this.saveMogoRelation(mshopShareBinding);
        //5.履历
        MshopShareBinding thisCustomBind = new MshopShareBinding();
        thisCustomBind.setUserId(userId);
        thisCustomBind.setUpuserId(userId);
        thisCustomBind.setTopLeaderUserId(userId);
        thisCustomBind.setShareChain(userId.toString());
        addChangeRecord(oldShareBinding, thisCustomBind, 3); // 记录切换记录
        //6.店主身份
        VshopInfo vshopInfo = new VshopInfo();
        vshopInfo.setVshopId(vshopId);
        vshopInfo.setVshopType(1);
        vshopInfo.setVshopIdentity(UserIdentityEnum.topLeaderUser.getCode());
        CommonResultEntity<String> result = vshopFacade.updateVshop(vshopInfo);
        if (result.getCode() != 0) {
            throw new BizException(result.getCode(), result.getMessage());
        }
        //7.处理缓存
        userRelationCacheService.removeUserRelation(mshopShareBinding.getUserId(), mshopShareBinding.getUpuserId(), mshopShareBinding.getIdentity(), mshopShareBinding.getType());
        return Boolean.TRUE;
    }

    private void handleSubordinateRelationship(Long pzUserId, Long pzMid, List<MshopShareBinding> list) {
        if (CollectionUtils.isNotEmpty(list)) {
            for (MshopShareBinding item : list) {
                String shareChain = item.getShareChain();
                int index = shareChain.indexOf(String.valueOf(pzUserId));
                if (index == -1) {
                    logger.error("片总升级切换下级用户关系,关系链中未出现片总的用户id,用户关系如下:{}", JSON.toJSON(item));
                    continue;
                }
                item.setShareChain(shareChain.substring(index));
                item.setTopLeaderMid(pzMid);
                item.setTopLeaderUserId(pzUserId);
                int res = mShopShareBindingMapper.updateOnlyMshopShareBinding(item);
                if (res > 0) {
                    userRelationCacheService.refreshUserRelation(item);
                    this.saveMogoRelation(item);
                }

            }
        }

    }

    /**
     * @param invateMshopShareBinding 邀请上级（计算以后的，里面有邀请人userId,片总）
     * @param thisCustomBind          当前用户
     * @return
     */
    @Override
    @Transactional(rollbackFor = Throwable.class)
    public MapResults customChangeUpper(MshopShareBinding invateMshopShareBinding, MshopShareBinding thisCustomBind) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        // 查看绑定次数是否超过两次
        Long userId = thisCustomBind.getUserId();
        int count = mShopShareChangeBindingMapper.queryChangeCount(thisCustomBind.getUserId());
        if (count >= 2)
            return new MapResults<>(ExceptionCodeEnum.CHANG_UPPER_COUNT_MORE);
        else {
            MshopShareBinding oldShareBinding = new MshopShareBinding();

            try {
                BeanUtils.copyProperties(oldShareBinding, thisCustomBind);
            } catch (Exception e) {
                e.printStackTrace();
            }
            String shareChain = invateMshopShareBinding.getShareChain();
            thisCustomBind.setUpuserId(invateMshopShareBinding.getUserId());
            thisCustomBind.setUpmid(invateMshopShareBinding.getMid());
            thisCustomBind.setPmid(0L);
            thisCustomBind.setType(NEW_USER_TYPE); // 身份变成新客
            thisCustomBind.setPuserId(0L);// 与上级脱离 邀请关系
            thisCustomBind.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
            thisCustomBind.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
            thisCustomBind.setShareChain(shareChain);

            logger.info("MShopShareBindingServiceImpl--customChangeUpper-C切换B，修改的对象为：{}", thisCustomBind);
            int res = mShopShareBindingMapper.updateOnlyMshopShareBinding(thisCustomBind);
            // 修改下级
            if (res > 0) {
                addChangeRecord(oldShareBinding, thisCustomBind, 0); // 记录切换记录
                mShopShareBindingMapper.spiltRelationByPuserId(userId); // 上下级脱钩
                logger.info("MShopShareBindingServiceImpl-customChangeUpper spiltRelationByPuserId 分离下一级用户的关系，分离结果为:{}", res);
                this.saveMogoRelation(thisCustomBind);
            }
        }

        return mapResults;
    }

    /**
     * @param invateMshopShareBinding 邀请人参数
     * @param vshopId                 venusvshop那边传过来的当前userId的mid
     * @param thisCustomBind          查询绑定表中原始的绑定关系
     * @return
     */
    @Override
    @SneakyThrows
    @Transactional(rollbackFor = Throwable.class)
    public MapResults customUpToShop(Long vshopId, MshopShareBinding invateMshopShareBinding, MshopShareBinding thisCustomBind) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        Long userId = thisCustomBind.getUserId();
        if (NumberUtils.isNullOrZero(thisCustomBind.getMid())) {
            MshopShareBinding oldShareBinding = new MshopShareBinding();
            BeanUtils.copyProperties(oldShareBinding, thisCustomBind);
            // 先拿到老的对象 // 修改 当前用户 为 B
            thisCustomBind.setMid(vshopId);
            thisCustomBind.setType(3);
            thisCustomBind.setIdentity(1);
            thisCustomBind.setPmid(0L);
            thisCustomBind.setPuserId(0L);// 与上级脱离 邀请关系
            thisCustomBind.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
            thisCustomBind.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
            thisCustomBind.setUpuserId(invateMshopShareBinding.getUserId());
            thisCustomBind.setUpdateTime(new Date());
            thisCustomBind.setUpmid(invateMshopShareBinding.getMid());
            String shareChain = invateMshopShareBinding.getShareChain();
            String shareChain2 = StringUtils.isNotBlank(shareChain) && !shareChain.contains(userId.toString()) ? shareChain + "-" + userId : shareChain;
            thisCustomBind.setShareChain(shareChain2); // 修改关系链
            logger.info("MShopShareBindingServiceImpl--customUpUpper-C升级B： 修改当前C 为B 修改的对象为{}", thisCustomBind);
            int res = mShopShareBindingMapper.updateOnlyMshopShareBinding(thisCustomBind);
            if (res > 0) {
                userRelationCacheService.refreshUserRelation(oldShareBinding);
                this.saveMogoRelation(thisCustomBind);
                // 操作所有直接下级关系
                bulkUpdateRealtions(userId, vshopId, thisCustomBind);
                // 修改关系链记录数据
                mShopShareRecordMapper.updateMShopShareRecordType(6, userId);
                userRelationCacheService.removeShareRecord(thisCustomBind.getUniqueId(), userId);
                try {
                    addChangeRecord(oldShareBinding, thisCustomBind, 1); // 记录切换记录
                } catch (Exception ex) {
                    logger.error("MShopShareBindingServiceImpl--customUpUpper-C升级B：记录切换记录时异常.", ex);
                }
            }
        } else {
            logger.info("MShopShareBindingServiceImpl--customUpUpper-C升级B： 查询当前的用户不是普通用户。用户id 为{}", userId);
            mapResults = new MapResults<>(ExceptionCodeEnum.INVATED_USER_ERROR);
        }
        return mapResults;
    }

    /**
     * @param invateMshopShareBinding
     * @param newCustomBind
     * @param isCustom                true ： B-->C（C在原始绑定关系中不存在）  false： B-->C(C切换B，C在原始绑定关系中存在上级)
     * @return
     */
    @Override
    @Transactional(rollbackFor = Throwable.class)
    public MapResults shopBindUser(MshopShareBinding invateMshopShareBinding, MshopShareBinding newCustomBind, boolean isCustom) {
        MapResults<?> mapResults = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
        logger.info("C升级B的绑定关系，入参,invateMshopShareBinding:{},newCustomBind:{},isCustom:{}", invateMshopShareBinding, newCustomBind, isCustom);
        int res = addBindingRelation(newCustomBind, invateMshopShareBinding, isCustom);
        if (res > 0) {
            userRelationCacheService.refreshUserRelation(newCustomBind);
            mShopShareRecordMapper.updateMShopShareRecordType(3, newCustomBind.getUserId());
            userRelationCacheService.removeShareRecord(newCustomBind.getUniqueId(), newCustomBind.getUserId());
        }
        return mapResults;
    }

    /**
     * 推送消息到大数据
     *
     * @param type            类型（业务线分支）
     * @param userId          当前用户
     * @param invertUserId    邀请者userId
     * @param olderShopUserID 当前用户的以上的上级
     * @param gomeOldUser     是否是国美的老用户（区分B --> C 升级为店主）
     */
    @Override
    public void SendMessageToMQ(SwitchType type, Long userId, Long invertUserId, Long olderShopUserID, Boolean gomeOldUser) {
        if (type == SwitchType.Change_Shop) //用户切换店主
        {
            CustomChangeShopData chageData = new CustomChangeShopData();
            chageData.setSourceUserId(olderShopUserID);
            chageData.setTargetUserId(invertUserId);
            chageData.setUserId(userId);
            String messageBody = JSON.toJSONString(chageData);
            try {
                String messageKey = UUID.randomUUID().toString();
                SendResult sendResult = MQProducer.sendMessageSelectQueue(TOPIC_BIGDATA, TAG_CHANGE_SHOP, messageKey, messageBody, chageData.getSourceUserId().toString());
                mShopShareRecordManager.insertMessageToDB(sendResult.getMsgId(), TOPIC_BIGDATA, TAG_CHANGE_SHOP, messageKey, messageBody, sendResult.getSendStatus().toString());
            } catch (MQClientException e) {
                logger.error("SendMessageToMQ 发送消息失败,当前事物不回滚,tag:{},Exception:{}", TAG_CHANGE_SHOP, e.getMessage());
            }
        }
        if (type == SwitchType.Upper_Shop)  //用户升级为店主
        {
            CustomUpperShopData chageData = new CustomUpperShopData();
            chageData.setInviteUserId(invertUserId);
            chageData.setUserId(userId);
            chageData.setGomeOldUser(gomeOldUser);
            String messageBody = JSON.toJSONString(chageData);
            try {
                String messageKey = UUID.randomUUID().toString();
                SendResult sendResult = MQProducer.sendMessageSelectQueue(TOPIC_BIGDATA, TAG_UPPER_SHOP, messageKey, messageBody, chageData.getUserId().toString());
                mShopShareRecordManager.insertMessageToDB(sendResult.getMsgId(), TOPIC_BIGDATA, TAG_UPPER_SHOP, messageKey, messageBody, sendResult.getSendStatus().toString());
            } catch (MQClientException e) {
                logger.error("SendMessageToMQ 发送消息失败,当前事物不回滚,tag:{},Exception:{}", TAG_UPPER_SHOP, e.getMessage());
            }
        }

        if (type == SwitchType.Bind_Custom) //店主绑用户
        {
            ShopBindCustomData chageData = new ShopBindCustomData();
            chageData.setInviteUserId(invertUserId);//被绑定人
            chageData.setUserId(userId);//上级
            chageData.setAuthorization(0);
            String messageBody = JSON.toJSONString(chageData);
            try {
                String messageKey = UUID.randomUUID().toString();
                SendResult sendResult = MQProducer.sendMessageSelectQueue(TOPIC_BIGDATA, TAG_BIND_CUSTOM, messageKey, messageBody, chageData.getInviteUserId().toString());
                mShopShareRecordManager.insertMessageToDB(sendResult.getMsgId(), TOPIC_BIGDATA, TAG_BIND_CUSTOM, messageKey, messageBody, sendResult.getSendStatus().toString());
            } catch (MQClientException e) {
                logger.error("SendMessageToMQ 发送消息失败,当前事物不回滚,tag:{},Exception:{}", TAG_BIND_CUSTOM, e.getMessage());
            }
        }

        if (type == SwitchType.Upper_Pian || type == SwitchType.Down_Pian) //店主升级片总
        {
            ShopChangePianData chageData = new ShopChangePianData();
            //chageData.newAreaOwnerUserId(bindUserId); //新的片总  --降级的时候有 默认给大锤
            chageData.setUserId(userId);
            chageData.setType(type == SwitchType.Upper_Pian ? 0 : 1);
            String messageBody = JSON.toJSONString(chageData);
            try {
                String messagekey = UUID.randomUUID().toString();
                SendResult sendResult = MQProducer.sendMessageSelectQueue(TOPIC_BIGDATA, TAG_UPPER_PIAN, messagekey, messageBody, chageData.getUserId().toString());
                mShopShareRecordManager.insertMessageToDB(sendResult.getMsgId(), TOPIC_BIGDATA, TAG_UPPER_PIAN, messagekey, messageBody, sendResult.getSendStatus().toString());
            } catch (MQClientException e) {
                logger.error("SendMessageToMQ 发送消息失败，当前事务不回滚:{}", e.getMessage());
                //存入DB
            }

        }
    }

    // 记录切换历史
    private int addChangeRecord(MshopShareBinding oldShareBinding, MshopShareBinding thisCustomBind, Integer type) {
        // 修改当前的用户 以及下级用户的链条
        MshopShareChangeBinding changBindingVo = new MshopShareChangeBinding();
        changBindingVo.setLastUpuserId(oldShareBinding.getUpuserId());
        changBindingVo.setLastShareChain(oldShareBinding.getShareChain());
        changBindingVo.setLastTopLeaderUserId(oldShareBinding.getTopLeaderUserId());
        changBindingVo.setUserId(thisCustomBind.getUserId());
        changBindingVo.setUpuserId(thisCustomBind.getUpuserId());
        changBindingVo.setShareChain(thisCustomBind.getShareChain());
        changBindingVo.setTopLeaderUserId(thisCustomBind.getTopLeaderUserId());
        changBindingVo.setType(type);
        logger.info("MShopShareBindingServiceImpl-addChangeRecord 用户切换上级美店主成功,对象为:{}", changBindingVo);
        return mShopShareChangeBindingMapper.addRecord(changBindingVo);
    }

    /**
     * 批量修改直属下一级的关系
     *
     * @param userId         升级为B的userId
     * @param vshopId        升级为B的mid
     * @param thisCustomBind
     */
    private void bulkUpdateRealtions(Long userId, Long vshopId, MshopShareBinding thisCustomBind) {
        MshopShareBinding mshopShareBindingVo = new MshopShareBinding();
        mshopShareBindingVo.setPuserId(userId);
        mshopShareBindingVo.setIdentity(0); // 身份一定是用户
        List<MshopShareBinding> shopShareBindings = mShopShareBindingMapper.queryListByParam(mshopShareBindingVo);
        logger.info("MShopShareBindingServiceImpl--bindingUserRelation-C升级B 获取C下面所有的邀请用户，用户Id为{}", userId);
        if (CollectionUtils.isNotEmpty(shopShareBindings)) {
            for (MshopShareBinding bind : shopShareBindings) {
                MshopShareBinding copyBind = bind;
                // 修改当前用户的 上级链条
                bind.setUpmid(vshopId);
                bind.setUpuserId(userId);
                bind.setTopLeaderMid(thisCustomBind.getTopLeaderMid());
                bind.setTopLeaderUserId(thisCustomBind.getTopLeaderUserId());
                bind.setType(NEW_USER_TYPE); // 下游身份全部变成新客
                bind.setShareChain(thisCustomBind.getShareChain());// 记录新的链条
                bind.setPuserId(0L);
                bind.setPmid(0L);
                mShopShareBindingMapper.updateOnlyMshopShareBinding(bind);
                userRelationCacheService.refreshUserRelation(copyBind);
                this.saveMogoRelation(bind);
            }
        }

    }

    // 绑定关系
    private int addBindingRelation(MshopShareBinding mshopShareBindingVo, MshopShareBinding invateMshopShareBinding, boolean isCustom) {
        String shareChain = invateMshopShareBinding.getShareChain();
        Long userId = mshopShareBindingVo.getUserId();
        Long pUserId = invateMshopShareBinding.getUserId();
        if (!isCustom) {
            if (StringUtils.isNotBlank(shareChain) && !shareChain.contains(userId.toString())) {
                shareChain = shareChain + "-" + userId;
            } // 拼凑好链条
            mshopShareBindingVo.setType(0);
            mshopShareBindingVo.setMid(mshopShareBindingVo.getMid());
            mshopShareBindingVo.setIdentity(1);
        } else {
            if (StringUtils.isNotBlank(shareChain) && !shareChain.contains(pUserId.toString())) {
                shareChain = shareChain + "-" + pUserId;
            } // 拼凑好链条
            mshopShareBindingVo.setMid(0L);
            mshopShareBindingVo.setType(1);// 新客
            mshopShareBindingVo.setIdentity(0);
        }
        mshopShareBindingVo.setShareChain(shareChain);
        // 针对C的话
        mshopShareBindingVo.setUserId(userId);
        mshopShareBindingVo.setUpuserId(invateMshopShareBinding.getUserId()); // 上一级
        mshopShareBindingVo.setUpmid(invateMshopShareBinding.getMid());
        mshopShareBindingVo.setPuserId(invateMshopShareBinding.getUserId());
        mshopShareBindingVo.setPmid(invateMshopShareBinding.getMid());
        mshopShareBindingVo.setTopLeaderUserId(invateMshopShareBinding.getTopLeaderUserId());
        mshopShareBindingVo.setTopLeaderMid(invateMshopShareBinding.getTopLeaderMid());
        logger.info("MShopShareBindingServiceImpl--invateUserOrChangeUpper 插入绑定关系表的入参为requestParam:{}", mshopShareBindingVo);
        int res = mShopShareBindingMapper.insertMShopShareBinding(mshopShareBindingVo);
        if (res > 0) {
            this.saveMogoRelation(mshopShareBindingVo);
        }
        return res;
    }

    // 保存Modb
    public void saveMogoRelation(MshopShareBinding binding) {
        try {
            MeidianShareChangeBind bind = new MeidianShareChangeBind();
            BeanUtils.copyProperties(bind, binding);
            userRelationService.saveUserRelation(bind);
        } catch (Exception ex) {
            logger.error("保存mogoDb 出现异常", ex);
        }
    }
}
