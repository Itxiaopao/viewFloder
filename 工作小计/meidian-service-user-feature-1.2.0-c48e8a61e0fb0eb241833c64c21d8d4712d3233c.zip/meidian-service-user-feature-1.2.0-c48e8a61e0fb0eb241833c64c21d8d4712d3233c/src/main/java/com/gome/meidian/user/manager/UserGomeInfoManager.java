package com.gome.meidian.user.manager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.UserGomeInfo;
import com.gome.meidian.user.entity.UserInfo;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.UserGomeInfoService;
import com.gome.memberCore.lang.MapResult;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;

import redis.Gcache;

@Component
public class UserGomeInfoManager implements IUserGomeInfoManager{
	private static Logger logger = LoggerFactory.getLogger(UserGomeInfoManager.class);
	@Autowired
	private UserGomeInfoService userGomeInfoService;
	@Autowired
	private Gcache gcache;
	private String userGomeInfoKey = "user.center.userGomeInfo.manager";
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	//调用会员组公共参数  invokeFrom
	public static final String INVOKE_FROM = "gomeShop";

    /**
     * 判断是否为新用户(根据用户注册国美时间判断)
     * @param userId  用户Id
     * @return
     */
	@Override
	public MapResults<Boolean> isNewUser(String userId) {
		MapResults<Boolean> result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
		if (StringUtils.isBlank(userId)) {
			logger.error("获取用户信息失败，userId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			UserGomeInfo userGomeInfo = getUserNewInfoByUserId(userId);
			if (userGomeInfo == null) {
				result.setBuessObj(false);
				return result;
			}
			result.setBuessObj(true);
			// 计算是否为新老客
			// 按照国美注册时间计算
			if (userGomeInfo.getRegisterTime() != null) {
				long systemTime = System.currentTimeMillis();
				// 当前时间与注册时间相差>24小时 老用户
				if ((systemTime - userGomeInfo.getRegisterTime().getTime()) > 1000 * 60 * 60 * 24)
					result.setBuessObj(false);
			} else {
				result.setBuessObj(false);
				return result;
			}

		} catch (Exception e) {
			logger.error("判断用户新老客户信息失败，userId"+userId,e);
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}
	
	
	
	/**
	 * 获取用户信息(新老客)
	 * @param userId
	 * @return
	 * @throws ParseException 
	 */
	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
	private UserGomeInfo getUserNewInfoByUserId(String userId) throws Exception {
		UserGomeInfo userGomeInfo = null;
		if(StringUtils.isBlank(userId)) {
			return userGomeInfo;
		}
		String key = userGomeInfoKey + ":" + userId;
		String userStr = gcache.get(key);
		if(StringUtils.isNotBlank(userStr)) {
			userGomeInfo = JSONObject.parseObject(userStr, UserGomeInfo.class);
		}
		
		if(null == userGomeInfo){
			userGomeInfo = userGomeInfoService.findByUserId(userId);
			if(null != userGomeInfo) {
				gcache.set(key, JSONObject.toJSONString(userGomeInfo));
			}else{
				//查询会员组服务
				Map<String, Object> param = new HashMap<>();
				param.put("companyName", "gomeOnLine");
				MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(userId, INVOKE_FROM, param);
				if(null != userResult && userResult.isSuccess()) {
					UnifyUserInfoExt info = userResult.getBuessObj();
					if(null != info && StringUtils.isNotBlank(info.getRegisterDateSting())) {
						UserGomeInfo addUserGomeInfo = new UserGomeInfo();
						addUserGomeInfo.setUserId(userId);
						addUserGomeInfo.setRegisterTime(new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(info.getRegisterDateSting()));
						Date date = new Date();
						addUserGomeInfo.setCtime(date);
						addUserGomeInfo.setUtime(date);
						userGomeInfoService.insertUserGomeInfo(addUserGomeInfo);
						//刷新缓存
						userGomeInfo = refeshUserGomeInfoCache(userId);
					}
				}
			}
		}
		return userGomeInfo;
	}
	
	private UserGomeInfo refeshUserGomeInfoCache(String userId){
		UserGomeInfo userGomeInfo = userGomeInfoService.findByUserId(userId);
		String key = userGomeInfoKey + ":" + userId;
		if(null != userGomeInfo) {
			gcache.set(key, JSONObject.toJSONString(userGomeInfo));
		}
		return userGomeInfo;
	}

}
