package com.gome.meidian.user.mapper;

import java.util.List;

import com.gome.meidian.user.entity.Role;
/**
 * 角色数据层
 *
 */
public interface RoleMapper extends BaseMapper<Role, Short> {
	/**
	 * 获取所有角色信息
	 * @return
	 */
	List<Role> findAll();
}
