package com.gome.meidian.user.mq;

import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.manager.MShopShareRecordManager;
import com.gome.meidian.user.service.UserRelationFactory;
import com.gomeo2o.common.exceptions.BizException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UserRelationConsumer {

    @Value("${mq.address}")
    private String namesrvAddr;
    @Value("${mq.user.relation.topic}")
    private String topic;
    @Value("${mq.user.relation.group}")
    private String group;
    @Value("${mq.instance}")
    private String instanceName;

    @Autowired
    private ApplicationContext applicationContext;

    @Resource(name = "threadPoolExecutor")
    private ThreadPoolExecutor threadPoolExecutor;

    @Autowired
    private MShopShareRecordManager mShopShareRecordManager;

    @PostConstruct
    @SneakyThrows(MQClientException.class)
    public void init() {
        Map<String, UserRelationFactory> beanMap = applicationContext.getBeansOfType(UserRelationFactory.class);
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(group);
        consumer.setNamesrvAddr(namesrvAddr);
        consumer.setInstanceName(instanceName);
        consumer.subscribe(topic, "*");
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET);
        consumer.setMessageModel(MessageModel.CLUSTERING);
        consumer.registerMessageListener((MessageListenerConcurrently) (msgs, context) -> {
            MessageExt msg = msgs.get(0);
            String msgId = msg.getMsgId();
            String msgBody = new String(msg.getBody(), StandardCharsets.UTF_8);
            StringBuilder logBuilder = new StringBuilder(128);
            try {
                logBuilder.append("开始消费 msgId:").append(msgId).append(" msgBody:").append(msgBody);
                if (StringUtils.isEmpty(msgBody)) {
                    logBuilder.append(",消息体为空,即将抛弃此消息");
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }
                MshopShareRecordDto mshopShareRecordDto = JSONObject.parseObject(msgBody, MshopShareRecordDto.class);
                MapResults<MshopShareRecordDto> addMshopShareRecordResult = mShopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
                logBuilder.append(",添加绑定关系链,result:").append(JSON.toJSON(addMshopShareRecordResult));
                if (ExceptionCodeEnum.SERVICE_EXCEPTION.getErrorCode() == addMshopShareRecordResult.getCode()) {
                    throw new Exception(addMshopShareRecordResult.getMessage());
                } else if (addMshopShareRecordResult.getCode() != 0) {
                    throw new BizException(addMshopShareRecordResult.getMessage());
                }
                beanMap.forEach((k, v) -> threadPoolExecutor.execute(() -> v.process(msgId, msgBody)));
                log.info(logBuilder.toString());
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            } catch (BizException e) {
                logBuilder.append(",消费失败,失败原因:").append(e.getMessage());
                log.info(logBuilder.toString());
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            } catch (DuplicateKeyException e) {
                log.error(logBuilder.append(",发生主键冲突异常,异常堆栈如下:").toString(), e);
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            } catch (Exception e) {
                log.error(logBuilder.append(",发生异常,异常堆栈如下:").toString(), e);
                return ConsumeConcurrentlyStatus.RECONSUME_LATER;
            }
        });
        consumer.start();
        log.info("UserRelationConsumer Started... MQAddress:{} ,group:{}, topic:{}", namesrvAddr, group, topic);
    }

}