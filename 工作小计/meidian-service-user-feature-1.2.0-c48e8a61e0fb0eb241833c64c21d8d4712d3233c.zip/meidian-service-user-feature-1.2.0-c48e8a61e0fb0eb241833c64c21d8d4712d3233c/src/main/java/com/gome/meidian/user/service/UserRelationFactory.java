package com.gome.meidian.user.service;

/**
 * 用户关系工厂
 */
public interface UserRelationFactory {

    void process(String msgId, String msgBody);

}
