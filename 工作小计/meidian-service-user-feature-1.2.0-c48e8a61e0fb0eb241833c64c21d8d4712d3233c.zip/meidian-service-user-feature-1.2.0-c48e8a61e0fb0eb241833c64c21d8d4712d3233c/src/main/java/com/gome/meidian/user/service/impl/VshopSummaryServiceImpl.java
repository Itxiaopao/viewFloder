package com.gome.meidian.user.service.impl;


import com.gome.meidian.entity.MeidianShareChangeBind;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.VShopSummary;
import com.gome.meidian.service.IUserRelationService;
import com.gome.meidian.user.entity.MeidianVshopSummary;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MeidianVshopSummaryMapper;
import com.gome.meidian.user.service.VshopSummaryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class VshopSummaryServiceImpl implements VshopSummaryService {

    @Autowired
    private MShopShareBindingMapper mShopShareBindingMapper;

    @Autowired
    private MeidianVshopSummaryMapper meidianVshopSummaryMapper;

    //游客身份
    private Integer userIdIdentity = 0;

    
    Integer pageCount = 0;
    Integer pageSize = 0;

    @Autowired
    private IUserRelationService userRelationService;

    @Override
    public void task(Integer pageCount, Integer pageSize) {

        for (int i = 1; i <= (pageCount + pageSize) / pageSize; i++) {
            Integer pageIndex = (i - 1) * pageSize;
            List<MshopShareBinding> mshopShareBindings = mShopShareBindingMapper.queryByPage(pageIndex, pageSize);
            for (MshopShareBinding model : mshopShareBindings) {
                if (StringUtils.isEmpty(model.getShareChain())) {
                    //无分享链跳出本次循环
                    continue;
                }
                List<MeidianVshopSummary> list = new ArrayList<>();
                for (String userId : model.getShareChain().split("-")) {
                    if (!String.valueOf(model.getUserId()).equals(userId)) {
                        MeidianVshopSummary vo = new MeidianVshopSummary();
                        vo.setUserId(Long.valueOf(userId));
                        if (userIdIdentity.equals(model.getIdentity())) {
                            vo.setCustomNum(1L);
                        } else {
                            vo.setShopNum(1L);
                        }
                        list.add(vo);
                    }
                }
                batchOperation(list);
            }
        }
    }

    @Override
    public Boolean batchOperation(List<MeidianVshopSummary> list) {
        if (CollectionUtils.isEmpty(list)) {
            //非空集合判断
            return Boolean.TRUE;
        }
        List<MeidianVshopSummary> operRecords = new ArrayList<>(list.size());
        for (MeidianVshopSummary vo : list) {
            MeidianVshopSummary model = meidianVshopSummaryMapper.selectByUserId(vo.getUserId());
            if (model == null) {
                operRecords.add(new MeidianVshopSummary(vo.getUserId(), vo.getShopNum(), vo.getCustomNum()));
            } else {
                vo.setCustomNum(model.getCustomNum() + vo.getCustomNum());
                vo.setShopNum(model.getShopNum() + vo.getShopNum());
                operRecords.add(vo);
            }
        }

        return meidianVshopSummaryMapper.batchOperation(list) > 0;
    }

    //@Override
    public MeidianVshopSummary selectByUserId_(Long userId) {
        return meidianVshopSummaryMapper.selectByUserId(userId);
    }
    
    @Override
    public MeidianVshopSummary selectByUserId(Long userId) {
        //return meidianVshopSummaryMapper.selectByUserId(userId);
    	MeidianVshopSummary summary;
    	try {
    	ResultEntity<VShopSummary> result=userRelationService.statisticUserRelation(userId);
    	if(result.getCode()==0)
    	{
    		summary=new MeidianVshopSummary();
    		VShopSummary vshopSumm=result.getBusinessObj();
    		if(vshopSumm!=null) {
    		summary.setShopNum(vshopSumm.getVShopNum());
    		summary.setCustomNum(vshopSumm.getCustomersNum());
    		}
    		return summary;
    	}
         
    	}
    	catch(Exception ex)
    	{
    		log.error("获取统计数据异常",ex);
    	}
    return null;
    }

	@Override
	public List<MeidianVshopSummary> selectByUserIdList(List<Long> userIdList) {
		List<MeidianVshopSummary> summarys = new ArrayList<MeidianVshopSummary>();
		for (Long userId : userIdList) {
			MeidianVshopSummary summary;
			try {
				ResultEntity<VShopSummary> result = userRelationService.statisticUserRelation(userId);
				summary = new MeidianVshopSummary();
				if (result.getCode() == 0) {
					VShopSummary vshopSumm = result.getBusinessObj();
					if (vshopSumm != null) {
						summary.setUserId(userId);
						summary.setShopNum(vshopSumm.getVShopNum());
						summary.setCustomNum(vshopSumm.getCustomersNum());
						summarys.add(summary);
					}
				} else {
					summary.setUserId(userId);
					summary.setShopNum(0L);
					summary.setCustomNum(0L);
					summarys.add(summary);
				}
			} catch (Exception ex) {
				log.error("获取统计数据异常", ex);
			}
		}
		return summarys;
	}

    /**
     * 数据清洗
     *
     * @return
     */
    @Override
    public String shareBindSync(Integer pageCount, Integer pageSize) {
        Date now = new Date();
        log.info("用户关系链数据同步开始，当前时间:{}", DateFormatUtils.format(now, "yyyy-MM-dd HH:mm:ss"));
        try {
            for (int i = 1; i <= (pageCount + pageSize) / pageSize; i++) {
                Integer pageIndex = (i - 1) * pageSize;
                List<MshopShareBinding> mshopShareBindings = mShopShareBindingMapper.queryByPage(pageIndex, pageSize);
                for (MshopShareBinding model : mshopShareBindings) {
                    MeidianShareChangeBind bind = new MeidianShareChangeBind();
                    BeanUtils.copyProperties(model, bind);
                    userRelationService.saveUserRelation(bind);
                }
            }
        } catch (Exception e) {
            return "数据同步失败，失败原因" + e.getMessage();
        }

        log.info("用户关系链数据同步结束,耗时：{}ms", (new Date().getTime() - now.getTime()) / 1000);
        return "success";
    }

}
