package com.gome.meidian.user.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.Gcache;
import redis.GcacheClient;

@Configuration
public class GcacheConfig {
	@Value("${dubbo.registry.gcache_address}")
	private String zk;
	
	@Value("${gome.userCenter.redis.business}")
	private String business;
	
	@Bean(name="gcache", destroyMethod="close")
	public Gcache gcache() {
		return new GcacheClient(zk, business);
	}
	public boolean setString(String key, String field, String value) throws Exception {
		try {
			gcache().hset(key, field, value);
			return true;
		} catch (Exception e) {
			throw e;
		}
	}
	public String getString(String key,String field) throws Exception {
		try {
			return gcache().hget(key,field);
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean hexists(String key, String field) throws Exception{
		try {
			return gcache().hexists(key, field);
		}catch (Exception e){
			throw e;
		}
	}
}
