package com.gome.meidian.user.exception;


public enum ExceptionCodeEnum  {
	SUCCESS(10000, "success"),
	SERVICE_EXCEPTION(10001, "接口服务异常"),
	EMPTY_PARAM(10002, "参数为空"),
	ERROR_PARAM(10003, "参数错误"),
	SHARE_USERID_UNIQUEID_PARAM(10004,"分享着userId和uniqueId不能同时为空"),
	SHARE_PUSERID_PARAM(10005,"分享人userId为空"),
	SHARE_UNIQUEID_PARAM(10006,"用户uniqueId为空"),
	SHARE_PUNIQUEID_PARAM(10007,"分享人puniqueId为空"),
	SHARE_IMAGE_PARAM(10008,"用户头像为空"),
	SHARE_NICKNAME_PARAM(10009,"用户昵称不能为空"),
	SHARE_NEWUSER_PARAM(10009,"授权/注册标识字段不能为空"),
	SHARE_CHANNEL_PARAM(10009,"业务渠道不能为空"),
	INTERFACE_DEPRECATED(10011,"接口已下线,暂不支持此功能"),
	ADD_USER_EXISTS(20201, "用户已存在"),
	BINDING_ERROR(20202,"绑定失败"),
	NO_lOGIN_ERROR(20203,"未登录态保存分享联调异常"),
	ILLEGAL_BINDING_RELATION(20204,"无法建立绑定关系"),
	SAME_SHARE(20205,"分享人和被分享人相同"),
	USERID_EMPTY(20206,"userId为空"),
	QR_EMPTY(20207,"二位码为空"),
	WECHAT_NUM_EMPTY(20208,"微信号为空"),
	CHANGE_MID_EMPTY(20209,"邀请人userId为空"),
	INVATE_USER_EMPTY(20210,"邀请人绑定关系不存在"),
	INVATE_USER_EXISTING(20211,"邀请人绑定关系已存在"),
	UPLOAD_USER_NOEXISTING(20212,"绑定关系不存在"),
	ADD_USER_INVITEUSER_NOTEXISTS(20213, "邀请人不存在"),
	INVATED_USER_ERROR(20214,"被邀请人已经是美店主"),
	CHANG_UPPER_COUNT_MORE(20215,"被邀请人已经切换美店主关系次数过多"),
	CHANG_UPPER_SHOP_ERROR(20216,"切换上级店主与当前上级店主一致，无须切换"),
	CHANG_USER_ERROR(20217,"当前用户已经是美店主，不可以切换！"),
	CHANG_PIAN_ERROR(20218,"升级片总失败"),
	NO_INVOKE_FROM(20219,"无调用方"),
	INVITE_USER_NOT_MATCH(20220,"邀请人不是推手"),
	INVITE_USER_BINDING_NOT_MATCH(20221,"绑定关系链中邀请人不是推手的身份"),
	INTERFACE_CLOSED(20223,"接口关闭"),
	EXISTS_RELATION(20224,"推手关系已存在"),
	PUSERID_USERID_IS_EMPTY(20225,"推手userId为空或邀请者userId也为空"),
	CHANG_TYPE_QUICKLY(20222,"操作过于频繁"),
	OPEN_VSHOP_ERROR(20223,"新建店铺失败"),
	OPEN_VSHOP_EXCEPTION(20223,"保存店铺信息出现异常"),
	CHANG_UPPER_TIMEOUT(20226,"该用户不符合切换店主条件"),
	;

	private int errorCode;
	private String errorMessage;
	
	private ExceptionCodeEnum(int errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
}
