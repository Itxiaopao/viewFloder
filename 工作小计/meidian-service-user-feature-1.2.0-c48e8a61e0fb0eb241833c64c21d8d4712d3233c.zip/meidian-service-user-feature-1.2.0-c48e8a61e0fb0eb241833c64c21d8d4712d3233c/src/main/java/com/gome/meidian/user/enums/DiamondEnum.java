package com.gome.meidian.user.enums;

import com.gome.boot.adapter.norm.DiamondEnumApi;

/**
 * diamond枚举
 */
public enum DiamondEnum implements DiamondEnumApi {

    DEFAULT_HAMMER_LIST(DiamondEnumApi.STYLE_CONTAIN_KEY, "ms_service_order", "meidian_default_hammer_list", "data center的一个默认配置项"),
    MEIDIAN_CPA_ACTIVITY(DiamondEnumApi.STYLE_CONTAIN_KEY, "ms_service_order", "meidian_cpa_activity", "美店CPA活动配置"),
    CMS_DATA_PLATFORM_SWITCH(DiamondEnumApi.STYLE_CONTAIN_VALUE, "ms_service_order", "ms_report_switch", "数据平台开关 1表示打开， 0表示关闭"),
    ;

    /**
     * diamond配置风格
     * DiamondEnumApi.STYLE_CONTAIN_KEY:diamond配置内容中包含小key
     * DiamondEnumApi.STYLE_CONTAIN_VALUE:diamond配置内容中只包含value
     */
    private Integer style;

    private String group;

    private String dataId;

    private String desc;

    DiamondEnum(Integer style, String group, String dataId, String desc) {
        this.group = group;
        this.style = style;
        this.dataId = dataId;
        this.desc = desc;
    }


    @Override
    public Integer getStyle() {
        return style;
    }

    @Override
    public String getGroup() {
        return group;
    }

    @Override
    public String getDataId() {
        return dataId;
    }

    @Override
    public String getDesc() {
        return desc;
    }
}
