package com.gome.meidian.user.enums;


/**
 * 用户权益场景
 */
public enum UserRightsSceneEnum {

    //场景 1:已开团,2:已参团,3:奖励开团(系统),4:奖励参团(系统),5:奖励开团(任务),6:奖励参团(任务),7:事务补偿

    openGroup(1, 1, "开团"),
    joinGroup(2, 2, "参团"),
    sysRewardOpenGroup(3, 3, "奖励开团(系统)"),
    sysRewardJoinGroup(4, 3, "奖励参团(系统)"),
    taskRewardOpenGroup(5, 4, "奖励开团(任务)"),
    taskRewardJoinGroup(6, 4, "奖励参团(任务)"),
    compensate(9, 9, "事务补偿");

    /**
     * 通过code码取出枚举
     *
     * @param code
     * @return
     */
    public static UserRightsSceneEnum valueOf(Integer code) {
        for (UserRightsSceneEnum enu : UserRightsSceneEnum.values()) {
            if (enu.getCode().equals(code)) {
                return enu;
            }
        }
        return null;
    }

    /**
     * 是否存在场景
     *
     * @param scene
     * @return
     */
    public static boolean contain(Integer scene) {
        for (UserRightsSceneEnum enu : UserRightsSceneEnum.values()) {
            if (enu.getScene().equals(scene)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    private Integer code;//明细码
    private Integer scene;//对外场景聚合
    private String desc;//描述

    UserRightsSceneEnum(Integer code, Integer scene, String desc) {
        this.code = code;
        this.scene = scene;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Integer getScene() {
        return scene;
    }

    public void setScene(Integer scene) {
        this.scene = scene;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
