package com.gome.meidian.user.gjob;

import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

/**
 * 查看接口类的类注释信息。
 *
 * @author hushengdong
 * @create 2019-10-21 14:39:00
 */
@Service
public class GjobManager implements IGjobManager {

    private static Logger logger = LoggerFactory.getLogger(GjobManager.class);

    @Autowired
    private ApplicationContext applicationContext;

    @Override
    public MapResults<String> startMshopUserJob(String beanName, String param) {
        logger.info("[GJOB 定时任务] beanName: {} param: {}", beanName, param);
        Object object = applicationContext.getBean(beanName);
        if (object instanceof AbstractGjobService) {
            AbstractGjobService abstractGjobService = (AbstractGjobService) object;
            return abstractGjobService.execute(param);
        }
        logger.info("[GJOB 定时任务] 无效的beanName，请继承AbstractGjobService类 beanName: {} param: {}", beanName, param);
        return new MapResults<>(ExceptionCodeEnum.ERROR_PARAM);
    }
}
