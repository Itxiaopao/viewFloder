package com.gome.meidian.user.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.IOException;
import java.util.List;


/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description web初始化相关配置
 */
@ControllerAdvice
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

    /**
     * 配置Springmvc对接受数据的JSON处理属性
     * @param converters
     */
    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
        builder.serializationInclusion(JsonInclude.Include.NON_NULL);
        ObjectMapper objectMapper = builder.build();
        SimpleModule simpleModule = new SimpleModule();
        simpleModule.addSerializer(Long.class, ToStringSerializer.instance);
        objectMapper.registerModule(simpleModule);
        objectMapper.configure(MapperFeature.PROPAGATE_TRANSIENT_MARKER, true);// 忽略 transient 修饰的属性
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        converters.add(new MappingJackson2HttpMessageConverter(objectMapper));
        super.configureMessageConverters(converters);
    }

    /**
     * 读取国际化文件路径配置
     * @return
     */
    @Bean(name = "messageSource")
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource rb = new ReloadableResourceBundleMessageSource();
        rb.setBasenames("classpath:message");
        return rb;
    }

    /**
     * 自定义jackson ObjectMapper
     * @return
     */
    @Bean
    public ObjectMapper jacksonObjectMapper() {

        ObjectMapper objectMapper = new ObjectMapper();
        // objectMapper.setSerializationInclusion(Include.NON_NULL);
        objectMapper.getSerializerProvider().setNullValueSerializer(new JsonSerializer<Object>() {
            @Override
            public void serialize(Object value, JsonGenerator jg, SerializerProvider sp)
                    throws IOException, JsonProcessingException {
                // 所有null字段，重写为空字符串
                jg.writeString("");
                sp.getDefaultNullKeySerializer();
            }
        });
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        return objectMapper;
    }


    /**
     * 注入RestTemplate,方便使用http客户端
     * @return
     */
    @Bean({"restTemplate"})
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    /**
     * 注入RestTemplate,方便使用http客户端
     * @return
     */
    @Bean({"restLoadBalanced"})
    public RestTemplate restHttp() {
        return new RestTemplate();
    }

}
