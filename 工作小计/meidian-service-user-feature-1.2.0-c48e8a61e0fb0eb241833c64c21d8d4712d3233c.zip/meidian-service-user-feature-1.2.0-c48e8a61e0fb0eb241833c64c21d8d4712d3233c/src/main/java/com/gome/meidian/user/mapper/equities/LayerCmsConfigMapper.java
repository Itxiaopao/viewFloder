package com.gome.meidian.user.mapper.equities;

import com.gome.meidian.user.dto.LayerCmsConfigDto;

import java.util.List;
import java.util.Map;

public interface LayerCmsConfigMapper {
    int deleteByPrimaryKey(Long id);

    int insert(LayerCmsConfigDto record);

    int insertSelective(LayerCmsConfigDto record);

    LayerCmsConfigDto selectByPrimaryKey(Long id);

    List<LayerCmsConfigDto> selectByParam(Map<String, Object> map);

    Long queryCountByParam(Map<String, Object> map);

    int updateByPrimaryKeySelective(LayerCmsConfigDto record);

    int updateByPrimaryKey(LayerCmsConfigDto record);
}