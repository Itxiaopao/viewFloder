package com.gome.meidian.user.exception;

import com.gome.meidian.user.reponse.ResponseJson;
import com.gome.meidian.user.reponse.StatusCode;
import org.apache.catalina.connector.Response;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description  mapping处理,异常处理类,url异常处理
 */
@Controller
public class ErrorControllerHandler implements ErrorController {

    @RequestMapping(value = "/error")
    public String error(HttpServletResponse resp, HttpServletRequest req) {
        if (resp.getStatus() == HttpStatus.NOT_FOUND.value()) {
            return "forward:/error400";
        }
        return "forward:/error500";
    }

    @ResponseBody
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @RequestMapping(value = "/error400")
    public ResponseJson error404(HttpServletResponse resp, HttpServletRequest req) {
        return new ResponseJson(StatusCode.NOT_FOUND, false);
    }

    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @RequestMapping(value = "/error500")
    public ResponseJson error505(HttpServletResponse resp, HttpServletRequest req) {

        Object servletError = req.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
        ResponseJson json = null;

        if (servletError instanceof ServletException) {
            Throwable rootCause = ((ServletException) servletError).getRootCause();
//            if (rootCause instanceof UnauthorizedException) {
//                json = new ResponseJson(StatusCode.NO_PERMISSION.getCode());
//                json.setMsg(StatusCode.NO_PERMISSION.getMsg());
//            }
        }
        resp.setStatus(Response.SC_OK);
        return json == null ? new ResponseJson(StatusCode.SYSTEM_ERROR, false) : json;
    }
    
    @Override
    public String getErrorPath() {
        return "/error";
    }
}
