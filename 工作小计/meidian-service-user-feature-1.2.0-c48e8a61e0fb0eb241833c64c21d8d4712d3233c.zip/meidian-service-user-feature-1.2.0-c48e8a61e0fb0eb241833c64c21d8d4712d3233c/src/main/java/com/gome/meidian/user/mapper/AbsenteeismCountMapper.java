package com.gome.meidian.user.mapper;

import org.apache.ibatis.annotations.Param;

import com.gome.meidian.user.entity.AbsenteeismCount;
/**
 * 矿工信息数据层
 * @author lishouxu-ds
 *
 */
public interface AbsenteeismCountMapper extends BaseMapper<AbsenteeismCount, Long>{
    /**
     * 根据用户Id查询矿工信息
     * @param userId
     * @return
     */
	AbsenteeismCount findByUserId(@Param("userId")String userId);
    int updateCount(AbsenteeismCount absenteeismCount);

}
