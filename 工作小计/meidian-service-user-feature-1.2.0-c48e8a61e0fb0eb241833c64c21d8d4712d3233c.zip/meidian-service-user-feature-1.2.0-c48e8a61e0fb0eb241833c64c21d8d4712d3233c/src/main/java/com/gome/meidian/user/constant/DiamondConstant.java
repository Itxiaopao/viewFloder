package com.gome.meidian.user.constant;

/**
 * 这里是diamond的常量类
 *
 * @author hushengdong
 * @date 2019/11/12
 */
public class DiamondConstant {

    public static final String PIANZONG_USERID = "business.meidian.default.pianzong.userId";
    public static final String PIANZONG_MID = "business.meidian.default.pianzong_mid";
    public static final String PIANZONG_STID = "business.meidian.default.pianzong_stid";
    public static final String PIANZONG_ORANID = "business.meidian.default.pianzong_oranid";
    public static final String SLEDGE_HAMMER_USERID = "business.meidian.default.hammer.userId";
    public static final String SLEDGE_HAMMER_MID = "business.meidian.default.hammer.mid";
    public static final String SLEDGE_HAMMER_REGIONID = "business.meidian.default.hammer.regionid";
    public static final String SLEDGE_HAMMER_REGIONNAME = "business.meidian.default.hammer.regionname";
    public static final String SLEDGE_HAMMER_BRANCHID = "business.meidian.default.hammer.branchid";
    public static final String SLEDGE_HAMMER_BRANCHNAME = "business.meidian.default.hammer.branchname";
    public static final String SLEDGE_HAMMER_BRANCHSECONDID = "business.meidian.default.hammer.branchsecondid";
    public static final String SLEDGE_HAMMER_BRANCHSECONDNAME = "business.meidian.default.hammer.branchsecondname";
    public static final String SLEDGE_HAMMER_STORENAME = "business.meidian.default.hammer.storename";
    public static final String PROPERTY_SOURCE_NAME = "diamond";
    public static final String MEIDIAN_CPA_ACTIVITY_BUSINESSCODE= "businessCode";
    public static final String MEIDIAN_CPA_ACTIVITY_ACTIVITYID= "activityId";
}
