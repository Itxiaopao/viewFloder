package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MeidianReportUserIdentity;

import java.util.List; /**
 * 这个类用户身份表 meidian_report_user_identity
 *
 * @author hushengdong
 * @create 2019-10-22 09:54:00
 */
public interface MeidianReportUserIdentityMapper {

    void batchInsertMeidianReportUserIdentity(List<MeidianReportUserIdentity> insertList);

    void updateMeidianReportUserIdentity(MeidianReportUserIdentity meidianReportUserIdentity);

    List<Long> selectNotExistUserIdList();

    void batchDeleteMeidianReportUserIdentity(List<Long> subList);

}
