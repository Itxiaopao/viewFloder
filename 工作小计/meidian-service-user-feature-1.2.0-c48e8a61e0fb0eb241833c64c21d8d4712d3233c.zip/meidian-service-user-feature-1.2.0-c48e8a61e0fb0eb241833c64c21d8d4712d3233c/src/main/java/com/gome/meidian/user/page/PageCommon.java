package com.gome.meidian.user.page;

/**
 * Created by mzb on 2016/5/16.
 */
public class PageCommon {

    private Integer pageNo; // 当前页码
    private Integer pageSize; // 每页行数
    private Integer sort; // 排序

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }
}
