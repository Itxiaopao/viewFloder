package com.gome.meidian.user.service.impl;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.mapper.MShopWeChatMapper;
import com.gome.meidian.user.service.MShopWechatService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author chenchen-ds6
 * 微信头像昵称处理
 */
@Service
public class MShopWechatServiceImpl implements MShopWechatService {
    @Autowired
    MShopWeChatMapper mShopWeChatMapper;
    @Override
    public MshopWechatUserInfo queryWechatInfoByParam(MshopWechatUserInfo mshopWechatUserInfo) {
        return mShopWeChatMapper.queryWechatInfoByParam(mshopWechatUserInfo);
    }

    @Override
    @SneakyLog("插入微信信息")
    public int insertMShopWechatInfo(MshopWechatUserInfo mshopWechatUserInfo) {
        if(StringUtils.isNotBlank(mshopWechatUserInfo.getNickname())){
            String replace = mshopWechatUserInfo.getNickname().replace("'", "\\'");
            mshopWechatUserInfo.setNickname(replace);

        }
        return mShopWeChatMapper.insertMShopWechatInfo(mshopWechatUserInfo);
    }

    @Override
    public int updateWechatUserInfo(MshopWechatUserInfo mshopWechatUserInfo) {
        return mShopWeChatMapper.updateWechatUserInfo(mshopWechatUserInfo);
    }

    @Override
    public List<MshopWechatUserInfo> queryWeChatInfoByUniqueId(String uniqueId) {
        return mShopWeChatMapper.queryWeChatInfoByUniqueId(uniqueId);
    }

    @Override
    public MshopWechatUserInfo queryMyNextWeChatInfoByNickName(Long myUserId, String nickName) {
        return mShopWeChatMapper.queryMyNextWeChatInfoByNickName(myUserId, nickName);
    }

    @Override
    public MshopWechatUserInfo queryMyWeChatInfoByUserId(Long upUserId) {
        return mShopWeChatMapper.queryMyWeChatInfoByUserId(upUserId);
    }

    @Override
    @SneakyLog("根据uniqueId更新微信记录")
    public int updateByUniqueId(MshopWechatUserInfo mshopWechatUserInfo) {
        if(StringUtils.isNotBlank(mshopWechatUserInfo.getNickname())){
            String replace = mshopWechatUserInfo.getNickname().replace("'", "\\'");
            mshopWechatUserInfo.setNickname(replace);

        }
        return mShopWeChatMapper.updateByUniqueId(mshopWechatUserInfo);
    }

    @Override public List<MshopWechatUserInfo> queryMyNextWeChatInfoByUserIdWithPage(Long userId, Integer pageSize,
            Integer pageIndex) {
        return mShopWeChatMapper.queryMyNextWeChatInfoByUserIdWithPage(userId, pageSize, pageIndex);
    }

}
