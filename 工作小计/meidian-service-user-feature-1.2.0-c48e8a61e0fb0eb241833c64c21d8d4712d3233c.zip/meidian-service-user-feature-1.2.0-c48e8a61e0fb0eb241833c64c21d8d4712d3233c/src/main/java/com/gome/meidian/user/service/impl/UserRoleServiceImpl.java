package com.gome.meidian.user.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.user.entity.UserRole;
import com.gome.meidian.user.mapper.UserRoleMapper;
import com.gome.meidian.user.service.AbstractService;
import com.gome.meidian.user.service.UserRoleService;
@Service
public class UserRoleServiceImpl extends AbstractService<UserRole, Long> implements UserRoleService {
	@Autowired
	private UserRoleMapper userRoleMapper;
	
	/**
	 * 根据userID获取所有角色
	 */
	@Override
	public List<UserRole> findByUserId(String userId) {
		// TODO Auto-generated method stub
		return userRoleMapper.findByUserId(userId);
	}

	@Override
	public void setBaseMapper() {
		// TODO Auto-generated method stub
		super.baseMapper = userRoleMapper;
	}

}
