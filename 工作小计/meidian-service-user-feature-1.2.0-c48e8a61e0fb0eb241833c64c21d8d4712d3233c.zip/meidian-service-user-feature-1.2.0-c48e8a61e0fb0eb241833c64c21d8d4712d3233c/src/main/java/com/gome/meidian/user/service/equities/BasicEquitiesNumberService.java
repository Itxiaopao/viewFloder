package com.gome.meidian.user.service.equities;

import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;

import java.util.List;

public interface BasicEquitiesNumberService {
    public List<UserBasicEquitiesNumberDto> queryAllListGroupBYType();

    public UserBasicEquitiesNumberDto queryByType(Integer type);

    public int insertBatch(List<UserBasicEquitiesNumberDto> list);

    void updateBatch(List<UserBasicEquitiesNumberDto> list);

}
