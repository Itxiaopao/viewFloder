package com.gome.meidian.user.mq.data;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(callSuper=false)
@ToString
public class ShopBindCustomData extends MQData{

    private Integer authorization;
    
    private Long inviteUserId;
    
    private String uniqueId;
    
    private String inviteUniqueId;

	
}
