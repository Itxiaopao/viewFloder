package com.gome.meidian.user.manager;

import com.gome.meidian.user.entity.MShopShareMessage;
import com.gome.meidian.user.service.MShopShareMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author chenchen-ds6
 */
@Component
public class MShopShareMessageManager {
    private static Logger logger = LoggerFactory.getLogger(MShopShareMessageManager.class);
    @Autowired
    private MShopShareMessageService mShopShareMessageService;
    public void insertMShopMessage(MShopShareMessage mShopShareMessage){
        try {
            logger.info("插入消息表，requestParam:{}",mShopShareMessage);
            Integer i = mShopShareMessageService.insertMShopMessage(mShopShareMessage);
            if(null != i && i.equals(0)){
                logger.error("插入消息表失败，requestParam:{},result:{}",mShopShareMessage,i);
            }
        }catch (Exception e){
            logger.error("插入消息表失败，requestParam:{},Exception:{}",mShopShareMessage,e.getMessage());
        }
    }
}
