package com.gome.meidian.user.manager;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.Role;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.service.RoleService;

import redis.Gcache;

@Component
public class RoleManager implements IRoleManager{
	private static Logger logger = LoggerFactory.getLogger(RoleManager.class);
	@Autowired
	private RoleService roleService;
	@Autowired
	private Gcache gcache;
	private String roleKey = "user.center.role.manager";

	/**
	 * 获取所有角色
	 * @return
	 */
	public MapResults<List<Role>> findAll(){
		MapResults<List<Role>> result = null;
		try {
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			List<Role> roles = null;
			//缓存中获取
			String roleStr = gcache.get(roleKey);
			if(null != roleStr) {
				roles = JSONObject.parseArray(roleStr, Role.class);
				if(null != roles && roles.size() > 0) {
					return result;
				}
			}

			//缓存没有从数据库获取
			roles = roleService.findAll();
			result.setBuessObj(roles);
			if(roles != null && roles.size() > 0) {
				gcache.set(roleKey, JSONObject.toJSONString(roles));
			}
		}catch(Exception e) {
			logger.error("获取角色信息异常，message:{}", e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}

//	/**
//	 * 添加角色
//	 * @param role
//	 */
//	@Transactional(rollbackFor = Throwable.class, isolation = Isolation.READ_COMMITTED)
//	public void addRole(Role role) {
//		if(null == role) {
//			logger.error("添加角色失败，参数role为空");
//			return;
//		}
//		Date date = new Date();
//		role.setCtime(date);
//		role.setUtime(date);
//		roleService.add(role);
//		//刷新角色缓存
//		if(role != null) {
//			this.refreshRoleCache();
//		}
//	}

	/**
	 * 查询角色
	 * @param roleId
	 * @return
	 */
	public MapResults<Role> findByRoleId(Short roleId) {
		MapResults<Role> result = null;
		if(roleId == null) {
			logger.error("查询角色失败，参数roleId为空");
			result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
			return result;
		}
		try {
			result = new MapResults<>(ExceptionCodeEnum.SUCCESS.getErrorCode(), ExceptionCodeEnum.SUCCESS.getErrorMessage());
			Role role = roleService.findById(roleId);
			result.setBuessObj(role);
		}catch(Exception e) {
			logger.error("查询角色异常，roleId:{}，message:{}", roleId, e.getMessage());
			result = new MapResults<>(ExceptionCodeEnum.SERVICE_EXCEPTION);
		}
		return result;
	}

	/**
	 * 刷新角色缓存
	 */
	private void refreshRoleCache() {
		gcache.del(roleKey);
		this.findAll();
	}
}
