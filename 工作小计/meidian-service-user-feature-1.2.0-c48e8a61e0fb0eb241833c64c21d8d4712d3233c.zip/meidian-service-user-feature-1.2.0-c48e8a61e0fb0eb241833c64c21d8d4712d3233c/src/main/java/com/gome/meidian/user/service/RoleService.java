package com.gome.meidian.user.service;

import java.util.List;

import com.gome.meidian.user.entity.Role;
/**
 * 角色服务层
 *
 */
public interface RoleService extends BaseService<Role, Short> {
	/**
	 * 获取所有角色
	 * @return
	 */
	List<Role> findAll();
}
