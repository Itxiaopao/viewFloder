package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MshopUserStatistic;

/**
 * @author chenchen-ds6
 * 统计mapper
 */
public interface MShopShareStatisticMapper {
    int insertMShopShareStatistic(MshopUserStatistic mshopUserStatistic);
}
