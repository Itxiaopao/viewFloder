package com.gome.meidian.user.mapper;

import com.gome.meidian.user.entity.MeidianUserBindWechatRecord;
import org.apache.ibatis.annotations.Param;

public interface MeidianUserBindWechatRecordMapper {

    int delete(Long id);

    int insert(MeidianUserBindWechatRecord record);

    MeidianUserBindWechatRecord selectOne(@Param("id") Long id);

    int update(MeidianUserBindWechatRecord record);
}