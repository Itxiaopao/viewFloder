package com.gome.meidian.user.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * 国美店主用户user_id和身份
 * @author hushengdong
 * @date 2019-10-21
 */
@Data
public class MeidianReportUserIdentity implements Serializable {
    private static final long serialVersionUID = 6227977189864267708L;
    /**
     * id
     */
    private Long id;
    /**
     * 用户userId
     */
    private Long userId;
    /**
     * 上线user_id
     */
    private Long upUserId;
    /**
     * 顶层userId
     */
    private Long topLeaderUserid;
    /**
     * 身份 看类SkRoleEnum
     */
    private Integer identity;
    /**
     * 创建时间
     */
    private Date insertTime;
    /**
     * 更新时间
     */
    private Date updateTime;
}
