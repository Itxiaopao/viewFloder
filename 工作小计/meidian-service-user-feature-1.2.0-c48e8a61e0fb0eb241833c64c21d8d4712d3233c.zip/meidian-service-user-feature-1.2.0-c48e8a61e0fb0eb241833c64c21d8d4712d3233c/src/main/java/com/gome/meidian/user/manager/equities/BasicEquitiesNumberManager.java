package com.gome.meidian.user.manager.equities;

import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;
import com.gome.meidian.user.manager.IUserBasicEquitiesNumberManager;
import com.gome.meidian.user.service.equities.BasicEquitiesNumberService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 瓜分团基本次数的配置
 *
 * @author limenghui-ds
 * @create 2019-07-18 14:29
 */
@Component("basicEquitiesNumberManager")
@Slf4j
public class BasicEquitiesNumberManager implements IUserBasicEquitiesNumberManager {

    @Autowired
    private BasicEquitiesNumberService basicEquitiesNumberService;
    /**
     * 查询最近修改的列表配置信息
     * @return
     */
    @Override
    public List<UserBasicEquitiesNumberDto> queryAllListGroupBYType() {
        List<UserBasicEquitiesNumberDto> userBasicEquitiesNumberDtos = basicEquitiesNumberService
                .queryAllListGroupBYType();
        log.info("BasicEquitiesNumberManager.queryAllListGroupBYType.result {} ", userBasicEquitiesNumberDtos);
        return userBasicEquitiesNumberDtos;
    }

    @Override
    public UserBasicEquitiesNumberDto queryByType(Integer type) {
        UserBasicEquitiesNumberDto data = basicEquitiesNumberService.queryByType(type);
        return data;
    }

    @Override
    public int insertBatch(List<UserBasicEquitiesNumberDto> list){
        log.info("BasicEquitiesNumberManager.insertBatch.param {}", list);
        try {
            if (CollectionUtils.isNotEmpty(list)) {
                basicEquitiesNumberService.insertBatch(list);
                return 1;
            }
        } catch (Exception e) {
            log.error("BasicEquitiesNumberManager.insertBatch.param {} ,批量插入数据失败 {} ", list, e);
        }
        return 0;
    }

    @Override
    public void updateBatch(List<UserBasicEquitiesNumberDto> list) {
        log.info("BasicEquitiesNumberManager.updateBatch...............");
        basicEquitiesNumberService.updateBatch(list);
    }
}
