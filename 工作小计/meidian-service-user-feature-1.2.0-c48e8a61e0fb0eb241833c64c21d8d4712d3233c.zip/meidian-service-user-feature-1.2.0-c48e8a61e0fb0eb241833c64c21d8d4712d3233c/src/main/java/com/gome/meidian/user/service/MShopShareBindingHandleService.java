package com.gome.meidian.user.service;

import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.SwitchType;
import com.gome.meidian.user.entity.MshopShareBinding;

public interface MShopShareBindingHandleService {
	/**
	 * 切换片总
	 * @param userId
	 * @param vshopId
	 * @return
	 */
	boolean pzUpgrade(Long userId, Long vshopId);

	/**
	 * C切换上级店主
	 * @param invateMshopShareBinding
	 * @param thisCustomBind
	 * @return
	 */
	MapResults customChangeUpper(MshopShareBinding invateMshopShareBinding ,MshopShareBinding thisCustomBind);

	/**
	 * C升级为店主
	 * @param vshopId
	 * @param invateMshopShareBinding
	 * @param thisCustomBind
	 * @return
	 */
	MapResults customUpToShop(Long vshopId,MshopShareBinding invateMshopShareBinding,MshopShareBinding thisCustomBind);

	/**
	 * 店主绑定用户
	 * @param invateMshopShareBinding
	 * @param newCustomBind
	 * @param isCustom
	 * @return
	 */
	MapResults shopBindUser(MshopShareBinding invateMshopShareBinding,MshopShareBinding newCustomBind,boolean isCustom);

	/**
	 * 店主绑定用户
	 * @param type
	 * @param userId
	 * @param invertUserId
	 * @param olderShopUserID
	 * @param gomeOldUser
	 */
	  void SendMessageToMQ(SwitchType type,Long userId,Long invertUserId,Long olderShopUserID,Boolean gomeOldUser);
	  
}
