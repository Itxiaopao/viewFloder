package com.gome.meidian.user.config;

import com.github.pagehelper.PageInterceptor;
import org.apache.ibatis.plugin.Interceptor;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.taobao.tddl.group.jdbc.TGroupDataSource;

import javax.sql.DataSource;
import java.util.Properties;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 数据库信息配置
 */
@Configuration
@EnableTransactionManagement
@Profile("product")
@MapperScan(basePackages = "com.gome.meidian.user.mapper", sqlSessionFactoryRef = "userSqlSessionFactory")
public class DataSourceConfig {

	/** tddl主从集群业务名称 */
	@Value("${user.tddl.appname}")
	public String app_name;

	/** tddl主从集群分组key */
	@Value("${user.tddl.groupkey}")
	public String group_key;

	private MybaitsPageInterceptor pageInterceptor = new MybaitsPageInterceptor();


	private MeidianCatMybatisInterceptor catMybatisInterceptor = new MeidianCatMybatisInterceptor();


	/**
	 * 初始化Tddl的DataSource数据源
	 * @return
	 */
	@Bean(initMethod = "init", name = "userDataSource")
	public DataSource userDataSource() {
		TGroupDataSource dataSource = new TGroupDataSource(group_key, app_name);
		return dataSource;
	}

	/**
	 * 初始化Tddl的sqlSessionFactory数据源
	 * @param dataSource
	 * @return
	 * @throws Exception
	 */
	@Bean(name = "userSqlSessionFactory")
	public SqlSessionFactoryBean userSqlSessionFactory(@Qualifier("userDataSource") DataSource dataSource,PageInterceptor pageHelper)
			throws Exception {
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(dataSource);
		Interceptor[] interceptors = new Interceptor[2];
		interceptors[0] = pageHelper;
		interceptors[1] = catMybatisInterceptor;
		sessionFactory.setPlugins(interceptors);
		sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml"));
		sessionFactory.setTypeAliasesPackage("com.gome.meidian.user.entity");
		
		
		return sessionFactory;
	}

	/**
	 * 事务管理组件
	 * @return
	 * @throws InterruptedException 
	 */
	@Bean(name = "userTransactionManager")
	public DataSourceTransactionManager userTransactionManager() {
		return new DataSourceTransactionManager(userDataSource());
	}


	@Bean
	public PageInterceptor pageHelper() {
		PageInterceptor pageHelper = new PageInterceptor();
		Properties p = new Properties();
		p.setProperty("helperDialect", "mysql");
		p.setProperty("offsetAsPageNum", "true");
		p.setProperty("rowBoundsWithCount", "true");
		p.setProperty("reasonable", "true");
		pageHelper.setProperties(p);
		return pageHelper;
	}

}
