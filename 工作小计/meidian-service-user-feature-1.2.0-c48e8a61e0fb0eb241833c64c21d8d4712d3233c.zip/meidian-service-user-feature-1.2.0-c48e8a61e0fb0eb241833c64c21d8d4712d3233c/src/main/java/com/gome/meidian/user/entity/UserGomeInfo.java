package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 国美用户信息表
 * table:md_user_center.user_gome_info
 *
 */
public class UserGomeInfo implements Serializable {
	private static final long serialVersionUID = 8362233897870674413L;
	private Long id;
	/**
	 * 用户ID
	 */
	private String userId;
	/**
	 * 更新时间
	 */
	private Date utime;
	/**
	 * 创建时间
	 */
	private Date ctime;
	/**
	 * 国美注册时间
	 */
	private Date registerTime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getUtime() {
		return utime;
	}
	public void setUtime(Date utime) {
		this.utime = utime;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public Date getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}
	@Override
	public String toString() {
		return "UserGomeInfo [id=" + id + ", userId=" + userId + ", utime=" + utime + ", ctime=" + ctime
				+ ", registerTime=" + registerTime + "]";
	}


}
