package com.gome.meidian.user.entity;

import java.io.Serializable;
import java.util.Date;
/**
 * 用户信息
 * table:md_user_center.user_info
 *
 */
public class UserInfo implements Serializable {

	private static final long serialVersionUID = -968749028819772642L;
	private Long id;
	/**
	 * 用户ID
	 */
	private String userId;
	/**
	 * 美店ID
	 */
	private String mid;
	/**
	 * 是否员工：0-非员工，1-员工
	 */
	private String employeeType;
	/**
	 * 注册时间
	 */
	private Date registerTime;
	/**
	 * 注册IP
	 */
	private String registerIp;
	/**
	 * 新增类型
	 */
	private String createType;
	/**
	 * 渠道来源
	 */
	private String refrenceType;
	/**
	 * 用户类型：1-美店新增，2-国美老用户
	 */
	private String userType;
	/**
	 * 父级邀请userId
	 */
	private String parentInviteUserId;
	/**
	 * 添加类型：1-注册，2-激活
	 */
	private String addType;
	/**
	 * 更新时间
	 */
	private Date utime;
	/**
	 * 创建时间
	 */
	private Date ctime;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getEmployeeType() {
		return employeeType;
	}
	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
	public Date getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}
	public String getRegisterIp() {
		return registerIp;
	}
	public void setRegisterIp(String registerIp) {
		this.registerIp = registerIp;
	}
	public Date getUtime() {
		return utime;
	}
	public void setUtime(Date utime) {
		this.utime = utime;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public String getCreateType() {
		return createType;
	}
	public void setCreateType(String createType) {
		this.createType = createType;
	}
	public String getRefrenceType() {
		return refrenceType;
	}
	public void setRefrenceType(String refrenceType) {
		this.refrenceType = refrenceType;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getParentInviteUserId() {
		return parentInviteUserId;
	}
	public void setParentInviteUserId(String parentInviteUserId) {
		this.parentInviteUserId = parentInviteUserId;
	}
	public String getAddType() {
		return addType;
	}
	public void setAddType(String addType) {
		this.addType = addType;
	}


	@Override
	public String toString() {
		return "UserInfo{" +
				"id=" + id +
				", userId='" + userId + '\'' +
				", mid='" + mid + '\'' +
				", employeeType='" + employeeType + '\'' +
				", registerTime=" + registerTime +
				", registerIp='" + registerIp + '\'' +
				", createType='" + createType + '\'' +
				", refrenceType='" + refrenceType + '\'' +
				", userType='" + userType + '\'' +
				", parentInviteUserId='" + parentInviteUserId + '\'' +
				", addType='" + addType + '\'' +
				", utime=" + utime +
				", ctime=" + ctime +
				'}';
	}
}
