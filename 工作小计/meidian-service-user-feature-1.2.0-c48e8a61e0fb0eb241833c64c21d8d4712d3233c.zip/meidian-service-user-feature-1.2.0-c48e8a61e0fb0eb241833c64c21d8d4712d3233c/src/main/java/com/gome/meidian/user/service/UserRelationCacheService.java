package com.gome.meidian.user.service;

import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.entity.MshopWechatUserInfo;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 用户关系缓存处理
 */
public interface UserRelationCacheService {

    /**
     * 缓存用户关系
     *
     * @param record 记录
     */
    void setUserRelation(MshopShareBinding record);

    /**
     * 获取用户关系
     *
     * @param userId 用户id
     * @return
     */
    MshopShareBinding getUserRelation(Long userId);

    /**
     * 批量获取用户绑定关系
     *
     * @param userIdSet 用户id集合
     * @return
     */
    List<MshopShareBinding> multiGetUserRelation(Set<String> userIdSet);

    /**
     * 移除用户关系
     *
     * @param userId   用户id
     * @param upUserId 上级用户id
     * @param identity 身份id
     * @param type     用户类型(新客,首单,忠粉)
     */
    void removeUserRelation(Long userId, Long upUserId, Integer identity, Integer type);

    /**
     * 重置用户关系(查库)
     *
     * @param userId 用户id
     * @return 数据库对应的绑定数据
     */
    MshopShareBinding resetUserRelation(Long userId);

    /**
     * 移除用户关系并且修改类型
     *
     * @param mshopShareBinding 数据库中绑定表数据
     */
    void refreshUserRelation(MshopShareBinding mshopShareBinding);

    /**
     * 缓存用户邀请关系
     *
     * @param record 记录
     */
    void setShareRecord(MshopShareRecord record);


    /**
     * 移除分享关系缓存
     *
     * @param uniqueId 微信id
     * @param userId   用户id
     */
    void removeShareRecord(String uniqueId, Long userId);


    /**
     * 重置游客关系(查库)
     *
     * @param record 游客记录
     * @return 数据库中游客记录
     */
    MshopShareRecord resetShareRecord(MshopShareRecord record);

    /**
     * 刷新缓存
     *
     * @param uniqueId 微信
     * @param userId   用户id
     * @param upUserId 上级用户id
     */
    void refreshShareRecord(String uniqueId, Long userId, Long upUserId);

    /**
     * 获取下级数量
     *
     * @param userId   用户id
     * @param identity 类型 BizConstant.USER_RELATION_CUSTOMER_TYPE:用户关系 - 下级用户
     *                 BizConstant.USER_RELATION_PUSHERS_TYPE:用户关系 - 下级推手
     *                 BizConstant.SHARE_RECORD_TYPE:邀请关系
     * @param type     用户类型(新客,首单,忠粉)
     * @return
     */
    Long getSubordinateCount(Long userId, Integer identity, Integer type);

    /**
     * 根据score计算下级数量
     *
     * @param userId    用户id
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param identity  类型 BizConstant.USER_RELATION_CUSTOMER_TYPE:用户关系 - 下级用户
     *                  BizConstant.USER_RELATION_PUSHERS_TYPE:用户关系 - 下级推手
     *                  BizConstant.SHARE_RECORD_TYPE:邀请关系
     * @param type      用户类型(新客,首单,忠粉)
     * @return
     */
    Long getSubordinateCountByScore(Long userId, Double startTime, Double endTime, Integer identity, Integer type);

    /**
     * 根据score获取下级列表
     *
     * @param userId    用户id
     * @param startTime 开始时间
     * @param endTime   结束时间
     * @param identity  类型 BizConstant.USER_RELATION_CUSTOMER_TYPE:用户关系 - 下级用户
     *                  BizConstant.USER_RELATION_PUSHERS_TYPE:用户关系 - 下级推手
     *                  BizConstant.SHARE_RECORD_TYPE:邀请关系
     * @param type      用户类型(新客,首单,忠粉)
     * @return
     */
    Set<String> getSubordinateListByScore(Long userId, Double startTime, Double endTime, Integer identity, Integer type);

    /**
     * 分页获取
     *
     * @param userId
     * @param identity
     * @param type
     * @param pageIndex
     * @param pageSize
     * @return
     */
    Set<String> getSubordinatePage(Long userId, Integer identity, Integer type, Integer pageIndex, Integer pageSize);

    /**
     * 设置微信用户信息
     *
     * @param record
     */
    void setWechatUserInfo(MshopWechatUserInfo record);

    /**
     * 获取微信用户信息
     *
     * @param type     用户类型
     * @param uniqueId 微信id
     * @return
     */
    MshopWechatUserInfo getWechatUserInfo(Integer type, String uniqueId);

    /**
     * 批量获取微信用户信息
     *
     * @param type        用户类型
     * @param uniqueIdSet 微信id
     * @return
     */
    Map<String, MshopWechatUserInfo> multiGetWechatUserInfo(Integer type, Set<String> uniqueIdSet);
}
