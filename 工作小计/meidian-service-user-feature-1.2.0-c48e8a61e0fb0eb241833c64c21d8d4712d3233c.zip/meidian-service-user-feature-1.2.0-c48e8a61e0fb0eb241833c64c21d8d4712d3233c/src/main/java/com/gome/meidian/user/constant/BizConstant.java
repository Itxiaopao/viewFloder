package com.gome.meidian.user.constant;

public class BizConstant {
    //用户关系 - 下级用户
    public static final Integer USER_RELATION_CUSTOMER_TYPE = 0;
    //用户关系 - 下级推手
    public static final Integer USER_RELATION_PUSHERS_TYPE = 1;
    //邀请关系
    public static final Integer SHARE_RECORD_TYPE = 2;

    //NewUser判断新建分享关系
    public static final Integer BING_SHARE_RECORD = 0;
    //NewUser判断新建绑定关系
    public static final Integer BING_USER_RELATION = 1;
}
