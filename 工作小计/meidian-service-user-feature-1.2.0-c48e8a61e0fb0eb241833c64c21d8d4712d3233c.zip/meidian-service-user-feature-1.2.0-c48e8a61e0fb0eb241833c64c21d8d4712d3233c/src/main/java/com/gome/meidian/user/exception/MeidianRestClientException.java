package com.gome.meidian.user.exception;

import com.gome.meidian.common.exception.MeidianException;

import java.util.Arrays;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description  远程调用异常
 */
public class MeidianRestClientException  extends MeidianException {

    private String errorCode;
    private Object[] args;
    private static final long serialVersionUID = -5662172559536606637L;

    public MeidianRestClientException(String errorCode) {
        super("ERROR CODE: " + errorCode);
        this.errorCode = errorCode;
    }

    public MeidianRestClientException(String errorCode, Object... args) {
        super("ERROR CODE: " + errorCode + " ARGS:" + Arrays.toString(args));
        this.errorCode = errorCode;
        this.args = args;
    }

    public MeidianRestClientException(Exception exception) {
    }

    public String getErrorCode() {
        return this.errorCode;
    }

    public Object[] getArgs() {
        return this.args;
    }

    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
