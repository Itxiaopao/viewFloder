package com;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.service.GenericService;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoDescFacade;
import org.junit.Test;

import java.util.Map;

/**
 * 这里的注释内容，需要对类的使用做一个简单的说明。
 *
 * @author hushengdong
 * @create 2019-10-28 15:21:00
 */
public class LiveDubboTestHelper {
    @Test
    public void changePianZongDubboLive() {

        String applicationName = "meidian-service-user";
        String ipPort = "10.115.37.135:20880";
        //接口版本，没有更改为null
        Class className = IUserShareBindingManager.class;
        String functionName = "changePianZong";
        String[] paramClassName = new String[] {"java.lang.Long","int"};

        Long userId = 82816491291l;

        Object[] paramValue = new Object[] { userId,1 };
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, null);
        System.err.println("结果是：" + result);
    }
    @Test
    public void changePianZongDubboLive1() {

        String applicationName = "meidian-service-user";
        String ipPort = "10.115.37.135:20880";
        //接口版本，没有更改为null
        Class className = IUserShareBindingManager.class;
        String functionName = "changeVShop";
        String[] paramClassName = new String[] {"com.gome.meidian.user.dto.MshopShareRecordDto"};
//        Long userId = 82816491291l;
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        mshopShareRecordDto.setUserId(80390760320L);
        mshopShareRecordDto.setMid(1098925L);
        mshopShareRecordDto.setUpuserId(74830574258L);
        Object[] paramValue = new Object[] { mshopShareRecordDto};
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, null);
        System.err.println("结果是：" + result);
    }


    @Test
    public void venusVshopDubboLive() {

        String applicationName = "venus-vshop";
        String ipPort = "10.125.140.109:30003";
        //接口版本，没有更改为null
        String version = "3.0.0";
        Class className = VshopFacade.class;
        String functionName = "updateVshop";
        String[] paramClassName = new String[] {"com.gomeo2o.facade.vshop.entity.VshopInfo"};

        //组装参数
        VshopInfo vshopInfo = new VshopInfo();
        vshopInfo.setVshopId(880768);
        vshopInfo.setVshopType(1);
        vshopInfo.setUserId(78613841556L);
        vshopInfo.setVshopIdentity(1);

        Object[] paramValue = new Object[] { vshopInfo };
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, version);
        System.err.println("结果是：" + result);
    }

    @Test
    public void venusVshopDescDubboLive() {

        String applicationName = "venus-vshop";
        String ipPort = "10.125.140.109:30003";
        //接口版本，没有更改为null
        String version = "3.0.0";
        Class className = VshopInfoDescFacade.class;
        String functionName = "synVshopInfoDesc";
        String[] paramClassName = new String[] {"java.util.List"};

        //组装参数
        VshopInfoDesc vshopInfo = new VshopInfoDesc();
        vshopInfo.setUserId(82816491291L);
        vshopInfo.setOrganization("1001");
        vshopInfo.setRewardStatus(1);
        vshopInfo.setStoreCode("A00V");

        Object[] paramValue = new Object[] { vshopInfo };
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, version);
        System.err.println("结果是：" + result);
    }

    /**
     * 泛化调用 dubbo接口
     *
     * @param name               dubbo接口的应用名称 例如： venus-vshop
     * @param interfaceClassName 你要调用的接口的类 例如：VshopFacade.class
     * @param functionName       要调用的方法的名称 例如： updateVshop
     * @param paramClass         数组，入参的全路径名称 例如： com.gomeo2o.facade.vshop.entity.VshopInfo
     * @param paramValue         数组，入参值 例如： 具体的一个List
     * @param ip                 要调用的IP 例如： 10.125.140.106
     * @param port               端口 例如： 30003
     * @return 返回值
     */
    public static Map<String, Object> dubboLive(String applicationName, Class interfaceClassName, String functionName, String[] paramClass, Object[] paramValue, String ipPort,String version) {
        // dubbo 泛化调用
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(applicationName);
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连
        reference.setUrl("dubbo://" + ipPort + "?scope=remote");
        reference.setRegistry(registryConfig);
        reference.setVersion(version);
        reference.setInterface(interfaceClassName);
        //true声明为泛化接口
        reference.setGeneric(true);
        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        // 泛化调用,接口方法名称+方法参数类型+方法参数值
        Map<String, Object> result = (Map<String, Object>) genericService.$invoke(functionName, paramClass, paramValue);
        System.err.println("结果是：" + result);
        return result;
    }

}
