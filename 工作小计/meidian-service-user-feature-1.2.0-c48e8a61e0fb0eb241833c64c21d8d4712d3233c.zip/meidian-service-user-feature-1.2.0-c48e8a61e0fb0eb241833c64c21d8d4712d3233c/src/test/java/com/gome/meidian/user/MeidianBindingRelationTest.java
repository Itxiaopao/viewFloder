package com.gome.meidian.user;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gome.meidian.MeidianUserStarter;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.manager.IMeidianBindingRelationManager;
import com.gome.meidian.user.manager.MShopShareRecordManager;
import com.gome.meidian.user.manager.OpenVshopManager;
import com.gome.meidian.user.manager.UserShareBindingManager;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;

/**
 * @author limenghui
 * @create 2020-02-12 12:58
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianUserStarter.class)
@EnableAutoConfiguration
public class MeidianBindingRelationTest {
    @Autowired IMeidianBindingRelationManager meidianBindingRelationManager;

    public MeidianBindingRelationTest() {
    }

    @Test
    public void getListByParam(){

//        List<MeidianBindingRelationDto> listByParam = meidianBindingRelationManager.getListByParam(new HashMap<>());
//        System.err.println("结果是：" + listByParam);
    }
    @Test
    public void getCountByStatus(){

//        List<MeidianBindingRelationDto> listByParam = meidianBindingRelationManager.getCountByStatus(new HashMap<>());
//        System.err.println("结果是：" + listByParam);
    }
    @Test
    public void getCountByPuserId(){
//        List<MeidianBindingRelationDto> countByPuserId = meidianBindingRelationManager
//                .getCountByPuserId(new HashMap<>());
//        System.err.println("结果是：" + countByPuserId);

    }
    @Autowired
    private MShopShareRecordManager mShopShareRecordManager;
    @Autowired
    private UserShareBindingManager userShareBindingManager;

    @Test
    public void test03(){
        //社会美店主邀请  普通的c
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        mshopShareRecordDto.setUserId(123L);
        mshopShareRecordDto.setPuserId(100051309401L);
        mshopShareRecordDto.setNewUser(1);
        MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mShopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
        System.out.println(mshopShareRecordDtoMapResults.getBuessObj());
    }
    @Test
    public void test33(){
        //社会美店主邀请  普通的c (邀请人有关系链)
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        mshopShareRecordDto.setUserId(1233L);
        mshopShareRecordDto.setPuserId(100051624124L);
        mshopShareRecordDto.setNewUser(1);
        MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mShopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
        System.out.println(mshopShareRecordDtoMapResults.getBuessObj());
    }
    @Test
    public void testO4(){
        //普通用户样请普通用户
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        mshopShareRecordDto.setUserId(123L);
        mshopShareRecordDto.setPuserId(2349898989L);
        mshopShareRecordDto.setNewUser(1);
        MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mShopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
        System.out.println(mshopShareRecordDtoMapResults.getBuessObj());
    }

    @Autowired
    MShopShareBindingMapper mShopShareBindingMapper;
    @Test
    public void test05(){
        //员工认证
        MapResults mapResults = userShareBindingManager.changePianZong(100054857733L, 1);
        System.out.println(mapResults.getBuessObj());
    }

    @Test
    public void test06(){
        //员工美店主要请普通用户
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        mshopShareRecordDto.setUserId(12366888L);
//        mshopShareRecordDto.setUserId(null);
        mshopShareRecordDto.setPuserId(100051624124L);
        mshopShareRecordDto.setNewUser(1);
        MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mShopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
        System.out.println(mshopShareRecordDtoMapResults.getBuessObj());
    }
    @Autowired
    private OpenVshopManager openVshopManager;
    @Test
    public void test07(){
        //员工解绑
        MapResults<Long> longMapResults = openVshopManager.savaInitTaskShop(123L, null);
        System.out.println(longMapResults);
    }
}
