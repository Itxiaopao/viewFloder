package com.gome.meidian.user;

import com.gome.boot.adapter.config.DiamondEnv;
import com.gome.meidian.MeidianUserStarter;
import com.gome.meidian.user.constant.DiamondConstant;
import com.gome.meidian.user.dto.LayerCmsConfigDto;
import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;
import com.gome.meidian.user.enums.DiamondEnum;
import com.gome.meidian.user.manager.equities.BasicEquitiesNumberManager;
import com.gome.meidian.user.manager.equities.LayerCmsConfigManager;
import com.gome.meidian.user.mapper.equities.LayerCmsConfigMapper;
import com.gome.meidian.user.service.equities.BasicEquitiesNumberService;
import com.google.common.collect.Lists;
import org.apache.commons.beanutils.BeanUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import redis.Gcache;

import javax.annotation.Resource;
import java.lang.reflect.InvocationTargetException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author limenghui-ds
 * @create 2019-07-18 14:58
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes= MeidianUserStarter.class)
public class DividedNumberTest {
    @Autowired
    private LayerCmsConfigMapper mapper;
    @Autowired
    private LayerCmsConfigManager layerCmsConfigManager;
    @Autowired
    private BasicEquitiesNumberManager basicEquitiesNumberManager;
    @Autowired
    private BasicEquitiesNumberService basicEquitiesNumberService;
    @Test
    public void queryByType(){
        UserBasicEquitiesNumberDto result1 = basicEquitiesNumberManager.queryByType(1);
        UserBasicEquitiesNumberDto result2 = basicEquitiesNumberManager.queryByType(2);
        UserBasicEquitiesNumberDto result3 = basicEquitiesNumberManager.queryByType(3);
        UserBasicEquitiesNumberDto result0 = basicEquitiesNumberManager.queryByType(0);
        System.out.println("结果是："+result1);
        System.out.println("结果是："+result2);
        System.out.println("结果是："+result3);
        System.out.println("结果是："+result0);

    }
    @Resource
    private Gcache gcache;

    private static final String KEY = "BasicEquitiesNumber_queryByType";
    @Test
    public void delCache(){
        gcache.del(KEY);
    }

    @Test
    public void queryList(){
        List<UserBasicEquitiesNumberDto> dividedBasicNumbers = basicEquitiesNumberManager.queryAllListGroupBYType();
        System.err.println("结果是：" + dividedBasicNumbers);
    }

    @Test
    public void insertBatch(){
        List<UserBasicEquitiesNumberDto> result = Lists.newArrayList();
        for(int i=0;i<4;i++){
            UserBasicEquitiesNumberDto dto = new UserBasicEquitiesNumberDto();
            dto.setId(null);
            dto.setType(i);
            dto.setOpenCount(0);
            dto.setJoinCount(0);
            dto.setResetTime("28");
            dto.setCreateOperator("limenghui-ds");
            dto.setUpdateOperator("limenghui-ds");
            result.add(dto);
        }
        int i = basicEquitiesNumberManager.insertBatch(result);
        String hget0 = gcache.hget(KEY, 0 + "");
        String hget1 = gcache.hget(KEY, 1 + "");
        String hget2 = gcache.hget(KEY, 2 + "");
        String hget3 = gcache.hget(KEY, 3 + "");
        System.err.println("hget0：" + hget0);
        System.err.println("hget1：" + hget1);
        System.err.println("hget2：" + hget2);
        System.err.println("hget3：" + hget3);

    }
    @Test
    public void updateBatch()throws Exception{
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<UserBasicEquitiesNumberDto> dividedBasicNumbers = basicEquitiesNumberManager.queryAllListGroupBYType();
        ArrayList<UserBasicEquitiesNumberDto> updateList = Lists.newArrayList();
        for (UserBasicEquitiesNumberDto basic : dividedBasicNumbers) {
            UserBasicEquitiesNumberDto dto = new UserBasicEquitiesNumberDto();
            dto.setType(basic.getType());
            dto.setRewardJoinCount(12);
            dto.setRewardOpenCount(12);
            dto.setUpdateOperator("limenghui-ds");
            dto.setRewardBeginTime(sdf1.parse("2019-08-12 11:46:00"));
            dto.setRewardEndTime(sdf1.parse("2019-08-12 11:50:00"));
            updateList.add(dto);
        }
        basicEquitiesNumberManager.updateBatch(updateList);

        String hget0 = gcache.hget(KEY, 0 + "");
        String hget1 = gcache.hget(KEY, 1 + "");
        String hget2 = gcache.hget(KEY, 2 + "");
        String hget3 = gcache.hget(KEY, 3 + "");
        System.err.println("hget0：" + hget0);
        System.err.println("hget1：" + hget1);
        System.err.println("hget2：" + hget2);
        System.err.println("hget3：" + hget3);
    }
    @Test
    public void chooseCmsLayer(){
        Map<String, Object> param = new HashMap<>();
        param.put("1", "12");//新客
        param.put("2", "0");//游客
        param.put("4","1");//首单
        param.put("5","1");//忠粉
        param.put("userId","100049075309");//忠粉
        Map<String, String> map = layerCmsConfigManager.chooseCmsLayer(param);
        System.out.println("结果是：" + map);
        System.out.println("结果是："+map.get("imageUrl"));
        System.out.println("结果是："+map.get("pathUrl"));
    }

    private static final String chooseCmsLayerKey = "CMS_LAYER_DATE_TIME_KEY";
    @Test
    public void delCacheLayser(){
//        gcache.scanCluster("*" + chooseCmsLayerKey, 100, new KeysExecutor() {
//            @Override public void execute(List<String> keys) {
//                System.err.println("结果是：" + keys);
//            }
//        });


//        Set<String> set = jedisCluster.keys("CMS_LAYER_TIME_KEY");
//        Iterator<String> it = set.iterator();
//        while(it.hasNext()){
//            String keyStr = it.next();
//            System.err.println("结果是：" + keyStr);
////            jedis.del(keyStr);
//        }
//        gcache.del(chooseCmsLayerKey);
    }


    @Test
    public void selectByParam(){
        try {
            LayerCmsConfigDto layerCmsConfigDto = new LayerCmsConfigDto();
            Map<String, String> describe = BeanUtils.describe(layerCmsConfigDto);
            Map<String, Object> map = new HashMap<>();
            map.put("pageSize",10);
            map.put("pageIndex",0);
            map.putAll(describe);
            Long aLong = mapper.queryCountByParam(map);
            System.out.println("个数是：" + aLong);
            List<LayerCmsConfigDto> layerCmsConfigDtos = mapper.selectByParam(map);
            System.out.println("结果是：" + layerCmsConfigDtos);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        }
    }


    @Test
    public void updateWithParam(){
        List<UserBasicEquitiesNumberDto> list = Lists.newArrayList();
        for (int i = 18; i < 22; i++) {
            UserBasicEquitiesNumberDto dividedBasicNumber = new UserBasicEquitiesNumberDto();
            dividedBasicNumber.setUpdateOperator("100051198411");
            dividedBasicNumber.setRewardOpenCount(10 + i);
            dividedBasicNumber.setRewardJoinCount(100 + i);
            dividedBasicNumber.setId(new Long(i));
            list.add(dividedBasicNumber);
        }
        basicEquitiesNumberManager.updateBatch(list);
    }
    @Autowired
    DiamondEnv diamondEnv;
    @Test
    public void testDiamond(){
        String valueByKey = diamondEnv.getValue(DiamondEnum.DEFAULT_HAMMER_LIST, DiamondConstant.PIANZONG_USERID);
        String org = diamondEnv.getValue(DiamondEnum.DEFAULT_HAMMER_LIST, DiamondConstant.PIANZONG_ORANID);
        String store = diamondEnv.getValue(DiamondEnum.DEFAULT_HAMMER_LIST, DiamondConstant.PIANZONG_STID);
        boolean contains = valueByKey.contains("77818001982");
        System.out.println(contains);
        System.out.println(valueByKey.contains("72714007966"));
        System.out.println(valueByKey);
        System.out.println(org);
        System.out.println(store);
    }

}
