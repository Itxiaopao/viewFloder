package com.gome.meidian.user.manager;

import com.gome.meidian.user.BaseTestClass;
import com.gome.meidian.user.dto.MShopOwnerInfoDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopOrderUserInfoDto;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.utils.UrlUtils;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestComponent;
import redis.Gcache;

import java.util.Calendar;


public class UserRelationTest extends BaseTestClass {
	@Autowired
	private MShopShareRecordManager mshopShareRecordManager;
    @Test
	public void testShareChain0(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100051251402L);//分享者
//		mshopShareRecordDto.setPuniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt3zPZActe0xaDlG07c-PPsU");
		mshopShareRecordDto.setUserId(100051243205L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}

	@Test
	public void testShareChain1(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100049064004L);//分享者
//		mshopShareRecordDto.setPuniqueId("o0zUGt1SjQjnXdaUt186sUHD1dDw");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");
		mshopShareRecordDto.setUserId(100051251402L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}

	@Test
	public void testShareChain2(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
//		mshopShareRecordDto.setPuserId(78472321565L);//分享者
		mshopShareRecordDto.setPuniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt3zPZActe0xaDlG07c-PPsU");
		mshopShareRecordDto.setUserId(100051243205L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}
	// ==============================================
	@Test
	public void testShareChain3(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100049064004L);//分享者
//		mshopShareRecordDto.setPuniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt1SjQjnXdaUt186sUHD1dDw");
		mshopShareRecordDto.setUserId(100051209403L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}

	@Test
	public void testShareChain4(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100051209403L);//分享者
//		mshopShareRecordDto.setPuniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt_ttl7NgrQlhfiT6wt09NDo");
		mshopShareRecordDto.setUserId(100051269303L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}

	@Test
	public void testShareChain5(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100049064004L);//分享者
//		mshopShareRecordDto.setPuniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");
		mshopShareRecordDto.setUserId(100051251402L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}

	@Test
	public void testShareChain6(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100051251402L);//分享者
//		mshopShareRecordDto.setPuniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");//c--
		mshopShareRecordDto.setUniqueId("o0zUGt_ttl7NgrQlhfiT6wt09NDo");
		mshopShareRecordDto.setUserId(100051269303L);
		mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
		mshopShareRecordDto.setNickname("被窝里的猫");
		mshopShareRecordDto.setAuthorization(1);
		mshopShareRecordDto.setNewUser(0);
		MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
		System.out.println(mshopShareRecordDtoMapResults.getSuccess());
	}

	@Test
	public void testMain(){
		testShareChain0();
		testShareChain1();
		testShareChain2();
	}
	@Test
	public void testRepeatShare(){
		testShareChain3();
		testShareChain4();
		testShareChain5();
		testShareChain6();
	}
	@Autowired
	Gcache gcache;

	@Autowired
	UserShareBindingManager userShareBindingManager;
	@Test
	public void testRelation(){
		MapResults<MshopOrderUserInfoDto> mshopOrderUserInfoDtoMapResults = userShareBindingManager.queryMshopOrderDtoByUserId(100051228428L);
		System.out.println(mshopOrderUserInfoDtoMapResults.getBuessObj());
	}

	@Autowired
	MShopShareBindingService mShopShareBindingService;
	@Test
	public void testCount(){
		Integer integer = mShopShareBindingService.selectCountByUserId(1000511984111L);
		System.out.println( null != integer && integer.equals(1));
	}

	@Test
	public void testBeanUtils(){
		try {
			long l = System.currentTimeMillis();
			MshopShareRecord mshopShareRecord1 = new MshopShareRecord();
			mshopShareRecord1.setType(1);
			mshopShareRecord1.setUpuserId(123L);
			MshopShareRecord mshopShareRecord2 = new MshopShareRecord();
			System.err.println(mshopShareRecord2);
			org.springframework.beans.BeanUtils.copyProperties(mshopShareRecord1,mshopShareRecord2);
			System.out.println("result:"+mshopShareRecord2);
			long l1 = System.currentTimeMillis() - l;
			System.out.println("耗时为："+ l1);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testApacheBeanUtils(){
		try {
			long l = System.currentTimeMillis();
			MshopShareRecord mshopShareRecord1 = new MshopShareRecord();
			mshopShareRecord1.setUpuserId(123L);
			mshopShareRecord1.setType(3);
			MshopShareRecord mshopShareRecord2 = new MshopShareRecord();
			System.err.println(mshopShareRecord2);
			org.apache.commons.beanutils.BeanUtils.copyProperties(mshopShareRecord2,mshopShareRecord1);
			System.out.println("result:"+mshopShareRecord2);
			long l1 = System.currentTimeMillis() - l;
			System.out.println("耗时为："+ l1);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	@Autowired
	MShopOwnerInfoManager mShopOwnerInfoManager;
	@Test
	public void test001(){
		MapResults<MShopOwnerInfoDto> mShopOwnerInfoDtoMapResults = mShopOwnerInfoManager.queryMShopBasicInfoByUserId(100049064004L);
	}
	@Autowired
	VshopFacade vshopFacade;
	@Test
	public void test002(){
		CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId("100049064004");
		System.out.println(vshopInfoCommonResultEntity.getBusinessObj());
	}

	@Test
	public void dealWithUrl() {
		String s = UrlUtils.dealWithUrl("肖伟冬");
        String s1 = UrlUtils.dealWithUrl(s);
		System.out.println(s);
	}
	@Test
    public void testImage(){
	    try {
            MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
            mshopShareRecordDto.setImage("http%253A%252F%252Fthirdwx.qlogo.cn%252Fmmopen%252Fvi_32%252FIhPtM2TlogaJkZfEHB5icwyyOtCxEjB372mL3vXMNozXcwib7XGWLND4GtiaqG9GJS2icF6Efau8l6NibgsUemVZZLA%252F132");
            mshopShareRecordDto.setNewUser(0);
            mshopShareRecordDto.setUniqueId("o0zUGtzbYdQ_pmJLf98GlKaYNeqs");
            mshopShareRecordDto.setPuserId(100037711631L);
            mshopShareRecordDto.setAuthorization(0);
            mshopShareRecordDto.setNickname("kira");
            mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
            Thread.sleep(2000L);
        }catch(Exception e){
	        e.printStackTrace();
        }
    }

    @Test
    public void testHttp1() {
        String url= "http%3A%2F%2Fthirdwx.qlogo.cn%2Fmmopen%2Fvi_32%2FfQgjeXyAS3No6x1eP4aicD9RBicsaXKEXzLJIpyhI7qDWUaOq6dDogPG6B5pXk3ffLviaNCoCmHRicak4lNga0icXow%2F132";
        String nickName = "%E5%93%97%E5%AD%90";
        long l = System.currentTimeMillis();
        String s = UrlUtils.dealWithUrl(url);
        long l1 = System.currentTimeMillis();
        String s1 = UrlUtils.dealWithUrl(nickName);
        long l2= System.currentTimeMillis();
        long l3 = l1 - l;
        System.out.println("转义url耗时："+ l3 +"url为："+s);
        long l4 = l2 - l1;
        System.out.println("转义unickName耗时："+ l4 + "nickname为："+s1);
    }
}