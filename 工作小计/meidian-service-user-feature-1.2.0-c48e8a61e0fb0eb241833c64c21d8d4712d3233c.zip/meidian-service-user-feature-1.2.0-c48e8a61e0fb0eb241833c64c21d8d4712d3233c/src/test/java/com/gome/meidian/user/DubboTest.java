package com.gome.meidian.user;

import com.gomeo2o.facade.vshop.service.VshopFacade;
import org.junit.Assert;
import org.junit.Test;

import java.util.Map;

/**
 * 这里的注释内容，需要对类的使用做一个简单的说明。
 *
 * @author hushengdong
 * @create 2019-10-28 15:36:00
 */
public class DubboTest {

    @Test
    public void testDubboInterface() {

        Class className = VshopFacade.class;
        String functionName = "queryVshopByuserId";
        String[] paramClassName = {"java.lang.String"};
        Object[] paramValue = {"82386538531"};
        Map<String, Object> result = TestHelper.queryVenusVshopDubboLive(className, functionName, paramClassName, paramValue);
        Assert.assertNotNull(result);
    }
}
