package com.gome.meidian.user.manager;

import com.gome.meidian.user.dto.*;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gomeo2o.facade.vshop.service.VshopFacade;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.gome.meidian.user.BaseTestClass;
import com.gome.meidian.user.config.GcacheConfig;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.dto.SwitchType;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.service.MShopShareBindingHandleService;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.MShopShareRecordService;
import com.gome.meidian.user.service.MShopWechatService;
import com.gome.meidian.user.service.VshopSummaryService;
import redis.Gcache;

import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadPoolExecutor;


public class UserInfoBingTest  extends BaseTestClass{
	@Autowired
	IUserShareBindingManager iUserShareBindingManager;
	
	@Autowired
	MShopShareRecordService mShopShareRecordService;
	
	@Autowired
	MShopShareBindingService mShopShareBindingService;

	@Autowired
	MShopShareRecordManager mShopShareRecordManager;

	@Autowired
	VshopSummaryService vshopSummaryService;
	
	@Autowired
    private GcacheConfig gCacheConfig;
	
	final String key="bind_userinfo";

	@Test public void queryListByParam() {
		Map<String, Object> map = new HashMap<>();
		map.put("topLeaderUserid", 100049064004l);
		List<MShopShareBindingDto> bindingDtoList = iUserShareBindingManager.queryListByParam(map);
		System.err.println("结果是：{} " + bindingDtoList);
	}

	
	//同步B-》P 
	@Test
	public void Test11()
	{
	        for (int i=0; i<3; i++){
	           new Thread(new MyThread1()).start();
	            try {
					Thread.sleep(10l);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        }

	        try {
				Thread.sleep(100000l);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
	//b->C  B->B 测试绑定
	@Test
	public void  executeChangeM()
	{
		MshopShareRecordDto dto=new MshopShareRecordDto();
		dto.setUserId(100051430101l);
		dto.setUpuserId(100051430101l);
	    //dto.setMid(845604l);
		MapResults<?> map=iUserShareBindingManager.changeMLeader(dto);
		System.out.println(map);

	}

	@Test
	public void executeChangeVshop()
	{
		MshopShareRecordDto dto=new MshopShareRecordDto();
		dto.setUserId(100051408403l);
		dto.setUpuserId(100049064004l);
	    dto.setMid(674840l);
		MapResults<?> map=iUserShareBindingManager.changeVShop(dto);
		System.out.println(map);

	}
	
	/*  @Test
	  public void test1()
	  {
		  userShareBindingManager.queryMshopOrderDtoByUserId(100011895128l);
		  MshopRebateDto dto=new MshopRebateDto();
		  dto.setUserId(100011895128L);
		  userShareBindingManager.queryMshopRebateDtoByUserIdOrMid(dto);
	  }
	
	*/
	@Test
	public void testRepeat(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setPuniqueId("o0zUGtzQroCx0E6nnZI3AsMqqjcs");
		mshopShareRecord.setUniqueId("o0zUGt-6GABJ3HwblerMBuPFW0YM");
		MshopShareRecord mshopShareRecord1 = mShopShareRecordService.queryByUniqueIdAndPuniqueId(mshopShareRecord);
		System.out.println(mshopShareRecord1);
	}
	@Autowired
	MShopWechatService mShopWechatService;
	@Test
	public void testUpdateWechat1(){
		try {
			MshopWechatUserInfo mshopWechatUserInfo = new MshopWechatUserInfo();
			mshopWechatUserInfo.setUniqueId("o0zUGt_kqd_L57JGsDCvferQva6Q1");
//			mshopWechatUserInfo.setNickname("A💋韩国化%妆品''''''''''💄小城");
//			mshopWechatUserInfo.setNickname("常规");
//			mshopWechatUserInfo.setNickname("drop table meidian_wechat_userinfo");
//			String replace = mshopWechatUserInfo.getNickname().replace("'", "/'");
//			mshopWechatUserInfo.setNickname(replace);
//			System.out.println(replace);
//			mshopWechatUserInfo.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/gtq5IMsyia6icAvYWnvq7wAZic5mp4Gsbdc5DZjcTOiasQuZbwjvFwicFccIT5TRDmtTQ0oE8sLwUYCrJs6BhKpM5cw/132");
//			mShopWechatService.insertMShopWechatInfo(mshopWechatUserInfo);
//			mShopWechatService.updateByUniqueId(mshopWechatUserInfo);
			MshopWechatUserInfo mshopWechatUserInfo1 = mShopWechatService.queryWechatInfoByParam(mshopWechatUserInfo);
			System.out.println(mshopWechatUserInfo1);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testURLdecold(){
		try {
			String decode = URLDecoder.decode("http%3A%2F%2Fthirdwx.qlogo.cn%2Fmmopen%2Fvi_32%2FQ0j4TwGTfTJwfOvCXFum9m9iage5gxvzrbMFbLw9gxIuLatlrzkhM0Ft4QVuqBX4JkUqtyqOPXLRGT5tls6Zibsw%2F132", "UTF-8");
			System.out.println(decode);
			String decode1 = URLDecoder.decode("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJwfOvCXFum9m9iage5gxvzrbMFbLw9gxIuLatlrzkhM0Ft4QVuqBX4JkUqtyqOPXLRGT5tls6Zibsw/132", "UTF-8");
			System.out.println(decode1);
		}catch (Exception e){

		}
	}
	@Autowired
	MShopShareRecordMapper mShopShareRecordMapper;
	@Test
	public void queryByUniqueIdOrUserId(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setUserId(100051204532L);
//		mshopShareRecord.setUniqueId("o0zUGt3zPZActe0xaDlG07c-PPsU");
		List<MshopShareRecord> mshopShareRecords = mShopShareRecordMapper.queryByUniqueIdOrUserId(mshopShareRecord);
		System.out.println(mshopShareRecords);
	}

    class MyThread1 implements Runnable
	{
		@Override
		public void run() {
			System.out.println("--------------");
			//executeChangeShenfen();
			 try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	@Test
	public void testRedisPop(){
		Gcache gcache = gCacheConfig.gcache();
		while (true) {
			List<String> redis_delay_queue = gcache.blpop(1, "redis_delay_queue");
			if(null != redis_delay_queue && redis_delay_queue.size() > 0 ){
				for (int i = 0, j = redis_delay_queue.size();i < j;i++){
					System.out.println(redis_delay_queue.get(i));
				}
			}
		}
	}
	@Test
	public void testIncre(){
		try {
			Gcache gcache = gCacheConfig.gcache();
			Long testCache_meidian = gcache.setnxex("testCache_meidian", 5, "123");
			System.out.println(null != testCache_meidian && testCache_meidian.equals(1L));
			System.out.println(testCache_meidian);
			Long testCache_meidian1 = gcache.setnxex("testCache_meidian", 5, "123");
			System.out.println(null != testCache_meidian1 && testCache_meidian1.equals(1L));
			System.out.println(testCache_meidian1);
			Thread.sleep(7000L);
			Long testCache_meidian2 = gcache.setnxex("testCache_meidian", 5, "123");
			System.out.println(null != testCache_meidian2 && testCache_meidian2.equals(1L));
			System.out.println(testCache_meidian2);
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	@Autowired
	ThreadPoolExecutor threadPoolExecutor;
	@Test
	public void testGcacheWatch() throws  Exception{
		HashMap<Object, Object> hashMap = new HashMap<>();
		String testHash = "acx";
		int i = testHash.hashCode();
		System.out.println(i / 20);
		ThreadGroup threadGroup = new ThreadGroup("testGroup");
		threadGroup.setMaxPriority(1);


	}
	@Autowired
	MShopShareBindingHandleService mShopShareBindingHandleService;
	@Test
	public void SendMessageToMQ(){
		for (int i = 1;i < 100 ; i++){
			mShopShareBindingHandleService.SendMessageToMQ(SwitchType.Upper_Pian, new Long(i), 33333333L, new Long(123123+i),false);
		}
	}
	@Autowired
	VshopFacade vshopFacade;

	@Test
	public void testEmoje(){
//		mShopShareRecordManager.pushJobMessage(111L,222L,1);//executeTaskAddB
//		mShopShareRecordManager.pushJobMessage(222L,333L,0);//executeTaskAddC
		Long userIdByUniqueId0 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGt1SjQjnXdaUt186sUHD1dDw");
		Long userIdByUniqueId1 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGt_ttl7NgrQlhfiT6wt09NDo");
		Long userIdByUniqueId2 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");
		Long userIdByUniqueId3 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGtz7RqvLWd15bhMfqBH9-H0I");
		Long userIdByUniqueId4 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGtzzdacoQlYY9k-ilxjvGlDM");
		Long userIdByUniqueId5 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGt3zPZActe0xaDlG07c-PPsU");
		Long userIdByUniqueId6 = mShopShareRecordManager.queryUserIdByUniqueId("o0zUGty275yZsfBSAQioBB5OVGSY");
	}

	@Autowired
	UserShareBindingManager userShareBindingManager;
	@Test
	public void testuserShareBinding(){
		MshopRebateDto mshopRebateDto = new MshopRebateDto();
		mshopRebateDto.setUserId(100049133307L);
		MapResults<MshopRebateDto> mshopRebateDtoMapResults = userShareBindingManager.queryMshopRebateDtoByUserIdOrMid(mshopRebateDto);
		System.out.println(mshopRebateDtoMapResults);
	}
	@Autowired
	MeidianBindingRelationManager meidianBindingManager;
	@Test
	public void test001(){
		MeidianBindingRelationDto meidianBindingRelation = new MeidianBindingRelationDto();
		meidianBindingRelation.setUserId(123L);
		meidianBindingRelation.setUserId(2344L);
		meidianBindingRelation.setActivityId("123");
		meidianBindingRelation.setChannel("wap");
		meidianBindingRelation.setStatus(1);
		MapResults mapResults = meidianBindingManager.addBindingRelation(meidianBindingRelation,"");
		System.out.println(mapResults.getCode());
		System.out.println(mapResults.getSuccess());
	}
	@Test
	public void test002(){
		MapResults<MeidianBindingRelationDto> relationByUserId = meidianBindingManager.getRelationByUserId(234L,"");
		System.out.println(relationByUserId.getBuessObj());
	}
	@Test
	public void test003(){
		MapResults test = meidianBindingManager.updateRelationStatus(28L, 6, "test");
		Object buessObj = test.getBuessObj();
		System.out.println(buessObj);
	}
	@Autowired
	IMShopOwnerInfoManager imShopOwnerInfoManager;
	@Autowired
	IMeidianBindingRelationManager iMeidianBindingRelationManager;
	@Test
	public void test004(){
//		MapResults<MshopSolicitingVo> mshopSolicitingVoMapResults = imShopOwnerInfoManager.queryMshopSolicitingInfo(100051624115L, 100049055306L);

		MeidianBindingRelationDto meidianBindingRelationDto = new MeidianBindingRelationDto();
		meidianBindingRelationDto.setUserId(100051627157L);
		meidianBindingRelationDto.setPuserId(100039501030L);
		meidianBindingRelationDto.setChannel("cpa");
		iMeidianBindingRelationManager.addBindingRelation(meidianBindingRelationDto,"shangcheng");
		meidianBindingRelationDto.setPuserId(0L);
		System.out.println(meidianBindingRelationDto.getPuserId() == 0L);
		System.out.println(meidianBindingRelationDto.getPuserId().equals(0L));
	}
}
