package com.gome.meidian.user.mapper;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.BeforeClass;
import org.junit.Test;

import com.gome.meidian.user.dto.MeidianBindingRelationDto;

/**
 * @author limenghui
 * @create 2020-02-08 19:17
 */
public class MeidianBindingRelationMapperTest {

    private static MeidianBindingRelationMapper mapper;

    @BeforeClass public static void setUpMybatisDatabase() {
        SqlSessionFactory builder = new SqlSessionFactoryBuilder()
                .build(MeidianBindingRelationMapperTest.class.getClassLoader().getResourceAsStream(
                        "mybatisTestConfiguration/MeidianBindingRelationMapperTestConfiguration.xml"));
        // you can use builder.openSession(false) to not commit to database
        mapper = builder.getConfiguration().getMapper(MeidianBindingRelationMapper.class, builder.openSession(true));
    }

    @Test public void testgetCountByStatus() throws FileNotFoundException {
        Map<String, Object> param = new HashMap<>();
        param.put("beginTime", "2020-02-08 14:46:17");
        param.put("endTime", "2020-02-08 18:38:30");
        param.put("puserId", 1);
        List<MeidianBindingRelationDto> countByStatus = mapper.getCountByStatus(param);
        System.err.println("结果是：" + countByStatus);
    }

    @Test public void testgetListByParam() throws FileNotFoundException {
        Map<String, Object> param = new HashMap<>();
        param.put("puserId", 1);
        param.put("pageIndex", 0);
        param.put("pageSize", 3);
        // todo 确定是否需要查询活动ID
        List<MeidianBindingRelationDto> listByParam = mapper.getListByParam(param);
        System.err.println("结果是：" + listByParam);
    }

    @Test public void testgetCountByPuserId() throws FileNotFoundException {
        Map<String, Object> param = new HashMap<>();
        param.put("pageSize", 30);
        List<MeidianBindingRelationDto> countByPuserId = mapper.getCountByPuserId(param);
        System.err.println("结果是：" + countByPuserId);
    }
}
