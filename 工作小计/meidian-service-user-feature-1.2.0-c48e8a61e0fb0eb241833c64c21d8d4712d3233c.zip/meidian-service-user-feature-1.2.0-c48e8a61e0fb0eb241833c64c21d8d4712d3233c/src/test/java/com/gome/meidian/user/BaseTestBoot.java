
package com.gome.meidian.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.test.context.ActiveProfiles;

@EnableScheduling
@SpringBootApplication
@ActiveProfiles("test")
public class BaseTestBoot {
	public static void main(String[] args) {
		SpringApplication.run(BaseTestBoot.class, args);
	}
}
