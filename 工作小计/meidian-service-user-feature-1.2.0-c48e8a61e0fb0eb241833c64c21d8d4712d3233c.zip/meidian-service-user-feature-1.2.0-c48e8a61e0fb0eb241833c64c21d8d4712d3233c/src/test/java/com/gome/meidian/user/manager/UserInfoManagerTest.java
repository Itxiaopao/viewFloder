package com.gome.meidian.user.manager;

import cn.com.gome.gis.dto.GisResultDto;
import cn.com.gome.gis.dubbo.CommonUploadService;
import com.alibaba.fastjson.JSON;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.user.BaseTestClass;
import com.gome.meidian.user.config.GcacheConfig;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopRebateDto;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.entity.*;
import com.gome.meidian.user.exception.ExceptionCodeEnum;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.mapper.MShopShareStatisticMapper;
import com.gome.meidian.user.mapper.MShopWeChatMapper;
import com.gome.meidian.user.mapper.UserInfoMapper;
import com.gome.meidian.user.page.Page;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.MShopWechatService;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import com.gome.userBase.model.weChat.GomeShopBasicInfoModel;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import redis.Gcache;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


public class UserInfoManagerTest extends BaseTestClass {
	@Autowired
	private UserInfoManager userInfoManager;
	@Autowired
	private UserRelationManager userRelationManager;
	@Autowired
	private UserRoleManager userRoleManager;
	String invokeFrom = "gomeShop";
	@Autowired
	private UserInfoMapper userInfoMapper;
	@Autowired
	private MShopShareRecordManager mshopShareRecordManager;
	@Autowired
	MShopShareBindingMapper mShopShareBindingMapper;

	//添加用户信息-手机号
	@Test
	public void addUserInfo() throws ServiceException {
		UserInfo user = new UserInfo();
		user.setUserId("100040422116");
		user.setAddType("1");
		user.setCreateType("1");
		
		String phone = "";
		userInfoManager.addUserInfoByInviteUser(user, phone, invokeFrom);
	}
	
	//获取用户信息
	@Test
	public void findUserInfoByUserId() {
		String userId = "";
		MapResults<UserInfo> result = userInfoManager.findUserInfoByUserId(userId);
		System.out.println("==========================");
		System.out.println("==========================");
		System.out.println("==========================");
		System.out.println(JSON.toJSONString(result));
		System.out.println("==========================");
		System.out.println("==========================");
		System.out.println("==========================");
	}
	
	//同步mid
	@Test
	public void modifyUserInfo() {
		String userId = "100040422116";
		String mid = "222";
		System.out.println(userInfoManager.modifyUserInfo(userId, mid));
	}
	
	//用户绑定关系
	@Test
	public void addUserRelation() {
		UserRelation relation = new UserRelation();
		relation.setUserId("100049399944");
		relation.setUnionId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");
		relation.setOpenId("oJ5y11DyQ3KBbK-PAmheHLd34cn4");
		userRelationManager.addUserRelation(relation);
	}
	
	//删除用户绑定关系
	@Test
	public void deleteUserRelation() {
		Long id = 1L;
		userRelationManager.deleteUserRelation(id);
	}
	
	//修改绑定
	@Test
	public void updateUserRelation() {
		UserRelation relation = new UserRelation();
		relation.setId(1L);
		relation.setUnionId("222");
		relation.setOpenId("3333333");
		userRelationManager.updateUserRelation(relation);
	}
	
	//获取绑定
	@Test
	public void findByUserId() {
		String userId = "100040422116";
		System.out.println(JSON.toJSONString(userRelationManager.findByUserId(userId)));
	}

	@Test
	public void addUserRole(){
		String userId = "100049398409";
		String roleId = "1";
		userRoleManager.addUserRole(userId, roleId);
	}

	@Test
	public void modifyMDUserRole(){
		String userId = "100049398409";
		userRoleManager.modifyMDUserRole(userId);
	}

	@Test
	public void test(){
		Map<String, Object> map=new HashMap<String,Object>();
		Page page=Page.newBuilder(1,10,"user_info");
		map.put("page",page);
		List<UserInfo> list=userInfoMapper.findByQuery(map);
		for (UserInfo userInfo :list) {
			System.out.println("UserInfo :"+userInfo);
		}

	}




	@Test
	public void testCount(){
		Integer list=userInfoMapper.findCountUserInfo();
		System.out.println("UserInfoCount :"+list);

	}

	@Test
	public void test001(){

		MapResults result = new MapResults<>(ExceptionCodeEnum.EMPTY_PARAM);
		System.out.println(result.getCode());
		System.out.println(result.getMessage());
		System.out.println(result.getSuccess());
		System.out.println(result.getBuessObj());
	}
    @Autowired
    MShopShareRecordMapper mshopShareRecordMapper;


	@Test
	public void test002(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setPuserId(1L);
		mshopShareRecord.setPmid(1L);
		mshopShareRecord.setPuniqueId("1L");
		mshopShareRecord.setUniqueId("1");
		mshopShareRecord.setUserId(1L);
		mshopShareRecord.setMid(123L);
		mshopShareRecord.setUpuserId(1L);
		mshopShareRecord.setUpmid(1L);
		mshopShareRecord.setType(1);
		mshopShareRecord.setPtype(1);
//		mshopShareRecordMapper.insertMShopShareRecord(mshopShareRecord);
    }

	@Test
	public void test003(){
		MshopShareBinding mshopShareBinding = new MshopShareBinding();
		mshopShareBinding.setUserId(10000000003l);
		mshopShareBinding.setUpmid(845435l);
		mshopShareBinding.setUpuserId(100049064004L);
		mshopShareBinding.setPuserId(10000000001l);
		mshopShareBinding.setPmid(845435l);
		mshopShareBinding.setTopLeaderMid(845435l);
		mshopShareBinding.setTopLeaderUserId(100049064004l);
		mshopShareBinding.setShareChain("100049064004");
		mShopShareBindingMapper.insertMShopShareBinding(mshopShareBinding);
	}
	@Autowired
	MShopWeChatMapper mShopWeChatMapper;
	@Test
	public void test004(){
		MshopWechatUserInfo mshopWechatUserInfo = new MshopWechatUserInfo();
		mshopWechatUserInfo.setUniqueId("uniqueId");
		mshopWechatUserInfo.setPhoneMobile(15652126663L);
		mshopWechatUserInfo.setMid(123L);
		mshopWechatUserInfo.setImage("image");
		mshopWechatUserInfo.setNickname("nickename");
		//mshopWechatUserInfo.setWechatNum(6666666L);
		mShopWeChatMapper.insertMShopWechatInfo(mshopWechatUserInfo);
	}
	@Autowired
	MShopShareStatisticMapper mShopShareStatisticMapper;
	@Test
	public void test005(){
		MshopUserStatistic mshopUserStatistic = new MshopUserStatistic();
		mshopUserStatistic.setMid(1L);
		mshopUserStatistic.setUserId(2L);
		mshopUserStatistic.setFidelityUser(12L);
		mshopUserStatistic.setFirstOrder(1L);
		mshopUserStatistic.setGmv(new BigDecimal(100000));
		mshopUserStatistic.setOrderNum(123L);
		mShopShareStatisticMapper.insertMShopShareStatistic(mshopUserStatistic);
	}
    @Test
	public void testShareChain(){
		try {
			MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
			mshopShareRecordDto.setPuserId(100049064004L);//分享者
			mshopShareRecordDto.setPuniqueId("o0zUGt4saeod3IzlwAUkkMd0S83k");//c--
			mshopShareRecordDto.setUniqueId("o0zUGt7-t9FKzqbcFPza6C_CGDyw");
			mshopShareRecordDto.setUserId(18620388291L);
			mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKb5BzdGZbSYAZbE2PNrP0aWD4ToJHWCbr701d9icicZGRpOoZciaxAxXAAjT338BDQD8gibKnSCOFiaMw/132");
			mshopShareRecordDto.setNickname("彪");
			mshopShareRecordDto.setAuthorization(1);
			mshopShareRecordDto.setNewUser(1);
			MapResults<MshopShareRecordDto> mshopShareRecordDtoMapResults = mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
			System.out.println(mshopShareRecordDtoMapResults.getSuccess());
//		MshopShareRecordDto buessObj = mshopShareRecordDtoMapResults.getBuessObj();
//		System.out.println(buessObj.getUpuserId());
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	@Test
	public void testUpdateBinding(){
		MshopShareBinding mshopShareBinding = new MshopShareBinding();
		mshopShareBinding.setUserId(78908044559L);
//		MshopShareBinding rtnmshopShareBinding = mShopShareBindingMapper.queryByParam(mshopShareBinding);
//		System.out.println(rtnmshopShareBinding);
	}
	@Autowired
	com.gome.userCenter.facade.login.ISNSLoginFacade ISNSLoginFacade;
	@Test
	public void testUniqueId(){
		HashMap<String, Object> hashMap = new HashMap<String, Object>(1);
		hashMap.put("SNSUnionId","o0zUGt3fjY78Wek5-jITtTXf4oY8");
		MapResult<com.gome.userCenter.model.UserInfo> shareSnsInfoById = ISNSLoginFacade.getSnsInfoById("o0zUGt3fjY78Wek5-jITtTXf4oY8", "wechat", "gomeShop", hashMap);
		System.out.println(JSON.toJSONString(shareSnsInfoById));
	}

	@Test
	public void testCreateBinding(){

		/**
		 * MshopShareRecord(id=null, uniqueId=o0zUGt1SjQjnXdaUt186sUHD1dDw, use
		 * rId=100051184821, mid=null, puniqueId=o0zUGtxJwtyHyItiaMxG1adrDVWg, pmid=null, puserId=100051184820, ptype=null, type=null, insertTime=null, updateTime=null, upmid=null, upuserId=null, version=null)
		 */
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setUniqueId("o0zUGt1SjQjnXdaUt186sUHD1dDw");
		mshopShareRecord.setPuniqueId("o0zUGtxJwtyHyItiaMxG1adrDVWg");
		mshopShareRecord.setPuserId(100051184820L);
		mshopShareRecord.setUserId(100051184821L);
		mshopShareRecordManager.createMshopShareBinging(mshopShareRecord);
	}
	@Test
	public void testUpdate(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setType(3);
		mshopShareRecord.setUniqueId("oazsPwTgL4AfKu7Sz5Rmex8An0o8");
//		mshopShareRecord.setPuserId(100037781242L);
		mshopShareRecord.setUserId(100049578901L);
		mshopShareRecord.setVersion(5);
//        ArrayList<MshopShareRecord> mshopShareRecords = new ArrayList<>();
//        mshopShareRecords.add(mshopShareRecord);
        mshopShareRecordMapper.updateMShopShareRecord(mshopShareRecord);
	}
    @Test
    public void testQueryList(){
        MshopShareRecord mshopShareRecord = new MshopShareRecord();
        mshopShareRecord.setType(2);
        mshopShareRecord.setUniqueId("oazsPwTgL4AfKu7Sz5Rmex8An0o8");
//		mshopShareRecord.setPuserId(100037781242L);
        mshopShareRecord.setUserId(100049578901L);

//        ArrayList<MshopShareRecord> mshopShareRecords = new ArrayList<>();
//        mshopShareRecords.add(mshopShareRecord);
        List<MshopShareRecord> mshopShareRecords = mshopShareRecordMapper.queryListByParam(mshopShareRecord);
        for (MshopShareRecord rtnMshopShareRecord:mshopShareRecords
        ) {
            rtnMshopShareRecord.setType(3);
            mshopShareRecordMapper.updateMShopShareRecord(rtnMshopShareRecord);
        }

    }
    @Test
    public void testForeache(){
        ArrayList<String> objects = new ArrayList<>();
        System.out.println(objects.size());
        for (String thisString:objects
             ) {
            System.out.println(123);
        }
    }
    @Autowired
	UserShareBindingManager userShareBindingManager;
	@Autowired
	MShopShareBindingService mShopShareBindingService;
	@Test
	public void testAuthorization(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setUserId(73251258588L);
		mshopShareRecordDto.setAuthorization(3);
//		MshopShareBinding mshopShareBinding = new MshopShareBinding();
//		mshopShareBinding.setUserId(73251258588L);
//		MshopShareBinding mshopShareBinding1 = mShopShareBindingMapper.queryByParam(mshopShareBinding);
//		System.out.println(mshopShareBinding1);
		userShareBindingManager.authorizationPrivacy(mshopShareRecordDto);
	}
	@Test
	public void testU(){
		MshopShareBinding mshopShareBinding = new MshopShareBinding();
		mshopShareBinding.setUserId(73251258588L);
		mshopShareBinding.setAuthorization(2);
		mShopShareBindingMapper.updateMshopShareBinding(mshopShareBinding);
	}
	@Autowired
	MShopWechatService mShopWechatService;

	@Test
	public void testWechat(){
		MshopWechatUserInfo mshopWechatUserInfo = new MshopWechatUserInfo();
//		mshopWechatUserInfo.setUserId(111666L);
//		mshopWechatUserInfo.setPhoneMobile(15652126663L);
//		mshopWechatUserInfo.setWechatNum(6666666666L);
//		mshopWechatUserInfo.setNickname("nickname");
//		mshopWechatUserInfo.setImage("http://image");
//		mshopWechatUserInfo.setUniqueId("uniqueId");
//		mshopWechatUserInfo.setMid(123321L);
//		mshopWechatUserInfo.setQrCode("http://qrcode");
		MShopShareBindingDto mShopShareBindingDto = new MShopShareBindingDto();
		mShopShareBindingDto.setQrCode("http://gfs5.atguat.net.cn/T1z6ZjB4hT1RCvBVdK.jpg");
		mShopShareBindingDto.setUserId(100049055702L);
		mShopShareBindingDto.setWechatNum("777777777");
		userShareBindingManager.uploadQrCode(mShopShareBindingDto);
	}

  @Test
  public void test1()
  {
//	  userShareBindingManager.queryMshopOrderDtoByUserId(100011895128L);
	  MshopRebateDto dto=new MshopRebateDto();
	  dto.setUserId(100049090639l);
	  MapResults<MshopRebateDto> mshopRebateDtoMapResults = userShareBindingManager
			  .queryMshopRebateDtoByUserIdOrMid(dto);
	  System.out.println("结果是：" + mshopRebateDtoMapResults.getBuessObj());
  }
    @Test
    public void testUpdateWechat(){
        MshopWechatUserInfo mshopWechatUserInfo = new MshopWechatUserInfo();
//        mshopWechatUserInfo.setUserId(111666L);
        mshopWechatUserInfo.setUniqueId("uniqueId");
        MshopWechatUserInfo mshopWechatUserInfo1 = mShopWechatService.queryWechatInfoByParam(mshopWechatUserInfo);
        mshopWechatUserInfo1.setQrCode("http://qrcode");
        mShopWechatService.updateWechatUserInfo(mshopWechatUserInfo1);
//        System.out.println(mshopWechatUserInfo1);
    }
	@Test
	public void testMid(){
		Long midByUnique = mshopShareRecordManager.checkMidByUnique("", 100049179351L);
		System.out.println(midByUnique);
	}
	@Autowired
	private VshopFacade vshopFacade;

	@Test
	public void testCreateMid(){
//		Long userIdByUniqueId = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGt_ttl7NgrQlhfiT6wt09NDo");
		ArrayList<Long> longs = new ArrayList<>();
		longs.add(100053133602L);

		for (Long userId:longs
			 ) {
			VshopInfo vshopInfo = new VshopInfo();
			vshopInfo.setUserId(userId);
			vshopInfo.setVshopName("test_vshopname2");
			CommonResultEntity<String> vshop2 = vshopFacade.createVshop2(vshopInfo);
			System.out.println(JSON.toJSONString(vshop2));
		}
//		CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId("100018025714");
//		System.out.println(vshopInfoCommonResultEntity.getBusinessObj().getVshopId());
	}
	@Test
	public void queryVshop(){
		ArrayList<Long> longs = new ArrayList<>();
		longs.add(100053133602L);
		longs.add(100037478562L);
		longs.add(162020008L);
		longs.add(100037482516L);
		for (Long userId:longs) {
			CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(userId.toString());
			if(null == vshopInfoCommonResultEntity || null == vshopInfoCommonResultEntity.getBusinessObj() ){
				System.out.println(userId.toString());
				continue;
			}
			System.out.println(vshopInfoCommonResultEntity.getBusinessObj().getVshopId()+":"+vshopInfoCommonResultEntity.getBusinessObj().getUserId()+":"+vshopInfoCommonResultEntity.getBusinessObj().getVshopIdentity());
		}
	}
	//100049568009
	@Test
	public void testStringSplit(){
		String s = "11111111111111";
		String[] split = s.split("-");
		System.out.println(split.length);
		for (String str:
			split) {
			System.out.println(str);
		}
		split[split.length - 1] = "-222222222222222";
		String result = split.toString();
		System.out.println(result);
	}

	@Test
	public void invateUserOrChangeUpper(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setUpuserId(100049055702L);
		mshopShareRecord.setUserId(100040845602L);
		mshopShareRecordManager.invateUserOrChangeUpper(mshopShareRecord);
	}
	@Test
	public void testCopyBean(){
		try {
			MshopShareRecord mshopShareRecord = new MshopShareRecord();
			MshopShareBinding mshopShareBinding = new MshopShareBinding();
			mshopShareBinding.setUpmid(123321L);
			BeanUtils.copyProperties(mshopShareRecord,mshopShareBinding);
			System.out.println(mshopShareRecord);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	@Test
	public void testResult(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setPuserId(100049064014L);
		mshopShareRecord.setUniqueId("o0zUGt_ttl7NgrQlhfiT6wt09NDo");
		mshopShareRecord.setUpmid(123L);
		MshopShareRecord mshopShareRecord1 = mshopShareRecordMapper.queryByUniqueIdAndPuserId(mshopShareRecord);
		System.out.println(mshopShareRecord1);
	}
	@Test
	public void testLogin(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setPuserId(100049058306L);//分享者
		mshopShareRecordDto.setUserId(100049611602L);
		mshopShareRecordDto.setUniqueId("o0zUGt_a7CUiVc10HBRWm73pSoAs");
		mshopShareRecordDto.setNewUser(0);
    /* mshopShareRecordDto.setPuniqueId("o0zUGty275yZsfBSAQioBB5OVGSY");//c--
     mshopShareRecordDto.setUniqueId("o0zUGtxJwtyHyItiaMxG1adrDVWg");
//     mshopShareRecordDto.setUserId(71L);
     mshopShareRecordDto.setImage("http://thirdwx.qlogo.cn/mmopen/vi_32/PiajxSqBRaEKNM66drCtbu1TmmhoFzHk2IuXMx1HFI3YGjLDalpf7lxraEdarh5I7nFeww0JQDWObgfAKzIvZ2Q/132");
     mshopShareRecordDto.setNickname("一条咸鱼"); */
		mshopShareRecordManager.addMshopShareRecord(mshopShareRecordDto);
	}
	@Test
	public void testQuerybin(){
	MshopShareBinding mshopShareBinding = new MshopShareBinding();
	mshopShareBinding.setUserId(100051177314L);
		MshopShareBinding mshopShareBinding1 = mShopShareBindingService.queryByParam(mshopShareBinding);
		System.out.println(mshopShareBinding1);
	}
	@Test
	public void testBlank(){
		Long midByUnique = mshopShareRecordManager.checkMidByUnique("o0zUGtzQroCx0E6nnZI3AsMqqjcs", null);
		System.out.println(midByUnique);
	}
	@Test
	public void testS(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setUniqueId("2132311323123");
		mshopShareRecordManager.updateMshopShareRecord(3,mshopShareRecord);
	}

	@Test
	public void testqueryByUniqueIdOrUserId(){
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setUniqueId("o0zUGtznnOKykWwCXnPW1gpM5WSs1");
		mshopShareRecord.setUserId(21L);
		List<MshopShareRecord> mshopShareRecords = mshopShareRecordMapper.queryByUniqueIdOrUserId(mshopShareRecord);
		System.out.println(mshopShareRecords);
	}
	@Test
	public void test999(){
////		MshopShareBinding mshopShareBinding = new MshopShareBinding();
//		MShopShareBindingDto mShopShareBindingDto = mShopShareBindingMapper.queryShareBindingByUserId(100051196506L);
//		System.out.println(mShopShareBindingDto);
//		Long midByUnique = mshopShareRecordManager.checkMidByUnique("o0zUGt3fjY78Wek5-jITtTXf4oY8", null);
//		System.out.println(midByUnique);
		MshopShareBinding mshopShareBinding = new MshopShareBinding();
		mshopShareBinding.setUserId(80765835529L);
		MshopShareBinding mshopShareBinding1 = mShopShareBindingService.queryByParam(mshopShareBinding);
		System.out.println(mshopShareBinding1);
	}
	@Value("${upload.gfs.key}")
	private String gfsKey;
	@Test
	public void testUploadPic(){
//		String s = mshopShareRecordManager.uploadPicToGFS("http://thirdwx.qlogo.cn/mmopen/vi_32/KbAhel8wEfPHDeTRicx9h66mBwM6GgNxn2zpyIaoticibvkVPfU646MwutPmOJGkad5M0CverfMWfz6vqGicpiaTGuw/132");
//		System.out.println(s);
	}
    @Autowired
    ThreadPoolExecutor threadPoolExecutor;
	@Autowired
	private CommonUploadService commonUploadService;
	@Test
    public void testThreadPool(){
	/*    try {
	    	for(int i = 0 ; i < 20 ; i++){
				MshopWechatUserInfo mshopWechatUserInfo1 = new MshopWechatUserInfo();
				mshopWechatUserInfo1.setImage("http://123");
				mshopWechatUserInfo1.setUniqueId("thisUniqueId"+i);
				UploadPicThread uploadPicThread = new UploadPicThread(mshopWechatUserInfo1,gfsKey);
				threadPoolExecutor.submit(uploadPicThread);
			}
	    	Thread.sleep(35000L);
        }catch(Exception e){
	        e.printStackTrace();
        }*/
		GisResultDto gisResultDto = commonUploadService.uploadURLImage("https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIYjibQpY3Au3icAKwhzH3uSC8dSUIveoP7rAz96SAYxqjLCKaK1mYZibDyroA6HTPRy731fyRz5oIvg/132", "1d2c01d6685c4500bb4639c1b9a0004b");
		String url = gisResultDto.getUrl();
		System.out.println(url);
	}
    @Autowired
	private GcacheConfig gCacheConfig;
    @Test
	public void testGache(){
		Gcache gcache = gCacheConfig.gcache();
		String mdnew_cache = gcache.get("MDNEW_CACHE");
		if(StringUtils.isBlank(mdnew_cache)){
			//调接口取数据
			System.out.println("调接口取数据");
		}else{
			System.out.println("数据"+mdnew_cache);
		}
		gcache.setex("MDNEW_CACHE" , 5 * 60 , "123");
	}
	@Test
	public void testctoBCreateBinding(){
	/*	(uniqueId=o0zUGt9XZRVw64rG1hcWExzGTnn4, puniqueId=, userId=
				80743976904, puserId=78910095407, mid=null, pmid=null, upuserId=null, upmid=null, image=http%3A%2F%2Fthirdwx.qlogo.cn%2Fmmopen%2Fvi_32%2FQ0j4TwGTfTJWv3ic4BmCg8MBiaKbibwwHCljzHxFG7qjHeoVEgHIarFHwKS9sUtsku5VuX0OzmVb71SbLhyWqiaTQg%2F132, nickname=Spring,
			authorization=1, pType=null, type=null, newUser=1, insertTime=null, updateTime=null)*/
		MshopShareRecord mshopShareRecord = new MshopShareRecord();
		mshopShareRecord.setUniqueId("o0zUGt9XZRVw64rG1hcWExzGTnn4");
//		mshopShareRecord.setUserId(123L);
//		if(null != mshopShareRecord.getUniqueId()){
//			System.out.println("去会员查询0");
//			mshopShareRecord.setUserId(321L);
//			System.out.println("***1***"+mshopShareRecord);
//		}
		if(null != mshopShareRecord.getUniqueId() && null == mshopShareRecord.getUserId()){
			System.out.println("去会员查询1");
			mshopShareRecord.setUserId(333L);
			System.out.println("***2***"+mshopShareRecord);
		}
	}

	@Test
	public void testAuto(){
		MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
		mshopShareRecordDto.setUserId(11111111111L);
		mshopShareRecordDto.setAuthorization(2);
		userShareBindingManager.authorizationPrivacy(mshopShareRecordDto);

	}
	@Autowired
	IGomeShopWeChatFacade gomeShopWeChatFacade;
	@Test
	public void testA(){
		UserResult<Boolean> booleanUserResult = gomeShopWeChatFacade.updatePrivacyAuth("100051207512", "1", "gomeShop");
		System.out.println(booleanUserResult.isSuccess());
		System.out.println(booleanUserResult.getBuessObj());
	}
	@Test
	public void testB(){
		Integer integer = mShopShareBindingService.selectCountByUserId(100051222003L);
		System.out.println(integer);
		System.out.println(integer.equals(1));
	}
	@Autowired
	Gcache gcache;
	@Test
	public void testGcache() throws Exception{
		Long meidian_wechat_nickname = gcache.setnxex("meidian_wechat_nickname", 2, "666666");
		System.out.println(meidian_wechat_nickname);
		Long meidian_wechat_nickname1 = gcache.setnxex("meidian_wechat_nickname", 2, "666666");
		System.out.println(meidian_wechat_nickname1);
		Thread.sleep(2000L);
		Long meidian_wechat_nickname2 = gcache.setnxex("meidian_wechat_nickname1", 2, "666666");
		System.out.println(meidian_wechat_nickname2);
		Long meidian_wechat_nicknam3 = gcache.setnxex("meidian_wechat_nickname2", 2, "666666");
		System.out.println(meidian_wechat_nicknam3);
//		1
//		0
//		1
//		1
//		1
	}

	@Test
	public void test0001(){
		Long userIdByUniqueId = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGt1V2cQpyDelv8Dv4wCgH7c8");
		System.out.println(userIdByUniqueId);
	}
	@Test
	public void testExpireTime() {
		try {
			Long userIdByUniqueId = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGt1SjQjnXdaUt186sUHD1dDw");
			System.out.println("o0zUGt1SjQjnXdaUt186sUHD1dDw:"+userIdByUniqueId);
			Long userIdByUniqueId1 = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGt_ttl7NgrQlhfiT6wt09NDo");
			System.out.println("o0zUGt_ttl7NgrQlhfiT6wt09NDo:"+userIdByUniqueId1);
			Long userIdByUniqueId2 = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGt_W1C1ZOfTPynMox4vgJQ7k");
			System.out.println("o0zUGt_W1C1ZOfTPynMox4vgJQ7k:"+userIdByUniqueId2);
			Long userIdByUniqueId3 = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGtz7RqvLWd15bhMfqBH9-H0I");
			System.out.println("o0zUGtz7RqvLWd15bhMfqBH9-H0I:"+userIdByUniqueId3);
			Long userIdByUniqueId4 = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGtzzdacoQlYY9k-ilxjvGlDM");
			System.out.println("o0zUGtzzdacoQlYY9k-ilxjvGlDM:"+userIdByUniqueId4);
			Long userIdByUniqueId5 = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGt3zPZActe0xaDlG07c-PPsU");
			System.out.println("o0zUGt3zPZActe0xaDlG07c-PPsU:"+userIdByUniqueId5);
			Long userIdByUniqueId6 = mshopShareRecordManager.queryUserIdByUniqueId("o0zUGty275yZsfBSAQioBB5OVGSY");
			System.out.println("o0zUGty275yZsfBSAQioBB5OVGSY:"+userIdByUniqueId6);
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	@Autowired
	IGomeShopWeChatFacade iGomeShopWeChatFacade;
	@Test
	public void testQueryUniqueIdByUserId(){
		long l = System.currentTimeMillis();
		String s0 = mshopShareRecordManager.queryUniqueIdByUserId(100051251402L);
		System.out.println(System.currentTimeMillis() - l);
		System.out.println(s0);
		long ll = System.currentTimeMillis();
		String s1 = mshopShareRecordManager.queryUniqueIdByUserId(100051251402L);
		System.out.println(System.currentTimeMillis() - ll);
		System.out.println(s1);
		long lll = System.currentTimeMillis();
		String s2 = mshopShareRecordManager.queryUniqueIdByUserId(100051243205L);
		System.out.println(s2);
		System.out.println(System.currentTimeMillis() - lll);
		long llll = System.currentTimeMillis();
		String s3 = mshopShareRecordManager.queryUniqueIdByUserId(100051243205L);
		System.out.println(System.currentTimeMillis() - llll);
	}

}