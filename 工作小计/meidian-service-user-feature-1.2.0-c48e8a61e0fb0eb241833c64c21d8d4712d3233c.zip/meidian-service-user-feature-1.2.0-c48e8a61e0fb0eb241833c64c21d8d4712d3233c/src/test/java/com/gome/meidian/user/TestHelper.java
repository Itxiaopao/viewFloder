package com.gome.meidian.user;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.service.GenericService;

import java.util.Map;

/**
 * 这里的注释内容，需要对类的使用做一个简单的说明。
 *
 * @author hushengdong
 * @create 2019-10-28 15:21:00
 */
public class TestHelper {

    /**
     * 泛化调用 dubbo接口
     *
     * @param name               dubbo接口的应用名称 例如： venus-vshop
     * @param interfaceClassName 你要调用的接口的类 例如：VshopFacade.class
     * @param functionName       要调用的方法的名称 例如： updateVshop
     * @param paramClass         数组，入参的全路径名称 例如： com.gomeo2o.facade.vshop.entity.VshopInfo
     * @param paramValue         数组，入参值 例如： 具体的一个List
     * @param zookeeperList      要调用的zookeeper 例如： 10.58.22.192:2181,10.58.22.193:2181,10.58.22.191:2181,10.58.166.145:2181,10.58.166.146:2181,10.58.188.146:2181,10.58.188.147:2181,10.58.188.148:2181,10.58.166.147:2181,10.58.166.148:2181
     * @param ip                 要调用的IP 例如： 10.125.140.106
     * @param port               端口 例如： 30003
     * @return 返回值
     */
    public static Map<String, Object> dubboLive(String name, Class interfaceClassName, String functionName, String[] paramClass, Object[] paramValue, String zookeeperList, String ip, String port) {
        // dubbo 泛化调
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(name);
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(zookeeperList);
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连
        reference.setUrl("dubbo://" + ip + ":" + port + "?scope=remote");
        reference.setRegistry(registryConfig);
        reference.setVersion("3.0.0");
        //                reference.setGroup("techisan-beta");
        reference.setInterface(interfaceClassName);
        //true声明为泛化接口
        reference.setGeneric(true);

    /*ReferenceConfig实例很重，封装了与注册中心的连接以及与提供者的连接，
    需要缓存，否则重复生成ReferenceConfig可能造成性能问题并且会有内存和连接泄漏。
    API方式编程时，容易忽略此问题。
    这里使用dubbo内置的简单缓存工具类进行缓存*/
        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        // 泛化调用,接口方法名称+方法参数类型+方法参数值
        Map<String, Object> result = (Map<String, Object>) genericService.$invoke(functionName, paramClass, paramValue);
        System.err.println("结果是：" + result);
        return result;
    }

    public static Map<String, Object> queryVenusVshopDubboLive(Class className, String functionName, String[] paramClassName, Object[] paramValue) {

        String applicationName = "venus-vshop";
        String ip = "10.125.140.106";
        String port = "30003";
        String zookeeperList = "10.58.22.192:2181,10.58.22.193:2181,10.58.22.191:2181,10.58.166.145:2181,10.58.166.146:2181,10.58.188.146:2181,10.58.188.147:2181,10.58.188.148:2181,10.58.166.147:2181,10.58.166.148:2181";
        Map<String, Object> result = TestHelper.dubboLive(applicationName, className, functionName, paramClassName, paramValue, zookeeperList, ip, port);
        return result;
    }
}
