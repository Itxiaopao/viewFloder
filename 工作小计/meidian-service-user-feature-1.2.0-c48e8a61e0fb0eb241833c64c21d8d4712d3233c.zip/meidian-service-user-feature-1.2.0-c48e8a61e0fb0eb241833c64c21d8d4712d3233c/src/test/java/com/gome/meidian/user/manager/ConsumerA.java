package com.gome.meidian.user.manager;


import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.gome.meidian.user.dto.MshopShareRecordDto;


import java.util.List;

//2、订阅者（消费者）
public class ConsumerA {
    public static void main(String[] args) throws InterruptedException, MQClientException {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer("meidian_service_user_group_one");
        // 建议唯一，比如包含进程的pid
        consumer.setInstanceName("meidian_service_user_instance_name");
        consumer.setNamesrvAddr("10.112.178.137:9876;10.112.178.138:9876");
        consumer.subscribe("meidian-user-relationship", "executeTaskAddB");
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
        consumer.registerMessageListener(new MessageListenerConcurrently() {
            @Override
            public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                try {
                    MessageExt msg = msgs.get(0);
                    String tags = msg.getTags();
                    System.out.println(tags);
                    System.out.println(msg.getMsgId());
                    String s = new String(msg.getBody());
                    System.out.println(s);
//                    MshopShareRecordDto mshopShareRecordDto = JSON.parseObject(s, MshopShareRecordDto.class);
//                    System.out.println(mshopShareRecordDto);
                    System.out.println("==============A==============");
                    // 有异常记得抛出来，不要全捕获了，这样保证不能消费的消息下次重推，每次重新消费间隔：
                    // 按照服务端配置的间隔进行重试
                    // 注意上述处理不要把异常捕了，如果没有异常会认为都成功消费
                }catch (Exception e){
                    e.printStackTrace();
                }
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
        });
        consumer.start();
        System.out.println("ConsumerA Started.");
    }
}
