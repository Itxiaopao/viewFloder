package com.gome.meidian.user.manager;

import com.taobao.tddl.executor.function.scalar.filter.In;
import com.vdurmont.emoji.EmojiParser;
import org.junit.Test;
import java.util.concurrent.*;

import java.util.Date;


public class AAAA {

	@Test
	public void getDay(){
		int day = new Date().getDay();
		int date = new Date().getDate();
		System.out.println(day);
		System.out.println(date);
	}

	public static void main(String[] args) throws Exception{
//		String str = "A💋韩国化妆品💄小城";
//		System.out.println("原始字符为：\n" + str);
//		String s2 = EmojiParser.parseToAliases(str);
//		System.err.println(s2);
//		System.err.println(EmojiParser.parseToUnicode(s2));
//		ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(5, 5, 2l, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Thread>(10), new ThreadFactory() {
//			@Override
//			public Thread newThread(Runnable r) {
//				int i = 0;
//				return new Thread(i+"");
//			}
//		});
		String testHash = new String("abc");
		Integer integer = new Integer(123);
		int i = testHash.hashCode();
		System.out.println(i / 20);
		System.out.println(i % 20);
		System.out.println(integer % 20);
	}

	@Test
	public void test(){
		String corn = "0 0 0 "+ 28 +" * ? *";
		String[] split = corn.split(" ");
		System.out.println(split + "----" + split[3]);

	}
}