package com.gome.meidian.user;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.w3c.dom.ranges.Range;

import cn.com.gome.gis.dto.GisResultDto;
import cn.com.gome.gis.dubbo.CommonUploadService;
import com.alibaba.fastjson.JSON;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.meidian.MeidianUserStarter;
import com.gome.meidian.user.constant.BizConstant;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.service.UserRelationCacheService;
import com.gome.service.CommandType;
import redis.Gcache;

import static com.alibaba.dubbo.common.dgroup.TTType.Type.s;

/**
 * @author limenghui
 * @create 2020-05-14 15:51
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianUserStarter.class)
@EnableAutoConfiguration
public class BangBangTest {

    @Autowired
    private CommonUploadService commonUploadService;
    @Autowired
    UserRelationCacheService cacheService;

    @Test
    public void setShareRecord(){
        MshopShareRecord shareRecord = new MshopShareRecord();
        shareRecord.setUniqueId("hdasjgksjgnkfjgk");
        shareRecord.setUpuserId(123456L);
        cacheService.setShareRecord(shareRecord);
    }

    @Test
    public void removeShareRecord(){
        cacheService.removeShareRecord("hdasjgksjgnkfjgk",123456L);

    }

    @Test
    public void getYouKeCache(){
        //user_share_record_str_prefix_o0zUGt3g_iP-RDl9xLY37hv5la80
        String uniqueId = "o0zUGt3g_iP-RDl9xLY37hv5la80";
        /*MshopShareRecord shareRecord = cacheService.getShareRecord(uniqueId);
        System.err.println("游客本身的记录是：" + shareRecord);*/


        //user_subordinate_relation_zset_prefix_2_null_100049055306
        Long upUserId = 100049055306L;
        Set<String> subordinatePage = cacheService.getSubordinatePage(upUserId, 2, null, 0, 10);
        System.err.println("结果是：" + subordinatePage);

    }

    @Test
    public void uploadImage(){
        String image = "https://image.baidu.com/search/detail?ct=503316480&z=0&ipn=d&word=ins%E6%83%85%E4%BE%A3%E5%A4%B4%E5%83%8F%E5%8D%A1%E9%80%9A&step_word=&hs=0&pn=0&spn=0&di=116710&pi=0&rn=1&tn=baiduimagedetail&is=0%2C0&istype=0&ie=utf-8&oe=utf-8&in=&cl=2&lm=-1&st=-1&cs=2239174917%2C3824860292&os=24624344%2C2881861228&simid=3512669297%2C178786085&adpicid=0&lpn=0&ln=1309&fr=&fmq=1589441639472_R&fm=rs4&ic=undefined&s=undefined&hd=undefined&latest=undefined&copyright=undefined&se=&sme=&tab=0&width=undefined&height=undefined&face=undefined&ist=&jit=&cg=&bdtype=0&oriquery=%E5%A4%B4%E5%83%8F%E5%9B%BE%E7%89%87&objurl=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201807%2F14%2F20180714173019_icfjf.thumb.700_0.jpg&fromurl=ippr_z2C%24qAzdH3FAzdH3Fooo_z%26e3B17tpwg2_z%26e3Bv54AzdH3Fks52AzdH3F%3Ft1%3Dlcmcbmc8c&gsm=1&rpstart=0&rpnum=0&islist=&querylist=&force=undefined";
        String GFSKEY = "1d2c01d6685c4500bb4639c1b9a0004b";
        GisResultDto gisResultDto = commonUploadService.uploadURLImage(image, GFSKEY);
        System.err.println("结果是"+ JSON.toJSONString(gisResultDto));

    }

}
