package com.gome.meidian.user.gjob;

import com.gome.meidian.user.BaseTest;
import com.gome.meidian.user.dto.MapResults;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 这里的注释内容，需要对类的使用做一个简单的说明。
 *
 * @author hushengdong
 * @create 2019-10-22 10:33:00
 */
public class SynUserIdentityServiceTest extends BaseTest {

    @Autowired
    SynUserIdentityService synUserIdentityService;

    @Test
    public void execute() throws Exception {

        MapResults mapResults = synUserIdentityService.execute("123");
        Assert.assertTrue(mapResults.getSuccess());
    }

}