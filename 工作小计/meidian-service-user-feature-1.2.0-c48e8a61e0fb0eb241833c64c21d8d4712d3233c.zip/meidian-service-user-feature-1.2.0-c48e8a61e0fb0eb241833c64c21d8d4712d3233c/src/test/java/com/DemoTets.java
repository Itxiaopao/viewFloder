package com;

import com.gome.meidian.user.dto.MShopOwnerInfoDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.manager.MShopShareRecordManager;
import com.google.common.collect.Lists;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

/**
 * @author limenghui-ds
 * @create 2019-07-11 11:52
 */
public class DemoTets {

    @Test
    public void test() {
        String name = " ";
        name = name.substring(0, 1) + "****" + name.substring(name.length() - 1);
        System.out.println("name:" + name);
    }

    @Test
    public void test01() {
        //list按照最近浏览时间进行降序
        ArrayList<MShopOwnerInfoDto> list = Lists.newArrayList();
        Collections.sort(list, new Comparator<MShopOwnerInfoDto>() {
            @Override
            public int compare(MShopOwnerInfoDto o1, MShopOwnerInfoDto o2) {
                return o2.getBrowsLatestDate().compareTo(o1.getBrowsLatestDate());
            }
        });
    }

    @Test
    public void test02() {
        long l = System.currentTimeMillis();
        Date date1 = new Date(l);
        Date date2 = new Date(l);
        int i = date1.compareTo(date2);
        System.out.println(i);
    }

}
