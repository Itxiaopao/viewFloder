import com.alibaba.cobar.parser.ast.expression.primary.function.misc.Sleep;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.config.DiamondEnv;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.meidian.MeidianUserStarter;
import com.gome.meidian.user.config.GcacheConfig;
import com.gome.meidian.user.constant.BizConstant;
import com.gome.meidian.user.constant.CacheConstant;
import com.gome.meidian.user.dto.*;
import com.gome.meidian.user.entity.MshopShareBinding;
import com.gome.meidian.user.entity.MshopShareRecord;
import com.gome.meidian.user.entity.MshopWechatUserInfo;
import com.gome.meidian.user.enums.DiamondEnum;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.meidian.user.manager.MShopOwnerInfoManager;
import com.gome.meidian.user.manager.MShopWechatUserInfoManager;
import com.gome.meidian.user.manager.UserShareBindingManager;
import com.gome.meidian.user.mapper.MShopShareBindingMapper;
import com.gome.meidian.user.mapper.MShopShareRecordMapper;
import com.gome.meidian.user.mapper.MShopWeChatMapper;
import com.gome.meidian.user.mq.UserRelationConsumer;
import com.gome.meidian.user.service.MShopShareBindingService;
import com.gome.meidian.user.service.MShopShareRecordService;
import com.gome.meidian.user.service.MShopWechatService;
import com.gome.meidian.user.service.UserRelationCacheService;
import com.gome.meidian.user.service.impl.UserRelationCacheServiceImpl;
import com.gome.meidian.user.utils.DateUtil;
import com.gome.meidian.user.utils.UploadPicThread;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.google.common.collect.Lists;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import redis.Gcache;

import java.util.*;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;


@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = MeidianUserStarter.class)
public class MeidianUserTests {
	@Autowired
	private MShopShareBindingService mShopShareBindingService;
	@Autowired
	private IUserShareBindingManager shareBindingManager;
	@Autowired
	private MShopShareRecordMapper shareRecordMapper;
	@Autowired
	private MShopOwnerInfoManager mShopOwnerInfoManager;
	@Autowired
	private MShopShareRecordService mShopShareRecordService;
	@Autowired
	private MShopWechatUserInfoManager mShopWechatUserInfoManager;
	//	@Autowired
//	private IOrderShopService orderShopServiceImpl;
	@Autowired
	private VshopFacade vshopFacade;
	@Autowired
	private MShopWechatService mShopWechatService;
	//	@Autowired
//	private IcSmDqlStaffService icSmDqlStaffService;
	@Autowired
	MShopWeChatMapper mShopWeChatMapper;
	@Autowired
	private ApplicationContext applicationContext;

	@Autowired
	DiamondEnv diamondEnv;

	@Autowired
	private UserRelationConsumer userRelationConsumer;

	@Autowired
	private UserRelationCacheService userRelationCacheService;

	@Autowired
	UserRelationCacheServiceImpl userRelationCacheServiceImpl;

	@Autowired
	private Gcache gcache;

	@Autowired
	private ThreadPoolExecutor threadPoolExecutor;

	@Autowired
	private MShopShareBindingMapper mShopShareBindingMapper;

	@Autowired
	private UploadPicThread uploadPicThread;

	@Test
	@SneakyThrows
	public void test02() {

		userRelationCacheService.removeShareRecord("o0zUGtyqy8NbHBCol9OWhrE66ehY",100054833204L);
		userRelationCacheService.removeShareRecord("o0zUGtyBPTdMXUE0e6d2zwxQ_o48",100054833205L);

		userRelationCacheService.removeUserRelation(100054833205L, 100051541601L, 0, 1);
		Set<String> subordinatePage = userRelationCacheService.getSubordinatePage(100051541601L, BizConstant.SHARE_RECORD_TYPE, null, 0, 100);
		System.out.println("+++++" + JSON.toJSON(subordinatePage));
	}

	public <T> String getSubordinateRedisKey(T upUserId, Integer identity, Integer type) {
		return CommUtils.getRedisKey(CacheConstant.USER_SUBORDINATE_RELATION_ZSET_PREFIX, identity, type, upUserId);
	}

	@Test

	public void test01() throws Exception {
		List<MshopWechatUserInfo> mshopWechatUserInfos = null;
		MshopWechatUserInfo mshopWechatUserInfo = new MshopWechatUserInfo();
		mshopWechatUserInfo.setUniqueId("ABC123");
		mshopWechatUserInfo.setImage("HAO123");
		mshopWechatUserInfo.setNickname("测试1");

		MshopWechatUserInfo mshopWechatUserInfo2 = new MshopWechatUserInfo();
		mshopWechatUserInfo2.setUniqueId("ABC12345");
		mshopWechatUserInfo2.setImage("HAO12345");
		mshopWechatUserInfo2.setNickname("测试2");

		Map<String, MshopWechatUserInfo> mshopWechatUserInfoMap =  mshopWechatUserInfos.stream().collect(Collectors.toMap(MshopWechatUserInfo::getUniqueId, item -> item));
		System.out.println(JSON.toJSON(mshopWechatUserInfoMap));
	}

	@Test
	public void test() {
		List<MshopWechatUserInfo> weChatInfoList = mShopWechatService.queryWeChatInfoByUniqueId("o0zUGt1SjQjnXdaUt186sUHD1dDw");
		System.out.println("结果是：" + weChatInfoList);
	}

	@Test
	public void queryWeChatInfoByUserId() {
		List<MshopWechatUserInfo> mShopWeChatInfos = mShopWeChatMapper.queryWeChatInfoByUserId(Lists.newArrayList("100049062015"));
		System.out.println("结果是：" + mShopWeChatInfos);
	}

	@Test
	public void queryWeChatInfoByUniqueId() {
		List<String> list = mShopShareRecordService.queryUniqueIdListByUpUserId(100049064004l);
		for (String i : list) {
			List<MShopWeChatInfo> weChatInfos = mShopWechatUserInfoManager.queryWeChatInfoByUniqueId(i);
			System.out.println("结果是：" + weChatInfos);
		}
	}


	@Test
	public void queryWeChatInfoListByUniqueIdList() {
		List<String> list = mShopShareRecordService.queryUniqueIdListByUpUserId(100049062015l);
		List<MShopWeChatInfo> weChatInfos = mShopWechatUserInfoManager.queryWeChatInfoListByUniqueIdList(list);
		System.out.println("结果是：" + weChatInfos);

	}

	@Test
	public void queryUniqueIdListByUpUserId() {
		List<String> list = mShopShareRecordService.queryUniqueIdListByUpUserId(100049062015l);
		System.out.println("结果是：" + list);

	}

	/**
	 * 批量更改vshop_info表中的身份状态，
	 */
	@Test
	public void updateVshopBatch() {
//		PageParam pageParam = new PageParam();
//		pageParam.setNumPerPage(3000);
//		pageParam.setPageNum(1);
//		CommonResultEntity<List<VshopInfo>> listCommonResultEntity = vshopFacade.queryVshopInfoList(pageParam);
//		if (null != listCommonResultEntity && null != listCommonResultEntity.getBusinessObj()) {
//			List<VshopInfo> businessObj = listCommonResultEntity.getBusinessObj();
//			for (VshopInfo info : businessObj) {
//				info.setVshopIdentity(1);
//				vshopFacade.updateVshop(info);
//			}
//		}
	}

	@Test
	public void updateVshop() {
//		CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId("100040530501");
//		if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
//			VshopInfo businessObj = vshopInfoCommonResultEntity.getBusinessObj();
//			businessObj.setVshopIdentity(3);
//			vshopFacade.updateVshop(businessObj);
//		}
	}

	@Test
	public void IcSmDqlStaffService() {
//		Map<String, Integer> map = new HashMap<>();
//		        map.put("pageNum", 1);
//		        map.put("pageSize", 90);
//		ResultEntity<List<IcSmDqlStaff>> resultEntity = icSmDqlStaffService.selectPart(map);
//		List<Long> list = Lists.newArrayList();
//		for (IcSmDqlStaff info : resultEntity.getBusinessObj()) {
//			//获取id,将对应的状态更改为3
//			CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade
//					.queryVshopByuserId(String.valueOf(info.getZxUid()));
//			if (null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()) {
//				VshopInfo businessObj = vshopInfoCommonResultEntity.getBusinessObj();
//				businessObj.setVshopIdentity(3);
//				vshopFacade.updateVshop(businessObj);
//				list.add(info.getZxUid());
//			}
//		}
//		System.err.println("更改的userid是：" + list);

	}

	/**
	 * 导师：上传头像
	 */
	@Test
	public void uploadQrCode() {
		MShopShareBindingDto mShopShareBindingDto = new MShopShareBindingDto();
		mShopShareBindingDto.setQrCode(
				"//gfs14.atguat.net.cn/T1PRdTByWT1RCvBVdK.jpg");
		mShopShareBindingDto.setWechatNum("hhhg");
		mShopShareBindingDto.setUserId(100049055306l);
		shareBindingManager.uploadQrCode(mShopShareBindingDto);
	}

	/**
	 * 测试33层接口
	 */
//	@Test
//	public void order()
//	{
//		ResultEntity<StaffInfo> staffInfoWithParam = orderShopServiceImpl.getStaffInfoWithParam(100049055702L, null);
//		System.out.println(staffInfoWithParam.getBusinessObj()+"jieguo shi ");
//	}
	@Autowired
	private UserShareBindingManager userShareBindingManager;

	@Test
	public void selectByUserId() {
		// MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryInviteCount(100040893594l);
		//        Integer integer = mShopShareBindingService.queryMidCount(100049055702L);
		MapResults<MeidianVshopSummaryDto> meidianVshopSummaryDtoMapResults = mShopOwnerInfoManager
				.selectByUserId(100049064004l);
		System.err.println("结果是：" + meidianVshopSummaryDtoMapResults.getBuessObj());
	}

	/**
	 * 查找邀请店主数量
	 */
	@Test
	public void queryMidCount() {
		// MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryInviteCount(100040893594l);
//        Integer integer = mShopShareBindingService.queryMidCount(100049055702L);
		Integer integer = userShareBindingManager.queryMidCount(199720249l);
		System.err.println("结果是：" + integer);
	}

	/**
	 * 邀请的客户数量
	 */
	@Test
	public void queryConsumerCount() {
		// MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryInviteCount(100040893594l);
		Integer integer = userShareBindingManager.queryCustomerCount(199720249l);
		System.err.println("结果是：" + integer);
	}

	@Test
	public void getInviteList() {
		// MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryInviteCount(100040893594l);
//		MapResults<List<MShopPerformanceDto>> inviteList = mShopOwnerInfoManager.getInviteList(100049055702L, 10, 1);
		MapResults<List<MShopPerformanceDto>> inviteList = mShopOwnerInfoManager.getInviteList(100051196548l, 100, 1);
		System.err.println("结果是：" + inviteList.getBuessObj());
	}

	@Test
	public void queryMshopOwnerIndexByUserId() {

//        MapResults<MShopPerformanceDto> mShopPerformanceDtoMapResults = mShopOwnerInfoManager.queryMshopInfoWithPerformance(154546546545L);
//        MapResults<MShopPerformanceDto> mShopPerformanceDtoMapResults = mShopOwnerInfoManager.queryMshopInfoWithPerformance(100049055702L);
		MapResults<MShopOwnerInfoDto> mShopOwnerInfoDtoMapResults = mShopOwnerInfoManager
				.queryMshopOwnerIndexByUserId(100014465913L);
		System.out.println("结果是：" + mShopOwnerInfoDtoMapResults.getBuessObj());
	}

	@Test
	public void converInfoWithHaveAccount() {
		MShopOwnerInfoDto mShopOwnerInfoDto = mShopOwnerInfoManager.converInfoWithHaveAccount(100051184816L);
		System.out.println("结果是：" + mShopOwnerInfoDto);

	}

	/**
	 * 游客，新客，首单，忠粉数量查询
	 */
	@Test
	public void queryOfflineCount() {
//        MapResults<Map<Integer, Integer>> mapMapResults = mShopOwnerInfoManager.queryOfflineCount(100049055702L);
		MapResults<Map<Integer, Integer>> mapMapResults = mShopOwnerInfoManager.queryOfflineCount(100054856723L);
		System.out.println("结果是：" + mapMapResults.getBuessObj());
	}

	/**
	 * 新客，首单，忠粉列表
	 */
	@Test
	public void queryOfflineInfoOfOtherType() {
		MapResults<List<MShopOwnerInfoDto>> listMapResults5 = mShopOwnerInfoManager.queryOfflineInfoOfOtherType(100049064004l, "1", 100, 1);
		System.out.println("结果是：" + listMapResults5.getBuessObj());
	}

	@Test
	public void queryOfflineInfoOfVisitor() {
		MapResults<List<MShopOwnerInfoDto>> listMapResults = mShopOwnerInfoManager.queryOfflineInfoOfVisitor(100054856723L, "2", 10, 1);
		System.err.println("结果是：" + listMapResults.getBuessObj().size());
		List<MShopOwnerInfoDto> buessObj = listMapResults.getBuessObj();
		for (MShopOwnerInfoDto vo : buessObj) {
			System.err.println(vo);
		}
//		List<String> list = mShopShareRecordService.queryUniqueIdListByUpUserId(100049064004l);
//		for (String id : list) {
//			List<MshopWechatUserInfo> mshopWechatUserInfos = mShopWechatService.queryWeChatInfoByUniqueId(id);
//			System.out.println("结果是：" + mshopWechatUserInfos);
//		}
	}

	/**
	 * 王瑞波
	 */
	@Test
	public void queryMshopSolicitingInfo() {
		MapResults<MshopSolicitingVo> mshopSolicitingVoMapResults = mShopOwnerInfoManager.queryMshopSolicitingInfo(100049193042L, 100049064004L);
		System.err.println("结果是：" + mshopSolicitingVoMapResults.getBuessObj());
		MshopSolicitingVo buessObj = mshopSolicitingVoMapResults.getBuessObj();
		System.err.println("数据对象是：" + buessObj);
	}


	@Test
	public void queryOfflineInfoByWeiXinNickName() {

		MapResults<List<MShopOwnerInfoDto>> A = mShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName(100049062015l, "乔大侠");
//		MapResults<List<MShopOwnerInfoDto>> A = mShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName(100049064004l, "aaaaa");
		System.err.println("结果是：" + A.getBuessObj());

	}

	@Test
	public void aaaaa() {
		//有账户，判断该用户是否是我的游客
		MshopShareRecord param = new MshopShareRecord();
		param.setUpuserId(100051209401l);
		param.setUserId(Long.valueOf(100051207507l));
		List<MshopShareRecord> mshopShareRecords = mShopShareRecordService.queryListByParam(param);
		//记录表存在，是游客
		if (CollectionUtils.isNotEmpty(mshopShareRecords)) {
			String time = DateUtil.formatDate(mshopShareRecords.get(0).getUpdateTime(), "YYYY-MM-dd HH:mm:ss");
			System.err.println("时间是：" + time);
		}
	}

	@Test
	public void queryOfflineInfoByPhone() {
		// 笑 100042411621l  15801074261
		//上级：100042411621l  邀请人：100042411621l 下级：100051184816 江米条 13126818519
		//上级：100042411621l  邀请人：100051184816  下级：100038539344 風潇潇 18301036817
//		MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryOfflineInfoByPhone(100042411621l, "15801074261");
		MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryOfflineInfoByPhone(76393460499l, "17057539244");
//		MapResults<MShopOwnerInfoDto> A = mShopOwnerInfoManager.queryOfflineInfoByPhone(100049055702L, "12345678951");
		System.err.println("结果是：" + A.getBuessObj());
	}

	@Test
	public void queryUserIdList() {
		MapResults<List<String>> listMapResults = mShopOwnerInfoManager.queryUserIdList(100049055702L);
		System.err.println("结果是：" + listMapResults.getBuessObj());
	}

	@Test
	public void queryMShopBasicInfoByUserId() {
		MapResults<MShopOwnerInfoDto> mShopOwnerInfoDtoMapResults = mShopOwnerInfoManager.queryMShopBasicInfoByUserId(100036366297l);
        MapResults<MShopOwnerInfoDto> mShopOwnerInfoDtoMapResults2 = mShopOwnerInfoManager.queryMShopBasicInfoByUserId(100036366297l);
		System.err.println("结果是：" + mShopOwnerInfoDtoMapResults.getBuessObj());
	}

	/**
	 * 提奖明细
	 */
	@Test
	public void queryMShopBasicInfoByUserIdBatch() {
//		ArrayList<Long> longs = Lists.newArrayList(100038539344L, 100040845602L, 100049058306L, 100048899922L);
		ArrayList<Long> longs = Lists.newArrayList(100051184816L);
//		ArrayList<Long> longs = Lists.newArrayList(54545L, 45454L, 48454L, 54154L);
		MapResults<List<MShopOwnerInfoDto>> listMapResults = mShopOwnerInfoManager
				.queryMShopBasicInfoByUserIdBatch(longs);
		System.err.println("结果是：" + listMapResults.getBuessObj());
	}


	@Autowired
	private GcacheConfig gCacheConfig;

	private final String DISLOCK_KEY = "MEIDIAN:BINDING_USER_";

	@Test
	public void testCache1() {
		Gcache gcache = gCacheConfig.gcache();
		String switchFlag = gcache.get(DISLOCK_KEY + "SWITCH");
		if (StringUtils.isNotBlank(switchFlag) && switchFlag.equals("true")) {
			System.err.println("结果是：" + switchFlag);
//			insertVshopDescInfo(userId);
		}
	}

	@Test
	public void delCache() {
		Gcache gcache = gCacheConfig.gcache();
		String key = "MShopOwnerInfoManager.queryOfflineInfoByWeiXinNickName";
		gcache.del(key);

	}

	@Test
	public void setCache() {
		Gcache gcache = gCacheConfig.gcache();
		String key = "MShopOwnerInfoManager.queryMshopInfoWithPerformance";
		gcache.hset(key, 123 + "", JSON.toJSONBytes(new MShopOwnerInfoDto()));
		gcache.expire(key, 60);
		byte[] bytes = gcache.hgetBytes(key, 123 + "");
		System.out.println(bytes);

	}

	@Test
	public void testCache() {
		System.out.println();
	}


	@Test
	public void test2() {
		Set<Long> set = new HashSet<>();
		set.add(100051251402L);
		set.add(123L);
		MapResults<List<UserAuthDto>> userAuthList = userShareBindingManager.getUserAuthList(set);
		System.out.println(JSON.toJSONString(userAuthList));
	}
}
