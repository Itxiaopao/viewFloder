import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gome.meidian.user.dto.UserBasicEquitiesNumberDto;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;

public class JsonMapTest {
    @Test
    public void test01(){
        List<Object> collect = Lists.newArrayList().stream().filter(i -> i != null).collect(Collectors.toList());
        System.err.println("结果是：" + collect);

    }
    @Test
    public void testSet(){
        Set<Long> userIdSet = Sets.newHashSet(null, 1l, null);
        Set<Long> userIdSet2 = Sets.newHashSet();
        userIdSet.removeAll(Collections.singleton(null));
        Set<Long> result = Sets.newHashSet();
        if (CollectionUtils.isEmpty(userIdSet)) {
            //直接用userIdSet2去查找
            result.addAll(userIdSet2);
            return;
        }
        //长度只能是1
        if (userIdSet.size() == 1) {
            Long next1 = userIdSet.iterator().next();
            if (CollectionUtils.isEmpty(userIdSet2)) {
                //用next1去查
            }else{
                if(userIdSet2.contains(next1)){
                    //用next1去查
                }
            }
        }
        //如果userIdSet为空，说明没有穿参数，直接用userIdSet2去查询
        //如果userIdSet不为空，并且长度=1,去userIdSet2中找到唯一的id进行去查找
        userIdSet.forEach(i -> System.err.println("去掉null之后的数据" + i));



        if (userIdSet.size() == 1 ){
            if (userIdSet.contains(null)) {
                userIdSet2.forEach(i -> System.err.println("结果是：" + i));
            }else{

            }
        } else {
            if (CollectionUtils.isNotEmpty(userIdSet2)) {
                userIdSet.retainAll(userIdSet2);
                userIdSet.forEach(i -> System.err.println("结果是：" + i));
            }
        }
    }


    @Test
    public void testJSON(){
        String cache=null;
        byte[] bytes = JSON.toJSONBytes(cache, SerializerFeature.WriteNullNumberAsZero);
        System.err.println(new String(bytes));


        String string = JSON.toJSONString(cache,SerializerFeature.WriteMapNullValue);
        System.err.println("string " + string);//null
        System.err.println(StringUtils.isEmpty(string));

    }
    //  map 转 json格式
    public Object mapToJson() {
        Map<String, String> map = new HashMap<String, String>();
        map.put( "1", "aaa" );
        map.put( "2", "bbb" );
        map.put( "3", "ccc" );
        map.put( "4", "ddd" );
        map.put( "5", "eee" );
        map.put( "6", "fff" );
        map.put( "7", "ggg" );
        map.put( "8", "hhh" );
        Object  object=JSON.toJSON(map);
        return object;
    }

    @Test
    public void test(){
        String cache = null;
        UserBasicEquitiesNumberDto result = JSON.parseObject(cache, new TypeReference<UserBasicEquitiesNumberDto>() {
        });
        System.out.println(result);
    }

  /*  public static void main(String[] args) {
        JsonMapTest t = new JsonMapTest();
        System.out.println(t.mapToJson());
    }*/

    public static void main(String[] args){
        int availProcessors = Runtime.getRuntime().availableProcessors();
        System.out.println("avail processors count: " + availProcessors);
    }
}
