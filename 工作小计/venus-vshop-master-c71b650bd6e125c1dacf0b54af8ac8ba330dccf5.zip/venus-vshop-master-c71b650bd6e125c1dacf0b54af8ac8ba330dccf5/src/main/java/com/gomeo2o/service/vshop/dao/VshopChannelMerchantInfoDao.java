package com.gomeo2o.service.vshop.dao;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantInfo;

public interface VshopChannelMerchantInfoDao extends BaseDao<VshopChannelMerchantInfo>{
    
	public VshopChannelMerchantInfo getVshopChannelMerchantInfo(Long id);
}