package com.gomeo2o.service.vshop.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.service.vshop.dao.VshopInfoDescDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopInfoDescDao")
public class VshopInfoDescDaoImpl extends CBaseDaoImpl<VshopInfoDesc> implements VshopInfoDescDao {

    private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopInfoDescDaoImpl.";

	@Override
	public void insertVshopInfoDesc(VshopInfoDesc vshopInfoDesc) {
		this.getSessionTemplate().insert(baseSQL + "insertVshopInfoDesc", vshopInfoDesc);
	}

	@Override
	public void updateVshopInfoDesc(VshopInfoDesc vshopInfoDesc) {
		this.getSessionTemplate().update(baseSQL + "update", vshopInfoDesc);
	}

	@Override
	public List<VshopInfoDesc> queryVshopInfoDescByMap(Map<String, Object> map) {
		return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoDescByMap", map);
	}

	@Override
	public List<VshopInfoDesc> queryVshopInfoDescUnionVshopInfoByParam(Map<String, Object> map) {
		return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoDescUnionVshopInfoByParam", map);
	}

	@Override
	public Long queryCountVshopInfoDescUnionVshopInfoByParam(Map<String, Object> map) {
		return this.getSessionTemplate().selectOne(baseSQL + "queryCountVshopInfoDescUnionVshopInfoByParam", map);
	}

	@Override public void insertOrUpdateVshopInfoDesc(VshopInfoDesc vshopInfoDesc) {
		this.getSessionTemplate().insert(baseSQL + "insertOrUpdateVshopInfoDesc", vshopInfoDesc);
	}

}
