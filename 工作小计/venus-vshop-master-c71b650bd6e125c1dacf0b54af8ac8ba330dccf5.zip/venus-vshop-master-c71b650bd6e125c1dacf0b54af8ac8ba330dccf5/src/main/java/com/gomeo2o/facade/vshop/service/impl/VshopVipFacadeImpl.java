package com.gomeo2o.facade.vshop.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import cn.com.gome.user.service.QueryUserInfoFacade;
import cn.com.gome.user.v2.model.UserVo;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gome.framework.base.ResultDTO;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.pangu.promotionapply.client.budget.BudgetClient;
import com.gome.pangu.promotionapply.client.budget.dto.GomeBudgetParamDTO;
import com.gome.pangu.promotionapply.client.budget.dto.GomePromoActivityDTO;
import com.gome.pangu.promotiondata.client.PromotionQueryService;
import com.gome.pangu.promotiondata.client.dto.promotionRule.CouponRuleDTO;
import com.gome.userBase.facade.staff.IGomeStaffInfoFacade;
import com.gome.userBase.model.staff.GomeStaffInfo;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageBean;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.InvitationVipDto;
import com.gomeo2o.facade.vshop.dto.VshopVipDto;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipCouponProject;
import com.gomeo2o.facade.vshop.entity.VshopVipInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipInfoRecord;
import com.gomeo2o.facade.vshop.entity.VshopVipMshopIdSimpleInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipTeamInfo;
import com.gomeo2o.facade.vshop.enums.CouponProjectStatusEnum;
import com.gomeo2o.facade.vshop.enums.EffectiveEnum;
import com.gomeo2o.facade.vshop.enums.VipIdentityEnum;
import com.gomeo2o.facade.vshop.enums.VshopTypeEnum;
import com.gomeo2o.facade.vshop.enums.VshopVipInfoRecordEnum;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.facade.vshop.exception.VshopVipException;
import com.gomeo2o.facade.vshop.service.VshopVipFacade;
import com.gomeo2o.service.vshop.biz.VipBiz;
import com.gomeo2o.service.vshop.biz.VshopInfoBiz;
import com.gomeo2o.service.vshop.biz.VshopVipInfoBiz;
import com.gomeo2o.service.vshop.biz.VshopVipRelationshipBiz;
import com.gomeo2o.service.vshop.biz.VshopVipTeamMemberInfoBiz;
import com.gomeo2o.service.vshop.dao.VshopVipCouponProjectDao;
import com.gomeo2o.service.vshop.dao.VshopVipInfoRecordDao;
import com.gomeo2o.service.vshop.dao.VshopVipRelationshipDao;
import com.gomeo2o.service.vshop.dao.VshopVipTeamInfoDao;
import com.gomeo2o.service.vshop.dao.VshopVipTeamMemberInfoDao;
import com.gomeo2o.utils.ValidateUtils;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

/**
 * 付费vip相关接口实现
 *
 * @author baixiangzhu
 * @date 2018/4/12
 **/
@Slf4j
@Service("vshopVipFacade")
public class VshopVipFacadeImpl implements VshopVipFacade {

	/** 预算接口令牌 */
	private static final String VERIFICATION_CODE = "0d8e83f51e774ffbaab320c38e374685";
	/** 预算类型，优惠券业务默认为红券 */
	private static final String DEFAULT_BUDGET_TYPE = "10";
	/** 优惠券扣减预算前缀 */
	private static final String MSHOP_COUPON_PLAN = "mshop_coupon_pan_";

	@Autowired
	private VshopInfoBiz vshopInfoBiz;
	@Autowired
	private VipBiz vipBiz;
	@Autowired
	private VshopVipRelationshipDao vshopVipRelationshipDao;
	@Autowired
	private VshopVipTeamMemberInfoDao vshopVipTeamMemberInfoDao;
	@Autowired
	private VshopVipTeamInfoDao vshopVipTeamInfoDao;
	@Autowired
	private VshopVipTeamMemberInfoBiz vshopVipTeamMemberInfoBiz;
	@Autowired
	private VshopVipInfoBiz vshopVipInfoBiz;
	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	@Autowired
	private VshopVipRelationshipBiz vshopVipRelationshipBiz;
	@Autowired
	private VshopVipCouponProjectDao vshopVipCouponProjectDao;
	@Autowired
	private PromotionQueryService promotionQueryService;
	@Autowired
	private BudgetClient budgetClient;
	@Autowired
	private IGomeStaffInfoFacade iGomeStaffInfoFacade;
	@Autowired
	private VshopVipInfoRecordDao vshopVipInfoRecordDao;

	/**
	 * 开通SVIP 1.美店主 2.VIP身份 3.邀请VIP人数>=20
	 *
	 * @param userId
	 *
	 */
	@Transactional
	@Override
	public CommonResultEntity<Boolean> openSVIP(Long userId, String teamName, String teamDesc) {
		log.info("openSVIP params userId=[{}],teamName=[{}],teamDesc=[{}] ", userId, teamName, teamDesc);
		// 校验参数
		if (ValidateUtils.isNull(userId)) {
			throw VshopException.PARAM_IS_NULL;
		}

		CommonResultEntity<Boolean> commonResultEntity = new CommonResultEntity<>();

		// 是否是美店主
		// if (!isVshop(userId)){
		// log.info("the user=[{}] open SVIP error, not open vshop.",userId);
		// throw VshopVipException.VSHOP_EXIST;
		// }

		// 是否已开通vip
		VshopVipInfo vipInfo = vipBiz.getVipInfoByUserId(userId);
		if (null == vipInfo) {
			log.info("the user=[{}] is not open vip.", userId);
			throw VshopVipException.NOT_OPEN_VIP;
		}
		if (!VipIdentityEnum.VIP.name().equals(vipInfo.getIdentity()) || EffectiveEnum.N.name().equals(vipInfo.getIsEffective())) {
			log.info("the user=[{}] is already open svip.vipInfo=[{}]", userId, vipInfo);
			throw VshopVipException.EXIST_OPEN_SVIP;
		}

		// 检查是否邀请20个vip【包含直接和间接邀请？】
		if (!checkInvitationCount(userId)) {
			log.info("the user=[{}] is not invite 20 vip .", userId);
			throw VshopVipException.NO_INVITE_20;
		}

		try {
			doOpenSVIP(userId, teamName, teamDesc);
		} catch (Exception e) {
			// 由于框架捕获异常导致事务不会滚，手动回滚
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			log.error("doOpenSVIP error.", e);
			throw e;
		}

		commonResultEntity.setBusinessObj(Boolean.TRUE);

		return commonResultEntity;
	}

	@Override
	public CommonResultEntity<VshopVipInfo> getVshopVipInfoByUserId(Long userId) {
		CommonResultEntity<VshopVipInfo> commonResultEntity = new CommonResultEntity<VshopVipInfo>();
		VshopVipInfo shopVipInfo = vshopVipInfoBiz.getVshopVipInfoByUserId(userId);
		commonResultEntity.setBusinessObj(shopVipInfo);

		return commonResultEntity;
	}

	/**
	 * 查询用户vip及扩展信息
	 *
	 * @param userId
	 * @return
	 */
	@Override
	public CommonResultEntity<VshopVipDto> getVshopVipExternalInfoByUserId(Long userId) {
		CommonResultEntity<VshopVipDto> commonResultEntity = new CommonResultEntity<VshopVipDto>();
		VshopVipInfo shopVipInfo = vshopVipInfoBiz.getVshopVipInfoByUserId(userId);
		if (shopVipInfo == null) {
			return commonResultEntity;
		}
		VshopVipDto dto = new VshopVipDto();
		BeanUtils.copyProperties(dto, shopVipInfo);
		try {
			// 实时查询配置（允许升级svip需要的邀请数量）
			CommonResultEntity<Integer> inviterCount = getInviterCount();
			Integer count = inviterCount.getBusinessObj();
			// 查询当前用户邀请人数
			CommonResultEntity<Integer> invitedVipCount = getInvitedVipCount(userId);
			Integer vipCount = invitedVipCount.getBusinessObj();
			if (vipCount >= count) {
				dto.setIsApplySvip(1);
			} else {
				dto.setIsApplySvip(0);
			}
		} catch (Exception e) {
			log.error("getVshopVipExternalInfoByUserId error! userId:[{}]", userId, e);
			dto.setIsApplySvip(0);
		}
		commonResultEntity.setBusinessObj(dto);
		return commonResultEntity;
	}

	/**
	 *
	 * @Description: 编辑vip用户信息，修改微信号
	 * @author: zhaoxingxing
	 * @date: 2018年4月13日 上午10:05:37
	 * @param vshopVipInfo
	 * @return
	 */
	@Override
	public CommonResultEntity<String> updateVip(VshopVipInfo vshopVipInfo) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		// 校验用户id不能为空
		ValidateUtils.notNull(vshopVipInfo, "userId");
		String qrNo = vshopVipInfo.getQrNo();
		if (ValidateUtils.isNull(qrNo)) {
			throw VshopException.PARAM_IS_NULL;
		}
		vipBiz.updateVip(vshopVipInfo);
		return cre;
	}

	@Override
	public CommonResultEntity<VshopVipInfo> getTutorVipInfoByUserId(Long userId) {
		CommonResultEntity<VshopVipInfo> cre = new CommonResultEntity<VshopVipInfo>();
		// 校验用户id不能为空
		if (ValidateUtils.isNull(userId)) {
			throw VshopException.PARAM_IS_NULL;
		}
		VshopVipInfo vshopVipInfo = vipBiz.queryVshopVipInfoByUserId(userId);
		cre.setBusinessObj(vshopVipInfo);
		return cre;
	}

	/**
	 * 运营后台分页查询
	 *
	 * @param pageParam
	 * @param map
	 * @return
	 */
	@Override
	public CommonResultEntity<List<Map<String, Object>>> queryVipInfo(PageParam pageParam, Map<String, Object> map) {
		log.info("queryVipInfo,pageParam={},map={}", pageParam, map);
		CommonResultEntity<List<Map<String, Object>>> result = new CommonResultEntity<List<Map<String, Object>>>();
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		if (map.containsKey("shopId") || map.containsKey("shopName")) {
			if (null != map.get("shopId") || null != map.get("shopName")) {
				log.info("queryVipInfo,含美店查询条件");
				// 含美店查询条件
				Map<String,Object> newMap = new HashMap<>();
				if (null != map.get("shopName")) {
					newMap.put("shopName",String.valueOf(map.get("shopName")));
				}
				if (null != map.get("shopId")) {
					newMap.put("shopId" ,(Long) map.get("shopId"));
				}
				if (null != map.get("userId")) {
					newMap.put("userId",(Long) map.get("userId"));
				}
				List<VshopInfo> shopList = this.vshopInfoBiz.queryVshopInfoListByCriteria(pageParam, newMap);
				for (VshopInfo shop : shopList) {
					Map<String, Object> sqlParams = new HashMap<String, Object>();
					sqlParams.put("userId", shop.getUserId());
					if (map.containsKey("source") && null != map.get("source")) {
						sqlParams.put("source", (Integer) map.get("source"));
					}
					if (map.containsKey("startTime") && null != map.get("startTime")) {
						sqlParams.put("startTime", (String) map.get("startTime"));
					}
					if (map.containsKey("endTime") && null != map.get("endTime")) {
						sqlParams.put("endTime", (String) map.get("endTime"));
					}
					List<VshopVipInfo> vipList = this.vshopVipInfoBiz.adminPageQueryVipInfo(pageParam, sqlParams);
					// VshopVipInfo
					// vip=this.vshopVipInfoBiz.getVshopVipInfoByUserId(shop.getUserId());
					if (null != vipList && 0 < vipList.size()) {
						VshopVipInfo vip = vipList.get(0);
						Map<String, Object> data = convertMap(vip, shop);
						log.info("queryVipInfo,data={}", data);
						if (null != data && !data.isEmpty()) {
							list.add(data);
						}
					}
				}
			}
		} else {
			log.info("queryVipInfo,不含美店查询条件");
			Map<String, Object> sqlParams = new HashMap<String, Object>();
			if (map.containsKey("userId") && null != map.get("userId")) {
				sqlParams.put("userId", (Long) map.get("userId"));
			}
			if (map.containsKey("source") && null != map.get("source")) {
				sqlParams.put("source", (Integer) map.get("source"));
			}
			if (map.containsKey("startTime") && null != map.get("startTime")) {
				sqlParams.put("startTime", (String) map.get("startTime"));
			}
			if (map.containsKey("endTime") && null != map.get("endTime")) {
				sqlParams.put("endTime", (String) map.get("endTime"));
			}
			// 不含美店查询条件
			List<VshopVipInfo> vipList = this.vshopVipInfoBiz.adminPageQueryVipInfo(pageParam, sqlParams);
			log.info("queryVipInfo,vipList={}", vipList);
			for (VshopVipInfo vip : vipList) {
				log.info("queryVipInfo,vip={}", vip);
				VshopInfo vshopInfo = this.vshopInfoBiz.queryVshopByuserId(vip.getUserId());
				Map<String, Object> data = null;
				if (null != vshopInfo) {
					data = convertMap(vip, vshopInfo);
				} else {
					data = convertMap(vip, null);
				}
				log.info("queryVipInfo,data={}", data);
				if (null != data && !data.isEmpty()) {
					list.add(data);
				}
			}
		}
		if (null != list && 0 < list.size()) {
			result.setBusinessObj(list);
		} else {
			result.setBusinessObj(null);
		}
		log.info("queryVipInfo,result={}", result);
		return result;
	}

	@Override
	public CommonResultEntity<Long> queryVipInfoCount(Map<String, Object> map) {
		log.info("queryVipInfoCount,map={}", map);
		CommonResultEntity<Long> result = new CommonResultEntity<Long>();
		Map<String, Object> sqlParams = new HashMap<String, Object>();
		Long resultCount = 0L;
		if (map.containsKey("shopId") || map.containsKey("shopName")) {
			if (null != map.get("shopId") || null != map.get("shopName")) {
				// 含美店查询条件
				log.info("queryVipInfoCount,含美店查询条件");
				if (null != map.get("shopName")) {
					sqlParams.put("vshopName", (String) map.get("shopName"));
				}
				if (null != map.get("shopId")) {
					sqlParams.put("vshopId", (Long) map.get("shopId"));
				}
				if (map.containsKey("userId") && null != map.get("userId")) {
					sqlParams.put("userId", (Long) map.get("userId"));
				}
				List<VshopInfo> shopList = this.vshopInfoBiz.queryVshopInfoListForVip(sqlParams);
				for (VshopInfo shop : shopList) {
					sqlParams.clear();
					sqlParams.put("userId", shop.getUserId());
					if (map.containsKey("source") && null != map.get("source")) {
						sqlParams.put("source", (Integer) map.get("source"));
					}
					if (map.containsKey("startTime") && null != map.get("startTime")) {
						sqlParams.put("startTime", (String) map.get("startTime"));
					}
					if (map.containsKey("endTime") && null != map.get("endTime")) {
						sqlParams.put("endTime", (String) map.get("endTime"));
					}
					Long count = this.vshopVipInfoBiz.adminPageQueryVipInfoCount(sqlParams);
					if (null != count && 0 != count) {
						resultCount = resultCount + count;
					}
				}
			}
		} else {
			log.info("queryVipInfoCount,不含美店查询条件");
			// 不含美店查询条件
			if (map.containsKey("userId") && null != map.get("userId")) {
				sqlParams.put("userId", (Long) map.get("userId"));
			}
			if (map.containsKey("source") && null != map.get("source")) {
				sqlParams.put("source", (Integer) map.get("source"));
			}
			if (map.containsKey("startTime") && null != map.get("startTime")) {
				sqlParams.put("startTime", (String) map.get("startTime"));
			}
			if (map.containsKey("endTime") && null != map.get("endTime")) {
				sqlParams.put("endTime", (String) map.get("endTime"));
			}
			resultCount = this.vshopVipInfoBiz.adminPageQueryVipInfoCount(sqlParams);
		}
		result.setBusinessObj(resultCount);
		log.info("queryVipInfoCount,result={}", result);
		return result;
	}

	/**
	 * 运营后台根据userId查询用户信息
	 * @param userId
	 * @return
	 */
	@Override
	public CommonResultEntity<Map<String, Object>> queryUserInfo(Long userId) {
		log.info("queryUserInfo,userId={}", userId);
		CommonResultEntity<Map<String, Object>> result = new CommonResultEntity<Map<String, Object>>();
		Map<String, Object> data = new HashMap<String, Object>();
		CommonResultEntity<UserVo> userVoResult = null;
		try {
			userVoResult = queryUserInfoFacade.queryUserInfoByOnlineUserId(String.valueOf(userId));
		} catch (Exception e) {
			log.error("queryUserInfo,queryUserInfoFacade.queryUserInfoByOnlineUserId exception:{}", e);
		}
		if (null == userVoResult || null == userVoResult.getBusinessObj()) {
			log.error("queryUserInfo,queryUserInfoFacade.queryUserInfoByOnlineUserId is null");
			return null;
		}
		Map<String, Object> user = new HashMap<String, Object>();
		user.put("userId", userId);
		user.put("nickName", userVoResult.getBusinessObj().getNickname());
		user.put("mobile", userVoResult.getBusinessObj().getMobile());
		data.put("user", user);
		VshopInfo vshopInfo = this.vshopInfoBiz.queryVshopByuserId(userId);
		if (null != vshopInfo) {
			Map<String, Object> shop = new HashMap<String, Object>();
			shop.put("shopId", vshopInfo.getVshopId());
			shop.put("shopName", vshopInfo.getVshopName());
			data.put("shop", shop);
		}
		result.setBusinessObj(data);
		log.info("queryUserInfo,result={}", result);
		return result;
	}

	/**
	 * 运营后台开通VIP或者SVIP
	 *
	 * @param userId
	 * @param opType
	 *            1-VIP 2-SVIP
	 * @return
	 */
	@Transactional
	@Override
	public CommonResultEntity<Void> adminOpenVip(Long userId, Integer opType, Integer validTime, String remark) {
		CommonResultEntity<Void> result = new CommonResultEntity<Void>();
		log.info("adminOpenVip,userId={},opType={},validTime={},remark={}", userId, opType, validTime, remark);
		if (null == userId || null == opType) {
			throw VshopException.PARAM_IS_NULL;
		}
		VshopVipInfo vip = this.vshopVipInfoBiz.getVshopVipInfoByUserId(userId);
		log.info("adminOpenVip,vip={}", vip);
		Calendar c = Calendar.getInstance();
		VshopVipInfoRecord record = new VshopVipInfoRecord();
		switch (opType) {
		case 1:
			// 开通VIP
			if (null != vip && (!"SVIP".equals(vip.getIdentity()))) {
				VshopVipInfo update = new VshopVipInfo();
				Date newDate = null;
				if ("Y".equals(vip.getIsEffective())) {
					// 有效还未到，续费场景
					c.setTime(vip.getEndEffectiveTime());// 当前有效期
					c.add(Calendar.DATE, validTime);// 延长当前有效期
					newDate = c.getTime();
					log.info("adminOpenVip,开通VIP，有效还未到，续费场景");

					record.setEndEffectiveTime(newDate);
					record.setStartEffectiveTime(vip.getStartEffectiveTime());
				} else {
					// 已过期，续费场景
					Date current = new Date();
					c.setTime(current);// 当前日期
					c.add(Calendar.DATE, validTime);// 加有效期
					newDate = c.getTime();
					update.setStartEffectiveTime(current);
					log.info("adminOpenVip,开通VIP，已过期，续费场景");

					record.setEndEffectiveTime(newDate);
					record.setStartEffectiveTime(current);
				}
				update.setUserId(userId);
				update.setIdentity("VIP");
				update.setIsEffective("Y");
				update.setIsPermanent("N");
				update.setSource(2);
				update.setUpdateTime(new Date());
				update.setEndEffectiveTime(newDate);
				log.info("adminOpenVip,update={}", update);
				this.vipBiz.updateVip(update);

				record.setUpdateTime(new Date());
				record.setVipRemark(remark);
				record.setUserId(userId);
				record.setCreateTime(new Date());
				record.setRemark(VshopVipInfoRecordEnum.BACKSTAGE_REOPEN_VIP.getDesc());
				this.vshopVipInfoRecordDao.insert(record);
				return result;
			} else {
				Date current = new Date();
				c.setTime(current);// 当前日期
				c.add(Calendar.DATE, validTime);// 加有效期
				Date newDate = c.getTime();
				vip = new VshopVipInfo();
				vip.setIdentity("VIP");
				vip.setUserId(userId);
				vip.setIsEffective("Y");
				vip.setIsPermanent("N");
				vip.setSource(2);// 后台开通
				vip.setCreateTime(new Date());
				vip.setUpdateTime(new Date());
				vip.setStartEffectiveTime(current);
				vip.setEndEffectiveTime(newDate);
				log.info("adminOpenVip,开通VIP，全新开通场景");
				log.info("adminOpenVip,save={}", vip);
				this.vipBiz.createVip(vip);

				record.setEndEffectiveTime(vip.getEndEffectiveTime());
				record.setStartEffectiveTime(vip.getStartEffectiveTime());
				record.setUpdateTime(new Date());
				record.setVipRemark(remark);
				record.setUserId(userId);
				record.setCreateTime(new Date());
				record.setRemark(VshopVipInfoRecordEnum.BACKSTAGE_OPEN_VIP.getDesc());
				this.vshopVipInfoRecordDao.insert(record);
			}
			break;
		case 2:
			// 开通SVIP
			if (null != vip) {
				VshopVipInfo update = new VshopVipInfo();
				Date oneyearlater = null;
				if ("SVIP".equals(vip.getIdentity()) && "N".equals(vip.getIsEffective())) {
					// 已过期，续费场景
					Date current = new Date();
					c.setTime(current);// 当前日期
					c.add(Calendar.YEAR, 1);// 加有效期
					oneyearlater = c.getTime();
					update.setStartEffectiveTime(current);
					update.setUserId(userId);
					update.setEndEffectiveTime(oneyearlater);// 新有效期
					update.setIdentity("SVIP");
					update.setIsEffective("Y");
					update.setIsPermanent("Y");
					update.setSource(2);
					update.setUpdateTime(new Date());
					log.info("adminOpenVip,开通SVIP，已过期，续费场景");
					log.info("adminOpenVip,update={}", update);
					this.vipBiz.updateVip(update);

					record.setEndEffectiveTime(update.getEndEffectiveTime());
					record.setStartEffectiveTime(update.getStartEffectiveTime());
					record.setUpdateTime(new Date());
					record.setSvipRemark(remark);
					record.setUserId(userId);
					record.setCreateTime(new Date());
					record.setRemark(VshopVipInfoRecordEnum.BACKSTAGE_OPEN_SVIP.getDesc());
					this.vshopVipInfoRecordDao.insert(record);
				}
				if ("VIP".equals(vip.getIdentity())) {
					Date current = new Date();
					c.setTime(current);// 当前日期
					c.add(Calendar.YEAR, 1);// 加有效期
					oneyearlater = c.getTime();
					update.setUserId(userId);
					update.setEndEffectiveTime(oneyearlater);// 新有效期
					update.setIdentity("SVIP");
					update.setIsEffective("Y");
					update.setIsPermanent("Y");
					update.setSource(2);
					update.setUpdateTime(new Date());
					log.info("adminOpenVip,开通SVIP，VIP升级开通场景");
					log.info("adminOpenVip,update={}", update);
					this.vipBiz.updateVip(update);

					record.setEndEffectiveTime(update.getEndEffectiveTime());
					record.setStartEffectiveTime(update.getStartEffectiveTime());
					record.setUpdateTime(new Date());
					record.setSvipRemark(remark);
					record.setUserId(userId);
					record.setCreateTime(new Date());
					record.setRemark(VshopVipInfoRecordEnum.BACKSTAGE_OPEN_SVIP.getDesc());
					this.vshopVipInfoRecordDao.insert(record);
				}
			} else {
				Date current = new Date();
				c.setTime(current);// 当前日期
				c.add(Calendar.YEAR, 1);// 加一年
				Date oneyearlater = c.getTime();
				vip = new VshopVipInfo();
				vip.setIdentity("SVIP");
				vip.setUserId(userId);
				vip.setIsEffective("Y");
				vip.setIsPermanent("Y");
				vip.setSource(2);
				vip.setCreateTime(new Date());
				vip.setUpdateTime(new Date());
				vip.setStartEffectiveTime(current);
				vip.setEndEffectiveTime(oneyearlater);
				log.info("adminOpenVip,开通SVIP，全新开通场景");
				log.info("adminOpenVip,vip={}", vip);
				this.vipBiz.createVip(vip);

				record.setEndEffectiveTime(current);
				record.setStartEffectiveTime(oneyearlater);
				record.setUpdateTime(new Date());
				record.setSvipRemark(remark);
				record.setUserId(userId);
				record.setCreateTime(new Date());
				record.setRemark(VshopVipInfoRecordEnum.BACKSTAGE_OPEN_SVIP.getDesc());
				this.vshopVipInfoRecordDao.insert(record);
			}
			createTeamMember(userId, null, null);
			break;
		default:
			break;
		}
		return result;
	}

	/**
	 * Bean 转 Map
	 *
	 * @param vip
	 * @param shop
	 * @return
	 */
	private Map<String, Object> convertMap(VshopVipInfo vip, VshopInfo shop) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Map<String, Object> map = new HashMap<String, Object>();
		CommonResultEntity<UserVo> userVoResult = null;
		try {
			userVoResult = queryUserInfoFacade.queryUserInfoByOnlineUserId(String.valueOf(vip.getUserId()));
			log.info("queryUserInfoFacade.queryUserInfoByOnlineUserId,userVoResult={}", userVoResult);
		} catch (Exception e) {
			log.error("queryUserInfoFacade.queryUserInfoByOnlineUserId,exception:{}", e);
		}
		if (null != userVoResult && null != userVoResult.getBusinessObj()) {
			map.put("userNickName", userVoResult.getBusinessObj().getNickname());
		} else {
			map.put("userNickName", "");
		}
		Long beginTime = System.currentTimeMillis();
		UserResult<GomeStaffInfo> resultEntity = null;
		log.info("iGomeStaffInfoFacade.getStaffInfoByUserId,userId={}", vip.getUserId());
		try {
			resultEntity = this.iGomeStaffInfoFacade.getStaffInfoByUserId(String.valueOf(vip.getUserId()), "gomePlus");
			log.info("iGomeStaffInfoFacade.getStaffInfoByUserId result:{},time:{}ms", resultEntity, (System.currentTimeMillis() - beginTime));
		} catch (Exception e) {
			log.error("iGomeStaffInfoFacade.getStaffInfoByUserId，exception:{}", e);
			log.info("try again iGomeStaffInfoFacade.getStaffInfoByUserIds");
			resultEntity = this.iGomeStaffInfoFacade.getStaffInfoByUserId(String.valueOf(vip.getUserId()), "gomePlus");
			log.info("iGomeStaffInfoFacade.getStaffInfoByUserId result:{}", resultEntity);
		}
		if (null != resultEntity && resultEntity.isSuccess() && null != resultEntity.getBuessObj()) {
			GomeStaffInfo gomeStaffInfo = resultEntity.getBuessObj();
			if (StringUtils.isNotBlank(gomeStaffInfo.getOrgNo())) {
				map.put("userType", "门店员工");
			} else {
				map.put("userType", "线上员工");
			}
		} else {
			if (null != shop) {
				map.put("userType", "非员工");
			} else {
				map.put("userType", "其他");
			}
		}
		if (null != shop) {
			map.put("shopId", shop.getVshopId());
			map.put("shopName", shop.getVshopName());
		}
		map.put("id", vip.getId());
		map.put("userId", vip.getUserId());
		map.put("identity", vip.getIdentity());
		if (StringUtils.isNotBlank(vip.getQrNo())) {
			map.put("qrNo", vip.getQrNo());
		}
		if (1 == vip.getSource()) {
			map.put("source", "付费开通");
		}
		if (2 == vip.getSource()) {
			map.put("source", "免费开通");
		}
		if (StringUtils.isNotBlank(vip.getOrderNo())) {
			map.put("orderNo", vip.getOrderNo());
		}
		if (null != vip.getStartEffectiveTime()) {
			map.put("startEffectiveTime", sdf.format(vip.getStartEffectiveTime()));
		}
		if ("SVIP".equals(vip.getIdentity())) {
			map.put("endEffectiveTime", "");// SVIP不展示到期时间
		} else {
			if (null != vip.getEndEffectiveTime()) {
				map.put("endEffectiveTime", sdf.format(vip.getEndEffectiveTime()));
			}
		}
		if (StringUtils.isNotBlank(vip.getIdentity())) {
			map.put("identity", vip.getIdentity());
		}
		if ("Y".equals(vip.getIsEffective())) {
			map.put("isEffective", "生效");
		} else {
			map.put("isEffective", "无效");
		}
		if ("Y".equals(vip.getIsPermanent())) {
			map.put("isPermanent", "是");
		} else {
			map.put("isPermanent", "否");
		}
		return map;
	}

	/**
	 * 具体开通svip流程
	 *
	 * @param userId
	 * @param teamName
	 * @param teamDesc
	 */
	private void doOpenSVIP(Long userId, String teamName, String teamDesc) {

		// 更新vipInfo身份
		VshopVipInfo updateVipInfo = new VshopVipInfo();
		updateVipInfo.setUserId(userId);
		updateVipInfo.setIdentity(VipIdentityEnum.SVIP.name());
		updateVipInfo.setIsPermanent("Y"); // 永久有效
		vipBiz.updateVip(updateVipInfo);

		// 创建团队
		createTeamMember(userId, teamName, teamDesc);
	}

	/**
	 * 校验是否是美店主
	 *
	 * @param userId
	 * @return
	 */
	private boolean isVshop(Long userId) {

		VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);

		return (null != vshopInfo && VshopTypeEnum.MEIDIAN.getValue() == vshopInfo.getVshopType());
	}

	/**
	 * 校验当前用户邀请人数是否大于等于20
	 *
	 * @param currentUserId
	 * @return
	 */
	private boolean checkInvitationCount(Long currentUserId) {

		// 查询直接邀请的vip人数
		Integer inviteCount = vshopVipRelationshipDao.countVshopVipRelationshipByInviterUserId(currentUserId, "1");

		log.info("the user=[{}] invite [{}] vip.", currentUserId, inviteCount);
		int  inviteCountLimit = 9999;
		log.info("checkInvitationCount,inviteCountLimit={}", inviteCountLimit);
		return inviteCount != null && inviteCount >= inviteCountLimit;
	}

	/**
	 * 创建团队
	 *
	 * @param userId
	 * @param teamName
	 * @param teamDesc
	 */
	private void createTeamMember(Long userId, String teamName, String teamDesc) {

		// 创建新的团队
		VshopVipTeamInfo vshopVipTeamInfo = new VshopVipTeamInfo();
		vshopVipTeamInfo.setTutorUserId(userId);
		vshopVipTeamInfo.setTeamName(teamName);
		vshopVipTeamInfo.setTeamDesc(teamDesc);
		vshopVipTeamInfoDao.insert(vshopVipTeamInfo);

		// 查询团队成员信息
		Long tutorUserId = vshopVipTeamMemberInfoDao.queryTutorUserIdByMemberUserId(userId);

		// 如果在svip团队中，则退出团队
		if (null != tutorUserId) {
			// 退出原团队
			vshopVipTeamMemberInfoDao.quitVipTeamMember(userId, new Date());
			return;
		}
	}

	@Override
	public CommonResultEntity<PageBean> getVshopVipRelationships(PageParam pageParam, Long inviterUserId) {

		return vshopVipRelationshipBiz.getVshopVipRelationships(pageParam, inviterUserId);
	}

	@Override
	public CommonResultEntity<Integer> getInvitedVipCount(Long inviterUserId) {

		return vshopVipRelationshipBiz.getInvitedVipCount(inviterUserId);
	}

	@Override
	public CommonResultEntity<PageBean> getVshopVipTeamMembers(PageParam pageParam, Long tutorUserId) {

		return vshopVipTeamMemberInfoBiz.getVshopVipTeamMembers(pageParam, tutorUserId);
	}

	@Override
	public CommonResultEntity<Integer> getInviterCount() {
		CommonResultEntity<Integer> cre = new CommonResultEntity<>();
		cre.setBusinessObj(9999);
		return cre;
	}

	@Override
	public CommonResultEntity<VshopVipInfo> invitationOpenVip(InvitationVipDto invitationVipDto) {
		CommonResultEntity<VshopVipInfo> cre = new CommonResultEntity<>();
		// 发放优惠券
		try {
			vipBiz.sendCoupon(invitationVipDto.getUserId(), invitationVipDto.getOrderNo());
		} catch (Exception e) {
			log.error("sendCoupon error! userId:[{}],orderNo:[{}]", invitationVipDto.getUserId(), invitationVipDto.getOrderNo(), e);
		}
		VshopVipInfo vshopVipInfo = vipBiz.invitationOpenVip(invitationVipDto);
		cre.setBusinessObj(vshopVipInfo);
		return cre;
	}

	@Override
	public CommonResultEntity<VshopVipInfo> renewVip(InvitationVipDto invitationVipDto) {
		CommonResultEntity<VshopVipInfo> cre = new CommonResultEntity<>();
		VshopVipInfo vvi = vshopVipInfoBiz.getVshopVipInfoByUserId(invitationVipDto.getUserId());
		boolean flag = checkVipInfo(vvi, invitationVipDto.getOrderTime());
		if (!flag) {
			throw VshopVipException.VIP_INFO_INVALID;
		}
		// 发放优惠券
		try {
			vipBiz.sendCoupon(invitationVipDto.getUserId(), invitationVipDto.getOrderNo());
		} catch (Exception e) {
			log.error("sendCoupon error! userId:[{}],orderNo:[{}]", invitationVipDto.getUserId(), invitationVipDto.getOrderNo(), e);
		}
		VshopVipInfo vshopVipInfo = vipBiz.renewVip(vvi, invitationVipDto);
		cre.setBusinessObj(vshopVipInfo);
		return cre;
	}

	/* 校验vip续费，1是vip，2当前生效，3距离过期前1个月范围内 */
	private boolean checkVipInfo(VshopVipInfo vvi, Date orderTime) {
		if (vvi == null || VipIdentityEnum.SVIP.toString().equals(vvi.getIdentity()) || "N".equals(vvi.getIsEffective())) {
			return Boolean.FALSE;
		}

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date endEffectiveTime = vvi.getEndEffectiveTime();

			Calendar endDate = Calendar.getInstance();
			endDate.setTime(sdf.parse(sdf.format(endEffectiveTime)));

			Calendar oneMonthBeforeDate = Calendar.getInstance();
			oneMonthBeforeDate.setTime(sdf.parse(sdf.format(endEffectiveTime)));
			oneMonthBeforeDate.add(Calendar.MONTH, -1);

			Calendar orderDate = Calendar.getInstance();
			orderDate.setTime(sdf.parse(sdf.format(orderTime)));

			if (orderDate.before(endDate) && orderDate.after(oneMonthBeforeDate))
				return Boolean.TRUE;
			else
				return Boolean.FALSE;
		} catch (Exception e) {
			log.error("checkVipInfo error.", e);
			return Boolean.FALSE;
		}
	}

	/**
	 * 查询优惠券方案列表
	 *
	 * @param pageParam
	 * @param params
	 * @return
	 */
	@Override
	public CommonResultEntity<List<VshopVipCouponProject>> queryCouponList(PageParam pageParam, Map<String, Object> params) {

		if (pageParam != null) {
			params.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
			params.put("pageSize", pageParam.getNumPerPage());
		}

		List<VshopVipCouponProject> projectList = vshopVipCouponProjectDao.queryListByCondition(params);

		CommonResultEntity<List<VshopVipCouponProject>> cre = new CommonResultEntity<>();
		cre.setBusinessObj(projectList);

		return cre;
	}

	/**
	 * 查询优惠券方案数量
	 *
	 * @param params
	 * @return
	 */
	@Override
	public CommonResultEntity<Long> queryCouponCount(Map<String, Object> params) {
		Long count = vshopVipCouponProjectDao.selectCount(params);

		CommonResultEntity<Long> cre = new CommonResultEntity<>();
		cre.setBusinessObj(count);

		return cre;
	}

	/**
	 * 新建优惠券方案
	 *
	 * @param couponProject
	 * @return
	 */
	@Transactional
	@Override
	public CommonResultEntity<Boolean> addCouponProject(VshopVipCouponProject couponProject) {

		log.info("add Coupon project params =[{}]", couponProject);
		CommonResultEntity<Boolean> cre = new CommonResultEntity<>();

		// 检查时间冲突
		// boolean isConflict =
		// checkProjectConflict(couponProject.getEffectiveStartTime(),
		// couponProject.getEffectiveEndTime());
		// if (isConflict){
		// throw VshopVipException.EFFECT_DATE_CONFLICT;
		// }

		String budgetNumber = couponProject.getBudgetNumber();
		// 1.校验预算信息
		GomePromoActivityDTO budgetInfo = this.getBudgetInfo(budgetNumber);

		if (null == budgetInfo) {
			throw VshopVipException.BUDGET_NUM_ERROR;
		}

		// 检查有效期是否符合
		// boolean checkBudget = checkBudgetEffectiveDate(budgetInfo,
		// couponProject.getEffectiveStartTime(),
		// couponProject.getEffectiveEndTime());
		// if (!checkBudget){
		// throw VshopVipException.BUDGET_EFFECTIVE_DATE_NOT_MATCH;
		// }

		// 预算
		Double budget = budgetInfo.getBudget();

		// 2.校验规则ID
		Double regularAmount = this.getRegularAmount(couponProject.getRegularContent());
		if (null == regularAmount) {
			throw VshopVipException.REGULAR_ID_NOT_EXIST;

		}

		// 3.校验是否超预算
		// 礼包预算
		Double giftBudget = regularAmount * couponProject.getGiftTotalCount();
		if (giftBudget > budget) {
			throw VshopVipException.OVER_BUDGET;
		}

		try {
			// 4.创建预算记录
			// 默认生效
			couponProject.setStatus(CouponProjectStatusEnum.ALREADY_EFFECT.getCode());
			couponProject.setBudgetConsume(new BigDecimal(giftBudget));
			long id = vshopVipCouponProjectDao.insert(couponProject);

			// 5.扣减预算
			GomeBudgetParamDTO paramDTO = new GomeBudgetParamDTO();
			paramDTO.setPromId(MSHOP_COUPON_PLAN + couponProject.getId());
			paramDTO.setActivityNo(budgetNumber);
			paramDTO.setChangeBudget(giftBudget);
			ResultDTO<Boolean> booleanResultDTO = budgetClient.subtractRemainingBudget(UUID.randomUUID().toString(), VERIFICATION_CODE, paramDTO);
			log.info("decline budget result = [{}],params=[{}]", ReflectionToStringBuilder.toString(booleanResultDTO),
					ReflectionToStringBuilder.toString(paramDTO));

			if (!booleanResultDTO.isSuccess() || !booleanResultDTO.getData()) {
				// 如果扣减预算失败，主动回滚事务
				TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
			}

		} catch (Exception e) {
			log.error("decline budget error.budgetNumber=[{}]", budgetNumber, e);
			// 异常回滚事务
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		}
		cre.setBusinessObj(true);

		return cre;
	}

    /**
     *
     * @Description: 发放优惠券(签到兑换优惠券提供)
     * @author: guowenbo
     * @param userId 用户id
     * @param RegularIdList 红券list
     * @param orderNo 订单No
     * @return
     */
    @Override
    public CommonResultEntity<String> sendCoupon(Long userId, List<String> RegularIdList, String orderNo) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        if (RegularIdList == null || RegularIdList.size() <= 0){
            throw VshopVipException.REGULARID_INVALID;
        }
        String s = vipBiz.sendCoupon(userId, RegularIdList, orderNo);
        if(StringUtils.isNotBlank(s)){
            throw new VshopException(189999,s);
        }
        return cre;
    }

    /**
     * 校验预算是否有效
     * @param budgetInfo
     * @param effectiveStartTime
     * @param effectiveEndTime
     * @return
     */
    private boolean checkBudgetEffectiveDate(GomePromoActivityDTO budgetInfo, Date effectiveStartTime, Date effectiveEndTime) {

		Long state = budgetInfo.getState();
		// 0：激活；1：终止
		if (state != 0) {
			return false;
		}

		Date startDate = budgetInfo.getStartDate();
		Date endDate = budgetInfo.getEndDate();

		if (startDate.compareTo(effectiveStartTime) < 0 || endDate.compareTo(effectiveEndTime) > 0) {
			return true;
		}

		return false;
	}

	/**
	 * 比较两个日期是否冲突
	 *
	 * @param startDate
	 * @param endDate
	 * @param compareStartDate
	 * @param compareEndDate
	 * @return
	 */
	private boolean checkDateConflict(Date startDate, Date endDate, Date compareStartDate, Date compareEndDate) {

		// 开始时间在有效期内
		if (startDate.compareTo(compareStartDate) >= 0 && startDate.compareTo(compareEndDate) < 0) {
			return true;
		}

		// 结束时间在有效期内
		if (endDate.compareTo(compareStartDate) >= 0 && endDate.compareTo(compareEndDate) < 0) {
			return true;
		}

		// 开始时间小于有效期，结束时间大于有效期
		if (startDate.compareTo(compareStartDate) <= 0 && endDate.compareTo(compareEndDate) > 0) {
			return true;
		}

		return false;
	}

	/**
	 * 校验日期是否冲突
	 *
	 * @param effectStartTime
	 * @param effectEndTime
	 * @return
	 */
	private boolean checkProjectConflict(Date effectStartTime, Date effectEndTime) {

		// 加载所有审核通过或者生效的计划
		List<VshopVipCouponProject> allEffectiveProject = vshopVipCouponProjectDao.getAllEffectiveProject();

		for (VshopVipCouponProject project : allEffectiveProject) {

			if (checkDateConflict(effectStartTime, effectEndTime, project.getEffectiveStartTime(), project.getEffectiveEndTime())) {

				return true;
			}
		}

		return false;
	}

	/**
	 * 校验规则ID，并获取规则ID对于的优惠券金额
	 *
	 * @param regularContent
	 */
	private Double getRegularAmount(String regularContent) {

		if (StringUtils.isEmpty(regularContent)) {
			return null;
		}

		Double totalAmount = 0.0;

		JSONArray regularArr = JSONArray.parseArray(regularContent);

		if (regularArr.isEmpty()) {
			return null;
		}

		Map<String, Integer> regularCache = Maps.newHashMap();

		for (Object obj : regularArr) {
			JSONObject regularInfo = (JSONObject) obj;
			String regularId = regularInfo.getString("regularId");
			Integer count = regularInfo.getInteger("count");

			regularCache.put(regularId, count);
		}

		// 获取规则信息
		ResultDTO<List<CouponRuleDTO>> listResultDTO = promotionQueryService.queryCouponValueByRuleInfo(Lists.newArrayList(regularCache.keySet()));

		log.info("get ruleInfo result =[{}],params=[{}]", ReflectionToStringBuilder.toString(listResultDTO), regularCache.keySet());

		if (!listResultDTO.isSuccess()) {
			return null;
		}

		List<CouponRuleDTO> data = listResultDTO.getData();

		for (CouponRuleDTO dto : data) {

			String ruleId = dto.getRuleId();
			Double amount = dto.getAmount();

			Integer count = regularCache.get(ruleId);
			totalAmount += amount * count;
		}

		return totalAmount;
	}

	/**
	 * 获取预算信息
	 *
	 * @return
	 */
	private GomePromoActivityDTO getBudgetInfo(String budgetNumber) {
		GomeBudgetParamDTO dto = new GomeBudgetParamDTO();
		dto.setActivityNo(budgetNumber);
		dto.setBudgetTypes(Lists.newArrayList(DEFAULT_BUDGET_TYPE));

		ResultDTO<List<GomePromoActivityDTO>> remainingBudgetDTO_v1 = budgetClient.getRemainingBudgetDTO_V1(VERIFICATION_CODE, dto);

		log.info("get budget Info result = [{}],params = [{}]", ReflectionToStringBuilder.toString(remainingBudgetDTO_v1), dto);

		if (remainingBudgetDTO_v1.isSuccess()) {
			return remainingBudgetDTO_v1.getData().get(0);
		}
		return null;
	}


	/**
	 * 查询所有vip userId和vshopId关系
	 * @return
	 */
	@Override
	public CommonResultEntity<List<VshopVipMshopIdSimpleInfo>> queryAllVipMshopIdInfoList() {
		List<VshopVipMshopIdSimpleInfo> list=vshopVipInfoBiz.queryAllVipMshopIdInfoList();
		log.info("query vip all mid and userId ：{}",list);

		CommonResultEntity<List<VshopVipMshopIdSimpleInfo>> result = new CommonResultEntity<List<VshopVipMshopIdSimpleInfo>>();
		result.setBusinessObj(list);
		return result;
	}
}
