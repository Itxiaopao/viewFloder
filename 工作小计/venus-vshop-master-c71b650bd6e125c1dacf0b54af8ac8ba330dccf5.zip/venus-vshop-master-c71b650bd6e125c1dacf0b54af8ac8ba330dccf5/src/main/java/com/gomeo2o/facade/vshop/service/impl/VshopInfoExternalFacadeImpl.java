package com.gomeo2o.facade.vshop.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.com.gome.swf.dubbo.SwfService;
import cn.com.gome.swf.model.SwfResultDto;
import cn.com.gome.user.service.QueryUserInfoFacade;
import cn.com.gome.user.v2.model.StaffInfoVo;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.ItemDistributionStatusDto;
import com.gomeo2o.facade.vshop.entity.VshopDistributionItem;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeo2o.facade.vshop.enums.ProductStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopTypeEnum;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;
import com.gomeo2o.service.vshop.biz.VshopDistributionItemBiz;
import com.gomeo2o.service.vshop.biz.VshopInfoBiz;
import com.gomeo2o.service.vshop.biz.VshopInvitationRelationBiz;
import com.gomeo2o.utils.EmojiFilterUtils;
import com.gomeo2o.utils.HttpUtil;
import com.gomeo2o.utils.JsonUtils;
import com.gomeo2o.utils.StringUtil;
import com.gomeo2o.utils.ValidateUtils;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

@Slf4j
@Service("vshopInfoExternalFacade")
public class VshopInfoExternalFacadeImpl implements VshopInfoExternalFacade{
	@Autowired VshopInfoBiz vshopInfoBiz;

	@Autowired
	private VshopFacadeImpl vshopFacadeImpl;

	@Autowired
	private VshopDistributionItemBiz vshopDistributionItemBiz;

	@Autowired
	private VshopInvitationRelationBiz vshopInvitationRelationBiz;

	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;

	@Autowired
	private SwfService swfService;

	@Autowired
	Gcache vshopCache;

	//美店分销商品数量上限
	public static final int VSHOP_DISTRIBUTION_TOTAL_MAX = 5000;//美店分销商品数量上限

	private ThreadPoolExecutor pool = new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors()/2,
			Runtime.getRuntime().availableProcessors(), 0l, TimeUnit.MILLISECONDS,new ArrayBlockingQueue<Runnable>(100),new ThreadPoolExecutor.CallerRunsPolicy());


	@Override
	public CommonResultEntity<VshopInfo> queryVshopInfoByUserId(Long userId) {
		if(null == userId || "".equals(userId)){
			log.info("用户ID为空{}", userId);
			throw VshopException.PARAM_IS_NULL;
		}
		log.info("queryVshopInfoByUserId通过userId查询美店主信息:{}",userId);
		CommonResultEntity<VshopInfo> cre = new CommonResultEntity<VshopInfo>();
		VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);
		cre.setBusinessObj(vshopInfo);
		return cre;
	}

	@Override
	public CommonResultEntity<String> createOrUpdateVshop(VshopInfo vshopInfoEntity) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		ValidateUtils.notNull(vshopInfoEntity, "userId");
        vshopInfoEntity.setVshopType(VshopTypeEnum.MEIDIAN.getValue());
		// 校验用户是否存在微店
		VshopInfo vshopInfoExist = vshopInfoBiz.queryVshopByuserId(vshopInfoEntity.getUserId());
		boolean isExists = (vshopInfoExist!=null);
		vshopInfoEntity.setVshopStatus(VshopStatusEnum.JINGYING.getValue());
		// 店铺logo
		if (StringUtils.isBlank(vshopInfoEntity.getVshopIcon())) {
			vshopInfoEntity.setVshopIcon(getVshopDefaultLogo());
		}
		if (vshopInfoEntity.getVersion() == 0) {// 0：isSkip 不跳过 校验店铺名称
			// 校验店铺名称是否重复
			vshopInfoBiz.queryVshopName(isExists ? vshopInfoExist.getVshopId() : 0, vshopInfoEntity.getVshopName());
		}

		validateDesc(vshopInfoEntity.getVshopDesc());

		if (isExists) {
			//更新美店
			if(StringUtils.isNotBlank(vshopInfoEntity.getVshopName())){
				validateName(vshopInfoEntity.getVshopName(),vshopInfoEntity.getUserId());
			}
			vshopInfoEntity.setVshopId(vshopInfoExist.getVshopId());
			vshopInfoBiz.updateVshop(vshopInfoEntity);
			cre.setBusinessObj(String.valueOf(vshopInfoExist.getVshopId()));
		} else {
			//新增美店
			ValidateUtils.notNull(vshopInfoEntity,"vshopName");
			validateName(vshopInfoEntity.getVshopName(),vshopInfoEntity.getUserId());
			//创建美店来源地址推送MQ使用
			MDC.put("AppId", vshopInfoEntity.getSource());
			long vshopId = vshopInfoBiz.createVshop(vshopInfoEntity);
			cre.setBusinessObj(String.valueOf(vshopId));
			Long inviterVshopId = vshopInfoEntity.getInviterVshopId();
			//创建美店邀请关系
			if(inviterVshopId != null){
				VshopInvitationRelation vshopInvitationRelation = new VshopInvitationRelation();
				vshopInvitationRelation.setReceiverUserId(vshopInfoEntity.getUserId());
				vshopInvitationRelation.setInviterVshopId(inviterVshopId);
				vshopInvitationRelation.setReceiverVshopId(vshopId);
				try {
					vshopInvitationRelationBiz.createVshopInvitationRelation(vshopInvitationRelation);
				} catch (Exception e) {
					log.error("vshopInvitationRelationFacade.createVshopInvitationRelation fail,userId is:{},error message is:{}",
							vshopInvitationRelation.getReceiverUserId(),e.getMessage());
				}
			}
		}
		return cre;
	}

	private void validateName(String name,Long userId) {
		int len = StringUtil.calculateLen(name);
		if (len < 2 || len > 30) {
			throw VshopException.VSHOP_NAME_LENGTH_NONSTANDARD;
		}
		// 获取敏感词
		String sensitiveStr = "官方,旗舰店,专卖店,专营店";
		if (StringUtils.isNotBlank(sensitiveStr)) {
			String[] sensitiveWords = sensitiveStr.split(",");
			boolean flag = false;
			for (int i = 0; i < sensitiveWords.length; i++) {
				flag = name.replaceAll(" ", "").contains(sensitiveWords[i]);
				if (flag) {
					throw VshopException.VSHOP_NAME_WORDS_NONSTANDARD;
				}
			}
		}
		//是否员工美店校验‘国美’敏感字
		CommonResultEntity<StaffInfoVo> res = queryUserInfoFacade.getStaffInfoByUserId(String.valueOf(userId));
		if (res != null && res.getCode() != 0) {
			log.info("getStaffInfoByUserId happened error,userId: {}", userId);
		} else if (res.getBusinessObj() == null) {
			if(name.replaceAll(" ", "").contains("国美")){
				throw VshopException.VSHOP_NAME_WORDS_NONSTANDARD_FOR_NORMAL;
			}
		}

		String onlineswftype = "strictCensorWords";
		String onlineswftoken = "6ec4c77850d14f288e61b48fd63a213d";
		SwfResultDto swfResultDto = swfService.checkWords(name, onlineswftype, "0", onlineswftoken);

		if("Y".equals(swfResultDto.getResult()) && StringUtil.notEmpty(swfResultDto.getSensitiveWords())) {//包含敏感词
			throw VshopException.VSHOP_NAME_WORDS_SENSITIVEWORDS;
		}else if("N".equals(swfResultDto.getResult())) {//调用异常
			log.error("swfService.checkWords error! vshopName:[{}]",name);
		}

	}

	private void validateDesc(String description) {
		// 美店描述
		if (StringUtils.isBlank(description)) {
			return;
		}
		description = EmojiFilterUtils.filterEmoji(description).trim();
		int len = StringUtil.calculateLen(description);
		if (len > 200) {
			throw VshopException.VSHOP_DESCRIPTION_LENGTH_NONSTANDARD;
		}

		String onlineswftype = "strictCensorWords";
		String onlineswftoken = "6ec4c77850d14f288e61b48fd63a213d";
		SwfResultDto swfResultDto = swfService.checkWords(description, onlineswftype, "0", onlineswftoken);

		if("Y".equals(swfResultDto.getResult()) && StringUtil.notEmpty(swfResultDto.getSensitiveWords())) {//包含敏感词
			throw VshopException.VSHOP_DESCRIPTION_WORDS_SENSITIVEWORDS;
		}else if("N".equals(swfResultDto.getResult())) {//调用异常
			log.error("swfService.checkWords error! vshopDesc:[{}]",description);
		}
	}

	@Override
	public CommonResultEntity<Integer> queryProductCountByStatus(int isValid, long vshopId) {
		CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
		// 判断是否为下架标示
		StringBuffer sb = new StringBuffer();
		if (isValid == ProductStatusEnum.XIAJIA.getValue()) {
			// 下架查询冻结与下架的商品（冻结：强制下架）
			sb.append(ProductStatusEnum.XIAJIA.getValue());
			sb.append(",");
			sb.append(ProductStatusEnum.DONGJIE.getValue());
		}else if(isValid == ProductStatusEnum.SHANGJIA.getValue()){
			sb.append(ProductStatusEnum.SHANGJIA.getValue());
		}
		cre.setBusinessObj(vshopDistributionItemBiz.queryProductCountByStatus(sb.toString(), vshopId));
		return cre;
	}

	// 获取默认店铺logo
	public String getVshopDefaultLogo() {
		return "http://gfs10.gomein.net.cn/T1YFxTByJT1R4cSCrK.png";
	}

	@Override
	public CommonResultEntity<List<VshopInfo>> queryVshopInfosByUserIds(List<Long> userIds) {
	    CommonResultEntity<List<VshopInfo>> result = new CommonResultEntity<List<VshopInfo>>();
	    if (userIds == null || userIds.isEmpty()) {
	        return result;
	    }
	    List<VshopInfo> data = new ArrayList<VshopInfo>();
	    for (Long userId : userIds) {
	        VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);
	        data.add(vshopInfo);
	    }
	    result.setBusinessObj(data);
	    return result;
	}
	
	/**
	 * @Description: 通过userId,productId判断是否已经存在商品
	 * @author: guowenbo
	 * @date: 2015年6月13日 下午3:44:30
	 * @param userId
	 * @param productId
	 * @return
	 */
	@Override
	public CommonResultEntity<Boolean> queryProductIsExist(String userId, String productId, String skuId) {
		CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
		// 卖家版查询除删除冻结的所有商品
		StringBuffer sb = new StringBuffer();
		sb.append(ProductStatusEnum.SHANGJIA.getValue());
		String status = sb.toString();
		Boolean flag = vshopDistributionItemBiz.checkProductIsExist(userId, productId, skuId, status);
		cre.setBusinessObj(flag);
		return cre;
	}

	@Override
	public CommonResultEntity<List<ItemDistributionStatusDto>> queryItemsDistributionStatus(
			Long shopId, String itemIds) {
		CommonResultEntity<List<ItemDistributionStatusDto>> cre = new CommonResultEntity<List<ItemDistributionStatusDto>>();
		String[] itemIdList = itemIds.split(",");
		List<ItemDistributionStatusDto> list = new ArrayList<ItemDistributionStatusDto>();
		ItemDistributionStatusDto vo = null;
		// 只查询除上架中的商品
		String status = String.valueOf(ProductStatusEnum.SHANGJIA.getValue());
		for (int i = 0; i < itemIdList.length; i++) {
			String itemId = itemIdList[i];
			Boolean result = vshopDistributionItemBiz.queryProducDistributionStatus(shopId, itemId, null, status);
			vo = new ItemDistributionStatusDto();
			vo.setItemId(itemId);
			vo.setDistribution(result);
			list.add(vo);	
		}
		cre.setBusinessObj(list);
		return cre;
	}
	
	/**
	 * @Description: 通过微店id查询微店信息
	 * @author: guowenbo
	 * @date: 2015年4月15日 下午3:09:27
	 * @param vshopId
	 * @return CommonResultEntity<VshopInfo>
	 */
	@Override
	public CommonResultEntity<VshopInfo> queryVshopById(long vshopId) {
		// 校验店铺
		// vshopInfoBiz.checkVshop(vshopId);
		CommonResultEntity<VshopInfo> cre = new CommonResultEntity<VshopInfo>();
		cre.setBusinessObj(vshopInfoBiz.queryVshopById(vshopId));
		return cre;
	}

	@Override
	public CommonResultEntity<Void> isStarVshop(long vshopId) {
		CommonResultEntity<Void> cre = new CommonResultEntity<Void>();
		int isStar = 1;//是明星美店
		vshopInfoBiz.updataIsStarByShopId(vshopId,isStar);
		return cre;
	}

	@Override
	public CommonResultEntity<Void> isNotStarVshop(long vshopId) {
		CommonResultEntity<Void> cre = new CommonResultEntity<Void>();
		int isStar = 0;//不是明星美店
		vshopInfoBiz.updataIsStarByShopId(vshopId,isStar);
		return cre;
	}

	@Override
	public CommonResultEntity<String> createDistributionItems(List<VshopDistributionItem> list, long shopId) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		int itemCount = list.size();
		// 在redis中获取美店的商品上架数量
		Integer svalue = Integer.valueOf(vshopCache.get("shop:shopitemscount:"+shopId ));
		if (svalue != null) {
			if (svalue >= VSHOP_DISTRIBUTION_TOTAL_MAX || (svalue + itemCount > VSHOP_DISTRIBUTION_TOTAL_MAX)) {
				log.error("DistributionItemsResource--post--onshelfItemsQuantity in vshop greater than " + VSHOP_DISTRIBUTION_TOTAL_MAX
						+ ",shopId id {} ", shopId);
				cre.setCode(500);
				cre.setMessage("超出美店分销商品数量上限5000!");
				return cre;
			}
		}

		//防止线程导致重复类目记录创建，在线程创建之前持久化
		String categoriesResult = HttpUtil.getUrlContent("http://access.ec.api"+"/v3/comm/category?pids=" +list.get(0).getItemId());
		log.info("queryfirstCategory from online ,result:{}", categoriesResult);
		if (categoriesResult == null || !categoriesResult.contains("成功")) {
			log.error("queryfirstCategory from online happens error! itemId is: {},result is :{}", list.get(0).getItemId(), categoriesResult);
		}else{
			StringBuffer category = new StringBuffer();
			List<Map<String, Object>> listMap = JsonUtils.Json2ListMap(net.sf.json.JSONObject.fromObject(categoriesResult).getString("data"));
			if (listMap.size() > 0) {
				for (Map<String, Object> map : listMap) {
					if(map.get("firstCategory") != null && !"".equals(String.valueOf(map.get("firstCategory")))){
						category.append(map.get("firstCategory") + ",");
					}
				}
				vshopFacadeImpl.getVshopCategoryId(shopId, category.toString());
			}
		}

		for (int i = 0; i < list.size(); i++) {
			final VshopDistributionItem paramsData = list.get(i);
			final Long finalShopId = shopId;
			pool.execute(new Runnable() {
				@Override
				public void run() {
					try {
						String result = HttpUtil.getUrlContent("http://access.ec.api/v3/comm/category?pids=" + paramsData.getItemId());
						log.info("queryfirstCategory from online ,result:{}", result);
						if (result == null || !result.contains("成功")) {
							log.error("queryfirstCategory from online happens error! itemId is: {},result is :{}", paramsData.getItemId(), result);
						}else{
							StringBuffer category = new StringBuffer();
							List<Map<String, Object>> listMap = JsonUtils.Json2ListMap(net.sf.json.JSONObject.fromObject(result).getString("data"));
							if (listMap.size() > 0) {
								for (Map<String, Object> map : listMap) {
									if(map.get("firstCategory") != null && !"".equals(String.valueOf(map.get("firstCategory")))){
										category.append(map.get("firstCategory") + ",");
									}
								}
								CommonResultEntity<Map<String, Object>> cre1 = vshopFacadeImpl.getVshopCategoryId(finalShopId, category.toString());
								Map<String, Object> map1 = cre1.getBusinessObj();
								for (Map<String, Object> map : listMap) {
									if (paramsData.getItemId().equals(map.get("productId")) && !"".equals(String.valueOf(map.get("firstCategory")))) {
										paramsData.setVcategoryId(Long.parseLong(map1.get(map.get("firstCategory")).toString()));
										break;
									}
								}
							}
						}

						CommonResultEntity<String> resultEntity = vshopFacadeImpl.createDistributionItem(paramsData);
						if (resultEntity.getCode() != 0) {
							log.error("method：DistributionItemAction--post--vshopFacade.createDistributionItem，"
											+ "happens error：vshopId is：{}，itemId is：{}，error message is：{}",
									finalShopId, paramsData.getItemId(), resultEntity.getMessage());
						}
					} catch (Exception e) {
						log.error("distributionItem fail,message is :{}",e);
					}
				}
			});

		}
		return cre;
	}

	@Override
	public CommonResultEntity<String> deleteDistributionItems(List<VshopDistributionItem> list, long shopId) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		List<String> itemIds = new ArrayList<>();
		for (VshopDistributionItem vshopDistributionItem:list) {
			itemIds.add(vshopDistributionItem.getItemId());
		}
		if(itemIds != null && itemIds.size() > 0){
			// 校验店铺
			vshopInfoBiz.checkVshop(shopId);
			vshopDistributionItemBiz.deleteDistributionItems(itemIds, shopId);
		}
		return cre;
	}
	
	@Override
	public CommonResultEntity<List<VshopInfo>> queryVshopInfoListByShopName(PageParam pageParam, String shopName) {
		
		CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
		List<VshopInfo> list = vshopInfoBiz.queryVshopInfoListByShopName(pageParam,shopName);
    	cre.setBusinessObj(list);
		return cre;
	}

	@Override
	public CommonResultEntity<Boolean> isInviter(Long userId) {
		CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
		Boolean isInviter = false;
		VshopInvitationRelation vshopInvitationRelation = vshopInvitationRelationBiz.getInvitationRelationByReceiverUserId(userId);
		if(vshopInvitationRelation != null){
			isInviter = true;
		}
		cre.setBusinessObj(isInviter);
		return cre;
	}

}
