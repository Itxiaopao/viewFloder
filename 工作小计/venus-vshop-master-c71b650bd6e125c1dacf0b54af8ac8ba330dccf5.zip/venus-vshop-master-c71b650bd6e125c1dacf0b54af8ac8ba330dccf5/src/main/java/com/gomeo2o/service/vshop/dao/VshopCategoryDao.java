package com.gomeo2o.service.vshop.dao;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopCategory;

public interface VshopCategoryDao extends BaseDao<VshopCategory> {

	public VshopCategory queryCategoryByVshopId(long vshopId);
	
	public int update(VshopCategory category);

}
