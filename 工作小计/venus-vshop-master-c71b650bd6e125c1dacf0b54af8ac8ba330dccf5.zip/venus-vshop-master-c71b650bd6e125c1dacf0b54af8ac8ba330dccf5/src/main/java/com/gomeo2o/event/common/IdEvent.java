/**
 * gomeo2o.com Copyright (c) 2015-2025 All Rights Reserved.
 * 
 * @Description id事件接口
 * @author sunyizhong
 * @date 2016年2月22日 下午3:09:37
 */
package com.gomeo2o.event.common;

/**
 * @Description id事件接口
 * @author sunyizhong
 * @date 2016年2月22日 下午3:09:37
 */
public interface IdEvent {

    public Long id();

}
