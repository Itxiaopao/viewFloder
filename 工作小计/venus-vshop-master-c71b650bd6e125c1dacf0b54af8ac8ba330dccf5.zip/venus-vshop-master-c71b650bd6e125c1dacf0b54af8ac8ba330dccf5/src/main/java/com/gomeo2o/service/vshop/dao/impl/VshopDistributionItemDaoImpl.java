package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopDistributionItem;
import com.gomeo2o.facade.vshop.enums.ProductStatusEnum;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopDistributionItemDao;
import com.gomeo2o.service.vshop.dao.base.BaseDaoImpl;

@Repository("name=vshopDistributionItemDao")
public class VshopDistributionItemDaoImpl extends BaseDaoImpl<VshopDistributionItem> implements VshopDistributionItemDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopDistributionItemDaoImpl.";

	@Override
	public int queryProductCountByVshopId(long vshopId, String status) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("status", status);
		paramMap.put("vshopId", vshopId);
		return this.getSessionTemplate().selectOne(baseSQL + "queryProductCountByVshopId", paramMap);
	}

	@Override
	public List<VshopDistributionItem> queryListProductByCategoryId(PageParam pageParam, long vcategoryId, long vshopId, String status) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vcategoryId", vcategoryId);
		paramMap.put("vshopId", vshopId);
		paramMap.put("status", status);
		paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		paramMap.put("pageSize", pageParam.getNumPerPage());
		return this.getSessionTemplate().selectList(baseSQL + "queryListProductByCategoryId", paramMap);
	}

	@Override
	public List<VshopDistributionItem> queryListProductByStatus(PageParam pageParam, String status, long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("status", status);
		paramMap.put("vshopId", vshopId);
		paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		paramMap.put("pageSize", pageParam.getNumPerPage());
		return this.getSessionTemplate().selectList(baseSQL + "queryListProductByStatus", paramMap);
	}

	@Override
	public int queryProductCountByStatus(String status, long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("status", status);
		paramMap.put("vshopId", vshopId);
		return this.getSessionTemplate().selectOne(baseSQL + "queryProductCountByStatus", paramMap);
	}

	@Override
	public int queryItemCountByCategoryId(long vcategoryId, long vshopId, String status) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vcategoryId", vcategoryId);
		paramMap.put("vshopId", vshopId);
		paramMap.put("status", status);
		return this.getSessionTemplate().selectOne(baseSQL + "queryItemCountByCategoryId", paramMap);
	}

	@Override
	public void updateProductCategory(long vcategoryId, long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vcategoryId", vcategoryId);
		paramMap.put("vshopId", vshopId);
		this.getSessionTemplate().update(baseSQL + "updateProductCategory", paramMap);
	}

	/*
	 * 不再使用
	 * 
	public void updateProductForDeleteCategory(Long categoryId, long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vshopId", vshopId);
		paramMap.put("vcategoryId", categoryId);
		getSessionTemplate().update(baseSQL + "updateProductForDeleteCategory", paramMap);
	}*/

	@Override
	public List<VshopDistributionItem> queryListProductByVshopId(PageParam pageParam, long vshopId, String status) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vshopId", vshopId);
		paramMap.put("status", status);
		paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		paramMap.put("pageSize", pageParam.getNumPerPage());
		return this.getSessionTemplate().selectList(baseSQL + "queryListProductByVshopId", paramMap);
	}

	//商城推送（商品下架||pop店铺关闭） MQ,下架相关美店的商品操作
	//@Override
	//public void updateDistributionItemByMQ(Map<String, Object> map) {
	//	this.getSessionTemplate().update(baseSQL + "updateDistributionItemByMQ", map);
	//}

	@Override
	public VshopDistributionItem queryProductByProductId(String itemId, String skuId, long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("itemId", itemId);
		paramMap.put("skuId", skuId);
		paramMap.put("vshopId", vshopId);
		return this.getSessionTemplate().selectOne(baseSQL + "queryProductByProductId", paramMap);
	}

	@Override
	public void checkProduct(long vshopId, String itemId, String skuId, int flag) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("itemId", itemId);
		paramMap.put("vshopId", vshopId);
		paramMap.put("skuId", skuId);
		StringBuffer sb = new StringBuffer();
		sb.append(ProductStatusEnum.SHANGJIA.getValue());
		if (flag == 2) {
			// 申请分销时，只判断有无上架状态冲突
			sb.append(",");
			sb.append(ProductStatusEnum.XIAJIA.getValue());
		}
		String status = sb.toString();
		paramMap.put("status", status);
		int count = this.getSessionTemplate().selectOne(baseSQL + "checkProduct", paramMap);
		// flag是2则为编辑删除判断是否有该商品，flag是1则为新增判断是否有该商品
		if (flag == 2) {
			if (count <= 0) {
				throw VshopException.PRODUCT_EXIST;
			}
		} else if (flag == 1) {
			if (count >= 1) {
				throw VshopException.PRODUCT_IS_EXIST;
			}
		}
	}

	@Override
	public Boolean checkProductIsExist(long vshopId, String itemId, String skuId, String status) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("itemId", itemId);
		paramMap.put("skuId", skuId);
		paramMap.put("vshopId", vshopId);
		paramMap.put("status", status);
		int count = this.getSessionTemplate().selectOne(baseSQL + "checkProduct", paramMap);
		if (count >= 1) {
			return true;
		}
		return false;
	}

	@Override
	public void updateProductaddByDongJie(VshopDistributionItem vshopProductadd) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vshopId", vshopProductadd.getVshopId());
		paramMap.put("status", vshopProductadd.getStatus());
		this.getSessionTemplate().update(baseSQL + "updateProductaddByDongJie", paramMap);
	}

	//未使用
	@Deprecated
	@Override
	public Integer queryProductShareCount(String itemId) {
		return this.getSessionTemplate().selectOne(baseSQL + "queryProductShareCount", itemId);
	}

	//商城推送（商品下架）MQ,通过itemId查询所有分销的美店店铺进行上架数redis-1
	//@Override
	//public List<VshopDistributionItem> queryListProductByProductId(String productId) {
	//	return this.getSessionTemplate().selectList(baseSQL + "queryListProductByProductId", productId);
	//}

	@Override
	public int update(VshopDistributionItem vshopProductadd) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vshopId", vshopProductadd.getVshopId());
		paramMap.put("status", vshopProductadd.getStatus());
		paramMap.put("vcategoryId", vshopProductadd.getVcategoryId());
		paramMap.put("story", vshopProductadd.getStory());
		paramMap.put("itemId", vshopProductadd.getItemId());
		return this.getSessionTemplate().update(baseSQL + "update", paramMap);
	}

	@Override
	public Integer queryDistributionItemCountCount(long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vshopId", vshopId);
		return this.getSessionTemplate().selectOne(baseSQL + "queryDistributionItemCountCount", paramMap);
	}

	// 610编号api暂时性数据填充
	@Override
	public List<VshopDistributionItem> queryListProductByCriteria(PageParam pageParam, Map<String, Object> criteria) {
		criteria.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		criteria.put("pageSize", pageParam.getNumPerPage());
		return this.getSessionTemplate().selectList(baseSQL + "queryListProductByCriteria", criteria);
	}

	@Override
	public Integer queryItemQuantityByCriteria(Map<String, Object> criteria) {
		return this.getSessionTemplate().selectOne(baseSQL + "queryItemQuantityByCriteria", criteria);
	}

	@Override
	public void deleteDistributionItems(List<String> itemIds, long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("itemIds", itemIds);
		paramMap.put("vshopId", vshopId);
		getSessionTemplate().delete(baseSQL + "deleteDistributionItems", paramMap);
	}

	@Override
	public void updateDistributionItems(List<String> itemIds, long vshopId, long vcategoryId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("itemIds", itemIds);
		paramMap.put("vshopId", vshopId);
		paramMap.put("vcategoryId", vcategoryId);
		getSessionTemplate().update(baseSQL + "updateDistributionItems", paramMap);
	}

	@Override
	public int deleteDistributionItem(Map<String, Object> map) {
		return getSessionTemplate().delete(baseSQL + "deleteDistributionItem", map);
	}

	//推送美店商品给搜索（遍历全部）
	@Override
	public List<VshopDistributionItem> queryItemsInMShop(PageParam pageParam) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		paramMap.put("pageSize", pageParam.getNumPerPage());
		return this.getSessionTemplate().selectList(baseSQL + "queryItemsInMShop", paramMap);
	}

	/*
	 * 未使用
	 * 
	@Override
	public void deleteDistributionItemByVshopId(Map<String, Object> map) {
		getSessionTemplate().delete(baseSQL + "deleteDistributionItemByVshopId", map);

	}*/

	//pop店铺关闭，查询所有分销此店铺下商品的相关记录，进行美店下商品数量redis-1
	//@Override
	//public List<VshopDistributionItem> queryListProductByPopId(String popId) {
	//	Map<String, Object> paramMap = new HashMap<String, Object>();
	//	paramMap.put("pshopId", popId);
	//	return this.getSessionTemplate().selectList(baseSQL + "queryListProductByPopId", paramMap);
	//}

	@Override
	public void updateProductIdentificationByVshopId(Long vshopId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("vshopId", vshopId);
		getSessionTemplate().update(baseSQL + "updateProductIdentificationByVshopId", paramMap);
	}

	@Override
	public List<VshopDistributionItem> queryListProductByMQ(
			Map<String, Object> map) {
		return this.getSessionTemplate().selectList(baseSQL + "queryListProductByMQ", map);
	}

	@Override
	public void updateProductByMQ(Map<String, Object> map) {
		this.getSessionTemplate().update(baseSQL + "updateProductByMQ", map);
	}

	@Override
	public List<VshopDistributionItem> queryListProducts(Map<String, Object> idsMap) {
		return this.getSessionTemplate().selectList(baseSQL + "queryListProducts", idsMap);
	}

}
