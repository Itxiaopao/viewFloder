package com.gomeo2o.service.vshop.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopOnItemCount;
import com.gomeo2o.service.vshop.dao.VshopOnItemCountDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopOnItemCountDao")
public class VshopOnItemCountDaoImpl extends CBaseDaoImpl<VshopOnItemCount>
		implements VshopOnItemCountDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopOnItemCountDaoImpl.";

	@Override
	public List<VshopOnItemCount> queryOnItemCount() {
		return this.getSessionTemplate().selectList(
				baseSQL + "queryOnItemCount");
	}

	@Override
	public List<VshopOnItemCount> queryAllShopList() {
		return this.getSessionTemplate().selectList(
				baseSQL + "queryAllShopList");
	}

}
