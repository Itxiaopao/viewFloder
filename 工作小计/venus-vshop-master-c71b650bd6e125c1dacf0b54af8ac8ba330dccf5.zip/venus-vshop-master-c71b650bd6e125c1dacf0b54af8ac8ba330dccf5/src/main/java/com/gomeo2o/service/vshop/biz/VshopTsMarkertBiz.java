/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年5月25日 下午2:52:34
 */
package com.gomeo2o.service.vshop.biz;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.facade.vshop.entity.VshopTsMarkert;
import com.gomeo2o.service.vshop.dao.VshopTsMarkertDao;

/**
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年5月25日 下午2:52:34
 */
@Service("name=vshopTsMarkertBiz")
public class VshopTsMarkertBiz {

	@Autowired
	private VshopTsMarkertDao vshopTsMarkertDao;
	
	public List<VshopTsMarkert> queryTsMarkert(Integer groupId) {
		if(groupId!=null){
			return vshopTsMarkertDao.queryTsMarkert(groupId);
		}
		Random ra =new Random();
		groupId = ra.nextInt(2);
		return vshopTsMarkertDao.queryTsMarkert(groupId);
	}

	
}
