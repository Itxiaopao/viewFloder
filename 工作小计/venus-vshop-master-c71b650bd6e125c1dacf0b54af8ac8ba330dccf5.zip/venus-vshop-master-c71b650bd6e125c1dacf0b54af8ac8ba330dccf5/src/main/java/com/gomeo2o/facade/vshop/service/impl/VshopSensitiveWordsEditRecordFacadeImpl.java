package com.gomeo2o.facade.vshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopSensitiveWordsEditRecord;
import com.gomeo2o.facade.vshop.service.VshopSensitiveWordsEditRecordFacade;
import com.gomeo2o.service.vshop.biz.VshopSensitiveWordsEditRecordBiz;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopSensitiveWordsEditRecordFacade")
public class VshopSensitiveWordsEditRecordFacadeImpl implements VshopSensitiveWordsEditRecordFacade {
	
	@Autowired
	private VshopSensitiveWordsEditRecordBiz sensitiveWordsEditRecordBiz;

	@Override
	public CommonResultEntity<Void> saveSensitiveWordsEditRecord(
			VshopSensitiveWordsEditRecord sensitiveWordsEditRecord) {
		CommonResultEntity<Void> cre = new CommonResultEntity<Void>();
		sensitiveWordsEditRecordBiz.saveSensitiveWordsEditRecord(sensitiveWordsEditRecord);
		return cre;
	}

	@Override
	public CommonResultEntity<VshopSensitiveWordsEditRecord> getSensitiveWordsEditRecordByVshopId(
			Long vshopId) {
		CommonResultEntity<VshopSensitiveWordsEditRecord> cre = new CommonResultEntity<VshopSensitiveWordsEditRecord>();
		VshopSensitiveWordsEditRecord sensitiveWordsEditRecord = sensitiveWordsEditRecordBiz.getSensitiveWordsEditRecordByVshopId(vshopId);
		cre.setBusinessObj(sensitiveWordsEditRecord);
		return cre;
	}
	
	

}
