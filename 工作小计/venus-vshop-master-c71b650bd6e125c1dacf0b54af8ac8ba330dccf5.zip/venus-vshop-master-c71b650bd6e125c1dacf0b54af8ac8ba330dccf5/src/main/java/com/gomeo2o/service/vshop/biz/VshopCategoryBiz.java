/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: Administrator
 * @date: 2015年4月9日 上午9:57:27
 */
package com.gomeo2o.service.vshop.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gomeo2o.facade.vshop.dto.VshopCategoryDto;
import com.gomeo2o.facade.vshop.entity.VshopCategory;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopCategoryDao;
import com.gomeo2o.service.vshop.dao.VshopDistributionItemDao;
import com.gomeo2o.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("name=vshopCategoryBiz")
public class VshopCategoryBiz {

	@Autowired
	private VshopCategoryDao vshopCategoryDao;

	@Autowired
	private VshopDistributionItemDao vshopProductaddDao;
	
	public VshopCategoryBiz() {
	}

	
	public VshopCategory queryCategoryByVshopId(long vshopId) {
		return vshopCategoryDao.queryCategoryByVshopId(vshopId);
	}
	
	public long createVshopCategory(VshopCategory vshopCategory) {
		long vcategoryId = vshopCategoryDao.insert(vshopCategory);
		return vcategoryId;
	}

	public void updateVshopCategory(VshopCategory vshopCategory) {
		vshopCategoryDao.update(vshopCategory);
	}

	@Transactional
	public void deleteVshopCategory(VshopCategory category,List<Long> modifyCategories,long vcategoryId) {
		vshopCategoryDao.update(category);
		// 删除分类后商品移动到未分类
		vshopProductaddDao.updateProductCategory(vcategoryId, category.getVshopId());
		// 重新迭代分类后排版顺序
		//for (Long categoryId : modifyCategories) {
		//	vshopProductaddDao.updateProductForDeleteCategory(categoryId,category.getVshopId());
		//}
	}

	public VshopCategoryDto queryCategoryByCategoryId(long vshopId,long categoryId) {
		VshopCategoryDto dto =  new VshopCategoryDto();
		VshopCategory vshopCategory = vshopCategoryDao.queryCategoryByVshopId(vshopId);
		if(categoryId==0){
			dto.setCategoryId(0);
			dto.setCategoryName("默认分类");
			return dto;
		}
		List<VshopCategoryDto> list = JsonUtils.toList(vshopCategory.getVcategories(), new VshopCategoryDto());
		for (VshopCategoryDto vshopCategoryDto : list) {
			if(categoryId == vshopCategoryDto.getCategoryId()){
				dto.setCategoryId(vshopCategoryDto.getCategoryId());
				dto.setCategoryName(vshopCategoryDto.getCategoryName());
				break;
			}
		}
		return dto;
	}

		
		/**
		 * @Description: 校验分类存在与否
	     * @author: guowenbo
	     * @date: 2015年6月4日 下午1:01:36
	     * @param vshopId
	     * @param vcategoryId
		 */
	public void checkCategory(long vshopId, long vcategoryId) {
		VshopCategory vshopCategory = vshopCategoryDao.queryCategoryByVshopId(vshopId);
		if(vcategoryId==0){
			return;
		}else if(vshopCategory==null){
			throw VshopException.CATEGORY_EXIST;
		}
		List<VshopCategoryDto> list = JsonUtils.toList(vshopCategory.getVcategories(), new VshopCategoryDto());
		String a = "";
		for (VshopCategoryDto vshopCategoryDto : list) {
			a = a + vshopCategoryDto.getCategoryId()+",";
		}
		int flag = a.indexOf(vcategoryId+",");
		log.debug("方法：checkCategory，遍历出来的分类信息是：{},比较是否包含的结果是：{}",a,flag);
		if(flag==-1){
			throw VshopException.CATEGORY_EXIST;
		}
		
	}

}
