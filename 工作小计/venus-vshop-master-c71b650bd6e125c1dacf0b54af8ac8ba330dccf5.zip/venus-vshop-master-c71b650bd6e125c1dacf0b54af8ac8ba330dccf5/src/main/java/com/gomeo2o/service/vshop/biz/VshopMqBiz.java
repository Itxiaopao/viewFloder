package com.gomeo2o.service.vshop.biz;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.mq.MQPushIcdataProducer;
import com.gomeo2o.mq.MQPushProducer;
import com.gomeplus.venus.common.imageutil.IllegalExpressionException;
import com.gomeplus.venus.common.imageutil.UrlConverter;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Description: 解析美店推送的mq消息 
 * @author: lixilong
 * @date: 2017年10月31日 下午3:49:54
 */
@Slf4j
@Service("name=vshopMqBiz")
public class VshopMqBiz {

    @Autowired
    private UrlConverter urlConverter;
    
    /**
     * rocketMQ
     */
    @Autowired
    private MQPushProducer mqPushProducer;

    @Autowired
    private MQPushIcdataProducer mqPushIcdataProducer;

    /**
     * 
	 * @Description: 开通/更新美店 推送rocketMq(vshopInfo)
     * @author: lixilong
     * @date: 2017年10月31日 下午3:52:40
     * @param vshopInfo
     * @return
     */
    public void pushVshopInfoRocketMq(VshopInfo vshopInfo,String action) {
        JSONObject jo = new JSONObject();
        jo.put("id", vshopInfo.getVshopId());
        jo.put("name", vshopInfo.getVshopName());
        jo.put("status", vshopInfo.getVshopStatus());
        jo.put("description", vshopInfo.getVshopDesc());
        jo.put("userId", vshopInfo.getUserId());
        try {
            jo.put("icon", urlConverter.getHashedFullLocation(vshopInfo.getVshopIcon()));
        } catch (IllegalExpressionException e) {
            log.error("pushVshopInfoRocketMq icon happend error,message :" , e);
        }
        jo.put("sendTime", new Date().getTime());
        mqPushProducer.send(jo.toJSONString(), "TagPlusShop",null);
        jo.put("action",action);
        mqPushIcdataProducer.send(jo.toJSONString());
    }
    
    /**
     * 
	 * @Description: 开通/更新美店 推送rabbitMq 
     * @author: lixilong
     * @date: 2017年10月31日 下午4:06:27
     * @param vshopInfo
     */
   /* public void pushVshopInfoRabbitMq(VshopInfo vshopInfo, SubmitAction action) {
        JSONObject vshopInfoObj = new JSONObject();
        Long vshopId = vshopInfo.getVshopId();
        vshopInfoObj.put("id", vshopId);
        vshopInfoObj.put("name", vshopInfo.getVshopName());
        try {
            vshopInfoObj.put("icon", urlConverter.getHashedFullLocation(vshopInfo.getVshopIcon()));
        } catch (IllegalExpressionException e) {
            log.error("pushVshopInfoRabbitMq parse icon happend error,message :" , e);
        }
        vshopInfoObj.put("vshopX", vshopInfo.getVshopX());
        vshopInfoObj.put("vshopY", vshopInfo.getVshopY());
        vshopInfoObj.put("vshopArea", vshopInfo.getVshopArea());
        vshopInfoObj.put("provinceId", vshopInfo.getProvinceId());
        vshopInfoObj.put("cityId", vshopInfo.getCityId());
        vshopInfoObj.put("countyId", vshopInfo.getCountyId());
        vshopInfoObj.put("status", vshopInfo.getVshopStatus());
        
        try {
            sendMqProducer.sendVo2Mq(String.valueOf(vshopId), "vshop.vshopInfo", action, vshopInfoObj);
            log.info("pushVshopInfoRabbitMq message is [{}] , action is [{}]", vshopInfoObj, action);
        } catch (Exception e) {
            log.error("pushVshopInfoRabbitMq happend exception, vshopId is [{}]", vshopId, e);
        }
    }
    */
}
