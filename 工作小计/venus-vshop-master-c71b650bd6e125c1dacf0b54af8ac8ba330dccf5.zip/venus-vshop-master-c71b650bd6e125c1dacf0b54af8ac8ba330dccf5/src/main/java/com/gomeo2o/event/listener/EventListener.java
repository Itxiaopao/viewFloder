package com.gomeo2o.event.listener;

public interface EventListener {
}
