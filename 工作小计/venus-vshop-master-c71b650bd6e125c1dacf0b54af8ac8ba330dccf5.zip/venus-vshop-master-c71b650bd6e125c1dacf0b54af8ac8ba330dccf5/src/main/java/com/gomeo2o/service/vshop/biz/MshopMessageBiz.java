package com.gomeo2o.service.vshop.biz;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.MshopPushMessage;
import com.gomeo2o.service.vshop.dao.MshopMessageDao;

@Service("name=mshopMessageBiz")
public class MshopMessageBiz {
	@Autowired
	private MshopMessageDao mshopMessageDao;

	public Long createMshopPushMessage(MshopPushMessage mshopPushMessage) {
		long res = mshopMessageDao.insert(mshopPushMessage);
		return res;
	}

	public List<MshopPushMessage> queryMshopPushMessage(PageParam pageParam, Map<String, Object> map) {
		map.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		map.put("pageSize", pageParam.getNumPerPage());
		return mshopMessageDao.queryMshopPushMessage(map);
	}

	public Integer updateMshopPushMessage(MshopPushMessage mshopPushMessage) {
		int res = mshopMessageDao.update(mshopPushMessage);
		return res;
	}

	public MshopPushMessage queryMshopPushMessageById(Long id) {

		return mshopMessageDao.queryMshopPushMessageById(id);
	}

	public Integer queryMshopPushMessageCount(Map<String, Object> map) {

		return mshopMessageDao.queryMshopPushMessageCount(map);
	}

	public Integer deleteMshopPushMessageById(Long id) {

		return mshopMessageDao.deleteById(id);
	}

	public MshopPushMessage queryRegisterMshopPushMessage() {

		return mshopMessageDao.queryRegisterMshopPushMessage();
	}

}
