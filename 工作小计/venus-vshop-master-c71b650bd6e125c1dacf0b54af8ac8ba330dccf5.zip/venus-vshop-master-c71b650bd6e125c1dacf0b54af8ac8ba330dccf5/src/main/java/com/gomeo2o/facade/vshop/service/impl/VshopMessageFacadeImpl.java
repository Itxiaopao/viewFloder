package com.gomeo2o.facade.vshop.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.MshopPushMessage;
import com.gomeo2o.facade.vshop.service.VshopMessageFacade;
import com.gomeo2o.service.vshop.biz.MshopMessageBiz;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

@Slf4j
@Service("vshopMessageFacade")
public class VshopMessageFacadeImpl implements VshopMessageFacade {
	
	private static final String REGISTRY_PUSH_MSG = "vshop:registry-push-msg";
	
	@Autowired
	private MshopMessageBiz mshopMessageBiz;

	@Autowired Gcache vshopCache;

	private enum MsgTypeEnum{
        //消息类型：1：美店定时群发消息；2：美店注册单发消息
	    SCHEDULED_MSG(1),REGISTRY_MSG(2);
	    private int type;
        MsgTypeEnum(int type){
	        this.type = type;
        }

        public int getType() {
            return type;
        }
    }

	@Override
	public CommonResultEntity<List<MshopPushMessage>> queryMshopPushMessage(PageParam pageParam, Map<String, Object> map) {
		CommonResultEntity<List<MshopPushMessage>> cre = new CommonResultEntity<List<MshopPushMessage>>();
		List<MshopPushMessage> list = mshopMessageBiz.queryMshopPushMessage(pageParam, map);
		cre.setBusinessObj(list);
		return cre;
	}

	@Override
	public CommonResultEntity<String> createMshopPushMessage(MshopPushMessage mshopPushMessage) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		Long res = mshopMessageBiz.createMshopPushMessage(mshopPushMessage);
		cre.setBusinessObj(String.valueOf(res));
		return cre;
	}

	@Override
	public CommonResultEntity<String> updateMshopPushMessage(MshopPushMessage mshopPushMessage) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		Integer res = mshopMessageBiz.updateMshopPushMessage(mshopPushMessage);

		//修改美店注册单发消息更新redis
        if(mshopPushMessage != null && res > 0){
            MshopPushMessage newMsg = mshopMessageBiz.queryRegisterMshopPushMessage();
            if(newMsg.getType() == MsgTypeEnum.REGISTRY_MSG.getType()){
				vshopCache.set(REGISTRY_PUSH_MSG,JSONObject.toJSONString(newMsg));
            }
        }

		cre.setBusinessObj(String.valueOf(res));
		return cre;
	}

	@Override
	public CommonResultEntity<MshopPushMessage> queryMshopPushMessageById(Long id) {
		CommonResultEntity<MshopPushMessage> cre = new CommonResultEntity<MshopPushMessage>();
		cre.setBusinessObj(mshopMessageBiz.queryMshopPushMessageById(id));
		return cre;
	}

	@Override
	public CommonResultEntity<Integer> queryMshopPushMessageCount(Map<String, Object> map) {
		// TODO Auto-generated method stub
		CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
		cre.setBusinessObj(mshopMessageBiz.queryMshopPushMessageCount(map));
		return cre;
	}

	@Override
	public CommonResultEntity<String> deleteMshopPushMessage(Long id) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		cre.setBusinessObj(String.valueOf(mshopMessageBiz.deleteMshopPushMessageById(id)));
		return cre;
	}

	@Override
	public MshopPushMessage queryRegisterMshopPushMessage() {


	    //优先从redis获取
		String str = vshopCache.get(REGISTRY_PUSH_MSG);

        if(StringUtils.isNotEmpty(str) && !"null".equals(str)){
            return JSONObject.parseObject(String.valueOf(str),MshopPushMessage.class);
        }

        MshopPushMessage mshopPushMessage = mshopMessageBiz.queryRegisterMshopPushMessage();

        //存入redis
        if(mshopPushMessage != null){
			vshopCache.set(REGISTRY_PUSH_MSG,JSONObject.toJSONString(mshopPushMessage));
        }

        return mshopPushMessage;
	}

	@Override
	public void deleteRegisterMshopPushMessage() {

        MshopPushMessage mshopPushMessage = this.queryRegisterMshopPushMessage();

        if(mshopPushMessage == null)
            return;

        //删除redis中的数据
		vshopCache.del(REGISTRY_PUSH_MSG);

        //删除DB的数据
        this.deleteMshopPushMessage(mshopPushMessage.getId());
    }

}
