package com.gomeo2o.service.vshop.dao.impl;

import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopInfoLabel;
import com.gomeo2o.service.vshop.dao.VshopInfoLabelDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopInfoLabelDao")
public class VshopInfoLabelDaoImpl extends CBaseDaoImpl<VshopInfoLabel> implements VshopInfoLabelDao {
    private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopInfoLabelDaoImpl.";

    @Override
    public VshopInfoLabel queryVshopInfoLabelByUserId(Map<String, Object> map) {
        return this.getSessionTemplate().selectOne(baseSQL + "queryVshopInfoLabelByUserId", map);
    }

    @Override
    public int insertVshopInfoLabel(VshopInfoLabel vshopInfoLabel) {
        return this.getSessionTemplate().insert(baseSQL + "insertVshopInfoLabel", vshopInfoLabel);
    }

    @Override
    public int updateVshopInfoLabel(VshopInfoLabel vshopInfoLabel) {
        return this.getSessionTemplate().update(baseSQL + "updateVshopInfoLabel", vshopInfoLabel);
    }
}
