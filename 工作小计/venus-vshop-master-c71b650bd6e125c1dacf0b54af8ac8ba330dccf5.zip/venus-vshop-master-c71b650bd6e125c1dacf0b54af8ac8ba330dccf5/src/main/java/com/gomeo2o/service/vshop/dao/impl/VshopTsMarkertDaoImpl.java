/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年5月25日 下午3:11:58
 */
package com.gomeo2o.service.vshop.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopTsMarkert;
import com.gomeo2o.service.vshop.dao.VshopTsMarkertDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

/**
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年5月25日 下午3:11:58
 */
@Repository("name=vshopTsMarkertDao")
public class VshopTsMarkertDaoImpl extends CBaseDaoImpl<VshopTsMarkert> implements VshopTsMarkertDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopTsMarkertDaoImpl.";
	
	@Override
	public List<VshopTsMarkert> queryTsMarkert(long groupId) {
		return this.getSessionTemplate().selectList(baseSQL + "queryTsMarkert", groupId);
	}


}
