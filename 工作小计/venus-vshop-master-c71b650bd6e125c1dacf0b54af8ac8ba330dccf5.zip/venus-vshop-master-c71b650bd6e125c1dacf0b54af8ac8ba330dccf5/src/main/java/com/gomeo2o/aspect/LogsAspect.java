package com.gomeo2o.aspect;

import java.io.IOException;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.rpc.RpcContext;
import com.alibaba.fastjson.JSON;
import com.gomeo2o.common.constant.BaseConstants;
import com.gomeo2o.common.entity.CommonResultEntity;
import lombok.extern.slf4j.Slf4j;

/**
 * @author limenghui
 * @create 2020-07-29 16:32
 */
@Slf4j
@Aspect
@Component
public class LogsAspect {

    @Pointcut("execution(* com.gomeo2o.facade.vshop.service.impl.*.*(..))")
    public void businessService() {
    }

    public void doAfter(JoinPoint jp) throws IOException {
    }

    @Around("businessService()")
    public Object doAround(ProceedingJoinPoint pjp) throws Throwable {

        // 设置会话id，用于log输出
        String logSessionId = RpcContext.getContext().getAttachment(BaseConstants.LOG_SESSION_ID);
        /*
         *  如果logSessionId为空则不进行赋值
         *  防止业务逻辑自己调用其他方法再次经过切面时，将空值赋给MDC，导致之后日志无logSessionId
         */
        if (logSessionId != null && logSessionId.trim().length() > 0) {
            MDC.put(BaseConstants.LOG_SESSION_ID, logSessionId);
        }

        String clazzName = pjp.getTarget().getClass().getName();
        String methodName = pjp.getSignature().getName();
        String params = JSON.toJSONString(pjp.getArgs());
        long startTime = System.currentTimeMillis();
        //方法返回对象
        Object rvt = null;
        try {
            rvt = pjp.proceed();
        } catch (Exception e1) {
            log.error("方法运行异常, methodName: {}.{}, params {} ", clazzName, methodName, params, e1);
            return new CommonResultEntity<String>(999999, "服务异常", null);
        }finally{
            log.info("log Ending method: {}.{} ,params {},结果是 {} ,runTime {} ms",
                    clazzName, methodName, params,JSON.toJSONString(rvt),System.currentTimeMillis() - startTime);
            // 删除会话id
            MDC.remove(BaseConstants.LOG_SESSION_ID);
        }
        return rvt;
    }

    public void doBefore(JoinPoint jp) throws IOException {

    }

    public void doThrowing(JoinPoint jp, Throwable ex) {

    }

}
