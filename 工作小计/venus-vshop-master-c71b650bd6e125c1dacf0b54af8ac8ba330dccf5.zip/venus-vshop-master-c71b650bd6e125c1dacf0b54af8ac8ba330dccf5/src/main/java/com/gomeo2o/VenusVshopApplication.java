package com.gomeo2o;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
//io.terminus.ecp.shop.dao.mysql
//"io.terminus.ecp.config.center"
// "io.terminus.ecp.config.center"

@SpringBootApplication
@ComponentScan(basePackages = {"com.gomeo2o.*"})
@ImportResource({ "classpath:dubbo/*.xml"})
public class VenusVshopApplication {

	public static void main(String[] args) {

		SpringApplication.run(VenusVshopApplication.class, args);
		System.out.println("...............................................................");
		System.out.println("..................Service starts successfully..................");
		System.out.println("...............................................................");
	}

}
