package com.gomeo2o.service.vshop.dao;
import java.util.List;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.ChannelMshopReqDto;
import com.gomeo2o.facade.vshop.entity.VshopChannelInfo;

public interface VshopChannelInfoDao extends BaseDao<VshopChannelInfo>{

	public List<VshopChannelInfo> getVshopChannelInfoList(PageParam pageParam,ChannelMshopReqDto channelMshopReqDto);

	public Integer getChannelMshopCount(ChannelMshopReqDto channelMshopReqDto);

	public VshopChannelInfo queryVshopChannel(VshopChannelInfo vshopChannelInfo);

	
	/**
	 * 
	 * @Description: 根据渠道美店id查询渠道美店信息 
     * @author: lixilong
     * @date: 2018年6月7日 上午11:31:58
     * @param channelId
     * @return
	 */
	public VshopChannelInfo selectVshopChannelInfoById(Long channelId,String storeCode);

	/**
     * 
     * @Description: 根据渠道美店编码storeCode查询渠道美店信息 
     * @author: lixilong
     * @date: 2018年6月7日 上午11:31:58
     * @param storeCode
     * @return
     */
    public VshopChannelInfo selectVshopChannelInfoByStoreCode(String storeCode);

    /**
     * 
	 * @Description: 根据经纬度查询附近的渠道美店信息集合 
     * @author: lixilong
     * @date: 2018年6月7日 下午2:13:34
     * @param lng 纬度
     * @param lat 经度
     * @param number 获取的渠道美店数量
     * @return
     */
    public List<VshopChannelInfo> selectChannelInfoByPosition(String lng, String lat,int number);

}