/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年5月25日 下午3:09:10
 */
package com.gomeo2o.service.vshop.dao;

import java.util.List;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopTsMarkert;

/**
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年5月25日 下午3:09:10
 */
public interface VshopTsMarkertDao extends BaseDao<VshopTsMarkert>{

	public List<VshopTsMarkert> queryTsMarkert(long groupId);

}
