package com.gomeo2o.mq;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.gome.diamond.annotations.DiamondValue;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Description vip开通推送返利消息
 * @author guowenbo
 * @date 2017年1月12日 下午3:47:54
 */
@Slf4j
@Component
public class MQPushRebateProducer {

	@DiamondValue("${mq.address}")
	private String namesrvAddr;
	@DiamondValue("${mq.vip.vshop_vip_rebate_topic}")
	private String topic;
	@DiamondValue("${mq.vip.vshop_vip_rebate_group}")
	private String group;
	
	private DefaultMQProducer producer = null;

	private String tag = "tagVshopVipRebate";

	@PostConstruct
	public void init(){
		/**
		 * 一个应用创建一个Producer，由应用来维护此对象，可以设置为全局对象或者单例<br>
		 * 注意：ProducerGroupName需要由应用来保证唯一<br>
		 * ProducerGroup这个概念发送普通的消息时，作用不大，但是发送分布式事务消息时，比较关键，
		 * 因为服务器会回查这个Group下的任意一个Producer
		 */
		log.info("MQPushRebateProducer start ! topic: {},  namesrvAddr: {}, group: {}" ,
				topic, namesrvAddr, group);
		
		producer = new DefaultMQProducer(group);
		producer.setNamesrvAddr(namesrvAddr);
		try {
			producer.start();
		} catch (MQClientException e) {
			log.error("vshop-MQPushRebateProducer start fail ! ", e);
		}
		log.debug("vshop-MQPushRebateProducer start success!");
	}

	/**
	 * 应用退出时，要调用shutdown来清理资源，关闭网络连接，从MetaQ服务器上注销自己
	 * 注意：我们建议应用在JBOSS、Tomcat等容器的退出钩子里调用shutdown方法  
	 */
	@PreDestroy
	public void shutdown(){
		producer.shutdown();
	}

	/**
	 *
	 * @param message:
	 *                  {
	 *					"userId":"123", //当前支付用户id
	 *					"inviterUserId":"456", //邀请人用户id
	 *					"inviteTime":"12346549876145", //邀请时间
	 *					"orderNo":"12334456566", //支付订单号
	 *					"tutorUserId":"790" //导师userid
	 *					}
	 * @return
	 */
	public SendResult send(String message){
		try {
			log.info("MQPushRebateProducer:send mq message parameter message: {},topic: {},  tag: {}, namesrvAddr: {}, groupName: {}", message, topic, tag, namesrvAddr, group);
			Message msg;
			msg = new Message(topic, tag, message.getBytes("utf-8"));  //增加字符编码校验
			SendResult sendResult;
			sendResult = producer.send(msg);
			log.info("MQPushRebateProducer send mq message success! msgId:{},message:{}",sendResult.getMsgId(),message);
			return sendResult;
		} catch (Exception e) {
			log.error("MQPushRebateProducer:send msg error: ", e);
			return null;
		}
	}

	/**
	 * @Description 封装MQ消息
	 * @param userId 用户id
	 * @param inviterUserId 邀请人id
	 * @param tutorUserId 导师id
	 * @param tutorShopId 导师vshopId
	 * @param inviteTime 邀请时间
	 * @param orderNo	订单号
	 */
	public void mqDataStored(Long userId,Long inviterUserId,Long inviterShopId,Long tutorUserId,Long tutorShopId,Long inviteTime,String orderNo){
		JSONObject jo = new JSONObject();
		jo.put("userId",userId);
		jo.put("inviterUserId",inviterUserId);
		jo.put("inviterShopId",inviterShopId);
		jo.put("tutorUserId",tutorUserId);
		jo.put("tutorShopId",tutorShopId);
		jo.put("inviteTime",inviteTime);
		jo.put("orderNo",orderNo);
		send(jo.toJSONString());
	}
}
