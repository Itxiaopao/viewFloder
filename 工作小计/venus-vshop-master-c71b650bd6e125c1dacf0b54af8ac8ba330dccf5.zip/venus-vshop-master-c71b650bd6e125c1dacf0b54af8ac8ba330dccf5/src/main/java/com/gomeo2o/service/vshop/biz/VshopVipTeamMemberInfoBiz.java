package com.gomeo2o.service.vshop.biz;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageBean;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.VshopVipRelationshipDto;
import com.gomeo2o.facade.vshop.entity.VshopVipTeamMemberInfo;
import com.gomeo2o.facade.vshop.enums.VipIdentityEnum;
import com.gomeo2o.service.vshop.dao.VshopVipInfoDao;
import com.gomeo2o.service.vshop.dao.VshopVipTeamMemberInfoDao;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopVipTeamMemberInfoBiz")
public class VshopVipTeamMemberInfoBiz {
	
	@Autowired
	private VshopVipTeamMemberInfoDao vshopVipTeamMemberInfoDao;
	
	@Autowired
	private VshopVipInfoDao vshopVipInfoDao;
	
	public CommonResultEntity<PageBean> getVshopVipTeamMembers(PageParam pageParam, Long tutorUserId) {
		CommonResultEntity<PageBean> cre = new CommonResultEntity<PageBean>();
		PageBean pageBean = new PageBean();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("tutorUserId", tutorUserId);
		int count = vshopVipTeamMemberInfoDao.countVshopVipTeamMemberByTutorUserId(map);
		pageBean.setTotalCount(count);
		if(count == 0){
			cre.setBusinessObj(pageBean);
			return cre;
		}
		List<VshopVipTeamMemberInfo> list = vshopVipTeamMemberInfoDao.getVshopVipTeamMembers(pageParam,tutorUserId);
		List<VshopVipRelationshipDto> resultList = new ArrayList<VshopVipRelationshipDto>();
		if(list != null){
			for(VshopVipTeamMemberInfo teamInfo:list){
				VshopVipRelationshipDto vipDto = new VshopVipRelationshipDto();
				vipDto.setIdentity(VipIdentityEnum.VIP.name());
				vipDto.setInviteTime(teamInfo.getCreateTime());
				vipDto.setSource(teamInfo.getSource());
				vipDto.setUserId(teamInfo.getMemberUserId());
				resultList.add(vipDto);
			}
		}
		pageBean.setRecordList(resultList);
		cre.setBusinessObj(pageBean);
		return cre;
	}

	public void createVshopVipTeamMemberInfo(VshopVipTeamMemberInfo vvtmi) {
		vshopVipTeamMemberInfoDao.insert(vvtmi);
	}

	public Long queryTutorUserIdByMemberUserId(Long memberUserId){
		return vshopVipTeamMemberInfoDao.queryTutorUserIdByMemberUserId(memberUserId);
	}
}
