package com.gomeo2o.config;

import org.springframework.stereotype.Component;

/**
 * @author limenghui
 * @create 2020-07-28 13:33
 */
@Component
public class RabbitConfig {



}
