package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopCategory;
import com.gomeo2o.service.vshop.dao.VshopCategoryDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopCategoryDao")
public class VshopCategoryDaoImpl extends CBaseDaoImpl<VshopCategory> implements VshopCategoryDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopCategoryDaoImpl.";

	@Override
	public VshopCategory queryCategoryByVshopId(long vshopId) {
		return this.getSessionTemplate().selectOne(
				baseSQL + "queryCategoryByVshopId", vshopId);
	}

	@Override
	public int update(VshopCategory category) {
		return this.getSessionTemplate().update(
				baseSQL + "update", category);
	}
}
