package com.gomeo2o.mq;

import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.MessageQueueSelector;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.alibaba.rocketmq.common.message.MessageQueue;
import com.gome.diamond.annotations.DiamondValue;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Description vshop推送消息 (店铺分销商品上下架，店铺状态以及信息变动)
 * @author guowenbo
 * @date 2017年1月12日 下午3:47:54
 */
@Slf4j
@Component
public class MQPushProducer {
	private static DefaultMQProducer producer;

	@DiamondValue("${mq.plus.plus_manage_topic}")
	private String topic;
	@DiamondValue("${mq.plus.plus_manage_group}")
	private String group;
	@DiamondValue("${mq.queues}")
	private int queueTmp;
	@DiamondValue("${mq.address}")
	private String namesrvAddr;

	@PostConstruct
	public void init() {
		DefaultMQProducer producerNew = null;
		try {
			producerNew = new DefaultMQProducer(group);
			producerNew.setNamesrvAddr(namesrvAddr);
			producerNew.setInstanceName("Instace_");
			producerNew.setDefaultTopicQueueNums(queueTmp);
			producerNew.start();
			log.info("MQProducer 初始化成功！.....");
		} catch (Exception ex) {
			log.error("MQProducer 初始化异常...", ex);
		}
		// 这里很重要：先替换老实例再关闭老实例;如果先关闭老实例,有可能它在被程序调用着
		DefaultMQProducer oldInsetance = producer;
		producer = producerNew;
		if (oldInsetance != null) {
			oldInsetance.shutdown();
		}
	}

	public SendResult send(String message,String tag,String itemId){
		try {
			log.info("MQPushProducer:send mq message parameter message: {},topic: {},  tag: {}, namesrvAddr: {}, groupName: {}",
					message, topic, tag, namesrvAddr, group);
			Message msg = new Message(topic, tag, message.getBytes("utf-8"));
			SendResult sendResult;
			if ("TagPlusProduct".equals(tag) && StringUtils.isNotBlank(itemId)) {
	            //推送mq消息，按商品id分块，保证消息的顺序一致性
				sendResult=  producer.send(msg, new MessageQueueSelector() {
	                @Override
	                public MessageQueue select(List<MessageQueue> mqs, Message msg, Object arg) {
	                    Integer id = (Integer) arg;
	                    int index = id % mqs.size();
	                    return mqs.get(index);
	                }
	            }, getHashKey(itemId));
			} else {
				sendResult= producer.send(msg);
			}
			
			log.info("send mq message success! msgId:{},message:{}",sendResult.getMsgId(),message);
			return sendResult;
		} catch (Exception e) {
			log.error("MQPushProducer:send msg error: ", e);
			return null;
		}
	}
	
	public static int getHashKey(String key) {
        int hashCode = 0;
        int i = 0;
        int len = key.length();
        for (; i < len; i++) {
            hashCode = ((hashCode * 33) + key.codePointAt(i)) & 0x7fffffff;
        }
        return hashCode;
    }

}
