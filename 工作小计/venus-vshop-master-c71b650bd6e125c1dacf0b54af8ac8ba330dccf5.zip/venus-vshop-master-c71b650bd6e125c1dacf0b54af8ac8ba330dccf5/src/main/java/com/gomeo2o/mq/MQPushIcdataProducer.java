package com.gomeo2o.mq;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.stereotype.Component;

import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.gome.diamond.annotations.DiamondValue;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Description 店铺信息推送大数据
 * @author guowenbo
 * @date 2017年1月12日 下午3:47:54
 */
@Slf4j
@Component
public class MQPushIcdataProducer {

	@DiamondValue("${mq.address}")
	private String namesrvAddr;
	@DiamondValue("${mq.mshop.mshop_topic}")
	private String topic;
	@DiamondValue("${mq.mshop.mshop_icdata_mshopinfo_group}")
	private String group;
	
	private DefaultMQProducer producer = null;

	private String tag = "mshopInfo";

	@PostConstruct
	public void init(){
		/**
		 * 一个应用创建一个Producer，由应用来维护此对象，可以设置为全局对象或者单例<br>
		 * 注意：ProducerGroupName需要由应用来保证唯一<br>
		 * ProducerGroup这个概念发送普通的消息时，作用不大，但是发送分布式事务消息时，比较关键，
		 * 因为服务器会回查这个Group下的任意一个Producer
		 */
		log.info("MQPushIcdataProducer start ! topic: {},  namesrvAddr: {}, group: {}" , topic, namesrvAddr, group);
		
		producer = new DefaultMQProducer(group);
		producer.setNamesrvAddr(namesrvAddr);
		try {
			producer.start();
		} catch (MQClientException e) {
			log.error("vshop-MQPushIcdataProducer start fail ! ", e);
		}
		log.debug("vshop-MQPushIcdataProducer start success!");
	}

	/**
	 * 应用退出时，要调用shutdown来清理资源，关闭网络连接，从MetaQ服务器上注销自己
	 * 注意：我们建议应用在JBOSS、Tomcat等容器的退出钩子里调用shutdown方法  
	 */
	@PreDestroy
	public void shutdown(){
		producer.shutdown();
	}

	/**
	 *
	 * @param message:
	 *                  {
	 *						"id": 6222,
	 *						"name": "银联",
	 *						"status": 3,
	 *						"description": "111111111111",
	 *						"userId": 12,
	 *						"icon": "http://10.125.31.23/v1/img/T1RFhTBmCT1R4cSCrK.png",
	 *						"sendTime": 1442851200000,
	 *						"action":"create"
	 *					}
	 * @return
	 */
	public SendResult send(String message){
		try {
			log.info("MQPushIcdataProducer:send mq message parameter message: {},topic: {},  tag: {}, namesrvAddr: {}, groupName: {}", message, topic, tag, namesrvAddr, group);
			Message msg = new Message(topic, tag, message.getBytes("utf-8"));
			SendResult sendResult = producer.send(msg);
			log.info("MQPushIcdataProducer send mq message success! msgId:{},message:{}",sendResult.getMsgId(),message);
			return sendResult;
		} catch (Exception e) {
			log.error("MQPushIcdataProducer:send msg error: ", e);
			return null;
		}
	}

}
