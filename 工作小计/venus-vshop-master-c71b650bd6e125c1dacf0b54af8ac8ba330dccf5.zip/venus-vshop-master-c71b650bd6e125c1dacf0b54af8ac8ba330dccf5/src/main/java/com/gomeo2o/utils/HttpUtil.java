package com.gomeo2o.utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * @author limenghui
 * @create 2020-07-29 11:34
 */
@Slf4j
public class HttpUtil {
    private static CloseableHttpClient httpclient = null;

    private static IdleConnectionMonitorThread scanThread = null;

    /**
     * 初始化client对象.
     */
    public static void init() {

        // 连接池设置
        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(800); // 最多800个连接
        cm.setDefaultMaxPerRoute(400); // 每个路由400个连接

        // 创建client对象
        httpclient = HttpClients.custom().setConnectionManager(cm).build();

        // 扫描无效连接的线程
        scanThread = new IdleConnectionMonitorThread(cm);
        scanThread.start();
    }

    /**
     * 关闭连接池.
     */
    public static void close() {
        if (httpclient != null) {
            try {
                httpclient.close();
            } catch (IOException e) {
            }
        }
        if (scanThread != null) {
            scanThread.shutdown();
        }
    }

    /**
     * Get方式取得URL的内容.
     *
     * @param url
     *            访问的网址
     * @return
     */
    public static String getUrlContent(String url) {

        // 参数检查
        if (httpclient == null) {
            //throw new RuntimeException("httpclient not init.");
            log.error("getUrlContent:httpclient not init.");
            return null;
        }
        if (url == null || url.trim().length() == 0) {
            //throw new RuntimeException("url is blank.");
            log.error("getUrlContent:url is blank.");
            return null;
        }

        HttpGet httpGet = new HttpGet(url);
        CloseableHttpResponse response = null;
        try {
            // 执行请求
            response = httpclient.execute(httpGet, HttpClientContext.create());

            // 转换结果
            HttpEntity entity1 = response.getEntity();
            String html = EntityUtils.toString(entity1, "utf-8");

            // 消费掉内容
            EntityUtils.consume(entity1);
            return html;
        } catch (IOException e) {
            log.error("getUrlContent:httpclient.execute happens exception.", e);
            return "";
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    log.error("getUrlContent:response.close() happens exception.");
                }
            }
            httpGet.releaseConnection();
        }
    }

    /**
     * Post方式取得URL的内容，默认为"application/x-www-form-urlencoded"格式，charset为UTF-8.
     *
     * @param url
     *            访问的网址
     * @param content
     *            提交的数据
     * @return
     */
    public static String postToUrl(String url, Map<String, Object> params) {
        return postToUrl(url, params, "application/x-www-form-urlencoded",
                "UTF-8");
    }

    /**
     * json字符串形式请求
     *
     * @param url
     * @param param
     * @return
     */
    public static String postForJson(String url, Map<String, Object> params) {
        return postToUrl(url, params, "application/json", "UTF-8");
    }

    /**
     * Post方式取得URL的内容.
     *
     * @param url
     *            访问的网址
     * @param content
     *            提交的数据
     * @return
     */
    public static String postToUrl(String url, Map<String, Object> params,
            String contentType, String charset) {

        // 参数检查
        if (httpclient == null) {
            log.error("postToUrl:httpclient not init.");
            return null;
        }
        if (url == null || url.trim().length() == 0) {
            log.error("postToUrl:url is blank.");
            return null;
        }

        HttpPost httpPost = new HttpPost(url);
        setPostParams(httpPost, params);
        //        // 设置内容
        //        ContentType type = ContentType.create(contentType,
        //                Charset.forName(charset));
        //        StringEntity reqEntity = new StringEntity(content, type);
        //        httpPost.setEntity(reqEntity);
        //        httpPost.addHeader("User-Agent",
        //                "Mozilla/4.0 (compatible; MSIE .0; Windows NT 6.1; Trident/4.0; SLCC2;)");
        //        httpPost.addHeader("Accept-Encoding", "*");

        // 设置请求和传输超时时间
        RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(30000).setConnectTimeout(30000).build();
        httpPost.setConfig(requestConfig);

        CloseableHttpResponse response = null;
        try {
            // 执行请求
            response = httpclient.execute(httpPost, HttpClientContext.create());

            // 转换结果
            HttpEntity entity1 = response.getEntity();
            String html = EntityUtils.toString(entity1, charset);

            // 消费掉内容
            EntityUtils.consume(entity1);
            return html;
        } catch (IOException ex) {
            log.error("postToUrl:httpclient.execute happens exception.", ex);
            return null;
        } finally {
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                    log.error("postToUrl:response.close() happens exception.", e);
                    return null;
                }
            }
            httpPost.releaseConnection();
        }
    }

    /**
     * @Description 设置POST请求参数
     * @author jiale
     * @date 2017年3月4日 下午4:11:30
     * @param httpost
     * @param params
     */
    private static void setPostParams(HttpPost httpost,
            Map<String, Object> params) {
        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            nvps.add(new BasicNameValuePair(key, params.get(key).toString()));
        }
        try {
            httpost.setEntity(new UrlEncodedFormEntity(nvps, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            log.error("httpost.setEntity happens error.", e);
        }
    }

}
