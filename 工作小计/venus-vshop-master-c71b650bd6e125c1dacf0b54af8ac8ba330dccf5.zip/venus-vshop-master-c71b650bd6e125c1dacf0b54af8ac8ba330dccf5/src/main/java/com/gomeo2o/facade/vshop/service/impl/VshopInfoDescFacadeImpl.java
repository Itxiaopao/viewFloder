package com.gomeo2o.facade.vshop.service.impl;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dianping.cat.Cat;
import com.dianping.cat.message.Message;
import com.dianping.cat.message.Transaction;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.facade.vshop.service.VshopInfoDescFacade;
import com.gomeo2o.service.vshop.biz.VshopInfoBiz;
import com.gomeo2o.service.vshop.biz.VshopInfoDescBiz;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 美店主信息同步
 * @author chenchen-ds6
 * @date: 2019年10月10日 下午19:20:00
 */
@Slf4j
@Service("vshopInfoDescFacade")
public class VshopInfoDescFacadeImpl implements VshopInfoDescFacade{
    @Autowired
    VshopInfoDescBiz vshopInfoDescBiz;

    @Autowired
    VshopInfoBiz vshopInfoBiz;

    @Override
    public CommonResultEntity<Long> synVshopInfoDesc(List<VshopInfoDesc> list) {
        return new CommonResultEntity<Long>();
    }

    @Override
    public VshopInfoDesc getVshopInfoDesc(Long userId) {
        return vshopInfoDescBiz.getVshopInfoDesc(userId);
    }
    /**
     * mis后台提供服务，连表查询美店主信息
     * @param map
     * @return
     */
    @Override
    public CommonResultEntity<List<VshopInfoDesc>> queryVshopInfoDescUnionVshopInfoByParam(
            Map<String,Object> map) {
        CommonResultEntity<List<VshopInfoDesc>> cre = new CommonResultEntity<List<VshopInfoDesc>>();
        List<VshopInfoDesc> vshopInfoDescs = vshopInfoDescBiz.queryVshopInfoDescUnionVshopInfoByParam(map);
        cre.setBusinessObj(vshopInfoDescs);
        return cre;
    }
    /**
     * mis后台提供服务，连表查询美店主信息条数
     * @param map
     * @return
     */

    @Override
    public CommonResultEntity<Long> queryCountVshopInfoDescUnionVshopInfoByParam(Map<String, Object> map) {
        CommonResultEntity<Long> cre = new CommonResultEntity<Long>();
        Long count=vshopInfoDescBiz.queryCountVshopInfoDescUnionVshopInfoByParam(map);
        cre.setBusinessObj(count);
        return cre;
    }

    @Override
    public void synSocietyVshopInfoDesc() {
        return;
    }

    @Override
    public CommonResultEntity<VshopInfoDesc> queryVshopInfoDescByUserId(Long userId) {
        if (userId < 1000) {
            Transaction transaction = Cat.newTransaction("testTransactionUser", "queryVshopInfoDescByUserId");
            transaction.addData("errorParam: ",userId);
            transaction.addData("methodName: ","queryVshopInfoDescByUserId");
            transaction.addData("testUser: ","MeiliLi");
            transaction.addData("任意自己需要记录的key: ","任意自己需要记录的value");
            try {
                //需要监控的业务代码
                long l = 100 / userId;
                transaction.setStatus(Message.SUCCESS);
            } finally {
                transaction.complete();
            }

        }
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if(userId == null || userId <= 0) {
            return new CommonResultEntity(1,"userId不符合规范",null);
        }
        VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);
        if(vshopInfo == null) {
            return new CommonResultEntity(0,"vshop_info表不存在",null);
        }
        long mid = vshopInfo.getVshopId();
        VshopInfoDesc vshopInfoDesc = getVshopInfoDesc(userId);
        if(vshopInfoDesc == null) {
            return new CommonResultEntity(0,"vshop_info_desc表不存在",null);
        }
        vshopInfoDesc.setVshopId(mid);
        vshopInfoDesc.setVshopIdentity(vshopInfo.getVshopIdentity());
        return new CommonResultEntity(0,"success ",vshopInfoDesc);
    }

}