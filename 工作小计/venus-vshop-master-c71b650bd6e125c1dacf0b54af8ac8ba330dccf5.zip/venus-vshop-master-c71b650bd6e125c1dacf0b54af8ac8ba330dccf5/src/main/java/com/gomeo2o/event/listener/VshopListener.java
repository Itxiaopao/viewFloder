/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: VshopListener.java 
 * @Prject: venus-vshop
 * @Package: com.gomeo2o.event.listener 
 * @Description: 美店信息监听类
 * @author: sunyizhong   
 * @date: 2016年11月24日 下午3:01:14 
 * @version: V1.0   
 */
package com.gomeo2o.event.listener;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.gomeo2o.event.vshop.CreateVshopEvent;
import com.gomeo2o.event.vshop.UpdateVshopEvent;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.service.vshop.biz.VshopMqBiz;
import com.gomeo2o.service.vshop.dao.VshopInfoDao;
import com.google.common.eventbus.Subscribe;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

/**
 * 
 * @ClassName: VshopListener
 * @Description: 美店信息监听类
 * @author: sunyizhong
 * @date: 2016年11月24日 下午3:02:31
 */
@Component
@Slf4j
public class VshopListener implements EventListener {


	@Autowired
	private VshopInfoDao vshopInfoDao;


	@Autowired
    private VshopMqBiz vshopMqBiz;

	private final String VSHOP_INFO_KEY = "vshop:vshopInfo_userId:";

	@Resource(name = "vshopCache")
	Gcache gcache;

	/**
	 * 
	 * @Title: onVshopCreateEvent
	 * @Description: 创建美店事件
	 * @param event
	 * @return: void
	 */
	@Subscribe
	public void onVshopCreateEvent(CreateVshopEvent event) {
		Long vshopId = event.id();
		// 获取美店信息
		VshopInfo vshopInfo = vshopInfoDao.getById(vshopId);
		//更新gcache
		gcache.set(VSHOP_INFO_KEY+vshopInfo.getUserId(), JSON.toJSONString(vshopInfo));
		//推送rocketMq->商城->搜索->大数据
		vshopMqBiz.pushVshopInfoRocketMq(vshopInfo,"create");
		//推送rabbitMq->大数据
//		vshopMqBiz.pushVshopInfoRabbitMq(vshopInfo,SubmitAction.CREATE);

	}

	/**
	 * 
	 * @Title: onVshopUpdateEvent 
	 * @Description: 更新美店事件
	 * @param event
	 * @return: void
	 */
	@Subscribe
	public void onVshopUpdateEvent(UpdateVshopEvent event) {
		Long vshopId = event.id();
		// 获取美店信息
		VshopInfo vshopInfo = vshopInfoDao.getById(vshopId);
		vshopInfo.setCtx("");
		//存放gcache
		gcache.set(VSHOP_INFO_KEY+vshopInfo.getUserId(), JSON.toJSONString(vshopInfo));
		//推送rocketMq->商城->搜索->大数据
        vshopMqBiz.pushVshopInfoRocketMq(vshopInfo,"update");
		//推送rabbitMq->大数据
//        vshopMqBiz.pushVshopInfoRabbitMq(vshopInfo,SubmitAction.UPDATE);
	}
	
}
