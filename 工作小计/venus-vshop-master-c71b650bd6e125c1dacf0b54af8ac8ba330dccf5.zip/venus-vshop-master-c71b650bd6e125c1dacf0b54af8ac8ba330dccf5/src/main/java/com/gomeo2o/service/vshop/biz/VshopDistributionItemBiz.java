/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年4月8日 下午4:25:44
 */
package com.gomeo2o.service.vshop.biz;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.event.listener.CoreEventDispatcher;
import com.gomeo2o.event.vshop.CreateVshopItemEvent;
import com.gomeo2o.event.vshop.DeleteVshopItemEvent;
import com.gomeo2o.facade.vshop.entity.VshopDistributionItem;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopOnItemCount;
import com.gomeo2o.facade.vshop.enums.ProductStatusEnum;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.mq.MQPushProducer;
import com.gomeo2o.service.vshop.dao.VshopDistributionItemDao;
import com.gomeo2o.service.vshop.dao.VshopOnItemCountDao;
import com.gomeo2o.utils.JsonUtils;
import com.gomeo2o.utils.PropertiesUtil;
import com.gomeo2o.utils.ValidateUtils;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

/**
 * @Description: 商品分销
 * @author: guowenbo
 * @date: 2015年4月8日 下午4:25:44
 */

@Slf4j
@Service("vshopDistributionItemBiz")
public class VshopDistributionItemBiz {

	public static final String ACCESSUAT_EC_API_HOST = "accessuat.ec.api.host";

	@Autowired
	private VshopDistributionItemDao vshopDistributionItemDao;

	@Autowired
	private VshopInfoBiz vshopInfoBiz;

	@Autowired VshopOnItemCountDao vshopOnItemCountDao;

	@Autowired
	private CoreEventDispatcher coreEventDispatcher;

	@Autowired
	private MQPushProducer mqPushProducer;
	@Autowired Gcache vshopCache;


	ThreadPoolExecutor pool = new ThreadPoolExecutor(Runtime.getRuntime().availableProcessors(),Runtime.getRuntime().availableProcessors(), 
			0l, TimeUnit.MILLISECONDS, new ArrayBlockingQueue<Runnable>(2000),new ThreadPoolExecutor.CallerRunsPolicy());

	public VshopDistributionItemBiz() {
	}

	public int queryProductCountByVshopId(long vshopId, String status) {
		return vshopDistributionItemDao.queryProductCountByVshopId(vshopId, status);
	}

	public List<VshopDistributionItem> queryListProductByCategoryId(PageParam pageParam, long vcategoryId, long vshopId, String status) {
		return vshopDistributionItemDao.queryListProductByCategoryId(pageParam, vcategoryId, vshopId, status);
	}

	public List<VshopDistributionItem> queryListProductByStatus(PageParam pageParam, String status, long vshopId) {
		return vshopDistributionItemDao.queryListProductByStatus(pageParam, status, vshopId);
	}

	public int queryProductCountByStatus(String status, long vshopId) {
		return vshopDistributionItemDao.queryProductCountByStatus(status, vshopId);
	}

	public int queryItemCountByCategoryId(long vcategoryId, long vshopId, String status) {
		return vshopDistributionItemDao.queryItemCountByCategoryId(vcategoryId, vshopId, status);
	}

	public void createDistributionItem(VshopDistributionItem vshopProductadd) {
		VshopDistributionItem product = vshopDistributionItemDao.queryProductByProductId(vshopProductadd.getItemId(), vshopProductadd.getSkuId(),
				vshopProductadd.getVshopId());
		long id = 0;
		if (product != null) {
			// 美店分销的商品为非上架状态，再次被分销时，修改原始记录
			id = product.getId();
			vshopProductadd.setId(id);
			vshopProductadd.setCreateTime(new Date());
			vshopDistributionItemDao.update(vshopProductadd);
			int oldStatus = product.getStatus();// 0下架1上架2冻结
			if (oldStatus != 1) {
				long vshopId = vshopProductadd.getVshopId();
				vshopCache.incr("shop:shopitemscount:"+vshopId);
			}
		} else {
			id = vshopDistributionItemDao.insert(vshopProductadd);
			vshopProductadd.setId(id);
			vshopProductadd.setCreateTime(new Date());
			// 上架，redis计数加一
			long vshopId = vshopProductadd.getVshopId();
			// String productId = vshopProductadd.getProductId();
			vshopCache.incr("shop:shopitemscount:"+vshopId);
		}
		// 发布美店商品上架信息
		// 封装推送数据平台的数据
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("vshopId", vshopProductadd.getVshopId());
		data.put("itemId", vshopProductadd.getItemId());
		data.put("status", vshopProductadd.getStatus());
		data.put("createTime", new Date().getTime());
		CreateVshopItemEvent event = new CreateVshopItemEvent(vshopProductadd.getVshopId());
		event.setData(data);
		coreEventDispatcher.publish(event);
		sendMQ(vshopProductadd.getVshopId(), vshopProductadd.getItemId(), vshopProductadd.getStatus(),vshopProductadd.getVcategoryId(), vshopProductadd.getId(), 0,
				vshopProductadd.getSkuId(),vshopProductadd.getCreateTime(),vshopProductadd.getIdentification());
	}

	private static RestTemplate restTemplate = new RestTemplate();

	public void deleteUserDistributionItem(Long userId) {
		VshopInfo info = vshopInfoBiz.queryVshopByuserId(userId);

		PageParam pageParam = new PageParam();
		pageParam.setPageNum(0);
		pageParam.setNumPerPage(1000000);

		List<VshopDistributionItem> distributionItemList = vshopDistributionItemDao.queryListProductByStatus(pageParam,
				ProductStatusEnum.SHANGJIA.getValue() + "", info.getVshopId());

		for (VshopDistributionItem distributionItem : distributionItemList) {
			ResponseEntity<Map> responseEntity = restTemplate.getForEntity(
					PropertiesUtil.getProperTies(VshopDistributionItemBiz.ACCESSUAT_EC_API_HOST), Map.class, distributionItem.getItemId());
			if (responseEntity.getStatusCode() != HttpStatus.OK) {
				throw new RuntimeException("call online interface error");
			}
			Map map = responseEntity.getBody();
			Map dataMap = (Map) map.get("data");
			boolean classify = (Boolean) dataMap.get("classify");
			if (classify) {
				Map<String, Object> deleteMap = new HashMap<String, Object>();
				map.put("vshopId", info.getVshopId());
				deleteMap.put("itemId", distributionItem.getItemId());
				vshopDistributionItemDao.deleteDistributionItem(deleteMap);
			}
		}

	}

	/**
	 * 更新店铺内分类、 旧逻辑里的分销上下架处理
	 * 
	 * @param vshopDistributionItem
	 */
	public void updateDistributionItem(VshopDistributionItem vshopDistributionItem) {
		String itemId = vshopDistributionItem.getItemId();
		String skuId = vshopDistributionItem.getSkuId();
		long vshopId = vshopDistributionItem.getVshopId();
		// 旧的状态
		VshopDistributionItem vshopProductOld = vshopDistributionItemDao.queryProductByProductId(itemId, skuId, vshopId);
		if (vshopDistributionItem.getIsDelete() != null && vshopDistributionItem.getIsDelete() == 1) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("itemId", itemId);
			map.put("vshopId", vshopId);
			vshopDistributionItemDao.deleteDistributionItem(map);
		} else {
			vshopDistributionItemDao.update(vshopDistributionItem);
			//先推送删除后新增
			sendMQ(vshopId, itemId, ProductStatusEnum.XIAJIA.getValue(), 0, vshopProductOld.getId(), 0,skuId,vshopProductOld.getCreateTime(),vshopProductOld.getIdentification());
			sendMQ(vshopId, itemId, ProductStatusEnum.SHANGJIA.getValue(), vshopDistributionItem.getVcategoryId(), vshopProductOld.getId(), 0,skuId,vshopProductOld.getCreateTime(),vshopProductOld.getIdentification());
		}
		if (vshopDistributionItem.getStatus() != null) {

			int updateStatus = vshopDistributionItem.getStatus();// 上下架标示,0:下架,1:上架,2:冻结'
			int oldStatus = vshopProductOld.getStatus(); // 上下架标示
															// 0:下架,1:上架,2:冻结'
			if (oldStatus == 1 && updateStatus != 1)
				vshopCache.decr("shop:shopitemscount:"+vshopId);
			if (oldStatus != 1 && updateStatus == 1)
				vshopCache.incr("shop:shopitemscount:"+vshopId);
		}
	}

	/**
	 * 批量更新店铺内分类
	 * 
	 * @param itemIds
	 * @param vshopId
	 * @param vcategoryId
	 */
	public void updateDistributionItems(List<String> itemIds, long vshopId, long vcategoryId) {
		vshopDistributionItemDao.updateDistributionItems(itemIds, vshopId, vcategoryId);
		for (String itemId : itemIds) {
			VshopDistributionItem vshopProductOld = vshopDistributionItemDao.queryProductByProductId(itemId, null, vshopId);
			//先推送删除后新增
			sendMQ(vshopId, itemId, ProductStatusEnum.XIAJIA.getValue(), 0, vshopProductOld.getId(), 0,vshopProductOld.getSkuId(),vshopProductOld.getCreateTime(),vshopProductOld.getIdentification());
			sendMQ(vshopId, itemId, ProductStatusEnum.SHANGJIA.getValue(), vcategoryId, vshopProductOld.getId(), 0,vshopProductOld.getSkuId(),vshopProductOld.getCreateTime(),vshopProductOld.getIdentification());
		}
	}

	/**
	 * V2新逻辑取消分销
	 * 
	 * @param itemId
	 * @param vshopId
	 */
	public void deleteDistributionItem(String itemId, String skuId, long vshopId) {
		VshopDistributionItem vshopProductadd = vshopDistributionItemDao.queryProductByProductId(itemId, skuId, vshopId);
		if (vshopProductadd == null) {
			return;
		}
		int status1 = vshopProductadd.getStatus(); // 上下架标示 0:下架,1:上架,2:冻结'
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("itemId", itemId);
		map.put("vshopId", vshopId);
		map.put("skuId", skuId);
		log.info("deleteItem-itemInfo: vshopId {}, itemId {}", vshopId, itemId);
		int result=vshopDistributionItemDao.deleteDistributionItem(map);
		log.info("deleteDistributionItem result={}",result);
		if (1==status1&&1==result) {
			// 上架商品删除才减1
			log.info("deleteItem-decrRedis,itemInfo: vshopId {}, itemId {}", vshopId, itemId);
			vshopCache.decr("shop:shopitemscount:"+vshopId);
			// 封装推送数据平台的数据
			// 发布美店商品下架信息
			Map<String, Object> data = new HashMap<String, Object>();
			data.put("vshopId", vshopId);
			data.put("itemId", itemId);
			data.put("status", 0);
			data.put("createTime", new Date().getTime());
			DeleteVshopItemEvent event = new DeleteVshopItemEvent(vshopProductadd.getVshopId());
			event.setData(data);
			coreEventDispatcher.publish(event);
			String pshopId = vshopProductadd.getPshopId();
			long popId = 0L;
			if (StringUtils.isNotBlank(pshopId) && !"null".equals(pshopId)) {
			    try {
			        popId = Long.parseLong(pshopId);
                } catch (Exception e) {
                    log.warn("pshopId is not number,shopId is {} ,itemId is {}",vshopId,itemId);
                }
			}
			log.info("deleteDistributionItem2SendMQ: itemInfo: vshopId {}, itemId {}", vshopId, itemId);
			sendMQ(vshopId, itemId, ProductStatusEnum.XIAJIA.getValue(),0, vshopProductadd.getId(), popId,skuId,vshopProductadd.getCreateTime(),vshopProductadd.getIdentification());
		}
	}

	/**
	 * V2新逻辑批量取消分销
	 * 
	 * @param itemIds
	 * @param vshopId
	 */
	public void deleteDistributionItems(List<String> itemIds, long vshopId) {
		for (String itemId : itemIds) {
			// TODO 批量还未处理 ↓ 参数null需替换成真实数值
			VshopDistributionItem vshopProductadd = vshopDistributionItemDao.queryProductByProductId(itemId, null, vshopId);
			if (vshopProductadd == null) {
				continue;
			}
			int status = vshopProductadd.getStatus(); // 上下架标示 0:下架,1:上架,2:冻结'
			if (status == 1) {
				// 上架商品删除才减1
				vshopCache.decr("shop:shopitemscount:"+vshopId);
				// 封装推送数据平台的数据
				// 发布美店商品下架信息
				JSONObject data = new JSONObject();
				data.put("vshopId", vshopId);
				data.put("itemId", itemId);
				data.put("status", 0);
				data.put("createTime", new Date().getTime());
				DeleteVshopItemEvent event = new DeleteVshopItemEvent(vshopProductadd.getVshopId());
				event.setData(data);
				coreEventDispatcher.publish(event);
				sendMQ(vshopId, itemId, 0, 0, vshopProductadd.getId(), 0,vshopProductadd.getSkuId(),vshopProductadd.getCreateTime(),vshopProductadd.getIdentification());
			}
		}
		vshopDistributionItemDao.deleteDistributionItems(itemIds, vshopId);
	}

	public List<VshopDistributionItem> queryListProductByVshopId(PageParam pageParam, long vshopId, String status) {
		return vshopDistributionItemDao.queryListProductByVshopId(pageParam, vshopId, status);
	}

	/**
	 * @Description: 通过MQ同步更新分销商品信息(商品状态更新)
	 * @author: guowenbo
	 * @date: 2015年5月22日 上午10:04:45
	 * @return
	 */
	/*public void updateProductStatusByPop(String body) {
		// 校验字段
		if (ValidateUtils.isNull(body)) {
			throw VshopException.PARAM_IS_NULL;
		}

		// 将json转换为map集合
		Map<String, Object> map = JsonUtils.toMap(body);
		String itemId = null;
		Long shopId = null;
		Integer status = null;
		// map非空放入数据
		if (!map.isEmpty()) {
			// 验证mq参数是否齐全
			ValidateUtils.notNull(map, "product_id", "is_valid", "shop_id");
			if (ProductStatusEnum.DONGJIE.getValue() != Integer.parseInt(map.get("is_valid").toString())) {
				log.info("mq接收参数is_valid值不为冻结，不做处理！is_valid = {}", map.get("is_valid"));
				return;
			}

			itemId = map.get("product_id").toString();
			status = ProductStatusEnum.XIAJIA.getValue();
			shopId = Long.parseLong(map.get("shop_id").toString());
		}
		// 删除已经推荐的该商品
		// deleteRecommendItem(shopId, itemId);
		log.info("MQ productUpdate: itemId'{}' status'{}'", itemId, status);
		List<VshopDistributionItem> productList = null;
		Map<String, Object> map1 = new HashMap<String, Object>();
		try {
			productList = vshopDistributionItemDao.queryListProductByProductId(itemId);
		} catch (Exception e) {
			log.error("query ListProduct By ProductId happen exception: ", e);
		}
		try {
			map1.put("itemId", itemId);
			map1.put("status", status);
			vshopDistributionItemDao.updateDistributionItemByMQ(map1);
		} catch (Exception e) {
			log.error("MQ productUpdate Error!!!: itemId'{}' status'{}'", itemId, status);
		}
		// 执行更改店铺数量的方法
		shopItemsCountChange(productList, status, itemId);
		log.debug("consumer MQ end...");
	}*/
	
	/**
	 * @Description: 通过MQ同步更新分销商品信息(分销状态更新)
	 * @author: guowenbo
	 * @date: 2015年6月1日 上午11:33:04
	 * @param body
	 */
	/*
	public void updateProductAddByFx(String body) {
		// 校验字段
		if (ValidateUtils.isNull(body)) {
			throw VshopException.PARAM_IS_NULL;
		}

		// 将json转换为map集合
		Map<String, Object> map = JsonUtils.toMap(body);
		String itemId = null;
		// 把不可分销后的商品状态更改为下架
		int status = ProductStatusEnum.XIAJIA.getValue();

		// map非空放入数据
		if (!map.isEmpty()) {

			// 验证mq参数是否齐全
			ValidateUtils.notNull(map, "product_id");
			if (ProductStatusEnum.DONGJIE.getValue() != Integer.parseInt(map.get("is_valid").toString())) {
				log.info("mq接收参数is_valid值不为冻结，不做处理！is_valid = {}", map.get("is_valid"));
				return;
			}
			itemId = map.get("product_id").toString();
		}
		List<VshopDistributionItem> productList = null;
		Map<String, Object> map1 = new HashMap<String, Object>();
		try {
			productList = vshopDistributionItemDao.queryListProductByProductId(itemId);
		} catch (Exception e) {
			log.error("query ListProduct By ProductId happen exception: ", e);
		}
		log.info("MQ productFxUpdate itemId'{}' status'{}'", itemId, status);
		try {
			map1.put("itemId", itemId);
			map1.put("status", status);
			vshopDistributionItemDao.updateDistributionItemByMQ(map1);
		} catch (Exception e) {
			log.error("MQ productFxUpdate Error!!!: itemId'{}' status'{}'", itemId, status);
		}
		shopItemsCountChange(productList, status, itemId);
	}*/

	/**
	 * @Description: 通过MQ同步更新分销商品信息(商品状态更新)
	 * @author: guowenbo
	 * @date: 2015年5月22日 上午10:04:45
	 * @return
	 */
	public void updateProductStatusByPopForOnline(String body) {
		// 校验字段
		if (ValidateUtils.isNull(body)) {
			throw VshopException.PARAM_IS_NULL;
		}

		// 将json转换为map集合
		Map<String, Object> map = JsonUtils.toMap(body);
		//Map<String, Object> map1 = new HashMap<String, Object>();
		String itemId = null;
		//Integer status = null;
		// map非空放入数据
		if (!map.isEmpty()) {
			// 验证mq参数是否齐全
			ValidateUtils.notNull(map, "productId");
			itemId = map.get("productId").toString();
			//status = ProductStatusEnum.XIAJIA.getValue();
		}
		log.info("MQ productUpdate: itemId'{}' ", itemId);
		/*List<VshopDistributionItem> productList = null;
		try {
			productList = vshopDistributionItemDao.queryListProductByProductId(itemId);
		} catch (Exception e) {
			log.error("query ListProduct By ProductId happen exception: ", e);
		}
		try {
			map1.put("itemId", itemId);
			map1.put("status", status);
			vshopDistributionItemDao.updateDistributionItemByMQ(map1);
		} catch (Exception e) {
			log.error("MQ productUpdate Error!!!: itemId'{}' status'{}'", itemId, status);
		}
		// 执行更改店铺数量的方法
		shopItemsCountChange(productList, status, itemId);*/
		updateRedisAndAllDateForMQ(null, itemId);
		log.debug("consumer MQ end...");
	}

	/**
	 * @Description: 通过MQ同步更新分销商品信息(店铺关闭)
	 * @author: guowenbo
	 * @date: 2015年5月22日 上午10:04:45
	 * @return
	 */
	public void updateProductStatusByCloseForOnline(String body) {
		if (ValidateUtils.isNull(body)) {
			throw VshopException.PARAM_IS_NULL;
		}
		Map<String, Object> map = JsonUtils.toMap(body);
		//Map<String, Object> map1 = new HashMap<String, Object>();
		String popId = null;
		//Integer status = null;
		if (!map.isEmpty()) {
			ValidateUtils.notNull(map, "shopNo");
			popId = map.get("shopNo").toString();
			//status = ProductStatusEnum.XIAJIA.getValue();
		}
		log.info("MQ updateProductByClose: popId'{}'", popId);
		/*List<VshopDistributionItem> productList = null;
		try {
			// 从popId取所有下架商品的店铺以执行店铺上架商品数量redis减操作->shopItemsCountChange
			productList = vshopDistributionItemDao.queryListProductByPopId(popId);
			if (!productList.isEmpty()) {
				for (VshopDistributionItem shopDistributionItem : productList) {
					vshopCache.decr("shop:shopitemscount:"+String.valueOf(shopDistributionItem.getVshopId()));
				}
			}
		} catch (Exception e) {
			log.error("query ListProduct By popId happen exception : ", e);
		}
		try {
			map1.put("popId", popId);
			map1.put("status", status);
			vshopDistributionItemDao.updateDistributionItemByMQ(map1);
		} catch (Exception e) {
			log.error("MQ productUpdate Error!!!: popId'{}' status'{}'", popId, status);
		}
		 */		
		updateRedisAndAllDateForMQ(popId, null);
		log.debug("consumer MQ end...");
	}

	public VshopDistributionItem queryProductByProductId(String productId, String skuId, long vshopId) {
		return vshopDistributionItemDao.queryProductByProductId(productId, skuId, vshopId);
	}

	/**
	 * @Description: 校验商品存在与否 (flag是2则为编辑删除判断是否有该商品，flag是1则为新增判断是否有该商品)
	 * @author: guowenbo
	 * @date: 2015年6月4日 上午11:38:36
	 * @param vshopId
	 * @param itemId
	 * @param skuId
	 * @param flag
	 */
	public void checkProduct(long vshopId, String itemId, String skuId, int flag) {
		vshopDistributionItemDao.checkProduct(vshopId, itemId, skuId, flag);
	}

	/**
	 * @Description: 通过userId,productId判断是否已经存在商品
	 * @author: guowenbo
	 * @date: 2015年6月13日 下午3:58:42
	 * @param userId
	 * @param productId
	 * @param status
	 * @return
	 */
	public Boolean checkProductIsExist(String userId, String productId, String skuId, String status) {
		VshopInfo info = vshopInfoBiz.queryVshopByuserId(Long.parseLong(userId));
		Boolean flag = true;
		if (info != null) {
			flag = vshopDistributionItemDao.checkProductIsExist(info.getVshopId(), productId, skuId, status);
		} else {
			throw VshopException.VSHOP_EXIST;
		}
		return flag;
	}

	/**
	 * 
	 * @Description 通过vshopId,productId判断是否已经分销商品
	 * @author lijiahuan
	 * @date 2017年2月21日 下午7:33:07
	 * @param vshopId
	 * @param productId
	 * @param skuId
	 * @param status
	 * @return
	 */
	public Boolean queryProducDistributionStatus(Long vshopId, String productId, String skuId, String status) {
		return vshopDistributionItemDao.checkProductIsExist(vshopId, productId, skuId, status);
	}

	/**
	 * @Description: 店铺冻结下架所有上架的商品
	 * @author: guowenbo
	 * @date: 2015年7月3日 下午3:42:33
	 * @param vshopProductadd
	 */
	public void updateProductaddByDongJie(VshopDistributionItem vshopProductadd) {
		vshopDistributionItemDao.updateProductaddByDongJie(vshopProductadd);
		vshopCache.set("shop:shopitemscount:"+vshopProductadd.getVshopId(),"0");
	}

	/**
	 * @Description 改变店铺下商品数量
	 * @author suliangyi
	 * @date 2015年12月23日 下午6:44:52
	 * @param productList
	 * @param isValid
	 * @param itemId
	 */
	/*
	public void shopItemsCountChange(List<VshopDistributionItem> productList, int isValid, String itemId) {
		if (productList != null && productList.size() > 0) {
			for (int i = 0; i < productList.size(); i++) {
				VshopDistributionItem vshopProductadd = productList.get(i);
				int oldStatus = vshopProductadd.getStatus();// 上下架标示
															// 0:下架,1:上架,2:冻结,3:删除'
				long vshopId = vshopProductadd.getVshopId();
				if (oldStatus == 1 && isValid != 1) {
					// 上架状态更改为其他状态redis计数减一
					vshopCache.decr("shop:shopitemscount:"+String.valueOf(vshopId));
					// 封装推送数据平台的数据
					JSONObject data = new JSONObject();
					data.put("vshopId", vshopId);
					data.put("itemId", itemId);
					data.put("status", 0);
					data.put("createTime", new Date().getTime());
					// 发布美店商品下架信息
					DeleteVshopItemEvent event = new DeleteVshopItemEvent(vshopProductadd.getVshopId());
					event.setData(data);
					coreEventDispatcher.publish(event);
				}
			}
		}
	}*/

	/**
	 * @Description 查找所有的上架店铺数量
	 * @author suliangyi
	 * @date 2015年12月25日 上午10:55:10
	 */
	public void findAllOnItemCount() {
		List<VshopOnItemCount> allShopList = vshopOnItemCountDao.queryAllShopList();
		for (VshopOnItemCount shopOnCount : allShopList) {
			// 将所有微店的商品数量重置为0
			vshopCache.set("shop:shopitemscount:"+shopOnCount.getShopId(),"0" );
			log.debug("shopId is {},itemNum is {}", shopOnCount.getShopId(), 0);
		}
		List<VshopOnItemCount> list = vshopOnItemCountDao.queryOnItemCount();
		for (VshopOnItemCount shopOnCount : list) {
			// 将所有微店的上架商品数量set进redis
			vshopCache.set("shop:shopitemscount:"+ shopOnCount.getShopId(),""+shopOnCount.getCount());
			log.debug("shopId is {},itemNum is {}", shopOnCount.getShopId(), shopOnCount.getCount());
		}
	}

	public Integer queryDistributionItemCountCount(long vshopId) {
		return vshopDistributionItemDao.queryDistributionItemCountCount(vshopId);
	}

	// 610编号api暂时性数据填充
	public List<VshopDistributionItem> queryListProductByCriteria(PageParam pageParam, Map<String, Object> criteria) {
		return vshopDistributionItemDao.queryListProductByCriteria(pageParam, criteria);
	}

	public Integer queryItemQuantityByCriteria(Map<String, Object> criteria) {
		return vshopDistributionItemDao.queryItemQuantityByCriteria(criteria);
	}

	public List<VshopDistributionItem> queryItemsInMShop(PageParam pageParam) {
		return vshopDistributionItemDao.queryItemsInMShop(pageParam);
	}

	public void sendMQ(long vshopId, String itemId, Integer status,long categoryId, long id, long popId,String skuId,Date onShelfAt,String identification) {
		VshopInfo vshopInfo = vshopInfoBiz.queryVshopById(vshopId);
		JSONObject jo = new JSONObject();
		jo.put("id", id);
		jo.put("mshopId", vshopId);
		jo.put("itemId", itemId);
		jo.put("status", status);
		jo.put("pshopId", popId);
		jo.put("categoryId", categoryId);
		jo.put("userId", vshopInfo.getUserId());
		jo.put("skuId", skuId);
		jo.put("onShelfAt", onShelfAt.getTime());
		jo.put("identification",identification);
		long curTime = new Date().getTime();
		jo.put("sendTime", curTime);
		jo.put("currentDate", curTime);
		mqPushProducer.send(jo.toJSONString(), "TagPlusProduct",itemId);
	}

	/**
	 * 推送分销商品MQ
	 * 
	 * @param vshopId
	 * @param itemId
	 * @param status
	 * @param id
	 * @param popId
	 * @param currentDate
	 */
	public void sendDistributionItemsMQ(long vshopId, String itemId, Integer status, long id, long popId, long currentDate,long categoryId) {
		VshopInfo vshopInfo = vshopInfoBiz.queryVshopById(vshopId);
		VshopDistributionItem vshopDistributionItem = vshopDistributionItemDao.queryProductByProductId(itemId, null, vshopId);
		Long onShelfAt = null;
		String skuId = null;
		JSONObject jo = new JSONObject();
		if(vshopDistributionItem != null){
			onShelfAt = vshopDistributionItem.getCreateTime().getTime();
			skuId = vshopDistributionItem.getSkuId();
			jo.put("identification",vshopDistributionItem.getIdentification());
		} else {
		    jo.put("identification","online");
		}
		jo.put("id", id);
		jo.put("mshopId", vshopId);
		jo.put("itemId", itemId);
		jo.put("status", status);
		jo.put("pshopId", popId);
		jo.put("categoryId", categoryId);
		jo.put("userId", vshopInfo.getUserId());
		jo.put("sendTime", new Date().getTime());
		if (currentDate == 0) {
		    currentDate = new Date().getTime();
		}
		jo.put("currentDate", currentDate);
		jo.put("skuId", skuId);
		jo.put("onShelfAt", onShelfAt);
		mqPushProducer.send(jo.toJSONString(), "TagPlusProduct",itemId);
	}

	/**
	 * 
	 * @Description: 修改商品indentification 标示
	 * @author: zhaoxingxing
	 * @date: 2017年3月9日 下午3:17:26
	 * @param vshopId
	 */
	@Transactional
	public void updateProductIdentificationByVshopId(Long vshopId) {
		vshopInfoBiz.updateVshopNameByVshopId(vshopId);
		vshopDistributionItemDao.updateProductIdentificationByVshopId(vshopId);
	}
	
	/**
	 * 
	 * @Description: 分表后MQ推送的全表处理
	 * @author: guowenbo
	 * @date: 2017年5月12日 下午3:17:26
	 */
	public void updateRedisAndAllDateForMQ(String popId,String itemId) {
		String baseTableName="vshop_distribution_item_vshopid";
		List<VshopDistributionItem> productList = null;
		Map<String, Object> map = new HashMap<String, Object>();
		if(StringUtils.isNotBlank(popId)){
			map.put("popId", "'"+popId+"'");
		}
		if(StringUtils.isNotBlank(itemId)){
		    map.put("itemId", "'"+itemId+"'");
		}
		map.put("status", ProductStatusEnum.XIAJIA.getValue());
		for (int i = 0; i < 128; i++) {
			String tableName= baseTableName+"_"+i;
			map.put("tableName", tableName);
			try {
				productList = vshopDistributionItemDao.queryListProductByMQ(map);
			} catch (Exception e) {
				log.error("MQ queryListProductByMQ Error! param:'{}' e: ", map.toString(),e);
			}
			try {
				vshopDistributionItemDao.updateProductByMQ(map);
			} catch (Exception e) {
				log.error("MQ updateProductByMQ Error! param:'{}' e: ", map.toString(),e);
			}
			if (!productList.isEmpty()) {
				for (VshopDistributionItem shopDistributionItem : productList) {
					vshopCache.decr("shop:shopitemscount:"+shopDistributionItem.getVshopId());
				}
			}
		}
	}

	public void createDistributionItems(final List<VshopDistributionItem> list) {  
		for(final VshopDistributionItem item:list){
				pool.execute(new Runnable() {
					@Override
					public void run() {
						try{
							vshopDistributionItemDao.insert(item);
							vshopCache.incr("shop:shopitemscount:"+item.getVshopId());
							
							// 发布美店商品上架信息
							// 封装推送数据平台的数据
							CreateVshopItemEvent event = new CreateVshopItemEvent(item.getVshopId());
							Map<String, Object> data = new HashMap<String, Object>();
							data.put("vshopId", item.getVshopId());
							data.put("itemId", item.getItemId());
							data.put("status", item.getStatus());
							data.put("createTime", new Date().getTime());
							event.setData(data);
							coreEventDispatcher.publish(event);
							
							VshopInfo vshopInfo = vshopInfoBiz.queryVshopById(item.getVshopId());
							JSONObject jo = new JSONObject();
							jo.put("id", item.getId());
							jo.put("mshopId", item.getVshopId());
							jo.put("itemId", item.getItemId());
							jo.put("status", item.getStatus());
							jo.put("pshopId", 0);
							jo.put("categoryId", item.getVcategoryId());
							jo.put("userId", vshopInfo.getUserId());
							jo.put("skuId", item.getSkuId());
							jo.put("identification",item.getIdentification());
							jo.put("onShelfAt", new Date().getTime());
							long curTime = new Date().getTime();
							jo.put("sendTime", curTime);
							jo.put("currentDate", curTime);
							mqPushProducer.send(jo.toJSONString(), "TagPlusProduct",item.getItemId());
						}catch(Exception e){
							log.error("createDistributionItems error,shopId is [{}],itemId is [{}], Exception is : ", item.getVshopId(),item.getItemId(),e);
						}
					}
				});
		}
	}

	public List<String> queryListProducts(Map<String, Object> idsMap) {
		List<String> list = new ArrayList<String>();
		List<VshopDistributionItem> items = vshopDistributionItemDao.queryListProducts(idsMap);
		for(VshopDistributionItem item:items){
			list.add(item.getItemId());
		}
		return list;
	}
}
