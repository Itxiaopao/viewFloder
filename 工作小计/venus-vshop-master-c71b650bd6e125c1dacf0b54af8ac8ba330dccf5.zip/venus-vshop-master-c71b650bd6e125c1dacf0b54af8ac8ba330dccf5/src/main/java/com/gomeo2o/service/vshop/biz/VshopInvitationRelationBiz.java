package com.gomeo2o.service.vshop.biz;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopInfoDao;
import com.gomeo2o.service.vshop.dao.VshopInvitationRelationDao;

@Service("name=vshopInvitationRelationBiz")
public class VshopInvitationRelationBiz {
	
	@Autowired
	private VshopInvitationRelationDao vshopInvitationRelationDao;
	
	@Autowired
	private VshopInfoDao vshopInfoDao;

	public Long createVshopInvitationRelation(VshopInvitationRelation vshopInvitationRelation) {
		
		VshopInfo vshopInfo = vshopInfoDao.getById(vshopInvitationRelation.getInviterVshopId());
		if(vshopInfo == null){
			throw VshopException.VSHOP_EXIST;
		}
		vshopInvitationRelation.setInviterUserId(vshopInfo.getUserId());
		return vshopInvitationRelationDao.insert(vshopInvitationRelation);
	}

	public List<VshopInvitationRelation> getVshopInvitationRelation(PageParam pageParam,Map<String, Object> map) {
		
		return vshopInvitationRelationDao.getVshopInvitationRelation(pageParam,map);
	}

	public Integer countVshopInvitationRelation(Map<String, Object> map) {
		
		return vshopInvitationRelationDao.countVshopInvitationRelation(map);
	}

	public VshopInvitationRelation getInvitationRelationByReceiverUserId(Long userId) {
		return vshopInvitationRelationDao.getInvitationRelationByReceiverUserId(userId);
	}

}
