/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: AbstractIdEvent.java 
 * @Prject: venus-user
 * @Package: cn.com.gome.user.event.common 
 * @Description: id事件抽象类
 * @author: sunyizhong   
 * @date: 2016年11月23日 下午1:40:19 
 * @version: V1.0   
 */
package com.gomeo2o.event.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @ClassName: AbstractIdEvent
 * @Description: id事件抽象类
 * @author: sunyizhong
 * @date: 2016年11月23日 下午1:40:38
 * @param <T>
 */
public abstract class AbstractIdEvent<T> implements IdEvent {

	@Getter
	@Setter
	private T data; // 事件携带数据

	private Long id;

	public AbstractIdEvent(Long id) {
		this.id = id;
	}

	@Override
	public Long id() {
		return id;
	}

}
