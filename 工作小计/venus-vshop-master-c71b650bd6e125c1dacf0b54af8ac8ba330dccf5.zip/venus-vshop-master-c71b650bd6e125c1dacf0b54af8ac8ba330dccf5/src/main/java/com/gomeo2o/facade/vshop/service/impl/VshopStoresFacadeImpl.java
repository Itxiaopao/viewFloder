package com.gomeo2o.facade.vshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopStores;
import com.gomeo2o.facade.vshop.service.VshopStoresFacade;
import com.gomeo2o.service.vshop.biz.VshopStoresBiz;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopStoresFacade")
public class VshopStoresFacadeImpl implements VshopStoresFacade {
    @Autowired
    private VshopStoresBiz vshopStoresBiz;

    @Override
    public CommonResultEntity<VshopStores> queryVshopStoresById(Long vshopId) {
        CommonResultEntity<VshopStores> cre = new CommonResultEntity<>();
        VshopStores vshopStores = vshopStoresBiz.queryVshopStoresById(vshopId);
        cre.setBusinessObj(vshopStores);
        return cre;
    }

    @Override
    public CommonResultEntity<String> insertOrUpdateVshopStoresById(VshopStores vshopStores) {
        CommonResultEntity<String> cre = new CommonResultEntity<>();
        //insert操作返回id
        String id = vshopStoresBiz.insertOrUpdateVshopStores(vshopStores);
        cre.setBusinessObj(id);
        return cre;
    }
}
