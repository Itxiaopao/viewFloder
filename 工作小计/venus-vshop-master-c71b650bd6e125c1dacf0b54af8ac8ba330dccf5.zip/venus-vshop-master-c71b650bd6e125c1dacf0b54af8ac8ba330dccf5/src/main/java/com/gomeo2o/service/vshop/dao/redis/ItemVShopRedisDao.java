package com.gomeo2o.service.vshop.dao.redis;/*
package com.gomeo2o.service.vshop.dao.redis;

import com.gomeo2o.common.cache.dao.CacheCountDaoImpl;
import com.gomeo2o.common.redis.SimpleJedisTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Slf4j
@Repository
public class ItemVShopRedisDao extends CacheCountDaoImpl {

    @Autowired
    private SimpleJedisTemplate  simpleJedisTemplate;

    @Override
    public long incr(String project, String business, String id,
                     String... cases) {
        long count = 0l;
        try {
            count = super.incr(project, business, id, cases);
            log.info("vshop key is {}:{}:{} has increased!", project, business, id);
            log.debug("vshop the count  is {}", count);
        } catch (Exception e) {
            log.error("vshop {}:{}:{} incr happen  exception: ", project, business, id, e);
            return count;
        }
        return count;
    }

    @Override
    public long decr(String project, String business, String id,
                     String... cases) {
        long count = 0l;
        try {
            count = super.decr(project, business, id, cases);
            log.info("vshop key is {}:{}:{} has decreased!", project, business, id);
            log.debug("vshop the count  is {}", count);
        } catch (Exception e) {
            log.error("vshop id is {}:{}:{} decr happen  exception: ", project, business, id, e);
            return count;
        }
        return count;
    }


    @Override
    public long get(String project, String business, String id, String... cases) {
        long count = 0l;
        try {
            count = super.get(project, business, id, cases);
            log.info("vshop id is {}:{}:{} has getted!", project, business, id);
        } catch (Exception e) {
            log.error("vshop id is {}:{}:{} get happen  exception: ", project, business, id, e);
            return count;
        }
        return count;
    }


    @Override
    public String set(long value, String project, String business, String id,
                      String... cases) {
        String result = "FAIL";
        try {
            result = super.set(value, project, business, id, cases);
            log.info("vshop id is {}:{}:{} has setted!", project, business, id);
        } catch (Exception e) {
            log.error("vshop id is {}:{}:{} set happen  exception: ", project, business, id, e);
            return result;
        }
        return result;

    }

}
*/
