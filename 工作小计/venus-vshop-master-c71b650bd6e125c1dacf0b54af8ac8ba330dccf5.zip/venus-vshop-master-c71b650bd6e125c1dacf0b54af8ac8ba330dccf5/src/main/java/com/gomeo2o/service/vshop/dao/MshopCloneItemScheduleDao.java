package com.gomeo2o.service.vshop.dao;

import java.util.List;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.MshopCloneItemSchedule;

public interface MshopCloneItemScheduleDao extends BaseDao<MshopCloneItemSchedule> {

	public List<MshopCloneItemSchedule> queryMshopCloneItemScheduleById(long originMshopId,long targetMshopId);
}
