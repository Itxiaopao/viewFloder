package com.gomeo2o.service.vshop.biz;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopVipInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipMshopIdSimpleInfo;
import com.gomeo2o.service.vshop.dao.VshopVipInfoDao;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopVipInfoBiz")
public class VshopVipInfoBiz {

    @Autowired
    private VshopVipInfoDao shopVipInfoDao;


    public VshopVipInfo getVshopVipInfoByUserId(Long userId) {
        return shopVipInfoDao.getVshopVipInfoByUserId(userId);
    }


    public List<VshopVipInfo> adminPageQueryVipInfo(PageParam pageParam, Map<String, Object> map){
        map.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
        map.put("pageSize", pageParam.getNumPerPage());
        return shopVipInfoDao.adminPageQueryVipInfo(map);
    }

    public Long adminPageQueryVipInfoCount(Map<String, Object> map){
        return Long.valueOf(shopVipInfoDao.adminPageQueryVipInfoCount(map).toString());
    }

    /**
     * 查询所有vip mid userId关系
     * @return
     */
    public List<VshopVipMshopIdSimpleInfo> queryAllVipMshopIdInfoList() {
        return  shopVipInfoDao.queryAllVipMshopIdInfoList();
    }
}
