package com.gomeo2o.facade.vshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfoLabel;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoLabelFacade;
import com.gomeo2o.service.vshop.biz.VshopInfoLabelBiz;
import com.gomeo2o.utils.CodeUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopInfoLabelFacade")
public class VshopInfoLabelFacadeImpl implements VshopInfoLabelFacade {
    @Autowired
    private VshopInfoLabelBiz vshopInfoLabelBiz;
    @Autowired
    private VshopFacade vshopFacade;
    @Override
    public CommonResultEntity<VshopInfoLabel> queryVshopInfoLabelByUserId(Long userId,Integer type) {
        if(null == userId || userId.equals(0L)){
            log.error("查询百货店主标签,入参userId为空");
            throw VshopException.PARAM_IS_NULL;
        }
        CommonResultEntity<VshopInfoLabel> resultEntity = new CommonResultEntity<>();
        try {
            resultEntity.setBusinessObj(vshopInfoLabelBiz.queryVshopInfoLabelByUserId(userId,type));
        }catch (Exception e){
            log.error("VshopInfoLabelFacadeImpl.queryVshopInfoLabelByUserId Exception",e);
        }
        return resultEntity;
    }

    @Override
    public CommonResultEntity<String> createVshopInfoLabel(VshopInfoLabel vshopInfoLabel) {
        CommonResultEntity<String> commonResultEntity = new CommonResultEntity<String>();
        try {
            if (null == vshopInfoLabel || null == vshopInfoLabel.getUserId() || vshopInfoLabel.getUserId().equals(0L)) {
                log.error("查询百货店主标签,入参userId为空");
                throw VshopException.PARAM_IS_NULL;
            }
            CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(vshopInfoLabel.getUserId().toString());
            if (null == vshopInfoCommonResultEntity || vshopInfoCommonResultEntity.getBusinessObj() == null) {
                log.error("查询该userId不是店主");
                throw VshopException.VSHOP_EXIST;
            }
            VshopInfoLabel rtn = vshopInfoLabelBiz.queryVshopInfoLabelByUserId(vshopInfoLabel.getUserId(), vshopInfoLabel.getUserType());
            if (null != rtn) {
                commonResultEntity.setBusinessObj("当前百货店主已存在");
                return commonResultEntity;
            }
            int i = vshopInfoLabelBiz.insertVshopInfoLabel(vshopInfoLabel);
            if (i == 1) {
                commonResultEntity.setBusinessObj("SUCCESS");
            } else {
                commonResultEntity.setCode(CodeUtil.EXCEPTION);
                commonResultEntity.setMessage(CodeUtil.EXCEPTION_MSG);
                commonResultEntity.setBusinessObj("ERROR");
            }
        }catch (Exception e){
            commonResultEntity.setCode(CodeUtil.EXCEPTION);
            commonResultEntity.setMessage(CodeUtil.EXCEPTION_MSG);
            commonResultEntity.setBusinessObj("ERROR");
            log.error("VshopInfoLabelFacadeImpl.createVshopInfoLabel Exception",e);
        }
        return commonResultEntity;
    }

    @Override
    public CommonResultEntity<String> updateVshopInfoLabel(VshopInfoLabel vshopInfoLabel) {
        CommonResultEntity<String> commonResultEntity = new CommonResultEntity<String>();
        if(null == vshopInfoLabel || null == vshopInfoLabel.getUserId() || vshopInfoLabel.getUserId().equals(0L)){
            log.error("查询百货店主标签,入参userId为空");
            throw VshopException.PARAM_IS_NULL;
        }
        VshopInfoLabel rtn = vshopInfoLabelBiz.queryVshopInfoLabelByUserId(vshopInfoLabel.getUserId(),vshopInfoLabel.getUserType());
        if(null == rtn){
            commonResultEntity.setBusinessObj("当前百货店主不存在，无法更新");
            return commonResultEntity;
        }
        vshopInfoLabel.setVersion(rtn.getVersion());
        vshopInfoLabel.setId(rtn.getId());
        int i = vshopInfoLabelBiz.updateVshopInfoLabel(vshopInfoLabel);
        if(i == 1){
            commonResultEntity.setBusinessObj("SUCCESS");
        }else{
            commonResultEntity.setCode(CodeUtil.EXCEPTION);
            commonResultEntity.setMessage(CodeUtil.EXCEPTION_MSG);
            commonResultEntity.setBusinessObj("ERROR");
        }
        return commonResultEntity;
    }
}
