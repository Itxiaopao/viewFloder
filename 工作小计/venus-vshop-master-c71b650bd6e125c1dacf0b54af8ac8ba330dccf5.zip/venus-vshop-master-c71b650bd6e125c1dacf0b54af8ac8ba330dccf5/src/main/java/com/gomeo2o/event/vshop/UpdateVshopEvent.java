/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: UpdateVshopEvent.java 
 * @Prject: venus-vshop
 * @Package: com.gomeo2o.event.vshop 
 * @Description: 更新美店事件
 * @author: sunyizhong   
 * @date: 2016年11月24日 下午2:58:29 
 * @version: V1.0   
 */
package com.gomeo2o.event.vshop;

import java.util.Map;

import com.gomeo2o.event.common.AbstractIdEvent;

/**
 * 
 * @ClassName: UpdateVshopEvent
 * @Description: 更新美店事件
 * @author: sunyizhong
 * @date: 2016年11月24日 下午2:59:56
 */
public class UpdateVshopEvent extends AbstractIdEvent<Map<String, Object>> {

	public UpdateVshopEvent(Long id) {
		super(id);
	}

}
