package com.gomeo2o.service.vshop.biz;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.gome.framework.base.ResultDTO;
import com.gome.pangu.redcoupon.dubbo.model.CreateRuleRedCouponParam;
import com.gome.pangu.redcoupon.dubbo.model.ResultDO;
import com.gome.pangu.redcoupon.dubbo.service.RedCouponRuleService;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gome.promotion.handle.client.service.QueryGomePromService;
import com.gomeo2o.facade.vshop.dto.InvitationVipDto;
import com.gomeo2o.facade.vshop.dto.VipCouponRegularDto;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeo2o.facade.vshop.entity.VshopVipCouponProject;
import com.gomeo2o.facade.vshop.entity.VshopVipCouponRecord;
import com.gomeo2o.facade.vshop.entity.VshopVipInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipInfoRecord;
import com.gomeo2o.facade.vshop.entity.VshopVipRelationship;
import com.gomeo2o.facade.vshop.entity.VshopVipTeamMemberInfo;
import com.gomeo2o.facade.vshop.enums.VipIdentityEnum;
import com.gomeo2o.facade.vshop.enums.VshopStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopTypeEnum;
import com.gomeo2o.facade.vshop.enums.VshopVipInfoRecordEnum;
import com.gomeo2o.mq.MQPushRebateProducer;
import com.gomeo2o.service.vshop.dao.VshopInvitationRelationDao;
import com.gomeo2o.service.vshop.dao.VshopVipCouponProjectDao;
import com.gomeo2o.service.vshop.dao.VshopVipCouponRecordDao;
import com.gomeo2o.service.vshop.dao.VshopVipInfoDao;
import com.gomeo2o.service.vshop.dao.VshopVipInfoRecordDao;
import com.gomeo2o.service.vshop.dao.VshopVipRelationshipDao;
import com.gomeo2o.service.vshop.dao.VshopVipTeamMemberInfoDao;
import com.gomeo2o.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
@Slf4j
@Service("name=vipBiz")
public class VipBiz {
	@Autowired
	private VshopVipInfoDao vshopVipInfoDao;
	
	@Autowired
	private VshopVipTeamMemberInfoDao vshopVipTeamMemberInfoDao;

	@Autowired
	private VshopInfoBiz vshopInfoBiz;

	@Autowired
	private VshopInvitationRelationDao vshopInvitationRelationDao;

	@Autowired
	private VshopVipRelationshipDao vshopVipRelationshipDao;

	@Autowired
	private VshopVipCouponRecordDao vshopVipCouponRecordDao;

	@Autowired
	private VshopVipTeamMemberInfoBiz vshopVipTeamMemberInfoBiz;

	@Autowired
    private MQPushRebateProducer mqPushRebateProducer;

	@Autowired
	private VshopVipCouponProjectDao vshopVipCouponProjectDao;

	@Autowired
	private RedCouponRuleService redCouponRuleService;

	@Autowired
	private QueryGomePromService queryGomePromService;

	@Autowired
	private VshopVipInfoRecordDao vshopVipInfoRecordDao;


	public void updateVip(VshopVipInfo vshopVipInfo) {
		vshopVipInfoDao.update(vshopVipInfo);
	}

	public VshopVipInfo queryVshopVipInfoByUserId(Long userId) {
		//查出导师的userId
		Long tutorUserIdByMemberUserId = vshopVipTeamMemberInfoDao.queryTutorUserIdByMemberUserId(userId);
		//查询微信号等信息
		VshopVipInfo vshopVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(tutorUserIdByMemberUserId);
		if(null == vshopVipInfo){
			String vx = "meidiandabai";
			VshopVipInfo vshopVipInfos = new VshopVipInfo();
			vshopVipInfos.setQrNo(vx);
			return vshopVipInfos;
		}
		return vshopVipInfo;
	}

	/**
	 * 根据用户ID获取vip信息
	 * @param userId
	 * @return
	 */
	public VshopVipInfo getVipInfoByUserId(Long userId){

		return vshopVipInfoDao.getVshopVipInfoByUserId(userId);
	}

    public void createVip(VshopVipInfo vshopVipInfo) {
		vshopVipInfoDao.insert(vshopVipInfo);
    }


    @Transactional
	public VshopVipInfo invitationOpenVip(InvitationVipDto invitationVipDto) {
        //支付开通vip的用户id
		Long userId = invitationVipDto.getUserId();
		Long vshopId;
		//邀请人的用户id
		Long invitationUserId = invitationVipDto.getInvitationUserId();
		//订单创建时间
		Date orderTime = invitationVipDto.getOrderTime();
		//订单号
		String orderNo = invitationVipDto.getOrderNo();
		log.info("invitationOpenVip start ---> userId:[{}],invitationUserId:[{}],orderTime:[{}],orderNo:[{}]",userId,invitationUserId,orderTime.getTime(),orderNo);
		VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);
		if(vshopInfo == null ){
			//没店铺创建默认店铺
			VshopInfo vi = new VshopInfo();
			vi.setUserId(userId);
			vi.setVshopStatus(VshopStatusEnum.JINGYING.getValue());
			vi.setVshopType(VshopTypeEnum.MEIDIAN.getValue());
			vi.setVshopIcon("http://gfs10.gomein.net.cn/T1YFxTByJT1R4cSCrK.png");
			vi.setVshopName("我的小店");
			vshopId = vshopInfoBiz.createVshop(vi);
			//TODO 自动加入圈子?
		}else{
			vshopId = vshopInfo.getVshopId();
		}
		//校验店铺vip记录
		VshopVipInfo isExistVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(userId);
		if(isExistVipInfo != null && "Y".equals(isExistVipInfo.getIsEffective())){
			return isExistVipInfo;
		}
		//创建vip记录
		VshopVipInfo vshopVipInfo = new VshopVipInfo();
		vshopVipInfo.setUserId(userId);
		vshopVipInfo.setIdentity(VipIdentityEnum.VIP.name());
		vshopVipInfo.setOrderNo(orderNo);
		vshopVipInfo.setStartEffectiveTime(orderTime);
		vshopVipInfo.setIsEffective("Y");
		vshopVipInfo.setIsPermanent("N");
		vshopVipInfo.setSource(1);
		Calendar c = Calendar.getInstance();
		c.setTime(orderTime);//当前日期
		c.add(Calendar.YEAR,1);//加一年
		Date oneyearlater= c.getTime();
		vshopVipInfo.setEndEffectiveTime(oneyearlater);
		if(isExistVipInfo == null){
			vshopVipInfoDao.insert(vshopVipInfo);
		}else{
			vshopVipInfoDao.update(vshopVipInfo);
		}

		//创建vip履历
		VshopVipInfoRecord vvir = new VshopVipInfoRecord();
		vvir.setUserId(userId);
		vvir.setRemark(VshopVipInfoRecordEnum.OPEN_VIP.getDesc());
		vvir.setOrderNo(orderNo);
		vvir.setStartEffectiveTime(orderTime);
		vvir.setEndEffectiveTime(oneyearlater);
		vshopVipInfoRecordDao.insert(vvir);


		VshopVipInfo resultVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(userId);
		//没有推荐人直接返回
		if(invitationUserId == null){
			//结束
			return resultVipInfo;
		}

		//通过邀请人id查询邀请人身份（normal vip svip)
		String invitationUserType = "";
		VshopVipInfo invitationVshopVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(invitationUserId);
		VshopInfo invitationVshopInfo = vshopInfoBiz.queryVshopByuserId(invitationUserId);
		Long invatationShopId = null;
		if(invitationVshopInfo!=null){
			invatationShopId = invitationVshopInfo.getVshopId();
		}
		if(invitationVshopVipInfo == null || "N".equals(invitationVshopVipInfo.getIsEffective())){
			invitationUserType = "NORMAL";
		}else{
			invitationUserType = invitationVshopVipInfo.getIdentity();
		}
		if("NORMAL".equals(invitationUserType)){
			//创建普通美店邀请关系记录

			VshopInvitationRelation vir = new VshopInvitationRelation();
			vir.setInviterUserId(invitationUserId);
			vir.setReceiverUserId(userId);
			vir.setInviterVshopId(invatationShopId);
			vir.setReceiverVshopId(vshopId);
			vshopInvitationRelationDao.insert(vir);
		}else{
			//创建邀请关系记录
			VshopVipRelationship vvr = new VshopVipRelationship();
			vvr.setInvitedUserId(userId);
			vvr.setInviterUserId(invitationUserId);
			vvr.setInviteTime(orderTime);
			vvr.setIsEffective("Y");
			vvr.setSource(1);
			vshopVipRelationshipDao.insert(vvr);


			Long tutorUserId = null;
			Long tutorShopId = null;
			if (VipIdentityEnum.VIP.name().equals(invitationUserType)){
				//判断invitationUserId邀请数量
				/*Integer count = vshopVipRelationshipDao.countVshopVipRelationshipByInviterUserId(invitationUserId, "1");
				if(count >= getInvitationCount()){
					//TODO 推送开通Svip消息
				}*/

				//判断invitationUserId有没有团队，有则创建团队信息记录
				tutorUserId = vshopVipTeamMemberInfoBiz.queryTutorUserIdByMemberUserId(invitationUserId);
				if(tutorUserId != null){
				    VshopInfo tutorVshopInfo = vshopInfoBiz.queryVshopByuserId(tutorUserId);
				    if (tutorVshopInfo != null) {
				        tutorShopId = tutorVshopInfo.getVshopId();
				    }
					//TODO 续费重新开通vip暂不考虑加入新团队
					if(isExistVipInfo == null){
						VshopVipTeamMemberInfo vvtmi = new VshopVipTeamMemberInfo();
						vvtmi.setMemberUserId(userId);
						vvtmi.setTutorUserId(tutorUserId);
						//间接邀请
						vvtmi.setSource(2);
						vshopVipTeamMemberInfoBiz.createVshopVipTeamMemberInfo(vvtmi);
					}
					//创建导师间接邀请关系记录
					VshopVipRelationship vvrTutor = new VshopVipRelationship();
					vvrTutor.setInvitedUserId(userId);
					vvrTutor.setInviterUserId(tutorUserId);
					vvrTutor.setSource(2);
					vvrTutor.setIsEffective("Y");
					vvrTutor.setInviteTime(orderTime);
					vshopVipRelationshipDao.insert(vvrTutor);
				}
			}else if (VipIdentityEnum.SVIP.name().equals(invitationUserType)){
				//TODO 续费重新开通vip暂不考虑加入新团队
				if(isExistVipInfo == null){
					tutorUserId = invitationUserId;
					tutorShopId = invatationShopId;
					//创建加入团队信息记录
					VshopVipTeamMemberInfo vvtmi = new VshopVipTeamMemberInfo();
					vvtmi.setMemberUserId(userId);
					vvtmi.setTutorUserId(invitationUserId);
					vshopVipTeamMemberInfoBiz.createVshopVipTeamMemberInfo(vvtmi);
				}
			}

			mqPushRebateProducer.mqDataStored(userId,invitationUserId,invatationShopId,tutorUserId,tutorShopId,orderTime.getTime(),orderNo);
		}
		return resultVipInfo;
	}

	@Transactional
	public VshopVipInfo renewVip(VshopVipInfo vvi,InvitationVipDto invitationVipDto) {
		//支付开通vip的用户id
		Long userId = invitationVipDto.getUserId();
		//邀请人的用户id
		Long invitationUserId = invitationVipDto.getInvitationUserId();
		//订单创建时间
		Date orderTime = invitationVipDto.getOrderTime();
		//订单号
		String orderNo = invitationVipDto.getOrderNo();

		//目前过期时间
		Date endEffectiveTime = vvi.getEndEffectiveTime();
		log.info("renewVip start ---> userId:[{}],invitationUserId:[{}],orderTime:[{}],orderNo:[{}]",userId,invitationUserId,orderTime.getTime(),orderNo);

		//创建vip记录
		VshopVipInfo vshopVipInfo = new VshopVipInfo();
		vshopVipInfo.setUserId(userId);
		vshopVipInfo.setOrderNo(orderNo);
		vshopVipInfo.setSource(1);
		Calendar c = Calendar.getInstance();
		c.setTime(endEffectiveTime);//当前日期
		c.add(Calendar.YEAR,1);//加一年
		Date oneyearlater= c.getTime();
		vshopVipInfo.setEndEffectiveTime(oneyearlater);
		vshopVipInfoDao.update(vshopVipInfo);

		//创建vip履历
		VshopVipInfoRecord vvir = new VshopVipInfoRecord();
		vvir.setUserId(userId);
		vvir.setRemark(VshopVipInfoRecordEnum.REOPEN_VIP.getDesc());
		vvir.setOrderNo(orderNo);
		vvir.setStartEffectiveTime(endEffectiveTime);
		vvir.setEndEffectiveTime(oneyearlater);
		vshopVipInfoRecordDao.insert(vvir);

		VshopVipInfo resultVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(userId);
		//没有推荐人直接返回
		if(invitationUserId == null){
			//结束
			return resultVipInfo;
		}

		//通过邀请人id查询邀请人身份（normal vip svip)
		String invitationUserType = "";
		VshopVipInfo invitationVshopVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(invitationUserId);
		if(invitationVshopVipInfo == null || "N".equals(invitationVshopVipInfo.getIsEffective())){
			invitationUserType = "NORMAL";
		}else{
			invitationUserType = invitationVshopVipInfo.getIdentity();
		}

		//记录新的邀请关系不变动之前的所有关系
		if("NORMAL".equals(invitationUserType)){
			//创建普通美店邀请关系记录
			VshopInfo invitationVshopInfo = vshopInfoBiz.queryVshopByuserId(invitationUserId);
			VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);
			VshopInvitationRelation vir = new VshopInvitationRelation();
			vir.setInviterUserId(invitationUserId);
			vir.setReceiverUserId(userId);
			if(invitationVshopInfo != null){
				vir.setInviterVshopId(invitationVshopInfo.getVshopId());
			}
			if(vshopInfo != null){
				vir.setReceiverVshopId(vshopInfo.getVshopId());
			}
			vshopInvitationRelationDao.insert(vir);
		}else{
			//创建邀请关系记录
			VshopVipRelationship vvr = new VshopVipRelationship();
			vvr.setInvitedUserId(userId);
			vvr.setInviterUserId(invitationUserId);
			vvr.setInviteTime(orderTime);
			vvr.setIsEffective("Y");
			vvr.setSource(1);
			vshopVipRelationshipDao.insert(vvr);

			if (VipIdentityEnum.VIP.name().equals(invitationUserType)){
				//判断invitationUserId邀请数量
				/*Integer count = vshopVipRelationshipDao.countVshopVipRelationshipByInviterUserId(invitationUserId, "1");
				if(count >= getInvitationCount()){
					//TODO 推送开通Svip消息
				}*/
			}
		}
		return resultVipInfo;
	}

	public void sendCoupon(Long userId, String orderNo) {
		//查询当前生效的优惠券方案
		List<VshopVipCouponProject> vshopVipCouponProjectList = vshopVipCouponProjectDao.queryEffectiveVipCouponProject();
		VshopVipCouponProject vshopVipCouponProject = vshopVipCouponProjectList.get(0);
		VshopVipCouponRecord vvcr = new VshopVipCouponRecord();
		vvcr.setUserId(userId);
		if(vshopVipCouponProject==null){
			vvcr.setProjectId("-1");
			vvcr.setStatus(2);
			vvcr.setRemark("当前无生效的优惠券方案");
		}else if(vshopVipCouponProject.getGiftStockCount()<=0){
			vvcr.setProjectId(String.valueOf(vshopVipCouponProject.getId()));
			vvcr.setStatus(2);
			vvcr.setRemark("当前优惠券方案礼包剩余数量为0");
		}else{
			//调用发放优惠券接口
			vvcr.setProjectId(String.valueOf(vshopVipCouponProject.getId()));
			String regularContent = vshopVipCouponProject.getRegularContent();
			if(StringUtils.isBlank(regularContent) || JsonUtils.toList(regularContent, new VipCouponRegularDto()).size() <= 0){
				vvcr.setStatus(2);
				vvcr.setRemark("当前优惠券方案无红券ID");
				//创建优惠券信息记录
				vshopVipCouponRecordDao.insert(vvcr);
				//退出
				return;
			}
			List<VipCouponRegularDto> vipCouponRegularDtos = JsonUtils.toList(regularContent, new VipCouponRegularDto());
			List<CreateRuleRedCouponParam> list = new ArrayList<>();
			CreateRuleRedCouponParam crrp;
			Boolean flag = true;
			for (VipCouponRegularDto dto : vipCouponRegularDtos) {
				//发放券数量
				Integer count = dto.getCount();
				if(count!=null){
					//校验券规则有效性
					try {
						ResultDTO<CouponRuleInfo> couponRuleInfoByRuleId = queryGomePromService.getCouponRuleInfoByRuleId(dto.getRegularId());
						Boolean aBoolean = checkCouponValiteDate(couponRuleInfoByRuleId.getData().getCouponEndDate());
						if(!aBoolean){
							flag = false;
							log.error("this RegularId invalid! RegularId:[{}]",dto.getRegularId());
							break;
						}
					}catch (Exception e){
						log.error("queryGomePromService.getCouponRuleInfoByRuleId dubbo error! regularId:[{}]",dto.getRegularId(),e);
					}
					for (int i = 0; i < count; i++) {
						crrp = new CreateRuleRedCouponParam();
						//返券订单号
						crrp.setOrigOrderId(orderNo);
						//方案id
						crrp.setPromotionId(String.valueOf(vshopVipCouponProject.getId()));
						//生成原因：1004
						crrp.setGenerateReason(1004);
						//预算号
						crrp.setBudgetNo(vshopVipCouponProject.getBudgetNumber());
						//券履历备注，强制必填(付费美店)
						crrp.setHistoryRemark("付费美店");
						//操作类型，强制必填(1004)
						crrp.setHistoryOperateType(1004);
						//FALSE
						crrp.setSpecial(Boolean.FALSE);
						//券规则id
						crrp.setPromotionRule(dto.getRegularId());
						list.add(crrp);
					}
				}
			}

			if(!flag){
				vvcr.setStatus(2);
				vvcr.setRemark("当前优惠券方案内包含已经过期的券规则");
				//创建优惠券信息记录
				vshopVipCouponRecordDao.insert(vvcr);
				return;
			}
			ResultDO<List<String>> result = null;
			try {
				result = redCouponRuleService.createMultiRedCouponActivatedForRule(String.valueOf(userId), UUID.randomUUID().toString(), String.valueOf(userId), list);
			}catch (Exception e){
				vvcr.setStatus(2);
				vvcr.setRemark("调用优惠券异常！");
				log.error("redCouponRuleService.createMultiRedCouponActivatedForRule dubbo error",e);
			}
			if(result == null){
				vvcr.setStatus(2);
				vvcr.setRemark("调用优惠券异常，返回为null");
			}else if(!result.isSuccess()){
				vvcr.setStatus(2);
				vvcr.setRemark("错误代码"+result.getErrCode()+",调用优惠券错误："+ result.getErrMsg());
				log.error("redCouponRuleService.createMultiRedCouponActivatedForRule have error! userId:[{}], msg:[{}]",userId,result.getErrMsg());
			}else{
				log.info("sendCoupon Success! userId:[{}]",userId);
				List<String> data = result.getData();
				StringBuffer sb = new StringBuffer();
				if(data!=null && data.size() >0){
					for (String s : data) {
						sb.append(s + "_");
					}
				}
				vvcr.setStatus(1);
				vvcr.setRemark(sb.toString());

				int f = 0;
				//发放优惠券后数量为0则方案更改为失效。
				if(vshopVipCouponProject.getGiftStockCount() == 1){
					f = 1;
				}

				//调用发送接口成功后更新优惠券方案礼包剩余数量-1
				vshopVipCouponProjectDao.reduceGiftStockCount(vshopVipCouponProject.getId(),1,f);
				log.info("reduceGiftStockCount -1 Success! userId:[{}]",userId);
			}
		}
		//创建优惠券信息记录
		vshopVipCouponRecordDao.insert(vvcr);
	}

	public Boolean checkCouponValiteDate(Date couponEndDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			//当前时间
			Calendar now = Calendar.getInstance();
			Date nowDate = sdf.parse(sdf.format(new Date()));
			now.setTime(nowDate);

			//结束时间
			Calendar end = Calendar.getInstance();
			Date endDate = sdf.parse(sdf.format(couponEndDate));
			end.setTime(endDate);

			return now.before(end);
		} catch (Exception e) {
			log.error("checkCouponValiteDate failed!",e);
		}
		return true;
	}



	@Transactional
	public String sendCoupon(Long userId, List<String> regularIdList, String orderNo) {
		String msg = "";
		//查询当前生效的优惠券方案
		List<VshopVipCouponProject> vshopVipCouponProjectList = vshopVipCouponProjectDao.queryEffectiveVipCouponProject();
		//需要扣减礼包的集合
		List<VshopVipCouponProject> reduceList = new ArrayList<>();
		VshopVipCouponRecord vvcr = new VshopVipCouponRecord();
		vvcr.setUserId(userId);
		if(vshopVipCouponProjectList==null || vshopVipCouponProjectList.size() <= 0){
			vvcr.setProjectId("-1");
			vvcr.setStatus(2);
			vvcr.setRemark("当前无生效的优惠券方案");
			msg= "当前无生效的优惠券方案";
		}else{
			//调用发放优惠券接口
			List<CreateRuleRedCouponParam> list = new ArrayList<>();
			CreateRuleRedCouponParam crrp;
			for (String regularId : regularIdList) {
				for (VshopVipCouponProject vvcp : vshopVipCouponProjectList) {
					vvcr.setProjectId(String.valueOf(vvcp.getId()));
					String regularContent = vvcp.getRegularContent();
					if(StringUtils.isBlank(regularContent) || JsonUtils.toList(regularContent, new VipCouponRegularDto()).size() <= 0){
						continue;
					}
					List<VipCouponRegularDto> vipCouponRegularDtos = JsonUtils.toList(regularContent, new VipCouponRegularDto());
					//只取方案内第一个regularId
					VipCouponRegularDto dto = vipCouponRegularDtos.get(0);
					if(dto.getRegularId().equals(regularId)){
						//校验券规则有效性
						/*try {
							ResultDTO<CouponRuleInfo> couponRuleInfoByRuleId = queryGomePromService.getCouponRuleInfoByRuleId(dto.getRegularId());
							Boolean aBoolean = checkCouponValiteDate(couponRuleInfoByRuleId.getData().getCouponEndDate());
							if(!aBoolean){
								log.error("this RegularId invalid! RegularId:[{}]",dto.getRegularId());
								vvcr.setStatus(2);
								vvcr.setRemark("当前优惠券方案内包含已经过期的券规则");
								//创建优惠券信息记录
								vshopVipCouponRecordDao.insert(vvcr);
								break;
							}
						}catch (Exception e){
							log.error("queryGomePromService.getCouponRuleInfoByRuleId dubbo error! regularId:[{}]",dto.getRegularId(),e);
						}*/
						crrp = new CreateRuleRedCouponParam();
						//返券订单号
						crrp.setOrigOrderId(orderNo);
						//方案id
						crrp.setPromotionId(String.valueOf(vvcp.getId()));
						//生成原因：1004
						crrp.setGenerateReason(1004);
						//预算号
						crrp.setBudgetNo(vvcp.getBudgetNumber());
						//券履历备注，强制必填(付费美店)
						crrp.setHistoryRemark("付费美店");
						//操作类型，强制必填(1004)
						crrp.setHistoryOperateType(1004);
						//FALSE
						crrp.setSpecial(Boolean.FALSE);
						//券规则id
						crrp.setPromotionRule(dto.getRegularId());
						list.add(crrp);
						reduceList.add(vvcp);
					}
				}
			}
			ResultDO<List<String>> result = null;
			try {
				result = redCouponRuleService.createMultiRedCouponActivatedForRule(String.valueOf(userId), UUID.randomUUID().toString(), String.valueOf(userId), list);
			}catch (Exception e){
				vvcr.setStatus(2);
				vvcr.setRemark("调用优惠券异常！");
				msg= "调用优惠券异常！";
				log.error("redCouponRuleService.createMultiRedCouponActivatedForRule dubbo error",e);
			}
			if(result == null){
				vvcr.setStatus(2);
				vvcr.setRemark("调用优惠券异常，返回为null");
				msg= "调用优惠券异常，返回为null！";
			}else if(!result.isSuccess()){
				vvcr.setStatus(2);
				vvcr.setRemark("错误代码"+result.getErrCode()+",调用优惠券错误："+ result.getErrMsg());
				msg= "错误代码"+result.getErrCode()+",调用优惠券错误："+ result.getErrMsg();
				log.error("redCouponRuleService.createMultiRedCouponActivatedForRule have error! userId:[{}], msg:[{}]",userId,result.getErrMsg());
			}else{
				log.info("sendCoupon Success! userId:[{}]",userId);
				List<String> data = result.getData();
				StringBuffer sb = new StringBuffer();
				if(data!=null && data.size() >0){
					for (String s : data) {
						sb.append(s + "_");
					}
				}
				vvcr.setStatus(1);
				vvcr.setRemark(sb.toString());

				for (VshopVipCouponProject vshopVipCouponProject:reduceList) {
					int f = 0;
					//发放优惠券后数量为0则方案更改为失效。
					if(vshopVipCouponProject.getGiftStockCount() == 1){
						f = 1;
					}
					//调用发送接口成功后更新优惠券方案礼包剩余数量-1
					vshopVipCouponProjectDao.reduceGiftStockCount(vshopVipCouponProject.getId(),1,f);
					log.info("reduceGiftStockCount -1 Success! userId:[{}]",userId);
				}
			}
		}
		//创建优惠券信息记录
		vshopVipCouponRecordDao.insert(vvcr);
		return msg;
	}
}
