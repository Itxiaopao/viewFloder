package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;

public interface VshopInvitationRelationDao extends BaseDao<VshopInvitationRelation>{

	public List<VshopInvitationRelation> getVshopInvitationRelation(PageParam pageParam,Map<String, Object> map);

	public Integer countVshopInvitationRelation(Map<String, Object> map);

	public VshopInvitationRelation getInvitationRelationByReceiverUserId(Long userId);

}
