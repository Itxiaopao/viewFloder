package com.gomeo2o.utils;


/**
 * String 共通方法定义.
 * @project gome
 * @author 
 * @date Sep 01, 2010
 * @version 1.0
 * copyright (c) Founder
 */

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * the StringUtil class
 * 
 * @author Administrator
 * 
 */
public class StringUtil {
	
	/**
	 * 判断字符串是否为NULL和空串。
	 * 
	 * @param str
	 *            字符串
	 * @return boolean
	 */
	public static boolean isEmpty(String str) {
		return !notEmpty(str);
	}

	/**
	 * 判断字符串是否不为NULL和空串。
	 * 
	 * @param str
	 *            字符串
	 * @return boolean
	 */
	public static boolean notEmpty(String str) {
		return str != null && str.trim().length() > 0;
	}


	/**
	 * 计算字符串长度，中文占2个字符
	 * 
	 * @param pText
	 * @return
	 */
	public static int calculateLen(String pText) {
		int len = isEmpty(pText) ? 0 : pText.length();

		return len + getZNCount(pText);
	}

	/**
	 * 获取字符串中中文数量
	 * 
	 * @param pText
	 * @return
	 */
	public static int getZNCount(String pText) {
		int count = 0;

		if (!isEmpty(pText)) {
			Pattern p = Pattern.compile("[\\u4e00-\\u9fa5]");
			Matcher matcher = p.matcher(pText);
			while (matcher.find()) {
				count++;
			}
		}

		return count;
	}

	// 根据Unicode编码完美的判断中文汉字和符号
	private static boolean isChinese(char c) {
		if (c <= 122 && c >= 97) {// a-z
			return true;
		}
		if (c <= 90 && c >= 65) {// A-z
			return true;
		}
		if (c <= 57 && c >= 48) {// 0-9
			return true;
		}

		Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
		if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
				|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
				|| ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
				|| ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
				|| ub == Character.UnicodeBlock.GENERAL_PUNCTUATION) {
			return true;
		}
		return false;
	}

	// 根据Unicode编码完美的判断中文汉字和符号
		private static boolean isChineseForInvoiceHead(char c) {
			if (c <= 122 && c >= 97) {//a-z
				return true;
			}
			if (c <= 90 && c >= 65) {//A-z
				return true;
			}
			if (c <= 57 && c >= 48) {//0-9
				return true;
			}
			if (c == 40 || c == 41|| c == 46) {//().
				return true;
			}
			
			Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
			if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
					|| ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
					|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
					|| ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
					|| ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
					|| ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS
					|| ub == Character.UnicodeBlock.GENERAL_PUNCTUATION) {
				return true;
			}
			return false;
		}

    /**
	 * 邮箱格式化  
	 * 缺陷 55902 - 线上，页头用户名显示规则调整：更改邮箱、用户名显示规则
	 * 1、@前面的字符串长度为1-3，显示第一个，后面打三个*
	 * 		示例：abc@126.com，显示成a***@126.com
	 * 2、@前面的字符串长度为4-5，显示第一个和最后一个，中间打三个*
	 * 		示例：abcde@126.com，显示成a***e@126.com
	 * 3、@前面的字符串长度大于等于6，显示前两个，后三个，中间打三个*
	 * 		示例：abcdef@126.com，显示成ab***def@126.com
	 * 4、@后面域名长度大于15位，取前12位，后面打三个...
	 * 		示例：abcdefgh@12345678901234567890.com.cn，显示成ab***fgh@123456789012...	
	 * @param pEmail
	 * @return
	 * @author dengqingkui
	 * @date 2015-2-6 下午5:15:02
	 */
    public static String formatEmail(String pEmail){
		int preLength = pEmail.indexOf("@");
		if(preLength <= 0){//不含@或@前面为空，容错
			return pEmail;
		}
		String resultFormated;
		String emailSite =  pEmail.substring(preLength, pEmail.length());//含@
		emailSite = emailSite.length()>16 ? emailSite.substring(0, 13)+"..." : emailSite;
		if(preLength <= 3){//（@前面的字符串）长度为1-3
			resultFormated = pEmail.substring(0, 1) + "***" + emailSite;
		}else if(preLength <= 5){//长度为4-5
			resultFormated = pEmail.substring(0, 1) + "***" + pEmail.substring(preLength-1,preLength) + emailSite;
		}else{//长度大于6
			resultFormated = pEmail.substring(0, 2) + "***" + pEmail.substring(preLength-3,preLength) + emailSite;
		}
		return resultFormated;
	}
}

