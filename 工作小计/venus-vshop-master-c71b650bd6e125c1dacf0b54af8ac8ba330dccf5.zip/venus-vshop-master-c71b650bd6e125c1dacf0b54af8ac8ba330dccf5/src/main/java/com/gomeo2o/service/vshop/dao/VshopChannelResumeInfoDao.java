package com.gomeo2o.service.vshop.dao;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopChannelResumeInfo;

public interface VshopChannelResumeInfoDao extends BaseDao<VshopChannelResumeInfo>{
	
	
	
}