package com.gomeo2o.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.gome.diamond.annotations.DiamondValue;
import redis.Gcache;
import redis.GcacheClient;

@Configuration
public class GcacheConfig {

    @DiamondValue("${gcache.address}")
    private String address;

    @DiamondValue("${gcache.businessKey.vshop}")
    private String vshopBusinessKey;


    @Bean(name = "vshopCache", destroyMethod = "close")
    public Gcache vshopCache() {

        return new GcacheClient(address, vshopBusinessKey);
    }


}
