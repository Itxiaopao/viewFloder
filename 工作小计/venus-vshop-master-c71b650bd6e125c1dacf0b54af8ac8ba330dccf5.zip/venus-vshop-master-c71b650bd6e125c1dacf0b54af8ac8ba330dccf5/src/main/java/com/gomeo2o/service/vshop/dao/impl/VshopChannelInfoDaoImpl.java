package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.ChannelMshopReqDto;
import com.gomeo2o.facade.vshop.entity.VshopChannelInfo;
import com.gomeo2o.service.vshop.dao.VshopChannelInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("vshopChannelInfoDao")
public class VshopChannelInfoDaoImpl extends CBaseDaoImpl<VshopChannelInfo> implements VshopChannelInfoDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopChannelInfoDaoImpl.";
	
	@Override
	public List<VshopChannelInfo> getVshopChannelInfoList(PageParam pageParam,ChannelMshopReqDto channelMshopReqDto){
		Map<String,Object> map = new HashMap<>();
		map.put("id", channelMshopReqDto.getId());
		map.put("type", channelMshopReqDto.getType());
		map.put("name", channelMshopReqDto.getName());
		map.put("status", channelMshopReqDto.getStatus());
		map.put("provinceId", channelMshopReqDto.getProvinceId());
		map.put("cityId", channelMshopReqDto.getCityId());
		map.put("countyId", channelMshopReqDto.getCountyId());
		map.put("provinceName", channelMshopReqDto.getProvinceName());
		map.put("cityName", channelMshopReqDto.getCityName());
		map.put("countyName", channelMshopReqDto.getCountyName());
		map.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		map.put("pageSize", pageParam.getNumPerPage());
		List<VshopChannelInfo> list = this.getSessionTemplate().selectList(baseSQL+"getVshopChannelInfoList", map);
		return list;
	}

	@Override
	public Integer getChannelMshopCount(ChannelMshopReqDto channelMshopReqDto) {
		Map<String,Object> map = new HashMap<>();
		map.put("id", channelMshopReqDto.getId());
		map.put("type", channelMshopReqDto.getType());
		map.put("name", channelMshopReqDto.getName());
		map.put("status", channelMshopReqDto.getStatus());
		Integer count = this.getSessionTemplate().selectOne(baseSQL+"getChannelMshopCount",map);
		return count;
	}

	@Override
	public VshopChannelInfo queryVshopChannel(VshopChannelInfo vshopChannelInfo) {
		VshopChannelInfo vci = this.getSessionTemplate().selectOne(baseSQL+"queryVshopChannel",vshopChannelInfo);
		return vci;
	}

    @Override
    public VshopChannelInfo selectVshopChannelInfoById(Long channelId,String storeCode) {
    	 Map<String,Object> map = new HashMap<>();
         map.put("channelId", channelId);
         map.put("storeCode", storeCode);
        return this.getSessionTemplate().selectOne(baseSQL + "selectByParams", map);
    }

    @Override
    public VshopChannelInfo selectVshopChannelInfoByStoreCode(String storeCode) {
        return this.getSessionTemplate().selectOne(baseSQL + "selectByStoreCode", storeCode);
    }

    @Override
    public List<VshopChannelInfo> selectChannelInfoByPosition(String lng, String lat,int number) {
        Map<String,Object> map = new HashMap<>();
        map.put("longitude", lng);
        map.put("latitude", lat);
        map.put("number", number);
        return this.getSessionTemplate().selectList(baseSQL + "getChannelInfoByPosition", map);
    }
}
