package com.gomeo2o.facade.vshop.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.service.MshopScheduleFacade;
import com.gomeo2o.service.vshop.biz.MshopScheduleBiz;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("mshopScheduleFacade")
public class MshopScheduleFacadeImpl implements MshopScheduleFacade {
    @Autowired
    private MshopScheduleBiz mshopScheduleBiz;
    @Override
    public CommonResultEntity<Long> insertMshopCloneItemsSchedule(long originMshopId, long targertMshopId) {
        CommonResultEntity<Long> res = new CommonResultEntity<Long>();
        long l = mshopScheduleBiz.insertMshopCloneItemsSchedule(originMshopId, targertMshopId);
        if(l == 0){
        	res.setBusinessObj(l);
        	res.setCode(188888);
        	res.setMessage("您已执行过该任务，不可重复操作");
        	return res;
        }
        res.setBusinessObj(l);
        return res;
    }
}

