/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO
 * @author: guowenbo
 * @date: 2015年4月14日 下午12:08:36
 */
package com.gomeo2o.facade.vshop.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.dto.ExternalShopDto;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopMoreInfo;
import com.gomeo2o.facade.vshop.enums.ProductStatusEnum;
import com.gomeo2o.facade.vshop.service.VshopExternalFacade;
import com.gomeo2o.service.vshop.biz.VshopDistributionItemBiz;
import com.gomeo2o.service.vshop.biz.VshopInfoBiz;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

/**
 * @Description: 微店
 * @author: guowenbo
 * @date: 2015年4月14日 下午12:08:36
 */
@Slf4j
@Service("vshopExternalFacade")
public class VshopExternalFacadeImpl implements VshopExternalFacade {

	@Autowired
	private VshopDistributionItemBiz vshopDistributionItemBiz;
	@Autowired
	private VshopInfoBiz vshopInfoBiz;
	@Autowired
	Gcache vshopCache;

	@Override
	public CommonResultEntity<VshopMoreInfo> queryIsVshopByUserId(String userId) {
		CommonResultEntity<VshopMoreInfo> cre = new CommonResultEntity<VshopMoreInfo>();
		VshopMoreInfo vshopMoreInfo = new VshopMoreInfo();
        VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(Long.parseLong(userId));
        //封装数据
        if(vshopInfo!=null){
        	vshopMoreInfo.setIsVshop(true);
        	vshopMoreInfo.setVshopInfo(vshopInfo);
        }else{
        	vshopMoreInfo.setIsVshop(false);
        	vshopMoreInfo.setVshopInfo(null);
        }
        cre.setBusinessObj(vshopMoreInfo);
        return cre;
	}
	
	@Override
	public CommonResultEntity<Boolean> queryProducDistributionStatus(Long vshopId, String productId, String skuId) {
		CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
		Boolean flag = false;
		if (vshopId != null && vshopId != 0 && !StringUtils.isBlank(productId)) {
			// 只查询除上架中的商品
			String status = String.valueOf(ProductStatusEnum.SHANGJIA.getValue());
			flag = vshopDistributionItemBiz.queryProducDistributionStatus(vshopId, productId, skuId, status);
		} else {
			log.info("queryProducDistributionStatus pamas vshopId is [{}], productId is [{}], skuId is [{}]. ", vshopId, productId, skuId);
		}
		cre.setBusinessObj(flag);
		return cre;
	}

	@Override
	public CommonResultEntity<ExternalShopDto> queryDistributionItemCountByShopId(
			Long shopId) {
		CommonResultEntity<ExternalShopDto> cre = new CommonResultEntity<ExternalShopDto>();
		ExternalShopDto dto = new ExternalShopDto();
		String count = vshopCache.get("shop:shopitemscount:"+shopId);
		dto.setDistributionItemCount(Integer.valueOf(count));
		cre.setBusinessObj(dto);
		return cre;
	}

}
