package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopVipCouponProject;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
public interface VshopVipCouponProjectDao extends BaseDao<VshopVipCouponProject> {
    List<VshopVipCouponProject> queryEffectiveVipCouponProject();

    void reduceGiftStockCount(Long id,Integer count,Integer f);

    /**
     * 根据条件查询方案列表
     * @param params
     * @return
     */
    List<VshopVipCouponProject> queryListByCondition(Map<String,Object> params);

    /**
     * 获取所有已审核通过或者生效的方案

     * @return
     */
    List<VshopVipCouponProject> getAllEffectiveProject();

}