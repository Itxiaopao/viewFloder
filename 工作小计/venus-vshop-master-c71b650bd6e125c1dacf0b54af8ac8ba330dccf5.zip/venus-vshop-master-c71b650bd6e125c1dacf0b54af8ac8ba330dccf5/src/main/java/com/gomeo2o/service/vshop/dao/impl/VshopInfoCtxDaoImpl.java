package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopInfoCtx;
import com.gomeo2o.service.vshop.dao.VshopInfoCtxDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("vshopInfoCtxDao")
public class VshopInfoCtxDaoImpl extends CBaseDaoImpl<VshopInfoCtx> implements VshopInfoCtxDao {

    private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopInfoCtxDaoImpl.";

    @Override
    public void insertVshopInfoCtx(VshopInfoCtx ctx) {
        this.getSessionTemplate().insert(baseSQL + "insertVshopInfoCtx", ctx);
    }


}
