package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.MshopPushMessage;

public interface MshopMessageDao extends BaseDao<MshopPushMessage> {

	List<MshopPushMessage> queryMshopPushMessage(Map<String, Object> map);

	MshopPushMessage queryMshopPushMessageById(Long id);

	Integer queryMshopPushMessageCount(Map<String, Object> map);

	/**
	 * 查询美店新用户注册的单发消息
	 * @return
	 */
	MshopPushMessage queryRegisterMshopPushMessage();


}
