package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopVipRelationship;
import com.gomeo2o.service.vshop.dao.VshopVipRelationshipDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopVipRelationshipDao")
public class VshopVipRelationshipDaoImpl extends CBaseDaoImpl<VshopVipRelationship> implements VshopVipRelationshipDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopVipRelationshipDaoImpl.";

	@Override
	public Integer countVshopVipRelationshipByInviterUserId(Long inviterUserId,String source) {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("inviterUserId", inviterUserId);
		paramMap.put("source",source);
		return this.getSessionTemplate().selectOne(baseSQL+"countVshopVipRelationshipByInviterUserId",paramMap);
	}

	@Override
	public List<VshopVipRelationship> getVshopVipRelationships(PageParam pageParam, Long inviterUserId) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("inviterUserId", inviterUserId);
		if (null != pageParam){
			paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
			paramMap.put("pageSize", pageParam.getNumPerPage());
		}
		return this.getSessionTemplate().selectList(baseSQL+"getVshopVipRelationshipsByInviterUserId",paramMap);
	}

}
