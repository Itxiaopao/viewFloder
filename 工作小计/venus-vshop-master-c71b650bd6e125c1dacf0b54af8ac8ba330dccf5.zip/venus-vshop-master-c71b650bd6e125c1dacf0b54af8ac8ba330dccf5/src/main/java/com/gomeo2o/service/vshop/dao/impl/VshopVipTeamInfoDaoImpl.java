package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopVipTeamInfo;
import com.gomeo2o.service.vshop.dao.VshopVipTeamInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
@Repository("name=vshopVipTeamInfoDa")
public class VshopVipTeamInfoDaoImpl extends CBaseDaoImpl<VshopVipTeamInfo>
        implements VshopVipTeamInfoDao {

}