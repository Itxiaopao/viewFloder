package com.gomeo2o.service.vshop.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.MshopPushMessage;
import com.gomeo2o.service.vshop.dao.MshopMessageDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository
public class MshopMessageDaoImpl extends CBaseDaoImpl<MshopPushMessage> implements MshopMessageDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.MshopMessageDaoImpl.";

	@Override
	public List<MshopPushMessage> queryMshopPushMessage(Map<String, Object> map) {
		return this.getSessionTemplate().selectList(baseSQL + "queryMshopPushMessage", map);
	}

	@Override
	public MshopPushMessage queryMshopPushMessageById(Long id) {

		return this.getSessionTemplate().selectOne(baseSQL + "queryMshopPushMessageById", id);
	}

	@Override
	public Integer queryMshopPushMessageCount(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return this.getSessionTemplate().selectOne(baseSQL + "queryMshopPushMessageCount", map);
	}

	@Override
	public MshopPushMessage queryRegisterMshopPushMessage() {
		return this.getSessionTemplate().selectOne(baseSQL + "queryRegisterMshopPushMessage");
	}
}
