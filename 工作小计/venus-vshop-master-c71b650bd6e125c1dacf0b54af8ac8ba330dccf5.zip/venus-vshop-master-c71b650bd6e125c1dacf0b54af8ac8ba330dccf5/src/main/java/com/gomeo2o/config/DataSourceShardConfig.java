package com.gomeo2o.config;

import javax.sql.DataSource;

import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.gome.diamond.annotations.DiamondValue;
import com.gome.gcat.plugins.mybatis.CatMybatisInterceptor;
import com.taobao.tddl.group.jdbc.TGroupDataSource;

/**
 * @Author yuliang-ds1
 * @Date 2018/6/26 14:17
 * @Description 数据库信息配置
 */
@Configuration
public class DataSourceShardConfig {

	/** tddl主从集群业务名称 */
	@DiamondValue("${vshopShard.tddl.appname}")
	public String app_name;

	/** tddl主从集群分组key */
	@DiamondValue("${vshopShard.tddl.dbGroupKey}")
	public String group_key;


	/**
	 * 初始化Tddl的DataSource数据源
	 * @return
	 */
	@Bean(initMethod = "init", name = "dataSourceShard")
	public DataSource dataSourceShard() {
		TGroupDataSource dataSource = new TGroupDataSource(group_key, app_name);
		return dataSource;
	}
	/**
	 * 事务管理组件
	 * @return
	 * @throws InterruptedException
	 */
	@Bean(name = "transactionManagerShard")
	@Scope("prototype")
	public DataSourceTransactionManager transactionManagerShard(@Qualifier("dataSourceShard") DataSource dataSourceShard ) {
		return new DataSourceTransactionManager(dataSourceShard);
	}

	/**
	 * 初始化Tddl的sqlSessionFactory数据源
	 * @param dataSourceShard
	 * @return
	 * @throws Exception
	 */
	@Bean(name = "sqlSessionFactoryShard")
	public SqlSessionFactoryBean sessionFactoryShard(@Qualifier("dataSourceShard") DataSource dataSourceShard)
			throws Exception {
		final SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
		sessionFactory.setDataSource(dataSourceShard);
		sessionFactory.setPlugins(new Interceptor[]{new CatMybatisInterceptor()});
		sessionFactory.setConfigLocation(new PathMatchingResourcePatternResolver().getResource("classpath:/spring/venus-mybatis-config.xml"));
		sessionFactory.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mapper/*.xml"));
		return sessionFactory;
	}

	@Bean(name = "sessionTemplateShard")
	public SqlSessionTemplate sessionTemplateShard(
			@Qualifier("sqlSessionFactoryShard") SqlSessionFactory sqlSessionFactoryShard) throws Exception {
		return new SqlSessionTemplate(sqlSessionFactoryShard);
	}

}
