/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description:
 * @author: Administrator
 * @date: 2015年4月9日 上午9:57:27
 */
package com.gomeo2o.service.vshop.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.facade.vshop.entity.VshopStores;
import com.gomeo2o.service.vshop.dao.VshopStoresDao;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("name=vshopStoresBiz")
public class VshopStoresBiz {

	@Autowired
	private VshopStoresDao vshopStoresDao;

	public VshopStoresBiz() {
	}

    public VshopStores queryVshopStoresById(Long vshopId) {
		return vshopStoresDao.queryVshopStoresById(vshopId);
    }

    public String insertOrUpdateVshopStores(VshopStores vshopStores){
		VshopStores vs = vshopStoresDao.queryVshopStoresById(vshopStores.getVshopId());
		String id = "";
		if(vs!=null){
			id = String.valueOf(vshopStoresDao.update(vshopStores));
		}else{
			id = String.valueOf(vshopStoresDao.insert(vshopStores));
		}
		return id;
	}
}
