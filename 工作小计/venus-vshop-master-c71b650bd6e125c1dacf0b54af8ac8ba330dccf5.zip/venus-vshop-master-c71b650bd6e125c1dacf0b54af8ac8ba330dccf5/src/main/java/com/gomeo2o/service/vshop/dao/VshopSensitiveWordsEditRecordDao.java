package com.gomeo2o.service.vshop.dao;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopSensitiveWordsEditRecord;

public interface VshopSensitiveWordsEditRecordDao extends BaseDao<VshopSensitiveWordsEditRecord>{


	public VshopSensitiveWordsEditRecord getSensitiveWordsEditRecordByVshopId(Long vshopId);

}
