package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantChangeRecord;
import com.gomeo2o.service.vshop.dao.VshopChannelMerchantChangeRecordDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopChannelMerchantChangeRecordDao")
public class VshopChannelMerchantChangeRecordDaoImpl extends CBaseDaoImpl<VshopChannelMerchantChangeRecord> implements VshopChannelMerchantChangeRecordDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopChannelMerchantChangeRecordDaoImpl.";
}
