package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopInfoDao")
public class VshopInfoDaoImpl extends CBaseDaoImpl<VshopInfo> implements VshopInfoDao {

    private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopInfoDaoImpl.";

    @Override
    public VshopInfo queryVshopByuserId(long userId) {
        return this.getSessionTemplate().selectOne(baseSQL + "queryVshopByuserId", userId);
    }

    @Override
    public void queryVshopName(long vshopId, String vshopName) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("vshopName", vshopName);
        paramMap.put("vshopId", vshopId);
        int result = this.getSessionTemplate().selectOne(baseSQL + "queryVshopName", paramMap);
        if (result > 0) {
            throw VshopException.VSHOP_NAME_EXIST;
        }
    }

    @Override
    public void updateVshopStatus(long vshopId, Integer vshopStatus) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("vshopStatus", vshopStatus);
        paramMap.put("vshopId", vshopId);
        this.getSessionTemplate().update(baseSQL + "updateVshopStatus", paramMap);
    }

    @Override
    public List<VshopInfo> queryVshopInfoListByCriteria(PageParam pageParam, Map<String, Object> criteria) {
        if( null != pageParam){
            criteria.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
            criteria.put("pageSize", pageParam.getNumPerPage());
        }
        return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoListByCriteria", criteria);
    }

    @Override
    public Integer queryVshopInfoCountByCriteria( Map<String, Object> criteria) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        return this.getSessionTemplate().selectOne(baseSQL + "queryVshopInfoCountByCriteria", criteria);
    }

    @Override
    public List<VshopInfo> queryVshopInfoListForVip(Map<String, Object> sqlParams) {
        return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoListForVip", sqlParams);
    }

    @Override
    public Integer queryVshopInfoCountByShiId(long shiId, int vshopStatus) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("shiId", shiId);
        paramMap.put("vshopStatus", vshopStatus);
        return this.getSessionTemplate().selectOne(baseSQL + "queryVshopInfoCountByShiId", paramMap);
    }

    @Override
    public List<VshopInfo> queryVshopInfoListByShiId(PageParam pageParam, long shiId, int vshopStatus) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("shiId", shiId);
        paramMap.put("vshopStatus", vshopStatus);
        paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
        paramMap.put("pageSize", pageParam.getNumPerPage());
        return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoListByShiId", paramMap);
    }

    @Override
    public boolean queryVshopNameByApp(String vshopName) {
        int result = this.getSessionTemplate().selectOne(baseSQL + "queryVshopNameByApp", vshopName);
        if (result > 0) {
            return false;
        }
        return true;
    }

    @Override
    public void checkVshop(long vshopId) {
        int count = this.getSessionTemplate().selectOne(baseSQL + "checkVshop", vshopId);
        if (count <= 0) {
            throw VshopException.VSHOP_EXIST;
        }
    }

    @Override
    public void checkUser(long userId) {
        int count = this.getSessionTemplate().selectOne(baseSQL + "checkUser", userId);
        if (count >= 1) {
            throw VshopException.USER_EXIST;
        }
    }

    @Override
    public List<VshopInfo> queryPopInfo(String vshopType, int vshopStatus) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("vshopType", vshopType);
        paramMap.put("vshopStatus", vshopStatus);
        return this.getSessionTemplate().selectList(baseSQL + "queryPopInfo", paramMap);
    }

    @Override
    public void checkUserVshop(long userId, long vshopId) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("userId", userId);
        paramMap.put("vshopId", vshopId);
        int count = this.getSessionTemplate().selectOne(baseSQL + "checkUserVshop", paramMap);
        if (count <= 0) {
            throw VshopException.USER_NOT_VSHOP;
        }
    }

    @Override
    public void updatePopInfo(VshopInfo vshopInfo) {
        this.getSessionTemplate().update(baseSQL + "updatePopInfo", vshopInfo);
    }

    @Override
    public void deleteVshopInfo(long userId) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("userId", userId);
        this.getSessionTemplate().delete(baseSQL + "deleteVshopInfo", paramMap);
    }

    @Override
    public boolean queryVshopNameByApp(long userId, String vshopName) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("userId", String.valueOf(userId));
        paramMap.put("vshopName", vshopName);
        int result = this.getSessionTemplate().selectOne(baseSQL + "queryVshopNameByYY", paramMap);
        if (result > 0) {
            return false;
        }
        return true;
    }

    @Override
    public int update(VshopInfo vshopInfoEntity) {
        return this.getSessionTemplate().update(baseSQL + "update", vshopInfoEntity);
    }

    @Override
    public Integer queryMshopCount() {
        return this.getSessionTemplate().selectOne(baseSQL + "queryMshopCount");
    }

    @Override
    public long insertNewVshop(VshopInfo vshopInfoEntity) {
        long res = this.getSessionTemplate().insert(baseSQL + "insertNewVshop", vshopInfoEntity);
        long id = 0l;
        if (res > 0) {
            log.info("create vshop return id:{}", id);
            id = vshopInfoEntity.getVshopId();
        }
        return id;
    }

    @Override
    public List<VshopInfo> queryVshopInfoList(PageParam pageParam,
                                              Integer vshopStatus) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("vshopStatus", vshopStatus);
        paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
        paramMap.put("pageSize", pageParam.getNumPerPage());
        return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoList", paramMap);
    }

    @Override
    public List<Long> queryVshopInfoListById(Map map) {
        return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoListById", map);
    }

    @Override
    public void updateVshopNameByVshopId(Long vshopId) {
        this.getSessionTemplate().delete(baseSQL + "updateVshopNameByVshopId", vshopId);
    }

    @Override
    public void updataIsStarByShopId(long vshopId, int isStar) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("isStar", isStar);
        paramMap.put("vshopId", vshopId);
        this.getSessionTemplate().update(baseSQL + "updataIsStarByShopId", paramMap);
    }

    @Override
    public List<VshopInfo> getByVshopIds(List<Long> ids) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("ids", ids);
        return this.getSessionTemplate().selectList(baseSQL + "getByIds", paramMap);
    }

    @Override
    public List<VshopInfo> queryVshopInfoListByShopName(PageParam pageParam, String shopName) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("shopName", shopName);
        paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
        paramMap.put("pageSize", pageParam.getNumPerPage());
        return this.getSessionTemplate().selectList(baseSQL + "queryVshopInfoListByShopName", paramMap);
    }
    @Override
    public void queryVshopPhoneNo(long vshopId, String phoneNo) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("phoneNo", phoneNo);
        paramMap.put("vshopId", vshopId);
        log.info("select phone vshopId exit phoneNo:{},vshopId:{}", phoneNo,vshopId);
        int result = this.getSessionTemplate().selectOne(baseSQL + "queryVshopPhoneNo", paramMap);
        if (result > 0) {
            throw VshopException.VSHOP_PHONE_NO_EXIST;
        }
    }
}
