package com.gomeo2o.service.vshop.dao;

import java.util.List;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopOnItemCount;

public interface VshopOnItemCountDao extends BaseDao<VshopOnItemCount> {

	/**
	 * @Description 查询上架商品数量
	 * @author suliangyi
	 * @date 2015年12月25日 上午11:07:08
	 * @return
	 */
	public List<VshopOnItemCount> queryOnItemCount();
	/**
	 * @Description 查询所有的店铺
	 * @author suliangyi
	 * @date 2015年12月25日 上午11:07:08
	 * @return
	 */
	public List<VshopOnItemCount> queryAllShopList();
}
