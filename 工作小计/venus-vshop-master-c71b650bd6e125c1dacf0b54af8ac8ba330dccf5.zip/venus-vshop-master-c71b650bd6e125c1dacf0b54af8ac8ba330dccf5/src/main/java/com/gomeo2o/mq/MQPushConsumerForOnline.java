package com.gomeo2o.mq;

import java.util.List;
import java.util.concurrent.ExecutorService;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Component;

import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.gome.diamond.annotations.DiamondValue;
import com.gomeo2o.service.vshop.biz.VshopDistributionItemBiz;
import com.gomeo2o.utils.SpringContextUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description: MQ消费者
 * @author:      guowenbo
 * @date: 2015年5月26日 下午5:40:31
 */
@Slf4j
@Component
public class MQPushConsumerForOnline{
	
	@DiamondValue("${mq.address}")
	private String namesrvAddr;
	@DiamondValue("${mq.shelf.shelfmanage_topic}")
	private String topic;
	@DiamondValue("${mq.shelf.shelfmanage_group}")
	private String group;

	@PostConstruct
	public void init() {
		try {
			/**
			 * 一个应用创建一个Consumer，由应用来维护此对象，可以设置为全局对象或者单例<br>
			 * 注意：ConsumerGroupName需要由应用来保证唯一
			 */
			log.info("init MQ:namesrvAddr'{}' topic'{}' group'{}'",namesrvAddr,topic,group);
			DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(group);
			consumer.setNamesrvAddr(namesrvAddr);
			/**
			 * 订阅指定topic下tags分别等于TagU或TagFX
			 * 注意：一个consumer对象可以订阅多个topic
			 */
			 consumer.subscribe(topic, "TagU||TagClose");
			//调用MQThreads类获取
			final ExecutorService pool = MQThreads.newFixedThreadPool();

			consumer.registerMessageListener(new MessageListenerConcurrently() {
				/**
				 * 默认msgs里只有一条消息，可以通过设置consumeMessageBatchMaxSize参数来批量接收消息
				 */
				@Override
				public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {

					 MessageExt msg = msgs.get(0);
					if (msg.getTopic().equals(topic)) {
						pool.execute(new Runnable() {
							@Override public void run() {
								String tag = msg.getTags();
								String key = msg.getKeys();
								byte[] bytes = msg.getBody();
								String body = new String(bytes);
								log.info("use MQ: tag'{}' key:'{}' body:'{}'",tag,key,body);
								VshopDistributionItemBiz vshopDistributionItemBiz = (VshopDistributionItemBiz) SpringContextUtil.getBean("vshopDistributionItemBiz");
								// 执行商品状态更新的逻辑
								if (tag != null && tag.equals("TagU")) {
									vshopDistributionItemBiz.updateProductStatusByPopForOnline(body);
								}
								// 执行店铺关闭的逻辑
								else if(tag != null && tag.equals("TagClose")){
									vshopDistributionItemBiz.updateProductStatusByCloseForOnline(body);
								}
							}
						});
					}
					return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
				}
			});

			/**
			 * Consumer对象在使用之前必须要调用start初始化，初始化一次即可<br>
			 */
			consumer.start();
			log.info("Consumer Started.");
		} catch (Exception e) {
			log.error("init MQ ERROR: ",e);
		}
	}
}
