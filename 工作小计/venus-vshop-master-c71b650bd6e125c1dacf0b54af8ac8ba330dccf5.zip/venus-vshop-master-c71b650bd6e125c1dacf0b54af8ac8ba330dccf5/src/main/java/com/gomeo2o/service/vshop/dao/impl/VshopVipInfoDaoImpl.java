package com.gomeo2o.service.vshop.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopVipInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipMshopIdSimpleInfo;
import com.gomeo2o.service.vshop.dao.VshopVipInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
@Repository("name=vshopVipInfoDao")
public class VshopVipInfoDaoImpl extends CBaseDaoImpl<VshopVipInfo>
        implements VshopVipInfoDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.vshopVipInfoDaoImpl.";

    @Override
    public VshopVipInfo getVshopVipInfoByUserId(Long userId) {
        return getSessionTemplate().selectOne(getStatement("selectByUserId"), userId);
    }

    @Override
    public List<VshopVipInfo> adminPageQueryVipInfo(Map<String, Object> map) {
        return getSessionTemplate().selectList(getStatement("adminPageQueryVipInfo"), map);
    }

    @Override
    public Integer adminPageQueryVipInfoCount(Map<String, Object> map){
        return getSessionTemplate().selectOne(getStatement("adminPageQueryVipInfoCount"), map);
    }

    @Override
    public List<VshopVipMshopIdSimpleInfo> queryAllVipMshopIdInfoList() {
        return getSessionTemplate().selectList(getStatement("queryAllVipMshopIdInfoList"), null);

    }
}