package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeo2o.service.vshop.dao.VshopInvitationRelationDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopInvitationRelationDao")
public class VshopInvitationRelationDaoImpl  extends CBaseDaoImpl<VshopInvitationRelation> implements VshopInvitationRelationDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopInvitationRelationDaoImpl.";
	
	@Override
	public List<VshopInvitationRelation> getVshopInvitationRelation(PageParam pageParam,Map<String, Object> map) {
		map.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		map.put("pageSize", pageParam.getNumPerPage());
		return this.getSessionTemplate().selectList(baseSQL+"getVshopInvitationRelation", map);
	}

	@Override
	public Integer countVshopInvitationRelation(Map<String, Object> map) {
		
		return this.getSessionTemplate().selectOne(baseSQL+"countVshopInvitationRelation", map);
	}

	@Override
	public VshopInvitationRelation getInvitationRelationByReceiverUserId(Long userId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("receiverUserId", userId);
		return this.getSessionTemplate().selectOne(baseSQL+"getInvitationRelationByReceiverUserId", map);
	}



}
