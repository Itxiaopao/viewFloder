package com.gomeo2o.service.vshop.dao.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopVipTeamMemberInfo;
import com.gomeo2o.service.vshop.dao.VshopVipTeamMemberInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;
import com.google.common.collect.Maps;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/			  
@Repository("name=vshopVipTeamMemberInfoDao")
public class VshopVipTeamMemberInfoDaoImpl extends CBaseDaoImpl<VshopVipTeamMemberInfo>
        implements VshopVipTeamMemberInfoDao {
	
   private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopVipTeamMemberInfoDaoImpl.";
	
	@Override
	public Integer countVshopVipTeamMemberByTutorUserId(Map<String,Object> paramMap) {
		return this.getSessionTemplate().selectOne(baseSQL+"countVshopVipTeamMemberByTutorUserId", paramMap);
	}

	@Override
	public List<VshopVipTeamMemberInfo> getVshopVipTeamMembers(PageParam pageParam, Long tutorUserId) {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("tutorUserId", tutorUserId);
		paramMap.put("pageFirst", (pageParam.getPageNum() - 1) * pageParam.getNumPerPage());
		paramMap.put("pageSize", pageParam.getNumPerPage());
		
		return this.getSessionTemplate().selectList(baseSQL+"getVshopVipTeamMembersByTutorUserId", paramMap);
	}

	@Override
	public Long queryTutorUserIdByMemberUserId(Long memberUserId) {
		VshopVipTeamMemberInfo vshopVipTeamMemberInfo = this.getSessionTemplate().selectOne(baseSQL + "queryTutorUserIdByMemberUserId",memberUserId);
		if (null == vshopVipTeamMemberInfo){
			return null;
		}
		Long svipId = vshopVipTeamMemberInfo.getTutorUserId();
		return svipId;
	}

	@Override
	public Integer quitVipTeamMember( Long originMemberUserId, Date invaliaidTime) {

		Map<String,Object> params = Maps.newHashMap();
		params.put("originMemberUserId",originMemberUserId);
		params.put("invalaidTime",invaliaidTime);

		return this.getSessionTemplate().update(baseSQL+"quitVipTeamMember",params);
	}
}