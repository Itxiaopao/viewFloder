/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: CreateVshopItemEvent.java 
 * @Prject: venus-vshop
 * @Package: com.gomeo2o.event.vshop
 * @Description: 美店商品上架事件
 * @author: sunyizhong   
 * @date: 2016年11月24日 上午10:09:35 
 * @version: V1.0   
 */
package com.gomeo2o.event.vshop;

import java.util.Map;

import com.gomeo2o.event.common.AbstractIdEvent;

/**
 * 
 * @ClassName: CreateVshopItemEvent
 * @Description: 美店商品上架事件
 * @author: sunyizhong
 * @date: 2016年11月24日 上午11:50:53
 */
public class CreateVshopItemEvent extends AbstractIdEvent<Map<String, Object>> {

	public CreateVshopItemEvent(Long id) {
		super(id);
	}

}
