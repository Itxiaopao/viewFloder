package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInfo;

public interface VshopInfoDao extends BaseDao<VshopInfo> {

	public VshopInfo queryVshopByuserId(long userId);

	public void queryVshopName(long vshopId, String vshopName);

	public void updateVshopStatus(long vshopId, Integer vshopStatus);

	public List<VshopInfo> queryVshopInfoListByCriteria(PageParam pageParam,Map<String, Object> criteria);

	public List<VshopInfo> queryVshopInfoListForVip(Map<String,Object> sqlParams);

	public Integer queryVshopInfoCountByCriteria(Map<String, Object> criteria);

	public Integer queryVshopInfoCountByShiId(long shiId, int vshopStatus);

	public List<VshopInfo> queryVshopInfoListByShiId(PageParam pageParam, long shiId, int vshopStatus);

	public boolean queryVshopNameByApp(String vshopName);

	public void checkVshop(long vshopId);

	public void checkUser(long userId);

	public List<VshopInfo> queryPopInfo(String vshopType, int vshopStatus);

	public void checkUserVshop(long userId, long vshopId);

	public void updatePopInfo(VshopInfo vshopInfo);

	public void deleteVshopInfo(long userId);

	public boolean queryVshopNameByApp(long userId, String vshopName);

	public int update(VshopInfo vshopInfoEntity);

	public Integer queryMshopCount();

	public long insertNewVshop(VshopInfo vshopInfoEntity);

	public List<VshopInfo> queryVshopInfoList(PageParam pageParam,
	        Integer vshopStatus);
	public List<Long> queryVshopInfoListById(Map map);

    void updateVshopNameByVshopId(Long vshopId);

	public void updataIsStarByShopId(long vshopId, int isStar);
	
	public List<VshopInfo> getByVshopIds(List<Long> ids);

	public List<VshopInfo> queryVshopInfoListByShopName(PageParam pageParam,String shopName);

	void queryVshopPhoneNo(long vshopId, String phoneNo);
}
