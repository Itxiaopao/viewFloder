package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopDistributionItem;

public interface VshopDistributionItemDao extends BaseDao<VshopDistributionItem> {

	public int queryProductCountByVshopId(long vshopId, String status);

	public List<VshopDistributionItem> queryListProductByCategoryId(PageParam pageParam, long vcategoryId, long vshopId, String status);

	public List<VshopDistributionItem> queryListProductByStatus(PageParam pageParam, String status, long vshopId);

	public int queryProductCountByStatus(String status, long vshopId);

	public int queryItemCountByCategoryId(long vcategoryId, long vshopId, String status);

	public void updateProductCategory(long vcategoryId, long vshopId);

	public List<VshopDistributionItem> queryListProductByVshopId(PageParam pageParam, long vshopId, String status);

	//public void updateDistributionItemByMQ(Map<String, Object> map);

	public VshopDistributionItem queryProductByProductId(String itemId, String skuId, long vshopId);

	public void checkProduct(long vshopId, String itemId, String skuId, int flag);

	public Boolean checkProductIsExist(long vshopId, String productId, String skuId, String status);

	public void updateProductaddByDongJie(VshopDistributionItem vshopProductadd);

	public Integer queryProductShareCount(String itemId);

	//public List<VshopDistributionItem> queryListProductByProductId(String itemId);

	public int update(VshopDistributionItem vshopProductadd);

	public Integer queryDistributionItemCountCount(long vshopId);

	// 610编号api暂时性数据填充
	public List<VshopDistributionItem> queryListProductByCriteria(PageParam pageParam, Map<String, Object> criteria);

	public Integer queryItemQuantityByCriteria(Map<String, Object> criteria);

	public void deleteDistributionItems(List<String> itemIds, long vshopId);

	public void updateDistributionItems(List<String> itemIds, long vshopId, long vcategoryId);

	//public void updateProductForDeleteCategory(Long categoryId, long vshopId);

	public int deleteDistributionItem(Map<String, Object> map);

	//public void deleteDistributionItemByVshopId(Map<String, Object> map);

	public List<VshopDistributionItem> queryItemsInMShop(PageParam pageParam);

	//public List<VshopDistributionItem> queryListProductByPopId(String popId);

	public void updateProductIdentificationByVshopId(Long vshopId);

	public List<VshopDistributionItem> queryListProductByMQ(Map<String, Object> map);

	public void updateProductByMQ(Map<String, Object> map);

	public List<VshopDistributionItem> queryListProducts(Map<String, Object> idsMap);
}
