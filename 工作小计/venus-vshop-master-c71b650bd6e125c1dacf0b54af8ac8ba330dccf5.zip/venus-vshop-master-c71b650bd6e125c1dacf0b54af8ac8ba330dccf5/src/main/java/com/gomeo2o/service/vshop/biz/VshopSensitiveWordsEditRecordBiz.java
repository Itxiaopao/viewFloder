package com.gomeo2o.service.vshop.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.facade.vshop.entity.VshopSensitiveWordsEditRecord;
import com.gomeo2o.service.vshop.dao.VshopSensitiveWordsEditRecordDao;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopSensitiveWordsEditRecordBiz")
public class VshopSensitiveWordsEditRecordBiz {
	
	@Autowired
	private VshopSensitiveWordsEditRecordDao vshopSensitiveWordsEditRecordDao;
	
	public void saveSensitiveWordsEditRecord(VshopSensitiveWordsEditRecord sensitiveWordsEditRecord) {
		vshopSensitiveWordsEditRecordDao.insert(sensitiveWordsEditRecord);
	}

	public VshopSensitiveWordsEditRecord getSensitiveWordsEditRecordByVshopId(Long vshopId) {
		
		return vshopSensitiveWordsEditRecordDao.getSensitiveWordsEditRecordByVshopId(vshopId);
		
	}

}
