package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopSensitiveWordsEditRecord;
import com.gomeo2o.service.vshop.dao.VshopSensitiveWordsEditRecordDao;
import com.gomeo2o.service.vshop.dao.base.BaseDaoImpl;

@Repository("name=vshopSensitiveWordsEditRecordDao")
public class VshopSensitiveWordsEditRecordDaoImpl extends BaseDaoImpl<VshopSensitiveWordsEditRecord> implements VshopSensitiveWordsEditRecordDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopSensitiveWordsEditRecordDaoImpl.";
	@Override
	public VshopSensitiveWordsEditRecord getSensitiveWordsEditRecordByVshopId(Long vshopId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("vshopId", vshopId);
		List<VshopSensitiveWordsEditRecord> list = this.getSessionTemplate().selectList(baseSQL+"getSensitiveWordsEditRecordByVshopId", map);
		if(list != null && list.size()>0){
			return list.get(0);
		}
		return null;
	}

}
