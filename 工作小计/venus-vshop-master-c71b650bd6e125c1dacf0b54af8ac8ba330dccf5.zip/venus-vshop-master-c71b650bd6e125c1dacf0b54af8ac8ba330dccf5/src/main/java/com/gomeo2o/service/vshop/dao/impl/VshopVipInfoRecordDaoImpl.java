package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopVipInfoRecord;
import com.gomeo2o.service.vshop.dao.VshopVipInfoRecordDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopVipInfoRecordDao")
public class VshopVipInfoRecordDaoImpl extends CBaseDaoImpl<VshopVipInfoRecord>
        implements VshopVipInfoRecordDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.vshopVipInfoRecordDaoImpl.";

}