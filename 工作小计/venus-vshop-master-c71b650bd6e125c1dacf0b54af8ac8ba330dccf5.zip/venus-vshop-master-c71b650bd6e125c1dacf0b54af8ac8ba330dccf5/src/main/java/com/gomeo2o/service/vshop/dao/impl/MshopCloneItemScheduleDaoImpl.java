package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.MshopCloneItemSchedule;
import com.gomeo2o.service.vshop.dao.MshopCloneItemScheduleDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("mhopCloneItemScheduleDao")
public class MshopCloneItemScheduleDaoImpl extends CBaseDaoImpl<MshopCloneItemSchedule> implements MshopCloneItemScheduleDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.MshopCloneItemScheduleDaoImpl.";
	@Override
	public List<MshopCloneItemSchedule> queryMshopCloneItemScheduleById(long originMshopId,long targetMshopId) {
		Map<String,Object> map  = new HashMap<String, Object>();
		map.put("originMshopId", originMshopId);
		map.put("targetMshopId", targetMshopId);
		List<MshopCloneItemSchedule> selectList = getSessionTemplate().selectList(baseSQL + "queryMshopCloneItemScheduleById", map);
		return selectList;
	}

}
