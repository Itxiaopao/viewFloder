package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantInfo;
import com.gomeo2o.service.vshop.dao.VshopChannelMerchantInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopChannelMerchantInfoDao")
public class VshopChannelMerchantInfoDaoImpl extends CBaseDaoImpl<VshopChannelMerchantInfo> implements VshopChannelMerchantInfoDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopChannelMerchantInfoDaoImpl.";

	@Override
	public VshopChannelMerchantInfo getVshopChannelMerchantInfo(Long id) {
		Map<String,Object> map = new HashMap<>();
		map.put("id", id);
		VshopChannelMerchantInfo vshopChannelMerchantInfo = this.getSessionTemplate().selectOne(baseSQL+"getVshopChannelMerchantInfo", id);
		return vshopChannelMerchantInfo;
	}
	
}
