package com.gomeo2o.service.vshop.biz;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.service.vshop.dao.VshopInfoDescDao;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description:  美店主门店归属业务处理类
 * @author: chenchen-ds6
 * @date: 2019年10月11日 下午22:16:54
 */
@Slf4j
@Service("vshopInfoDescBiz")
public class VshopInfoDescBiz {
    @Autowired
    private VshopInfoDescDao vshopInfoDescDao;

    /**
     * 获取vshopInfoDesc 接口下架，不再维护desc数据，统一返回A00V
     * @param userId
     * @return
     */
    public VshopInfoDesc getVshopInfoDesc(Long userId){
        VshopInfoDesc vshopInfoDesc = new VshopInfoDesc();
        vshopInfoDesc.setUserId(userId);
        vshopInfoDesc.setStoreCode("A00V");
        vshopInfoDesc.setOrganization("1001");
        return vshopInfoDesc;
    }


    public List<VshopInfoDesc> queryVshopInfoDescUnionVshopInfoByParam(Map<String, Object> map) {
        return vshopInfoDescDao.queryVshopInfoDescUnionVshopInfoByParam(map);
    }

    public Long queryCountVshopInfoDescUnionVshopInfoByParam(Map<String, Object> map) {
        return vshopInfoDescDao.queryCountVshopInfoDescUnionVshopInfoByParam(map);
    }

}
