package com.gomeo2o.service.vshop.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopVipCouponProject;
import com.gomeo2o.service.vshop.dao.VshopVipCouponProjectDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopVipCouponProjectDao")
public class VshopVipCouponProjectDaoImpl extends CBaseDaoImpl<VshopVipCouponProject> implements VshopVipCouponProjectDao {

    private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopVipCouponProjectDaoImpl.";
    @Override
    public List<VshopVipCouponProject> queryEffectiveVipCouponProject() {
        return this.getSessionTemplate().selectList(baseSQL+"queryEffectiveVipCouponProject");
    }

    @Override
    public void reduceGiftStockCount(Long id,Integer count,Integer f) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("id", id);
        paramMap.put("count", count);
        paramMap.put("f", f);
        this.getSessionTemplate().update(baseSQL+"reduceGiftStockCount",paramMap);
    }

    @Override
    public List<VshopVipCouponProject> queryListByCondition(Map<String, Object> params) {
        return this.getSessionTemplate().selectList(baseSQL+"queryListByCondition",params);
    }

    @Override
    public List<VshopVipCouponProject> getAllEffectiveProject() {
        return this.getSessionTemplate().selectList(baseSQL+"getAllEffectiveProject");
    }
}
