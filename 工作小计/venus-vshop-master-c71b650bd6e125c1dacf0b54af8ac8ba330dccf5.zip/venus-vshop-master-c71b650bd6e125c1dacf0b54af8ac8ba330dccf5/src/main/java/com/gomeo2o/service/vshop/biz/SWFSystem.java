package com.gomeo2o.service.vshop.biz;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cn.com.gome.swf.dubbo.SwfService;
import cn.com.gome.swf.model.SwfResultDto;
import com.gome.diamond.annotations.DiamondValue;

/**
 * @author syncwt
 * @version V1.0
 * @Description: TODO
 * @date ${date} ${time}
 */

/**
 * SWF铭感词过滤系统
 */
@Component
public class SWFSystem {

    @Autowired
    private SwfService swfService;

    @DiamondValue("${swf_token}")
    private String token;

    @DiamondValue("${swf_type}")
    private String type;

    /**
     * 过滤铭感文字
     * @param arg
     * @return
     */
    public String handleWords(String arg){
        if(StringUtils.isEmpty(arg)){
            return arg;
        }
        System.out.println(token);
        arg = arg.replaceAll("<", "&lt;");
        arg = arg.replaceAll(">", "&gt;");
        String content=arg;
        String flag="1";
        SwfResultDto swfResultDto = swfService.checkWords(content,type,flag,token);
        if(swfResultDto!=null&& StringUtils.isNotEmpty(swfResultDto.getSensitiveWords())){
            String sensitiveWords = swfResultDto.getSensitiveWords();
            String[] words = sensitiveWords.split(",");
            for(int i=0;i<words.length;i++){
                StringBuffer replace=new StringBuffer("*");
                while(replace.length()<words[i].length()){
                    replace.append("*");
                }
                arg = arg.replace(words[i],replace);
            }
        }
        return arg;
    }
}
