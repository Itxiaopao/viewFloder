package com.gomeo2o.service.vshop.dao;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopStores;

public interface VshopStoresDao extends BaseDao<VshopStores> {

    public VshopStores queryVshopStoresById(Long vshopId);

    public int update(VshopStores vshopStores);
}
