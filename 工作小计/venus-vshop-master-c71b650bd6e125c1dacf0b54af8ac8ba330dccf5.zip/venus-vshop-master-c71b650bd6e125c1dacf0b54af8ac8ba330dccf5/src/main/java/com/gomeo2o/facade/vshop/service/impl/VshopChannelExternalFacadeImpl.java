package com.gomeo2o.facade.vshop.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.dragon.mds.client.dto.gcc.GomeStoreFull;
import com.gome.dragon.mds.client.gcc.GomeStoreFullClient;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.dto.GomeStore;
import com.gomeo2o.facade.vshop.entity.VshopChannelInfo;
import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantInfo;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.facade.vshop.service.VshopChannelExternalFacade;
import com.gomeo2o.service.vshop.biz.ChannelMshopBiz;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Description: 渠道美店接口 
 * @author: lixilong
 * @date: 2018年6月5日 下午4:20:00
 */
@Slf4j
@Service("vshopChannelExternalFacade")
public class VshopChannelExternalFacadeImpl implements VshopChannelExternalFacade {

    @Autowired
    private GomeStoreFullClient gomeStoreFullClient;
    
    @Autowired
    private ChannelMshopBiz channelMshopBiz;
    
    @Override
    public CommonResultEntity<List<GomeStore>> getChannelAndStoreByArea(String areaId, int number) {
        CommonResultEntity<List<GomeStore>> result = new CommonResultEntity<List<GomeStore>>();
        log.info("getChannelAndStoreByArea params is areaId:{},number:{}",areaId,number);
        if (StringUtils.isBlank(areaId)) {
            log.warn("warn! getChannelAndStoreByArea param areaId is null!");
            throw VshopException.PARAM_IS_NULL;
        }
        if (number == 0) {
            number =999999;
        }
        List<GomeStore> channelAndStoreList = new ArrayList<GomeStore>();
        List<com.gome.dragon.mds.client.dto.gomestore.GomeStore> storeFull = gomeStoreFullClient.getStoreFullByArea(areaId, number);
        if (storeFull == null) {
            log.info("getStoreFullByArea result is empty");
        } else {
            log.info("getStoreFullByArea result size : {}",storeFull.size());
            boolean isCopyFailed = false;
            for (com.gome.dragon.mds.client.dto.gomestore.GomeStore store:storeFull) {
                GomeStore vshopStore = new GomeStore();
                try {
                    BeanUtils.copyProperties(vshopStore, store);
                } catch (Exception e) {
                    isCopyFailed = true;
                    log.error("copy happened error! message is {}",e);
                    continue;
                }
                vshopStore.setType(0);
                channelAndStoreList.add(vshopStore);
            }
            if (isCopyFailed) {
                log.warn("getChannelAndStoreByArea copy happend error,size is {}",storeFull.size() - channelAndStoreList.size());
            }
        }
        
        List<GomeStore> channelShops = channelMshopBiz.getChannelShops(areaId, number);
        if (channelShops == null || channelShops.isEmpty()) {
            log.info("getChannelShops result is empty,areaId is {}",areaId);
        } else {
            channelAndStoreList.addAll(channelShops);
        }
        result.setBusinessObj(channelAndStoreList);
        return result;
    }

    @Override
    public List<GomeStore> getChannelShopByPosition(String lng, String lat,int number) {
        log.info("getChannelShopByPosition params is lng:{},lat:{},number:{}",lng,lat,number);
        if (number == 0) {
            number =999999;
        }
        return channelMshopBiz.getChannelShopByPosition(lng, lat, number);
    }

    @Override
    public GomeStore getChannelShopByStoreCode(String storeCode) {
        if ("QDMD".equals(storeCode)) {
            return channelMshopBiz.getChannelInfo2Store(storeCode);
            
        } else {
            GomeStore gomeStore = new GomeStore();
            GomeStoreFull storeFull = gomeStoreFullClient.getGomeStoreByStoreId(storeCode);
            if (storeFull == null) {
                return channelMshopBiz.getChannelInfo2Store(storeCode);
            }
            gomeStore.setStoreCode(storeFull.getStoreId());
            gomeStore.setChannelType(0);
            gomeStore.setName(storeFull.getStoreName());
            return gomeStore;
        }
    }

    @Override
    public VshopChannelMerchantInfo getChannelMerchantByStoreCode(String storeCode) {
        return channelMshopBiz.getChannelMerchantByStoreCode(storeCode);
    }
    
    @Override
    @Deprecated
    public CommonResultEntity<GomeStore> getChannelShopByStoreId(Long channelId) {
        CommonResultEntity<GomeStore> result = new CommonResultEntity<>();
        GomeStore gomeStore = new GomeStore();
        VshopChannelInfo storeInfo = channelMshopBiz.getVshopChannelInfoById(channelId);
        if (storeInfo != null) {
            try {
                BeanUtils.copyProperties(gomeStore, storeInfo);
            } catch (Exception e) {
            }
            if (storeInfo.getProvinceId() != null) {
                gomeStore.setProvinceCode(storeInfo.getProvinceId().toString());
            }
            if (storeInfo.getCityId() != null) {
                gomeStore.setCityCode(storeInfo.getCityId().toString());
            }
            if (storeInfo.getCountyId() != null) {
                gomeStore.setCountyCode(storeInfo.getCountyId().toString());
            }
            result.setBusinessObj(gomeStore);
            return result;
        }
        GomeStoreFull storeFull = gomeStoreFullClient.getGomeStoreByStoreId(channelId.toString());
        if (storeFull == null) {
            return null;
        }
        gomeStore.setGomeStoreId(storeFull.getStoreId());
        gomeStore.setChannelType(0);
        gomeStore.setName(storeFull.getStoreName());
        result.setBusinessObj(gomeStore);
        return result;
    }

}
