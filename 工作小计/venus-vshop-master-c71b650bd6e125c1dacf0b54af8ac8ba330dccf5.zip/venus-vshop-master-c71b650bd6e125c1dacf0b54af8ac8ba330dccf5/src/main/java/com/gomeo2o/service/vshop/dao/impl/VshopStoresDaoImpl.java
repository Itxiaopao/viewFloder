package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopStores;
import com.gomeo2o.service.vshop.dao.VshopStoresDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopStoresDao")
public class VshopStoresDaoImpl extends CBaseDaoImpl<VshopStores> implements VshopStoresDao {

	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopStoresDaoImpl.";

	@Override
	public VshopStores queryVshopStoresById(Long vshopId) {
		return this.getSessionTemplate().selectOne(baseSQL+"queryVshopStoresById",vshopId);
	}

	@Override
	public int update(VshopStores vshopStores) {
		return this.getSessionTemplate().update(baseSQL+"update",vshopStores);
	}
}
