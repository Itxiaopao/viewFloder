package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;

public interface VshopInfoDescDao extends BaseDao<VshopInfoDesc> {

	public void insertVshopInfoDesc(VshopInfoDesc vshopInfoDesc);
	
	public void updateVshopInfoDesc(VshopInfoDesc vshopInfoDesc);

	public List<VshopInfoDesc> queryVshopInfoDescByMap(Map<String,Object> map);

	public List<VshopInfoDesc> queryVshopInfoDescUnionVshopInfoByParam(Map<String,Object> map);

	public Long queryCountVshopInfoDescUnionVshopInfoByParam(Map<String, Object> map);

	void insertOrUpdateVshopInfoDesc(VshopInfoDesc vshopInfoDesc);
}
