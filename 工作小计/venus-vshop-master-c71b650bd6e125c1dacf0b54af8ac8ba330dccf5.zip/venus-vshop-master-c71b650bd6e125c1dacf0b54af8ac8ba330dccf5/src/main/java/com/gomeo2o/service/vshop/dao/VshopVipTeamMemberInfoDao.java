package com.gomeo2o.service.vshop.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopVipTeamMemberInfo;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
public interface VshopVipTeamMemberInfoDao extends BaseDao<VshopVipTeamMemberInfo>{
	
	public Integer countVshopVipTeamMemberByTutorUserId(Map<String, Object> paramMap);

	public List<VshopVipTeamMemberInfo> getVshopVipTeamMembers(PageParam pageParam,Long tutorUserId);
	
	public Long queryTutorUserIdByMemberUserId(Long memberUserId);

	/**
	 * 退出团队
	 * @param originMemberUserId  原成员ID
	 * @param invaliaidTime 退团时间
	 * @return
	 */
	Integer quitVipTeamMember(Long originMemberUserId, Date invaliaidTime);

}