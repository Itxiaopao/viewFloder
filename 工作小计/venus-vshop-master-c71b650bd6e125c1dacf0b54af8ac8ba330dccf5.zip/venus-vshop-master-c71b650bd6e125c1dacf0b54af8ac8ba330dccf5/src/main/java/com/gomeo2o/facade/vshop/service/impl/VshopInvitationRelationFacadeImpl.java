package com.gomeo2o.facade.vshop.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeo2o.facade.vshop.service.VshopInvitationRelationFacade;
import com.gomeo2o.service.vshop.biz.VshopInvitationRelationBiz;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopInvitationRelationFacade")
public class VshopInvitationRelationFacadeImpl implements VshopInvitationRelationFacade{
	
	
	@Autowired
	private VshopInvitationRelationBiz vshopInvitationRelationBiz;

	@Override
	public CommonResultEntity<Long> createVshopInvitationRelation(
			VshopInvitationRelation vshopInvitationRelation) {
		CommonResultEntity<Long> cre = new CommonResultEntity<Long>();
		Long id = vshopInvitationRelationBiz.createVshopInvitationRelation(vshopInvitationRelation);
//		System.out.println(id);
		cre.setBusinessObj(id);
		return cre;
	}

	@Override
	public CommonResultEntity<List<VshopInvitationRelation>> getVshopInvitationRelation(
			PageParam pageParam,Map<String, Object> map) {
		CommonResultEntity<List<VshopInvitationRelation>> cre = new CommonResultEntity<List<VshopInvitationRelation>>();
		List<VshopInvitationRelation> list = vshopInvitationRelationBiz.getVshopInvitationRelation(pageParam,map);
		cre.setBusinessObj(list);
		return cre;
	}

	@Override
	public CommonResultEntity<Integer> countVshopInvitationRelation(Map<String, Object> map) {
		CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
		Integer count = vshopInvitationRelationBiz.countVshopInvitationRelation(map);
		cre.setBusinessObj(count);
		return cre;
	}

}
