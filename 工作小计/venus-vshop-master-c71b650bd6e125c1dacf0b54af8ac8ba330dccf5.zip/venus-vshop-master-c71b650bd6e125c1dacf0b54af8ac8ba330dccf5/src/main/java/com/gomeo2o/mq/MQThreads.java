/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年6月3日 下午5:12:53
 */
package com.gomeo2o.mq;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @Description: 定长的阻塞队列（重写原有的线程池的ThreadPoolExecutor()方法）
 * @author: guowenbo
 * @date: 2015年6月3日 下午5:12:53
 */
public class MQThreads{

	//线程数
	private static int nThreads = 50;
	//最大数
	private static int MAX_QUEUQ_SIZE = 2000;
	
	
	//返回定长的阻塞队列（风险：消息处理的顺序问题）
	public static ExecutorService newFixedThreadPool() {
        return new ThreadPoolExecutor(nThreads,
  	          nThreads, 0L, TimeUnit.MILLISECONDS,
  	          new ArrayBlockingQueue<Runnable>(MAX_QUEUQ_SIZE),
  	          new ThreadPoolExecutor.CallerRunsPolicy());
    }
	
}
