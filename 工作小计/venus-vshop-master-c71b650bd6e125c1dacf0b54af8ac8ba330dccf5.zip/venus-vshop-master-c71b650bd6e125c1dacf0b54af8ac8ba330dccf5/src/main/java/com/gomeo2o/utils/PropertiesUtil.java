package com.gomeo2o.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class PropertiesUtil {
	/**
	 * 
	 * @Description: 通过key获取不通的配置文件
	 * @author: zhaoxingxing
	 * @date: 2017年2月15日 下午4:19:35
	 * @param key
	 * @return
	 */
	public static String getProperTies(String key) {
		Properties prop = new Properties();
		InputStream fis = null;
		String property = null;
		try {
			fis = Thread.currentThread().getContextClassLoader().getResourceAsStream("app.properties");
			prop.load(fis);
			property = prop.getProperty(key).trim();
		} catch (IOException e) {
			log.error("getProperties fail, the key is:{} exception is: ", key, e);
		}
		return property;
	}
}
