/**
 * gomeo2o.com
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: 美店接口层
 * @author: guowenbo
 * @date: 2015年4月14日 下午12:08:36
 */
package com.gomeo2o.facade.vshop.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.gome.mobile.commerce.member.model.ResultDTO;
import com.gome.mobile.commerce.member.staff.facade.StaffMshopFacade;
import com.gome.mobile.commerce.member.staff.model.StaffMshopModel;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.VshopCategoryDto;
import com.gomeo2o.facade.vshop.entity.VshopCategory;
import com.gomeo2o.facade.vshop.entity.VshopCommission;
import com.gomeo2o.facade.vshop.entity.VshopDistributionItem;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopTsMarkert;
import com.gomeo2o.facade.vshop.enums.ProductStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopTypeEnum;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.service.vshop.biz.SWFSystem;
import com.gomeo2o.service.vshop.biz.VshopCategoryBiz;
import com.gomeo2o.service.vshop.biz.VshopDistributionItemBiz;
import com.gomeo2o.service.vshop.biz.VshopInfoBiz;
import com.gomeo2o.service.vshop.biz.VshopInfoDescBiz;
import com.gomeo2o.service.vshop.biz.VshopTsMarkertBiz;
import com.gomeo2o.utils.CodeUtil;
import com.gomeo2o.utils.JsonUtils;
import com.gomeo2o.utils.ValidateUtils;
import com.google.common.base.Strings;
import lombok.extern.slf4j.Slf4j;

/**
 * @Description: 微店
 * @author: guowenbo
 * @date: 2015年4月14日 下午12:08:36
 */
@Slf4j
@Service("vshopFacade")
public class VshopFacadeImpl implements VshopFacade {

    @Autowired VshopInfoBiz vshopInfoBiz;
    @Autowired VshopInfoDescBiz vshopInfoDescBiz;
    @Autowired
    private VshopCategoryBiz vshopCategoryBiz;
    @Autowired
    private VshopDistributionItemBiz vshopDistributionItemBiz;
    @Autowired
    private VshopTsMarkertBiz vshopTsMarkertBiz;
    @Autowired
    @Lazy
    private StaffMshopFacade staffMshopFacade;
    @Autowired
    private SWFSystem sWFSystem;

    /**
     * @Description: 创建微店
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:09:27
     * @param vshopInfoEntity
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<String> createVshop(VshopInfo vshopInfoEntity) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        Integer vshopIdentity = vshopInfoEntity.getVshopIdentity();
        if(vshopIdentity==null){
            vshopInfoEntity.setVshopIdentity(1);
        }//设置默认值
        // 校验共有参数
        ValidateUtils.notNull(vshopInfoEntity, "userId", "vshopName");
        // 校验用户是否存在微店
        VshopInfo vshopInfoExist = vshopInfoBiz.queryVshopByuserId(vshopInfoEntity.getUserId());
        boolean isExists = (vshopInfoExist!=null);
        vshopInfoEntity.setVshopStatus(VshopStatusEnum.JINGYING.getValue());
        // 店铺logo
        if (StringUtils.isBlank(vshopInfoEntity.getVshopIcon())) {
            vshopInfoEntity.setVshopIcon(getVshopDefaultLogo());
        }
        if (vshopInfoEntity.getVersion() == 0) {// 0：isSkip 不跳过 校验店铺名称
            // 校验店铺名称是否重复
            vshopInfoBiz.queryVshopName(isExists ? vshopInfoExist.getVshopId() : 0, vshopInfoEntity.getVshopName());
        }
        //敏感词过滤
        log.info("敏感词过滤start：vshopName={},vshopDesc={}",vshopInfoEntity.getVshopName(),vshopInfoEntity.getVshopDesc());
        this.checkString(vshopInfoEntity);
        log.info("敏感词过滤end：vshopName={},vshopDesc={}",vshopInfoEntity.getVshopName(),vshopInfoEntity.getVshopDesc());
        if (isExists) {
            //更新美店
            vshopInfoEntity.setVshopId(vshopInfoExist.getVshopId());
            vshopInfoBiz.updateVshop(vshopInfoEntity);
            cre.setBusinessObj(String.valueOf(vshopInfoExist.getVshopId()));
        } else {
            //shop-servlet -》 MDC获取美店来源
            String source = MDC.get("AppId");
            if(StringUtils.isNotBlank(source)){
                vshopInfoEntity.setSource(source.substring(0,3));
            }
            long vshopId = vshopInfoBiz.createVshop(vshopInfoEntity);
            cre.setBusinessObj(String.valueOf(vshopId));
        }
        return cre;
    }

    /**
     * 过滤店铺名称和店铺介绍
     * @param vshopInfoEntity
     */
    private void checkString(VshopInfo vshopInfoEntity) {
        String vshopName = sWFSystem.handleWords(vshopInfoEntity.getVshopName());
        vshopInfoEntity.setVshopName(vshopName);
        String vshopDesc = sWFSystem.handleWords(vshopInfoEntity.getVshopDesc());
        vshopInfoEntity.setVshopDesc(vshopDesc);
    }

    /**
     * @Description: 更新微店信息
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:09:27
     * @param vshopInfoEntity
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<String> updateVshop(VshopInfo vshopInfoEntity) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        // 主键不能为空
        ValidateUtils.notNull(vshopInfoEntity, "vshopId");
        //校验美店名称是否重复
        if (StringUtils.isNotBlank(vshopInfoEntity.getVshopName())) {
            vshopInfoBiz.queryVshopName(vshopInfoEntity.getVshopId(), vshopInfoEntity.getVshopName());
        }
        //校验手机号是否重复
        if (StringUtils.isNotBlank(vshopInfoEntity.getPhoneNo())) {
            vshopInfoBiz.queryVshopPhoneNo(vshopInfoEntity.getVshopId(), vshopInfoEntity.getPhoneNo());
        }
        //敏感词过滤
        log.info("敏感词过滤start：vshopName={},vshopDesc={}",vshopInfoEntity.getVshopName(),vshopInfoEntity.getVshopDesc());
        this.checkString(vshopInfoEntity);
        log.info("敏感词过滤end：vshopName={},vshopDesc={}",vshopInfoEntity.getVshopName(),vshopInfoEntity.getVshopDesc());
        vshopInfoBiz.updateVshop(vshopInfoEntity);
        return cre;
    }

    /**
     * @Description: 判断店铺名称是否已存在
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:09:27
     * @param vshopName
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<Boolean> queryVshopName(String vshopName) {
        CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
        // 判断店铺名称是否已存在
        boolean flag = vshopInfoBiz.queryVshopNameByApp(vshopName);
        cre.setBusinessObj(flag);
        return cre;
    }

    /**
     * @Description: xpop平台更新校验店铺名
     * @author: guowenbo
     * @date: 2015年7月14日 上午11:16:05
     * @param userId
     * @param vshopName
     * @return
     */
    @Override
    public CommonResultEntity<Boolean> queryVshopName(long userId, String vshopName) {
        CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
        // 判断店铺名称是否已存在true：可用，false：不可用
        boolean flag = vshopInfoBiz.queryVshopNameByApp(userId, vshopName);
        cre.setBusinessObj(flag);
        return cre;
    }

    /**
     * @Description: 根据用户id查询微店信息
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:09:27
     * @param userId
     * @return CommonResultEntity<VshopInfo>
     */
    @Override
    public CommonResultEntity<VshopInfo> queryVshopByuserId(String userId) {
        if(null == userId || "".equals(userId)){
            log.info("用户ID为空{}", userId);
            throw VshopException.PARAM_IS_NULL;
        }
        CommonResultEntity<VshopInfo> cre = new CommonResultEntity<VshopInfo>();
        VshopInfo info = vshopInfoBiz.queryVshopByuserId(Long.parseLong(userId));
        cre.setBusinessObj(info);
        return cre;
    }

    @Override
    public CommonResultEntity<List<VshopInfo>> batchQueryVshopByUserIds(Set<Long> userIds) {
        CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
        if (CollectionUtils.isEmpty(userIds)) {
            throw VshopException.PARAM_IS_NULL;
        }
        try {
            List<VshopInfo> list = new ArrayList<>(userIds.size());
            for (Long userId : userIds) {
                if (userId == null) { continue; }
                VshopInfo vshopInfo = vshopInfoBiz.queryVshopByuserId(userId);
                if (vshopInfo == null) { continue; }
                list.add(vshopInfo);
            }
            cre.setBusinessObj(list);
        } catch (Exception e) {
            log.error("vshopGcache.batch error,userIds:"+userIds);
        }
        return cre;

    }

    /**
     * @Description: 通过微店id查询微店信息
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:09:27
     * @param vshopId
     * @return CommonResultEntity<VshopInfo>
     */
    @Override
    public CommonResultEntity<VshopInfo> queryVshopById(long vshopId) {
        VshopInfo vshopInfo = vshopInfoBiz.queryVshopById(vshopId);
        CommonResultEntity<VshopInfo> cre = new CommonResultEntity<VshopInfo>();
        cre.setBusinessObj(vshopInfo);
        return cre;
    }

    /**
     * @Description: 创建分类
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:40:47
     * @param vshopId
     * @param vshopCategoryName
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<Long> createVshopCategory(long vshopId, String vshopCategoryName) {
        CommonResultEntity<Long> cre = new CommonResultEntity<Long>();
        if (Strings.isNullOrEmpty(vshopCategoryName)) {
            log.error("店铺{}创建分类vshopCategoryName参数不能为为空！", vshopId);
            throw VshopException.PARAM_IS_NULL;
        }
        // 校验店铺存在与否
        vshopInfoBiz.checkVshop(vshopId);
        VshopCategory category = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        if (category == null) {
            //首次创建分类
            category = new VshopCategory();
            List<VshopCategoryDto> dtoList = new ArrayList<VshopCategoryDto>();
            VshopCategoryDto dto = new VshopCategoryDto();
            dto.setCategoryId(1);
            dto.setCategoryName(vshopCategoryName);
            dto.setOrder(1);
            dtoList.add(dto);
            category.setVshopId(vshopId);
            category.setVcategories(JsonUtils.toJson(dtoList));
            vshopCategoryBiz.createVshopCategory(category);
            cre.setBusinessObj(dto.getCategoryId());
            return cre;
        }
        List<VshopCategoryDto> agoList = JsonUtils.toList(category.getVcategories(), new VshopCategoryDto());
        Integer maxOrderId = 0;
        for (VshopCategoryDto categoryDto : agoList) {
            //判断分类是否重复，找到最大的order
            if (vshopCategoryName.equals(categoryDto.getCategoryName())) {
                throw VshopException.CATEGORYNAME_IS_EXIST;
            }
            if (categoryDto.getOrder() != null && categoryDto.getOrder() > maxOrderId) {
                maxOrderId = categoryDto.getOrder();
            }
        }
        long maxCtgyId = 0L;
        //处理分类中没有order的，重新赋值order，order存在的不做处理
        for (VshopCategoryDto categoryDto : agoList) {
            if (categoryDto.getOrder() == null) {
                categoryDto.setOrder(++maxOrderId);
            }
            if (categoryDto.getCategoryId() > maxCtgyId) {
                maxCtgyId = categoryDto.getCategoryId();
            }
        }
        VshopCategoryDto dto = new VshopCategoryDto();
        dto.setCategoryId(maxCtgyId + 1);
        dto.setCategoryName(vshopCategoryName);
        dto.setOrder(maxOrderId + 1);
        agoList.add(dto);
        category.setVshopId(vshopId);
        category.setVcategories(JsonUtils.toJson(agoList));
        vshopCategoryBiz.updateVshopCategory(category);
        cre.setBusinessObj(dto.getCategoryId());
        return cre;
    }

    /**
     * @Description: 更新分类
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:40:47
     * @param vcategoryId
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<String> updateVshopCategory(long vshopId, long vcategoryId, String vshopCategoryName, Boolean isRecommend) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        if (Strings.isNullOrEmpty(vshopCategoryName) || vcategoryId == 0) {
            log.error("店铺{}更新分类vshopCategoryName参数不能为为空！分类id参数：{}不能为0", vshopId, vcategoryId);
            throw VshopException.PARAM_IS_NULL;
        }
        // 校验店铺存在与否
        vshopInfoBiz.checkVshop(vshopId);
        // 校验分类存在与否
        vshopCategoryBiz.checkCategory(vshopId, vcategoryId);
        VshopCategory category = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        Long id;
        if (category != null) {
            List<VshopCategoryDto> agoList = JsonUtils.toList(category.getVcategories(), new VshopCategoryDto());
            List<VshopCategoryDto> nowList = new ArrayList<VshopCategoryDto>();
            id = 1L;
            for (VshopCategoryDto vshopCategoryDto : agoList) {
                if (vshopCategoryName.equals(vshopCategoryDto.getCategoryName()) && vcategoryId != vshopCategoryDto.getCategoryId()) {
                    throw VshopException.CATEGORYNAME_IS_EXIST;
                }
                if (vcategoryId == vshopCategoryDto.getCategoryId()) {
                    VshopCategoryDto dto = new VshopCategoryDto();
                    dto.setCategoryId(vshopCategoryDto.getCategoryId());
                    dto.setCategoryName(vshopCategoryName);
                    if (isRecommend == null) {
                        dto.setIsRecommend(vshopCategoryDto.getIsRecommend());
                    } else {
                        dto.setIsRecommend(isRecommend);
                    }
                    // 新加order
                    // 处理旧数据
                    if (vshopCategoryDto.getOrder() != null) {
                        dto.setOrder(vshopCategoryDto.getOrder());
                    } else {
                        dto.setOrder(id.intValue());
                    }
                    id++;
                    nowList.add(dto);
                } else {
                    VshopCategoryDto dto = new VshopCategoryDto();
                    dto.setCategoryId(vshopCategoryDto.getCategoryId());
                    dto.setCategoryName(vshopCategoryDto.getCategoryName());
                    dto.setIsRecommend(vshopCategoryDto.getIsRecommend());
                    // 新加order
                    // 处理旧数据
                    if (vshopCategoryDto.getOrder() != null) {
                        dto.setOrder(vshopCategoryDto.getOrder());
                    } else {
                        dto.setOrder(id.intValue());
                    }
                    id++;
                    nowList.add(dto);
                }
            }
            category.setVshopId(vshopId);
            category.setVcategories(JsonUtils.toJson(nowList));
            vshopCategoryBiz.updateVshopCategory(category);
        } else {
            throw VshopException.CATEGORY_EXIST;
        }
        return cre;
    }

    /**
     * @Description: 删除分类
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:40:47
     * @param vcategoryId
     * @param vshopId
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<String> deleteVshopCategoryById(long vshopId, long vcategoryId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        if (vcategoryId == 0) {
            log.error("店铺{}删除分类，分类id参数：{}不能为0", vshopId, vcategoryId);
            throw VshopException.PARAM_IS_NULL;
        }
        // 校验店铺存在与否
        vshopInfoBiz.checkVshop(vshopId);
        // 校验分类存在与否
        vshopCategoryBiz.checkCategory(vshopId, vcategoryId);
        VshopCategory category = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        Long id;
        if (category != null) {
            List<VshopCategoryDto> agoList = JsonUtils.toList(category.getVcategories(), new VshopCategoryDto());
            List<VshopCategoryDto> nowList = new ArrayList<VshopCategoryDto>();
            List<Long> modifyCategories = new ArrayList<Long>();
            id = 1L;
            for (VshopCategoryDto vshopCategoryDto : agoList) {
                if (vcategoryId != vshopCategoryDto.getCategoryId()) {
                    VshopCategoryDto dto = new VshopCategoryDto();
                    dto.setCategoryId(vshopCategoryDto.getCategoryId());
                    dto.setCategoryName(vshopCategoryDto.getCategoryName());
                    dto.setIsRecommend(vshopCategoryDto.getIsRecommend());
                    // 新加order
                    // 处理旧数据
                    if (vshopCategoryDto.getOrder() != null) {
                        dto.setOrder(vshopCategoryDto.getOrder());
                    } else {
                        dto.setOrder(id.intValue());
                    }
                    id++;
                    nowList.add(dto);
                    if (vcategoryId < vshopCategoryDto.getCategoryId()) {
                        modifyCategories.add(vshopCategoryDto.getCategoryId());
                    }
                }
            }
            category.setVshopId(vshopId);
            category.setVcategories(JsonUtils.toJson(nowList));
            vshopCategoryBiz.deleteVshopCategory(category, modifyCategories, vcategoryId);
        } else {
            throw VshopException.CATEGORY_EXIST;
        }
        return cre;
    }

    /**
     * @Description: 通过微店id查询微店分类列表
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:40:47
     * @param vshopId
     * @return CommonResultEntity<List<VshopCategoryDto>>
     */
    @Override
    public CommonResultEntity<List<VshopCategoryDto>> queryListVshopCategoryByVshopId(long vshopId) {
        CommonResultEntity<List<VshopCategoryDto>> cre = new CommonResultEntity<List<VshopCategoryDto>>();
        VshopCategory vshopCategory = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        if (vshopCategory != null && vshopCategory.getVcategories() != null) {
            List<VshopCategoryDto> list = JsonUtils.toList(vshopCategory.getVcategories(), new VshopCategoryDto());
            if (list.size() != 0 && list.get(0).getOrder() != null)
                Collections.sort(list);
            cre.setBusinessObj(list);
        }
        return cre;
    }

    /**
     * @Description: 通过微店id查询微店推荐分类列表
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:40:47
     * @param vshopId
     * @return CommonResultEntity<List<VshopCategoryDto>>
     */
    @Override
    public CommonResultEntity<List<VshopCategoryDto>> queryRecommendListVshopCategoryByVshopId(long vshopId) {
        CommonResultEntity<List<VshopCategoryDto>> cre = new CommonResultEntity<List<VshopCategoryDto>>();
        VshopCategory vshopCategory = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        List<VshopCategoryDto> recommendList = new ArrayList<VshopCategoryDto>();
        if (vshopCategory != null && vshopCategory.getVcategories() != null) {
            List<VshopCategoryDto> list = JsonUtils.toList(vshopCategory.getVcategories(), new VshopCategoryDto());
            if (list.size() != 0 && list.get(0).getOrder() != null)
                Collections.sort(list);
            for (VshopCategoryDto dto : list) {
                if (dto.getIsRecommend() != null && dto.getIsRecommend()) {
                    recommendList.add(dto);
                }
            }
            cre.setBusinessObj(recommendList);
        }
        return cre;
    }

    /**
     * @Description:添加分销商品
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param vshopDistributionItem
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<String> createDistributionItem(VshopDistributionItem vshopDistributionItem) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        // 校验参数
        ValidateUtils.notNull(vshopDistributionItem, "itemId", "vshopId");
        // 校验店铺
        vshopInfoBiz.checkVshop(vshopDistributionItem.getVshopId());
        // 校验微店下该商品
        //vshopDistributionItemBiz.checkProduct(vshopDistributionItem.getVshopId(), vshopDistributionItem.getItemId(),vshopDistributionItem.getSkuId(), 1);
        // 默认商品：上架
        vshopDistributionItem.setStatus(1);
        //处理Identification
        if(vshopDistributionItem.getIdentification()==null || !"offline".equals(vshopDistributionItem.getIdentification().toLowerCase())){
            vshopDistributionItem.setIdentification("online");
        }
        // long类型，未set默认就是未分类
        vshopDistributionItemBiz.createDistributionItem(vshopDistributionItem);
        return cre;
    }

    /**
     * @Description:更新分销商品
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param vshopDistributionItem
     * @return CommonResultEntity<String>
     */

    @Override
    public CommonResultEntity<String> updateDistributionItem(VshopDistributionItem vshopDistributionItem) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        // 校验参数
        ValidateUtils.notNull(vshopDistributionItem, "vshopId", "itemId");
        // 校验店铺
        vshopInfoBiz.checkVshop(vshopDistributionItem.getVshopId());
        // 校验微店下该商品
        vshopDistributionItemBiz.checkProduct(vshopDistributionItem.getVshopId(), vshopDistributionItem.getItemId(),
                vshopDistributionItem.getSkuId(), 2);
        vshopDistributionItemBiz.updateDistributionItem(vshopDistributionItem);
        return cre;
    }

    /**
     * @Description 批量更新分销商品（所属分类更新）
     * @author guowenbo
     * @date 2016年2月17日 上午11:14:59
     * @param itemIds
     * @return
     */
    @Override
    public CommonResultEntity<String> updateDistributionItems(List<String> itemIds, long vshopId, long vcategoryId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        // 校验店铺
        vshopInfoBiz.checkVshop(vshopId);
        // 校验分类
        vshopCategoryBiz.checkCategory(vshopId, vcategoryId);
        vshopDistributionItemBiz.updateDistributionItems(itemIds, vshopId, vcategoryId);
        return cre;
    }

    /**
     * @Description: 删除分销商品
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param itemId
     * @param vshopId
     * @return CommonResultEntity<String>
     */
    @Override
    public CommonResultEntity<String> deleteDistributionItem(String itemId, String skuId, long vshopId) {
        // 校验店铺
        vshopInfoBiz.checkVshop(vshopId);
        // 校验微店下该商品
        vshopDistributionItemBiz.checkProduct(vshopId, itemId, skuId, 2);
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        try {
            vshopDistributionItemBiz.deleteDistributionItem(itemId, skuId, vshopId);
        } catch (VshopException e) {
            cre.setMessage(e.getMessage());
            cre.setCode(e.getCode());
        }
        return cre;
    }

    /**
     * @Description 批量删除分销商品
     * @author guowenbo
     * @date 2016年2月17日 上午11:02:34
     * @param itemIds
     * @param vshopId
     * @return
     */
    @Override
    public CommonResultEntity<String> deleteDistributionItems(List<String> itemIds, long vshopId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        if(itemIds != null && itemIds.size() > 0){
            // 校验店铺
            vshopInfoBiz.checkVshop(vshopId);
            vshopDistributionItemBiz.deleteDistributionItems(itemIds, vshopId);
        }
        return cre;
    }

    /**
     * @Description: 通过微店id查找微店下商品数量
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param vshopId
     * @param status
     *            (查询指定的商品状态，为空默认查询上架的，商品状态：0下架，1上架，2冻结,多个以逗号间隔，如："0,1,2")
     * @return
     */
    @Override
    public CommonResultEntity<Integer> queryProductCountByVshopId(long vshopId, String status) {
        if (Strings.isNullOrEmpty(status)) {
            status = "1";
        }
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryProductCountByVshopId(vshopId, status));
        return cre;
    }

    /**
     * @Description: 通过分类id查询分类下所有商品列表
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param vcategoryId
     * @param vshopId
     * @param status
     *            (查询指定的商品状态，为空默认查询上架的，商品状态：0下架，1上架，2冻结,多个以逗号间隔，如："0,1,2")
     * @return CommonResultEntity<List<VshopProductadd>>
     */
    @Override
    public CommonResultEntity<List<VshopDistributionItem>> queryListProductByCategoryId(PageParam pageParam, String status, long vcategoryId,
            long vshopId) {
        CommonResultEntity<List<VshopDistributionItem>> cre = new CommonResultEntity<List<VshopDistributionItem>>();
        // 校验分类存在与否
        vshopCategoryBiz.checkCategory(vshopId, vcategoryId);
        if (Strings.isNullOrEmpty(status)) {
            status = "1";
        }
        cre.setBusinessObj(vshopDistributionItemBiz.queryListProductByCategoryId(pageParam, vcategoryId, vshopId, status));
        return cre;
    }

    // 610编号api暂时性数据填充
    @Override
    public CommonResultEntity<List<VshopDistributionItem>> queryListProductByCriteria(PageParam pageParam, Map<String, Object> criteria) {
        CommonResultEntity<List<VshopDistributionItem>> cre = new CommonResultEntity<List<VshopDistributionItem>>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryListProductByCriteria(pageParam, criteria));
        return cre;
    }

    @Override
    public CommonResultEntity<Integer> queryItemQuantityByCriteria(Map<String, Object> criteria) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryItemQuantityByCriteria(criteria));
        return cre;
    }

    /**
     * @Description: 根据分类id查询商品数量
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param vcategoryId
     * @param vshopId
     * @param status
     *            (查询指定的商品状态，为空默认查询上架的，商品状态：0下架，1上架，2冻结,多个以逗号间隔，如："0,1,2")
     * @return CommonResultEntity<Integer>
     */
    @Override
    public CommonResultEntity<Integer> queryItemCountByCategoryId(long vcategoryId, long vshopId, String status) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        if (Strings.isNullOrEmpty(status)) {
            status = "1";
        }
        // 校验分类存在与否
        vshopCategoryBiz.checkCategory(vshopId, vcategoryId);
        cre.setBusinessObj(vshopDistributionItemBiz.queryItemCountByCategoryId(vcategoryId, vshopId, status));
        return cre;
    }

    /**
     * @Description: 根据店铺ID获取所有商品
     * @author: guowenbo
     * @date: 2015年5月11日 下午4:59:40
     * @param vshopId
     * @return
     */
    @Override
    public CommonResultEntity<List<VshopDistributionItem>> queryListProductByVshopId(PageParam pageParam, String status, long vshopId) {
        if (Strings.isNullOrEmpty(status)) {
            status = "1";
        }
        CommonResultEntity<List<VshopDistributionItem>> cre = new CommonResultEntity<List<VshopDistributionItem>>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryListProductByVshopId(pageParam, vshopId, status));
        return cre;
    }

    /**
     * @Description: 运营后台更改店铺状态
     * @author: guowenbo
     * @date: 2015年5月13日 下午6:31:24
     * @param vshopId
     * @param vshopStatus
     * @return
     */
    @Override
    public CommonResultEntity<String> updateVshopStatus(long vshopId, Integer vshopStatus) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        vshopInfoBiz.updateVshopStatus(vshopId, vshopStatus);
        return cre;
    }

    /**
     * @Description: 运营后台批量更改店铺状态
     * @author: guowenbo
     * @date: 2015年5月14日 上午10:19:24
     * @param vshopIds
     * @param vshopStatus
     */
    @Override
    public CommonResultEntity<String> updateVshopStatus(List<Long> vshopIds, Integer vshopStatus) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        for (Long vshopId : vshopIds) {
            vshopInfoBiz.updateVshopStatus(vshopId, vshopStatus);
        }
        return cre;
    }

    /**
     * @Description: 运营后台模糊查询店铺信息(商家除外)
     * @author: guowenbo
     * @date: 2015年5月14日 上午10:25:24
     * @param criteria
     * (规则：shopId 店铺id；status 店铺状态；userId 用户id；shopName 精确店铺名称； shopNameLike 模糊店铺名称；startTime、endTime 店铺创建时间起止（String）；level 店铺等级 )
     */
    @Override
    public CommonResultEntity<List<VshopInfo>> queryVshopInfoListByCriteria(PageParam pageParam, Map<String, Object> criteria) {
        CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
        cre.setBusinessObj(vshopInfoBiz.queryVshopInfoListByCriteria(pageParam, criteria));
        return cre;
    }

    /**
     * @Description: 运营后台模糊查询店铺总记录数(商家除外)
     * @author: guowenbo
     * @date: 2015年5月15日 上午10:19:21
     * @param criteria
     * (规则：shopId 店铺id；status 店铺状态；userId 用户id；shopName 店铺名称； shopNameLike 模糊店铺名称，startTime、endTime 店铺创建时间起止（String）；level 店铺等级  )
     */
    @Override
    public CommonResultEntity<Integer> queryVshopInfoCountByCriteria(Map<String, Object> criteria) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        cre.setBusinessObj(vshopInfoBiz.queryVshopInfoCountByCriteria(criteria));
        return cre;
    }

    /**
     * @Description: 通过市ID查询微店数量
     * @author: guowenbo
     * @date: 2015年5月18日 下午4:57:44
     * @param shiId
     * @return
     */
    @Override
    public CommonResultEntity<Integer> queryVshopInfoCountByShiId(long shiId) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        int vshopStatus = VshopStatusEnum.JINGYING.getValue();
        cre.setBusinessObj(vshopInfoBiz.queryVshopInfoCountByShiId(shiId, vshopStatus));
        return cre;
    }

    /**
     * @Description: 通过市ID查询微店列表（分页）
     * @author: guowenbo
     * @date: 2015年5月26日 上午10:02:59
     * @param pageParam
     * @param shiId
     * @return
     */
    @Override
    public CommonResultEntity<List<VshopInfo>> queryVshopInfoListByShiId(PageParam pageParam, long shiId) {
        CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
        int vshopStatus = VshopStatusEnum.JINGYING.getValue();
        cre.setBusinessObj(vshopInfoBiz.queryVshopInfoListByShiId(pageParam, shiId, vshopStatus));
        return cre;
    }

    /**
     * @Description: 获取特色市场列表
     * @author: guowenbo
     * @date: 2015年5月25日 下午2:50:00
     * @return
     */
    @Override
    public CommonResultEntity<List<VshopTsMarkert>> queryTsMarkert(Integer groupId) {
        CommonResultEntity<List<VshopTsMarkert>> cre = new CommonResultEntity<List<VshopTsMarkert>>();
        cre.setBusinessObj(vshopTsMarkertBiz.queryTsMarkert(groupId));
        return cre;
    }

    /**
     * @Description: 根据productId查询商品信息
     * @author: guowenbo
     * @date: 2015年6月2日 上午11:08:21
     * @param productId
     * @param vshopId
     * @return
     */
    @Override
    public CommonResultEntity<VshopDistributionItem> queryProductByProductId(String productId, String skuId, long vshopId) {
        CommonResultEntity<VshopDistributionItem> cre = new CommonResultEntity<VshopDistributionItem>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryProductByProductId(productId, skuId, vshopId));
        return cre;
    }

    /**
     * @Description: 根据CategoryId查询分类名称
     * @author: guowenbo
     * @date: 2015年6月2日 下午2:32:15
     * @param vshopId
     * @param categoryId
     * @return
     */
    @Override
    public CommonResultEntity<VshopCategoryDto> queryCategoryByCategoryId(long vshopId, long categoryId) {
        VshopCategoryDto vshopCategoryDto = vshopCategoryBiz.queryCategoryByCategoryId(vshopId, categoryId);
        CommonResultEntity<VshopCategoryDto> cre = new CommonResultEntity<VshopCategoryDto>();
        cre.setBusinessObj(vshopCategoryDto);
        return cre;
    }

    /**
     * @Description: 通过userId,productId判断是否已经存在商品
     * @author: guowenbo
     * @date: 2015年6月13日 下午3:44:30
     * @param userId
     * @param productId
     * @return
     */
    @Override
    public CommonResultEntity<Boolean> queryProductIsExist(String userId, String productId, String skuId) {
        CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
        // 卖家版查询除删除冻结的所有商品
        StringBuffer sb = new StringBuffer();
        sb.append(ProductStatusEnum.SHANGJIA.getValue());
        // sb.append(",");
        // sb.append(ProductStatusEnum.XIAJIA.getValue());
        String status = sb.toString();
        Boolean flag = vshopDistributionItemBiz.checkProductIsExist(userId, productId, skuId, status);
        cre.setBusinessObj(flag);
        return cre;
    }

    // 获取默认店铺logo
    public String getVshopDefaultLogo() {
        return "http://gfs10.gomein.net.cn/T1YFxTByJT1R4cSCrK.png";
    }

    /**
     * @Description 查找美店数量
     * @author guowenbo
     * @date 2016年1月27日 上午11:49:49
     * @return
     */
    @Override
    public CommonResultEntity<Integer> queryMshopCount() {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        cre.setBusinessObj(vshopInfoBiz.queryMshopCount());
        return cre;
    }

    /**
     * @Description: 查询店铺内分销商品数量
     * @author: guowenbo
     * @date: 2015年8月11日 下午1:27:24
     */
    @Override
    public CommonResultEntity<Integer> queryDistributionItemCountCount(long vshopId) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryDistributionItemCountCount(vshopId));
        return cre;
    }

    /**
     * @Description: 店铺分类更新排序
     * @author: guowenbo
     * @date: 2017年01月20日 上午11:01:24
     * @param shopId
     *            店铺id
     * @param json
     *            分类串（[{"categoryId":1,"order":1},{"categoryId":2,"order":2}]）
     */
    @Override
    public CommonResultEntity<String> updateVshopCategoryByOrder(Long shopId, String json) {
        VshopCategory category = vshopCategoryBiz.queryCategoryByVshopId(shopId);
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        if (category != null) {
            List<VshopCategoryDto> agoList = JsonUtils.toList(category.getVcategories(), new VshopCategoryDto());
            List<VshopCategoryDto> list = JsonUtils.toList(json, new VshopCategoryDto());
            List<VshopCategoryDto> nowList = new ArrayList<VshopCategoryDto>();
            Map<Long, Object> ctgyMap = new HashMap<Long, Object>();
            int count = 0;
            for (VshopCategoryDto vshopCategoryDto1 : list) {
                ctgyMap.put(vshopCategoryDto1.getCategoryId(), vshopCategoryDto1);
            }
            for (VshopCategoryDto vshopCategoryDto : agoList) {

                if (ctgyMap.containsKey(vshopCategoryDto.getCategoryId())) {
                    VshopCategoryDto dto1 = (VshopCategoryDto) ctgyMap.get(vshopCategoryDto.getCategoryId());
                    VshopCategoryDto dto = new VshopCategoryDto();
                    dto.setCategoryId(vshopCategoryDto.getCategoryId());
                    dto.setCategoryName(vshopCategoryDto.getCategoryName());
                    if (dto1.getIsRecommend() == null) {
                        dto.setIsRecommend(vshopCategoryDto.getIsRecommend());
                        if (vshopCategoryDto.getIsRecommend() == true) {
                            count++;
                        }
                    } else {
                        if (dto1.getIsRecommend() == true) {
                            count++;
                        }
                        dto.setIsRecommend(dto1.getIsRecommend());
                    }
                    dto.setOrder(dto1.getOrder());
                    nowList.add(dto);
                }
            }
            // 推荐的分类不能超过5个
            if (count > 5) {
                throw VshopException.CATEGORY_INDEX_OUT_OF_BOUNDS;
            }
            category.setVshopId(shopId);
            category.setVcategories(JsonUtils.toJson(nowList));
            vshopCategoryBiz.updateVshopCategory(category);
        } else {
            throw VshopException.CATEGORY_EXIST;
        }
        return cre;
    }

    @Override
    public CommonResultEntity<String> sendMQ(long vshopId, String itemId, Integer status, long id, long popId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        VshopDistributionItem vshopDistributionItem = vshopDistributionItemBiz.queryProductByProductId(itemId, null, vshopId);
        Date onShelfAt = null;
        String skuId = null;
        if (vshopDistributionItem != null) {
            onShelfAt = vshopDistributionItem.getCreateTime();
            skuId = vshopDistributionItem.getSkuId();
        }
        vshopDistributionItemBiz.sendMQ(vshopId, itemId, status, 0, id, 0, skuId, onShelfAt,vshopDistributionItem.getIdentification());
        return cre;
    }

    /**
     * 分销商品推送MQ
     *
     * @param vshopId
     * @param itemId
     * @param status
     * @param id
     * @param popId
     * @return
     */
    @Override
    public CommonResultEntity<String> sendDistributionItemsMQ(long vshopId, String itemId, Integer status, long id, long popId, long currentDate,
            long categoryId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();

        vshopDistributionItemBiz.sendDistributionItemsMQ(vshopId, itemId, status, id, 0, currentDate, categoryId);
        return cre;
    }

    /**
     * @Description: 根据userId删除美店信息
     * @author: lixilong
     * @date: 2017年2月13日 下午7:00:39
     * @param userId
     * @return
     */
    @Override
    public CommonResultEntity<String> deleteVshopInfoByUserId(long userId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        vshopInfoBiz.deleteVshopInfo(userId);
        cre.setBusinessObj(null);
        return cre;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public CommonResultEntity<List<Long>> queryVshopInfoListById(Map map) {
        CommonResultEntity<List<Long>> cre = new CommonResultEntity<List<Long>>();
        cre.setBusinessObj(vshopInfoBiz.queryVshopInfoListById(map));
        return cre;
    }

    @Override
    public CommonResultEntity<List<VshopInfo>> queryVshopInfoList(PageParam pageParam) {
        CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
        // int vshopStatus = VshopStatusEnum.JINGYING.getValue();
        cre.setBusinessObj(vshopInfoBiz.queryVshopInfoList(pageParam, null));
        return cre;
    }

    @Override
    public CommonResultEntity<String> sendShopInfoMQ(long vshopId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        vshopInfoBiz.sendMQ(vshopId);
        return cre;
    }

    @Override
    public CommonResultEntity<Map<String, Object>> getVshopCategoryId(long vshopId, String categoryNames) {
        CommonResultEntity<Map<String, Object>> cre = new CommonResultEntity<Map<String, Object>>();
        // 校验店铺存在与否
        vshopInfoBiz.checkVshop(vshopId);
        String[] categorysTemp = categoryNames.split(",");
        List<String> categorys = new ArrayList<String>();
        for (int i = 0; i < categorysTemp.length; i++) {
            if (!categorys.contains(categorysTemp[i])) {
                categorys.add(categorysTemp[i]);
            }
        }
        Map<String, Object> resultMap = new HashMap<String, Object>();
        VshopCategory category = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        Long id;
        // 如果美店内没有分类，直接创建
        if (category == null) {
            category = new VshopCategory();
            id = 1L;
            List<VshopCategoryDto> createCtgyList = new ArrayList<VshopCategoryDto>();
            for (String categoryName : categorys) {
                // 如果分类不存在，将需要创建的分类加入到nowList中
                registCategories(id, categoryName, createCtgyList, resultMap);
                id++;
            }
            category.setMainCategoryNames(JsonUtils.toJson(categorys));
            category.setVshopId(vshopId);
            category.setVcategories(JsonUtils.toJson(createCtgyList));
            vshopCategoryBiz.createVshopCategory(category);
            cre.setBusinessObj(resultMap);
            return cre;
        }
        // 如果美店已有分类，根据传参，重新组装分类json串并更新
        List<VshopCategoryDto> agoList = JsonUtils.toList(category.getVcategories(), new VshopCategoryDto());
        List<String> agoMainCategoryList = new ArrayList<String>();
        if (StringUtils.isNotBlank(category.getMainCategoryNames())) {
            agoMainCategoryList = JsonUtils.toList(category.getMainCategoryNames(), new String());
        }
        List<String> updateMainCategoryList = new ArrayList<String>();
        List<VshopCategoryDto> updateCtgyList = new ArrayList<VshopCategoryDto>();
        // order如果有设置错误的，重新排序 将正确顺序的分类集合加入到新的集合updateCtgyList中
        categoriesSort(agoList);
        updateCtgyList.addAll(agoList);
        // 遍历美店内分类，如果传入的分类在已有分类中没有查询到，组装到updateCtgyList中
        // 从下一个要创建的分类id开始
        if (agoList.size() > 0) {
            id = agoList.get(agoList.size() - 1).getCategoryId() + 1;
        } else {
            id = 1L;
        }
        for (String categoryName : categorys) {
            boolean isExists4Name = false;
            if (StringUtils.isBlank(categoryName)) {
                continue;
            }
            for (VshopCategoryDto vshopCategoryDto : agoList) {
                if (vshopCategoryDto.getCategoryName().equals(categoryName)) {
                    resultMap.put(categoryName, vshopCategoryDto.getCategoryId());
                    isExists4Name = true;
                    break;
                }
            }
            // 如果分类不存在，将需要创建的分类加入到updateCtgyList中
            if (!isExists4Name) {
                registCategories(id, categoryName, updateCtgyList, resultMap);
                id++;
            }
        }
        // 新商品的主类目放到最前面
        String existMainCategoryNames = "#";
        for (String mainCategoryName : categorys) {
            for (String agoMainCategoryName : agoMainCategoryList) {
                if (mainCategoryName.equals(agoMainCategoryName)) {
                    existMainCategoryNames = existMainCategoryNames + mainCategoryName + "#";
                    break;
                }
            }
            updateMainCategoryList.add(mainCategoryName);
        }
        for (String agoMainCategoryName : agoMainCategoryList) {
            if (existMainCategoryNames.indexOf("#" + agoMainCategoryName + "#") == -1) {
                updateMainCategoryList.add(agoMainCategoryName);
            }
        }
        category.setMainCategoryNames(JsonUtils.toJson(updateMainCategoryList));
        category.setVshopId(vshopId);
        category.setVcategories(JsonUtils.toJson(updateCtgyList));
        vshopCategoryBiz.updateVshopCategory(category);
        cre.setBusinessObj(resultMap);
        return cre;
    }

    private void categoriesSort(List<VshopCategoryDto> agoList) {
        if (agoList != null && !agoList.isEmpty() && agoList.get(0).getOrder() == null) {
            for (VshopCategoryDto dto : agoList) {
                dto.setOrder((int) dto.getCategoryId());
            }
        }
    }

    /**
     *
     * @Description: 组装需要创建的分类
     * @author: lixilong
     * @date: 2017年3月4日 下午12:02:06
     * @param id
     * @param ctgyName
     * @param ctgyList
     * @param resultMap
     */
    private void registCategories(Long id, String ctgyName, List<VshopCategoryDto> ctgyList, Map<String, Object> resultMap) {
        VshopCategoryDto dto = new VshopCategoryDto();
        dto.setCategoryId(id);
        dto.setCategoryName(ctgyName);
        dto.setOrder(id.intValue());
        ctgyList.add(dto);
        resultMap.put(ctgyName, id);
    }

    @Override
    public CommonResultEntity<String> updateProductIdentification(Long vshopId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        vshopDistributionItemBiz.updateProductIdentificationByVshopId(vshopId);
        return cre;
    }

    /**
     *
     * @Description: 更改店铺主营类目
     * @author: guowenbo
     * @date: 2017年3月9日 上午11:01:04
     * @param vshopId
     * @param mainCategoryNames
     * @return
     */
    @Override
    public CommonResultEntity<String> updateMainCategoryByShopId(Long vshopId, String mainCategoryNames) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        VshopCategory category = new VshopCategory();
        if (StringUtils.isNotBlank(mainCategoryNames)) {
            String[] mainCategoryName = mainCategoryNames.split(",");
            List<String> list = java.util.Arrays.asList(mainCategoryName);
            category.setMainCategoryNames(JsonUtils.toJson(list));
        } else {
            category.setMainCategoryNames("[]");
        }
        category.setVshopId(vshopId);
        vshopCategoryBiz.updateVshopCategory(category);
        return cre;
    }

    /**
     *
     * @Description: 获取店铺主营类目
     * @author: guowenbo
     * @date: 2017年3月9日 上午11:01:04
     * @param vshopId
     * @return
     */
    @Override
    public CommonResultEntity<List<String>> queryListVshopMainCategoryByVshopId(Long vshopId) {
        CommonResultEntity<List<String>> cre = new CommonResultEntity<List<String>>();
        VshopCategory vshopCategory = vshopCategoryBiz.queryCategoryByVshopId(vshopId);
        if (vshopCategory != null && StringUtils.isNotBlank(vshopCategory.getMainCategoryNames())) {
            List<String> list = JsonUtils.toList(vshopCategory.getMainCategoryNames(), new String());
            cre.setBusinessObj(list);
        }
        return cre;
    }

    @Override
    public CommonResultEntity<String> createDistributionItems(List<VshopDistributionItem> list) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        if (list.isEmpty()) {
            return cre;
        }
        List<VshopDistributionItem> result = new ArrayList<VshopDistributionItem>();
        Long shopId = list.get(0).getVshopId();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("vshopId", shopId);
        map.put("status", ProductStatusEnum.SHANGJIA.getValue());

        List<String> existsItemIds = new ArrayList<String>();
        StringBuffer sb = new StringBuffer();
        for (VshopDistributionItem item : list) {
            existsItemIds.add(item.getItemId());
            sb.append("'" + item.getItemId() + "',");
        }
        Map<String, Object> idsMap = new HashMap<String, Object>();
        idsMap.put("vshopId", shopId);
        idsMap.put("status", ProductStatusEnum.SHANGJIA.getValue());
        idsMap.put("itemIds", sb.substring(0, sb.length() - 1));

        // 查询美店重复分销的商品
        List<String> vshopDistributionItems = vshopDistributionItemBiz.queryListProducts(idsMap);

        if (vshopDistributionItems != null && !vshopDistributionItems.isEmpty()) {
            for (VshopDistributionItem item : list) {
                log.info("The parameter distribution of item itemid is：{},categoryid is：{},vshopid is：{}", item.getItemId(), item.getVcategoryId(),
                        item.getVshopId());
                String itemId = item.getItemId();
                if (StringUtils.isBlank(itemId)) {
                    log.info("The parameter distribution of item:{}", item.toString());
                    continue;
                }
                if (vshopDistributionItems.contains(itemId)) {
                    continue;
                }
                item.setStatus(ProductStatusEnum.SHANGJIA.getValue());
                if(item.getIdentification()==null || !"offline".equals(item.getIdentification().toLowerCase())){
                    item.setIdentification("online");
                }
                result.add(item);
            }
        } else {
            for (VshopDistributionItem item : list) {
                log.info("itemid is{},categoryid is {},vshopid is{}", item.getItemId(), item.getVcategoryId(), item.getVshopId());
                item.setStatus(ProductStatusEnum.SHANGJIA.getValue());
                if(item.getIdentification()==null || !"offline".equals(item.getIdentification().toLowerCase())){
                    item.setIdentification("online");
                }
                result.add(item);
            }
        }

        vshopDistributionItemBiz.createDistributionItems(result);
        return cre;
    }

    @Override
    public CommonResultEntity<Map<String, Object>> queryVshopByUserId(Long userId) {
        CommonResultEntity<Map<String, Object>> res = new CommonResultEntity<Map<String, Object>>();
        String invokeFrom = "gomeShop";
        ResultDTO<StaffMshopModel> staffMshopByUserId = null;
        try {
            staffMshopByUserId = staffMshopFacade.getStaffMshopByUserId(String.valueOf(userId), invokeFrom);
            Map<String, Object> map = new HashMap<String, Object>();
            if (staffMshopByUserId.isSuccess() && staffMshopByUserId.getData() != null) {
                String storeName = staffMshopByUserId.getData().getStoreName();
                String categorys = staffMshopByUserId.getData().getCategorys();
                log.info("staffMshopFacade.getStaffMshopByUserId storeName:{},categorys:{},userId:{}", storeName, categorys, userId);
                // 去除品类中重复的值
                if (StringUtils.isNotBlank(categorys)) {
                    String[] strs = categorys.split("、");
                    StringBuffer sbCtgs = new StringBuffer();
                    List<String> list = new ArrayList<String>();
                    for (String name : strs) {
                        if (!list.contains(name)) {
                            if (sbCtgs.length() > 0) {
                                sbCtgs.append("、");
                            }
                            sbCtgs.append(name);
                            list.add(name);
                        }
                    }
                    categorys = sbCtgs.toString();
                }
                map.put("categorys", categorys);
                map.put("storeName", storeName);
                res.setBusinessObj(map);
            } else {
                res.setCode(Integer.valueOf(staffMshopByUserId.getErrCode()));
                res.setMessage(staffMshopByUserId.getErrMsg());
                log.info("staffMshopFacade.getStaffMshopByUserId errorMessage is:{},userId:{}", staffMshopByUserId.getErrMsg(), userId);
            }
        } catch (Exception e) {
            log.error("staffMshopFacade.getStaffMshopByUserId happend error exception,userId:{}", userId, e);
            res.setCode(Integer.valueOf(staffMshopByUserId.getErrCode()));
            res.setMessage("查询信息异常");
            return res;
        }
        return res;
    }

    /**
     * @Description:根据上下架标示查询商品列表
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param isValid
     * @param vshopId
     * @return CommonResultEntity<List<VshopProductadd>>
     */
    @Override
    public CommonResultEntity<List<VshopDistributionItem>> queryListProductByStatus(PageParam pageParam, int isValid, long vshopId) {
        // 判断是否为下架标示
        String status = "";
        if (isValid == ProductStatusEnum.XIAJIA.getValue()) {
            // 如果为下架，则查询冻结与下架的商品（冻结：强制下架）
            StringBuffer sb = new StringBuffer();
            sb.append(ProductStatusEnum.XIAJIA.getValue());
            sb.append(",");
            sb.append(ProductStatusEnum.DONGJIE.getValue());
            status = sb.toString();
        } else {
            status = String.valueOf(isValid);
        }
        CommonResultEntity<List<VshopDistributionItem>> cre = new CommonResultEntity<List<VshopDistributionItem>>();
        cre.setBusinessObj(vshopDistributionItemBiz.queryListProductByStatus(pageParam, status, vshopId));
        return cre;
    }

    //------------------- 分割线---------------------------如下的接口都是已经过时接口，后期删除--------------------------------//
    @Deprecated
    public CommonResultEntity<String> deleteVshopDistributionItemByUserId(Long userId) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();

        try {
            vshopDistributionItemBiz.deleteUserDistributionItem(userId);
        } catch (Exception e) {
            log.error("deleteVshopDistributionItemByUserId error: ", e);
            cre.setCode(-1); // 错误
            cre.setMessage(e.getMessage());
        }
        return cre;
    }

    /**
     * @Description: XPOP创建POP商家
     * @author: guowenbo
     * @date: 2015年6月30日 下午7:53:42
     * @param vshopInfoEntity
     * @return
     */
    @Deprecated
    @Override
    public CommonResultEntity<String> createPopInfo(VshopInfo vshopInfoEntity) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        // 校验用户是否存在微店
        vshopInfoBiz.checkUser(vshopInfoEntity.getUserId());
        // 校验店铺名称
        // vshopInfoBiz.queryVshopName(vshopInfoEntity.getVshopId(),
        // vshopInfoEntity.getVshopName());
        // 设置默认的背景图
        vshopInfoEntity.setVshopBgimage("0");
        // 设置微店的url
        vshopInfoEntity.setVshopUrl("http://mxwap.gome.cn/" + vshopInfoEntity.getUserId() + "/" + vshopInfoEntity.getVshopType());
        // 设置为审核中
        vshopInfoEntity.setVshopStatus(VshopStatusEnum.SHENHE.getValue());
        // 店铺logo
        if (vshopInfoEntity.getVshopIcon() == null || "".equals(vshopInfoEntity.getVshopIcon())) {
            vshopInfoEntity.setVshopIcon(getVshopDefaultLogo());
        }
        long vshopId = vshopInfoBiz.createVshop(vshopInfoEntity);
        cre.setBusinessObj(String.valueOf(vshopId));
        return cre;
    }

    /**
     * @Description: POP商家重新发起审核
     * @author: guowenbo
     * @date: 2015年6月26日 上午11:26:45
     * @param vshopInfo
     * @return
     */
    @Deprecated
    @Override
    public CommonResultEntity<String> updatePopInfo(VshopInfo vshopInfo) {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        VshopInfo info = null;
        if (vshopInfo.getVshopId() != 0) {
            info = vshopInfoBiz.queryVshopById(vshopInfo.getVshopId());
        } else if (vshopInfo.getUserId() != 0) {
            info = vshopInfoBiz.queryVshopByuserId(vshopInfo.getUserId());
        }
        if (info == null) {
            // 校验店铺名称
            vshopInfoBiz.queryVshopName(0, vshopInfo.getVshopName());
            // 校验用户是否存在微店
            vshopInfoBiz.checkUser(vshopInfo.getUserId());
            // 店铺logo
            if (vshopInfo.getVshopIcon() == null || "".equals(vshopInfo.getVshopIcon())) {
                vshopInfo.setVshopIcon(getVshopDefaultLogo());
            }
            // 设置默认的背景图
            vshopInfo.setVshopBgimage("0");
            // 设置微店的url
            vshopInfo.setVshopUrl("http://mxwap.gome.cn/" + vshopInfo.getUserId() + "/" + VshopTypeEnum.SHANGJIA.getValue());
            vshopInfo.setVshopStatus(VshopStatusEnum.SHENHE.getValue());
            vshopInfoBiz.createVshop(vshopInfo);
        } else {
            // 设置店铺类型为pop商家
            vshopInfo.setVshopType(VshopTypeEnum.SHANGJIA.getValue());
            vshopInfoBiz.updatePopInfo(vshopInfo);
        }
        return cre;
    }

    /**
     * @Description:根据上下架标示查询商品数量
     * @author: guowenbo
     * @date: 2015年4月15日 下午3:20:21
     * @param isValid
     * @param vshopId
     * @return CommonResultEntity<Integer>
     */
    @Deprecated
    @Override
    public CommonResultEntity<Integer> queryProductCountByStatus(int isValid, long vshopId) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        // 判断是否为下架标示
        String status = "";
        if (isValid == ProductStatusEnum.XIAJIA.getValue()) {
            // 下架查询冻结与下架的商品（冻结：强制下架）
            StringBuffer sb = new StringBuffer();
            sb.append(ProductStatusEnum.XIAJIA.getValue());
            sb.append(",");
            sb.append(ProductStatusEnum.DONGJIE.getValue());
            status = sb.toString();
        }
        cre.setBusinessObj(vshopDistributionItemBiz.queryProductCountByStatus(status, vshopId));
        return cre;
    }

    /**
     * @Description: 获取所有pop商家
     * @author: guowenbo
     * @date: 2015年6月17日 下午2:29:47
     * @return
     */
    @Deprecated
    @Override
    public CommonResultEntity<List<VshopInfo>> queryPopInfo() {
        CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
        String vshopType = String.valueOf(VshopTypeEnum.SHANGJIA.getValue());
        int vshopStatus = VshopStatusEnum.JINGYING.getValue();
        cre.setBusinessObj(vshopInfoBiz.queryPopInfo(vshopType, vshopStatus));
        return cre;
    }

    /**
     * @Description: 查询商品分销个数
     * @author: guowenbo
     * @date: 2015年8月11日 下午1:27:24
     * @param itemId
     * @return
     */
    @Deprecated
    @Override
    public CommonResultEntity<Integer> queryProductShareCount(String itemId) {
        CommonResultEntity<Integer> cre = new CommonResultEntity<Integer>();
        return cre;
    }

    /**
     * @Description 查找所有的上架店铺数量
     * @author suliangyi
     * @date 2015年12月25日 上午10:47:04
     * @return
     */
    @Deprecated
    @Override
    public CommonResultEntity<Void> findAllOnItemCount() {
        CommonResultEntity<Void> commonResultEntity = new CommonResultEntity<Void>();
        try {
            vshopDistributionItemBiz.findAllOnItemCount();
            commonResultEntity.setBusinessObj(null);
            return commonResultEntity;
        } catch (Exception e) {
            log.error("method:findAllFavCount,to count the shop favorite number is exception, the exception is :", e);
            commonResultEntity.setCode(CodeUtil.EXCEPTION);
            commonResultEntity.setMessage(CodeUtil.EXCEPTION_MSG);
            commonResultEntity.setBusinessObj(null);
            return commonResultEntity;
        }
    }
    /**
     * @Description: 所有美店店铺下的商品搜索
     * @author: guowenbo
     * @date: 2016年10月12日 上午11:01:24
     * @param pageParam
     *            :{pageNum:分页页码；pageSize:分页页数；}
     */
    @Override
    @Deprecated
    public CommonResultEntity<List<VshopDistributionItem>> queryItemsInMShop(PageParam pageParam) {
        CommonResultEntity<List<VshopDistributionItem>> cre = new CommonResultEntity<List<VshopDistributionItem>>();
        //List<VshopDistributionItem> items = vshopDistributionItemBiz.queryItemsInMShop(pageParam);
        //cre.setBusinessObj(items);
        return cre;
    }

    //------------------- 分割线---------------------------如上的接口都是已经过时接口，后期删除--------------------------------//

    @Override
    public CommonResultEntity<List<VshopInfo>> getByVshopIds(List<Long> ids) {
        CommonResultEntity<List<VshopInfo>> cre = new CommonResultEntity<List<VshopInfo>>();
        cre.setBusinessObj(vshopInfoBiz.getByVshopIds(ids));
        return cre;
    }

    @Override
    public CommonResultEntity<String> createVshop2(VshopInfo vshopInfoEntity) {
        log.info("createVshop2开店接口，入参vshopInfoEntity是 {} ", JSON.toJSONString(vshopInfoEntity));
        Integer vshopIdentity = vshopInfoEntity.getVshopIdentity();
        if(vshopIdentity==null){
            vshopInfoEntity.setVshopIdentity(1);
        }//设置默认值
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        // 校验入参中的fieids 字段都不能为空
        ValidateUtils.notNull(vshopInfoEntity, "userId", "vshopName");
        // 校验用户是否存在微店
        VshopInfo vshopInfoExist = vshopInfoBiz.queryVshopByuserId(vshopInfoEntity.getUserId());
        boolean isExists = (vshopInfoExist != null);
        vshopInfoEntity.setVshopStatus(VshopStatusEnum.JINGYING.getValue());
        // 店铺logo
        if (StringUtils.isBlank(vshopInfoEntity.getVshopIcon())) {
            vshopInfoEntity.setVshopIcon(getVshopDefaultLogo());
        }
        if (vshopInfoEntity.getVersion() == 0) {// 0：isSkip 不跳过 校验店铺名称
            // 校验店铺名称是否重复
            vshopInfoBiz.queryVshopName(isExists ? vshopInfoExist.getVshopId() : 0, vshopInfoEntity.getVshopName());
        }
        if(null != vshopInfoEntity.getPhoneNo() && !"".equals(vshopInfoEntity.getPhoneNo())){
            //查询手机号是否重复
            vshopInfoBiz.queryVshopPhoneNo(isExists ? vshopInfoExist.getVshopId() : 0,vshopInfoEntity.getPhoneNo());
        }
        //敏感词过滤
        log.info("敏感词过滤start：vshopName={},vshopDesc={}",vshopInfoEntity.getVshopName(),vshopInfoEntity.getVshopDesc());
        this.checkString(vshopInfoEntity);
        log.info("敏感词过滤end：vshopName={},vshopDesc={}",vshopInfoEntity.getVshopName(),vshopInfoEntity.getVshopDesc());
        if (isExists) {
            log.info("用户已经开通美店更新数据userId:{},vshopName:{},vshopId:{},渠道是 {}", vshopInfoEntity.getUserId(),
                    vshopInfoEntity.getVshopName(), vshopInfoExist.getVshopId(),vshopInfoEntity.getChannel());
            //更新美店
            vshopInfoEntity.setVshopId(vshopInfoExist.getVshopId());
            vshopInfoBiz.updateVshop(vshopInfoEntity);
            cre.setBusinessObj(String.valueOf(vshopInfoExist.getVshopId()));
        } else {
            log.info("用户开通美店userId:{},vshopName:{},开通美店的渠道 {}  ", vshopInfoEntity.getUserId(),
                    vshopInfoEntity.getVshopName(), vshopInfoEntity.getChannel());
            //新增美店
            //shop-servlet -》 MDC获取美店来源
            String source = MDC.get("AppId");
            if(StringUtils.isNotBlank(source)){
                vshopInfoEntity.setSource(source.substring(0,3));
            }
            long vshopId = vshopInfoBiz.createVshop(vshopInfoEntity);
            cre.setBusinessObj(String.valueOf(vshopId));
        }
        return cre;
    }

    @Override
    public CommonResultEntity<String> createTaskVshop(VshopInfo vshopInfo) throws Exception {
        CommonResultEntity<String> cre = new CommonResultEntity<String>();
        //敏感词过滤
        log.info("敏感词过滤start：vshopName={},vshopDesc={}",vshopInfo.getVshopName(),vshopInfo.getVshopDesc());
        this.checkString(vshopInfo);
        log.info("敏感词过滤end：vshopName={},vshopDesc={}",vshopInfo.getVshopName(),vshopInfo.getVshopDesc());
        //新增美店
        long vshopId = vshopInfoBiz.createVshop(vshopInfo);
        log.info("createTaskVshop success,vshopId:{}",vshopId);
        cre.setBusinessObj(String.valueOf(vshopId));
        return cre;
    }

    @Override
    public CommonResultEntity<Boolean> checkVshopName(VshopInfo vshopInfo) throws Exception {
        CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
        vshopInfoBiz.queryVshopName(vshopInfo.getVshopId(),vshopInfo.getVshopName());
        cre.setBusinessObj(false);
        return cre;
    }

    @Override
    public CommonResultEntity<Boolean> checkVshopPhoneNo(VshopInfo vshopInfo) throws Exception {
        CommonResultEntity<Boolean> cre = new CommonResultEntity<Boolean>();
        vshopInfoBiz.queryVshopPhoneNo(vshopInfo.getVshopId(),vshopInfo.getPhoneNo());
        cre.setBusinessObj(false);
        return cre;
    }

    @Override
    public List<VshopCommission> randomQueryVshops(long currentUserId, int pageSize){
        List<VshopCommission> result = null;
        Map<String, Object> param = new HashMap<>();
        try {
            int count = Optional.ofNullable(vshopInfoBiz.queryMshopCount()).orElse(0);
            int totalPage = count / pageSize - 1;
            Random random = new Random();
            int pageNo = random.nextInt(totalPage);
            param.put("excludUserId", currentUserId);
            param.put("pageFirst", Math.max((pageNo - 1), 0) * pageSize);
            param.put("pageSize", pageSize);
            List<VshopInfo> vshopInfos = vshopInfoBiz.queryVshopInfoListForVip(param);
            if(org.apache.commons.collections.CollectionUtils.isEmpty(vshopInfos)){
                return result;
            }
            result = new ArrayList<>(pageSize);
            for (VshopInfo vshopInfo : vshopInfos) {
                VshopCommission vshopCommission = new VshopCommission();
                vshopCommission.setUserId(vshopInfo.getUserId());
                vshopCommission.setCommission(BigDecimal.valueOf(Math.random() * 100).setScale(2, BigDecimal.ROUND_HALF_UP));
                result.add(vshopCommission);
            }
        } catch (Exception e) {
            log.error("随机查询店主数据 异常 入参 {} ", JSON.toJSONString(param), e);
        }
        return result;
    }

}
