package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopVipCouponRecord;
import com.gomeo2o.service.vshop.dao.VshopVipCouponRecordDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
@Repository("name=vshopVipCouponRecordDao")
public class VshopVipCouponRecordDaoImpl extends CBaseDaoImpl<VshopVipCouponRecord>
        implements VshopVipCouponRecordDao {
}