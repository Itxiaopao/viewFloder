package com.gomeo2o.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.gome.diamond.annotations.DiamondValue;
import com.gomeplus.venus.common.imageutil.UrlConverter;

/**
 * @author limenghui
 * @create 2020-07-28 13:20
 */
@Configuration
public class UrlConverterConfig {
    @DiamondValue("${imageutil_urlPrefix}")
    private String imageutil_urlPrefix;
    @DiamondValue("${imageutil_candidateSubdomains}")
    private String imageutil_candidateSubdomains;

    @Bean(name = "imgUrlConverter")
    public UrlConverter urlConverterConfig() {
        return new UrlConverter(imageutil_urlPrefix, imageutil_candidateSubdomains);
    }


}
