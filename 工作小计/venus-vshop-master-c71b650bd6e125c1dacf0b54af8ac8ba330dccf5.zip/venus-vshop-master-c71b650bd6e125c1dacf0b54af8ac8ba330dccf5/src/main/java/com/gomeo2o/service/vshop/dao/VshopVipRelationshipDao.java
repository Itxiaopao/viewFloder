package com.gomeo2o.service.vshop.dao;

import java.util.List;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopVipRelationship;

public interface VshopVipRelationshipDao extends BaseDao<VshopVipRelationship>{

	public Integer countVshopVipRelationshipByInviterUserId(Long inviterUserId,String source);

	public List<VshopVipRelationship> getVshopVipRelationships(PageParam pageParam,
			Long inviterUserId);

}
