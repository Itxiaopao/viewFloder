/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: DeleteVshopItemEvent.java 
 * @Prject: venus-vshop
 * @Package: com.gomeo2o.event.vshop
 * @Description: 美店商品下架事件
 * @author: sunyizhong   
 * @date: 2016年11月24日 上午10:09:35 
 * @version: V1.0   
 */
package com.gomeo2o.event.vshop;

import java.util.Map;

import com.gomeo2o.event.common.AbstractIdEvent;

/**
 * 
 * @ClassName: DeleteVshopItemEvent
 * @Description: 美店商品下架事件
 * @author: sunyizhong
 * @date: 2016年11月24日 上午11:50:53
 */
public class DeleteVshopItemEvent extends AbstractIdEvent<Map<String, Object>> {

	public DeleteVshopItemEvent(Long id) {
		super(id);
	}

}
