/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: CreateVshopEvent.java 
 * @Prject: venus-vshop
 * @Package: com.gomeo2o.event.vshop
 * @Description: 美店创建事件
 * @author: sunyizhong   
 * @date: 2016年11月24日 上午10:09:35 
 * @version: V1.0   
 */
package com.gomeo2o.event.vshop;

import java.util.Map;

import com.gomeo2o.event.common.AbstractIdEvent;

/**
 * 
 * @ClassName: CreateVshopEvent
 * @Description: 美店创建事件
 * @author: sunyizhong
 * @date: 2016年11月24日 上午11:50:53
 */
public class CreateVshopEvent extends AbstractIdEvent<Map<String, Object>> {

	public CreateVshopEvent(Long id) {
		super(id);
	}

}
