package com.gomeo2o.service.vshop.dao;

import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopInfoLabel;

public interface VshopInfoLabelDao extends BaseDao<VshopInfoLabel> {
    public VshopInfoLabel queryVshopInfoLabelByUserId(Map<String, Object> map);
    public int insertVshopInfoLabel(VshopInfoLabel vshopInfoLabel);
    public int updateVshopInfoLabel(VshopInfoLabel vshopInfoLabel);
}
