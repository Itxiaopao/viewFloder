package com.gomeo2o.service.vshop.biz;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.gomeo2o.facade.vshop.entity.VshopInfoLabel;
import com.gomeo2o.service.vshop.dao.VshopInfoLabelDao;
import com.gomeo2o.utils.StringUtil;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

@Slf4j
@Service("vshopInfoLableBiz")
public class VshopInfoLabelBiz {
    @Autowired
    private VshopInfoLabelDao vshopInfoLabelDao;
    private final String VSHOP_INFO_LABEL_KEY = "vshop:vshopInfoLabel_userId:";
    @Resource(name = "vshopCache")
    Gcache vshopGcache;
    public VshopInfoLabel queryVshopInfoLabelByUserId(Long userId,Integer type) {
        String s = vshopGcache.get(VSHOP_INFO_LABEL_KEY + userId + ":" + type);
        if(StringUtil.notEmpty(s)){
            try {

                VshopInfoLabel vshopInfoLabel = JSON.parseObject(s, VshopInfoLabel.class);
                return vshopInfoLabel;
            } catch (Exception e) {
                log.error("vshopInfoLabelGcache.get error,userId:{},exception",userId,e);
            }
        }
        HashMap<String, Object> map = new HashMap<>(2);
        map.put("userId",userId);
        map.put("userType",type);
        return vshopInfoLabelDao.queryVshopInfoLabelByUserId(map);
    }
    @Transactional(rollbackFor = Throwable.class)
    public int insertVshopInfoLabel(VshopInfoLabel vshopInfoLabel){
        int i = vshopInfoLabelDao.insertVshopInfoLabel(vshopInfoLabel);
        if(i == 1){
            VshopInfoLabel rtnvshopInfoLabel = queryVshopInfoLabelByUserId(vshopInfoLabel.getUserId(),vshopInfoLabel.getUserType());
            vshopGcache.set(VSHOP_INFO_LABEL_KEY+vshopInfoLabel.getUserId() + ":" + vshopInfoLabel.getUserType(), JSON.toJSONString(rtnvshopInfoLabel));
            return 1;
        }
        return 0;
    }
    @Transactional(rollbackFor = Throwable.class)
    public int updateVshopInfoLabel(VshopInfoLabel vshopInfoLabel){
        int i = vshopInfoLabelDao.updateVshopInfoLabel(vshopInfoLabel);
        if(i == 1){
            HashMap<String, Object> map = new HashMap<>(1);
            map.put("userId",vshopInfoLabel.getUserId());
            map.put("userType",vshopInfoLabel.getUserType());
            VshopInfoLabel rtnvshopInfoLabel = vshopInfoLabelDao.queryVshopInfoLabelByUserId(map);
            vshopGcache.set(VSHOP_INFO_LABEL_KEY+vshopInfoLabel.getUserId()+ ":" + vshopInfoLabel.getUserType(), JSON.toJSONString(rtnvshopInfoLabel));
            return 1;
        }
        return 0;
    }
}
