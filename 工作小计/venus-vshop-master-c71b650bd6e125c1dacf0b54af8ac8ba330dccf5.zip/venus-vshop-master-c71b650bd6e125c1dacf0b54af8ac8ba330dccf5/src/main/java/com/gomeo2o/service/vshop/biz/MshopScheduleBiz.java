package com.gomeo2o.service.vshop.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.facade.vshop.entity.MshopCloneItemSchedule;
import com.gomeo2o.service.vshop.dao.MshopCloneItemScheduleDao;

@Service("name=mshopScheduleBiz")
public class MshopScheduleBiz {

    @Autowired
    private MshopCloneItemScheduleDao mhopCloneItemScheduleDao;

    public long insertMshopCloneItemsSchedule(long originMshopId, long targetMshopId){
    	long res = 0;
    	//校验是否存在一键复制的定时任务
    	List<MshopCloneItemSchedule> list = mhopCloneItemScheduleDao.queryMshopCloneItemScheduleById(originMshopId, targetMshopId);
    	if(list != null && list.size() > 0)
    		return res;
        MshopCloneItemSchedule mshopCloneItemSchedule = new MshopCloneItemSchedule();
        mshopCloneItemSchedule.setOriginMshopId(originMshopId);
        mshopCloneItemSchedule.setTargetMshopId(targetMshopId);
        mshopCloneItemSchedule.setStatus(MshopCloneItemSchedule.CloneItemScheduleStatus.INIT.getStatus());
        res = mhopCloneItemScheduleDao.insert(mshopCloneItemSchedule);
        return res;
    }
}
