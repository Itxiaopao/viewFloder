/**   
 * Copyright © 2016 mx. All rights reserved.
 * 
 * @Title: VshopItemListener.java 
 * @Prject: venus-vshop
 * @Package: com.gomeo2o.event.listener 
 * @Description: 美店商品上下架信息监听类
 * @author: sunyizhong   
 * @date: 2016年11月24日 下午3:01:14 
 * @version: V1.0   
 */
package com.gomeo2o.event.listener;

import org.springframework.stereotype.Component;

import com.gomeo2o.event.vshop.CreateVshopItemEvent;
import com.gomeo2o.event.vshop.DeleteVshopItemEvent;
import com.google.common.eventbus.Subscribe;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @ClassName: VshopItemListener
 * @Description: 美店商品上下架信息监听类
 * @author: sunyizhong
 * @date: 2016年11月24日 下午3:02:31
 */
@Component
@Slf4j
public class VshopItemListener implements EventListener {

//	@Autowired
//	private SendMqProducer sendMqProducer;

	/**
	 * 
	 * @Title: onVshopItemCreateEvent
	 * @Description: 美店商品上架事件
	 * @param event
	 * @return: void
	 */
	@Subscribe
	public void onVshopItemCreateEvent(CreateVshopItemEvent event) {
	/*	Long vshopId = event.id();
		Map<String, Object> data = event.getData();
		try {
			if (data != null) {
				sendMqProducer.sendVo2Mq(vshopId + "_" + data.get("itemId"), "vshop.itemStatus", SubmitAction.CREATE, data);
				log.info("send create vshopItem rabbit mq, message is [{}] action is [{}]", data, SubmitAction.CREATE);
			}
		} catch (Exception e) {
			log.error("send create vshopItem rabbit mq exception vshopId is [{}]", vshopId, e);
		}*/
	}

	/**
	 * 
	 * @Title: onVshopItemDeleteEvent 
	 * @Description: 删除美店商品事件
	 * @param event
	 * @return: void
	 */
	@Subscribe
	public void onVshopItemDeleteEvent(DeleteVshopItemEvent event) {
		/*Long vshopId = event.id();
		Map<String, Object> data = event.getData();
		try {
			if (data != null) {
				sendMqProducer.sendVo2Mq(vshopId + "_" + data.get("itemId"), "vshop.itemStatus", SubmitAction.DELETE, data);
				log.info("send delete vshopItem rabbit mq, message is [{}] action is [{}]", data, SubmitAction.DELETE);
			}
		} catch (Exception e) {
			log.error("send delete vshopItem rabbit mq exception vshopId is [{}]", vshopId, e);
		}*/
	}
}
