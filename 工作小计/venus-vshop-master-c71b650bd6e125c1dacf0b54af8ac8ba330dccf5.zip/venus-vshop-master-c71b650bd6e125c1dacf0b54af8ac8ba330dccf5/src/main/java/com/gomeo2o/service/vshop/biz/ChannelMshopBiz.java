package com.gomeo2o.service.vshop.biz;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.ChannelMshopReqDto;
import com.gomeo2o.facade.vshop.dto.ChannelMshopRespDto;
import com.gomeo2o.facade.vshop.dto.GomeStore;
import com.gomeo2o.facade.vshop.entity.VshopChannelInfo;
import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantChangeRecord;
import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantInfo;
import com.gomeo2o.facade.vshop.entity.VshopChannelResumeInfo;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopChannelInfoDao;
import com.gomeo2o.service.vshop.dao.VshopChannelMerchantChangeRecordDao;
import com.gomeo2o.service.vshop.dao.VshopChannelMerchantInfoDao;
import com.gomeo2o.service.vshop.dao.VshopChannelResumeInfoDao;
import com.gomeo2o.utils.JSONUtilss;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

@Slf4j
@Service("name=channelMshopBiz")
public class ChannelMshopBiz {
	@Autowired
	private VshopChannelInfoDao vshopChannelInfoDao;
	@Autowired
	private VshopChannelMerchantInfoDao vshopChannelMerchantInfoDao;
	@Autowired
	private VshopChannelMerchantChangeRecordDao vshopChannelMerchantChangeRecordDao;
	@Autowired
	private VshopChannelResumeInfoDao vshopChannelResumeInfoDao;
	@Autowired Gcache vshopCache;
	/**
	 * 
	 * @Description: 获取渠道美店相关信息 
     * @author: zhaoxingxing
     * @date: 2018年6月6日 上午11:58:11
     * @param pageParam
     * @param channelMshopReqDto
     * @return
     * @throws Exception
	 */
	public List<ChannelMshopRespDto> getChannelMshopList(PageParam pageParam,ChannelMshopReqDto channelMshopReqDto){
		List<ChannelMshopRespDto> resList = new ArrayList<>();
		List<VshopChannelInfo> vshopChannelInfoList = vshopChannelInfoDao.getVshopChannelInfoList(pageParam,channelMshopReqDto);
		if(vshopChannelInfoList==null || vshopChannelInfoList.size()==0){
			return resList;
		}
		for (VshopChannelInfo vci : vshopChannelInfoList) {
			ChannelMshopRespDto channelMshopRespDto = new ChannelMshopRespDto();
			channelMshopRespDto.setVshopChannelInfo(vci);
			/*try {
				BeanUtils.copyProperties(channelMshopRespDto, vci);
			} catch (Exception e) {
				Log.error("getChannelMshopList:copyProperties fail,vshopChannelInfo:{},e:{}",vci.toString(),e);
				continue;
			}*/
			channelMshopRespDto.setAreaName(vci.getProvinceName()+" "+vci.getCityName()+" "+vci.getCountyName());
			VshopChannelMerchantInfo merchantInfo = vshopChannelMerchantInfoDao.getVshopChannelMerchantInfo(vci.getMerchantId());
			if(merchantInfo != null){
				channelMshopRespDto.setVshopChannelMerchantInfo(merchantInfo);
			}
			/*channelMshopRespDto.setMerchantCardFront(merchantInfo.getMerchantCardFront());
			channelMshopRespDto.setMerchantCardPerson(merchantInfo.getMerchantCardPerson());
			channelMshopRespDto.setMerchantCardReverse(merchantInfo.getMerchantCardReverse());
			channelMshopRespDto.setMerchantIdNumber(merchantInfo.getMerchantIdNumber());
			channelMshopRespDto.setMerchantName(merchantInfo.getMerchantName());
			channelMshopRespDto.setMerchantPhone(merchantInfo.getMerchantPhone());
			channelMshopRespDto.setMerchantWorkUnits(merchantInfo.getMerchantWorkUnits());
			channelMshopRespDto.setMerchantWorkUnitsCard(merchantInfo.getMerchantWorkUnitsCard());*/
			resList.add(channelMshopRespDto);
		}
		return resList;
	}
	/**
	 * 
	 * @Description: 查询数量 
     * @author: zhaoxingxing
     * @date: 2018年6月6日 下午3:30:45
     * @param channelMshopReqDto
     * @return
	 */
	public Integer getChannelMshopCount(ChannelMshopReqDto channelMshopReqDto) {
		return vshopChannelInfoDao.getChannelMshopCount(channelMshopReqDto);
	}
	/**
	 * 
	 * @Description: 查询渠道美店 
     * @author: zhaoxingxing
     * @date: 2018年6月8日 上午10:30:07
     * @param vshopChannelInfo
     * @return
	 */
	public VshopChannelInfo queryVshopChannel(VshopChannelInfo vshopChannelInfo) {
		VshopChannelInfo vci = vshopChannelInfoDao.queryVshopChannel(vshopChannelInfo);
		return vci;
	}
	/**
	 * 
	 * @Description: 创建渠道美店 
     * @author: zhaoxingxing
     * @date: 2018年6月8日 上午10:28:49
     * @param vshopChannelInfo
     * @return
	 */
	public Long createVshopChannel(VshopChannelInfo vshopChannelInfo) {
		long id = vshopChannelInfoDao.insert(vshopChannelInfo);
		return id;
	}
	/**
	 * 
	 * @Description: 创建店主身份 
     * @author: zhaoxingxing
     * @date: 2018年6月8日 上午10:29:09
     * @param vshopChannelMerchantInfo
     * @return
	 */
	public Long createVshopChannelMerchant(VshopChannelMerchantInfo vshopChannelMerchantInfo) {
		Long merchantId = vshopChannelMerchantInfoDao.insert(vshopChannelMerchantInfo);
		return merchantId;
	}
	
	/**
	 * 
	 * @Description: 查询渠道美店集合 cms接口专用
     * @author: lixilong
     * @date: 2018年6月6日 下午6:12:21
     * @param areaId
     * @param number
     * @return
	 */
	public List<GomeStore> getChannelShops(String areaId, int number) {
	    PageParam pageParam = new PageParam();
	    pageParam.setPageNum(1);
	    pageParam.setNumPerPage(number);
	    ChannelMshopReqDto channelMshopReqDto = new ChannelMshopReqDto();
	    channelMshopReqDto.setCountyId(Long.valueOf(areaId));
	    channelMshopReqDto.setStatus(2);
        List<VshopChannelInfo> channelInfoList = vshopChannelInfoDao.getVshopChannelInfoList(pageParam,channelMshopReqDto);
	    return convertChannelInfoList2GomeStoreList(channelInfoList);
	}
	
	/**
	 * 
	 * @Description: cms接口专用
	 * 根据渠道美店编码查询渠道美店信息，并转化为数字门店结构GomeStore 
     * @author: lixilong
     * @date: 2018年6月7日 上午11:58:14
     * @param storeCode
     * @return
	 */
	public GomeStore getChannelInfo2Store(String storeCode) {
	    if (StringUtils.isBlank(storeCode)) {
	        throw VshopException.PARAM_IS_NULL;
	    }
	    VshopChannelInfo channelInfo = vshopChannelInfoDao.selectVshopChannelInfoByStoreCode(storeCode);
	    return convertChannelInfo2GomeStore(channelInfo);
	}
	
	/**
	 * 
	 * @Description: 根据渠道美店编码查询渠道美店店主信息 
     * @author: lixilong
     * @date: 2018年6月7日 下午1:46:23
     * @param storeCode
     * @return
	 */
	public VshopChannelMerchantInfo getChannelMerchantByStoreCode(String storeCode) {
	    VshopChannelInfo channelInfo = vshopChannelInfoDao.selectVshopChannelInfoByStoreCode(storeCode);
        if (channelInfo == null) {
            log.error("getChannelMerchantByStoreCode is null,storeCode is {}",storeCode);
            return null;
        }
        if (channelInfo.getMerchantId() == null) {
            log.error("getChannelMerchantByStoreCode merchantId is null,storeCode is {}",storeCode);
            return null;
        }
	    return vshopChannelMerchantInfoDao.getVshopChannelMerchantInfo(channelInfo.getMerchantId());
	}
	
	public List<GomeStore> getChannelShopByPosition(String lng, String lat,int number) {
	    List<VshopChannelInfo> channelInfoList = vshopChannelInfoDao.selectChannelInfoByPosition(lng, lat, number);
	    return convertChannelInfoList2GomeStoreList(channelInfoList);
	}
	
	/**
	 * 
	 * @Description: 将渠道美店结构转为数字门店结构保持统一，cms接口专用
     * @author: lixilong
     * @date: 2018年6月7日 下午2:23:08
     * @param channelInfoList
     * @return
	 */
	private List<GomeStore> convertChannelInfoList2GomeStoreList(List<VshopChannelInfo> channelInfoList){
	    List<GomeStore> storeList = new ArrayList<GomeStore>();
	    if (channelInfoList == null || channelInfoList.isEmpty()) {
            return null;
        }
        for (VshopChannelInfo channelInfo : channelInfoList) {
            GomeStore store = convertChannelInfo2GomeStore(channelInfo);
            storeList.add(store);
        }
        return storeList;
	}
	
	/**
	 * 
	 * @Description: 将渠道美店结构转为数字门店结构保持统一，cms接口专用
     * @author: lixilong
     * @date: 2018年6月7日 下午2:22:37
     * @param channelInfo
     * @return
	 */
	private GomeStore convertChannelInfo2GomeStore(VshopChannelInfo channelInfo) {
	    GomeStore store = new GomeStore();
	    if (channelInfo == null) {
            return null;
        }
        try {
            BeanUtils.copyProperties(store, channelInfo);
        } catch (Exception e) {
            log.error("getChannelInfo2Store:copyProperties fail,vshopChannelInfo:{}",channelInfo.toString());
            return null;
        }
        store.setType(1);
        store.setGomeStoreId(channelInfo.getId().toString());
        store.setLat(channelInfo.getLatitude());
        store.setLng(channelInfo.getLongitude());
	    store.setChannelType(channelInfo.getType());
	    store.setProvinceCode(String.valueOf(channelInfo.getProvinceId()));
	    store.setCityCode(String.valueOf(channelInfo.getCityId()));
	    store.setCountyCode(String.valueOf(channelInfo.getCountyId()));
        return store;
	}
	/**
	 * 
	 * @Description: 修改渠道美店信息 
     * @author: zhaoxingxing
     * @date: 2018年6月8日 上午10:25:19
     * @param vshopChannelInfo
	 */
	public void updateVshopChannelById(VshopChannelInfo vshopChannelInfo) {
		
		vshopChannelInfoDao.update(vshopChannelInfo);
	}
	/**
	 * 
	 * @Description: 修改店主信息 
     * @author: zhaoxingxing
     * @date: 2018年6月8日 上午10:25:58
     * @param shopChannelMerchantInfo
	 */
	public void updateVshopChannelMerchantById(VshopChannelMerchantInfo shopChannelMerchantInfo) {
		
		vshopChannelMerchantInfoDao.update(shopChannelMerchantInfo);
	}
	/**
	 * 
	 * @Description: 根据Id查询渠道店铺信息 
     * @author: zhaoxingxing
     * @date: 2018年6月8日 上午11:25:23
     * @param id
     * @return
	 */
	public ChannelMshopRespDto getChannelMshopById(Long id,String storeCode) {
		ChannelMshopRespDto cmrd = new ChannelMshopRespDto();
		VshopChannelInfo vshopChannelInfo = vshopChannelInfoDao.selectVshopChannelInfoById(id,storeCode);
		if(vshopChannelInfo != null){
			cmrd.setVshopChannelInfo(vshopChannelInfo);
			if(vshopChannelInfo.getMerchantId() != null){
				VshopChannelMerchantInfo vshopChannelMerchantInfo = vshopChannelMerchantInfoDao.getVshopChannelMerchantInfo(vshopChannelInfo.getMerchantId());
				cmrd.setVshopChannelMerchantInfo(vshopChannelMerchantInfo);
			}
		}
		return cmrd;
	}

	/**
	 *
	 * @Description: 根据storeCode查询渠道店铺信息
	 * @author: zhangwei
	 * @date: 2019年3月28日 下午14:32:00
	 * @param storeCode
	 * @return
	 */
	public ChannelMshopRespDto getChannelMshopByStoreCode(String storeCode) {
		ChannelMshopRespDto cmrd = new ChannelMshopRespDto();
        VshopChannelInfo vshopChannelInfo=getOccurList(storeCode);
        cmrd.setVshopChannelInfo(vshopChannelInfo);
        return cmrd;
	}
    /**
     * 绑定添加缓存
     * @param storeCode
     * @return
     */
    private VshopChannelInfo getOccurList(String storeCode) {
        String itemKey = "vshop-storeCode" + storeCode;
        // 先从缓存取数据
        String byteList = vshopCache.get(itemKey);
        if (null == byteList) {
            // 缓存无数据 从数据库取
            VshopChannelInfo  vshopChannelInfo = vshopChannelInfoDao.selectVshopChannelInfoByStoreCode(storeCode);
            // 存入缓存
			vshopCache.setex(itemKey,60 * 2, JSONUtilss.toJSONString(vshopChannelInfo));
            return vshopChannelInfo;
        }
        return JSON.parseObject(byteList, VshopChannelInfo.class);
    }

	/**
	 * 
	 * @Description: 创建美店群主信息变更记录 
     * @author: zhaoxingxing
     * @date: 2018年6月13日 下午4:46:43
     * @param vcmcr
     * @return
	 */
	public Long createShopChannelMerchantChangeRecord(VshopChannelMerchantChangeRecord vcmcr) {
		long id = vshopChannelMerchantChangeRecordDao.insert(vcmcr);
		return id;
	}
	/**
	 * 
	 * @Description: TODO 
     * @author: zhaoxingxing
     * @date: 2018年6月13日 下午4:46:57
     * @param vcri
     * @return
	 */
	public Long createShopChannelResume(VshopChannelResumeInfo vcri) {
		long id = vshopChannelResumeInfoDao.insert(vcri);
		return id;
	}
	
	public VshopChannelInfo getVshopChannelInfoById(Long channelId) {
	    return vshopChannelInfoDao.selectVshopChannelInfoById(channelId,null);
	}
	
}
