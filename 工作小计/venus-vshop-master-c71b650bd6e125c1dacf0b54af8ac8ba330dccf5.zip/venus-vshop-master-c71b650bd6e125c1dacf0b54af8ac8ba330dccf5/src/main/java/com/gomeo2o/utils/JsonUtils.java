/**
 * gomeo2o.com 
 * Copyright (c) 2015-2025 All Rights Reserved.
 * @Description: TODO 
 * @author: guowenbo
 * @date: 2015年6月1日 上午11:42:53
 */
package com.gomeo2o.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSONException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * @Description: JSON工具类
 * @author: guowenbo
 * @date: 2015年6月1日 上午11:42:53
 */
public class JsonUtils {

    static ObjectMapper mapper = new ObjectMapper();

    /**
     * 将json数组转换为List<Map<String, Object>>
     * @param json
     * @return
     */
    @SuppressWarnings("unchecked")
    public static List<Map<String, Object>> Json2ListMap(String json) {
        List<Map<String, Object>> list = null;
        try {
            list = mapper.readValue(json,List.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    @SuppressWarnings("unchecked")
    public static Map<String,Object> json2Map(String json) {
        Map<String,Object> res = null;
        try {
            res = mapper.readValue(json,Map.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Map<String,Object> toMap(String jsonString) throws JSONException {

        JSONObject jsonObject = JSONObject.fromObject(jsonString);
        
        Map result = new HashMap();
		Iterator iterator = jsonObject.keys();
        String key = null;
        String value = null;
        
        while (iterator.hasNext()) {
            key = (String) iterator.next();
            value = jsonObject.getString(key);
            result.put(key, value);
        }
        return result;

    }
	
	public static <T> String toJson(List<T> t){
		JSONArray json = JSONArray.fromObject(t);
		return json.toString();
    }
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static <T> List<T> toList(String json,T t){
		JSONArray jsonArray = JSONArray.fromObject(json);  
        List<T> list = (List) JSONArray.toCollection(jsonArray,t.getClass());  
        return list;  
	}

}
