package com.gomeo2o.service.vshop.dao;

import java.util.List;
import java.util.Map;

import com.gomeo2o.common.core.dao.BaseDao;
import com.gomeo2o.facade.vshop.entity.VshopVipInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipMshopIdSimpleInfo;

/**
 * @author baixiangzhu
 * @date 2018/4/12
 **/
public interface VshopVipInfoDao extends BaseDao<VshopVipInfo>{

    public VshopVipInfo getVshopVipInfoByUserId(Long userId) ;

    public List<VshopVipInfo> adminPageQueryVipInfo(Map<String, Object> map);

    public Integer adminPageQueryVipInfoCount(Map<String, Object> map);

    public List<VshopVipMshopIdSimpleInfo> queryAllVipMshopIdInfoList() ;
}