package com.gomeo2o.service.vshop.biz;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageBean;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.VshopVipRelationshipDto;
import com.gomeo2o.facade.vshop.entity.VshopVipInfo;
import com.gomeo2o.facade.vshop.entity.VshopVipRelationship;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopVipInfoDao;
import com.gomeo2o.service.vshop.dao.VshopVipRelationshipDao;
import com.gomeo2o.utils.ValidateUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("vshopVipRelationshipBiz")
public class VshopVipRelationshipBiz {
	
	@Autowired
	private VshopVipRelationshipDao vshopVipRelationshipDao;
	
	@Autowired
	private VshopVipInfoDao vshopVipInfoDao;
	
	public CommonResultEntity<PageBean> getVshopVipRelationships(PageParam pageParam,Long inviterUserId) {
		CommonResultEntity<PageBean> cre = new CommonResultEntity<PageBean>();
		PageBean pageBean = new PageBean();
		
		String source = "1,2";
		int vipCount = vshopVipRelationshipDao.countVshopVipRelationshipByInviterUserId(inviterUserId,source);
		pageBean.setTotalCount(vipCount);
		pageBean.setCurrentPage(pageParam.getPageNum());
		pageBean.setNumPerPage(pageParam.getNumPerPage());
		if(vipCount == 0){
			cre.setBusinessObj(pageBean);
			return cre;
		}
		List<VshopVipRelationship> vipList = vshopVipRelationshipDao.getVshopVipRelationships(pageParam,inviterUserId);
		List<VshopVipRelationshipDto> resultList = new ArrayList<VshopVipRelationshipDto>();
		for(VshopVipRelationship vipRelationship:vipList){
			VshopVipRelationshipDto vipDto = new VshopVipRelationshipDto();
			VshopVipInfo vshopVipInfo = vshopVipInfoDao.getVshopVipInfoByUserId(vipRelationship.getInvitedUserId());
			if(vshopVipInfo == null){
				log.error("vip或者svip用户不存在,userId is:{}", inviterUserId);
			}else{
				vipDto.setUserId(vipRelationship.getInvitedUserId());
				vipDto.setIdentity(vshopVipInfo.getIdentity());
				vipDto.setInviteTime(vipRelationship.getInviteTime());
				vipDto.setSource(vipRelationship.getSource());
				resultList.add(vipDto);
			}
			
		}
		pageBean.setRecordList(resultList);
		cre.setBusinessObj(pageBean);
		return cre;
	}

	public CommonResultEntity<Integer> getInvitedVipCount(Long inviterUserId) {
		CommonResultEntity<Integer> cre = new CommonResultEntity<>();
		if(ValidateUtils.isNull(inviterUserId)){
			throw VshopException.PARAM_IS_NULL;
		}
		String source = "1,2";
		Integer count = vshopVipRelationshipDao.countVshopVipRelationshipByInviterUserId(inviterUserId,source);
		cre.setBusinessObj(count);
		return cre;
	}

}
