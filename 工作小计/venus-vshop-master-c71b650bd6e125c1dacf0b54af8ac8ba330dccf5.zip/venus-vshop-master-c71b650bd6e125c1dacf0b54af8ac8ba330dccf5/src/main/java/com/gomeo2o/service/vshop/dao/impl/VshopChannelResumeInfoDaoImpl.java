package com.gomeo2o.service.vshop.dao.impl;

import org.springframework.stereotype.Repository;

import com.gomeo2o.facade.vshop.entity.VshopChannelResumeInfo;
import com.gomeo2o.service.vshop.dao.VshopChannelResumeInfoDao;
import com.gomeo2o.service.vshop.dao.base.CBaseDaoImpl;

@Repository("name=vshopChannelResumeInfoDao")
public class VshopChannelResumeInfoDaoImpl extends CBaseDaoImpl<VshopChannelResumeInfo> implements VshopChannelResumeInfoDao {
	
	private String baseSQL = "com.gomeo2o.service.vshop.dao.impl.VshopChannelResumeInfoDaoImpl.";
}
