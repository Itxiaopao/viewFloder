package com.gomeo2o.facade.vshop.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.dto.ChannelMshopReqDto;
import com.gomeo2o.facade.vshop.dto.ChannelMshopRespDto;
import com.gomeo2o.facade.vshop.entity.VshopChannelInfo;
import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantChangeRecord;
import com.gomeo2o.facade.vshop.entity.VshopChannelMerchantInfo;
import com.gomeo2o.facade.vshop.entity.VshopChannelResumeInfo;
import com.gomeo2o.facade.vshop.service.VshopChannelFacade;
import com.gomeo2o.service.vshop.biz.ChannelMshopBiz;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @Description: 渠道美店接口 
 * @author: lixilong
 * @date: 2018年6月5日 下午4:24:34
 */
@Slf4j
@Service("vshopChannelFacade")
public class VshopChannelFacadeImpl implements VshopChannelFacade {
	
	@Autowired
	private ChannelMshopBiz channelMshopBiz;
	
	public CommonResultEntity<List<ChannelMshopRespDto>> getChannelMshopList(PageParam pageParam,ChannelMshopReqDto channelMshopReqDto){
		CommonResultEntity<List<ChannelMshopRespDto>> res = new CommonResultEntity<>();
		List<ChannelMshopRespDto> channelMshopList = channelMshopBiz.getChannelMshopList(pageParam,channelMshopReqDto);
		res.setBusinessObj(channelMshopList);
		return res;
	}
	
	public CommonResultEntity<Integer> getChannelMshopCount(ChannelMshopReqDto channelMshopReqDto){
		CommonResultEntity<Integer> res = new CommonResultEntity<>();
		Integer count = channelMshopBiz.getChannelMshopCount(channelMshopReqDto);
		res.setBusinessObj(count);
		return res;
	}
	/**
	 * 
	 * @Description: 创建渠道美店
     * @author: zhaoxingxing
     * @date: 2018年6月7日 下午4:23:18
     * @param vshopChannelInfo
     * @return
	 */
	@Override
	public CommonResultEntity<String> createVshopChannel(VshopChannelInfo vshopChannelInfo) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		
		Long shopId = channelMshopBiz.createVshopChannel(vshopChannelInfo);
		
		cre.setBusinessObj(String.valueOf(shopId));
		return cre;
	}
	/**
	 * 
	 * @Description: 创建店主身份 
     * @author: zhaoxingxing
     * @date: 2018年6月7日 下午4:23:36
     * @param vshopChannelMerchantInfo
     * @return
	 */
	
	@Override
	public CommonResultEntity<String> createVshopChannelMerchant(VshopChannelMerchantInfo vshopChannelMerchantInfo) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		Long merchantId = channelMshopBiz.createVshopChannelMerchant(vshopChannelMerchantInfo);
		cre.setBusinessObj(String.valueOf(merchantId));
		return cre;
	}
	
	@Override
	public CommonResultEntity<String> updateVshopChannelById(VshopChannelInfo vshopChannelInfo) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		channelMshopBiz.updateVshopChannelById(vshopChannelInfo);
		return cre;
	}

	@Override
	public CommonResultEntity<String> updateVshopChannelMerchantById(VshopChannelMerchantInfo shopChannelMerchantInfo) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		channelMshopBiz.updateVshopChannelMerchantById(shopChannelMerchantInfo);
		return cre;
	}

	@Override
	public CommonResultEntity<ChannelMshopRespDto> getChannelMshopById(Long id) {
		CommonResultEntity<ChannelMshopRespDto> cre = new CommonResultEntity<ChannelMshopRespDto>();
		ChannelMshopRespDto cmrd= channelMshopBiz.getChannelMshopById(id,null);
		cre.setBusinessObj(cmrd);
		return cre;
	}

	@Override
	public CommonResultEntity<String> createShopChannelMerchantChangeRecord(VshopChannelMerchantChangeRecord vcmcr) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		
		Long shopId = channelMshopBiz.createShopChannelMerchantChangeRecord(vcmcr);
		
		cre.setBusinessObj(String.valueOf(shopId));
		return cre;
	}

	@Override
	public CommonResultEntity<String> createShopChannelResume(VshopChannelResumeInfo vcri) {
		CommonResultEntity<String> cre = new CommonResultEntity<String>();
		
		Long shopId = channelMshopBiz.createShopChannelResume(vcri);
		
		cre.setBusinessObj(String.valueOf(shopId));
		return cre;
	}

	@Override
	public CommonResultEntity<ChannelMshopRespDto> getChannelMshopByParams(Long id, String storeCode) {
		CommonResultEntity<ChannelMshopRespDto> cre = new CommonResultEntity<ChannelMshopRespDto>();
		ChannelMshopRespDto dto = channelMshopBiz.getChannelMshopById(id,storeCode);
		cre.setBusinessObj(dto);
		return cre;
	}

	@Override
	public CommonResultEntity<ChannelMshopRespDto> getChannelShopBindingParms(String storeCode) {
		CommonResultEntity<ChannelMshopRespDto> cre = new CommonResultEntity<ChannelMshopRespDto>();
		ChannelMshopRespDto dto = channelMshopBiz.getChannelMshopByStoreCode(storeCode);
		if(dto.getVshopChannelInfo() != null){
			cre.setBusinessObj(dto);
		}else {
			cre.setCode(1);
		}
		return cre;
	}
}
