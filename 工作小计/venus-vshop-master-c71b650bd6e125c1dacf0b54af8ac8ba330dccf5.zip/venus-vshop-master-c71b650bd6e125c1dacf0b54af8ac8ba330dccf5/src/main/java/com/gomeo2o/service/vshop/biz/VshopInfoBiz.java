package com.gomeo2o.service.vshop.biz;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.event.listener.CoreEventDispatcher;
import com.gomeo2o.event.vshop.CreateVshopEvent;
import com.gomeo2o.event.vshop.UpdateVshopEvent;
import com.gomeo2o.facade.vshop.entity.VshopDistributionItem;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfoCtx;
import com.gomeo2o.facade.vshop.enums.ProductStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopStatusEnum;
import com.gomeo2o.facade.vshop.enums.VshopTypeEnum;
import com.gomeo2o.facade.vshop.exception.VshopException;
import com.gomeo2o.service.vshop.dao.VshopInfoCtxDao;
import com.gomeo2o.service.vshop.dao.VshopInfoDao;
import com.gomeo2o.utils.StringUtil;
import com.gomeo2o.utils.ValidateUtils;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

@Slf4j
@Service("name=vshopInfoBiz")
public class VshopInfoBiz {

	private final String VSHOP_INFO_KEY = "vshop:vshopInfo_userId:";

	@Resource(name = "vshopCache")
	Gcache vshopCache;

	@Autowired VshopInfoDao vshopInfoDao;

	@Autowired VshopDistributionItemBiz vshopProductBiz;

	@Autowired
	private CoreEventDispatcher coreEventDispatcher;

	@Autowired
	private IUserInfoManager iUserInfoManager;
	@Autowired
	private VshopInfoCtxDao vshopInfoCtxDao;

	public VshopInfoBiz() {
	}

	public long createVshop(VshopInfo vshopInfoEntity) {
		// 获取自增vshopId
		long vshopId = vshopInfoDao.insert(vshopInfoEntity);
		log.info("开店完成"+vshopId);
		//新增CTX数据到vshop_info_ctx表中
		VshopInfoCtx ctx = new VshopInfoCtx();
		ctx.setVshopId(vshopId);
		ctx.setCtx(vshopInfoEntity.getCtx());
		ctx.setUserId(vshopInfoEntity.getUserId());
		vshopInfoCtxDao.insertVshopInfoCtx(ctx);

		// 发布美店创建事件
		CreateVshopEvent event = new CreateVshopEvent(vshopId);
		coreEventDispatcher.publish(event);
		log.info("发布事件"+event);
		//更新美店用户信息
		iUserInfoManager.modifyUserInfo(vshopInfoEntity.getUserId() + "", vshopId + "");
		log.info("更新用户信息");
		return vshopId;
	}

	public void updateVshop(VshopInfo vshopInfoEntity) {
		// 更新店铺信息
	    vshopInfoDao.update(vshopInfoEntity);
		// 发布更新美店信息事件
		UpdateVshopEvent event = new UpdateVshopEvent(vshopInfoEntity.getVshopId());
		coreEventDispatcher.publish(event);
	}

	public VshopInfo queryVshopByuserId(long userId) {
		if (ValidateUtils.isNull(userId)) {
			throw VshopException.PARAM_IS_NULL;
		}
		String s = vshopCache.get(VSHOP_INFO_KEY + userId);
		if(StringUtil.notEmpty(s)){
			try {
				VshopInfo vshopInfo = JSON.parseObject(s, VshopInfo.class);
				//更新缓存操作
				if(vshopInfo!=null&&vshopInfo.getVshopIdentity()==null){
					VshopInfo vshop = new VshopInfo();
					vshop.setVshopId(vshopInfo.getVshopId());
					vshop.setVshopIdentity(1);
					this.updateVshop(vshop);
					vshopInfo.setVshopIdentity(1);
				}
				return vshopInfo;
			} catch (Exception e) {
				log.error("vshopGcache.get error,userId:"+userId);
			}
		}
		return vshopInfoDao.queryVshopByuserId(userId);
	}

	public VshopInfo queryVshopById(long vshopId) {
		return vshopInfoDao.getById(vshopId);
	}

	public void queryVshopName(long vshopId, String vshopName) {
		if (ValidateUtils.isNull(vshopName) || ValidateUtils.isNull(vshopId)) {
			throw VshopException.PARAM_IS_NULL;
		}
		vshopInfoDao.queryVshopName(vshopId, vshopName);
	}

	/**
	 * 
	 * @Title: updateVshopStatus
	 * @Description: 运营后台更改美店状态
	 * @param vshopId
	 * @param vshopStatus
	 * @return: void
	 */
	@Transactional
	public void updateVshopStatus(long vshopId, Integer vshopStatus) {
		updateVshopStatusInner(vshopId, vshopStatus);
		// 发布更新微店信息事件
		UpdateVshopEvent event = new UpdateVshopEvent(vshopId);
		coreEventDispatcher.publish(event);
	}

	public void updateVshopStatusInner(long vshopId, Integer vshopStatus) {
		vshopInfoDao.updateVshopStatus(vshopId, vshopStatus);
		// 如果是冻结店铺，下架所有已上架的商品
		if (VshopStatusEnum.DONGJIE.getValue() == vshopStatus.intValue()) {
			VshopDistributionItem vshopProductadd = new VshopDistributionItem();
			vshopProductadd.setVshopId(vshopId);
			vshopProductadd.setStatus(ProductStatusEnum.XIAJIA.getValue());
			vshopProductBiz.updateProductaddByDongJie(vshopProductadd);
		}
	}

	public List<VshopInfo> queryVshopInfoListByCriteria(PageParam pageParam,  Map<String, Object> criteria) {
		return vshopInfoDao.queryVshopInfoListByCriteria(pageParam,criteria);
	}

	public Integer queryVshopInfoCountByCriteria( Map<String, Object> criteria) {
		return vshopInfoDao.queryVshopInfoCountByCriteria(criteria);
	}

	public List<VshopInfo> queryVshopInfoListForVip(Map<String,Object> sqlParams) {
		return vshopInfoDao.queryVshopInfoListForVip(sqlParams);
	}

	public Integer queryVshopInfoCountByShiId(long shiId, int vshopStatus) {
		return vshopInfoDao.queryVshopInfoCountByShiId(shiId, vshopStatus);
	}

	public List<VshopInfo> queryVshopInfoListByShiId(PageParam pageParam, long shiId, int vshopStatus) {
		return vshopInfoDao.queryVshopInfoListByShiId(pageParam, shiId, vshopStatus);
	}

	public boolean queryVshopNameByApp(String vshopName) {
		if (ValidateUtils.isNull(vshopName)) {
			throw VshopException.PARAM_IS_NULL;
		}
		return vshopInfoDao.queryVshopNameByApp(vshopName);
	}

	/**
	 * @Description: 校验微店id存在与否
	 * @author: guowenbo
	 * @date: 2015年6月4日 上午10:42:23
	 * @param vshopId
	 */
	public void checkVshop(long vshopId) {
		vshopInfoDao.checkVshop(vshopId);
	}

	/**
	 * @Description: 校验用户是否已有微店
	 * @author: guowenbo
	 * @date: 2015年6月12日 下午3:59:26
	 * @param userId
	 */
	public void checkUser(long userId) {
		vshopInfoDao.checkUser(userId);
	}

	public List<VshopInfo> queryPopInfo(String vshopType, int vshopStatus) {
		return vshopInfoDao.queryPopInfo(vshopType, vshopStatus);
	}

	/**
	 * @Description: 校验用户店铺是否匹配
	 * @author: guowenbo
	 * @date: 2015年6月24日 上午10:34:21
	 * @param userId
	 * @param vshopId
	 */
	public void checkUserVshop(long userId, long vshopId) {
		vshopInfoDao.checkUserVshop(userId, vshopId);
	}

	public void updatePopInfo(VshopInfo vshopInfo) {
		VshopInfo oldVshop = queryVshopById(vshopInfo.getVshopId());
		vshopInfoDao.updatePopInfo(vshopInfo);
		if ((oldVshop.getVshopStatus() == VshopStatusEnum.SHENHE.getValue() || oldVshop.getVshopStatus() == VshopStatusEnum.SHENHESHIBAI.getValue())
				&& oldVshop.getVshopType() == VshopTypeEnum.SHANGJIA.getValue()) {
			if (vshopInfo.getVshopStatus() == VshopStatusEnum.JINGYING.getValue()) {
				// 表示xpop开店成功 发布xpop店创建事件
				CreateVshopEvent event = new CreateVshopEvent(vshopInfo.getVshopId());
				coreEventDispatcher.publish(event);
			}
		} else {
			// 发布店铺更新信息事件
			UpdateVshopEvent event = new UpdateVshopEvent(vshopInfo.getVshopId());
			coreEventDispatcher.publish(event);
		}
	}

	/**
	 * @Description: 根据userId删除美店信息
	 * @author: guowenbo
	 * @date: 2015年7月1日 下午2:19:47
	 * @param userId
	 */
	public void deleteVshopInfo(long userId) {
		vshopInfoDao.deleteVshopInfo(userId);
	}

	public boolean queryVshopNameByApp(long userId, String vshopName) {
		return vshopInfoDao.queryVshopNameByApp(userId, vshopName);
	}

	public Integer queryMshopCount() {
		return vshopInfoDao.queryMshopCount();
	}

	public void sendMQ(long vshopId) {
		// 发布更新美店信息事件
        UpdateVshopEvent event = new UpdateVshopEvent(vshopId);
        coreEventDispatcher.publish(event);
	}

	/**
	 * 
	 * @Description: 从旧版APP拉去数据创建到新版APP
	 * @author: zhaoxingxing
	 * @date: 2017年2月17日 下午12:04:26
	 * @param vshopInfoEntity
	 * @return
	 */
	// @Transactional
	public long createNewVshop(VshopInfo vshopInfoEntity) {
		// 获取自增vshopId
		Long vshopId = vshopInfoDao.insertNewVshop(vshopInfoEntity);
		if (vshopInfoEntity.getVshopType() == VshopTypeEnum.MEIDIAN.getValue()
				&& vshopInfoEntity.getVshopStatus() == VshopStatusEnum.JINGYING.getValue()) {
			// 发布美店创建事件
			CreateVshopEvent event = new CreateVshopEvent(vshopId);
			coreEventDispatcher.publish(event);
		}
		return vshopId;
	}

	public List<VshopInfo> queryVshopInfoList(PageParam pageParam,
	        Integer vshopStatus) {
		return vshopInfoDao.queryVshopInfoList(pageParam, vshopStatus);
	}
	
	public List<Long> queryVshopInfoListById(Map map) {
		return vshopInfoDao.queryVshopInfoListById(map);
	}

	public void updateVshopNameByVshopId(Long vshopId) {
		vshopInfoDao.updateVshopNameByVshopId(vshopId);
	}

	public void updataIsStarByShopId(long vshopId, int isStar) {
		vshopInfoDao.updataIsStarByShopId(vshopId, isStar);
	}
	
	public List<VshopInfo> getByVshopIds(List<Long> ids){
		return vshopInfoDao.getByVshopIds(ids);
	}

	public List<VshopInfo> queryVshopInfoListByShopName(PageParam pageParam,String shopName) {
		return vshopInfoDao.queryVshopInfoListByShopName(pageParam,shopName);
	}
	public void queryVshopPhoneNo(long vshopId, String phoneNo) {
		vshopInfoDao.queryVshopPhoneNo(vshopId,phoneNo);
	}
}
