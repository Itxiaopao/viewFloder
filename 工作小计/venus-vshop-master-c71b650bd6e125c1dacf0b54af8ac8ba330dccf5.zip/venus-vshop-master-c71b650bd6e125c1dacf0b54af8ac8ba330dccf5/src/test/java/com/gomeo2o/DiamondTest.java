package com.gomeo2o;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.gome.diamond.annotations.DiamondValue;

/**
 * @author limenghui
 * @create 2020-07-30 11:13
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes= VenusVshopApplication.class)
public class DiamondTest {
    @Value("${spring.application.name}")
    private String applicationName;
    @DiamondValue("${gcache.address}")
    private String cacheAddress;
    @DiamondValue("${gcache.businessKey.vshop}")
    private String cacheKey;
    @DiamondValue("${mq.shelf.shelfmanage_topic}")
    private String shelfmanage_topic;
    @DiamondValue("${mq.address}")
    private String mqAddress;
    @DiamondValue("${vshop.tddl.appname}")
    private String vshopAppName;
    @DiamondValue("${vshop.tddl.dbGroupKey}")
    private String vshopGroupKey;
    @DiamondValue("${vshopShard.tddl.appname}")
    private String vshopShardAppName;
    @DiamondValue("${vshopShard.tddl.dbGroupKey}")
    private String vshopShardGroupKey;
    @DiamondValue("${dubbo.registry.address}")
    private String dubboAddress;

    @Test
    public void testDiamond(){
        System.err.println("applicationName" + JSON.toJSONString(applicationName));
        System.err.println("cacheAddress" + JSON.toJSONString(cacheAddress));
        System.err.println("cacheKey" + JSON.toJSONString(cacheKey));
        System.err.println("shelfmanage_topic" + JSON.toJSONString(shelfmanage_topic));
        System.err.println("mqAddress" + JSON.toJSONString(mqAddress));
        System.err.println("vshopAppName" + JSON.toJSONString(vshopAppName));
        System.err.println("vshopGroupKey" + JSON.toJSONString(vshopGroupKey));
        System.err.println("vshopShardAppName" + JSON.toJSONString(vshopShardAppName));
        System.err.println("vshopShardGroupKey" + JSON.toJSONString(vshopShardGroupKey));
        System.err.println("dubboAddress" + JSON.toJSONString(dubboAddress));

    }
}
