package com.gomeo2o;

import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;
import org.junit.Before;
import org.junit.Test;

/**
 * @author limenghui
 * @create 2020-07-28 18:28
 */
public class ZookeeperWatchDemo {
    ZooKeeper zk = null;

    @Before
    public void init() throws Exception{

        zk = new ZooKeeper("mini1:2181,mini2:2181,mini3:2181",2000,new Watcher(){

            public void process(WatchedEvent event) {

                if(event.getState() == Event.KeeperState.SyncConnected && event.getType() == Event.EventType.NodeDataChanged){
                    System.out.println(event.getPath());
                    System.out.println(event.getType());
                    System.out.println("test event ");

                    try{
                        System.out.println(new String(zk.getData(event.getPath(), true, null),"UTF-8"));
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }else if(event.getState() == Event.KeeperState.SyncConnected && event.getType() == Event.EventType.NodeChildrenChanged){

                    System.out.println("子节点变化了");
                }
            }

        });

    }

    @Test
    public void testGetWatch() throws Exception{
        while(true){
            byte[] data = zk.getData("/data", true, null);
            System.out.println(new String (data,"UTF-8"));
            Thread.sleep(30000);
        }
    }

}
