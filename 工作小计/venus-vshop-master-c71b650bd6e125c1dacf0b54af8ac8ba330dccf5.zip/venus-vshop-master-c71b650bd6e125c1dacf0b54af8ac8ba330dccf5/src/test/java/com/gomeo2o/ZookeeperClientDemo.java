package com.gomeo2o;

import java.util.List;

import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.junit.Before;
import org.junit.Test;

/**
 * @author limenghui
 * @create 2020-07-28 18:30
 */
public class ZookeeperClientDemo {
    ZooKeeper zk = null;

    @Before
    public void setUp() throws Exception{
        zk = new ZooKeeper("10.112.179.149:2181,10.112.179.150:2181,10.112.179.151:2181",12000,null);
    }

    @Test
    public void testCreate() throws Exception{
        String create = zk.create("/zhiquanqiao", "hanyuli".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        System.out.println(create);
    }

    @Test
    public void testUpdate() throws Exception{
        zk.setData("/zhiquanqiao", "my girl:hanyu li".getBytes(), -1);
        zk.close();
    }

    @Test
    public void testGet() throws Exception{
        String path = "/test02";
        zk.create(path, "test".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
        byte[] data = zk.getData(path, false, null);
        System.out.println("结果是：" + new String(data, "UTF-8"));
        zk.close();
    }

    @Test
    public void testListChildren() throws Exception{
        List<String> children = zk.getChildren("/data", false);

        for(String child:children){
            System.out.println(child);
        }
        zk.close();
    }

    @Test
    public void testRm() throws Exception{
        zk.delete("/zhiquanqiao", 1);
        zk.close();
    }

}
