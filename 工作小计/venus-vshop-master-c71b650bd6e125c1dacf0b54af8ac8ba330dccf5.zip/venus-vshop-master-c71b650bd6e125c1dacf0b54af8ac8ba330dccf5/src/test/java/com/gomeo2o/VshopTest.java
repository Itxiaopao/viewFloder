package com.gomeo2o;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeplus.venus.common.imageutil.IllegalExpressionException;
import com.gomeplus.venus.common.imageutil.UrlConverter;

/**
 * @author limenghui
 * @create 2020-07-29 15:31
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes= VenusVshopApplication.class)
public class VshopTest {
    @Autowired
    VshopFacade vshopFacade;
    @Autowired
    private UrlConverter urlConverter;


    @Test
    public void test(){
        VshopInfo vshopInfo = new VshopInfo();
        vshopInfo.setUserId(12345678L);
        vshopInfo.setVshopName("1234567891011的测试店铺");
        CommonResultEntity<String> vshop2 = vshopFacade.createVshop2(vshopInfo);
        System.err.println("结果是" + JSON.toJSONString(vshop2));

    }

    @Test
    public void test01(){
        String hashedFullLocation = null;
        try {
            hashedFullLocation = urlConverter.getHashedFullLocation("http://gfs10.gomein.net.cn/T1YFxTByJT1R4cSCrK.png");
        } catch (IllegalExpressionException e) {
            e.printStackTrace();
        }
        System.err.println("结果是" + JSON.toJSONString(hashedFullLocation));

    }

}
