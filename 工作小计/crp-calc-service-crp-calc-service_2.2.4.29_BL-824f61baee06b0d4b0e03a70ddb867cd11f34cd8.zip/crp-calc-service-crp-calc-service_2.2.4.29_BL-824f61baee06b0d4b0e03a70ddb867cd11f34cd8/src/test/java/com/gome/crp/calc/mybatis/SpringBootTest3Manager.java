package com.gome.crp.calc.mybatis;

import com.gome.crp.calc.mybatis.mapper.SapRecordMapper;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ISapRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class SpringBootTest3Manager {
    @Autowired
    private SapRecordMapper sapRecordMapper;

    @Autowired
    private ISapRecordService iSapRecordService;

    @Transactional
    public void conver(){
        SapRecord sapRecord1 = new SapRecord();
        sapRecord1.setBstkd("dddddddddddddd");
        sapRecordMapper.insert(sapRecord1);

        List<SapRecord> entityList = new ArrayList<>();
/*        SapRecord sapRecord = new SapRecord();
        sapRecord.setId(1L);
        sapRecord.setFlag(500);
        entityList.add(sapRecord);*/

        SapRecord sapRecord2 = new SapRecord();
        sapRecord2.setId(2000L);
        sapRecord2.setFlag(100);
        entityList.add(sapRecord2);


        boolean b = iSapRecordService.updateBatchById(entityList);
    }
}
