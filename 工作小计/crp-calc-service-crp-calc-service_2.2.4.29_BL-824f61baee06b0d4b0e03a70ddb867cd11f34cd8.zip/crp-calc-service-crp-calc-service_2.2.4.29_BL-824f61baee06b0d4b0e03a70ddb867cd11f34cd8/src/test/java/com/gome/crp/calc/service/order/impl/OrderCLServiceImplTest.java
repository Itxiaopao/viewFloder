package com.gome.crp.calc.service.order.impl;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderCLServiceImplTest {
    @Autowired
    private OrderCLServiceImpl orderCLServiceImpl;

    @Test
    public void process() {
        OrderCalcDto orderCalcDto = new OrderCalcDto();
        orderCalcDto.setOrderId("19015439901");
        orderCalcDto.setDeliveryId("2570405598");
        orderCalcDto.setSkuNo("109968074");
        orderCalcDto.setDetailId("1149598446");
        orderCalcDto.setGomeState(BaseConstants.ORDER_CL_STATUS);
        orderCLServiceImpl.process(orderCalcDto);
    }
}
