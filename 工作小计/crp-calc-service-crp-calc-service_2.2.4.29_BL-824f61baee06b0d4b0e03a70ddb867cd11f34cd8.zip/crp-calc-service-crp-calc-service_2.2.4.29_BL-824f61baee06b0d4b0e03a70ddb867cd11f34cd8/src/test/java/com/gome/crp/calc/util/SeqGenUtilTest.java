package com.gome.crp.calc.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SeqGenUtilTest {
    @Autowired
    private SeqGenUtil seqGenUtil;

    @Test
    public void testSeqGen() {
        Long aLong = seqGenUtil.nextCrpCalcCommonId();
        System.out.println(aLong);
    }

}
