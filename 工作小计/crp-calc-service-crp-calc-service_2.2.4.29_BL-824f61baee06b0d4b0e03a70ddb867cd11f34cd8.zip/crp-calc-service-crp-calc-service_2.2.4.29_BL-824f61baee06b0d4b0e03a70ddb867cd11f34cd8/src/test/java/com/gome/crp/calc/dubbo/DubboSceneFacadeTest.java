package com.gome.crp.calc.dubbo;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.impl.ProfitStaffService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.facade.dto.ResultDTO;
import com.gome.crp.calc.facade.dto.orderCalc.CouponsDto;
import com.gome.crp.calc.facade.dto.orderCalc.DetailGoodsDto;
import com.gome.crp.calc.facade.dto.orderCalc.OrderDto;
import com.gome.crp.calc.facade.dto.orderCalc.res.OrderCalcResDto;
import com.gome.crp.calc.facade.dubbo.IDubboSceneFacade;



@RunWith(SpringRunner.class)
@SpringBootTest
public class DubboSceneFacadeTest {
	@Autowired
	private IDubboSceneFacade dubboSceneFacade;
	@Autowired
	private ProfitStaffService profitStaffService;

	@Test
	public void fn() {
		
		
		OrderDto orderDto = new OrderDto();
//		String json = "{\"detailGoodsVos\":[{\"channelNo\":\"13\",\"commerceItemId\":\"49307192\",\"eaBrandCode\":\"00818\",\"eaGroupCode\":\"R1201004\",\"shareUserId\":\"\",\"shopNo\":\"A00G\",\"shopType\":\"pshop\",\"supplier\":\"0020000947\"}],\"orderId\":\"19015749578\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.0\",\"requestParamsCommonModel\":\"{\\\"user\\\":{\\\"userId\\\":\\\"100042196547\\\",\\\"mobile\\\":\\\"15901017165\\\",\\\"userGrade\\\":\\\"15\\\",\\\"userType\\\":\\\"COMMON\\\",\\\"loginStatus\\\":\\\"logined\\\",\\\"loginName\\\":\\\"gm_15901017165rye\\\",\\\"userIP\\\":\\\"10.2.116.115\\\",\\\"userExtension\\\":{\\\"engineeringMachine\\\":false,\\\"accountPeriod\\\":false}},\\\"requestSource\\\":{\\\"siteId\\\":\\\"homeSite\\\",\\\"terminal\\\":\\\"wap\\\",\\\"txId\\\":\\\"5a0f6071-6979-45cb-a18c-bfe8093d45d2\\\",\\\"invokeFrom\\\":\\\"app_cart\\\",\\\"version\\\":\\\"asersets\\\"},\\\"operateDomain\\\":\\\"settlement_domain\\\"}\",\"plt\":\"wap\"},\"submittedDate\":1585214683976,\"userId\":\"100042196547\"}"; 
		String json = "{\"detailGoodsVos\":[{\"channelNo\":\"16\",\"commerceItemId\":\"49537041\",\"couponsDtos\":[],\"eaBrandCode\":\"00001\",\"eaGroupCode\":\"R0501002\",\"shareUserId\":\"100053058202\",\"shopNo\":\"A007\",\"shopType\":\"pshop\",\"supplier\":\"0020000947\"}],\"orderId\":\"19015918484\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.0\",\"cmpid\":\"Plus\",\"requestParamsCommonModel\":\"{\\\"user\\\":{\\\"userId\\\":\\\"100051352301\\\",\\\"mobile\\\":\\\"13811243526\\\",\\\"userGrade\\\":\\\"13\\\",\\\"userType\\\":\\\"COMMON\\\",\\\"loginStatus\\\":\\\"logined\\\",\\\"loginName\\\":\\\"gm_13811243526xoc\\\",\\\"userIP\\\":\\\"10.112.3.67\\\",\\\"userExtension\\\":{\\\"engineeringMachine\\\":false,\\\"accountPeriod\\\":false}},\\\"requestSource\\\":{\\\"siteId\\\":\\\"homeSite\\\",\\\"terminal\\\":\\\"aPhone\\\",\\\"txId\\\":\\\"43ac2883-5779-4021-8fe2-936c0e9a77d9\\\",\\\"invokeFrom\\\":\\\"app_cart\\\",\\\"version\\\":\\\"09e8feb0-b99b-409a-a85f-cf3737879862\\\"},\\\"operateDomain\\\":\\\"settlement_domain\\\"}\",\"plt\":\"aPhone\"},\"submittedDate\":1585753061672,\"userId\":\"100051352301\"}";
		orderDto = JSONObject.parseObject(json, OrderDto.class);
		
		
		ResultDTO<OrderCalcResDto> sceneUser = dubboSceneFacade.getSceneUser(orderDto);
		
		System.out.println(sceneUser.toString());
	}
	
}
