package com.gome.crp.calc.client.employee.impl;

import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StaffInfoServiceTest {

    @Autowired
    StaffInfoService staffInfoService;

    @Test
    public void queryGomeEmployeeInformationTest() {
        // Dubbo查询员工/促销员信息, 入参: {"brandId":"00001","categoryId":"R05","currentPage":0,"pageSize":0,"shop":"A007","staffLevel":"4"}
        // Dubbo查询员工/促销员信息, 入参: {"brandId":"00001","categoryId":"R05","currentPage":0,"pageSize":0,"shop":"A007","staffLevel":"4"}
        List<EmployeeInfoDto> employeeInfoDtos = staffInfoService.queryGomeEmployeeInformation("R05", "00001", null, "A007", "4");
        System.out.println(employeeInfoDtos);
    }

}