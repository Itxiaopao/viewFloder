package com.gome.crp.calc.client.sap;

import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.dto.ermDto.OccupyBudgetResDto;
import com.gome.crp.calc.dto.sapDto.*;
import com.gome.crp.calc.util.GcacheUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IQueryPlanServiceTest {
    @Autowired
    private IQueryPlanService iQueryPlanService;
    @Autowired
    private GcacheUtil gcacheUtil;

    @Test
    public void terminatePlan() {
        TerminatePlanReqDto reqDto = new TerminatePlanReqDto();
        reqDto.setPlanId("123");
        TerminatePlanResDto terminatePlanResDto = iQueryPlanService.terminatePlan(reqDto);
        System.out.println(terminatePlanResDto);
    }

    @Test
    public void returnResource() {
        String cpqsBudgetReleaseUniqueKey = CacheKeyConstants.getCpqsBudgetReleaseUniqueKey("666");
        //幂等校验
        gcacheUtil.deleteKey(new String[]{cpqsBudgetReleaseUniqueKey});

        ResourceReturnReqDto reqDto = new ResourceReturnReqDto();
        reqDto.setPlanId("648");
        reqDto.setRequestUuid("666");
        reqDto.setReturnAmount(new BigDecimal("50"));
        ClientResultDTO<ResourceReturnResDto> resourceReturnResDtoClientResultDTO = iQueryPlanService.returnResource(reqDto);
        System.out.println(resourceReturnResDtoClientResultDTO);
    }


    @Test
    public void occupyResource() {
        String cpqsBudgetOccupyUniqueKey = CacheKeyConstants.getCpqsBudgetOccupyUniqueKey("123");
        //幂等校验
        gcacheUtil.deleteKey(new String[]{cpqsBudgetOccupyUniqueKey});

        ResourceOccupyReqDto reqDto = new ResourceOccupyReqDto();
        reqDto.setPlanId("648");
        reqDto.setRequestUuid("123");
        reqDto.setOccupyAmount(new BigDecimal("50"));
        ClientResultDTO<OccupyBudgetResDto> occupyBudgetResDtoClientResultDTO = iQueryPlanService.occupyResource(reqDto);
        System.out.println(occupyBudgetResDtoClientResultDTO);
    }
}
