package com.gome.crp.calc.dubbo;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.facade.dto.orderCalc.OrderDto;
import org.aspectj.weaver.ast.Or;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DubboProfitStaffFacadeImplTest {

    @Autowired
    private DubboProfitStaffFacadeImpl dubboProfitStaffFacade;

    @Test
    public void getProfitStaff() {
        String json = "{\"detailGoodsVos\":[{\"channelNo\":\"16\",\"commerceItemId\":\"6297897486\",\"couponsDtos\":[],\"eaBrandCode\":\"00001\",\"eaGroupCode\":\"R0501002\",\"shopNo\":\"A72R\",\"shopType\":\"pshop\",\"supplier\":\"\"}],\"orderId\":\"12506672027\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.4\",\"cmpid\":\"PlusAppStore\",\"plt\":\"iPhone\"},\"submittedDate\":1592371427509,\"userId\":\"72002547025\"}";
        OrderDto orderDto = new OrderDto();
        orderDto = JSON.parseObject(json, OrderDto.class);
        dubboProfitStaffFacade.getProfitStaff(orderDto) ;
    }

    @Test
    public void defualtCouponDto() {
    }
}