package com.gome.crp.calc.util;

import com.gome.crp.calc.CrpCalcServiceApplication;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CrpCalcServiceApplication.class})
public class RedisLockTest {
    @Autowired
    private RedisLockHelper redisLockHelper;

    @Test
    public void lock() {
        RedisLock redisLock = redisLockHelper.getLock("123");
        redisLock.lock();
        redisLock.unlock();
        redisLock.lock();
        redisLock.unlock();
        System.out.println("ooooookkkkkk");

    }

}
