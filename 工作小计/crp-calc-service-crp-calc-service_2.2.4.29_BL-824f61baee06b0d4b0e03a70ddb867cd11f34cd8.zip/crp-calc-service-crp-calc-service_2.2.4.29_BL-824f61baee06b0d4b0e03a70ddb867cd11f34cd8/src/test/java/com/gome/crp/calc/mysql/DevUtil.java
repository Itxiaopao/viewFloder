package com.gome.crp.calc.mysql;

import java.io.BufferedReader;
import java.io.File;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

public class DevUtil {

    //需要去除的表前缀,解析表名称才需要
    private static String tbPrefix = "crp_";

    //表名称
    private String tbName;
    //表描述
    private String desc;

    //是否需要引入java.util.Date;
    private boolean importDate;

    public static void main(String[] args) throws Exception {
//        for (int i = 1; i <= 6; i++) {
            DevUtil dev= new DevUtil();
            String path = "D:/crpdb/"+"create.txt";
            dev.modelToFile(path, "com.gome.crp.model",true,"D:/workspace/crp-mapper/src/main/java/com/gome/crp/model/");
            dev.mapperToFile(path, "com.gome.crp.calc.mybatis.mapper","com.gome.crp.model", "D:/workspace/crp-mapper/src/main/java/com/gome/crp/mapper/");
//        }
    }

    //生成.java文件在指定目录
    public void modelToFile(String path,String sourcePackage,boolean lombook,String sourcePathFolder)throws Exception{
        String res = printModel(path, sourcePackage, lombook);
        if(sourcePathFolder!=null){
            String p = sourcePathFolder+tbName+".java";
            FileUtils.writeStringToFile(new File(p), res, "UTF-8");
        }
    }

    public String mapperToFile(String path,String sourcePackage,String modelPkg,String sourcePathFolder)throws Exception{
        Map<String, String> map = System.getenv();
        String userName = "zhangshuang";//map.get("USERNAME");
        List<TableFieldInfo> tbList = parse(path);
        StringBuilder builder = new StringBuilder();
        if(!tbList.isEmpty()){
            builder.append("package "+sourcePackage+";\n\n");
            builder.append("import com.baomidou.mybatisplus.core.mapper.BaseMapper;\n");
            builder.append("import "+modelPkg+"."+tbName+";\n\n");
            builder.append("/**\n");
            if(desc!=null){
                builder.append(" * "+desc+" Mapper\n");
            }
            if(userName!=null && !"".equals(userName)){
                builder.append(" * @author "+userName+"\n");
            }
            builder.append(" *\n");
            builder.append(" */\n");
            builder.append("public interface "+tbName+"Mapper extends BaseMapper<"+tbName+">{\n");
            builder.append("\n}");
            String res = builder.toString();
            System.err.println(res);
            if(sourcePathFolder!=null){
                String p = sourcePathFolder+tbName+"Mapper.java";
                FileUtils.writeStringToFile(new File(p), res, "UTF-8");
            }
            return builder.toString();
        }
        return null;
    }

    //打印Java模型
    public String printModel(String path,String sourcePackage,boolean lombook)throws Exception{
        Map<String, String> map = System.getenv();
        String userName = "zhangshuang";map.get("USERNAME");
        List<TableFieldInfo> tbList = parse(path);
        StringBuilder builder = new StringBuilder();
        if(!tbList.isEmpty()){
            builder.append("package "+sourcePackage+";\n\n");
            if(importDate){
                builder.append("import java.util.Date;\n\n");
            }

            if(lombook){
                builder.append("import lombok.Getter;\n");
                builder.append("import lombok.Setter;\n");
                builder.append("import lombok.ToString;\n\n");
            }
            builder.append("/**\n");
            if(desc!=null){
                builder.append(" * "+desc+" Model\n");
            }
            if(userName!=null && !"".equals(userName)){
                builder.append(" * @author "+userName+"\n");
            }
            builder.append(" *\n");
            builder.append(" */\n");
            if(lombook){
                builder.append("@Getter\n");
                builder.append("@Setter\n");
                builder.append("@ToString\n");
            }
            builder.append("public class "+tbName+" {\n");
            for(TableFieldInfo tb:tbList ){
                builder.append("\n\tprivate "+tb.modelType +" "+ tb.modelField+"; //"+(tb.tbComment==null?tb.modelField:tb.tbComment));
            }
            builder.append("\n}");
            System.err.println(builder.toString());
            return builder.toString();
        }
        return null;
    }

    //打印MybatisResultMap
    public void printMybatisResultMap(String path)throws Exception{
        List<TableFieldInfo> tbList = parse(path);
        for(TableFieldInfo tb:tbList ){
            //<result column="id" property="id"/>
            System.out.println("<result column=\""+tb.tbField+"\" property=\""+tb.modelField+"\"/>");
        }
    }
    //打印条件
    public String getMybatisCondition(String path)throws Exception{
        List<TableFieldInfo> tbList = parse(path);
        StringBuilder sql = new StringBuilder();
        for(TableFieldInfo tb:tbList ){
            sql.append("\n<if test=\""+tb.modelField+" != null\"> "+tb.tbField+" = #{"+tb.modelField+"}, </if>");
        }
        return sql.toString();
    }

    //打印条件
    public void printAndCondition(String path)throws Exception{
        List<TableFieldInfo> tbList = parse(path);
        StringBuilder sql = new StringBuilder();
        for(TableFieldInfo tb:tbList ){
            sql.append("\n<if test=\""+tb.modelField+" != null\"> and "+tb.tbField+" = #{"+tb.modelField+"} </if>");
        }
        System.out.println(sql.toString());
    }

    //打印insert语句
    public void printMybatisInsert(String path,String tableName)throws Exception{
        List<TableFieldInfo> tbList = parse(path);
        StringBuilder sql = new StringBuilder("<insert id=\"insert\" useGeneratedKeys=\"true\" keyProperty=\"id\">");
        sql.append("\n INSERT INTO "+tableName+"(" );
        int count =0;
        for(TableFieldInfo tb:tbList ){
            sql.append(tb.tbOldField+",");
            count++;
            if(count>=4){
                sql.append("\n");
                count=0;
            }
        }
        count =0;
        sql.delete(sql.lastIndexOf(","), sql.length());
        sql.append(")").append("\nVALUES\n(");
        for(TableFieldInfo tb:tbList ){
            sql.append("#{"+tb.modelField+"},");
            count++;
            if(count>=4){
                sql.append("\n");
                count=0;
            }
        }
        sql.delete(sql.lastIndexOf(","), sql.length());
        sql.append(")\n</insert>");
        System.out.println(sql.toString());
    }

    //打印update语句
    public void printMybatisUpdate(String path,String tableName,String parameterType)throws Exception{
        StringBuilder sql = new StringBuilder("<update id=\"update\" parameterType=\""+parameterType+"\">");
        sql.append("\nUPDATE "+tableName).append("\n<set>");
        String condition = getMybatisCondition(path);
        sql.append(condition);
        int ix = sql.lastIndexOf(",");
        sql.delete(ix, ix+1);
        sql.append("\n</set>").append("\n</update>");
        System.out.println(sql.toString());
    }


    private List<TableFieldInfo> parse(String path) throws Exception {
        File file = new File(path);
        String text = FileUtils.readFileToString(file, "UTF-8").toLowerCase();
        BufferedReader br = new BufferedReader(new StringReader(text));
        String s = null;
        List<TableFieldInfo> tbList = new ArrayList<>();
        while ((s = br.readLine()) != null) {// 使用readLine方法，一次读一行
            if(StringUtils.isNotBlank(s)){
                String[] arr = s.split(" ");
                String join = StringUtils.join(Arrays.asList(arr), ",");
                //把每行内容以分割的数据变成一个list
                List<String> temp = Arrays.asList(StringUtils.split(join, ","));
                String tbField = temp.get(0);

                //获取表名称
                if("create".equalsIgnoreCase(tbField)){
                    String name = temp.get(2);
                    if(name.startsWith("`")){
                        name = name.substring(1);
                    }
                    if(name.endsWith("`")){
                        name = name.substring(0,name.length()-1);
                    }
                    if(name.startsWith(tbPrefix)){
                        name = name.replace(tbPrefix, "");
                    }
                    tbName = upperTable(name);
                }
                //获取表注释
                if(")".equals(tbField)){
                    for (String c : temp) {
                        if(c.startsWith("comment")){
                            int x = c.indexOf("'")+1;
                            int y = c.lastIndexOf("'");
                            desc = c.substring(x,y);
                            break;
                        }
                    }
                }
                if(StringUtils.isNotBlank(tbField) && StringUtils.startsWith(tbField, "`")){
                    TableFieldInfo tbModel = new TableFieldInfo();
                    //获取表列名称
                    String tbOldFiled=tbField;
                    tbField=tbField.substring(1, tbField.length() -1);
                    String filed = getFiled(tbField);
                    //获取表类型
                    String type = getType(s);
                    //获取表注释
                    String comment = getComment(s);
                    tbModel.tbOldField = tbOldFiled;
                    tbModel.tbField = tbField;
                    tbModel.modelField=filed;
                    tbModel.modelType = type;
                    tbModel.tbComment = comment;
                    tbList.add(tbModel);
                }
            }
        }
        br.close();
        return tbList;
    }

    private String getType(String str){
        String type = "String";
        if(str.indexOf("bigint")!=-1){
            type = "Long";
        }else if(str.indexOf("int")!=-1){
            if(str.indexOf("auto_increment")!=-1){
                type = "Long";
            }else{
                type = "Integer";
            }
        }else if(str.indexOf("timestamp")!=-1){
            importDate = true;
            type = "Date";
        }
        return type;
    }


    private String getComment(String str){
        String comment = null;
        int ix = str.indexOf("comment");
        if(ix!=-1){
            comment = str.substring(ix,str.length());
            int idx = comment.indexOf("'");
            if(idx!=-1){
                comment = comment.substring(idx,comment.length());
                comment  = comment.substring(1, comment.length()-2);
            }
        }
        return comment;
    }



    private String getFiled(String str){
        int ix = str.indexOf("_");
        if(ix!=-1){
            String f = str.substring(0, ix);
            String c = str.substring(ix+1, str.length());
            String u = c.substring(0, 1).toUpperCase();
            String e = c.substring(1, c.length());
            return getFiled(f+u+e);
        }
        return str;
    }

    private String upperTable(String str)
    {
        // 字符串缓冲区
        StringBuffer sbf = new StringBuffer();
        // 如果字符串包含 下划线
        if (str.contains("_"))
        {
            // 按下划线来切割字符串为数组
            String[] split = str.split("_");
            // 循环数组操作其中的字符串
            for (int i = 0, index = split.length; i < index; i++)
            {
                // 递归调用本方法
                String upperTable = upperTable(split[i]);
                // 添加到字符串缓冲区
                sbf.append(upperTable);
            }
        } else
        {// 字符串不包含下划线
            // 转换成字符数组
            char[] ch = str.toCharArray();
            // 判断首字母是否是字母
            if (ch[0] >= 'a' && ch[0] <= 'z')
            {
                // 利用ASCII码实现大写
                ch[0] = (char) (ch[0] - 32);
            }
            // 添加进字符串缓存区
            sbf.append(ch);
        }
        // 返回
        return sbf.toString();
    }


}
class TableFieldInfo{
    public String tbOldField;
    public String tbField;
    public String modelField;
    public String modelType;
    public String tbComment;
}
