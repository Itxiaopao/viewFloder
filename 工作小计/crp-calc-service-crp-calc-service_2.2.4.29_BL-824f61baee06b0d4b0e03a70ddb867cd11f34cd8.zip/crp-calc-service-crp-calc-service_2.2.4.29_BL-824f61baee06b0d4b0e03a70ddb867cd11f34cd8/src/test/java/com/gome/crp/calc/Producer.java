package com.gome.crp.calc;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.order.calc.dto.*;
import com.gome.crp.order.calc.util.SerializeUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Producer {
    public static void main(String[] args) throws MQClientException, InterruptedException {
        DefaultMQProducer producer = new DefaultMQProducer("test");
        producer.setInstanceName("instance");
        producer.setNamesrvAddr("10.112.178.137:9876;10.112.178.138:9876");
        producer.start();
        try {
            String json = "{\"deliveryList\":[{\"channelNo\":\"60\",\"gomeState\":\"CO\",\"goodsList\":[{\"categoryFirstId\":\"cat10000004\",\"categoryFourthId\":\"\",\"categorySecondId\":\"cat10000010\",\"categoryThirdId\":\"cat10000062\",\"commerceItemId\":\"48820384\",\"companyCode\":\"\",\"description\":\"一店一页-家用空调-格力-后端\",\"detailList\":[{\"buyNum\":1,\"detailId\":\"1149615128\",\"logicMasLoc\":\"BX01X011\",\"price\":1000,\"salesModel\":\"01\",\"supplier\":\"0020000947\"}],\"eaBrandCode\":\"00005\",\"eaGroupCode\":\"R0301001\",\"goodsType\":\"1\",\"salePrice\":1000,\"salesOrganization\":\"1001\",\"skuId\":\"1000225772\",\"skuName\":\"一店一页-家用空调-格力-后端\",\"skuNo\":\"109968060\"}],\"orderDate\":1584867952293,\"shippingGroupId\":\"2570409302\",\"shopNo\":\"G001\",\"shopType\":\"fshop\"}],\"loginName\":\"gm_15901017165rye\",\"orderId\":\"19015442900\",\"orderPrice\":1000,\"orderSalePrice\":1000,\"profileId\":\"100042196547\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.0\",\"plt\":\"wap\"},\"submittedDate\":1584866799921}";
            OrderDto orderDto = JSON.parseObject(json, OrderDto.class);
//            orderDto.setOrderId("12015436666");
//            orderDto.setProfileId("100048777602"); // 查询z的邀请人，下单人的邀请人是开单人，Y的集客活动也是用此字段
//            orderDto.setSubmittedDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2020-02-18 12:05:30"));
//
//            DeliveryDto deliveryDto = orderDto.getDeliveryList().get(0);
//            deliveryDto.setGomeState("CO");
//
//            GoodsDto goodsDto = deliveryDto.getGoodsList().get(0);
//            goodsDto.setStoreSellerId("00050688"); // 开单人编码
//            goodsDto.setRetailId("100048777602"); // 商品分享人编码
//            DetailGoodsDto detailGoodsDto = goodsDto.getDetailList().get(0);

            // 3001:美券 3002:蓝券 3003:红券 3004:运费券 3005:营销券
            // 券号（美券、营销券传ticketId）
            // 券id（红券、蓝券传券CouponId）
//            List<CouponsDto> couponsDtos = new ArrayList<>(); // 券的分享关系
//            CouponsDto couponsDto1 = new CouponsDto();
//            couponsDto1.setCouponId(""); // 红券 传 CouponId
//            couponsDto1.setCouponType(3003L);
//            couponsDtos.add(couponsDto1);
//            CouponsDto couponsDto2 = new CouponsDto();
//            couponsDto2.setTicketId(""); // 美券 传 券号
//            couponsDto2.setCouponType(3001L);
//            couponsDtos.add(couponsDto2);
//            CouponsDto couponsDto3 = new CouponsDto();
//            couponsDto3.setCouponId(""); // 红券 传 CouponId
//            couponsDto3.setCouponType(3003L);
//            couponsDtos.add(couponsDto3);
//            detailGoodsDto.setCouponsDtoList(couponsDtos);

            Message msg = new Message("gome_crp_order_topic_uat",// topic
                    "gome_crp_order_topic",// tag
                    System.currentTimeMillis()+"",// key
                    SerializeUtil.serialize(orderDto.toString()));// body
            SendResult sendResult = producer.send(msg);
            System.out.println(sendResult.getMsgId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        producer.shutdown();
    }
}