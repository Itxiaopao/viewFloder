package com.gome.crp.calc.client.receiver;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.Receiver;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ReceiverServiceImplTest {
    @Autowired
    private ILarkService iLarkService;
    @Autowired
    private ITelTradingService iTelTradingService;

    /**
     * IM查询承接人测试
     */
    @Test
    public void testLarkService() {
        OrderCalcDto OrderCalcDto = new OrderCalcDto();
        OrderCalcDto.setShopNo("A007");
        OrderCalcDto.setUserId("100019386371");
        OrderCalcDto.setSkuNo("109968097");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date parse = dateFormat.parse("2020-06-23 00:00:00");
            OrderCalcDto.setPayDate(parse);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<Receiver> resDto = iLarkService.queryReceiverList(OrderCalcDto);
        for (Receiver receiver : resDto) {
            System.out.println(receiver.getStaffId() + ":" + receiver.getReceiverTime());
        }
    }

    /**
     * 外呼查询承接人测试
     */
    @Test
    public void testTelTradingService() {
        OrderCalcDto OrderCalcDto = new OrderCalcDto();
        OrderCalcDto.setShopNo("A007");
        OrderCalcDto.setUserId("100038055221");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date parse = dateFormat.parse("2020-06-15 15:42:45");
            OrderCalcDto.setPayDate(parse);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        List<Receiver> resDto = iTelTradingService.queryReceiverList(OrderCalcDto);
        for (Receiver receiver : resDto) {
            System.out.println(receiver.getStaffId() + ":" + receiver.getReceiverTime());
        }
    }


}
