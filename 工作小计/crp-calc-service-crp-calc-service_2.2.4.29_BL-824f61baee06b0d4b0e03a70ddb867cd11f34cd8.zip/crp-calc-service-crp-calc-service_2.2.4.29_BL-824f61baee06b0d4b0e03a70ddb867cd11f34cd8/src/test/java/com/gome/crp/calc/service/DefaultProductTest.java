package com.gome.crp.calc.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.exception.MQBrokerException;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.remoting.exception.RemotingException;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gome.crp.calc.dto.contractDto.CalcContractDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.facade.dubbo.IDubboUpdateFacade;
import com.gome.crp.calc.facade.dubbo.task.IDubboBudgetJobFacade;
import com.gome.crp.calc.facade.dubbo.task.IDubboCalcOrderResultFacade;
import com.gome.crp.calc.facade.dubbo.task.IDubboDealSceneYFacade;
import com.gome.crp.calc.manager.CalcResultManager;
import com.gome.crp.calc.manager.CalcResultSingleManager;
import com.gome.crp.calc.manager.CalcSceneYRecordManager;
import com.gome.crp.calc.manager.contract.CalcContractManager;
import com.gome.crp.calc.manager.employee.EmployeeAttendanceSynManager;
import com.gome.crp.calc.service.job.IJob15PercentService;
import com.gome.crp.calc.service.job.IJobAwardService;
import com.gome.crp.calc.service.job.IJobDealSceneYService;
import com.gome.crp.calc.service.job.impl.JobAwardServiceImpl;
import com.gome.crp.calc.service.job.impl.JobSapCompareCompatibleService;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.calc.service.oms.impl.OMSOrderServiceImpl;
import com.gome.crp.calc.service.plan.impl.PlanServiceImpl;
import com.gome.crp.calc.service.scene.impl.SceneYServiceImpl;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.common.vo.PlanDetialForCal;
import com.gome.crp.calc.mybatis.mapper.EmployeeAttendanceMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.EmployeeAttendance;
import com.gome.crp.order.calc.dto.OrderDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopRebateDto;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;

import java.math.BigDecimal;
import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DefaultProductTest {
    private static final Logger logger = LoggerFactory.getLogger(DefaultProductTest.class);

    /**
     * 使用RocketMq的生产者
     */
    @Autowired
    private DefaultMQProducer defaultMQProducer;
    /**
     * 使用自己封装的生产者
     */
//    @Autowired
//    private MQProducerSendMsgProcessor mqProducerSendMsgProcessor;

    /**
     * 发送消息
     *
     * @throws InterruptedException
     * @throws MQBrokerException
     * @throws RemotingException
     * @throws MQClientException
     */
    @Test
    public void testSend() throws Exception {
        String msg = "demo msg test";
        logger.info("开始发送消息：" + msg);
//        Message sendMsg = new Message(TopicEnum.ORDER_TOPIC.getCode(), "", msg.getBytes());
//        //默认3秒超时
//        SendResult sendResult = defaultMQProducer.send(sendMsg);
//        logger.info("消息发送响应信息：" + sendResult.toString());
    }

    /**
     * 使用自己封装的生产者发送消息
     */
    @Test
    public void testSendByMyProduct() {
        String msg = "demo msg test";
        logger.info("开始发送消息：" + msg);
//        MQSendResult mqSendResult = mqProducerSendMsgProcessor.send(TopicEnum.ORDER_TOPIC.getCode(), "", msg);
//        logger.info("消息发送响应信息：" + mqSendResult.toString());
    }

    @Autowired
    GcacheUtil gcacheUtil;
    @Autowired
    Gcache gcache;
    @Autowired
    EmployeeAttendanceMapper employeeAttendanceMapper;
    @Autowired
    EmployeeAttendanceSynManager employeeAttendanceSynManager;
    @Test
    public void testGcache() {
        HashMap<String, Object> stringListHashMap = new HashMap<>();
        ArrayList<String> stringArraytList = new ArrayList<String>();
        stringArraytList.add("0001");//
        stringArraytList.add("0002");//
        stringArraytList.add("0003");
        stringArraytList.add("0004");
        stringListHashMap.put("staff_code", stringArraytList);
        List<EmployeeAttendance> employeeAttendances = employeeAttendanceSynManager.queryEmployeeAttendanceByStaffCode(stringArraytList, "201903");
        System.out.println(employeeAttendances.size());
        QueryWrapper<EmployeeAttendance> objectQueryWrapper = new QueryWrapper<>();
        QueryWrapper<EmployeeAttendance> staff_code = objectQueryWrapper.in("staff_code", stringArraytList).ge("hasday", 15).eq("work_month", "201903");
        List<EmployeeAttendance> employeeAttendances1 = employeeAttendanceMapper.selectList(staff_code);
        System.out.println(employeeAttendances1.size());

    }
    @Autowired
    CalcResultManager calcResultDetailManager;
    @Test
    public void testEmployee() {
        List<CalcResult> calcResultDetails = calcResultDetailManager.queryListOfFreeze();
        System.out.println(calcResultDetails.size());
        ArrayList<CalcResult> arrayList = new ArrayList<>();
        for (int i = 0 ; i < calcResultDetails.size() ; i++) {
            CalcResult thisC = calcResultDetails.get(i);
            System.out.println(thisC);

            thisC.setJobStatus(i);
            System.out.println(thisC);
            arrayList.add(thisC);
        }
        Boolean aBoolean = calcResultDetailManager.updateByList(arrayList);
        //
        System.out.println(aBoolean);
    }
    @Autowired
    IDubboCalcOrderResultFacade dubboCalcOrderResultFacade;
    @Autowired
    PlanServiceImpl planServiceImpl;
    @Autowired
    CalcResultManager calcResultManager;

    @Autowired
    IJob15PercentService iJob15PercentService;
    @Test
    public void testCalendar(){
       /* OrderCalcDto orderCalcDto = new OrderCalcDto();
        orderCalcDto.setSkuNo("TE00002");
        orderCalcDto.setSalesModel("05");
        orderCalcDto.setSubmittedDate(new Date());
        orderCalcDto.setShopNo("1001");
        orderCalcDto.setSupplier("testSupplierCode");
        orderCalcDto.setChannelCalcNo("1");
        orderCalcDto.setSalesOrganization("1002");
        List<PlanDto> planDtos = planServiceImpl.orderMatchPlan(orderCalcDto);
        System.out.println(planDtos.size());*/

        iJob15PercentService.deal15Percent();
    }
    @Test
    public void testPlan(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(70L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setContractType("1");
        planDetialForCal.setCurrentPrice(100L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(44L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        ArrayList<String> strings = new ArrayList<>();
        strings.add("A001");
        strings.add("A002");
        strings.add("A003");
        strings.add("A004");
        stringListHashMap.put("1002",strings);
        stringListHashMap.put("1002",null);
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(5);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
//        planDetialForCal.setStepRate(5);
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00002:05", "44", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
//    public void skuCache(String key ,String field, PlanDetialForCal cal){
//        log.info("CacheService-calCache start");
//        gcache.hset(key, field, JSON.toJSONString(cal));
//        gcache.sadd("calcSet", key);
//    }

    @Autowired
    SceneYServiceImpl sceneYService;
    @Autowired
    CalcSceneYRecordManager calcSceneYRecordManager;
    @Autowired
    IDubboDealSceneYFacade iDubboDealSceneYFacade;
    @Test
    public void testDecr(){
//        for(int i = 0 ; i < 3 ; i++){
//            sceneYService.saveOrUpdateSceneY(i+"",i+"",i+"");
//        }
//
//        for(int i = 0 ; i < 3 ; i++){
//            sceneYService.saveOrUpdateSceneY(i+"",i+"",i+"");
//        }

//        sceneYService.jobDealSceneY();
//        List<BigDecimal> perAwardPrice = sceneYService.getPerAwardPrice(100L, 3);
        iDubboDealSceneYFacade.executeJob();
    }
    @Autowired
    private IJobAwardService iJobAwardService;

    @Autowired
    private SeqGenUtil seqGenUtil;

    @Autowired
    private PlanServiceImpl planService;
    @Test
    public void testGcache1(){
//        PlanDto planDto = new PlanDto();
//        planDto.setPromotionsType(5);
//        planDto.setExpenseOfferType(2);
//        OrderCalcDto orderCalcDto = new OrderCalcDto();
//        orderCalcDto.setSupplier("supplier");
//
//        Boolean flag = BaseConstants.PLAN_EXPENSE_OFFER_TWO_TYPE.equals(planDto.getExpenseOfferType());//是国美预算
//        Boolean falgInvate = BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(planDto.getPromotionsType().toString());//是拓客
//        if(!(flag || falgInvate)){ //不是拓客并且不是国美预算
//            System.out.println("进行供应商编码校验");
//        }else {
//            System.out.println("不校验供应商编码");
//        }
        long l = System.currentTimeMillis();
        Date date1 = new Date(l);
        Date date2 = new Date(l);
        int i = date1.compareTo(date2);
        System.out.println(i);
        int i1 = date2.compareTo(date1);
        System.out.println(i1);
        Comparator<PlanDto> comparator = new Comparator<PlanDto>() {
            @Override
            public int compare(PlanDto o1, PlanDto o2) {
                Date startTime1 = null;
                Date startTime2 = null;

                //无函 或者  没有签约类型
                startTime1 = o1.getStartTime();
                startTime2 = o2.getStartTime();

                if (startTime1.compareTo(startTime2) == 1) {
                    return -1;
                } else {
                    if(startTime1.compareTo(startTime2) != 0){
                        return 1;
                    }else {
                        return o1.getPlanId() > o2.getPlanId() ? -1 : 1;
                    }
                }
            }
        };
        PlanDto planDto1 = new PlanDto();
        planDto1.setPlanId(1L);
        planDto1.setStartTime(date1);
        PlanDto planDto2 = new PlanDto();
        planDto2.setPlanId(2L);
        planDto2.setStartTime(date2);
        ArrayList<PlanDto> objects = new ArrayList<>();
        objects.add(planDto1);
        objects.add(planDto2);
        Collections.sort(objects,comparator);
        System.out.println(objects.get(0).getPlanId());
        System.out.println(objects.get(1).getPlanId());
    }

    @Autowired
    private IUserShareBindingManager iUserShareBindingManager;
    @Test
    public void testQuery(){
        MshopRebateDto mshopRebateDto = new MshopRebateDto();
        mshopRebateDto.setUserId(12366666L);
        MapResults<MshopRebateDto> mshopRebateDtoMapResults = iUserShareBindingManager.queryMshopRebateDtoByUserIdOrMid(mshopRebateDto);
        System.out.println(mshopRebateDtoMapResults.getBuessObj().getUpUserId());
    }
    @Autowired
    private IOMSOrderService iOMSOrderService;
    @Test
    public void testQueryShareUser() {
        String str = "{\"deliveryList\":[{\"channelNo\":\"60\",\"gomeState\":\"CO\",\"goodsList\":[{\"categoryFirstId\":\"cat10000004\",\"categoryFourthId\":\"\",\"categorySecondId\":\"cat10000008\",\"categoryThirdId\":\"cat10000054\",\"commerceItemId\":\"54527630\",\"companyCode\":\"\",\"description\":\"一店一页-手机屏碎保一年\",\"detailList\":[{\"buyNum\":1,\"detailId\":\"1149642876\",\"price\":7,\"sapDetailId\":\"25705259031149642876\"}],\"eaBrandCode\":\"03837\",\"eaGroupCode\":\"R4602001\",\"goodsType\":\"1\",\"salePrice\":7,\"salesOrganization\":\"1001\",\"skuId\":\"1000225588\",\"skuName\":\"一店一页-手机屏碎保一年\",\"skuNo\":\"540051701\"}],\"orderDate\":1595919845453,\"shippingGroupId\":\"2570525903\",\"shopNo\":\"G001\",\"shopType\":\"fshop\"}],\"loginName\":\"gm_13321171572iyg\",\"orderId\":\"19017902289\",\"orderPrice\":17,\"orderSalePrice\":17,\"orderType\":\"0\",\"payDate\":1595919841367,\"profileId\":\"100051577501\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.0\",\"plt\":\"wap\"},\"submittedDate\":1595919577098}";
        OrderDto orderDto = JSON.parseObject(str, OrderDto.class);
        iOMSOrderService.handler(orderDto);
    }
    @Autowired
    private IJobDealSceneYService iJobDealSceneYService;
    @Autowired
    private JobAwardServiceImpl jobAwardService;
    @Test
    public void test009(){
        jobAwardService.dealFreezeStatus();
    }
    @Autowired
    CalcResultSingleManager calcResultSingleManager;
    @Test
    public void test010(){
        CalcResult calcResult = new CalcResult();
        calcResult.setId(130000L);
        calcResult.setGomeStatus("CO");
        calcResult.setJobStatus(-2);
        calcResultSingleManager.updateByParam(calcResult);
    }
    @Test
    public void test011(){
        System.out.println(123);
        RuntimeException runtimeException = new RuntimeException();
        StackTraceElement[] stackTrace = runtimeException.getStackTrace();
        System.out.println(312);
    }
    @Autowired
    IDubboUpdateFacade iDubboUpdateFacade;
    @Autowired
    VshopFacade vshopFacade;
    @Autowired
    IDubboBudgetJobFacade iDubboBudgetJobFacade;
    @Autowired
    JobSapCompareCompatibleService jobSapCompareCompatibleService;
    @Autowired
    OMSOrderServiceImpl omsOrderService;
    @Autowired
    CalcContractManager calcContractManager;
    @Test
    public void testPlan123(){
        /*String messageBody = "{\"deliveryList\":[{\"channelNo\":\"60\",\"gomeState\":\"CO\",\"goodsList\":[{\"categoryFirstId\":\"cat10000004\",\"categoryFourthId\":\"\",\"categorySecondId\":\"cat10000010\",\"categoryThirdId\":\"cat10000062\",\"commerceItemId\":\"54669130\",\"companyCode\":\"\",\"description\":\"一店一页-家用空调-格力-后端\",\"detailList\":[{\"buyNum\":1,\"detailId\":\"1149637572\",\"logicMasLoc\":\"BY0J0071\",\"price\":200,\"salesModel\":\"01\",\"sapDetailId\":\"25705074541149637572\",\"supplier\":\"0020001078\"}],\"eaBrandCode\":\"00005\",\"eaGroupCode\":\"R1101001\",\"goodsType\":\"1\",\"salePrice\":200,\"salesOrganization\":\"1001\",\"skuId\":\"1000225772\",\"skuName\":\"一店一页-家用空调-格力-后端\",\"skuNo\":\"109968060\"}],\"orderDate\":1595403494269,\"shippingGroupId\":\"2570507454\",\"shopNo\":\"G001\",\"shopType\":\"fshop\"}],\"loginName\":\"zxgtest\",\"orderId\":\"19017818869\",\"orderPrice\":200,\"orderSalePrice\":200,\"orderType\":\"0\",\"payDate\":1595403489953,\"profileId\":\"108140030\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.0\",\"plt\":\"pc\"},\"submittedDate\":1595403478933}";
        OrderDto orderCalcDtoLock = JSONObject.parseObject(messageBody,OrderDto.class);
        List<OrderCalcDto> orderCalcDtos = omsOrderService.transferOrderCalcDto(orderCalcDtoLock);
        System.out.println(123);*/
        CalcContractDto contractDtoBySapDetailId = calcContractManager.getContractDtoBySapDetailId("25705382981149644811");
        System.out.println(contractDtoBySapDetailId);
    }

}
