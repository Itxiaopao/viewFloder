package com.gome.crp.calc.service.order.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gome.crp.calc.service.retry.impl.CalcRetryCopeServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcRetryMapper;
import com.gome.crp.calc.mybatis.model.CalcRetry;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CalcOrderRetryServiceTest {

	
	@Autowired
	private CalcRetryCopeServiceImpl calcRetryCopeServiceImpl;
	@Autowired
	private CalcRetryMapper calcRetryMapper;



    @Test
    public void fn2() {
        calcRetryCopeServiceImpl.scan();
    }


	@Test
	public void fn1() {
		
		CalcRetry selectById = calcRetryMapper.selectById(2825L);
//
//
//        // 推送 重试
//        boolean ret = calcRetryCopeServiceImpl.retryTheCopeFn(selectById);
//        if (!ret) {
//            selectById.setRepeatTime(selectById.getRepeatTime() + 1);	// 重试失败 次数+1
//        } else {
//            selectById.setIsDelete(IsDeleteEnum.YES.getCode());	// 重试成功 将数据至为 已删除
//            selectById.setIsSuc(IsSuccessEnum.YES.getCode());	// 成功标示
//        }
//        selectById.setUpdateTime(new Date());
//
//        int updateById = calcRetryMapper.updateById(selectById);
//        System.out.println(updateById);
		
	}
}
