package com.gome.crp.calc.mq.producer;

import com.gome.crp.calc.dto.bigDataDto.CalcResultDetailDto;
import com.gome.crp.calc.dto.bigDataDto.CalcResultDto;
import com.gome.crp.calc.util.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SendBigDataProducerProcessImplTest {

    @Autowired
    SendBigDataProducerProcessImpl sendBigDataProducerProcess;

    @Test
    public void sendBigData() {
        // CalcResultDto(order_id=12398352102, delivery_order_id=2924383183, sku_no=100517734, commerce_item_id=6086648419, detail_id=1479270320,
        // sap_detail_id=29243831831479270320, return_order_id=null, sales_model=01, sales_channel=16, jobStatus=2, gomeStatus=CL,
        // submittedDate=2020-04-21 19:37:13, datas=[CalcResultDetailDto(plan_id=1874, vitae_id=14001, profit_type=SCENE-X, profit_amount=13699,
        // employee_id=00001530, member_id=72116339515, update_time=2020-04-21 20:34:44)])
        CalcResultDto calcResultDto = new CalcResultDto();
        calcResultDto.setOrder_id("12398352102");
        calcResultDto.setDelivery_order_id("2924383183");
        calcResultDto.setSku_no("100517734");
        calcResultDto.setCommerce_item_id("6086648419");
        calcResultDto.setDetail_id("1479270320");
        calcResultDto.setSap_detail_id("29243831831479270320");
        calcResultDto.setSales_model("01");
        calcResultDto.setSales_channel("16");
        calcResultDto.setJobStatus(2);
        calcResultDto.setGomeStatus("CL");
        calcResultDto.setSubmittedDate("2020-04-21 19:37:13");
        calcResultDto.setReturn_order_id(null);

        CalcResultDetailDto calcResultDetailDto = new CalcResultDetailDto();
        calcResultDetailDto.setPlan_id("1874");
        calcResultDetailDto.setVitae_id("14001");
        calcResultDetailDto.setProfit_type("SCENE-X");
        calcResultDetailDto.setProfit_amount("-13699");
        calcResultDetailDto.setEmployee_id("00001530");
        calcResultDetailDto.setMember_id("72116339515");
        calcResultDetailDto.setUpdate_time("2020-04-21 20:34:44");

        List<CalcResultDetailDto> calcResultDetailDtos = new ArrayList<>();
        calcResultDetailDtos.add(calcResultDetailDto);
        calcResultDto.setDatas(calcResultDetailDtos);

        sendBigDataProducerProcess.sendBigData(calcResultDto);
    }
}