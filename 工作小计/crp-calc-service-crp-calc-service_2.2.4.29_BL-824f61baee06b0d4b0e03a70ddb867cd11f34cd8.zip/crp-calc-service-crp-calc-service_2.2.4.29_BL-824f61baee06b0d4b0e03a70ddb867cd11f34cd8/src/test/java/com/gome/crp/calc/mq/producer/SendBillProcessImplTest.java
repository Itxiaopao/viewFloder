package com.gome.crp.calc.mq.producer;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.billDto.EnrollBillMQDto;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class SendBillProcessImplTest {

    @Autowired
    SendEnrollBillProcessImpl sendEnrollBillProcess;
    @Autowired
    private CalcResultMapper calcResultMapper;

    @Test
    public void sendBigData() {

        List<CalcResult> calcResults = get("19017856540");

//        sendEnrollBillProcess.sendPreBills(calcResults, BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_1);
    }

    private CalcResult get(long tableId){
        CalcResult calcResult = calcResultMapper.selectById(tableId);
        calcResult.setUserId("100054835403");
        calcResult.setOrderSubmitTime(new Date());
        return calcResult;
    }

    private CalcResult get(){
        String json = "{\"accountType\":1,\"amount\":15,\"childGomeId\":\"100051352301\",\"createTime\":1591079176047,\"itemSource\":2,\"key\":\"237655\",\"level\":1,\"merchantId\":\"888\",\"orderCreateTime\":1591079176047,\"orderId\":\"19017851877\",\"rebateTime\":1591079176047,\"rebateType\":44,\"skuId\":\"1000225781\",\"skuName\":\"一店一页测试国美CCFL-LCD彩电大件用途前端007\",\"skuNo\":\"109968069\",\"status\":1,\"userId\":\"100054835403\"}";
        CalcResult c = JSONObject.parseObject(json, CalcResult.class);
        c.setId(237655001L);
        c.setGomeStatus("RCO");
        c.setAwardAmount(10L);
        c.setUserId("100054835403");
        return c;
    }

    // orderId
    private List<CalcResult> get(String orderId){
        CalcResult que = new CalcResult();
        que.setOrderId(orderId);
        List<CalcResult> calcResults = calcResultMapper.selectList(Wrappers.query(que));
        if(CollectionUtils.isEmpty(calcResults)){
            return null;
        }

        List<CalcResult> collect1 = calcResults.stream().map(x -> {
            CalcResult a = null;
            if(!x.getScenes().equals(BaseConstants.SCENE_X)){
                a = x;
            }
            return a;
        }).collect(Collectors.toList());
        log.info("数据打印: {}", JSONObject.toJSONString(collect1));
        return collect1;
    }

    private EnrollBillMQDto getBill(){
//        String b = "{\"accountType\":1,\"amount\":15,\"childGomeId\":\"100051352301\",\"createTime\":1591079176047,\"itemSource\":2,\"key\":\"237655\",\"level\":1,\"merchantId\":\"888\",\"orderCreateTime\":1591079176047,\"orderId\":\"19017851877\",\"rebateTime\":1591079176047,\"rebateType\":44,\"skuId\":\"1000225781\",\"skuName\":\"一店一页测试国美CCFL-LCD彩电大件用途前端007\",\"skuNo\":\"109968069\",\"status\":1,\"userId\":\"100054835403\"}";
//        EnrollBillMQDto bs = JSONObject.parseObject(b, EnrollBillMQDto.class);
//        bs.setKey("237655001L");
//        bs.setStatus();
        return null;
    }


}