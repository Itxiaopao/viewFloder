package com.gome.crp.calc.client.message;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SendMessageTest {

	@Autowired
	private ISendMessage sendMessage;
	
	@Test
	public void test1(){
		List<String> userList = new ArrayList<>();
		userList.add("zhangshuang29@gome.com.cn");
		SendMessageDto dto = new SendMessageDto(1, "11111", "test");
		dto.setTopic("测试邮件");
		dto.setUserList(userList);
		boolean sendSyncMsg = sendMessage.sendSyncMsg(dto);
		System.err.println(sendSyncMsg);
	}
	
	@Test
	public void test2(){
		SendMessageDto dto = new SendMessageDto(2, "11111", "test");
		dto.setContent("没有跳转连接");
		boolean sendSyncMsg = sendMessage.sendSyncMsg(dto);
		System.err.println(sendSyncMsg);
	}
}
