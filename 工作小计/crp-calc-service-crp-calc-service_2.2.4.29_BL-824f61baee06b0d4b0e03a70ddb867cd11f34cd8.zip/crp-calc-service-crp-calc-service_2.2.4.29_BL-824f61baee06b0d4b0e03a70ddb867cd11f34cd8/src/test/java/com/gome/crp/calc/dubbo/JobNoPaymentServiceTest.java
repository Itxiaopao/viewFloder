package com.gome.crp.calc.dubbo;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.Date;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.gome.common.util.DateFormatUtils;
import com.gome.crp.calc.service.job.impl.JobSapNoPaymentServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JobNoPaymentServiceTest {

	@Autowired
	private JobSapNoPaymentServiceImpl jobSapNoPaymentServiceImpl;

	@Test
	public void defualtCouponDto1() {
		Date date = new Date();
		jobSapNoPaymentServiceImpl.fetchList(1, 200, date);
	}

	@Test
	public void defualtCouponDto2() {
		jobSapNoPaymentServiceImpl.changeJobStatus();
	}
	
	public static void main(String[] args) {
		LocalDate dateTime = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
		Instant instant = dateTime.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
		Date date = Date.from(instant);
		System.out.println(DateFormatUtils.format(date));
        System.out.println("firstday:"+date);

	}
	
}