package com.gome.crp.calc.service.order.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.receiver.impl.LarkServiceImpl;
import com.gome.crp.calc.client.sap.impl.QueryPlanServiceImpl;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.lark.model.entity.AgentServiceForSkuNo;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderCOServiceImplTest {
    @Autowired
    private QueryPlanServiceImpl queryPlanServiceImpl;
    @Autowired
    private OrderCOServiceImpl orderCOServiceImpl;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private LarkServiceImpl larkServiceImpl;


    @Test
    public void redoCalc() {
        ArrayList<Integer> ids = new ArrayList<>();
        ids.add(173649);

        CalcResult calcResult = calcResultMapper.selectById(173649);


        List<CalcResult> calcResults = calcResultMapper.selectBatchIds(ids);

        OrderCalcDto coOrderCalcDto = JSON.parseObject(calcResults.get(0).getCoMsgBody(), OrderCalcDto.class);
        orderCOServiceImpl.redoCalc(coOrderCalcDto, calcResults);

/*        ContractPolicyVO contractPolicy = queryPlanServiceImpl.getContractPolicy("W0062020C00100038", "R0501001");
        System.out.println(contractPolicy);*/
    }
    
    
    @Test
    public void test1() {
    	
    	OrderCalcDto orderCalcDto = new OrderCalcDto();
    	orderCalcDto.setSkuNo("1002537191");
    	AgentServiceForSkuNo agentServiceForSkuNo = new AgentServiceForSkuNo();
    	agentServiceForSkuNo.setSkuNoList("1002535351,1002537191,1002530671");
    	larkServiceImpl.matchSpuId(orderCalcDto,agentServiceForSkuNo);
    	//larkServiceImpl.queryorderDtoSpid(orderCalcDto);
	}
}
