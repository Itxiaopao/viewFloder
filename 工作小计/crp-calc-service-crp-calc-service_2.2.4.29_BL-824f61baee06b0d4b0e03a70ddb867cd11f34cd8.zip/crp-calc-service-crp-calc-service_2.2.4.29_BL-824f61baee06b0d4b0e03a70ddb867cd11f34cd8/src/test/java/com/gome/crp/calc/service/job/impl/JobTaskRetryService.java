package com.gome.crp.calc.service.job.impl;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.IsDeleteEnum;
import com.gome.crp.calc.constants.IsSuccessEnum;
import com.gome.crp.calc.facade.dubbo.task.IDubboCalcRetryFacade;
import com.gome.crp.calc.mybatis.mapper.CalcRetryMapper;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.mybatis.service.ICalcRetryService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JobTaskRetryService {
	
	@Autowired
	private IDubboCalcRetryFacade dubboCalcRetryFacade;
	@Autowired
	private CalcRetryMapper calcRetryMapper;
	@Autowired
	private ICalcRetryService calcRetryService;
	
	
	@Test
	public void fn1(){
		dubboCalcRetryFacade.scan();
	}
	
	@Test
	public void fn2() {
		CalcRetry cr = new CalcRetry();
        cr.setIsDelete(IsDeleteEnum.NO.getCode());
        cr.setIsSuc(IsSuccessEnum.NO.getCode());
        QueryWrapper<CalcRetry> query = Wrappers.query(cr);
        int i = 1;
        int pageNum = 100;
        IPage<CalcRetry> page = new Page<>();
//        page.setPages(pageNum);
        page.setSize(pageNum);
        page.setCurrent(i);
		IPage<CalcRetry> selectPage = calcRetryMapper.selectPage(page, query);
        List<CalcRetry> pageResults = selectPage.getRecords();
        pageResults.forEach(x -> {
        	x.setIsSuc(IsSuccessEnum.YES.getCode());
        	x.setIsDelete(IsDeleteEnum.YES.getCode());
        });
//        boolean saveOrUpdateBatch = calcRetryService.saveOrUpdateBatch(pageResults);
        boolean saveOrUpdateBatch = calcRetryService.saveOrUpdateBatch(pageResults, 2);
        System.out.println(saveOrUpdateBatch);
        
        
        
	}

}
