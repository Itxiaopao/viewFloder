package com.gome.crp.calc.service.bill;

import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class IBillServiceTest {
    @Autowired
    private IBillService iBillService;
    @Autowired
    private CalcResultMapper calcResultMapper;

    @Test
    public void applyPay() {
        CalcResult calcResult = calcResultMapper.selectById(20808);
        CalcResult calcResult1 = calcResultMapper.selectById(20804);
        CalcResult calcResult2 = calcResultMapper.selectById(20769);
        List<CalcResult> calcResultList = new ArrayList<>();
        calcResultList.add(calcResult);
        calcResultList.add(calcResult1);
        calcResultList.add(calcResult2);
        iBillService.applyPay(calcResultList);



/*        List<CalcResult> calcResultList = new ArrayList<>();
        CalcResult calcResult = new CalcResult();
        calcResult.setId(223457L);
        calcResult.setScenes("SCENE-Y");
        calcResult.setGomeStatus("DL");
        calcResult.setAwardAmount(10000L);
        calcResult.setDeliveryId("111");
        calcResult.setExpencesOfferType(1);
        calcResult.setDetailId("123456");
        calcResult.setSkuNo("aaaaa");
        calcResult.setSkuName("aaaaa名字");
        calcResult.setBuyNum(10);
        calcResult.setOrderEffectTime(new Date());
        calcResult.setCompanyCode("3");
        calcResult.setShopNo("2");
        calcResult.setUserId("555xxxx");
        calcResult.setPlanId("123");
        calcResult.setIsGomeOffer(0);
        calcResult.setIsAsella(0);
        calcResultList.add(calcResult);*/
    }
}
