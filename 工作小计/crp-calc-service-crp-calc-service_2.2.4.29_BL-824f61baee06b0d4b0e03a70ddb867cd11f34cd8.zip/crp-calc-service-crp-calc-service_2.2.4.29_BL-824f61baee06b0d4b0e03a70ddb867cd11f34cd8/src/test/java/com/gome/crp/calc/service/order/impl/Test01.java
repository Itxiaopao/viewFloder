package com.gome.crp.calc.service.order.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Test01 {


    public static void main(String[] args) {
        String ret = "2020-06-08 00:00:00";
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse(ret, dateTimeFormatter);
        Date d = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
        System.out.println(System.currentTimeMillis());
        System.out.println(d.getTime());
        boolean rets = true;
        if(System.currentTimeMillis() > d.getTime()){
            rets = false;
        }
        System.out.println(rets);
    }
}
