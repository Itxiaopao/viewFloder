package com.gome.crp.calc.client.erm;

import com.gome.crp.calc.dto.ermDto.ClosePlanReqDto;
import com.gome.crp.calc.dto.ermDto.LetterReqDto;
import com.gome.crp.calc.dto.ermDto.LetterResDto;
import com.gome.crp.calc.dto.ermDto.ReleaseBudgetReqDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IErmServiceTest {
    @Autowired
    private IErmService iErmService;

    @Test
    public void closePlan() {
        ClosePlanReqDto closePlanReqDto = new ClosePlanReqDto();
        closePlanReqDto.setPlanId("669");
        iErmService.closePlan(closePlanReqDto);
    }

    @Test
    public void releaseBudget() {
        ReleaseBudgetReqDto reqDto = new ReleaseBudgetReqDto();
        reqDto.setPlanId("139");
        reqDto.setMessageId("1234567");
        reqDto.setAmount(new BigDecimal("100"));
        iErmService.releaseBudget(reqDto);
    }

    @Test
    public void occupyBudget() {
    }

    @Test
    public void queryNewContractCode() {
        String newContractCode1 = iErmService.queryNewContractCode("10012019C00100012");
        String newContractCode2 = iErmService.queryNewContractCode("10012019C00100019");
        String newContractCode3 = iErmService.queryNewContractCode("10012020C00100005");
        String newContractCode4 = iErmService.queryNewContractCode("15012019C00100008");
        String newContractCode5 = iErmService.queryNewContractCode(null);
        System.out.println(newContractCode1);
        System.out.println(newContractCode2);
        System.out.println(newContractCode3);
        System.out.println(newContractCode4);
        System.out.println(newContractCode5 == null);
    }

    @Test
    public void queryLetter() {
        LetterReqDto letterReqDto = new LetterReqDto();
        letterReqDto.setContractCode("10012020C00300002");
        letterReqDto.setExtraPurchaseCode("1001");
        letterReqDto.setOrderSupplierCode("0020001078");
        letterReqDto.setDocty("ZC09");
        letterReqDto.setSkuNo("109968108");
        letterReqDto.setSalesModel("01");
        List<LetterResDto> letterResDtos = iErmService.queryLetter(letterReqDto);
        System.out.println(letterResDtos);
    }
}
