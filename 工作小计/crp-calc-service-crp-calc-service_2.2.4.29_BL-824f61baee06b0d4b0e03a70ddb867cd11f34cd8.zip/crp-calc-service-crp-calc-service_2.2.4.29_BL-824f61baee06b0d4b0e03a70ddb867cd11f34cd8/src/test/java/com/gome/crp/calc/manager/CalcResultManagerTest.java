package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.model.CalcResult;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;


@RunWith(SpringRunner.class)
@SpringBootTest
public class CalcResultManagerTest {
    @Autowired
    private CalcResultManager calcResultManager;

    @Test
    public void testDoSaveCalcResult() {
        List<CalcResult> calcResults = calcResultManager.queryListOfFreeze();
        System.out.println(calcResults);
    }

    @Test
    public void testQueryListByOrderIdAndDetailId() {
        calcResultManager.queryListByOrderIdAndDetailId("1", "1");
    }

    @Test
    public void queryListOfSendOfflineSAP() {

    }
}
