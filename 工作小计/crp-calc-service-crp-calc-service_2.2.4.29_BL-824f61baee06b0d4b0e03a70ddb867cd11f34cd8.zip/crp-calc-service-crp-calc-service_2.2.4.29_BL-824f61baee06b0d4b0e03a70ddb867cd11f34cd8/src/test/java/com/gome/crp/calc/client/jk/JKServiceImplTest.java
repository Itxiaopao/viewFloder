package com.gome.crp.calc.client.jk;

import com.gome.crp.calc.dto.jkDto.QueryShareUserReqDto;
import com.gome.crp.calc.dto.jkDto.QueryShareUserResDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@RunWith(SpringRunner.class)
@SpringBootTest
public class JKServiceImplTest {
    @Autowired
    private IJKService iJKService;

    @Test
    public void testQueryShareUser() {
        QueryShareUserReqDto reqDto = new QueryShareUserReqDto();
        reqDto.setActivityId("9405");
        reqDto.setUserId("100048777602");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            Date parse = dateFormat.parse("2020-02-18 12:05:30");
            reqDto.setOrderDate(parse);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        QueryShareUserResDto resDto = iJKService.queryShareUser(reqDto);
        assert resDto != null && resDto.getStaffCode() != null;
    }
}
