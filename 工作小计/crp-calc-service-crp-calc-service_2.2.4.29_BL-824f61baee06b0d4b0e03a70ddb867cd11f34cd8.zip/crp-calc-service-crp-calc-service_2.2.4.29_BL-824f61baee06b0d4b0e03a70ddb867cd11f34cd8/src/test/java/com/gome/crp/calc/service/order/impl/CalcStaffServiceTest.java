package com.gome.crp.calc.service.order.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.impl.GomeEmployeeInfoService;
import com.gome.crp.calc.client.employee.impl.StaffInfoService;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class CalcStaffServiceTest {

	@Autowired
	private GomeEmployeeInfoService gomeEmployeeInfoService;
	@Autowired
	private StaffInfoService staffInfoService;




	@Test
	public void fn_1(){
//		{"brandId":"00005","categoryId":"R03","currentPage":0,"pageSize":0,"shop":"A007","staffLevel":"4"}4
		List<String> empll = new ArrayList<>();
		empll.add("10204162");
		String orderId = "";
		String cateId = "";
		String brandId = "";
		String shop = "A007";
		List<EmployeeInfoDto> employeeInfoDtos = gomeEmployeeInfoService.queryGomeEmployeeInfos(orderId, cateId, brandId, empll, shop);

		log.info("json- {}", JSONObject.toJSONString(employeeInfoDtos));

	}

	@Test
	public void fn_2(){
		List<String> empll = new ArrayList<>();
		empll.add("10204162");
		String orderId = "";
		String cateId = "";
		String brandId = "";
		String shop = "A007";
		List<EmployeeInfoDto> employeeInfoDtos = staffInfoService.queryGomeEmployeeInformation(cateId, brandId, empll, shop, "4");
		log.info("json- {}", JSONObject.toJSONString(employeeInfoDtos));
	}
	
}
