package com.gome.crp.calc.service.job.impl;

import com.gome.crp.calc.service.job.IJobSapCompareService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class JobSapCompareServiceTest {
    @Autowired
    private IJobSapCompareService iJobSapCompareService;

    @Test
    public void scanNorm() {
        iJobSapCompareService.scanNorm();
    }

    @Test
    public void scanUnSuc() {
        iJobSapCompareService.scanUnSuc();
    }

    @Test
    public void scanNoDetect() {
        iJobSapCompareService.scanNoDetect();
    }

    @Test
    public void scanFollowUp() {
        iJobSapCompareService.scanFollowUp();
    }

}
