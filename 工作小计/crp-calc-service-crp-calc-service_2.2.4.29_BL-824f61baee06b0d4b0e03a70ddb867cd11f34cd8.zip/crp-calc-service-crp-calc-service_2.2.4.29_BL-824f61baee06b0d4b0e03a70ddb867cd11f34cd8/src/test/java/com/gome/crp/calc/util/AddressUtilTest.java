package com.gome.crp.calc.util;

import org.junit.Test;

public class AddressUtilTest {

    @Test
    public void getLocalAddress() {
        String localAddress = AddressUtil.getLocalAddress();
        System.out.println(localAddress);
    }

    @Test
    public void normalizeHostAddress() {
    }
}
