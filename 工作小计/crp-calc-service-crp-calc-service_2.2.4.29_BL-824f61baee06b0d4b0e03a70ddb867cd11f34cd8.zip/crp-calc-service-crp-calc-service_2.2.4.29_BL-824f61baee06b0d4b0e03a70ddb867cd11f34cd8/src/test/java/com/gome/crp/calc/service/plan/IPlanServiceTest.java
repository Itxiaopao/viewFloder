package com.gome.crp.calc.service.plan;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.sap.impl.QueryPlanServiceImpl;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.order.calc.dto.OrderDto;
import com.gome.scot.ocqs.api.model.ContractDetailVO;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class IPlanServiceTest {

    @Autowired
    IPlanService planService;

    @Test
    public void getPlansById() {
        String[] ids = new String[]{"1692"};
        List<PlanDto> plans = planService.getPlansById(ids);
        System.out.println(JSON.toJSON(plans));
    }

    @Test
    public void skuMatchPlan() {
        // 19015800056订单为啥没匹配到计划1692
        // id 1662  订单 19015907682  能麻烦帮看下这单子和计划为啥没匹配上吗 @莫汉蒙德·彪
        Map<String, String> map = new HashMap<>();
        map.put(BaseConstants.PROBLEM_SKU_NO, "109968087"); // skuNo
        map.put(BaseConstants.PROBLEM_SALE_MODEL, "01"); // salesModel
        map.put(BaseConstants.PROBLEM_EA_GROUP_CODE, "R0101004"); // eaGroupCode 四级品类编码
        map.put(BaseConstants.PROBLEM_EA_BRAND_CODE, "00003"); // eaBrandCode 品牌编码
        map.put(BaseConstants.PROBLEM_PLAN_ID, "1612"); // planId 1871，1791

        List<String> res = planService.skuIsMatchPlan(map);
        System.out.println(JSON.toJSON(res));

        List<PlanDto> list = new LinkedList<>();
    }
    @Autowired
    private QueryPlanServiceImpl queryPlanService;
    @Test
    public void testQueryPlan(){
        OrderCalcDto orderCalcDto = new OrderCalcDto();
        orderCalcDto.setSkuId("1000226154");
        orderCalcDto.setSkuNo("000000000109968086");
        orderCalcDto.setCategoryFourthId("R0301002");
        orderCalcDto.setEaBrandCode("00001");
        orderCalcDto.setSupplier("0020000994");
        orderCalcDto.setLogicMasLoc("WXF0X011");
        orderCalcDto.setPayDate(new Date());
        orderCalcDto.setSalesOrganization("1001");
        orderCalcDto.setSalePrice(new BigDecimal(1000));
        orderCalcDto.setSalesModel("01");
        //ContractDetailVO contractDetailVO = queryPlanService.queryContractByParam(orderCalcDto);
        OrderCalcDto orderCalcDto1 = new OrderCalcDto();
        orderCalcDto1.setCategoryFourthId("R05");
        orderCalcDto1.setEaBrandCode("00024");
        orderCalcDto1.setSkuNo("109968155");
        orderCalcDto1.setSupplier("0010012050");
        orderCalcDto1.setSalesModel("01");
        orderCalcDto1.setChannel("1");
        orderCalcDto1.setSalesOrganization("1001");
        orderCalcDto1.setShopNo("A007");
        orderCalcDto1.setPayDate(new Date(1589125324000L));
        //queryPlanService.queryPlanByParam(orderCalcDto1,contractDetailVO);
//        int i = 1;
//        switch (i){
//            case 1:
//            case 2:
//                System.out.println("1and2");

//            case 3:
//                System.out.println("3");
//        }

    }
}