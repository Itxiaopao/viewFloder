package com.gome.crp.calc.service.order.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.service.oms.impl.OMSOrderServiceImpl;
import com.gome.crp.calc.service.so.ISOOrderService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.employee.impl.ProfitStaffService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.employee.StaffBindDto;
import com.gome.crp.calc.dto.employee.StaffsIsMainDto;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.service.calc.CalcFatctory;
import com.gome.crp.calc.service.calc.impl.CalcServiceOrder;
import com.gome.crp.calc.service.job.impl.JobBudgetServiceImpl;
import com.gome.crp.calc.service.order.OrderFactory;
import com.gome.crp.calc.service.plan.impl.PlanServiceImpl;
import com.gome.crp.calc.service.scene.impl.SceneMServiceImpl;
import com.gome.crp.calc.service.scene.impl.SceneXServiceImpl;
import com.gome.crp.calc.service.scene.impl.SceneZServiceImpl;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.mapper.OrderRecordMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.OrderRecord;
import com.gome.crp.order.calc.dto.OrderDto;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class CalcOrderCalcTest {

	@Autowired
	CalcServiceOrder calcServiceOrder;
	@Autowired
	OrderRCOServiceImpl orderRCOServiceImpl;
	@Autowired
	JobBudgetServiceImpl budgetServiceImpl;
	@Autowired
	private SceneXServiceImpl sceneXServiceImpl;
	@Autowired
	private SceneMServiceImpl sceneMServiceImpl;
	@Autowired
	private SceneZServiceImpl sceneZServiceImpl;
	@Autowired
	private OrderCOServiceImpl orderCOServiceImpl;
	@Autowired
    private OrderFactory orderFactory;
	@Autowired
	private OMSOrderServiceImpl oMSOrderServiceImpl;
	@Autowired
    private CalcFatctory calcFatctory;
	@Autowired
	private PlanServiceImpl planService;
	@Autowired
	private OrderRecordMapper orderRecordMapper;
	@Autowired
	private JobBudgetServiceImpl jobBudgetServiceImpl;
	@Autowired
	private IStaffInfoService staffInfoService;
	@Autowired
	private ISOOrderService isoOrderService;

	// 获取时间
	@Value("${rel_budget_standstill_time}")
	private String rel_budget_standstill_time;

	@Test
	public void fn40(){
		System.out.println(rel_budget_standstill_time);
	}
	
	
	public List<OrderCalcDto> buildDataOrder(String orderId) {
		OrderRecord entity = new OrderRecord();
		entity.setOrderId(orderId);
		List<OrderRecord> selectOne = orderRecordMapper.selectList(Wrappers.query(entity));
		String json = selectOne.get(0).getMsgBody();
		OrderDto order = JSONObject.parseObject(json, OrderDto.class);
		List<OrderCalcDto> transferOrderCalcDto = this.transferOrderCalcDto(order);
		return transferOrderCalcDto;
	}
	
	@Test
	public void fn11() {
//		List<OrderCalcDto> buildDataOrder = buildDataOrder("");
//		List<PlanDto> buildDataPlan = buildDataPlan(buildDataOrder.get(0));
//		sceneXServiceImpl.sceneFormula(buildDataOrder.get(0), buildDataPlan.get(0), 1, BaseConstants.SCENE_X);
	}
	
	@Test
	public void fn15() {
		StaffReqsDto staffReq = new StaffReqsDto();
//		staffReq.setShopNo(orderCalcDto.getShopNo());
//		staffReq.setEaBrandCode(orderCalcDto.getEaBrandCode());
//		staffReq.setEaCateSecond(orderCalcDto.getEaGroupCodeSecond());
		staffReq.setLogEmbedPort("查找定向结果");
		String json = "{\"eaBrandCode\":\"00005\",\"eaCateSecond\":\"R03\",\"logEmbedPort\":\"-\",\"shopNo\":\"A007\"}";
		staffReq = JSONObject.parseObject(json, StaffReqsDto.class);
		staffReq.setStaffCodeList(Arrays.asList("10204751"));
		StaffsIsMainDto queryIsMainStoreSellers = staffInfoService.queryIsMainStoreSellers(staffReq);
		System.out.println(queryIsMainStoreSellers);
	}
	
	
	@Test
	public void fn12() {

		// 计算逻辑
		String orderId = "19017843638";
		List<OrderCalcDto> buildDataOrder = buildDataOrder(orderId);
		if(CollectionUtils.isEmpty(buildDataOrder)) {
			return;
		}

		OrderCalcDto orderCalcDto = buildDataOrder.get(0);

		// select * from crp_order_calc_msg where order_id = '19017813586';
//		isoOrderService.handler("16", "25704996581149639740");
//		List<PlanDto> buildDataPlan = Arrays.asList(getPlandefDto(1));
		log.info("=========================   " + JSONObject.toJSONString(orderCalcDto));
		List<PlanDto> buildDataPlan = buildDataPlan(orderCalcDto);
		for (PlanDto planDto : buildDataPlan) {
			sceneXServiceImpl.calc(buildDataOrder.get(0), planDto);
//			sceneMServiceImpl.calc(buildDataOrder.get(0), planDto);
//			sceneZServiceImpl.calc(buildDataOrder.get(0), planDto);
		}
		
	}
	
	
	
	public List<PlanDto> buildDataPlan(OrderCalcDto calcDto) {
		List<PlanDto> planDtos = planService.orderMatchPlan(calcDto);
		
		return planDtos;
	}
	
	
	public PlanDto buildDataPlan(OrderCalcDto calcDto, Long planId) {
		List<PlanDto> planDtos = planService.orderMatchPlan(calcDto);
		PlanDto planDto = null;
		if(planDtos != null && planDtos.size() > 0) {
			Map<Long, PlanDto> collect = planDtos.stream().collect(Collectors.toMap(x -> x.getPlanId(), x -> x));
			planDto = collect.get(planId);
		}
		return planDto;
	}
	
	@Test
	public void fn13() {
		// 退单逻辑
		//19015556088
		List<OrderCalcDto> buildDataOrder = buildDataOrder("19015922681");
		orderRCOServiceImpl.process(buildDataOrder.get(0));
	}

	
	@Test
	public void fn14() {
		jobBudgetServiceImpl.occupyBudget1();
	}

	@Autowired
	private CalcResultMapper calcResultMapper;
	@Autowired
	private ICalcResultService iCalcResultService;


	@Test
	public void fn20(){
		Page<CalcResult> page = new Page<>();
		page.setSearchCount(false);
		page.setSize(10);
		CalcResult query = new CalcResult();
		query.setId(174801L);
//		query.setBudgetStatus(BaseConstants.BUDGET_CHECK_SUCCESS);
//		query.setJobStatus(BaseConstants.CRD_JOB_STATUS_1);
		QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
		queryWrapper.orderByAsc("id");
		// 添加in条件
//		queryWrapper.gt("id", idIndex);
		queryWrapper.select("id", "sku_name", "order_id", "plan_id", "award_amount", "job_status", "contract_type", "budget_status");
		Page<CalcResult> calcResultDetailPage = calcResultMapper.selectPage(page, queryWrapper);
		List<CalcResult> records = calcResultDetailPage.getRecords();
		records.forEach(x -> {
			x.setSkuName(x.getSkuName() + 1);
		});

		boolean result = iCalcResultService.updateBatchById(records);
		System.out.println(result);
	}
	
	@Test
	public void fn16() {
		//100040893702
		StaffBindDto staffInfoByUid = staffInfoService.getStaffInfoByUid("100040893702");
		System.out.println(staffInfoByUid);

	}
	
    @Autowired
    private SeqGenUtil seqGenUtil;
    
	@Test
	public void fn17() {
		Long calcRecordId = seqGenUtil.nextCrpCalcRecordId();	// 加入id生成器
    	System.out.println(calcRecordId);
	}
	
	@Test
	public void fn5() {
		this.readUrl("https://meiban.gome.com.cn/office/api/clockOn/addJson/10303777/70B1027660E34270-B1BB-643B8F325028_1572920783000/0/0/1");
	}
	

	/**
	 * 读取url地址数据, 类爬虫
	 * @param urlstr
	 */
	public static void readUrl(String urlstr) {
		if(StringUtils.isBlank(urlstr)) {
			return;
		}
		try {
			URL url = new URL(urlstr);
			URLConnection urlConnection = url.openConnection();
			HttpURLConnection connection = null;
			if (urlConnection instanceof HttpURLConnection) {
				connection = (HttpURLConnection) urlConnection;
			} else {
				System.out.println("请输入 URL 地址");
				return;
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
			String urlString = "";
			String current;
			while ((current = in.readLine()) != null) {
				urlString += current;
			}
			String format = DateFormatUtils.ISO_DATETIME_FORMAT.format(System.currentTimeMillis());
			System.out.println(format + " : " + urlString);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private List<OrderCalcDto> transferOrderCalcDto(OrderDto orderDto) {
        return oMSOrderServiceImpl.transferOrderCalcDto(orderDto);
    }
	
	
	@Autowired
	private ProfitStaffService profitStaffService;
	@Test
	public void fn110() {
		// oms
		List<OrderCalcDto> buildDataOrder = this.buildDataOrder("19015922722");
		StaffReqsDto staffReqsDto = this.getStaffReqsDto(buildDataOrder.get(0));
		List<PersonDto> so = profitStaffService.memberUserIdFindStaffIdentity(staffReqsDto);
		System.out.println(JSONObject.toJSONString(so));
	}
	
	
	
	/**
	 * StaffReqsDto 封装入参对象
	 * @return
	 */
	private StaffReqsDto getStaffReqsDto(OrderCalcDto order) {
		StaffReqsDto sr = new StaffReqsDto();
		List<OrderCalcCouponDto> occl = new ArrayList<>();;
		List<OrderCalcCouponDto> couponsDtos = order.getCouponsDtoList();
//		List<CouponsDto> couponsDtos = detailGoodsDto.getCouponsDtos();
		if (couponsDtos != null && couponsDtos.size() > 0) {
			couponsDtos.forEach(x -> {
				OrderCalcCouponDto nocc = new OrderCalcCouponDto();
				BeanUtils.copyProperties(x, nocc);
				occl.add(nocc);
			});
		}
		sr.setCouponsDtoList(occl);
		sr.setEaBrandCode(order.getEaBrandCode());
		String eaGroupCode = order.getEaGroupCode();
		if (StringUtils.isNotBlank(eaGroupCode)) {
			sr.setEaCateSecond(eaGroupCode.substring(0, 3));
		}
		String commerceItemId = order.getCommerceItemId();
		sr.setLogEmbedPort(String.format("[为OMS提供服务]-orderId:%s, 行项目号:%s ", order.getOrderId(), commerceItemId));
		sr.setProductShareUserId(order.getShareUserId());
		sr.setShopNo(order.getShopNo());
		sr.setStoreLevel(BaseConstants.STAFF_LEVEL_4 + "");
		sr.setSupplierCode(order.getSupplier());
		sr.setOrderUserId(order.getUserId());
		return sr;
	}

	private PlanDto getPlandefDto(int promotion){

		PlanDto planDto = new PlanDto();
		planDto.setPromotionsType(promotion);
		planDto.setContractClass(BaseConstants.COMPACT_CLASS_LSDK);
		// 新增月返
		planDto.setAddMonthlyRebate(BigDecimal.valueOf(22));
		planDto.setSingleStandardMoney(22L);
		// 追加金额
		planDto.setAdditionalAward(BigDecimal.valueOf(22L));
		// 发放比例
		planDto.setIssueRate(BigDecimal.valueOf(22L));
		planDto.setAddEachRebate(22L);
		planDto.setPolicyCode(BaseConstants.PLAN_EXTRA_POLICY_CODE_195);
		// xzm 比例
		planDto.setXValue(BigDecimal.valueOf(22L));
		planDto.setZValue(BigDecimal.valueOf(22L));
		planDto.setMValue(BigDecimal.valueOf(22L));
		// 十大品类编码
		planDto.setOfferPrice(22L);
		planDto.setPolicyRatio(BigDecimal.valueOf(22L));
		planDto.setSingleStandard(BigDecimal.valueOf(22L));
		planDto.setPlanId(1000000L);
		planDto.setAddEachRebate(22L);
		planDto.setCurrentPrice(22L);
		planDto.setProvisionType(BaseConstants.PLAN_PROVISION_SELL);


		return planDto;
	}
	
}
