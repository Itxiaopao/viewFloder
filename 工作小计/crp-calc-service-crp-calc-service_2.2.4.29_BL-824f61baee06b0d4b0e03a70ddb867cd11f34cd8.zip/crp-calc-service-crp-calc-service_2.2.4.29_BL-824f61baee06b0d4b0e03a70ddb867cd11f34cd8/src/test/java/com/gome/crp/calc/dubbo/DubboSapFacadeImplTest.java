package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.facade.dto.sap.*;
import com.gome.crp.calc.facade.dubbo.sap.IDubboSapFacade;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.common.util.ReflectUtil;
import com.gome.crp.calc.mybatis.mapper.SapRecordMapper;
import com.gome.crp.calc.mybatis.model.SapRecord;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DubboSapFacadeImplTest {
    @Autowired
    private IDubboSapFacade iDubboSapFacade;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private SapRecordMapper SapRecordMapper;

    @Test
    public void testSyncOrder() {
        OrderReqDto orderReqDto = new OrderReqDto();
        orderReqDto.setMessageId("1");
        orderReqDto.setDtSend(DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSS"));
        OrderItemDto orderItemDto = new OrderItemDto();

        orderItemDto.setVbeln("3");
        orderItemDto.setVtweg("10");
        orderItemDto.setPosnr("5");
        orderItemDto.setBstkd("12345678901234567890");
        orderItemDto.setMabnr("7");
        orderItemDto.setKwmeng("8");
        orderItemDto.setZekorg("9");
        orderItemDto.setWerks("10");
        orderItemDto.setLgort("11");
        orderItemDto.setZlifnr("12");
        orderItemDto.setZywjx("13");
        orderItemDto.setZdbukrs("14");
        orderItemDto.setZzconno("15");
        orderItemDto.setZelpak("16");
        orderItemDto.setZzxsbj("17");
        orderItemDto.setFlag("2");
        orderItemDto.setErdat(DateUtils.formatDate(new Date(), "yyyyMMddHHmmss"));

        String sapOrderUniqueKey = CacheKeyConstants.getSapOrderUniqueKey(orderReqDto.getMessageId());
        gcacheUtil.deleteKey(new String[]{sapOrderUniqueKey});

        List<OrderItemDto> orderItemDtoList = new ArrayList<>();
        iDubboSapFacade.syncOrder(orderReqDto, orderItemDtoList);
    }

    @Test
    public void testSyncBillReply() {
        BillReplyReqDto billReplyReqDto = new BillReplyReqDto();
        billReplyReqDto.setMessageId("1");
        billReplyReqDto.setDtSend(DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSS"));
        ArrayList<BillReplyItemDto> list = new ArrayList<>();
        BillReplyItemDto billReplyItemDto = new BillReplyItemDto();
        billReplyItemDto.setZflag("1");
        billReplyItemDto.setPernr("4");
        billReplyItemDto.setFlag1("5");
        billReplyItemDto.setTcjh("6");
        billReplyItemDto.setBstkd("12345678901234567890");
        billReplyItemDto.setQxbs("N");
        billReplyItemDto.setPosrq(DateUtils.formatDate(new Date(), "yyyyMMdd"));
        billReplyItemDto.setMatnr("10");
        billReplyItemDto.setFkimg("11");
        billReplyItemDto.setDmbtr("12");
        billReplyItemDto.setDmbtr1("13");
        billReplyItemDto.setZwerks("14");
        billReplyItemDto.setLifnr("15");
        billReplyItemDto.setLevel4("16");
        billReplyItemDto.setPrdha("17");
        billReplyItemDto.setConno("18");
        billReplyItemDto.setKonnr("19");
        billReplyItemDto.setJsrq(DateUtils.formatDate(new Date(), "yyyyMMdd"));
        billReplyItemDto.setCxflx("0");
        billReplyItemDto.setCxflxms("22");
        billReplyItemDto.setVbeln("23");
        billReplyItemDto.setPosnr("24");
        billReplyItemDto.setVbeln1("25");
        billReplyItemDto.setPosnr1("26");
        billReplyItemDto.setFkdat(DateUtils.formatDate(new Date(), "yyyyMMdd"));
        billReplyItemDto.setEbeln("28");
        billReplyItemDto.setBudat(DateUtils.formatDate(new Date(), "yyyyMMdd"));

        String SapRecordUniqueKey = CacheKeyConstants.getSapRecordUniqueKey(billReplyItemDto.getTcjh(), billReplyItemDto.getFlag1(), billReplyItemDto.getBstkd(), billReplyItemDto.getQxbs(), billReplyItemDto.getMatnr(), billReplyItemDto.getPernr());
        gcacheUtil.deleteKey(new String[]{SapRecordUniqueKey});

        list.add(billReplyItemDto);
        //billReplyReqDto.setList(list);

        SapRecord SapRecord = ReflectUtil.converter(billReplyReqDto, SapRecord.class);
        //SapRecord.setFlag(Integer.valueOf(billReplyReqDto.getList().get(0).getFlag1()));
        SapRecord.setPosrq(DateUtils.parseDate_yyyyMMdd("20200308"));
        SapRecord.setFkdat(DateUtils.parseDate_yyyyMMdd("20200308"));
        SapRecord.setBudat(DateUtils.parseDate_yyyyMMdd("20200308"));
        SapRecord.setJsrq(DateUtils.parseDate_yyyyMMdd("20200308"));
        SapRecordMapper.insert(SapRecord);

        //iDubboSapFacade.syncBillReply(billReplyReqDto);
    }

    @Test
    public void testSyncConfirmReceiptReply() {
        ConfirmReceiptReplyReqDto reqDto = new ConfirmReceiptReplyReqDto();
        reqDto.setMessageId("1");
        reqDto.setDtSend(DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSS"));
        ArrayList<ConfirmReceiptReplyItemDto> list = new ArrayList<>();
        ConfirmReceiptReplyItemDto itemDto = new ConfirmReceiptReplyItemDto();
        itemDto.setEbeln("28");
        itemDto.setEbelp("2");
        itemDto.setBelnr("3");
        itemDto.setBuzei("4");
        itemDto.setBudat("20200310");
        itemDto.setMenge("100.34");
        itemDto.setShkzg("S");
        itemDto.setElikz("X");
        list.add(itemDto);
        //reqDto.setList(list);

        String SapRecordReceiptUniqueKey = CacheKeyConstants.getSapRecordReceiptUniqueKey(itemDto.getEbeln(), itemDto.getBelnr(), itemDto.getShkzg(), itemDto.getElikz());
        gcacheUtil.deleteKey(new String[]{SapRecordReceiptUniqueKey});
        //iDubboSapFacade.syncConfirmReceiptReply(reqDto);
    }
}
