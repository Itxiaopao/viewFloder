package com.gome.crp.calc.service.problem.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.common.vo.PlanDetialForCal;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;

import java.math.BigDecimal;
import java.util.*;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ProblemServiceImplTest {

    @Autowired
    ProblemServiceImpl problemService;

    private String orderId = "123"; //订单ID
    private String deliveryId = "1234"; //配送单id
    private String skuNo = "1235"; //skuNo
    private String detailId = "123456"; //detailId

    @Test
    public void addData() {
//        ProblemDto problemDto = new ProblemDto(orderId, deliveryId, skuNo, detailId);
//        problemService.addData(problemDto, ProblemEnum.CODE_101);
//        testPlan();
//        testPlan1();
//        testPlan2();
//        testPlan3();
//        testPlan4();
//        testPlan5();
//        testPlan6();
//        testPlan7();
//        testPlan8();
//        testPlan9();
//        testPlan10();
        testPlan11();
        testPlan12();
    }
    @Autowired
    Gcache gcache;
    @Autowired
    GcacheUtil gcacheUtil;
    @Test
    public void testPlan(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(70L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setContractType("1");
        planDetialForCal.setCurrentPrice(100L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(44L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("1002",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(5);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00002:05", "44", JSON.toJSONString(planDetialForCal));
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        System.out.println(planVos.size());
    }

    @Test
    public void testPlan1(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(170L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setContractType("1");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(45L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        ArrayList<String> strings = new ArrayList<>();
        strings.add("A001");
        strings.add("A002");
        strings.add("A003");
        strings.add("A004");
        stringListHashMap.put("1002",strings);
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(5);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00002:05", "45", JSON.toJSONString(planDetialForCal));
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }

    @Test
    public void testPlan2(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setContractType("1");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(46L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(5);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00002:05", "46", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }

    //差异化
    @Test
    public void testPlan3(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,2);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("1");//签约类型
        planDetialForCal.setContractStartTime(instance.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(47L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(1);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00003:04", "47", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
    //差异化
    @Test
    public void testPlan4(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("1"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(48L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(1);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00003:04", "48", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
    //差异化
    @Test
    public void testPlan5(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("2"); //签约类型
        planDetialForCal.setContractStartTime(instance.getTime());
        planDetialForCal.setExtraStartTime(instance.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(49L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(1);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00003:04", "49", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
    //差异化
    @Test
    public void testPlan6(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("2"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(50L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(1);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00003:04", "50", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }

    //差异化
    @Test
    public void testPlan7(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("4"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(51L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(1);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00003:04", "51", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
    //差异化
    @Test
    public void testPlan8(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,2);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("4"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(52L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(1);
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00003:04", "52", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }

    //非差异化
    @Test
    public void testPlan9(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,2);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("4"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(3);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(53L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(0); //促销费类型
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00004:05", "53", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
    @Test
    public void testPlan10(){
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("4"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(2);
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(54L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(0); //促销费类型
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00004:05", "54", JSON.toJSONString(planDetialForCal));
//        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
//        System.out.println(planVos.size());
    }
    //供应商承担
    @Test
    public void testPlan11(){
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,1);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("3"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(0);//费用承担
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(45L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(0); //促销费类型
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00004:05", "55", JSON.toJSONString(planDetialForCal));
//        gcache.hdel("CALC:TE00004:05", "55");
    }
    @Test
    public void testPlan12(){
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,3);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("4"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(1);//费用承担
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(56L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(0); //促销费类型
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00004:05", "56", JSON.toJSONString(planDetialForCal));
//        gcache.hdel("CALC:TE00004:05", "55");
    }
    //差异化
    @Test
    public void testPlan13(){
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,3);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("2"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(1);//费用承担
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(57L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(0); //促销费类型
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00004:05", "57", JSON.toJSONString(planDetialForCal));
//        gcache.hdel("CALC:TE00004:05", "55");
    }

    //差异化
    @Test
    public void testPlan14(){
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField("CALC:TE00002:05", PlanDetialForCal.class);
        PlanDetialForCal planDetialForCal = new PlanDetialForCal();
        planDetialForCal.setContractSupplierCode("testSupplierCode");
        planDetialForCal.setAwardMoney(270L);
        planDetialForCal.setContractCode("A1000000001");
        planDetialForCal.setCurrentPrice(200L);
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH,3);
        planDetialForCal.setStartTime(instance.getTime());
        Calendar instance1 = Calendar.getInstance();
        instance1.set(Calendar.DAY_OF_MONTH,29);
        planDetialForCal.setEndTime(instance1.getTime());
        planDetialForCal.setContractType("2"); //签约类型
        planDetialForCal.setContractStartTime(instance1.getTime());
        planDetialForCal.setExtraStartTime(instance1.getTime());
        planDetialForCal.setExpenseOfferType(2);//费用承担
        planDetialForCal.setExtensionCoverageType("1");
        planDetialForCal.setExtraNum("A000101011");
        planDetialForCal.setExtraType(2);
        planDetialForCal.setId(58L);
        planDetialForCal.setIsOffset(1);
        planDetialForCal.setIssueRate(new BigDecimal(70));
        planDetialForCal.setOfferPrice(12000L);
        HashMap<String, Map<String, List<String>>> stringHashMapHashMap = new HashMap<>();
        HashMap<String, List<String>> stringListHashMap = new HashMap<>();
        stringListHashMap.put("11010000",new ArrayList<>());
        stringHashMapHashMap.put("1",stringListHashMap);
        planDetialForCal.setOrgToStore(stringHashMapHashMap);
        planDetialForCal.setPolicyCode("Z195");
        planDetialForCal.setPromotionsType(0); //促销费类型
        planDetialForCal.setProvisionType(0);
        planDetialForCal.setRoyaltyType(0);
        planDetialForCal.setSalesModelCode("05");
        planDetialForCal.setSkuNo("TE00001");
        planDetialForCal.setStatus(3);
        planDetialForCal.setStepRate(new BigDecimal(5));
        planDetialForCal.setTagPrice(1000L);
        gcache.hset("CALC:TE00004:05", "58", JSON.toJSONString(planDetialForCal));
//        gcache.hdel("CALC:TE00004:05", "55");
    }
}