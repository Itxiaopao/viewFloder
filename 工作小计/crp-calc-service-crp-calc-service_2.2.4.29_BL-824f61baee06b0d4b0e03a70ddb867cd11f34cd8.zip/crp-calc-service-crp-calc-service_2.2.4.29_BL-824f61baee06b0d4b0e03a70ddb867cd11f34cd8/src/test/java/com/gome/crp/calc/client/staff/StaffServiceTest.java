package com.gome.crp.calc.client.staff;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.service.scene.impl.SceneXServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StaffServiceTest {
	
	@Autowired
	private IStaffInfoService iStaffInfoService;
	
	@Autowired
	private SceneXServiceImpl sceneXServiceImpl;
	@Autowired
	private CalcResultMapper calcResultMapper;
	
	public void fn1() {
		List<String> ids = new ArrayList<>();
		iStaffInfoService.getBatchStaffInfoByUid(ids);
	}
	public void fn2() {
		List<String> codes = new ArrayList<>();
		iStaffInfoService.getBatchUserInfoByStaffCode(codes);
		
	}
	
	public void fn3() {
		iStaffInfoService.getStaffInfoByUid("");
	}
	
	@Test
	public void fn5() {
//		OrderCalcDto od = new OrderCalcDto();
//		CalcResult rd = new CalcResult();
//		rd.setId(23L);
//		CalcResult selectOne = calcResultMapper.selectOne(Wrappers.query(rd));
//		BeanUtils.copyProperties(selectOne, od);
//
//		od.setEaBrandCode("00818");
//		od.setEaGroupCodeSecond("R12");
//		od.setStoreSellerId("10138502");
//		od.setShareUserId("123");
		
			
//		List<PersonDto> profitPerson = sceneXServiceImpl.getProfitPerson(od, null);
//		profitPerson.forEach(System.out::println);
	}
	
    @Test
	public void fn4() {
		List<String> employeeIdList = null;
//		employeeIdList = Arrays.asList("10208658", "00067642", "00069983", "10275383", "10275427", "10275552", "10033432", "10275744");
		// {"brandId":"00818","categoryId":"R12","currentPage":0,"pageSize":0,"shop":"A007","staffLevel":"4"}

//		employeeIdList = Arrays.asList("00026985");
//		String categoryId = "R05";
//		String brandId = "00001";
//		String shop = "A007";
//		String shoplevel = "4";
		String categoryId = "R12";
		String brandId = "00818";
		String shop = "A007";
		String shoplevel = "4";
		List<EmployeeInfoDto> list = iStaffInfoService.queryGomeEmployeeInformation(categoryId, brandId, employeeIdList, shop, shoplevel);
		System.out.println(JSONObject.toJSONString(list));
		
//		for (EmployeeInfoDto employeeInfoDto : list) {
//			System.out.println(JSONObject.toJSONString(employeeInfoDto));
//		}
	}
    
    
    @Test
    public void fn() {
    	String user = "19015204348";
    	EmployeeInfoDto employeeDtoByUserId = iStaffInfoService.getEmployeeDtoByUserId(user);
    	System.out.println("========================" + employeeDtoByUserId);
    	
    	
    }

}
