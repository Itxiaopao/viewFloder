package com.gome.crp.calc.service.job.impl;

import com.gome.crp.calc.util.GcacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest
public class IJob15PercentServiceImplTest {
    @Autowired
    private IJob15PercentServiceImpl job15PercentService;
    @Autowired
    private GcacheUtil gcacheUtil;

//    @DiamondValue("${reset.cursor.time}")
//    private int timeExpire;

    @Test
    public void deal15Percent() {
//        for (;;){
//            System.out.println("=========================");
//            System.out.println(1);
//            System.out.println("=========================");
//        }
//        job15PercentService.deal15Percent();
        job15PercentService.deal15PercentCursor();
//        gcacheUtil.putKeyValue(CacheKeyConstants.get15PercentIndexKey(),"456666");
//        gcacheUtil.setExpireTime(CacheKeyConstants.get15PercentIndexKey(),8);
    }
}