package com.gome.crp.calc.filter;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FieldValueChangeLogTest {
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private ICalcResultService iCalcResultService;

    @Test
    public void recordChange() {
        CalcResult calcResult = new CalcResult();
        calcResult.setId(199999999L);
        calcResult.setJobStatus(9);
        //calcResultMapper.insert(calcResult);

        ArrayList<CalcResult> calcResultList = new ArrayList<>();
        CalcResult calcResult2 = new CalcResult();
        calcResult2.setId(188888888L);
        calcResult2.setJobStatus(18);
        calcResultList.add(calcResult2);

        CalcResult calcResult3 = new CalcResult();
        calcResult3.setId(1777777777L);
        calcResult3.setJobStatus(17);
        calcResultList.add(calcResult3);
        //iCalcResultService.saveBatch(calcResultList);


        calcResult3.setJobStatus(117);
        calcResult2.setJobStatus(118);
        //iCalcResultService.updateBatchById(calcResultList);

        calcResult3.setJobStatus(2119);
        iCalcResultService.updateById(calcResult3);
    }
}
