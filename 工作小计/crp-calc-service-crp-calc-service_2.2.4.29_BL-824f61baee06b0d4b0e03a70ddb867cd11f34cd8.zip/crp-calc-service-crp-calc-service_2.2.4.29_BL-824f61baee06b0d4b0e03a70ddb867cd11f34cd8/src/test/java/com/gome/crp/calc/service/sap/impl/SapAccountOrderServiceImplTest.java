package com.gome.crp.calc.service.sap.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.dto.sapDto.SapAccountInfo;
import com.gome.crp.calc.service.sap.ISapAccountOrderService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SapAccountOrderServiceImplTest {
    @Autowired
    private ISapAccountOrderService iSapAccountOrderService;

    @Test
    public void handler() {
        String msg = "{\"budat\":1587052800000,\"budat1\":1587052800000,\"budat2\":1587052800000,\"bukrs\":\"V511\",\"bukrs0\":\"5101\",\"charg\":\" \",\"conno\":\"GOME2019C00500277\",\"dmbtr1\":799.00,\"dmbtr2\":799.00,\"dmbtr3\":31.96,\"ebeln\":\" \",\"ebelp\":0,\"fkimg\":1,\"forwardStatus\":0,\"id\":1194031,\"konnr\":\" \",\"level2\":\"R31\",\"level3\":\"R3102\",\"level4\":\"R3102001\",\"lifnr\":\"0010044439\",\"matnr\":\"000000000100548151\",\"mblnr\":\"7218182454\",\"meins\":\"TAI\",\"newno\":\"GOME2019C00500277\",\"posnr\":1,\"reuno\":\"FY0000084\",\"updats\":1588089600000,\"vbeln\":\"1180723521\",\"zcxfy\":0.00,\"zdmbt1\":\" \",\"zdtbz\":\" \",\"zeile\":1,\"zyfje\":0.00}";
        SapAccountInfo sapAccountInfo = JSON.parseObject(msg, SapAccountInfo.class);
        iSapAccountOrderService.handler(sapAccountInfo);
    }
}
