package com.gome.crp.calc.client.sap;

import com.gome.crp.calc.client.erm.IErmService;
import com.gome.crp.calc.constants.FailureReasonEnum;
import com.gome.crp.calc.dto.ermDto.LetterReqDto;
import com.gome.crp.calc.dto.ermDto.LetterResDto;
import com.gome.crp.calc.dto.sapDto.*;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SapServiceImplTest {
    @Autowired
    private ISapService iSapService;
    @Autowired
    private IErmService iErmService;
    @Autowired
    private CalcResultMapper calcResultMapper;

    @Test
    public void testApplyBill() {

        ApplyBillReqDto applyBillReqDto = new ApplyBillReqDto();
        HeaderDto headerDto = new HeaderDto();
        headerDto.setInterfaceId("FI475");
        headerDto.setMessageId("223456789");
        headerDto.setSender("crp-calc-service");
        headerDto.setReceiver("ECC");
        headerDto.setDtsend(DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSS"));
        applyBillReqDto.setHeader(headerDto);

        Fi475Dto fi475Dto = new Fi475Dto();
        fi475Dto.setFlag("1");

        List<ItemDto> itemDtos = new ArrayList<>();
        ItemDto itemDto = new ItemDto();
        itemDto.setBstkd("1");
        itemDto.setQxbs("3");
        itemDto.setPosrq("4");
        itemDto.setMatnr("5");
        itemDto.setFkimg(new BigDecimal("7"));
        itemDto.setDmbtr(new BigDecimal("8"));
        itemDto.setDmbtr1(new BigDecimal("9"));
        itemDto.setZwerks("10");
        itemDto.setLifnr("11");
        itemDto.setLevel4("12");
        itemDto.setPrdha("13");
        itemDto.setConno("14");
        itemDto.setKonnr("15");
        itemDto.setFlag1("X");
        itemDto.setTcjh("17");
        itemDto.setPernr("18");
        itemDto.setCxflx("19");
        itemDto.setCxflxms("20");
        itemDtos.add(itemDto);

        fi475Dto.setItem(itemDtos);
        applyBillReqDto.setFi475(fi475Dto);

        ApplyBillResDto applyBillResDto = iSapService.applyBill(applyBillReqDto);
        assert applyBillResDto == null;
    }

    @Test
    public void testQueryPurchaseCode() {
        QueryPurchaseCodeReqDto queryPurchaseCodeReqDto = new QueryPurchaseCodeReqDto();
        queryPurchaseCodeReqDto.setLogicDcPlaceId("WX46XBT1");
        QueryPurchaseCodeResDto queryPurchaseCodeResDto = iSapService.queryPurchaseCode(queryPurchaseCodeReqDto);
        System.out.println(queryPurchaseCodeResDto.getPurchasingOrganizationIdList());
    }

    @Test
    public void testPurchaseCode() {
        QueryPurchaseCodeReqDto queryPurchaseCodeReqDto = new QueryPurchaseCodeReqDto();
        queryPurchaseCodeReqDto.setLogicDcPlaceId("WX46XBT1");
        QueryPurchaseCodeResDto queryPurchaseCodeResDto = iSapService.queryPurchaseCode(queryPurchaseCodeReqDto);
        System.out.println(queryPurchaseCodeResDto.getPurchasingOrganizationIdList());
    }

    @Test
    public void testIsSameLetterNo() {

        String str = "25955,25956";
        String[] split = str.split("[,]");

        for (int i = 0; i < split.length; i++) {
            CalcResult calcResult = calcResultMapper.selectById(split[i]);

            LetterReqDto letterReqDto = new LetterReqDto();
            letterReqDto.setContractCode(calcResult.getContractCode());
            letterReqDto.setExtraPurchaseCode(calcResult.getExtraPurchaseCode());
            letterReqDto.setOrderSupplierCode(calcResult.getOrderSupplierCode());
            letterReqDto.setDocty(calcResult.getDocty());
            letterReqDto.setSkuNo(calcResult.getSkuNo());
            letterReqDto.setSalesModel(calcResult.getSalesModel());

            List<LetterResDto> letterDtoList = iErmService.queryLetter(letterReqDto);
            if (!CollectionUtils.isEmpty(letterDtoList)) {
                //函有效期校验
                List<LetterResDto> filterLetterDtoList = letterDtoList.stream().filter(l -> l.getAedat() != null
                        && l.getDatbi() != null
                        && l.getDatab() != null
                        && calcResult.getOrderSubmitTime() != null
                        && calcResult.getOrderSubmitTime().after(l.getDatab())
                        && calcResult.getOrderSubmitTime().before(l.getDatbi())).collect(Collectors.toList());
                if (!CollectionUtils.isEmpty(filterLetterDtoList)) {
                    //排序筛选
                    Optional<LetterResDto> first = filterLetterDtoList.stream()
                            .sorted(Comparator.comparing(LetterResDto::getAedat).reversed()).findFirst();
                    LetterResDto letterDto = first.get();
                    if (calcResult.getExtraNum() != null && calcResult.getExtraNum().equals(letterDto.getQrnno())) {
                        System.out.println("okokok" + split[i]);
                    }
                }
            }

            calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_LETTER_NO_MATCH.getMsg());
            System.out.println("errerrerr" + split[i]);
        }

    }
}
