package com.gome.crp.calc.service.scene.impl;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.service.scene.formula.impl.FormulaCYH;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FormulaCYHTest {

    @Autowired
    private FormulaCYH formulaCYH;

    @Test
    public void formulaCYH_v2_fn_test() {
        String scene = "SCENE-X";
        String log_pre = "公式测试";
        //
        OrderCalcDto orderCalcDto = new OrderCalcDto();
        orderCalcDto.setBuyNum(10);
        //
        PlanDto planDto = new PlanDto();
        planDto.setAddEachRebate(100L);
        planDto.setAddMonthlyRebate(new BigDecimal("10"));
        planDto.setAdditionalAward(BigDecimal.valueOf(10L));
        planDto.setIssueRate(new BigDecimal("10"));
        planDto.setXValue(new BigDecimal("10"));
        planDto.setCurrentPrice(10000L);
        planDto.setOfferPrice(2000L);
        planDto.setComprehensiveContribution("10");
        planDto.setNowRateProfit(new BigDecimal("80"));
        planDto.setOldRateProfit(new BigDecimal("20"));
        BigDecimal result = formulaCYH.formulaCYH_v2_fn5(orderCalcDto, planDto, scene, log_pre);
        System.out.println("result:" + result);

    }


}
