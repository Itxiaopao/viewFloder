package com.gome.crp.calc.client.employee;

import com.gome.dragon.mds.client.dto.gcc.GomeOrganization;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class IStaffInfoServiceTest {
    @Autowired
    private IStaffInfoService iStaffInfoService;

    @Test
    public void getSellingOrganization() {
        GomeOrganization sellingOrganization = iStaffInfoService.getSellingOrganization("5001");
        System.out.println(sellingOrganization.getCompanyId());
    }
}
