package com.gome.crp.calc.mq.consumer;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.order.calc.dto.OrderDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderMsgConsumerProcessImplTest {
    @Autowired
    private IOMSOrderService iOMSOrderService;

    @Test
    public void testConsumeMessage() {
        String str = "{\"deliveryList\":[{\"channelNo\":\"16\",\"gomeState\":\"CO\",\"goodsList\":[{\"categoryFirstId\":\"cat10000000\",\"categoryFourthId\":\"\",\"categorySecondId\":\"cat10000012\",\"categoryThirdId\":\"cat10000070\",\"commerceItemId\":\"48952219\",\"companyCode\":\"1001\",\"description\":\"一店一页测试海尔单门冰箱大件预售前端009\",\"detailList\":[{\"buyNum\":1,\"couponsDtoList\":[{\"couponType\":3005,\"ticketId\":\"b7a316c282b639c08aa846fe2d957638\"}],\"detailId\":\"1149616668\",\"logicMasLoc\":\"WXF0X011\",\"price\":2207,\"salesModel\":\"01\",\"supplier\":\"0020001137\"}],\"eaBrandCode\":\"00001\",\"eaGroupCode\":\"R0501001\",\"goodsType\":\"1\",\"salePrice\":2222,\"salesOrganization\":\"1001\",\"skuId\":\"1000225777\",\"skuName\":\"一店一页>测试海尔单门冰箱大件预售前端009\",\"skuNo\":\"109968066\"}],\"orderDate\":1585014030723,\"shippingGroupId\":\"2570413012\",\"shopNo\":\"A00G\",\"shopType\":\"pshop\"}],\"loginName\":\"10138502\",\"orderId\":\"19015555539\",\"orderPrice\":2207,\"orderSalePrice\":2207,\"profileId\":\"100035895223\",\"requestHeaderMap\":{\"app\":\"shangcheng\",\"ver\":\"v7.0.0\",\"plt\":\"wap\"},\"submittedDate\":1585013858263}";
        OrderDto orderDto = JSON.parseObject(str, OrderDto.class);
        iOMSOrderService.handler(orderDto);
    }
}
