package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

import java.io.Serializable;

@Data
public class HeaderDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private String interfaceId; //接口编号-固定值:FI475
    private String messageId; //消息编号-32位GUID
    private String sender; //发送方代码-固定值:crp-calc-service
    private String receiver; //接收方代码-固定值:ECC
    private String dtsend; //发送时间-格式:yyyyMMddHHmmssSSS
}
