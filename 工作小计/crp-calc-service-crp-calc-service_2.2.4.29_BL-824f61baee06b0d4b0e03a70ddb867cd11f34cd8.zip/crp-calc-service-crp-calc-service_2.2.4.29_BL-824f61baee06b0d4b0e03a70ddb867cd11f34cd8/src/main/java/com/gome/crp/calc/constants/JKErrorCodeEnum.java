package com.gome.crp.calc.constants;

/**
 * 集客活动错误码
 */
public enum JKErrorCodeEnum {
    CODE_301("301", "调用来源不合法"),
    CODE_401("401", "部分参数为空或参数不正确"),
    CODE_402("402", "当前活动不存在"),
    CODE_403("403", "当前订单时间不在活动销售时间范围"),
    CODE_404("404", "下单用户不存在集客索引"),
    CODE_405("405", "当前活动类型错误，非领票活动"),
    CODE_406("406", "下单用户未参与活动 或 所交订金已退款,不计入统计"),
    CODE_500("500", "服务内部异常"),

    ;

    private String code;
    private String msg;

    JKErrorCodeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
