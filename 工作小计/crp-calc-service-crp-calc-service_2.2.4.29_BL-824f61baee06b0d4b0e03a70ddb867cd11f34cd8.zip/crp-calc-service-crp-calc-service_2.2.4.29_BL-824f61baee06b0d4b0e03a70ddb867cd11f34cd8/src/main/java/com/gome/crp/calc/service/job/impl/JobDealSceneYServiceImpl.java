package com.gome.crp.calc.service.job.impl;

import com.gome.crp.calc.service.job.IJobDealSceneYService;
import com.gome.crp.calc.service.scene.impl.SceneYServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Slf4j
@Service
public class JobDealSceneYServiceImpl implements IJobDealSceneYService {
    @Autowired
    private SceneYServiceImpl sceneYServiceImpl;
    @Override
    public void dealSceneY() {
        log.info("执行处理SceneY的job,时间:{}",new Date().toString());
        sceneYServiceImpl.jobDealSceneY();
    }
}
