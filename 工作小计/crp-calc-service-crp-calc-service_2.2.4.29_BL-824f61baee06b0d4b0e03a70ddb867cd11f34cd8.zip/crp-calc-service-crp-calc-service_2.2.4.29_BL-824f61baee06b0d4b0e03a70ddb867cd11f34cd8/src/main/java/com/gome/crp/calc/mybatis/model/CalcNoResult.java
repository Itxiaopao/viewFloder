package com.gome.crp.calc.mybatis.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * 未匹配计划订单表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class CalcNoResult {
	@TableId(type = IdType.INPUT)
	private Long id; //id
	private String orderId; //订单号
	private String deliveryId; //配送单号
	private String sapDetailId; //sapDetailId
	private String detailId; //detailId
	private String channel; //订单渠道
	private Integer status; //状态
	private String remark; //备注
	private Date createTime; //createTime
	private Date updateTime; //updateTime
}