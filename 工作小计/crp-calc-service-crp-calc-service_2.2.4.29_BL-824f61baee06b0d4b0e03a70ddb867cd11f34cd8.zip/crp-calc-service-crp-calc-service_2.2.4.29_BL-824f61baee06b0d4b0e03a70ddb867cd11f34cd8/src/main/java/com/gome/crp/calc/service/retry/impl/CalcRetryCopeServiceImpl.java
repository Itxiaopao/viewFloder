package com.gome.crp.calc.service.retry.impl;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.client.message.ISendMessage;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;
import com.gome.crp.calc.dto.threadLocal.LocalDto;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import com.gome.crp.calc.service.retry.cope.RetryFactory;
import com.gome.crp.calc.mybatis.mapper.CalcRetryMapper;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.mybatis.service.ICalcRetryService;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import com.gome.crp.calc.util.GcacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * 计划重推
 *
 * @author libinbin9
 */
@Slf4j
@Service
public class CalcRetryCopeServiceImpl implements ICalcRetryCopeService {

    @Autowired
    private ICalcRetryService calcRetryService;
    @Autowired
    private CalcRetryMapper calcRetryMapper;
    @Autowired
    private GcacheUtil gcache;
//    @Autowired
//    private Gcache gcache;
    @Autowired
    private RetryFactory retryFactory;
    @Autowired
    private ISendMessage iSendMessage;


    private static int LIMIT = 50;   // limit

    // selct * from retry where id >= select_id_from
    private static long select_id_from = 0;

    // 5 minite
    private static int expire_time_1_min = 60;
    // 5 minite
    private static int expire_time_5_min = expire_time_1_min * 5;
    // 10 minite
    private static int expire_time_10_min = expire_time_1_min * 10;
    // 20 minite
    private static int expire_time_20_min = expire_time_1_min * 20;
    // 30 minite
    private static int expire_time_30_min = expire_time_1_min * 30;
    // 60 minite
    private static int expire_time_60_min = expire_time_1_min * 60;


    @Override
    public void insertRetry(CalcRetry calcRetry) {
        if (calcRetry == null) {
            return;
        }

        if (calcRetry.getRepeatTime() == null) {
            calcRetry.setRepeatTime(0);
        }

        if (calcRetry.getIsDelete() == null) {
            calcRetry.setIsDelete(IsDeleteEnum.NO.getCode());
        }

        if (calcRetry.getIsSuc() == null) {
            calcRetry.setIsSuc(IsSuccessEnum.NO.getCode());
        }

        if (calcRetry.getFailureReason() != null && calcRetry.getFailureReason().length() > 1000) {
            calcRetry.setFailureReason(calcRetry.getFailureReason().substring(0, 1000));
        }

        calcRetryMapper.insert(calcRetry);
    }

    /**
     * 扫描
     */
    @Override
    public void scan() {
        String scan_redis_key = CacheKeyConstants.getCalcRetryTaskLockKey("retry-scan-all-1");
        // 最大执行时间
        Long distributedLock = gcache.setnxex(scan_redis_key, expire_time_20_min, scan_redis_key);
        if (distributedLock != 1){
            log.info(String.format("重推JOB异常-程序正在停止期, scan-all-rediskey: %s", scan_redis_key));
            // 当前节点分布式程序还没有执行完毕, 保证job只存在一台机器执行
            return;
        }
        try {
            scan_fn();
        }catch (Exception e){
            log.error("重推JOB异常-终止", e);
        }finally {
            // 删除keys... 单独删除, key 属于不同的槽点, 批删报错
            gcache.del(scan_redis_key);
        }
    }

    private void scan_fn(){
//        String localAddress = AddressUtil.getLocalAddress();
        // id-from-redis-key
        log.info(String.format("重推JOB,重试扫描-START"));
        String scan_fn_id_from_rk = CacheKeyConstants.getCalcRetryTaskLockKey("retry-job-1");
        // condition==============================
        CalcRetry cr = new CalcRetry();
        cr.setIsDelete(IsDeleteEnum.NO.getCode());
        cr.setIsSuc(IsSuccessEnum.NO.getCode());
        QueryWrapper<CalcRetry> query = Wrappers.query(cr);
        query.lt("repeat_time", 10);
        query.ge("id", select_id_from);
        query.orderByAsc("id");
        // condition===============================
        IPage<CalcRetry> page = new Page<>();
        page.setSize(LIMIT);
        long cope_size = 0; // 统计数据量
        while (true) {
            String keyValue = gcache.get(scan_fn_id_from_rk);
            if(StringUtils.isBlank(keyValue)){
                query.ge("id", 0);
            }else{
                query.gt("id", Long.valueOf(keyValue));
            }
            IPage<CalcRetry> selectPage = calcRetryMapper.selectPage(page, query);
            List<CalcRetry> pageResults = selectPage.getRecords();
            int size = pageResults.size();
            if(pageResults == null || size <= 0){
                break;
            }
            // 统计处理数量
            Long cope_offset_id = this.scan_cope_one_page(pageResults);
            // 保存偏移量 10 min
            gcache.setex(scan_fn_id_from_rk, expire_time_1_min, cope_offset_id + "");
            cope_size += pageResults.size();
        }
        gcache.del(scan_fn_id_from_rk);
        log.info(String.format("重推JOB,重试扫描-END, 处理数据量: %s", cope_size));
    }

    // 处理位置
    private Long scan_cope_one_page(List<CalcRetry> pageResults){
        // offset id
        Long id_offset = 0L;
        // 推送 重试
        for (CalcRetry x: pageResults) {
            // 设置id-from-setoff
            id_offset = x.getId();
            // 单条信息校对, 如处理中, 跳过, execute next data
            /*String calcRetryTaskLockKey = CacheKeyConstants.getCalcRetryTaskLockKey("retry-id:" + x.getId());
            Long id_lock_offset = gcache.setnxex(calcRetryTaskLockKey, expire_time_5_min,  "1");
            if(id_lock_offset < 1){
                // 当前正在执行, 防止重复执行
                log.info("重推操作id- {}, 已经执行过了, 请等待 {}s 时间结束后如果未成功将继续尝试重试操作", x.getId(), expire_time_5_min);
                continue;
            }*/
            boolean ret = this.retryTheCopeFun(x);
            if (!ret) {
                x.setRepeatTime(x.getRepeatTime() + 1);    // 重试失败 次数+1
                //重试次数满10次报警
                if (x.getRepeatTime() == 10) {
                    String content = String.format("重试失败id:%s", x.getId());
                    SendMessageDto sendMessageDto = new SendMessageDto(SendMsgTypeEnum.SEND_WECHAT_TEXT.getCode(), content, SendMsgBusinessTypeEnum.RETRY_ALERT.getCode());
                    sendMessageDto.setTopic("提成二期系統-重试满10次异常报警");
                    sendMessageDto.setUserList(MailAddressEnum.getMailAddressList());
                    iSendMessage.sendAsyncMsg(sendMessageDto);
                }
            } else {
                x.setIsSuc(IsSuccessEnum.YES.getCode());    // 成功标示
            }
            x.setMsgBody(null); // 制空 存储速度 ******
            x.setFailureReason(null);   // 处理错误信息报错问题
            // 执行更新
            try {
                calcRetryService.updateById(x);
            }catch (Exception e){
                log.error(String.format("Retry-Update操作异常请查阅数据- %s ", JSONObject.toJSONString(x)), e);
            }
            // del key
            /*gcache.del(calcRetryTaskLockKey);*/
        }
        // 执行更新
//        try {
//            calcRetryService.updateBatchById(pageResults, pageResults.size());
//        }catch (Exception e){
//            log.error(String.format("Retry-Update操作异常请查阅数据- %s ", JSONObject.toJSONString(pageResults)), e);
//        }
        return id_offset;
    }

    /**
     * 重推类型处理类: 不同类型封装不同的方法体, 引入该方法统一做判断
     *
     * @param calcRetry
     * @return
     */
    private boolean retryTheCopeFun(CalcRetry calcRetry) {
        IRetrySceneService cope_service = retryFactory.getCopeService(calcRetry.getType());
        boolean cope = false;
        try {
            cope = cope_service.cope(calcRetry);
        }catch (Exception e){
            log.error(String.format("重推操作失败-id-%s",calcRetry.getId()), e);
            cope = false;
        }
        return cope;
    }

}



