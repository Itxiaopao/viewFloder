package com.gome.crp.calc.mybatis.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.SapRecordMapper;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ISapRecordService;
import org.springframework.stereotype.Service;

@Service
public class SapRecordServiceImpl extends ServiceImpl<SapRecordMapper, SapRecord> implements ISapRecordService {
}
