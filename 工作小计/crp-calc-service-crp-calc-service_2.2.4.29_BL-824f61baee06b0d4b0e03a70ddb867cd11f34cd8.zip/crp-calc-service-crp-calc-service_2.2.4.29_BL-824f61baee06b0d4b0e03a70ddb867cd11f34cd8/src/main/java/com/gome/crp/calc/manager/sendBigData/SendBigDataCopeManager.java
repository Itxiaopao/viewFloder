package com.gome.crp.calc.manager.sendBigData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.gome.crp.calc.dto.bigDataDto.CalcResultDetailDto;
import com.gome.crp.calc.dto.bigDataDto.CalcResultDto;
import com.gome.crp.calc.mq.producer.SendBigDataProducerProcessImpl;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.mybatis.model.CalcResult;

import lombok.extern.slf4j.Slf4j;

/**
 * 推送大数据(数据封装处理类)
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class SendBigDataCopeManager {
	
    @Autowired
    private SendBigDataProducerProcessImpl sendBigDataProducerProcessImpl;

    /**
     * 推送大数据: 状态日志中判断 (正向单)
     * 
     * @param calcResultList
     */
    public void sendBigDataMSG(List<CalcResult> calcResultList) {
    	this.sendBigDataMSG(calcResultList, null);
    }
    
    
    /**
     * 推送大数据: 状态日志中判断 , 逆向单
     * 
     * @param calcResultList
     * @param returnOrderId 可为空
     */
    public void sendBigDataMSG(List<CalcResult> calcResultList, String returnOrderId) {
	   String jsonString = JSONObject.toJSONString(calcResultList);
	   // 非空判断
	   if(CollectionUtils.isEmpty(calcResultList)) {
		   log.info(String.format("推送大数据[失败], 数据为空"));
		   return;
	   }

       // key: primiry-id, value:CalcResult
       Map<Long, CalcResult> map = calcResultList.stream().collect(Collectors.toMap(x -> x.getId(), x -> x));	
       // key: orderId, value: List<primiry-id>
       Map<String, Set<Long>> orderMap = new HashMap<>();	
       calcResultList.stream().forEach(x -> {
           String orderId = x.getOrderId();
           Set<Long> set = orderMap.get(orderId);
           Optional<Set<Long>> op = Optional.ofNullable(set);
           set = op.orElse(new HashSet<>());
           set.add(x.getId());
           orderMap.put(orderId, set);
       });

       try {
           Set<String> keySet = orderMap.keySet();
           if (keySet == null || keySet.size() <= 0) {
        	   log.info(String.format("发送大数据失败, msg:%s, 批处理结果为NULL.", jsonString));
               return;
           }
           for (String key : keySet) {
               Set<Long> set = orderMap.get(key);
               if(null == set || set.size() <= 0) {
            	   continue;
               }
               CalcResultDto calcrd = null;
               List<CalcResultDetailDto> datas = new ArrayList<>();
               for (Long resultId : set) {
                   CalcResult cr = map.get(resultId);
                   if (null == calcrd) {
                       calcrd = new CalcResultDto();
                       calcrd.setCommerce_item_id(cr.getCommerceItemId());
                       calcrd.setDelivery_order_id(cr.getDeliveryId());
                       calcrd.setDetail_id(cr.getDetailId());
                       calcrd.setGomeStatus(cr.getGomeStatus());
                       calcrd.setJobStatus(cr.getJobStatus());
                       calcrd.setOrder_id(cr.getOrderId());
                       calcrd.setSales_channel(cr.getChannel());
                       calcrd.setSales_model(cr.getSalesModel());
                       calcrd.setSap_detail_id(cr.getSapDetailId());
                       calcrd.setSku_no(cr.getSkuNo());
                       calcrd.setSubmittedDate(DateUtils.formatDateTime(cr.getOrderSubmitTime()));
                       if(cr.getPayDate() != null){
                    	   calcrd.setPay_date(DateUtils.formatDateTime(cr.getPayDate()));
                       }
                   }
                   CalcResultDetailDto crd = new CalcResultDetailDto();
                   crd.setEmployee_id(cr.getStaffCode());
                   crd.setMember_id(cr.getUserId());
                   crd.setPlan_id(cr.getPlanId());
                   crd.setProfit_amount(cr.getAwardAmount() + "");    // 分
                   crd.setProfit_type(cr.getScenes());
                   crd.setUpdate_time(DateUtils.formatDateTime(cr.getUpdateTime()));
                   crd.setVitae_id(cr.getId() + "");
                   if(cr.getProfitBehavior() != null){
                	   crd.setAttribution_action(cr.getProfitBehavior().toString());
                   }
                   datas.add(crd);

               }
               if (null != calcrd) {
                   calcrd.setDatas(datas);
                   calcrd.setReturn_order_id(returnOrderId);
                   Integer jobStatus = calcrd.getJobStatus();
                   String msg_json_data = JSONObject.toJSONString(calcrd);
                   log.info(String.format("发送大数据[START], jobStatus=%d, msg=%s", jobStatus, msg_json_data));
                   sendBigDataProducerProcessImpl.sendBigData(calcrd);
                   log.info(String.format("发送大数据[END], jobStatus=%d, msg=%s", jobStatus, msg_json_data));
               }
           }
       } catch (Exception e) {
    	   log.error(String.format("发送大数据[异常], msg:%s", jsonString), e);
       }
    }
    
    
    
}
