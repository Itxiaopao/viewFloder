package com.gome.crp.calc.client.settlement.impl;

import cn.com.gome.rebate.dubbo.service.app.IDubboCrpService;
import cn.com.gome.rebate.model.CrpConvertRebateDto;
import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.settlement.IPayService;
import com.gome.crp.calc.dto.payDto.ApplyPayItemDto;
import com.gome.crp.calc.dto.payDto.ApplyPayReqDto;
import com.gome.crp.calc.dto.payDto.ApplyPayResDto;
import com.gome.crp.calc.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class PayServiceImpl implements IPayService {
    @Autowired
    private IDubboCrpService iDubboCrpService;

    @Override
    public ApplyPayResDto applyPay(ApplyPayReqDto reqDto) {
        if (reqDto == null || CollectionUtils.isEmpty(reqDto.getItems())) {
            throw new IllegalArgumentException("调用支付模块挂账接口-入参错误");
        }

        String payDtoListJson = null;
        try {
            List<ApplyPayItemDto> itemList = reqDto.getItems();
            List<CrpConvertRebateDto> payDtoList = new ArrayList<>(itemList.size());

            for (ApplyPayItemDto itemDto : itemList) {
                CrpConvertRebateDto payItemDto = translate(itemDto);
                payDtoList.add(payItemDto);
            }

            payDtoListJson = JSON.toJSONString(payDtoList);
            //支付模块挂账接口调用
            log.info("调用支付模块挂账接口开始payDtoList:{}", payDtoListJson);
            iDubboCrpService.crpSendToSAP(payDtoList);
            log.info("调用支付模块挂账接口完成payDtoList:{}", payDtoListJson);

            return new ApplyPayResDto();
        } catch (Exception e) {
            log.error("调用支付模块挂账接口异常payDtoList:{}", payDtoListJson, e);
            throw new BusinessException(String.format("调用支付模块挂账接口异常payDtoList:%s", payDtoListJson), e);
        }
    }

    /**
     * 冪等（id + statusStr）
     *
     * @param itemDto
     * @return
     */
    private CrpConvertRebateDto translate(ApplyPayItemDto itemDto) {
        CrpConvertRebateDto payDto = new CrpConvertRebateDto();
        payDto.setId(itemDto.getCalcResultId().intValue());
        payDto.setKid(itemDto.getScenes());
        payDto.setStatusStr(itemDto.getGomeStatus());
        payDto.setAmount(itemDto.getAwardAmount());
        payDto.setDeliveryOrderId(itemDto.getDeliveryId());
        payDto.setRebateType(itemDto.getExpencesOfferType());
        payDto.setSkuNo(itemDto.getSkuNo());
        payDto.setSkuName(itemDto.getSkuName());
        payDto.setBuyNum(itemDto.getBuyNum());
        payDto.setDeliveredTime(itemDto.getOrderEffectTime());
        payDto.setCompanyCode(itemDto.getCompanyCode());
        payDto.setShopCode(itemDto.getShopNo());
        payDto.setUserId(itemDto.getUserId());
        payDto.setFlbs(itemDto.getIsASellA() == null ? null : itemDto.getIsASellA().toString());
        payDto.setPlanId(Integer.valueOf(itemDto.getPlanId()));
        payDto.setZcjbs(String.valueOf(itemDto.getIsGomeOffer()));
        payDto.setChannel(itemDto.getChannel());
        return payDto;
    }

}