package com.gome.crp.calc.service.order.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.client.erm.IErmService;
import com.gome.crp.calc.client.sap.IQueryPlanService;
import com.gome.crp.calc.client.settlement.IClientSettlementService;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.dto.ermDto.ReleaseBudgetReqDto;
import com.gome.crp.calc.dto.ermDto.ReleaseBudgetResDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.sapDto.ResourceReturnReqDto;
import com.gome.crp.calc.dto.sapDto.ResourceReturnResDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.manager.sendBigData.SendBigDataCopeManager;
import com.gome.crp.calc.mq.producer.SendEnrollBillProcessImpl;
import com.gome.crp.calc.mybatis.model.*;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.service.budget.IBudgetService;
import com.gome.crp.calc.service.order.IOrderService;
import com.gome.crp.calc.service.order.abstr.AbstractOrderBaseService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.service.ICalcRecordService;
import com.gome.crp.calc.mybatis.service.ISapRecordService;
import com.gome.crp.settlement.facade.vo.SaReverseOrderDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 退货审核完成 等于原来的退货申请 提成失效
 * 
 * 
 */
@Slf4j
@Service
public class OrderRCOServiceImpl extends AbstractOrderBaseService implements IOrderService {

	@Autowired
	private IProblemService problemService;
	@Autowired
	private ISapRecordService sapRecordService;
	@Autowired
	private IErmService ermService;
//	@Autowired
//	private ICalcResultService calcResultService;
	@Autowired
	private CalcResultMapper calcResultMapper;
	@Autowired
	private IClientSettlementService clientSettlementService;
	@Autowired
	private IBillService billService;
	@Autowired
	private ICalcRecordService calcRecordService;
	@Autowired
	private SendBigDataCopeManager sendBigDataCopeManager;
	@Autowired
	private ICalcRewardsService calcRewardsService;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;
    @Autowired
    private SeqGenUtil seqGenUtil;
    @Autowired
    private IBudgetService budgetService;
    @Autowired
	private IQueryPlanService iQueryPlanService;
    @Autowired
	private SendEnrollBillProcessImpl sendEnrollBillProcess;

    // 获取时间
    @Value("${rel_budget_standstill_time}")
	private String rel_budget_standstill_time;
	
	/**
	 * 1. 判断数据正确性1. 提奖金额 > 0  订单数量应该 > 0, job <4 <p>
	 * 
	 * 2. 按照退货单号入计算履历表中 <p>
	 * 
	 * 3. job < 4 状态分别处理以下结果 <p>
	 * 	a. job = 3 以拉取 调取 推动结算接口 <p>
	 * 	b. 其他状态: 调取sendToSap状态数据 <p>
	 * 
	 * 4. SAP冲账 job < 3, 调取sap冲账接口 <p>
	 * 
	 * 5. 预算回滚: <p>
	 * 
	 * 6. 推送大数据, job = 2 <p>
	 * 
	 * 7. 数据更新: a.如果计算提奖结果 <= 0, 强job = 失效, b.订单gome状态改为 RCO <p>
	 * 
	 * 8. 数据更新: 如果result 结果表的提奖金额 > 0 都作为部分妥投, 如果=0设置为退货 <p>
	 * 
	 */
	@Override
	public Integer process(OrderCalcDto orderCalcDto) {
		String orderId = orderCalcDto.getOrderId();
		String deliveryId = orderCalcDto.getDeliveryId();
		String detailId = orderCalcDto.getDetailId();
		String channel = orderCalcDto.getChannel();
		String skuNo = orderCalcDto.getSkuNo();
		String returnOrderId = orderCalcDto.getReturnOrderId();	// 退单iD
		
		log.info(String.format("RCO退单流程处理[START], orderId:%s, deliveryId:%s, detailId:%s, channel:%s, skuNo:%s, param:%s", 
				orderId, deliveryId, detailId, channel, skuNo, JSONObject.toJSONString(orderCalcDto)));
		CalcResult cr = new CalcResult();
		cr.setOrderId(orderId);
		cr.setChannel(channel);
		cr.setDetailId(detailId);
		cr.setSkuNo(skuNo);
		cr.setIsDelete(IsDeleteEnum.NO.getCode());
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(cr);
        queryWrapper.eq("calc_logic", orderCalcDto.getCalcLogic()).or().eq("calc_logic", "");
		List<CalcResult> calcResultList = calcResultMapper.selectList(queryWrapper);
		log.info(String.format("RCO退单流程处理, 数据库查询结果, deliveryId:%s, results:%s", deliveryId, JSONObject.toJSONString(calcResultList)));
		if (null == calcResultList || calcResultList.size() <= 0) {
			return null;	// 不向下执行操作
		}

		// 可用订单使用
		List<CalcResult> use_collection = calcResultList.stream().filter(x -> {
			if (x.getBuyNum() <= 0) {
				// 诊断 数据可用性
				log.info(String.format("RCO退单流程处理[数据存在异常], order.buyNum<=0, orderId:%s, resultId:%s, sapDetailId:%s, init_jobStatus:%s",
						x.getOrderId(), x.getId(), x.getSapDetailId(), x.getJobStatus()));
				return false;
			}else{
				return true;
			}
		}).collect(Collectors.toList());

		this.cope_collections(orderCalcDto, use_collection);

		log.info(String.format("RCO退单流程处理[END], orderId:%s, deliveryId:%s, 退单流程结束", orderId, deliveryId));
		return null;
	}

	// collection dataset
	private void cope_collections(OrderCalcDto orderCalcDto, List<CalcResult> calcResultList){
		//	逻辑: 妥投 > 退货数量
		//  异常: 提奖金额 <= 0 时 或者购买数量 <= 0时: update result表, 改成退货状态 加入履历record表 订单状态直接改成退货
		if (null == calcResultList || calcResultList.size() <= 0) {
			return;	// 不向下执行操作
		}
		// 推送结算[负值:awardMoney]
		List<SaReverseOrderDto> settlementReverseOrders = new ArrayList<>();
		// 履历表
		List<CalcRecord> insertRecords = new ArrayList<>();
		// 推送 SAP 线上  [正值awardMoney]
		List<CalcResult> sapOnlines = new ArrayList<>();
		// 加入sap冲账 线下 [负值awardMoney]
		List<CalcResult> sapOfflines = new ArrayList<>();
		// 推送大数据
		List<CalcResult> bigDataResults = new ArrayList<>();
		// 预算回滚
		List<ReleaseBudgetReqDto> rollbackBudgetDtos = new ArrayList<>();
		// 新接口
		List<ResourceReturnReqDto> rollbackBudgetDtos_new = new ArrayList<>();
		// 存储计算结果履历
		List<CalcResultReward> calcResultRewardList = new ArrayList<>();
		// 账单结果集
		List<CalcResult> billResults = new ArrayList<>();

		for (CalcResult calcResult: calcResultList){
			this.copeResultElement(calcResult, orderCalcDto, rollbackBudgetDtos,
					rollbackBudgetDtos_new, insertRecords, bigDataResults,
					settlementReverseOrders, sapOnlines, sapOfflines,
					calcResultRewardList, billResults);
		}
		// 集中更新操作
		this.updateAll(rollbackBudgetDtos, rollbackBudgetDtos_new, insertRecords,
				bigDataResults, settlementReverseOrders, sapOnlines,
				sapOfflines, orderCalcDto.getOrderId(), orderCalcDto.getReturnOrderId(),
				calcResultRewardList, billResults);
	}
	
	// cope data set
	private void copeResultElement(CalcResult calcResult, OrderCalcDto orderCalcDto,
			List<ReleaseBudgetReqDto> rollbackBudgetDtos,
		    List<ResourceReturnReqDto> rollbackBudgetDtos_new, List<CalcRecord> insertRecords,
			List<CalcResult> bigDataResults, List<SaReverseOrderDto> settlementReverseOrders,
			List<CalcResult> sapOnlines, List<CalcResult> sapOfflines, List<CalcResultReward> calcResultRewardList,
		    List<CalcResult> billResults ) {

		String orderId = orderCalcDto.getOrderId();
		String deliveryId = orderCalcDto.getDeliveryId();
		// result Id
		Long id = calcResult.getId();
		// 退单id
		String returnOrderId = orderCalcDto.getReturnOrderId();
		// sap detail 
		String sapDetailId = orderCalcDto.getSapDetailId();
		// 初始job状态
		Integer init_jobStatus = calcResult.getJobStatus();
		// 初始gome状态
		String init_gomeStatus = calcResult.getGomeStatus();
		log.info(String.format("RCO退单流程处理[detail], orderId:%s, resultId:%s, sapDetailId:%s, init_jobStatus:%s", orderId, id, sapDetailId, init_jobStatus));
		
		// 2.计算提奖金额并修改(等比例), (buyNum - dto.buyNum) * 总金额/原有订单数量 = 保存的数据 
		// 计算单件价格
		int will_divided_buyNum = orderCalcDto.getBuyNum();	// dto-> buyNum
		if(will_divided_buyNum < 0) {
			// 校验是否是正数
			will_divided_buyNum = -will_divided_buyNum;
		}
		int initial_buyNum = calcResult.getBuyNum();	// 结果表 buyNum
		Long initial_awardAmount = calcResult.getAwardAmount(); // 结果表 cr_aw
//		if (initial_buyNum <= 0){
//			// 诊断 数据可用性
//			log.info(String.format("RCO退单流程处理[数据存在异常], order.buyNum<=0, orderId:%s, resultId:%s, sapDetailId:%s, init_jobStatus:%s", orderId, id, sapDetailId, init_jobStatus));
//			return;
//		}
		// 等比例 单个商品提奖金额
		BigDecimal singleAwardPrice = BigDecimal.valueOf(initial_awardAmount).divide(BigDecimal.valueOf(initial_buyNum), 0, BigDecimal.ROUND_DOWN);
		// 需要扣减的提奖金额
		BigDecimal willDividedAward = BigDecimal.valueOf(will_divided_buyNum).multiply(singleAwardPrice);
		// 原始提奖金额 - 扣减提奖金额 = 需要保存的扣减提奖金额
		BigDecimal result_awards = BigDecimal.valueOf(initial_awardAmount).subtract(willDividedAward);
		if(result_awards.compareTo(BigDecimal.valueOf(0)) < 0) {
			calcResult.setAwardAmount(0L);	// 防止为负值
		}else {
			calcResult.setAwardAmount(result_awards.longValue());
		}
		// 保存购买数量并计算
		calcResult.setBuyNum(initial_buyNum - will_divided_buyNum);
		
		// 7(upgrade). 数据更新: a.如果计算提奖结果 <= 0, 强job = 失效, b.订单gome状态改为 RCO
		if(result_awards.longValue() <= 0) {
			calcResult.setFailureReason("RCO扣减提奖金额为 0,job=4");
			calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
			calcResult.setGomeStatus(BaseConstants.ORDER_RCO_STATUS);
		}else {
			calcResult.setGomeStatus(BaseConstants.ORDER_DL_STATUS);
		}
		// 8(upgrade). 数据更新: 如果result 结果表的提奖金额 > 0 都作为部分妥投, 如果=0设置为退货
		if(initial_buyNum == will_divided_buyNum) {
			calcResult.setFailureReason("RCO全部退货,job=4");
			calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);	// 是否设置job=4
			calcResult.setGomeStatus(BaseConstants.ORDER_RCO_STATUS);
		}else if(initial_buyNum > will_divided_buyNum) {
			calcResult.setGomeStatus(BaseConstants.ORDER_DL_STATUS);
		}
		
		// 3.a. job = 3 以拉取 调取 推动结算接口
		// 计算的需要扣减的结果值, 注: 负值
		BigDecimal minusDivisedAward = willDividedAward.multiply(BigDecimal.valueOf(-1));
		
		// 幂等id == sap使用
		Long msgId = null;
		CalcRecord cpta = this.cpInsertRecord(calcResult, orderCalcDto, 
								willDividedAward.longValue(), will_divided_buyNum);
		msgId = cpta.getId();
		// 3.b. 其他状态: 调取sendToSap状态数据 job < 3
		if(init_jobStatus <= 4) {
			// 加入计算履历表
			long longValue = willDividedAward.longValue();
			if(longValue > 0) {
				// 推送sap 线上
				Integer isOnlineApplyBill = calcResult.getIsOnlineApplyBill();
				if(isOnlineApplyBill != null && isOnlineApplyBill.equals(IsOnlineApplyBillEnum.ALREADY_APPLY.getCode())) {
					CalcResult bo = setSapResult(calcResult, msgId, will_divided_buyNum, longValue);	// postive
					bo.setGomeStatus(BaseConstants.ORDER_RCO_STATUS);	// 退单 线上rco
					sapOnlines.add(bo);
				}else {
					log.info(String.format("RCO退单流程处理-线上sap冲账[状态:未挂账-PASS], deliveryId:%s, calcResultId:%s, orderId:%s", deliveryId, id, orderId));
				}
				// 4.SAP冲账 job < 3, 调取sap冲账接口, // 冲账 线下
				Integer isOfflineApplyBill = calcResult.getIsOfflineApplyBill();
				if(isOfflineApplyBill != null && isOfflineApplyBill.equals(IsOnlineApplyBillEnum.ALREADY_APPLY.getCode())) {
					CalcResult bo = setSapResult(calcResult, calcResult.getId(), will_divided_buyNum, -longValue);	// minus
					bo.setSapDetailId(sapDetailId);
					sapOfflines.add(bo);
				}else {
					log.info(String.format("RCO退单流程处理-线下sap冲账[状态:未挂账-PASS], deliveryId:%s, calcResultId:%s, orderId:%s", deliveryId, id, orderId));
				}
			}else {
				log.info(String.format("RCO退单流程处理-[线上,线下]sap冲账[冲账金额:0-PASS], deliveryId:%s, calcResultId:%s, orderId:%s", deliveryId, id, orderId));
			}
			// 退货推送大数据
			//是否推动大数据判断  兼容旧数据NULL
        	Integer isPushBigdata = calcResult.getIsPushBigdata();
        	if(isPushBigdata == null || isPushBigdata == 1){
    			CalcResult sendBigDataCalcResult = bigDataResultDto(calcResult, will_divided_buyNum, willDividedAward.longValue());
    			bigDataResults.add(sendBigDataCalcResult);
        	}

		}
		
		// 1.处理错误数据
		boolean matchCalcResult = this.matchCalcResult(initial_awardAmount.longValue(), initial_buyNum, init_jobStatus, will_divided_buyNum, calcResult);
		if(!matchCalcResult) {
			//if(calcResult.getGomeStatus())
			log.info(String.format("RCO退单流程处理-校验数据信息[不处理] , orderId:%s, calcResultId:%s, deliveryId:%s, job=%s, gomestatus=%s", 
									orderId, id, deliveryId, init_jobStatus, init_gomeStatus));
			return;
		}
		
		// job状态: 已拉取(妥投 + 7) 产生退货结算通知
		if(init_jobStatus == 3) {
			log.info(String.format("RCO退单流程处理-jobstatus:3, 推送结算, deliveryId:%s, calcResultId:%s, orderId:%s", deliveryId, id, orderId));
			SaReverseOrderDto sro = this.cpSaReverseOrderDto(calcResult, returnOrderId, minusDivisedAward, will_divided_buyNum);
			settlementReverseOrders.add(sro);
			return;
		}
		
		if(init_jobStatus < 3) {
			// 推送返利入账状态 job < 3
			if(calcResult.getRebateAccountType() > BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_INIT){
				CalcResult rebateBillMQ = this.getRebateBillMQ(calcResult, willDividedAward.longValue());
				billResults.add(rebateBillMQ);
				// 处理退单数据
				calcResult.setRebateAccountType(BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_3);
			}

			// 3.0 更新数据, 查看数据是否正常, 如果不正常抛出异常, 结束当前计算过程
			log.info(String.format("RCO退单流程处理[COPE]: deliveryId:%s, 订单orderId:%s, 扣减提奖金额:%s, 退货数量:%d, "
													+ "gomeStatus:%s -> %s, jobStatus:%d -> %d", 
									deliveryId, orderId, willDividedAward, will_divided_buyNum, 
									init_gomeStatus, calcResult.getGomeStatus(), init_jobStatus, calcResult.getJobStatus()));
			// 更新测试

			this.singleResultUpdate(calcResult, init_jobStatus);
		
			// 加入计算履历表record
			insertRecords.add(cpta);
			
			// 5.预算回滚: 
			boolean isBudget = budgetService.isBudgetControl(calcResult);
			// 判断是否可用预算
			if (isBudget && calcResult.getBudgetStatus() == 1) {
				// 一期逻辑
				if (calcResult.getVersion() == 1) {
					// 金额: 正数  幂等校验问题,  recordId 为负数
					ReleaseBudgetReqDto reqDto = new ReleaseBudgetReqDto(-msgId + "", calcResult.getPlanId(), willDividedAward);
					rollbackBudgetDtos.add(reqDto);
				} else {
					// 二期逻辑
					if(BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))){
						// 金额: 正数  幂等校验问题,  recordId 为负数
						ReleaseBudgetReqDto reqDto = new ReleaseBudgetReqDto(-msgId + "", calcResult.getPlanId(), willDividedAward);
						rollbackBudgetDtos.add(reqDto);
					}else{
						ResourceReturnReqDto reqDto = new ResourceReturnReqDto();
						reqDto.setPlanId(calcResult.getPlanId());
						reqDto.setRequestUuid(-msgId + "");
						reqDto.setReturnAmount(willDividedAward);
						reqDto.setCalcResult(calcResult);	// by 2020-8-19
						rollbackBudgetDtos_new.add(reqDto);
					}
				}
//				calcResultRewardList.add(getCalcReward(calcResult, (willDividedAward.longValue() + "")));
			}else {
				log.info(String.format("RCO退单流程处理-预算回滚[否], calcResultId:%s, deliveryId:%s, orderId:%s", id, deliveryId, orderId));
			}
		}
	}
	
	// all update
	private void updateAll(List<ReleaseBudgetReqDto> rollbackBudgetDtos,
						   List<ResourceReturnReqDto> rollbackBudgetDtos_new, List<CalcRecord> insertRecords,
						   List<CalcResult> bigDataResults, List<SaReverseOrderDto> settlementReverseOrders,
						   List<CalcResult> sapOnlines, List<CalcResult> sapOfflines, String orderId, String returnOrderId,
						   List<CalcResultReward> calcResultRewardList, List<CalcResult> billResults) {
		// 预算回滚 以上都会滚
		this.releaseBudgetCope(rollbackBudgetDtos, orderId);
		// 预算新接口
		this.releaseBudgetCope_new(rollbackBudgetDtos_new, orderId);
		// 保证事务
		this.transSaveRecordCope(insertRecords, orderId);
		// 推送大数据 
		this.sendBidDataCope(bigDataResults, orderId, returnOrderId);
		// 推送结算通知
		this.settlementCope(settlementReverseOrders, orderId);
		// sap冲账 线下/线上
		this.sendSapCope(sapOnlines, sapOfflines, orderId);
		// 保存退单计算值数据
//		this.saveRewardsRecord(calcResultRewardList);
		this.sendRebateBillDataCope(billResults, orderId);

	}
    
	/**
	 * 单独更新操作
	 * @param calcResult
	 * @param jobStatus 原始订单的job状态
	 * @return
	 */
	private int singleResultUpdate(CalcResult calcResult, int jobStatus) {
		CalcResult condition = new CalcResult();
		// 订单状态不等于4的情况下加入插入校验
		String orderId = calcResult.getOrderId();
		Long id = calcResult.getId();
		condition.setJobStatus(jobStatus);
		condition.setId(id);
		condition.setOrderId(orderId);
		log.info(String.format("RCO退单流程处理-[单条]更新结算表CalcResult, orderId:%s, resultId:%d, jobStatus:%d", orderId, id, jobStatus));
		int update = calcResultMapper.update(calcResult, Wrappers.query(condition));
		log.info(String.format("RCO退单流程处理-[单条]更新结算表CalcResult, orderId:%s, resultId:%d, jobStatus:%d, 更新结果:%d ", orderId, id, jobStatus, update));
		if(update <= 0) {
			throw new BusinessException(String.format("RCO退单流程处理-更新退货单: 该数据状态以改变导致更新失败,需要计划重推, param: %s", JSONObject.toJSONString(calcResult)));
		}
		return update;
	}
	
	
	
	// 添加事务
	@Transactional(rollbackFor = Exception.class)
	private void transSaveRecordCope(List<CalcRecord> insertRecords, String orderId) {
		// 履历表
		if(insertRecords != null && insertRecords.size() > 0) {
			// 插入record表信息
			log.info(String.format("RCO退单流程处理-加入履历表[START], orderId:%s, param:%s", orderId, JSONObject.toJSONString(insertRecords)));
			calcRecordService.saveOrUpdateBatch(insertRecords, insertRecords.size());
			log.info(String.format("RCO退单流程处理-加入履历表[END], orderId:%s", orderId));
		}
		/*// 结果表
		List<CalcResult> udpateCalcResults, 
		if(udpateCalcResults != null && udpateCalcResults.size() > 0) {
			// 更新表信息
			log.info(String.format("RCO退单流程处理-更新结算[START], orderId:%s,param:%s", orderId, JSONObject.toJSONString(udpateCalcResults)));
			calcResultService.saveOrUpdateBatch(udpateCalcResults, udpateCalcResults.size());
			log.info(String.format("RCO退单流程处理-更新结算[END], orderId:%s", orderId));
		}*/
	}
	

	
	/**
	 * 预算回滚
	 * @param rollbackBudgetDtos
	 * @param orderId 
	 */
	private void releaseBudgetCope(List<ReleaseBudgetReqDto> rollbackBudgetDtos, String orderId) {
		if(CollectionUtils.isEmpty(rollbackBudgetDtos)) {
			return;
		}
		for (ReleaseBudgetReqDto reqDto : rollbackBudgetDtos) {
			log.info(String.format("RCO退单流程处理-预算回滚接口 [start], orderId:%s, resultId:%s, param:%s", orderId, reqDto.getMessageId(), JSONObject.toJSONString(reqDto)));
			ClientResultDTO<ReleaseBudgetResDto> releaseBudget = ermService.releaseBudget(reqDto); // 是否加入重推计划
			if (!releaseBudget.isSuccess()) {
				// 报错强制回滚
                throw new BusinessException(String.format("RCO退单流程处理-预算回滚接口[异常], 释放预算失败, orderId:%s, reqDto:%s", orderId, JSON.toJSONString(reqDto)));
            }
			log.info(String.format("RCO退单流程处理-预算回滚接口 [end], orderId:%s, resultId:%s, 结果: %d", orderId, reqDto.getMessageId(), releaseBudget.getCode()));
		}
	}

	/**
	 * 预算回滚
	 * @param rollbackBudgetDtos
	 * @param orderId
	 */
	private void releaseBudgetCope_new(List<ResourceReturnReqDto> rollbackBudgetDtos, String orderId) {
		if(CollectionUtils.isEmpty(rollbackBudgetDtos)) {
			return;
		}
		for (ResourceReturnReqDto reqDto : rollbackBudgetDtos) {
			log.info(String.format("RCO退单流程处理-new-预算回滚接口 [start], orderId:%s, resultId:%s, param:%s", orderId, reqDto.getRequestUuid(), JSONObject.toJSONString(reqDto)));
			ClientResultDTO<ResourceReturnResDto> retq = iQueryPlanService.returnResource(reqDto);
			if (!retq.isSuccess()) {
				// 报错强制回滚
                throw new BusinessException(String.format("RCO退单流程处理-new-预算回滚接口[异常], 释放预算失败, orderId:%s, reqDto:%s", orderId, JSON.toJSONString(reqDto)));
            }
			log.info(String.format("RCO退单流程处理-new-预算回滚接口 [end], orderId:%s, resultId:%s, 结果: %d", orderId, reqDto.getRequestUuid(), retq.getCode()));
		}
	}

	/**
	 * 发送大数据
	 * @param bigDataResults
	 * @param orderId 
	 */
	private void sendBidDataCope(List<CalcResult> bigDataResults, String orderId, String returnOrderId) {
		if(CollectionUtils.isEmpty(bigDataResults)) {
			return;
		}
		log.info(String.format("RCO退单流程处理-推送大数据[结束], orderId:%s, param:%s", orderId, JSONObject.toJSONString(bigDataResults)));
		if(bigDataResults.size() > 0) {
			sendBigDataCopeManager.sendBigDataMSG(bigDataResults, returnOrderId);
		}
		log.info(String.format("RCO退单流程处理-推送大数据[结束], orderId:%s", orderId));
	}
	/**
	 * 发送返利入账信息
	 * @param billResults
	 * @param orderId
	 */
	private void sendRebateBillDataCope(List<CalcResult> billResults, String orderId) {
		if(CollectionUtils.isEmpty(billResults)) {
			return;
		}
		log.info(String.format("RCO退单流程处理-推送返利入账[start], orderId:%s, param:%s", orderId, JSONObject.toJSONString(billResults)));
		sendEnrollBillProcess.sendPreBills(billResults, BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_3,BaseConstants.ORDER_RCO_STATUS);
		log.info(String.format("RCO退单流程处理-推送返利入账[end], orderId:%s", orderId));
	}
	
	
	/**
     * copy properties by source calcResult and inside log journal
     * 
     * @param calcResult
     * @return
     */
	private void addProblem(CalcResult calcResult, String problemMSG, ProblemEnum problemEnum) {
    	String str = String.format("RCO退单流程处理-加入问题小工具, orderId:%s, 问题信息:%s, 问题类型:%s", calcResult.getOrderId(), problemMSG, problemEnum.getCode());
    	log.info(str);
    	ProblemDto pd = new ProblemDto(calcResult.getOrderId(), calcResult.getChannel(), calcResult.getSkuNo(), calcResult.getDetailId());
    	pd.setDescription(problemMSG);
    	pd.setCalcResultId(calcResult.getId()+"");
    	pd.setPlanId(calcResult.getPlanId());
    	problemService.addData(pd, problemEnum);
    }
	
	// sap冲账  online offline
	private void sendSapCope(List<CalcResult> onlines, List<CalcResult> offlines, String orderId) {
		// 判断 推送sap截止时间
		if(getRelStill() && CollectionUtils.isNotEmpty(onlines)) {
			// 线上 sap冲账
			String onlineString = JSONObject.toJSONString(onlines);
			try {
				log.info(String.format("RCO退单流程处理-线上SAP冲账[START], orderId:%s,param:%s", orderId, onlineString));
				billService.applyPay(onlines);
				log.info(String.format("RCO退单流程处理-线上SAP冲账[END], orderId:%s, 处理成功", orderId));
			} catch (Exception e) {
				log.info(String.format("RCO退单流程处理-线上SAP冲账[失败-加入重推], orderId:%s, sap:%s", orderId, onlineString));
                this.saveRetry(onlineString, RetryJobEnum.SAP_RELEASE_ONLINE.getCode(), orderId, e);
			}
		}
		
		if(CollectionUtils.isNotEmpty(offlines)) {
			// sap冲账 1, 退货的时候, 订单会有一个sapDetailId, 用sapDetailId冲账,手动至为冲账金额为负
			String offlineString = JSONObject.toJSONString(offlines);
			log.info(String.format("RCO退单流程处理-线下SAP冲账 [START], orderId:%s, param:%s", orderId, offlineString));
			List<SapRecord> sapRecordList = billService.applyBill(offlines);
			boolean saveBatch = sapRecordService.saveBatch(sapRecordList);
			log.info(String.format("RCO退单流程处理-线下SAP冲账 [END], orderId:%s, 处理结果:%b", orderId, saveBatch));
			if(!saveBatch) {
				log.info(String.format("RCO退单流程处理-线下SAP冲账[失败-加入重推], orderId:%s, sap:%s", orderId, offlineString));
                this.saveRetry(offlineString, RetryJobEnum.SAP_RELEASE_OFFLINE.getCode(), orderId, null);
			}
		}
	}

	/**
	 * 限制条件 sap online 推送
	 * @return
	 */
	private boolean getRelStill(){
		// 查过 rel_budget_standstill_time 返回false
		String ret = rel_budget_standstill_time;
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime localDateTime = LocalDateTime.parse(ret, dateTimeFormatter);
		Date d = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
		boolean rets = true;
		if(System.currentTimeMillis() > d.getTime()){
			rets = false;
		}
		return rets;
	}

	/**
	 * 重推数据
	 * @param text
	 * @param type
	 */
    private void saveRetry(String text, int type, String orderId, Exception ex) {
        CalcRetry calcRetry = new CalcRetry();
        calcRetry.setType(type);
        calcRetry.setOrderId(orderId);
        calcRetry.setMsgBody(text);
        calcRetry.setGomeStatus(BaseConstants.ORDER_RCO_STATUS);
        if (ex != null) {
            calcRetry.setFailureReason(ex.getMessage());
        }
        calcRetryCopeService.insertRetry(calcRetry);
    }
	

	/**
	 * 推送 结算通知, 并做重推处理
	 * 
	 * @param settlementReverseOrders
	 * @param orderId 
	 */
	private void settlementCope(List<SaReverseOrderDto> settlementReverseOrders, String orderId) {
		if(CollectionUtils.isEmpty(settlementReverseOrders)) {
			return;
		}
		String text = JSONObject.toJSONString(settlementReverseOrders);
		// 推送结算
		log.info(String.format("RCO退单流程处理-推送结算接口, orderId:%s, 参数:%s", orderId, text));
		boolean resultre = clientSettlementService.receiveReverseOrder(settlementReverseOrders);
		log.info(String.format("RCO退单流程处理-推送结算接口, orderId:%s, 推送结果:%b", orderId, resultre));
		if (!resultre) {
			// 添加重推计划
            log.info(String.format("RCO退单流程处理-推送结算接口加入重推表, orderId:%s, msg:%s", orderId, text));
            this.saveRetry(text, RetryJobEnum.SETTLEMENT.getCode(), orderId, null);
		}
	}
	
	// 匹配是否是正常的结果数据
	private boolean matchCalcResult(long init_award, int init_buyNum, int init_jobStatus, int will_buyNum, CalcResult calcResult) {
		String error_str = "";
		if(init_jobStatus == 4) {
			error_str = String.format("RCO退单流程处理-匹配有效数据[失败], 原因:jobstatus=4, orderId:%s,", 
					calcResult.getOrderId());
			log.info(error_str);
			return false;
		}
		if(init_buyNum <= 0 || init_award < 0 ) {
			error_str = String.format("RCO退单流程处理-匹配有效数据[失败], orderId:%s, 原因:订单[商品数量:%d],匹配订单[提奖金额:%d]", 
					calcResult.getOrderId(), init_buyNum, init_award);
			log.info(error_str);
			this.addProblem(calcResult, 
					String.format("RCO退单流程处理-退单逻辑异常:订单商品数量:%d, 提奖金额:%d", init_buyNum, init_award), 
					ProblemEnum.CODE_118);
			return false;
		}
		if(init_buyNum < will_buyNum) {
			error_str = String.format("RCO退单流程处理-匹配有效数据[失败], orderId:%s, 原因:[订单]商品数量 < [退单]商品数量", 
					calcResult.getOrderId());
			log.info(error_str);
			this.addProblem(calcResult, "RCO退单流程处理-退单逻辑异常:订单商品数量 < 退单商品数量", ProblemEnum.CODE_118);
			return false;
		}
		return true;
	}

	/**
	 * 拷贝result字段, 到record表中, 并加入id生成器, 作为插入新的数据使用
	 *
	 * @return
	 */
	private CalcRecord cpInsertRecord(CalcResult result, OrderCalcDto orderCalcDto,
			long awardAmount, long buynum) {
		CalcRecord crd = new CalcRecord();
		Long calcRecordId = seqGenUtil.nextCrpCalcRecordId();	// 加入id生成器
		crd.setId(calcRecordId);
		crd.setDeliveryId(orderCalcDto.getDeliveryId());
		crd.setDetailId(orderCalcDto.getDetailId());
		crd.setOrderId(orderCalcDto.getOrderId());
		crd.setOrderDate(orderCalcDto.getOrderDate());
		crd.setSapDetailId(orderCalcDto.getSapDetailId());
		crd.setSkuNo(orderCalcDto.getSkuNo());
		crd.setReturnOrderId(orderCalcDto.getReturnOrderId());
		crd.setAward(-awardAmount);
		crd.setBuyNum(buynum);
		crd.setGomeStatus(BaseConstants.ORDER_RCO_STATUS);	// RCO
		// returnOrder msg
		crd.setOrderSubmitTime(result.getOrderSubmitTime());
		crd.setCalcResultId(result.getId() + "");
		return crd;
	}
	

	/**
	 * 封装结算对象
	 *
	 * @param source
	 * @param returnOrderId
	 * @param retreatAwardAmount 负值
	 * @param will_divided_buyNum 
	 * @return
	 */
	public SaReverseOrderDto cpSaReverseOrderDto(CalcResult source, String returnOrderId, BigDecimal retreatAwardAmount, int will_divided_buyNum) {
		SaReverseOrderDto target = new SaReverseOrderDto();
		target.setAwardAmount(retreatAwardAmount.longValue()); // negative 负值
		target.setUserId(source.getUserId());
		target.setStaffCode(source.getStaffCode());
		target.setStaffClass(source.getStaffClass());
		target.setScenes(source.getScenes());
		target.setCalcResultId(source.getId());
		target.setReverseOrderId(returnOrderId);
		target.setReverseNum(Long.valueOf(will_divided_buyNum));
		target.setIsOffset(source.getIsOffset());
		target.setExpencesOfferType(source.getExpencesOfferType());
		return target;
	}
	
	
    /**
     * 
     * @param calcResult
     * @param msgId
     * @param will_divided_buyNum
     * @param will_divided_award
     * @return
     */
    private CalcResult setSapResult(CalcResult calcResult, Long msgId, int will_divided_buyNum, Long will_divided_award) {
    	CalcResult bo = new CalcResult();
		BeanUtils.copyProperties(calcResult, bo);
		bo.setId(msgId);	// 防重幂等
		bo.setBuyNum(will_divided_buyNum);
		bo.setAwardAmount(will_divided_award);	// 正直
		return bo;
    }
    
    
	
    /**
     * 大数据信息处理dto
     * @param calcResult
     * @param will_divided_buyNum
     * @param will_divided_award
     * @return
     */
    private CalcResult bigDataResultDto(CalcResult calcResult, int will_divided_buyNum, long will_divided_award) {
    	CalcResult bo = new CalcResult();
		BeanUtils.copyProperties(calcResult, bo);
		bo.setBuyNum(will_divided_buyNum);
		bo.setAwardAmount(-will_divided_award);	// 正直
		bo.setJobStatus(null);
		bo.setGomeStatus(BaseConstants.ORDER_RCO_STATUS);
		return bo;
    }

    // 大数据同步是, 推送返利入账信息
    private CalcResult getRebateBillMQ(CalcResult source, long will_sub_award){
		CalcResult ret = new CalcResult();
		ret.setId(source.getId());
		ret.setScenes(source.getScenes());
		ret.setOrderId(source.getOrderId());
		ret.setSkuNo(source.getSkuNo());
		ret.setSkuId(source.getSkuId());
		ret.setAwardAmount(will_sub_award);
		ret.setProfileId(source.getProfileId());
		ret.setUserId(source.getUserId());
		ret.setOrderSubmitTime(source.getOrderSubmitTime());
		ret.setSkuName(source.getSkuName());
		ret.setGomeStatus(source.getGomeStatus());
		ret.setJobStatus(source.getJobStatus());
		ret.setRebateAccountType(source.getRebateAccountType());
		ret.setChannel(source.getChannel());
    	return ret;
	}


//    // 保存计算公式履历结果数据
//    private void saveRewardsRecord(List<CalcResultReward> calcResultRewardLisst){
//		calcRewardsService.addBatchCommit(calcResultRewardLisst);
//	}


    
}
