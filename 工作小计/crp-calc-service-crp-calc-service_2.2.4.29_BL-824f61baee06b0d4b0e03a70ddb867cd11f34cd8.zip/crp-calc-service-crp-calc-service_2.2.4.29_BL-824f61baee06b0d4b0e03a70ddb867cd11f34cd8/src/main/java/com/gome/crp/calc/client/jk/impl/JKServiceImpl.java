package com.gome.crp.calc.client.jk.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.jk.IJKService;
import com.gome.crp.calc.constants.JKErrorCodeEnum;
import com.gome.crp.calc.dto.jkDto.QueryShareUserReqDto;
import com.gome.crp.calc.dto.jkDto.QueryShareUserResDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.memberJikeES.facade.IJikeActivityFacade;
import com.gome.memberJikeEs.model.ResultDTO;
import com.gome.memberJikeEs.model.TicketItemRDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
public class JKServiceImpl implements IJKService {
    @Value("${system.id}")
    private String systemId;
    @Autowired
    private IJikeActivityFacade iJikeActivityFacade;

    @Override
    public QueryShareUserResDto queryShareUser(QueryShareUserReqDto reqDto) {
        if (reqDto == null || reqDto.getUserId() == null || reqDto.getActivityId() == null || reqDto.getOrderDate() == null) {
            throw new IllegalArgumentException("调用集客系统-入参错误");
        }

        try {
            reqDto.setInvokeFrom(systemId);
            reqDto.setTxId(UUID.randomUUID().toString());
            log.info("调用集客系统-查询分享人接口开始userId:{},reqDto:{}", reqDto.getUserId(), reqDto);
            ResultDTO<TicketItemRDTO> result = iJikeActivityFacade.getTicketInfoByOrder(reqDto.getTxId(), reqDto.getInvokeFrom(), reqDto.getActivityId(), reqDto.getUserId(), reqDto.getOrderDate());
            log.info("调用集客系统-查询分享人接口完成userId:{},reqDto:{},result:{}", reqDto.getUserId(), reqDto, JSON.toJSONString(result));

            QueryShareUserResDto resDto = new QueryShareUserResDto();
            if (result.isSuccess()) {
                TicketItemRDTO data = result.getData();
                if (data != null) {
                    resDto.setStaffCode(data.getStaffId());
                    resDto.setIsSham(data.getIsSham());
                }
                return resDto;
            }

            //返回的错误码判断
            if (JKErrorCodeEnum.CODE_301.getCode().equals(result.getErrMsg()) ||
                    JKErrorCodeEnum.CODE_401.getCode().equals(result.getErrMsg()) ||
                    JKErrorCodeEnum.CODE_402.getCode().equals(result.getErrMsg()) ||
                    JKErrorCodeEnum.CODE_500.getCode().equals(result.getErrMsg())) {
                throw new BusinessException(String.format("调用集客系统-查询分享人接口失败userId:%s,reqDto:%s,result:%s", reqDto.getUserId(), JSON.toJSONString(reqDto), JSON.toJSONString(result)));
            } else {
                return resDto;
            }

        } catch (Exception e) {
            log.error("调用集客系统-查询分享人接口异常userId:{},reqDto:{}", reqDto.getUserId(), reqDto, e);
            throw new BusinessException(String.format("调用集客系统-查询分享人接口异常userId:%s,reqDto:%s", reqDto.getUserId(), JSON.toJSONString(reqDto)), e);
        }
    }
}