package com.gome.crp.calc.mybatis.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.SapAccountMapper;
import com.gome.crp.calc.mybatis.model.SapAccount;
import com.gome.crp.calc.mybatis.service.ISapAccountService;
import org.springframework.stereotype.Service;

@Service
public class SapAccountServiceImpl extends ServiceImpl<SapAccountMapper, SapAccount> implements ISapAccountService {
}
