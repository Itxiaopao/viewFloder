package com.gome.crp.calc.client.receiver;

import java.util.List;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.Receiver;

/**
 * IM服务
 *
 */
public interface ILarkService {

    /**
     * 查询近7天国美会员的IM服务记录
     * https://www.kdocs.cn/l/cbS2U9w0u
     *
     * @param orderDto
     * @return
     */
    List<Receiver> queryReceiverList(OrderCalcDto orderDto);
    


}
