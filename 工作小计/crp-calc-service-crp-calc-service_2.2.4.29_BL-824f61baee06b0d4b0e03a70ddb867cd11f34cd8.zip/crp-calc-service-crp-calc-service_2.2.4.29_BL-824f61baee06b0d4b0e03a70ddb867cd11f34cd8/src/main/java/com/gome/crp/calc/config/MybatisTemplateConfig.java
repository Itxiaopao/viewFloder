package com.gome.crp.calc.config;
//package com.gome.crp.calc.service.config;
//
//import org.apache.ibatis.session.ExecutorType;
//import org.apache.ibatis.session.SqlSessionFactory;
//import org.mybatis.spring.SqlSessionTemplate;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.Primary;
//
///**
// * 配置mybatis 模板执行器
// * 主要是加入batch template 方便对批量更新、插入等操作支持原生的jdbc batch操作
// * 修改mybatis默认使用的 simple执行器，改为reuse执行器
// *
// * 在使用batch 模板时,需要注意操作必须在同一个事物中
// * 在同一个事物中如果同时用到了两个模板引擎那么会发生一个spring的事物异常，这里需要注意
// * @author lisuo
// *
// */
//@Configuration
//public class MybatisTemplateConfig {
//
//	@Autowired
//	private SqlSessionFactory sqlSessionFactory;
//
//	@Bean("batchSqlSessionTemplate")
//	public SqlSessionTemplate batchSqlSessionTemplate() {
//		SqlSessionTemplate batchSqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory, ExecutorType.BATCH);
//		return batchSqlSessionTemplate;
//	}
//
//	/**
//	 * 放弃默认的simple执行引
//	 * 默认使用Pscache引擎（缓存preparedstatement），相同的sql不会创建多个statement
//	 * @return
//	 */
//	@Primary
//	@Bean("reuseSqlSessionTemplate")
//	public SqlSessionTemplate reuseSqlSessionTemplate() {
//		SqlSessionTemplate batchSqlSessionTemplate = new SqlSessionTemplate(sqlSessionFactory, ExecutorType.REUSE);
//		return batchSqlSessionTemplate;
//	}
//}
