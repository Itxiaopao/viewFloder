package com.gome.crp.calc.mybatis.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.EmployeeAttendanceMapper;
import com.gome.crp.calc.mybatis.model.EmployeeAttendance;
import com.gome.crp.calc.mybatis.service.IEmployeeAttendanceService;
import org.springframework.stereotype.Service;

@Service
public class EmployeeAttendanceServiceImpl extends ServiceImpl<EmployeeAttendanceMapper, EmployeeAttendance> implements IEmployeeAttendanceService {
}
