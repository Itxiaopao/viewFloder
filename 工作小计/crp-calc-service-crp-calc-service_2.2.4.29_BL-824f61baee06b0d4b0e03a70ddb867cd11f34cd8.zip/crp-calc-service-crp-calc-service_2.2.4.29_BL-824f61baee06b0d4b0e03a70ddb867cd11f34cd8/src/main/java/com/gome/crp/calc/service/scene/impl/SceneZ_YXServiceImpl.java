package com.gome.crp.calc.service.scene.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.userLink.IUserLink;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.scene.abstr.AbstractSceneService;
import com.gome.crp.calc.service.scene.abstr.AbstractYXSceneService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * z场景-YX
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class SceneZ_YXServiceImpl extends AbstractYXSceneService {

	@Autowired
	IUserLink iUserLink;
	@Autowired
	private IStaffInfoService staffInfoService;
	@Autowired
	private IProblemService problemService;

	@Override
	public List<ProfitDto> calc(OrderCalcDto orderDto, PlanDto planDto) {
		List<ProfitDto> list = null;
		String sceneZ = BaseConstants.SCENE_Z;
		boolean checPlanCanCalc = this.checkPlanCanCalc(orderDto, planDto, sceneZ);
		if(!checPlanCanCalc) {
			return list;
		}
		List<PersonDto> personList = this.getProfitPerson(orderDto, planDto);
		if(personList != null && personList.size() > 0) {
			int size = personList.size();
			list = new ArrayList<>(size);
			List<BigDecimal> formula = super.sceneFormula(orderDto, planDto, size, sceneZ);
			int i = 0;
			for (PersonDto personDto : personList) {
				ProfitDto profit = new ProfitDto();
				profit.setPersonDto(personDto);
				profit.setScenes(sceneZ);
				profit.setAwardAmount(formula.get(i));
				i++;
				list.add(profit);
			}
			this.addRewardCommit(orderDto, planDto, list, sceneZ);
		} else {
			log.info(String.format("[Warn]Z-YX场景获利人:null, orderId:%s, planId:%d", orderDto.getOrderId(), planDto.getPlanId()));
			addProblem(orderDto, planDto, "Z-YX场景获利人:null", ProblemEnum.CODE_124);
		}
		log.info(String.format("Z-YX场景获利人最终提奖金额分配[END], order:%s, plan:%d, 结果:%s",
				orderDto.getOrderId(), planDto.getPlanId(), JSONObject.toJSONString(list)));
		return list;
	}

	@Override
	public List<PersonDto> getProfitPerson(OrderCalcDto orderDto, PlanDto planDto) {
		String orderId = orderDto.getOrderId();
		String paramuserId = orderDto.getUserId();
		String res_userId = iUserLink.selLinkUser(paramuserId);
		log.info(String.format("Z-YX场景查询获利人-员工关系查询, orderId:%s, userId:%s, 查询的userId结果:%s", orderId, paramuserId, res_userId));
		List<PersonDto> personDtos = null;
		if (StringUtils.isNotEmpty(res_userId)) {
			personDtos = new ArrayList<>();
			EmployeeInfoDto empl = staffInfoService.getEmployeeDtoByUserId(res_userId);
			log.info(String.format("Z-YX场景查询获利人-员工查询, orderId:%s, userId:%s, 结果:%s", orderId, res_userId, JSONObject.toJSONString(empl)));
			PersonDto personDto = null;
			if(empl != null) {
				personDto = this.copyProperies(empl, orderDto.getShopNo(), orderDto.getSupplier(), res_userId, null,ProfitBehaviorEnum.SUPERIOR_STAFF.getCode());
				personDtos.add(personDto);
			}else {
				personDto = new PersonDto();
				personDto.setUserId(res_userId);
				personDto.setProfitBehaviorCode(ProfitBehaviorEnum.SUPERIOR_STAFF.getCode());
				personDtos.add(personDto);
			}
		}
		log.info(String.format("Z-YX获利人查询结果[end], orderId:%s, 列表:%s", orderId, JSONObject.toJSONString(personDtos)));
		return personDtos;
	}

	@Override
	public String getScene() {
		return BaseConstants.SCENE_Z;
	}

}
