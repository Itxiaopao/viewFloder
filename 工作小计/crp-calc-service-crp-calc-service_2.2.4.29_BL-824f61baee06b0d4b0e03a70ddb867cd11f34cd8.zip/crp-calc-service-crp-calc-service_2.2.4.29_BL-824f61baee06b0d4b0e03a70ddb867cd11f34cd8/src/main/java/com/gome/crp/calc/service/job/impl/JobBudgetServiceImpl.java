package com.gome.crp.calc.service.job.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.service.budget.IBudgetService;
import com.gome.crp.calc.service.job.IJobBudgetService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class JobBudgetServiceImpl implements IJobBudgetService {
    private static final int PAGE_SIZE = 500;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private IBudgetService iBudgetService;
//    @Autowired
//    private IBillService iBillService;
//    @Autowired
//    private JobBudgetManager jobBudgetManager;

    @Override
    public void occupyBudget() {
//    	// libinbin9 develop
//        long startTime = System.currentTimeMillis();
//        log.info("定时任务-占用预算-执行开始");
//
//        //幂等校验
//        String cronJobBudgetOccupyLock = CacheKeyConstants.getCronJobBudgetOccupyLock();
//        try {
//            Long value = gcacheUtil.distributedLockAtom(cronJobBudgetOccupyLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
//            if (value == 1) {
//                //获取数据当前处理位置
//                String cronJobBudgetOccupyIdIndex = CacheKeyConstants.getCronJobBudgetOccupyIdIndex();
//                Long idIndex = 0L;
//                String keyValue = gcacheUtil.getKeyValue(cronJobBudgetOccupyIdIndex);
//                if (keyValue != null) {
//                    idIndex = Long.valueOf(keyValue);
//                }
//
//                //查询PAGE_SIZE条数据（job节点-预算校验,预算状态-未校验）
//                List<CalcResult> records = selectCalcResults(idIndex);
//
//                //更新数据下次处理位置
//                if (CollectionUtils.isEmpty(records) || records.size() < PAGE_SIZE) {
//                    gcacheUtil.putKeyValue(cronJobBudgetOccupyIdIndex, "0");
//                } else {
//                    CalcResult detail = records.get(records.size() - 1);
//                    gcacheUtil.putKeyValue(cronJobBudgetOccupyIdIndex, String.valueOf(detail.getId()));
//                }
//
//                if (!CollectionUtils.isEmpty(records)) {
//                    //sap挂账
//                    List<SapRecord> sapRecords = iBillService.applyJobStatusBill(records, BaseConstants.CRD_JOB_STATUS_2);
//                    //占用预算 + bigData + job异常->4
//                    List<CalcResult> updateCalcResults = iBudgetService.occupyBudget(records);
//                    //批量更新处理结果
//                    jobBudgetManager.doUpdateCalcResultStatus(updateCalcResults, sapRecords);
//                }else {
//                	log.info(String.format("占用预算-查询数据结果为null, idIndex:%d", idIndex));
//                }
//            }
//
//            log.info("定时任务-占用预算-处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
//        } catch (Exception e) {
//            log.error("定时任务-占用预算-处理异常", e);
//        } finally {
//            try {
//                gcacheUtil.deleteKey(new String[]{cronJobBudgetOccupyLock});
//            } catch (Exception ex) {
//                log.error("定时任务-删除占用预算防重键异常cronJobBudgetOccupyLock:{}", cronJobBudgetOccupyLock, ex);
//            }
//        }
    }
    
    @Override
    public void occupyBudget1() {
    	// libinbin9 develop
        long startTime = System.currentTimeMillis();
        log.info("定时任务-job1[1->2]占用预算-执行开始");

        //幂等校验
        String cronJob1BudgetOccupyLock = CacheKeyConstants.getCronJob1BudgetOccupyLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJob1BudgetOccupyLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobBudgetOccupyIdIndex = CacheKeyConstants.getCronJobBudgetOccupyIdIndex();
                Long idIndex = 0L;
                String keyValue = gcacheUtil.getKeyValue(cronJobBudgetOccupyIdIndex);
                if (keyValue != null) {
                    idIndex = Long.valueOf(keyValue);
                }

                //查询PAGE_SIZE条数据（job节点-预算校验,预算状态-未校验）
                List<CalcResult> records = selectCalcResultsJob1(idIndex);

                //更新数据下次处理位置
                if (CollectionUtils.isEmpty(records) || records.size() < PAGE_SIZE) {
                    gcacheUtil.putKeyValue(cronJobBudgetOccupyIdIndex, "0");
                } else {
                    CalcResult detail = records.get(records.size() - 1);
                    gcacheUtil.putKeyValue(cronJobBudgetOccupyIdIndex, String.valueOf(detail.getId()));
                }

                if (!CollectionUtils.isEmpty(records)) {
                    iBudgetService.occupyBudgetUncheckedDLOrCO(records);
                }else {
                	log.info(String.format("占用预算-job1[1->2]查询数据结果为null, idIndex:%d", idIndex));
                }
            }
            log.info("定时任务-job1[1->2]占用预算-处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-job1[1->2]占用预算-处理异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJob1BudgetOccupyLock});
            } catch (Exception ex) {
                log.error("定时任务-job1[1->2]删除占用预算防重键异常cronJob1BudgetOccupyLock:{}", cronJob1BudgetOccupyLock, ex);
            }
        }
    }
    
    
    @Override
    public void occupyBudget2() {
    	// libinbin9 develop
        long startTime = System.currentTimeMillis();
        log.info("定时任务-job2[1->2]占用预算-执行开始");

        //幂等校验
        String cronJob2BudgetOccupyLock = CacheKeyConstants.getCronJob2BudgetOccupyLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJob2BudgetOccupyLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobBudgetOccupyIdIndex = CacheKeyConstants.getCronJobBudgetOccupyIdIndex();
                Long idIndex = 0L;
                String keyValue = gcacheUtil.getKeyValue(cronJobBudgetOccupyIdIndex);
                if (keyValue != null) {
                    idIndex = Long.valueOf(keyValue);
                }

                //查询PAGE_SIZE条数据（job节点-预算校验,预算状态-未校验）
                List<CalcResult> records = selectCalcResultsJob2(idIndex);

                //更新数据下次处理位置
                if (CollectionUtils.isEmpty(records) || records.size() < PAGE_SIZE) {
                    gcacheUtil.putKeyValue(cronJobBudgetOccupyIdIndex, "0");
                } else {
                    CalcResult detail = records.get(records.size() - 1);
                    gcacheUtil.putKeyValue(cronJobBudgetOccupyIdIndex, String.valueOf(detail.getId()));
                }

                if (!CollectionUtils.isEmpty(records)) {
                    //占用预算 + bigData + job异常->4
                    iBudgetService.occupyBudgetHaveNoLetterY(records);
                    //批量更新处理结果
                }else {
                	log.info(String.format("占用预算-job2[1->2]查询数据结果为null, idIndex:%d", idIndex));
                }
            }

            log.info("定时任务-job2[1->2]占用预算-处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-job2[1->2]占用预算-处理异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJob2BudgetOccupyLock});
            } catch (Exception ex) {
                log.error("定时任务-job2[1->2]删除占用预算防重键异常cronJob2BudgetOccupyLock:{}", cronJob2BudgetOccupyLock, ex);
            }
        }
    }

    String [] colum1 = {
                        "id", "order_id", "plan_id", "award_amount",
                        "job_status", "budget_status", "contract_type", "is_receipt_goods",
                        "surplus_amount", "scenes", "promotions_type", "expences_offer_type",
                        "gome_status", "version",
                        };

    // job1 job预算校验节点, 预算:未校验, CO,DL
    private List<CalcResult> selectCalcResultsJob1(Long idIndex){
    	// 费用承担方
        Page<CalcResult> page = new Page<>();
        page.setSearchCount(false);
        page.setSize(PAGE_SIZE);
        CalcResult query = new CalcResult();
        query.setBudgetStatus(BaseConstants.BUDGET_UNCHECKED);
        query.setJobStatus(BaseConstants.CRD_JOB_STATUS_1);
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
        queryWrapper.orderByAsc("id");
        queryWrapper.in("gome_status", BaseConstants.ORDER_DL_STATUS, BaseConstants.ORDER_CO_STATUS);
        queryWrapper.gt("id", idIndex);
        queryWrapper.select(colum1);
        Page<CalcResult> calcResultDetailPage = calcResultMapper.selectPage(page, queryWrapper);
        return calcResultDetailPage.getRecords();
    }

    // 大数据应用字段比较多
    String[] colums2 = {
                        "id", "order_id", "plan_id", "award_amount",
                        "job_status", "contract_type", "budget_status", "is_receipt_goods",
                        "commerce_item_id", "delivery_id", "detail_id", "gome_status",
                        "channel", "sales_model", "sap_detail_id", "shop_no", "order_submit_time",
                        "staff_code", "user_id", "plan_id", "scenes", "update_time", "surplus_amount",
                        "promotions_type", "expences_offer_type", "version",
                        "sku_no", "sku_id", "sku_name",
                        "profile_id", "user_id", "profit_behavior", "pay_date",
                        };

    // job2 job:预算校验节点, 预算:校验成功
    private List<CalcResult> selectCalcResultsJob2(Long idIndex){
    	// 无函Y
        Page<CalcResult> page = new Page<>();
        page.setSearchCount(false);
        page.setSize(PAGE_SIZE);
        CalcResult query = new CalcResult();
        query.setBudgetStatus(BaseConstants.BUDGET_CHECK_SUCCESS);
        query.setJobStatus(BaseConstants.CRD_JOB_STATUS_1);
        // 确认收货标示
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
        queryWrapper.orderByAsc("id");
        queryWrapper.gt("id", idIndex);
        queryWrapper.select(colums2);
        Page<CalcResult> calcResultDetailPage = calcResultMapper.selectPage(page, queryWrapper);
        return calcResultDetailPage.getRecords();
    }


}
