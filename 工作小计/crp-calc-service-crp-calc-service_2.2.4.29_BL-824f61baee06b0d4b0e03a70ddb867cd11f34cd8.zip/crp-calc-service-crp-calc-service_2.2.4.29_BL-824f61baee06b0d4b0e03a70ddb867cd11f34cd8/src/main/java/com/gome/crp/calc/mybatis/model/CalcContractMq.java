package com.gome.crp.calc.mybatis.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import lombok.Data;

@Data
public class CalcContractMq {
	@TableId(type = IdType.INPUT)
	private Long id; //id
	private String sapDetailId;//sapDetailId
    private String msgId;//消息Id
    private String msgBody;//消息体
	private String ipAddress;//ip地址
}
