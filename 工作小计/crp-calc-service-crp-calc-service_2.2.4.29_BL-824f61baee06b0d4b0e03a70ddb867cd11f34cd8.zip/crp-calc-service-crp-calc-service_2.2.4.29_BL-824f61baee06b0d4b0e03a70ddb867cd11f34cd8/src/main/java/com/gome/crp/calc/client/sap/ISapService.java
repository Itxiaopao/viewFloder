package com.gome.crp.calc.client.sap;


import com.gome.crp.calc.dto.sapDto.ApplyBillReqDto;
import com.gome.crp.calc.dto.sapDto.ApplyBillResDto;
import com.gome.crp.calc.dto.sapDto.QueryPurchaseCodeReqDto;
import com.gome.crp.calc.dto.sapDto.QueryPurchaseCodeResDto;

/**
 * sap接口
 */
public interface ISapService {

    /**
     * 挂账或冲账
     * 挂账（取消标识qxbs为N，发放金额dmbtr1为正数）
     * 冲账（取消标识qxbs为X，发放金额dmbtr1为负数）
     *
     * @param reqDto
     * @return
     */
    ApplyBillResDto applyBill(ApplyBillReqDto reqDto);

    /**
     * 逻辑dc查询采购组织
     *
     * @param reqDto
     * @return
     */
    QueryPurchaseCodeResDto queryPurchaseCode(QueryPurchaseCodeReqDto reqDto);
}
