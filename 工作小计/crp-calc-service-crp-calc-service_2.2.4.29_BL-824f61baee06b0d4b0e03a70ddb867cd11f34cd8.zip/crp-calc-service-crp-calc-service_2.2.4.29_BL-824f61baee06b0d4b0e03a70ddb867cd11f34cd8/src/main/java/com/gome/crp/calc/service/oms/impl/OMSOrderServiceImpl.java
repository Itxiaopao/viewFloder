package com.gome.crp.calc.service.oms.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.cpqs.model.CommissionPlanQueryResp;
import com.gome.crp.calc.client.sap.IQueryPlanService;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.dto.contractDto.CalcContractDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.manager.OrderCalcMsgManager;
import com.gome.crp.calc.manager.contract.CalcContractManager;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.mapper.CalcResultRepeatMapper;
import com.gome.crp.calc.mybatis.mapper.OrderCalcMsgMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcResultRepeat;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.mybatis.model.OrderCalcMsg;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.calc.service.order.IOrderStatusHandlerService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.util.AddressUtil;
import com.gome.crp.calc.util.BigDecimalUtils;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import com.gome.crp.order.calc.dto.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
public class OMSOrderServiceImpl implements IOMSOrderService {
    @Autowired
    private OrderCalcMsgMapper orderCalcMsgMapper;
    @Autowired
    private SeqGenUtil seqGenUtil;
    @Autowired
    private OrderCalcMsgManager orderCalcMsgManager;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private IProblemService iProblemService;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;
    @Autowired
    private CalcResultRepeatMapper calcResultRepeatMapper;
    @Autowired
    private RedisLockHelper redisLockHelper;
    @Autowired
    private IOrderStatusHandlerService orderHandlerService;
    @Autowired
    private CalcContractManager calcContractManager;
    @Autowired
    private CalcResultMapper calcResultMapper;
    
    @Autowired
    private IQueryPlanService iQueryPlanService;

    @Override
    public List<OrderCalcMsg> matchOrderInfo(String saleChannel, String sapDetailId) {
        log.info("处理关系匹配入参 saleChannel is {} ,sapDetailId is {}", saleChannel, sapDetailId);
        OrderCalcMsg entity = new OrderCalcMsg();
        entity.setChannel(saleChannel);
        entity.setSapDetailId(sapDetailId);
        entity.setGomeStatus(BaseConstants.ORDER_CO_STATUS);
        OrderCalcMsg one = orderCalcMsgMapper.selectOne(Wrappers.query(entity));
        if (one == null) {
            log.error("处理关系匹配入参 saleChannel is {} ,sapDetailId is {} 查询不到数据", saleChannel, sapDetailId);
            return Collections.emptyList();
        }
        QueryWrapper<OrderCalcMsg> q = Wrappers.query();
        q.eq("order_id", one.getOrderId()).eq("sku_no", one.getSkuNo())
                .eq("detail_id", one.getDetailId()).eq("channel", one.getChannel())
                .eq("status", StatusEnum.UN_TREATED.getCode())
                .orderByAsc("order_date");
        List<OrderCalcMsg> list = orderCalcMsgMapper.selectList(q);
        return list;
    }

    @Override
    public void handler(OrderDto orderDto) {
        //订单数据格式转换
        List<OrderCalcDto> orderCalcDtos = transferOrderCalcDto(orderDto);
        if (orderCalcDtos != null) {
            dealOrderDetail(orderCalcDtos);
        }
    }

    private void dealOrderDetail(List<OrderCalcDto> orderCalcDtos) {
        for (OrderCalcDto orderCalcDto : orderCalcDtos) {
            long startTime = System.currentTimeMillis();
            log.info("detail级提成计算开始, 时间: {}", startTime);

            //订单幂等校验
            String orderUniqueKey = CacheKeyConstants.getOrderUniqueKey(orderCalcDto);
            try {
                log.info("detail级提成计算开始, orderId: {}, deliveryId: {}, skuNo: {}, detailId: {}, orderUniqueKey:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId(), orderUniqueKey, orderCalcDto);

                Long value = gcacheUtil.distributedLockAtom(orderUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
                if (value == 1L) {
                    //防重
                    try {
                        CalcResultRepeat calcResultRepeat = getCalcResultRepeat(orderCalcDto);
                        calcResultRepeatMapper.insert(calcResultRepeat);
                    } catch (DuplicateKeyException e) {
                        log.error("detail级提成计算被防重, orderId: {}, deliveryId: {}, skuNo: {}, detailId: {}, orderUniqueKey:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId(), orderUniqueKey, orderCalcDto, e);
                        gcacheUtil.distributedLockAtom(orderUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
                        continue;
                    }

                    //订单预计算
                    String orderDetailLock = CacheKeyConstants.getOrderDetailLock(orderCalcDto.getOrderId(), orderCalcDto.getChannel(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
                    RedisLock redisLock = redisLockHelper.getLock(orderDetailLock);
                    if (!redisLock.lock()) {
                        log.error("detail级提成计算加锁失败orderId:{},orderDetailLock:{}", orderCalcDto.getOrderId(), orderDetailLock);
                        throw new BusinessException(String.format("detail级提成计算加锁失败orderId:%s,orderDetailLock:%s", orderCalcDto.getOrderId(), orderDetailLock));
                    }

                    try {
                        calcOrderProxy(orderCalcDto);
                    } finally {
                        redisLock.unlock();
                    }

                } else {
                    log.info("幂等性校验失败");
                }

                log.info("detail级提成计算结束, orderId: {}, deliveryId: {}, skuNo: {}, detailId: {}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
            } catch (Exception e) {
                log.error("detail级提成计算失败, 错误信息: ", e);
                try {
                    // 问题小工具
                    iProblemService.addData(orderCalcDto, null, null, orderCalcDto.getOrderId(), ProblemEnum.CODE_113);
                    // 失败重试
                    CalcRetry calcRetry = new CalcRetry();
                    calcRetry.setType(RetryJobEnum.ORDERCALC.getCode());
                    calcRetry.setOrderId(orderCalcDto.getOrderId());
                    calcRetry.setSapDetailId(orderCalcDto.getSapDetailId());
                    calcRetry.setMsgBody(JSON.toJSONString(orderCalcDto));
                    calcRetry.setGomeStatus(orderCalcDto.getGomeState());
                    calcRetry.setFailureReason(e.getMessage());
                    calcRetryCopeService.insertRetry(calcRetry);
                } catch (Exception e1) {
                    log.error("提成计算插入问题小工具或插入失败重试失败，错误信息：", e1);
                }
            } finally {
                CalcLocal.removeLocalDto();
                log.info("detail级提成计算结束, 耗时: {}", System.currentTimeMillis() - startTime);
            }
        }
    }

    private CalcResultRepeat getCalcResultRepeat(OrderCalcDto orderCalcDto) {
        CalcResultRepeat calcResultRepeat = new CalcResultRepeat();
        calcResultRepeat.setOrderId(orderCalcDto.getOrderId());
        calcResultRepeat.setGomeStatus(orderCalcDto.getGomeState());
        calcResultRepeat.setSkuNo(orderCalcDto.getSkuNo());
        calcResultRepeat.setDetailId(orderCalcDto.getDetailId());
        calcResultRepeat.setChannel(orderCalcDto.getChannel());
        String returnOrderId = "";
        if (BaseConstants.ORDER_RCO_STATUS.equals(orderCalcDto.getGomeState())) {
            returnOrderId = orderCalcDto.getReturnOrderId();
        }
        calcResultRepeat.setReturnOrderId(returnOrderId);
        return calcResultRepeat;
    }

    @Override
    public void calcOrderProxy(OrderCalcDto orderCalcDto) {
        //O2O订单
        if (BaseConstants.ORDER_CHANNEL_O2O.equals(orderCalcDto.getChannel()) || Integer.valueOf(BaseConstants.ORDER_YB_WARRANTY_FLAG_1).equals(orderCalcDto.getWarrantyFlag())) {
            //计算逻辑
        	orderCalcDto.setCalcLogic("A");
            orderHandlerService.calcOrder(orderCalcDto);
            return;
        }
    	//过滤订单是否营销推广
    	int isYX = ifYxOrder(orderCalcDto);
    	orderCalcDto.setIsYX(isYX);
        //营销推广 （oms计算+so计算）
        if(BaseConstants.ORDER_YX_STATUS_1 == orderCalcDto.getIsYX()){
        	orderCalcDto.setCalcLogic("A");
        	orderHandlerService.calcOrder(orderCalcDto);
        	orderCalcDto.setIsYX(BaseConstants.ORDER_YX_STATUS_0);
        }
        orderCalcDto.setCalcLogic("B");
        //货到付款-兼容旧代码
        if (OrderTypeEnum.CASH_ON_DELIVERY.getCode().equals(orderCalcDto.getOrderType()) &&
                !BaseConstants.ORDER_CO_STATUS.equals(orderCalcDto.getGomeState())) {
            OrderCalcMsg coOrderCalcMsg = getCOOrderCalcMsg(orderCalcDto);
            if (coOrderCalcMsg == null) {
                if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())) {
                    CalcContractDto calcContractDto = calcContractManager.getContractDtoBySapDetailId(orderCalcDto.getSapDetailId());
                    if (calcContractDto == null) {
                        OrderCalcMsg unTreatedOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.UN_TREATED.getCode(), null);
                        orderCalcMsgMapper.insert(unTreatedOrder);
                    } else {
                        //DL计算逻辑
                        orderHandlerService.calcOrder(orderCalcDto);
                        OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                        orderCalcMsgMapper.insert(finishedProcessOrder);
                    }
                    return;
                }

                if (BaseConstants.ORDER_CL_STATUS.equals(orderCalcDto.getGomeState()) ||
                        BaseConstants.ORDER_RT_STATUS.equals(orderCalcDto.getGomeState())) {
                    //CL/RT计算逻辑
                    orderHandlerService.calcOrder(orderCalcDto);
                    OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                    orderCalcMsgMapper.insert(finishedProcessOrder);
                    return;
                }

                if (BaseConstants.ORDER_RCO_STATUS.equals(orderCalcDto.getGomeState())) {
                    OrderCalcMsg dlOrderCalcMsg = getDLOrderCalcMsg(orderCalcDto);
                    if (dlOrderCalcMsg == null) {
                        //RCO计算逻辑
                        orderHandlerService.calcOrder(orderCalcDto);
                        OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                        orderCalcMsgMapper.insert(finishedProcessOrder);
                    } else {
                        if (StatusEnum.UN_TREATED.getCode().equals(dlOrderCalcMsg.getStatus())) {
                            OrderCalcMsg unTreatedOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.UN_TREATED.getCode(), null);
                            orderCalcMsgMapper.insert(unTreatedOrder);
                        } else {
                            //RCO计算逻辑
                            orderHandlerService.calcOrder(orderCalcDto);
                            OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                            orderCalcMsgMapper.insert(finishedProcessOrder);
                        }
                    }
                    return;
                }
            }
        }

        //CO订单
        OrderCalcMsg coOrderCalcMsg;
        if (BaseConstants.ORDER_CO_STATUS.equals(orderCalcDto.getGomeState())) {
            //SO订单早于OMS订单消息之前，直接计算
            CalcContractDto calcContractDto = calcContractManager.getContractDtoBySapDetailId(orderCalcDto.getSapDetailId());
            if (calcContractDto != null) {
                orderHandlerService.calcOrder(orderCalcDto);
                OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                orderCalcMsgMapper.insert(finishedProcessOrder);
            } else {
                OrderCalcMsg unTreatedOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.UN_TREATED.getCode(), null);
                orderCalcMsgMapper.insert(unTreatedOrder);
            }
            return;
        } else {
            //查询co订单
            coOrderCalcMsg = getCOOrderCalcMsg(orderCalcDto);
            if (coOrderCalcMsg == null) {
                //兼容旧代码
                CalcResult calcResult = new CalcResult();
                calcResult.setOrderId(orderCalcDto.getOrderId());
                calcResult.setSkuNo(orderCalcDto.getSkuNo());
                calcResult.setDetailId(orderCalcDto.getDetailId());
                calcResult.setChannel(orderCalcDto.getChannel());
                QueryWrapper<CalcResult> queryWrapper = Wrappers.query(calcResult);
                List<CalcResult> calcResults = calcResultMapper.selectList(queryWrapper);
                if (CollectionUtils.isEmpty(calcResults)) {
                    log.error("detail级提成计算撤单-CO单不存在orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), JSON.toJSONString(orderCalcDto));
                    return;
                } else {
                    coOrderCalcMsg = new OrderCalcMsg();
                    coOrderCalcMsg.setStatus(StatusEnum.FINISHED_PROCESSING.getCode());
                }
            }
        }

        //DL/RCO订单
        if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())
                || BaseConstants.ORDER_RCO_STATUS.equals(orderCalcDto.getGomeState())) {
            if (StatusEnum.UN_TREATED.getCode().equals(coOrderCalcMsg.getStatus())) {
                OrderCalcMsg unTreatedOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.UN_TREATED.getCode(), null);
                orderCalcMsgMapper.insert(unTreatedOrder);
            } else {
                //DL/RCO计算逻辑
                orderHandlerService.calcOrder(orderCalcDto);
                OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                orderCalcMsgMapper.insert(finishedProcessOrder);
            }
            return;
        }

        //CL/RT订单
        if (BaseConstants.ORDER_CL_STATUS.equals(orderCalcDto.getGomeState())
                || BaseConstants.ORDER_RT_STATUS.equals(orderCalcDto.getGomeState())) {
            if (StatusEnum.UN_TREATED.getCode().equals(coOrderCalcMsg.getStatus())) {
                OrderCalcMsg updateCOOrderCalcMsg = new OrderCalcMsg();
                updateCOOrderCalcMsg.setId(coOrderCalcMsg.getId());
                updateCOOrderCalcMsg.setStatus(StatusEnum.FINISHED_PROCESSING.getCode());
                updateCOOrderCalcMsg.setProcessNode(ProcessNodeEnum.OMS_NODE.getCode());

                OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                orderCalcMsgManager.doUpdateOrderCalcMsg(finishedProcessOrder, updateCOOrderCalcMsg);
            } else {
                //CL/RT计算逻辑
                orderHandlerService.calcOrder(orderCalcDto);
                OrderCalcMsg finishedProcessOrder = createOrderCalcMsg(orderCalcDto, StatusEnum.FINISHED_PROCESSING.getCode(), ProcessNodeEnum.OMS_NODE.getCode());
                orderCalcMsgMapper.insert(finishedProcessOrder);
            }
        }
    }

    private OrderCalcMsg createOrderCalcMsg(OrderCalcDto orderCalcDto, Integer status, Integer processNode) {
        OrderCalcMsg orderCalcMsg = new OrderCalcMsg();
        orderCalcMsg.setId(seqGenUtil.nextCrpOrderCalcMsgSeq());
        orderCalcMsg.setChannel(orderCalcDto.getChannel());
        orderCalcMsg.setDeliveryId(orderCalcDto.getDeliveryId());
        orderCalcMsg.setDetailId(orderCalcDto.getDetailId());
        orderCalcMsg.setGomeStatus(orderCalcDto.getGomeState());
        orderCalcMsg.setOrderId(orderCalcDto.getOrderId());
        orderCalcMsg.setSapDetailId(orderCalcDto.getSapDetailId());
        orderCalcMsg.setReturnOrderId(orderCalcDto.getReturnOrderId());
        orderCalcMsg.setSkuNo(orderCalcDto.getSkuNo());
        orderCalcMsg.setOrderType(Integer.valueOf(orderCalcDto.getOrderType()));
        orderCalcMsg.setOrderDate(orderCalcDto.getOrderDate());
        if (processNode != null) {
            orderCalcMsg.setProcessNode(processNode);
        }
        orderCalcMsg.setMsgBody(JSON.toJSONString(orderCalcDto));
        orderCalcMsg.setStatus(status);
        String localAddress = AddressUtil.getLocalAddress();
        if (localAddress == null) {
            localAddress = "";
        } else if (localAddress.length() > 40) {
            localAddress = localAddress.substring(0, 40);
        }
        orderCalcMsg.setIpAddress(localAddress);
        return orderCalcMsg;
    }

    private OrderCalcMsg getCOOrderCalcMsg(OrderCalcDto orderCalcDto) {
        OrderCalcMsg query = new OrderCalcMsg();
        query.setOrderId(orderCalcDto.getOrderId());
        query.setGomeStatus(BaseConstants.ORDER_CO_STATUS);
        query.setSkuNo(orderCalcDto.getSkuNo());
        query.setDetailId(orderCalcDto.getDetailId());
        query.setChannel(orderCalcDto.getChannel());
        QueryWrapper<OrderCalcMsg> queryWrapper = Wrappers.query(query);
        return orderCalcMsgMapper.selectOne(queryWrapper);
    }

    private OrderCalcMsg getDLOrderCalcMsg(OrderCalcDto orderCalcDto) {
        OrderCalcMsg query = new OrderCalcMsg();
        query.setOrderId(orderCalcDto.getOrderId());
        query.setGomeStatus(BaseConstants.ORDER_DL_STATUS);
        query.setSkuNo(orderCalcDto.getSkuNo());
        query.setDetailId(orderCalcDto.getDetailId());
        query.setChannel(orderCalcDto.getChannel());
        QueryWrapper<OrderCalcMsg> queryWrapper = Wrappers.query(query);
        return orderCalcMsgMapper.selectOne(queryWrapper);
    }

    @Override
    public List<OrderCalcDto> transferOrderCalcDto(OrderDto orderDto) {
        if (orderDto == null) {
            return Collections.emptyList();
        }

        //订单计算对象集合
        List<OrderCalcDto> orderCalcList = new ArrayList<>();

        //配送单集合
        List<DeliveryDto> deliveryList = orderDto.getDeliveryList();
        if (CollectionUtils.isEmpty(deliveryList)) {
            return Collections.emptyList();
        }

        for (DeliveryDto deliveryDto : deliveryList) {
            //商品集合
            List<GoodsDto> goodsList = deliveryDto.getGoodsList();
            if (CollectionUtils.isEmpty(goodsList)) {
                continue;
            }

            for (GoodsDto goodsDto : goodsList) {
                //业务机型集合
                List<DetailGoodsDto> detailList = goodsDto.getDetailList();
                if (CollectionUtils.isEmpty(detailList)) {
                    continue;
                }

                for (DetailGoodsDto detailGoodsDto : detailList) {
                    //消息订单对象组装成计算对象
                    OrderCalcDto orderCalcDto = getOrderCalcDto(orderDto, deliveryDto, goodsDto, detailGoodsDto);
                    if (orderCalcDto != null) {
                        orderCalcList.add(orderCalcDto);
                    }
                }
            }
        }

        return orderCalcList;
    }

    private OrderCalcDto getOrderCalcDto(OrderDto orderDto, DeliveryDto deliveryDto, GoodsDto goodsDto, DetailGoodsDto detailGoodsDto) {
        OrderCalcDto orderCalcDto = new OrderCalcDto();
        orderCalcDto.setOrderId(orderDto.getOrderId());
        orderCalcDto.setReturnOrderId(orderDto.getReturnOrderId());
        orderCalcDto.setUserId(orderDto.getProfileId());
        orderCalcDto.setUserName(orderDto.getLoginName());
        orderCalcDto.setOrderPrice(BigDecimalUtils.changeY2F(orderDto.getOrderPrice()));
        orderCalcDto.setOrderSalePrice(BigDecimalUtils.changeY2F(orderDto.getOrderSalePrice()));
        orderCalcDto.setSubmittedDate(orderDto.getSubmittedDate());
        orderCalcDto.setPayDate(orderDto.getPayDate());
        orderCalcDto.setOrderType(orderDto.getOrderType());
        orderCalcDto.setCpsId(orderDto.getCpsId());
        orderCalcDto.setRequestHeaderMap(orderDto.getRequestHeaderMap());

        orderCalcDto.setOrderDate(deliveryDto.getOrderDate());
        orderCalcDto.setDeliveryId(deliveryDto.getShippingGroupId());
        orderCalcDto.setGomeState(deliveryDto.getGomeState());
        orderCalcDto.setShopNo(deliveryDto.getShopNo());
        orderCalcDto.setShopType(deliveryDto.getShopType());
        orderCalcDto.setChannel(deliveryDto.getChannelNo());
        orderCalcDto.setDemanderCode(deliveryDto.getDemanderCode());

        orderCalcDto.setCategoryFirstId(goodsDto.getCategoryFirstId());
        orderCalcDto.setCategorySecondId(goodsDto.getCategorySecondId());
        orderCalcDto.setCategoryThirdId(goodsDto.getCategoryThirdId());
        orderCalcDto.setCategoryFourthId(goodsDto.getCategoryFourthId());
        orderCalcDto.setSkuId(goodsDto.getSkuId());
        orderCalcDto.setSkuName(goodsDto.getSkuName());
        orderCalcDto.setSalesOrganization(goodsDto.getSalesOrganization());
        orderCalcDto.setCompanyCode(goodsDto.getCompanyCode());
        orderCalcDto.setSkuNo(goodsDto.getSkuNo());
        orderCalcDto.setSalePrice(BigDecimalUtils.changeY2F(goodsDto.getSalePrice()));
        orderCalcDto.setMicroID(goodsDto.getMicroID());
        orderCalcDto.setKid(goodsDto.getKid());
        orderCalcDto.setShareUserId(goodsDto.getRetailId());
        orderCalcDto.setStoreSellerId(goodsDto.getStoreSellerId());
        orderCalcDto.setEaBrandCode(goodsDto.getEaBrandCode());
        orderCalcDto.setGoodsType(goodsDto.getGoodsType());

        String eaGroupCode = goodsDto.getEaGroupCode();
        orderCalcDto.setEaGroupCode(eaGroupCode);
        if (StringUtils.isNotEmpty(eaGroupCode)) {
            orderCalcDto.setEaGroupCodeFirst(eaGroupCode.substring(0, 1));
            orderCalcDto.setEaGroupCodeSecond(eaGroupCode.substring(0, 3));
            orderCalcDto.setEaGroupCodeThird(eaGroupCode.substring(0, 5));
        } else {
            try {
                // 问题小工具
                iProblemService.addData(orderCalcDto, null, null, orderCalcDto.getOrderId(), ProblemEnum.CODE_136);
            } catch (Exception e) {
                log.error("线下四级品类为空,记录问题小工具异常orderId:{},orderDto:{}", orderDto.getOrderId(), orderDto);
            }
            return null;
        }

        orderCalcDto.setDescription(goodsDto.getDescription());
        orderCalcDto.setCommerceItemId(goodsDto.getCommerceItemId());

        orderCalcDto.setDetailId(detailGoodsDto.getDetailId());
        orderCalcDto.setSapDetailId(detailGoodsDto.getSapDetailId());
        orderCalcDto.setBuyNum(detailGoodsDto.getBuyNum());
        orderCalcDto.setPrice(BigDecimalUtils.changeY2F(detailGoodsDto.getPrice()));
        orderCalcDto.setSalesModel(detailGoodsDto.getSalesModel());
        orderCalcDto.setLogicMasLoc(detailGoodsDto.getLogicMasLoc());
        orderCalcDto.setSupplier(detailGoodsDto.getSupplier());
        //0811新增延保赋值
        orderCalcDto.setWarrantyFlag(goodsDto.getWarrantyFlag());
        List<CouponsDto> couponsList = detailGoodsDto.getCouponsDtoList();
        if (!CollectionUtils.isEmpty(couponsList)) {
            List<OrderCalcCouponDto> orderCalcCouponList = new ArrayList<>(couponsList.size());
            for (CouponsDto couponsDto : couponsList) {
                OrderCalcCouponDto orderCalcCouponDto = new OrderCalcCouponDto();
                orderCalcCouponDto.setCouponType(couponsDto.getCouponType());
                orderCalcCouponDto.setTicketId(couponsDto.getTicketId());
                orderCalcCouponDto.setCouponId(couponsDto.getCouponId());
                orderCalcCouponList.add(orderCalcCouponDto);
            }
            orderCalcDto.setCouponsDtoList(orderCalcCouponList);
        } else {
            orderCalcDto.setCouponsDtoList(Collections.emptyList());
        }

        // 封提成计算端对于线下、一店一页、线上的理解
        //如果是12渠道直接ChannelCalcNo赋值，非12渠道进行逻辑判断
        if (deliveryDto.getChannelNo().equals(BaseConstants.ORDER_CHANNEL_O2O)) {
            orderCalcDto.setChannelCalcNo(BaseConstants.PLAN_ORDER_CHANNEL_CALC_O2O);
        } else {
            String shopType = deliveryDto.getShopType();
            String application = orderDto.getRequestHeaderMap().get(BaseConstants.ORDER_APPLICATION);
            boolean ydye = (BaseConstants.ORDER_SHOPTYPE_PSHOP.equals(shopType) || BaseConstants.ORDER_SHOPTYPE_ASHOP.equals(shopType)) && BaseConstants.ORDER_APPLICATION_SHANGCHENG.equals(application);
            boolean offlineShop = BaseConstants.ORDER_APPLICATION_JINLI.equals(application) || BaseConstants.ORDER_APPLICATION_LAIGOU.equals(application);
            boolean onlineShop = BaseConstants.ORDER_SHOPTYPE_FSHOP.equals(shopType) && BaseConstants.ORDER_APPLICATION_SHANGCHENG.equals(application);
            if (ydye) {
                // 一店一页
                orderCalcDto.setChannelCalcNo(BaseConstants.PLAN_ORDER_CHANNEL_CALC_YDYE);
            } else if (offlineShop) {
                // 线下商城
                orderCalcDto.setChannelCalcNo(BaseConstants.PLAN_ORDER_CHANNEL_CALC_OFFLINE);
            } else if (onlineShop) {
                // 线上商城
                orderCalcDto.setChannelCalcNo(BaseConstants.PLAN_ORDER_CHANNEL_CALC_ONLINE);
            } else {
                log.info("orderId: {}, 不是一店一页、线下、线上订单", orderCalcDto.getOrderId());
                return null;
            }
        }
        //延保逻辑判断  0722需求
        if (Integer.valueOf(BaseConstants.ORDER_YB_WARRANTY_FLAG_1).equals(orderCalcDto.getWarrantyFlag())) {
            if(StringUtils.isEmpty(orderCalcDto.getSalesModel())) {
                orderCalcDto.setSalesModel(BaseConstants.ORDER_YB_SALE_MODEL);
            }
            if(StringUtils.isEmpty(orderCalcDto.getSupplier())){
                //延保订单供应商为空的时候给默认供应商
                orderCalcDto.setSupplier(BaseConstants.ORDER_YB_SUPPLIER);
            }
        }
        // Detail:库存类型, Since:BaseConstants:ORDER_CALC_STOCK_TYPE_*, By:libinbin9, Data:2020-8-6
        orderCalcDto.setStockType(goodsDto.getStockType());
        return orderCalcDto;
    }

    @Override
    public void updateById(OrderCalcMsg orderCalcMsg) {
        orderCalcMsgManager.updateById(orderCalcMsg);
    }
    
    private int ifYxOrder(OrderCalcDto orderCalcDto){
    	//判断渠道
    	String channel = orderCalcDto.getChannel();
    	if(channel == null || (!channel.equals(BaseConstants.ORDER_CHANNEL_YDYY) && !channel.equals(BaseConstants.ORDER_CHANNEL_ONLINE))){
    		log.info("ifYxOrder(RCO订单判断是否为营销推广识别)订单渠道为非16-60,不进行打标操作,orderCalcDto:{}",JSON.toJSONString(orderCalcDto));
    		return BaseConstants.ORDER_YX_STATUS_0;
    	}
    	//逆向订单退货(无支付时间)
    	if(BaseConstants.ORDER_RCO_STATUS.equals(orderCalcDto.getGomeState())){
    		//如果result表存在营销推广 则打标为 营销推广订单
            CalcResult calcResult = new CalcResult();
            calcResult.setOrderId(orderCalcDto.getOrderId());
            calcResult.setSkuNo(orderCalcDto.getSkuNo());
            calcResult.setDetailId(orderCalcDto.getDetailId());
            calcResult.setChannel(orderCalcDto.getChannel());
            calcResult.setGomeStatus(BaseConstants.ORDER_DL_STATUS);
            calcResult.setPromotionsType(Integer.valueOf(BaseConstants.PLAN_MARKETING_PROMOTION_TYPE));
            QueryWrapper<CalcResult> queryWrapper = Wrappers.query(calcResult);
            List<CalcResult> calcResults = calcResultMapper.selectList(queryWrapper);
            if (CollectionUtils.isEmpty(calcResults)) {
                log.info("ifYxOrder(RCO订单判断是否为营销推广识别)未查询到对应的DL的订单,不进行打标操作,orderCalcDto:{}",JSON.toJSONString(orderCalcDto));
                return BaseConstants.ORDER_YX_STATUS_0 ;
            } else {
            	 log.info("ifYxOrder(RCO订单判断是否为营销推广识别)查询到对应的DL的订单,进行打标操作,orderCalcDto:{}",JSON.toJSONString(calcResults));
                return BaseConstants.ORDER_YX_STATUS_1 ;
            }
    	}
    	//货到付款 CO订单（无支付时间）
    	if (OrderTypeEnum.CASH_ON_DELIVERY.getCode().equals(orderCalcDto.getOrderType()) && BaseConstants.ORDER_CO_STATUS.equals(orderCalcDto.getGomeState())) {
    		 log.info("ifYxOrder(RCO订单判断是否为营销推广识别)货到付款 CO订单（无支付时间）,不进行打标操作,orderCalcDto:{}",JSON.toJSONString(orderCalcDto));
    		 return BaseConstants.ORDER_YX_STATUS_0 ;
    	}
    	
    	log.info("查询计划验证订单是否为营销订单入参,requestParam:{}", JSON.toJSONString(orderCalcDto));
    	List<CommissionPlanQueryResp> commissionPlanQueryResps = iQueryPlanService.queryPlans(orderCalcDto);
    	log.info("查询计划验证订单是否为营销订单返参,responseParam:{}", JSON.toJSONString(commissionPlanQueryResps));
    	if(!CollectionUtils.isEmpty(commissionPlanQueryResps)){
    		for(CommissionPlanQueryResp commissionPlanQueryResp : commissionPlanQueryResps){
    			String planType = commissionPlanQueryResp.getPlanType();
    			if(StringUtils.isNotBlank(planType) && planType.equals(BaseConstants.PLAN_MARKETING_PROMOTION_TYPE)){
    				 return BaseConstants.ORDER_YX_STATUS_1 ;
    			}
    		}
    		return BaseConstants.ORDER_YX_STATUS_0;
    	}else{
    		return BaseConstants.ORDER_YX_STATUS_0;
    	}
    	
    }
}