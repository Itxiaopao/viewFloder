package com.gome.crp.calc.service.calc;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;

import java.util.List;

/**
 * 提成计算
 */
public interface ICalcService {

    /**
     * 根据 订单，计划 进行提成计算
     * @param orderCalcDto 订单信息
     * @param planDto 计划信息
     * @return ProfitDto
     * @see com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
     * @see com.gome.crp.calc.dto.planDto.PlanDto
     * @see com.gome.crp.calc.dto.profitDto
     */
    List<ProfitDto> calcOrder(OrderCalcDto orderCalcDto, PlanDto planDto);

}
