package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

import java.math.BigDecimal;

import com.gome.crp.calc.mybatis.model.CalcResult;

@Data
public class ResourceOccupyReqDto {
    private String planId;
    private String requestUuid;
    private BigDecimal occupyAmount;
    private CalcResult calcResult;
}
