package com.gome.crp.calc.mybatis.model;

import java.math.BigDecimal;
import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;

import lombok.Data;

@Data
public class CalcContractDetail {

	@TableId(type = IdType.INPUT)
	private Long id;//id
	private Long contractId;//主表Id
	private Integer detailType;//合同查询类型 0:主推返利函,1:带单确认函,2:新合同信息,3:订单批次合同信息,4:订单批次协议信息
    private String protocolCode;//主推函号
    private String agreementCode;//协议号
    private String contractCode;//合同号
    private String classTwo;//二级品类
    private String classCode;//品类编码
    private String brandCode;//品牌编码
    private BigDecimal offerPrice;//供价
    private BigDecimal costIncrease;//计提限价
    private Long addEachRebate;//合同政策值(新增台返)
    private Long addMonthlyRebate;//合同政策值(新增月返)
    private String confirmationNo;//带单确认函号
    private String buyOrgGroup;//采购组
    private Long limitPrice;//计提限价
    private Long singleStandard;//单台标准
    private BigDecimal distributionRate;//发放比例
    private String documentType;//合同类型
    private String buyGrpCode;//采购组
    private String buyOrgCode;//采购组织编码
    private String suppCode;//供应商编码
    private String companyCode;//公司编码
    private String agreementType;//合同类型
    private Date effectEndDate;//有效截至时间
    private Date effectStartDate;//有效开始时间
    private BigDecimal nowRateProfit;//现综合利润率
    private BigDecimal oldRateProfit;//原综合利润率
    private String salesModel;//业务机型
    private String policieStr;//政策JSON串

}
