package com.gome.crp.calc.client.receiver;

import java.util.List;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.Receiver;
/**
 * 到店预约
 * @author GOME
 *
 */
public interface IStoreSubscribeService {
	/**
	 * 到点预约人
	 * @param orderDto
	 * @return
	 */
	public List<Receiver> queryReceiver(OrderCalcDto orderDto);

}
