package com.gome.crp.calc.service.bill;

import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;

import java.util.List;

public interface IBillService {
    /**
     * sap费用挂账或冲账(有函或无函)
     * 冲账金额为负数
     *
     * @param list
     * @return
     */
    List<SapRecord> applyBill(List<CalcResult> list);

    /**
     * sap费用挂账或冲账（有函或无函）
     * 冲账金额为负数
     *
     * @param calcResultList
     * @param letterType
     * @return
     */
    List<SapRecord> applyBill(List<CalcResult> calcResultList, Integer letterType);

    /**
     * 支付挂账或冲账
     *
     * @param calcResultList
     * @param
     * @return
     */
    void applyPay(List<CalcResult> calcResultList);
}
