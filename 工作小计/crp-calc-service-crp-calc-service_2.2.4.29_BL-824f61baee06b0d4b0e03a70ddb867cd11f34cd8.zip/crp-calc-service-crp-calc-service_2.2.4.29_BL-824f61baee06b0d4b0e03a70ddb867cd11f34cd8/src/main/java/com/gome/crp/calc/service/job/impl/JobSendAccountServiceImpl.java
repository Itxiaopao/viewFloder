package com.gome.crp.calc.service.job.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.mq.producer.SendEnrollBillProcessImpl;
import com.gome.crp.calc.service.job.IJobSendAccountService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class JobSendAccountServiceImpl implements IJobSendAccountService{
    private static final int PAGE_SIZE = 500;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private GcacheUtil gcacheUtil;
    
    String[] colums = {
            "id", "order_id", "plan_id", "award_amount",
            "job_status", "contract_type", "budget_status", "is_receipt_goods",
            "commerce_item_id", "delivery_id", "detail_id", "gome_status",
            "channel", "sales_model", "sap_detail_id", "shop_no", "order_submit_time",
            "staff_code", "user_id", "plan_id", "scenes", "update_time", "surplus_amount",
            "promotions_type", "expences_offer_type", "version",
            "sku_no", "sku_id", "sku_name",
            "profile_id", "user_id",
            };
    @Autowired
    private SendEnrollBillProcessImpl sendPreBillProcess;
	@Override
	public void sentIncome() {
        long startTime = System.currentTimeMillis();
        log.info("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务");
        //幂等校验
        String cronJobSendAccountLock = CacheKeyConstants.getCronJobSendAccountLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJobSendAccountLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobSendAccountIdIndex = CacheKeyConstants.getCronJobSendAccountIdIndex();
                Long idIndex = 0L;
                String keyValue = gcacheUtil.getKeyValue(cronJobSendAccountIdIndex);
                if (keyValue != null) {
                    idIndex = Long.valueOf(keyValue);
                }

                //查询PAGE_SIZE条数据（job节点-预算校验,预算状态-未校验）
                List<CalcResult> records = selectCalcResults(idIndex);

                //更新数据下次处理位置
                if (CollectionUtils.isEmpty(records) || records.size() < PAGE_SIZE) {
                    gcacheUtil.putKeyValue(cronJobSendAccountIdIndex, "0");
                } else {
                    CalcResult detail = records.get(records.size() - 1);
                    gcacheUtil.putKeyValue(cronJobSendAccountIdIndex, String.valueOf(detail.getId()));
                }

				if (!CollectionUtils.isEmpty(records)) {
					// 推送入账信息
					log.info(String.format("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务-推送返利入账信息[start], param: %s",JSONObject.toJSONString(records)));
					sendPreBillProcess.sendPreBills(records, BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_1,BaseConstants.ORDER_CO_STATUS+"/"+BaseConstants.ORDER_DL_STATUS);
					log.info(String.format("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务-推送返利入账信息[END]"));
					log.info(String.format("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]更新数据库入账状态[start], param: %s",JSONObject.toJSONString(records)));
					updateResult(records);
					log.info(String.format("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]更新数据库入账状态[END]"));
				} else {
					log.info(String.format("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务查询数据结果为null, idIndex:%d", idIndex));
				}
            }

            log.info("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务-处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务-处理异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJobSendAccountLock});
            } catch (Exception ex) {
                log.error("定时任务-JobSendAccount处理正向单[jobStatus == 2 && gome_status == CO/DL]推送收入服务防重键异常cronJob2BudgetOccupyLock:{}", cronJobSendAccountLock, ex);
            }
        }
	}
	
    // job2 job:预算校验节点, 预算:校验成功
    private List<CalcResult> selectCalcResults(Long idIndex){
        Page<CalcResult> page = new Page<>();
        page.setSearchCount(false);
        page.setSize(PAGE_SIZE);
        CalcResult query = new CalcResult();
        query.setRebateAccountType(BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_INIT);
        query.setJobStatus(BaseConstants.CRD_JOB_STATUS_2);
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
        queryWrapper.in("gome_status",BaseConstants.ORDER_CO_STATUS,BaseConstants.ORDER_DL_STATUS);
        queryWrapper.orderByAsc("id");
        queryWrapper.gt("id", idIndex);
        queryWrapper.select(colums);
        Page<CalcResult> calcResultDetailPage = calcResultMapper.selectPage(page, queryWrapper);
        return calcResultDetailPage.getRecords();
    }
    
    
    public void updateResult(List<CalcResult> calcResults){
    	for(CalcResult calcResult : calcResults){
        	CalcResult updateCalcResult = new CalcResult();
        	updateCalcResult.setRebateAccountType(BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_1);
        	UpdateWrapper<CalcResult> calcResultWrapper = Wrappers.update();
        	calcResultWrapper.eq("job_status", BaseConstants.CRD_JOB_STATUS_2);
        	calcResultWrapper.eq("id", calcResult.getId());
        	calcResultMapper.update(updateCalcResult, calcResultWrapper);
    	}
  
    }


}
