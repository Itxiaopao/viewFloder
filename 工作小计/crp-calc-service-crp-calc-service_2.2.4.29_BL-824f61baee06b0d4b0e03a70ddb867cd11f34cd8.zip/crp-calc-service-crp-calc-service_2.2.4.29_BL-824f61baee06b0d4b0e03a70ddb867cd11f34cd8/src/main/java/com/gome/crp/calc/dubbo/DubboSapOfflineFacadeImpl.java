package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboSapOfflineFacade;
import com.gome.crp.calc.service.job.IJobSapOfflineService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DubboSapOfflineFacadeImpl implements IDubboSapOfflineFacade {
    @Autowired
    private IJobSapOfflineService iJobSapOfflineService;

    @Override
    public void applyBill() {
        iJobSapOfflineService.applyBill();
    }
}
