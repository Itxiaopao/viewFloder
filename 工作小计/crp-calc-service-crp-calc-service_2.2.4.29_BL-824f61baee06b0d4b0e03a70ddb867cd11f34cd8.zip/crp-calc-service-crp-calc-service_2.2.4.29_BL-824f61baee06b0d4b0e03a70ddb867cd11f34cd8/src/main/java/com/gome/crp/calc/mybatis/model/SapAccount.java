package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * sap账目表 Model
 */
@Getter
@Setter
@ToString
public class SapAccount {

	private Long id; //id
	private String bukrs; //公司代码
	private String lifnr; //供应商或债权人的帐号
	private String conno; //合同编号
	private String newno; //合同编号
	private String reuno; //收入项目编码(带单函 fy0000087， 主推 fy0000008， 零售提奖z605 fy0000084， 无促 z195/z197  fy0000078)
	private Date budat1; //计算开始日期
	private Date budat2; //计算结束日期
	private String bukrs0; //公司代码
	private String mblnr; //商品凭证编号
	private Integer zeile; //销售凭证项目
	private Date budat; //凭证中的过帐日期
	private String konnr; //协议编号或函号
	private String matnr; //商品编码
	private String charg; //批号
	private String ebeln; //采购凭证号
	private Integer ebelp; //采购凭证的项目编号
	private String vbeln; //开票凭证
	private Integer posnr; //销售凭证项目
	private Integer fkimg; //实际已开票数量
	private String meins; //基本计量单位
	private Long dmbtr1; //供价金额（含税）
	private Long dmbtr2; //售价额（含税）
	private Long dmbtr3; //返利额（含税）
	private String level4; //四级品类
	private String level3; //三级品类
	private String level2; //二级品类
	private Date updats; //更新日期
	private String zdtbz; //单台标准
	private String zdmbt1; //计提限价
	private Long zcxfy; //促销费金额
	private Long zyfje; //应发金额
	private String soSaleChannel; //销售渠道
	private String soSapItemNum; //sap行项目号
	private String soDeliveryDetailId; //配送单+detail_id(13/16/60渠道订单：前10位配送单号，后10位detail号；10渠道订单：销售组织+提货单号（位数不固定）)
	private String soCommodityCode; //商品编码
	private BigDecimal soCommodityNum; //商品数量
	private String soBuyorgCode; //采购组织
	private String soPlace; //地点
	private String soStockPlace; //库存地点
	private String soSuppCode; //供应商编码
	private String soBusinessModel; //业务机型(01 标准机02 包销机03 定制机04 临采机05 特价06 工程机07 会员商品08 赠品09 样机11 一步到位价)
	private String soDeliverCompanyCode; //发货公司代码
	private String soContractCode; //合同号
	private String soAgreementCode; //协议号
	private String soSaleMethod; //销售方式(01带安；02联营；09联营带安，null其他)
	private Integer isScan; //是否已扫描1:已扫描,0:未扫描
	private Date createTime; //创建时间
	private Date updateTime; //更新时间
	private Integer isDelete; //0未删除，1已删除
}