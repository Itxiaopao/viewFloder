package com.gome.crp.calc.constants;

public enum SystemVersionEnum {
    FIRST_EDITION(1, "一期"),
    SECOND_EDITION(2, "二期"),

    ;

    private int code;
    private String msg;

    SystemVersionEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
