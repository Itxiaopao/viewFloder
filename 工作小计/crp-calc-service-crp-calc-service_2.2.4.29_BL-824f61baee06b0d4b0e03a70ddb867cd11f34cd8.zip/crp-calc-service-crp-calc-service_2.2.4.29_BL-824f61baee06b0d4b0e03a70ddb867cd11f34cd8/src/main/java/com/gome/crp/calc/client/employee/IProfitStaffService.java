package com.gome.crp.calc.client.employee;

import java.util.List;

import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;

/**
 * 获利人身份信息判定
 * 
 * @author libinbin9
 *
 */
public interface IProfitStaffService {

	/**
	 * 会员信息获取获利人员工身份
	 * @param staffreq
	 * @return
	 */
	List<PersonDto> memberUserIdFindStaffIdentity(StaffReqsDto staffreq);
}
