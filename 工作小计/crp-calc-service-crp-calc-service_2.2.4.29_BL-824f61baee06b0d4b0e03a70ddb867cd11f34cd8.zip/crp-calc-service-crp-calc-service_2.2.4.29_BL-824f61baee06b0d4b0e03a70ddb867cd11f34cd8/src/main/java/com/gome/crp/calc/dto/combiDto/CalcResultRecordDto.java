package com.gome.crp.calc.dto.combiDto;

import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.Data;

@Data
public class CalcResultRecordDto {
    private CalcResult calcResult;
    private CalcRecord calcRecord;
    private SceneYDto sceneYDto;
}
