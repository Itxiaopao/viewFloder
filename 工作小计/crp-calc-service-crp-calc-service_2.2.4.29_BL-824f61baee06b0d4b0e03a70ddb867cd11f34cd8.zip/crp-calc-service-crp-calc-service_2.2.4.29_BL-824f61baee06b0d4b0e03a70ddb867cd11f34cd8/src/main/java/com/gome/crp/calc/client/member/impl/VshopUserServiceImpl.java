package com.gome.crp.calc.client.member.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.member.IVshopUserService;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class VshopUserServiceImpl implements IVshopUserService {
	
	
	@Autowired
	private VshopFacade vshopFacade;
	
	
	@Override
	public VshopInfo getVshopUserByUserId(String userId) {
		log.info(String.format("查询美店主信息接口/Dubbo: userId:%s ", userId));
		CommonResultEntity<VshopInfo> queryVshop = vshopFacade.queryVshopByuserId(userId);
		log.info(String.format("查询美店主信息接口/Dubbo: 结果:%s ", JSONObject.toJSONString(queryVshop)));
		VshopInfo businessObj = null;
		if(queryVshop.isSuccess()) {
			businessObj = queryVshop.getBusinessObj();
		}
		return businessObj;
	}

}
