package com.gome.crp.calc.constants;

/**
 * 是否删除
 */
public enum IsDeleteEnum {
    YES(1, "已删除"),
    NO(0, "未删除"),

    ;

    private int code;
    private String msg;

    IsDeleteEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
