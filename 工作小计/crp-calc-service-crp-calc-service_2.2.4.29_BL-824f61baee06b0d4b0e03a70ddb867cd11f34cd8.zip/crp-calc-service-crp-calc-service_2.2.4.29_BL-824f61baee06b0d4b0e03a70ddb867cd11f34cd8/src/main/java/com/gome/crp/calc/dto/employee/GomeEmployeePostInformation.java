package com.gome.crp.calc.dto.employee;

import java.io.Serializable;
import java.util.Date;

/**
 * 描述:岗位信息
 */
public class GomeEmployeePostInformation implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 2264699516700784508L;
	/** 岗位类型 */
	private String postType;
	/** 岗位编码 */
	private String postCode;
	/** 岗位名称 */
	private String postDesc;
	/** 员工所属机构 */
	private String shop;
	/** 员工所属机构级别 */
	private String staffLevel;
	/** 大区代码 */
	private String regioneId;
	/** 大区名称 */
	private String regioneName;
	/** 一级分部代码 */
	private String branchId1;
	/**一级分部名  */
	private String branchName1;
	/** 二级分部代码 */
	private String branchId2;
	/**二级分部名称  */
	private String branchName2;
	/** 门店id */
	private String storeId;
	/** 门店名称 */
	private String storeName;
	/** 销售组织ID */
	private String organizationId;
	/** 销售组织名 */
	private String organizationName;

	public String getPostType() {
		return postType;
	}

	public void setPostType(String postType) {
		this.postType = postType;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPostDesc() {
		return postDesc;
	}

	public void setPostDesc(String postDesc) {
		this.postDesc = postDesc;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

	public String getStaffLevel() {
		return staffLevel;
	}

	public void setStaffLevel(String staffLevel) {
		this.staffLevel = staffLevel;
	}

	public String getRegioneId() {
		return regioneId;
	}

	public void setRegioneId(String regioneId) {
		this.regioneId = regioneId;
	}

	public String getRegioneName() {
		return regioneName;
	}

	public void setRegioneName(String regioneName) {
		this.regioneName = regioneName;
	}

	public String getBranchId1() {
		return branchId1;
	}

	public void setBranchId1(String branchId1) {
		this.branchId1 = branchId1;
	}

	public String getBranchName1() {
		return branchName1;
	}

	public void setBranchName1(String branchName1) {
		this.branchName1 = branchName1;
	}

	public String getBranchId2() {
		return branchId2;
	}

	public void setBranchId2(String branchId2) {
		this.branchId2 = branchId2;
	}

	public String getBranchName2() {
		return branchName2;
	}

	public void setBranchName2(String branchName2) {
		this.branchName2 = branchName2;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
}