package com.gome.crp.calc.service.problem.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.manager.ProblemManager;
import com.gome.crp.calc.mybatis.model.Problem;
import com.gome.crp.calc.service.problem.IProblemService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProblemServiceImpl implements IProblemService {

    @Autowired
    ProblemManager problemManager;

    @Override
    public void addData(OrderCalcDto orderCalcDto, PlanDto planDto, ProfitDto profitDto, String desc, ProblemEnum problemEnum) {
        try {
            ProblemDto problemDto = generateProblemDto(null, null, orderCalcDto, planDto, profitDto, desc);
            Problem problem = generateProblem(problemDto, problemEnum);
            problemManager.addProblem(problem);
        } catch (Exception e) {
            log.error("订单号:{}, skuNo:{}, detailId:{}, channel:{} 问题小工具录入数据失败，失败原因：{}", orderCalcDto.getOrderId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId(), orderCalcDto.getChannel(), e.getMessage());
        }
    }

    @Override
    public void addData(ProblemDto problemDto, ProblemEnum problemEnum) {
        try {
            Problem problem = generateProblem(problemDto, problemEnum);
            problemManager.addProblem(problem);
        } catch (Exception e) {
            log.error("订单号:{}, skuNo:{}, detailId:{}, channel:{} 问题小工具录入数据失败，失败原因：{}", problemDto.getOrderId(), problemDto.getSkuNo(), problemDto.getDetailId(), problemDto.getChannel(), e.getMessage());
        }
    }

    @Override
    public void addData(String msgId, String msg, ProblemEnum problemEnum) {
        try {
            ProblemDto problemDto = generateProblemDto(msgId, msg);
            Problem problem = generateProblem(problemDto, problemEnum);
            problemManager.addProblem(problem);
        } catch (Exception e) {
            log.error("msgId: {} 问题小工具录入数据失败，失败原因：", msgId, e);
        }
    }

    private ProblemDto generateProblemDto(String msgId, String msg) {
        return generateProblemDto(msgId, msg, null, null, null, "");
    }

    /**
     * 生成 problemDto 对象
     *
     * @param msgId        mq消息id
     * @param msg          mq消息体
     * @param orderCalcDto OrderCalcDto
     * @param planDto      PlanDto
     * @param profitDto    ProfitDto
     * @param desc         问题描述
     * @return ProblemDto
     * @see OrderCalcDto
     * @see PlanDto
     * @see ProfitDto
     * @see ProblemDto
     */
    private ProblemDto generateProblemDto(String msgId, String msg, OrderCalcDto orderCalcDto, PlanDto planDto, ProfitDto profitDto, String desc) {
        ProblemDto problemDto;
        if (orderCalcDto != null) {
            problemDto = new ProblemDto(
                    orderCalcDto.getOrderId(),
                    orderCalcDto.getChannel(),
                    orderCalcDto.getSkuNo(),
                    orderCalcDto.getDetailId());
        } else {
            problemDto = new ProblemDto(msgId, msg);
        }

        if (planDto != null)
            problemDto.setPlanId(String.valueOf(planDto.getPlanId()));

        if (profitDto != null) {
            problemDto.setUserId(profitDto.getPersonDto().getUserId());
            problemDto.setStaffCode(profitDto.getPersonDto().getStaffCode());
        }

        problemDto.setDescription(desc);

        return problemDto;
    }

    /**
     * 生成 problem 对象
     *
     * @param problemDto  ProblemDto
     * @param problemEnum ProblemEnum
     * @return Problem
     * @see ProblemDto
     * @see ProblemEnum
     * @see Problem
     */
    private Problem generateProblem(ProblemDto problemDto, ProblemEnum problemEnum) {
        Problem problem = new Problem();
        // 封装订单信息
        problem.setOrderId(problemDto.getOrderId());
        problem.setChannel(problemDto.getChannel());
        problem.setSkuNo(problemDto.getSkuNo());
        problem.setDetailId(problemDto.getDetailId());

        problem.setPlanId(problemDto.getPlanId());

        problem.setUserId(problemDto.getUserId());
        problem.setStaffCode(problemDto.getStaffCode());

        problem.setCalcResultId(problemDto.getCalcResultId());

        generateDesc(problemDto.getDescription(), problemEnum, problem);

        return problem;
    }

    /**
     * 生成入库的描述
     *
     * @param desc              自定义描述内容
     * @param problemEnumByCode 枚举所对应的描述
     * @param problem           描述的接收对象
     */
    private void generateDesc(String desc, ProblemEnum problemEnumByCode, Problem problem) {
        desc = StringUtils.isNotEmpty(desc) ? desc : "";
        problem.setDescription(desc + problemEnumByCode.getMsg());
    }

    /**
     * 业绩还原查询时记录非法匹配
     * commerceItemId --->detail_id 
     * staff_code ----->staffCode
     * @param orderId
     * @param desc
     * @param problemEnum
     * @param staff_code
     */
	@Override
	public void addData(String  orderId, String channel,String detailId,String desc, ProblemEnum problemEnum,String staffCode) {
      Problem problem = new Problem();
      // 封装订单信息
      problem.setOrderId(orderId);
      problem.setChannel(channel);
      problem.setDetailId(detailId);
      problem.setStaffCode(staffCode);
      desc = StringUtils.isNotEmpty(desc) ? desc : "";
      problem.setDescription("[业绩还原查询]"+desc+"{"+problemEnum.getMsg()+"}");
      try {
          problemManager.addProblem(problem);
      } catch (Exception e) {
          log.error("msgId: {} 问题小工具录入数据失败，失败原因：", "订单号:"+orderId+"行项目号:"+detailId+"匹配人:"+staffCode, e);
      }
	}

    




}
