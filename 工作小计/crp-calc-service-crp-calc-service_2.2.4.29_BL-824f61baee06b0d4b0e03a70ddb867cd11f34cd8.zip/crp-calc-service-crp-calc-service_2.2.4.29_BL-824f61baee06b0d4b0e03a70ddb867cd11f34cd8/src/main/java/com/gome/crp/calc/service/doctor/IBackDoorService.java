package com.gome.crp.calc.service.doctor;

public interface IBackDoorService {
    void recalculateByOrderId(String[] orderIds);
}
