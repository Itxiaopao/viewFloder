package com.gome.crp.calc.service.doctor;

import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.dto.ermDto.OccupyBudgetResDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.sapDto.*;
import com.gome.scot.ocqs.api.model.CommissionVO;
import com.gome.scot.ocqs.api.model.ConfirmationVO;
import com.gome.scot.ocqs.api.model.ContractDetailVO;
import com.gome.scot.ocqs.api.model.ContractPolicyVO;

import java.util.List;

public interface IQueryPlanService {
    /**
     * 查询合同信息
     *
     * @param orderCalcDto
     * @return
     */
    ContractDetailVO queryContractByParam(OrderCalcDto orderCalcDto);

    /**
     * 根据订单信息、合同信息，查询计划信息
     *
     * @param orderCalcDto
     * @param contractDetail
     * @return
     */
    List<PlanDto> queryPlanByParam(OrderCalcDto orderCalcDto, ContractDetailVO contractDetail);
    
    /**
     * 根据订单信息查询计划信息(目前12渠道用)
     *
     * @param orderCalcDto
     * @return
     */
    List<PlanDto> queryPlanByParam(OrderCalcDto orderCalcDto);

    /**
     * 根据指定参数封装 planDto
     *
     * @param orderCalcDto
     * @param skuCode         skuNo
     * @param salesMode       业务机型
     * @param planId          如果传计划id，则只针对该计划id进行数据封装
     * @param promotionType   促销费类型
     * @param no              促销费类型对应的no，
     * @param classFourthCode 线下四级品类，查询无促计划的合同信息需要四级品类编码
     * @param soBuyOrgCode    挂账采购组织编码
     * @return
     */
    List<PlanDto> queryPlanByParam(OrderCalcDto orderCalcDto, String skuCode, String salesMode, String planId, String promotionType, String no, String classFourthCode, String soBuyOrgCode);

    /**
     * 根据合同号查询合同信息
     *
     * @param contractCode
     * @param classFourthCode 线下四级品类
     * @return
     */
    ContractPolicyVO getContractPolicy(String contractCode, String classFourthCode);

    /**
     * 根据带单函，采购组织编码查询函信息
     *
     * @param confirmationNo
     * @param buyOrgCode
     * @return
     */
    ConfirmationVO getMdConfirmation(String confirmationNo, String buyOrgCode, String skuCode, String salesModel);

    /**
     * 根据主推函查函信息
     *
     * @param protocolCode
     * @return
     */
    CommissionVO getMdCommission(String protocolCode, String skuCode, String salesModel);

    /**
     * 终止非差异化计划接口
     *
     * @param terminatePlanReqDto
     * @return
     */
    TerminatePlanResDto terminatePlan(TerminatePlanReqDto terminatePlanReqDto);

    /**
     * cpqs后台-释放预算接口
     *
     * @param resourceReturnReqDto
     * @return
     */
    ClientResultDTO<ResourceReturnResDto> returnResource(ResourceReturnReqDto resourceReturnReqDto);

    /**
     * cpqs后台-占用预算接口
     *
     * @param resourceOccupyReqDto
     * @return
     */
    ClientResultDTO<OccupyBudgetResDto> occupyResource(ResourceOccupyReqDto resourceOccupyReqDto);


}
