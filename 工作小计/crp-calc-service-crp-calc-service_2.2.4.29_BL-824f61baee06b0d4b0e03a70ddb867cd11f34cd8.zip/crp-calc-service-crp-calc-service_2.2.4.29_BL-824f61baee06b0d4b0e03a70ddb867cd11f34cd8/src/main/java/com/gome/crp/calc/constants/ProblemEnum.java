package com.gome.crp.calc.constants;

import org.apache.commons.lang3.StringUtils;

/**
 * 问题工具枚举
 */
public enum ProblemEnum {
    CODE_101("101", "未匹配到计划"),
    CODE_102("102", "预算不足"),
    CODE_103("103", "SAP严控未匹配到计划"),
    CODE_104("104", "场景互斥原因"),
    CODE_105("105", "政策编码605"),
    CODE_106("106", "政策编码 197 195 原因"),
    CODE_107("107", "获利人身份为加盟店"),
    CODE_108("108", "低于计提限价"),
    CODE_109("109", "匹配计划出现异常"),
    CODE_110("110", "重复计算Y奖励"),
    CODE_111("111", "计算Y匹配人出现异常"),
    CODE_112("112", "mq订单消费延迟超过计划结束时间24h"),
    CODE_113("113", "订单明细处理异常"),
    CODE_114("114", "订单消息重试处理异常"),
    CODE_115("115", "订单消息解析异常"),
    CODE_116("116", "公式计算处理异常"),
    CODE_117("117", "获利人查询结果异常"),
    CODE_118("118", "退单异常"),
    CODE_119("119", "Job Status 变更为失效"),
    CODE_120("120", "集客活动获利人员工编码为空"),
    CODE_121("121", "X场景未查询到获利人"),
    CODE_122("122", "Y场景未查询到获利人"),
    CODE_123("123", "Z场景未查询到获利人"),
    CODE_124("124", "M场景未查询到获利人"),
    CODE_125("125", "公式计算结果:0"),
    CODE_126("126", "逻辑dc获取采购组织不存在"),
    CODE_127("127", "奖励金额为0"),
    CODE_128("128", "必输项为空"),
    CODE_129("129", "货到付款"),
    CODE_130("130", "严控重新计算异常"),
    CODE_131("131", "计提基数不正确"),
    CODE_132("132", "计算比例不正确"),
    CODE_133("133", "业绩还原员工身份信息识别入参校验失败"),
    CODE_134("134", "业绩还原员工身份信息识别匹配失败"),
    CODE_135("135", "业绩还原员工身份信息识别接口异常"),
    CODE_136("136", "线下四级品类为空"),
    ;

    private String code;
    private String msg;

    ProblemEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

    /**
     * 通过 code 取枚举
     *
     * @param code
     * @return
     */
    public static ProblemEnum getProblemEnumByCode(String code) {
        if (StringUtils.isEmpty(code)) {
            return null;
        }
        for (ProblemEnum problemEnum : ProblemEnum.values()) {
            if (problemEnum.getCode().equals(code)) {
                return problemEnum;
            }
        }
        return null;
    }

}
