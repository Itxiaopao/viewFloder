package com.gome.crp.calc.service.problem;

import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;


public interface IProblemService {
    /**
     * 封装问题查询小工具数据
     *
     * @param orderCalcDto 必填，订单 dto
     *                     orderId、deliveryId、skuNo、detailId 必填
     * @param planDto      可为null，计划 dto
     * @param desc         可为null，问题描述
     * @param problemEnum  必填
     */
    void addData(OrderCalcDto orderCalcDto, PlanDto planDto, ProfitDto profitDto, String desc, ProblemEnum problemEnum);

    /**
     * 封装问题查询小工具数据
     *
     * @param problemDto  orderId、deliveryId、skuNo、detailId 必填
     * @param problemEnum
     */
    void addData(ProblemDto problemDto, ProblemEnum problemEnum);

    /**
     * 封装问题查询小工具数据
     *
     * @param msgId
     * @param msg
     * @param problemEnum
     */
    void addData(String msgId, String msg, ProblemEnum problemEnum);
    /**
     * 业绩还原查询时记录非法匹配
     * commerceItemId --->detail_id  行项目号
     * staff_code ----->staffCode  默认值
     * @param orderId
     * @param desc
     * @param problemEnum
     * @param staff_code
     */
    public void addData(String  orderId, String channel,String detailId,String desc, ProblemEnum problemEnum,String staffCode) ;
}
