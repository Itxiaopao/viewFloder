package com.gome.crp.calc.dto.contractDto;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 合同Dto
 */
@Data
public class CalcContractDto implements Serializable {
    private static final long serialVersionUID = -3897546300154078396L;
    private String deliveryDetailId;//sapDetailId
    private String sapSaleOrderNum;//sap销售单号
    private String sapItemNum;//sap行项目号
    private String saleChannel;//销售渠道
    private String skuNo;
    private Integer skuNum;//商品数量
    private String place;//todo 地点
    private String stockPlace;//库存地点
    private String businessModel;//业务机型
    private String deliverCompanyCode;//发货公司代码
    private String saleMethod;//销售方式
    private String operate;//0新增，1修改
    private Date commissionSendTime;//配置端发送时间戳到ms
    private Date sapOperateTime;//操作时间,到秒级
    private ScsContractDto scsContract;//合同查询数据
}
