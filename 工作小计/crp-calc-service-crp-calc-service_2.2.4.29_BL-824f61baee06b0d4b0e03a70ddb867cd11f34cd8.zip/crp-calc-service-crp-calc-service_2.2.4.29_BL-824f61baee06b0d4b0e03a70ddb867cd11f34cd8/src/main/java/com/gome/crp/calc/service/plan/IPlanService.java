package com.gome.crp.calc.service.plan;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.util.List;
import java.util.Map;

/**
 * 匹配计划
 */
public interface IPlanService {
    /**
     * 根据 OrderCalcDto 查询匹配计划（从缓存中查）
     *
     * @param orderCalcDto
     * @return
     */
    List<PlanDto> orderMatchPlan(OrderCalcDto orderCalcDto);

    /**
     * 根据计划 id 查缓存
     *
     * @param planId
     * @return
     */
    List<PlanDto> getPlansById(String[] planId);

    /**
     * 判断一个商品为什么不能匹配到某个计划
     *
     * @param skuMap key:必传  请使用常量：skuNo,saleModel,eaGroupCode,eaBrandCode,planId
     *               key对应常量：BaseConstants.PROBLEM_SKU_NO、BaseConstants.PROBLEM_SALE_MODEL、BaseConstants.PROBLEM_EA_GROUP_CODE、PROBLEM_EA_BRAND_CODE、PROBLEM_PLAN_ID
     * @return
     */
    List<String> skuIsMatchPlan(Map<String, String> skuMap);
}
