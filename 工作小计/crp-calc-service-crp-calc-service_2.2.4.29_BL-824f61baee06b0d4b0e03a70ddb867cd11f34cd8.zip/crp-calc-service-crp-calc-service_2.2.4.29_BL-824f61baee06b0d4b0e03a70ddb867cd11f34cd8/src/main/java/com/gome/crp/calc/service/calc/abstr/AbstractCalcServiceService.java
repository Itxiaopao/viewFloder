package com.gome.crp.calc.service.calc.abstr;

import com.gome.crp.calc.dto.calcDto.CalcResultDto;
import com.gome.crp.calc.service.calc.ICalcService;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

public abstract class AbstractCalcServiceService implements ICalcService {

}
