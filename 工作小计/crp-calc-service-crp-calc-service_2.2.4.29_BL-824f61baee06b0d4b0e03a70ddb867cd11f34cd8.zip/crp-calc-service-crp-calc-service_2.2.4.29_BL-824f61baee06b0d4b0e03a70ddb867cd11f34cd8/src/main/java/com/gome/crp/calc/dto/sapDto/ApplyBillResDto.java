package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

@Data
public class ApplyBillResDto {
}
