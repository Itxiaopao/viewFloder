package com.gome.crp.calc.manager.contract;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.constants.CalcContractDetailTypeEnum;
import com.gome.crp.calc.dto.contractDto.CalcContractDto;
import com.gome.crp.calc.dto.contractDto.ContractDto;
import com.gome.crp.calc.dto.contractDto.ExtraDto;
import com.gome.crp.calc.dto.contractDto.PoliciesDto;
import com.gome.crp.calc.dto.contractDto.PushLetterDto;
import com.gome.crp.calc.dto.contractDto.ReplaceLetterDto;
import com.gome.crp.calc.dto.contractDto.ScsContractDto;
import com.gome.crp.calc.mybatis.mapper.CalcContractDetailMapper;
import com.gome.crp.calc.mybatis.mapper.CalcContractMapper;
import com.gome.crp.calc.mybatis.model.CalcContract;
import com.gome.crp.calc.mybatis.model.CalcContractDetail;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gomeo2o.common.exceptions.BizException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CalcContractManager {

	@Autowired
	private CalcContractMapper calcContractMapper;
	
	@Autowired
	private CalcContractDetailMapper calcContractDetailMapper;
	
    @Autowired
    private SeqGenUtil seqGenUtil;
	
	public CalcContractDto getContractDtoBySapDetailId(String sapDetailId) {
		if(StringUtils.isBlank(sapDetailId)) {
			throw new BizException(422,"sapDetailId 不能为空");
		}
		CalcContractDto resultDto = null;
		try {
			QueryWrapper<CalcContract> query = Wrappers.query();
			query.eq(sapDetailId != null, "delivery_detail_id", sapDetailId);
			CalcContract contract = calcContractMapper.selectOne(query);
			if(contract != null) {
				resultDto = converterFromCalcContract(contract);
				Long contractId = contract.getId();
				Map<String, Object> columnMap = new HashMap<>();
				columnMap.put("contract_id", contractId);
				List<CalcContractDetail> detailList = calcContractDetailMapper.selectByMap(columnMap);
				if(CollectionUtils.isNotEmpty(detailList)) {
					ScsContractDto scsContract = new ScsContractDto();
	            	String comprehensiveContribution = contract.getComprehensiveContribution();
	            	scsContract.setComprehensiveContribution(comprehensiveContribution);
					for (CalcContractDetail detail : detailList) {
						Integer detailType = detail.getDetailType();
						if(detailType == CalcContractDetailTypeEnum.COMMISSION.getCode()) {
							PushLetterDto pushLetterDto = converterFromDetailToPush(detail);
							scsContract.setCommission(pushLetterDto);
						} else if(detailType == CalcContractDetailTypeEnum.CONFIRMATION.getCode()) {
							ReplaceLetterDto confirmation = converterFromDetailToReplace(detail);
							scsContract.setConfirmation(confirmation);
						} else if(detailType == CalcContractDetailTypeEnum.CONTRACT_POLICY.getCode()) {
							ContractDto contractPolicy = converterFromDetailToContract(detail);
							scsContract.setContractPolicy(contractPolicy);
						} else if(detailType == CalcContractDetailTypeEnum.ORDER_CONTRACT_POLICY.getCode()) {
							ContractDto orderContractPolicy = converterFromDetailToContract(detail);
							scsContract.setOrderContractPolicy(orderContractPolicy);
						} else if(detailType == CalcContractDetailTypeEnum.ORDER_AGREEMENT.getCode()) {
							ExtraDto orderAgreement = converterFromDetailToExtra(detail);
							scsContract.setOrderAgreement(orderAgreement);
						}
					}
					resultDto.setScsContract(scsContract);
				}
			}
		} catch (Exception e) {
			log.error("查询消息出错，sapDetailId is {}, error is {}",sapDetailId,e.getMessage());
		}
		return resultDto;
	}
	
    @Transactional(rollbackFor = Exception.class)
    public void saveDetialInfo(ScsContractDto scsContract, Long calcRecordId, CalcContract orderInfo) {
    	PushLetterDto pushLetterDto = scsContract.getCommission();//主推返利函
    	if(pushLetterDto != null) {
    		//数据入库
    		Long detialId = seqGenUtil.nextCrpContractDetailSeq();// 加入id生成器
    		CalcContractDetail detialInfo = converterFromPushDto(pushLetterDto);
    		detialInfo.setContractId(calcRecordId);
    		detialInfo.setDetailType(CalcContractDetailTypeEnum.COMMISSION.getCode());
    		detialInfo.setId(detialId);
    		// 调用保存方法
    		calcContractDetailMapper.insert(detialInfo);
    	}
    	ReplaceLetterDto confirmation = scsContract.getConfirmation();//带单确认函
    	if(confirmation != null) {
    		//数据入库
    		Long detialId = seqGenUtil.nextCrpContractDetailSeq();// 加入id生成器
    		CalcContractDetail detialInfo = converterFromReplaceDto(confirmation);
    		detialInfo.setContractId(calcRecordId);
    		detialInfo.setDetailType(CalcContractDetailTypeEnum.CONFIRMATION.getCode());
    		detialInfo.setId(detialId);
    		// 调用保存方法
    		calcContractDetailMapper.insert(detialInfo);
    	}
    	ContractDto contractPolicy = scsContract.getContractPolicy();//新合同信息
    	if(contractPolicy != null) {
    		//数据入库
    		Long detialId = seqGenUtil.nextCrpContractDetailSeq();// 加入id生成器
    		CalcContractDetail detialInfo = converterFromContractDto(contractPolicy);
    		detialInfo.setContractId(calcRecordId);
    		detialInfo.setDetailType(CalcContractDetailTypeEnum.CONTRACT_POLICY.getCode());
    		detialInfo.setId(detialId);
    		// 调用保存方法
    		calcContractDetailMapper.insert(detialInfo);
    	}
    	ContractDto orderContractPolicy = scsContract.getOrderContractPolicy();//订单批次合同信息
    	if(orderContractPolicy != null) {
    		//数据入库
    		Long detialId = seqGenUtil.nextCrpContractDetailSeq();// 加入id生成器
    		CalcContractDetail detialInfo = converterFromContractDto(orderContractPolicy);
    		detialInfo.setContractId(calcRecordId);
    		detialInfo.setDetailType(CalcContractDetailTypeEnum.ORDER_CONTRACT_POLICY.getCode());
    		detialInfo.setId(detialId);
    		// 调用保存方法
    		calcContractDetailMapper.insert(detialInfo);
    	}
    	ExtraDto orderAgreement = scsContract.getOrderAgreement();//订单批次协议信息
    	if(orderAgreement != null) {
    		//数据入库
    		Long detialId = seqGenUtil.nextCrpContractDetailSeq();// 加入id生成器
    		CalcContractDetail detialInfo = converterFromExtraDto(orderAgreement);
    		detialInfo.setContractId(calcRecordId);
    		detialInfo.setDetailType(CalcContractDetailTypeEnum.ORDER_AGREEMENT.getCode());
    		detialInfo.setId(detialId);
    		// 调用保存方法
    		calcContractDetailMapper.insert(detialInfo);
    	}
    	// 数据入库
    	calcContractMapper.insert(orderInfo);
    }
    
    private CalcContractDetail converterFromPushDto(PushLetterDto pushLetterDto) {
    	CalcContractDetail detialInfo = new CalcContractDetail();
		detialInfo.setProtocolCode(pushLetterDto.getProtocolCode());//主推函号
	    detialInfo.setContractCode(pushLetterDto.getContractCode());//合同号
	    detialInfo.setClassCode(pushLetterDto.getClassCode());//品类编码
	    detialInfo.setBrandCode(pushLetterDto.getBrandCode());//品牌编码
	    detialInfo.setOfferPrice(pushLetterDto.getOfferPrice());//供价
	    detialInfo.setCostIncrease(pushLetterDto.getCostIncrease());//计提限价
	    detialInfo.setAddEachRebate(pushLetterDto.getAddEachRebate().longValue());//合同政策值(新增台返)
	    detialInfo.setAddMonthlyRebate(pushLetterDto.getAddMonthlyRebate().longValue());//合同政策值(新增月返)
	    detialInfo.setDocumentType(pushLetterDto.getDocumentType());//合同类型
	    detialInfo.setBuyOrgCode(pushLetterDto.getBuyOrgCode());//采购组织编码
	    detialInfo.setSuppCode(pushLetterDto.getSuppCode());//供应商编码
	    detialInfo.setCompanyCode(pushLetterDto.getCompanyCode());//公司编码
	    detialInfo.setSalesModel(pushLetterDto.getSalesModel());//业务机型
	    return detialInfo;
    }
    
    private CalcContractDetail converterFromReplaceDto(ReplaceLetterDto confirmation) {
    	CalcContractDetail detialInfo = new CalcContractDetail();
	    detialInfo.setContractCode(confirmation.getContractCode());//合同号
	    detialInfo.setClassTwo(confirmation.getClassTwo());//二级品类
	    detialInfo.setBrandCode(confirmation.getBrandCode());//品牌编码
	    detialInfo.setConfirmationNo(confirmation.getConfirmationNo());//带单确认函号
	    detialInfo.setBuyOrgGroup(confirmation.getBuyOrgGroup());//采购组
	    detialInfo.setLimitPrice(confirmation.getLimitPrice().longValue());//计提限价
	    detialInfo.setSingleStandard(confirmation.getSingleStandard().longValue());//单台标准
	    detialInfo.setDistributionRate(confirmation.getDistributionRate());//发放比例
	    detialInfo.setDocumentType(confirmation.getDocumentType());//合同类型
	    detialInfo.setBuyOrgCode(confirmation.getBuyOrgCode());//采购组织编码
	    detialInfo.setSuppCode(confirmation.getSuppCode());//供应商编码
	    detialInfo.setCompanyCode(confirmation.getCompanyCode());//公司编码
	    detialInfo.setSalesModel(confirmation.getSalesModel());//业务机型
	    return detialInfo;
    }
    
    private CalcContractDetail converterFromContractDto(ContractDto contractPolicy) {
    	List<PoliciesDto> policies = contractPolicy.getPolicies();//政策
		CalcContractDetail detialInfo = new CalcContractDetail();
	    detialInfo.setContractCode(contractPolicy.getContractCode());//合同号
	    detialInfo.setClassCode(contractPolicy.getClassCode());//品类编码
	    detialInfo.setBrandCode(contractPolicy.getBrandCode());//品牌编码
	    detialInfo.setDocumentType(contractPolicy.getDocumentType());//合同类型
	    detialInfo.setBuyGrpCode(contractPolicy.getBuyGrpCode());//采购组
	    detialInfo.setBuyOrgCode(contractPolicy.getBuyOrgCode());//采购组织编码
	    detialInfo.setSuppCode(contractPolicy.getSuppCode());//供应商编码
	    detialInfo.setCompanyCode(contractPolicy.getCompanyCode());//公司编码
	    detialInfo.setEffectEndDate(contractPolicy.getEffectEndDate());//有效截至时间
	    detialInfo.setEffectStartDate(contractPolicy.getEffectStartDate());//有效开始时间
	    detialInfo.setPolicieStr(JSON.toJSONString(policies));//政策JSON串
	    detialInfo.setOfferPrice(contractPolicy.getOfferPrice());//供价
	    return detialInfo;
    }
    
    private CalcContractDetail converterFromExtraDto(ExtraDto orderAgreement) {
		CalcContractDetail detialInfo = new CalcContractDetail();
		List<PoliciesDto> policies = orderAgreement.getPolicies();
	    detialInfo.setAgreementCode(orderAgreement.getAgreementCode());//协议号
	    detialInfo.setContractCode(orderAgreement.getContractCode());//合同号
	    detialInfo.setClassCode(orderAgreement.getClassCode());//品类编码
	    detialInfo.setBrandCode(orderAgreement.getBrandCode());//品牌编码
	    detialInfo.setBuyOrgCode(orderAgreement.getBuyOrgCode());//采购组织编码
	    detialInfo.setSuppCode(orderAgreement.getSuppCode());//供应商编码
	    detialInfo.setCompanyCode(orderAgreement.getCompanyCode());//公司编码
	    detialInfo.setAgreementType(orderAgreement.getAgreementType());//合同类型
	    detialInfo.setEffectEndDate(orderAgreement.getEffectEndDate());//有效截至时间
	    detialInfo.setEffectStartDate(orderAgreement.getEffectStartDate());//有效开始时间
	    detialInfo.setNowRateProfit(orderAgreement.getNowRateProfit());//现综合利润率
	    detialInfo.setOldRateProfit(orderAgreement.getOldRateProfit());//原综合利润率
		detialInfo.setPolicieStr(JSON.toJSONString(policies));//政策JSON串
	    detialInfo.setOfferPrice(orderAgreement.getOfferPrice());//供价
	    return detialInfo;
    }
	
	
	/**
	 * 数据拼接
	 */
	private CalcContractDto converterFromCalcContract(CalcContract contract) {
		CalcContractDto dto = new CalcContractDto();
	    dto.setDeliveryDetailId(contract.getDeliveryDetailId());//sapDetailId
	    dto.setSapSaleOrderNum(contract.getSapSaleOrderNum());//sap销售单号
	    dto.setSapItemNum(contract.getSapItemNum());//sap行项目号
	    dto.setSaleChannel(contract.getSaleChannel());//销售渠道
	    dto.setSkuNo(contract.getSkuNo());
	    dto.setSkuNum(contract.getSkuNum());//商品数量
	    dto.setPlace(contract.getPlace());//todo 地点
	    dto.setStockPlace(contract.getStockPlace());//库存地点
	    dto.setBusinessModel(contract.getBusinessModel());//业务机型
	    dto.setDeliverCompanyCode(contract.getDeliverCompanyCode());//发货公司代码
	    dto.setSaleMethod(contract.getSaleMethod());//销售方式
	    dto.setOperate(contract.getOperate());//0新增，1修改
	    dto.setCommissionSendTime(contract.getCommissionSendTime());//配置端发送时间戳到ms
	    dto.setSapOperateTime(contract.getSapOperateTime());//操作时间,到秒级
		return dto;
	}
	
	private PushLetterDto converterFromDetailToPush(CalcContractDetail detail) {
		PushLetterDto dto = new PushLetterDto();
	    dto.setContractCode(detail.getContractCode());//合同编号
	    dto.setDocumentType(detail.getDocumentType());//合同类型
	    dto.setProtocolCode(detail.getProtocolCode());//主推函号
	    dto.setBrandCode(detail.getBrandCode());//品牌编码
	    dto.setClassCode(detail.getClassCode());//品类编码
	    dto.setSuppCode(detail.getSuppCode());//供应商编码
	    dto.setBuyOrgCode(detail.getBuyOrgCode());//采购组织编码
	    dto.setCompanyCode(detail.getCompanyCode());//公司编码
	    dto.setOfferPrice(detail.getOfferPrice());//供价
	    dto.setSalesModel(detail.getSalesModel());//业务机型
	    dto.setCostIncrease(detail.getCostIncrease());//计提限价
	    dto.setAddEachRebate(new BigDecimal(detail.getAddEachRebate()));//合同政策值(新增台返)
	    dto.setAddMonthlyRebate(new BigDecimal(detail.getAddMonthlyRebate()));//合同政策值(新增月返)
		return dto;
	}
	
	private ReplaceLetterDto converterFromDetailToReplace(CalcContractDetail detail) {
		ReplaceLetterDto dto = new ReplaceLetterDto();
	    dto.setContractCode(detail.getContractCode());//合同编号
	    dto.setDocumentType(detail.getDocumentType());//合同类型
	    dto.setConfirmationNo(detail.getConfirmationNo());//带单确认函号
	    dto.setClassTwo(detail.getClassTwo());//二级品类
	    dto.setBrandCode(detail.getBrandCode());//品牌编码
	    dto.setBuyOrgCode(detail.getBuyOrgCode());//采购组织编码
	    dto.setBuyOrgGroup(detail.getBuyOrgGroup());//采购组
	    dto.setSuppCode(detail.getSuppCode());//供应商编码
	    dto.setCompanyCode(detail.getCompanyCode());//公司编码
	    dto.setLimitPrice(new BigDecimal(detail.getLimitPrice()));//计提限价
	    dto.setSingleStandard(new BigDecimal(detail.getSingleStandard()));//单台标准
	    dto.setDistributionRate(detail.getDistributionRate());//发放比例
	    dto.setSalesModel(detail.getSalesModel());//业务机型
		return dto;
	}
	
	private ContractDto converterFromDetailToContract(CalcContractDetail detail) {
		ContractDto dto = new ContractDto();
	    String policieStr = detail.getPolicieStr();//政策JSON串
	    List<PoliciesDto> parseArray = JSON.parseArray(policieStr, PoliciesDto.class);
	    dto.setContractCode(detail.getContractCode());//合同号
	    dto.setBuyOrgCode(detail.getBuyOrgCode());//采购组织编码
	    dto.setSuppCode(detail.getSuppCode());//供应商编码
	    dto.setCompanyCode(detail.getCompanyCode());//公司编码
	    dto.setBrandCode(detail.getBrandCode());//品牌编码
	    dto.setClassCode(detail.getClassCode());//品类编码
	    dto.setDocumentType(detail.getDocumentType());//合同类型
	    dto.setBuyGrpCode(detail.getBuyGrpCode());//采购组
	    dto.setEffectEndDate(detail.getEffectEndDate());//有效截至时间
	    dto.setEffectStartDate(detail.getEffectStartDate());//有效开始时间
	    dto.setPolicies(parseArray);//政策
	    dto.setOfferPrice(detail.getOfferPrice());//供价
		return dto;
	}
	
	private ExtraDto converterFromDetailToExtra(CalcContractDetail detail) {
		ExtraDto dto = new ExtraDto();
	    dto.setAgreementCode(detail.getAgreementCode());//协议号
	    dto.setContractCode(detail.getContractCode());//合同号
	    dto.setBuyOrgCode(detail.getBuyOrgCode());//采购组织编码
	    dto.setSuppCode(detail.getSuppCode());//供应商编码
	    dto.setCompanyCode(detail.getCompanyCode());//公司编码
	    dto.setBrandCode(detail.getBrandCode());//品牌编码
	    dto.setClassCode(detail.getClassCode());//品类编码
	    dto.setAgreementType(detail.getAgreementType());//合同类型
	    dto.setEffectEndDate(detail.getEffectEndDate());//有效截至时间
	    dto.setEffectStartDate(detail.getEffectStartDate());//有效开始时间
	    dto.setNowRateProfit(detail.getNowRateProfit());//现综合利润率
	    dto.setOldRateProfit(detail.getOldRateProfit());//原综合利润率
	    dto.setOfferPrice(detail.getOfferPrice());//供价
		List<PoliciesDto> parseArray = JSON.parseArray(detail.getPolicieStr(), PoliciesDto.class);// 政策编码
		dto.setPolicies(parseArray);
		return dto;
	}

}
