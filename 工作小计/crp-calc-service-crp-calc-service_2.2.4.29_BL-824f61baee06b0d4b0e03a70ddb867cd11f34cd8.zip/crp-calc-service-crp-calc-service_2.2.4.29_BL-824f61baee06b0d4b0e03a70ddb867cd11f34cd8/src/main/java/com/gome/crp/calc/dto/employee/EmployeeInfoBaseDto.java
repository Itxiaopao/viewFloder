package com.gome.crp.calc.dto.employee;

import lombok.Data;

import java.io.Serializable;

/**
 * 基础信息
 */
@Data
public class EmployeeInfoBaseDto implements Serializable {

    private static final long serialVersionUID = 3764209951980671646L;

    /** 员工ID */
    private String employeeId;
    /** 员工name */
    private String employeeName;
    /** 员工手机号 */
    private String cellPhone;
    /** 员工类别 */
    private String emplClass;
    /** 员工状态 */
    private String gmHrStatus;
    /** 成本中心 */
    private String gmCostCenDes;
    /** 成本中心ID */
    private String gmDeptOrCostId;
    /** 公司代码 */
    private String gmCompCdPre;
    /** 公司名称 */
    private String gmCompCdDes;
    /** 银行卡号 */
    private String accountEcId;
    /** 公司id */
    private String companyId;
    /** 公司名称 */
    private String companyName;
    /** 头像 */
    private String headSculptureUrl;
    /** 服务单数 */
    private String serviceSingular;
    /** 综合评分 */
    private String compositeScore;
    /** 服务等级 */
    private String servicelevel;
    /** 员工等级名称 */
    private String servicelevelName;
    /** 服务量级标签 */
    private String serviceMagnitude;

    /** 在职状态 */
    private String status;
    /** 身份证号 */
    private String nationalId;

}
