package com.gome.crp.calc.constants;

/**
 * 线上sap是否挂账
 */
public enum IsOnlineApplyBillEnum {
    ALREADY_APPLY(1, "已挂账"),
    NOT_HAVE_APPLY(0, "未挂账"),

    ;

    private int code;
    private String msg;

    IsOnlineApplyBillEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
