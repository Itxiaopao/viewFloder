package com.gome.crp.calc.dubbo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.facade.dubbo.IDubboUpdateFacade;
import com.gome.crp.calc.mybatis.mapper.OrderRecordMapper;
import com.gome.crp.calc.mybatis.model.OrderRecord;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.order.calc.dto.DeliveryDto;
import com.gome.crp.order.calc.dto.OrderDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;

@Slf4j
@Service("dubboUpdateFacade")
public class DubboUpdateFacadeImpl implements IDubboUpdateFacade {
    @Autowired
    private OrderRecordMapper orderRecordMapper;
    @Autowired
    private IOMSOrderService iOMSOrderService;

    @Override
    public void updateParamById(JSONObject jsonObject) {
        ClassPathResource classPathResource = new ClassPathResource("repair.txt");
        InputStream inputStream = null;
        BufferedReader reader = null;
        String orderId = null;
        try {
            inputStream = classPathResource.getInputStream();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            while (reader.ready()) {
                orderId = reader.readLine();
                log.info("补发金立订单开始orderId:{}", orderId);
                if (StringUtils.isNotBlank(orderId)) {
                    try {
                        logicDeal(orderId);
                    } catch (Exception e) {
                        log.error("补发金立订单异常orderId:{}", orderId, e);
                    }
                }
            }

        } catch (Exception e) {
            log.error("补发金立订单异常orderId:{}", orderId, e);
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void logicDeal(String orderId) {
        OrderRecord orderRecord = new OrderRecord();
        orderRecord.setOrderId(orderId.trim());
        QueryWrapper<OrderRecord> queryWrapper = Wrappers.query(orderRecord);
        List<OrderRecord> orderRecords = orderRecordMapper.selectList(queryWrapper);
        if (CollectionUtils.isEmpty(orderRecords)) {
            log.error("补发金立订单不存在orderId:{}", orderId);
        } else {
            HashMap<String, OrderDto> recordMap = new HashMap<>();
            for (OrderRecord record : orderRecords) {
                String msgBody = record.getMsgBody();
                OrderDto orderDto = JSON.parseObject(msgBody, OrderDto.class);
                List<DeliveryDto> deliveryList = orderDto.getDeliveryList();
                recordMap.put(deliveryList.get(0).getGomeState(), orderDto);
            }

            if (recordMap.containsKey(BaseConstants.ORDER_CL_STATUS) ||
                    recordMap.containsKey(BaseConstants.ORDER_RT_STATUS) ||
                    recordMap.containsKey(BaseConstants.ORDER_RCO_STATUS)) {
                log.info("补发金立订单取消orderId:{}", orderId);
            } else {
                OrderDto coOrderDto = recordMap.get(BaseConstants.ORDER_CO_STATUS);
                if (coOrderDto != null) {
                    iOMSOrderService.handler(coOrderDto);
                }

                OrderDto dlOrderDto = recordMap.get(BaseConstants.ORDER_DL_STATUS);
                if (dlOrderDto != null) {
                    iOMSOrderService.handler(dlOrderDto);
                }

                log.info("补发金立订单完成orderId:{}", orderId);
            }
        }
    }

}
