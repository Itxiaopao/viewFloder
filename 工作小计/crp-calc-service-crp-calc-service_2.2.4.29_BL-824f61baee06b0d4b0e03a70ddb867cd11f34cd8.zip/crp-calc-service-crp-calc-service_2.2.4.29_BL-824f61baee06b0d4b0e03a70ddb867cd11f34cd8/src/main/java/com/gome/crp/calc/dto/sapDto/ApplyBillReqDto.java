package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

import java.io.Serializable;

@Data
public class ApplyBillReqDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private HeaderDto header;
    private Fi475Dto fi475;
}
