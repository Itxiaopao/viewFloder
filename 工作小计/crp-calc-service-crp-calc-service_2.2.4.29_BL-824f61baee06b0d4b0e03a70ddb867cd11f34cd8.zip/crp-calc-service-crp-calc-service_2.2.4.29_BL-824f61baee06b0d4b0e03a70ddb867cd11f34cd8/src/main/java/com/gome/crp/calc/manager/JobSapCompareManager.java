package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapAccount;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.mybatis.service.ISapAccountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class JobSapCompareManager {

    @Autowired
    private ICalcResultService iCalcResultService;
    @Autowired
    private ISapAccountService iSapAccountService;

    @Transactional
    public void doUpdateCalcResultJobStatus(SapAccount sapAccount, List<CalcResult> calcResults) {
        iSapAccountService.updateById(sapAccount);
        iCalcResultService.updateBatchById(calcResults);
    }

    @Transactional
    public void doUpdateCalcResultJobStatus(List<CalcResult> calcResults, List<Long> deletedRecalculateResultIds) {
        iCalcResultService.updateBatchById(calcResults);
        iCalcResultService.removeByIds(deletedRecalculateResultIds);
    }

    @Transactional
    public void doUpdateCalcResultJobStatus(List<CalcResult> calcResults) {
        iCalcResultService.updateBatchById(calcResults);
    }
}
