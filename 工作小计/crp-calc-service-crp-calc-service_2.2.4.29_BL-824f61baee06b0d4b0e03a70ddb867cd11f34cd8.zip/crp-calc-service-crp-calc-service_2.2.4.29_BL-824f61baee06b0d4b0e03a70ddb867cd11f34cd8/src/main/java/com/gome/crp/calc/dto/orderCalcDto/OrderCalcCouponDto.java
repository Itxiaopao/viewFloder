package com.gome.crp.calc.dto.orderCalcDto;

import lombok.Data;

@Data
public class OrderCalcCouponDto {
    private Long couponType; //券类型
    private String ticketId; //券号（美券、营销券传ticketId）
    private String couponId; //券id（红券、蓝券传券id）
}
