package com.gome.crp.calc.constants;

public enum PathEnum {
    SAP_FI475("/RESTAdapter/tcpt/fi475?j_username=tcptuser&j_password=TCPTUSER", "FI475", "ECC", "发放明细回传接口"),//挂账接口

    ;

    private String code;
    private String interfaceId;
    private String systemId;
    private String msg;

    PathEnum(String code, String interfaceId, String systemId, String msg) {
        this.code = code;
        this.interfaceId = interfaceId;
        this.systemId = systemId;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getInterfaceId() {
        return this.interfaceId;
    }

    public String getSystemId() {
        return this.systemId;
    }

    public String getMsg() {
        return this.msg;
    }


}
