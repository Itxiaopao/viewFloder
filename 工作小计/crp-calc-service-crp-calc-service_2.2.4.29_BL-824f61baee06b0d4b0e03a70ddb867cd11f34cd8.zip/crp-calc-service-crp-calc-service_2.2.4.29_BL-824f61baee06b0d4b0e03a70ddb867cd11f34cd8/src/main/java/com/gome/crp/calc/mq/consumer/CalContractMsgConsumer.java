package com.gome.crp.calc.mq.consumer;

import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import com.gome.crp.calc.dto.threadLocal.LocalDto;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.boot.common.logging.trace.mq.MqUtil;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.contractDto.CalcContractDto;
import com.gome.crp.calc.dto.contractDto.ScsContractDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.manager.contract.CalcContractManager;
import com.gome.crp.calc.manager.contract.CalcContractMqManager;
import com.gome.crp.calc.mq.core.consumer.MQConsumeResult;
import com.gome.crp.calc.mybatis.model.CalcContract;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.service.so.ISOOrderService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.util.threadLocal.CalcLocal;

import lombok.extern.slf4j.Slf4j;

/**
 * 接收 SO 的 MQ 消息
 */
@Slf4j
public class CalContractMsgConsumer {

    @Value("${rocketmq.consumer.namesrvAddr}")
    private String namesrvAddr;
    @Value("${contract_topic}")
    private String topic;
    @Value("${gome_crp_calc_contract_group}")
    private String group;
    @Autowired
    private SeqGenUtil seqGenUtil;
	@Autowired
	private CalcContractManager calcContractManager;
	@Autowired
	private CalcContractMqManager calcContractMqManager;
	@Autowired
	private GcacheUtil gcacheUtil;
	@Autowired
	private ISOOrderService isoOrderService;
	@Autowired
    private IProblemService problemService;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;
    
    private DefaultMQPushConsumer consumer;
    
    
    @PostConstruct
    public void init() {
        try {
            /**
             * 一个应用创建一个Consumer，由应用来维护此对象，可以设置为全局对象或者单例<br>
             * 注意：ConsumerGroupName需要由应用来保证唯一
             */
            log.info("init MQ:namesrvAddr'{}' topic'{}' group'{}'",namesrvAddr,topic,group);
            consumer = new DefaultMQPushConsumer(group);
            consumer.setNamesrvAddr(namesrvAddr);
            /**
             * 订阅指定topic下tags分别等于TagU或TagFX
             * 注意：一个consumer对象可以订阅多个topic
             */
            consumer.subscribe(topic, null);
            //CONSUME_FROM_FIRST_OFFSET（默认）:一个【新的订阅组】第一次启动从队列的【最前】位置开始消费，后续再启动接着上次消费的进度开始消费
            //CONSUME_FROM_LAST_OFFSET:一个【新的订阅组】第一次启动从队列的【最后】位置开始消费，后续再启动接着上次消费的进度开始消费
            consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
            consumer.setMessageModel(MessageModel.CLUSTERING);
            //设置批次处理消息的条数,默认是1
            //consumer.setConsumeMessageBatchMaxSize(1);
            consumer.registerMessageListener(new MessageListenerConcurrently() {
                /**
                 * 默认msgs里只有一条消息，可以通过设置consumeMessageBatchMaxSize参数来批量接收消息
                 */
                @Override
                public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                	if (CollectionUtils.isEmpty(msgs)) {
                		log.info("接受到的mq消息为空，不处理，直接返回成功");
                        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                    }
                    MessageExt msg = msgs.get(0);
                    log.info("处理mq消息，ID{}", msg.getMsgId());
                    return handler(msg);
                }
                
            });
            /**
             * Consumer对象在使用之前必须要调用start初始化，初始化一次即可<br>
             */
            consumer.start();
            log.info("{} Started.",this.getClass().getSimpleName());
        } catch (Exception e) {
            log.error("init MQ ERROR: ",e);
        }
    }
    
    protected ConsumeConcurrentlyStatus handler(MessageExt messageExt) {
        MQConsumeResult result = new MQConsumeResult();
        String msgId = null;
        String msg = null;
        CalcContractDto info = null;
        String key = null;
        try {
            msgId = messageExt.getMsgId();
            msg = new String(messageExt.getBody(), StandardCharsets.UTF_8);
            MqUtil.startLogTrack(msgId); 
            info = JSON.parseObject(msg, CalcContractDto.class);
            //MQ消息保存
            calcContractMqManager.saveMq(msgId, msg, info.getDeliveryDetailId());
            //内容空值判断
            if (StringUtils.isEmpty(info.getDeliveryDetailId())) {
            	log.error("接收供应链消息-必输项为空msgId:{},msg:{},sapAccountInfo:{}", msgId, msg, info);
            	result.setSuccess(true);
            	return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
            key = CacheKeyConstants.getContractIndex(info.getDeliveryDetailId()); 
            //添加幂等校验，时间3个月
            Long distributedLockAtom = gcacheUtil.distributedLockAtom(key, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
            if(distributedLockAtom != 1) {
				result.setSuccess(true);
				return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
            log.info("接收供应链消息开始msgId:{},msg:{},info:{}", msgId, msg, info);
            // 后续操作,数据入库
            CalcContract orderInfo = converterFromCalcContractDto(info);
            Long calcRecordId = seqGenUtil.nextCrpContractSeq();// 加入id生成器
            orderInfo.setId(calcRecordId);
            ScsContractDto scsContract = info.getScsContract();
            if(scsContract != null) {
            	String comprehensiveContribution = scsContract.getComprehensiveContribution();
            	orderInfo.setComprehensiveContribution(comprehensiveContribution);
            	calcContractManager.saveDetialInfo(scsContract, calcRecordId, orderInfo);
            }
            try {
                LocalDto localDto = new LocalDto();
                localDto.setBeginTime(System.currentTimeMillis());
                localDto.setType(2);
                isoOrderService.handler(info.getSaleChannel(), info.getDeliveryDetailId());
            }catch (Exception e){
                OrderCalcDto orderCalcDto = CalcLocal.getLocalDto().getOrderCalcDto();
                if(null == orderCalcDto) {
                    log.error("so合同信息入库以后计算异常,sapDetailId:{},channel:{},errorMsg:{}", info.getDeliveryDetailId(), info.getSaleChannel(), e);
                }else {
                    ProblemDto problemDto = new ProblemDto(orderCalcDto.getOrderId(), orderCalcDto.getChannelCalcNo(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
                    String msgError = String.format("orderId: %s,sapDetailId: %s,计算出现异常,异常信息: %s", orderCalcDto.getOrderId(), info.getDeliveryDetailId(),e.getMessage());
                    log.error("so触发计算异常,sapDetailId:{},exception:{}",info.getDeliveryDetailId(), e);
                    problemDto.setDescription(msgError);
                    problemDto.setPlanId(problemDto.getPlanId());
                    problemService.addData(problemDto, ProblemEnum.CODE_113);
                }

                CalcRetry calcRetry = new CalcRetry();
                calcRetry.setType(RetryJobEnum.SO_CALC_RETRY.getCode());
                calcRetry.setMsgBody(info.getSaleChannel() + "-" + info.getDeliveryDetailId());
                calcRetryCopeService.insertRetry(calcRetry);
            }
            log.info("接收供应链消息完成msgId:{},msg:{},info:{}", msgId, msg, info);
            result.setSuccess(true);
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        } catch (Exception e) {
        	if(StringUtils.isNotBlank(key)) {
        		String[] redisKey = {key};
        		gcacheUtil.deleteKey(redisKey);
        	}
            log.error("接收供应链消息异常msgId:{},msg:{},info:{}", msgId, msg, info, e);
            result.setSuccess(false);
            return ConsumeConcurrentlyStatus.RECONSUME_LATER;
        } finally {
            MqUtil.stopLogTrack();
        }
    }
    
    private CalcContract converterFromCalcContractDto(CalcContractDto info) {
    	CalcContract contract = new CalcContract();
	    contract.setDeliveryDetailId(info.getDeliveryDetailId());//sapDetailId
	    contract.setSapSaleOrderNum(info.getSapSaleOrderNum());//sap销售单号
	    contract.setSapItemNum(info.getSapItemNum());//sap行项目号
	    contract.setSaleChannel(info.getSaleChannel());//销售渠道
	    contract.setSkuNo(info.getSkuNo());
	    contract.setSkuNum(info.getSkuNum());//商品数量
	    contract.setPlace(info.getPlace());//todo 地点
	    contract.setStockPlace(info.getStockPlace());//库存地点
	    contract.setBusinessModel(info.getBusinessModel());//业务机型
	    contract.setDeliverCompanyCode(info.getDeliverCompanyCode());//发货公司代码
	    contract.setSaleMethod(info.getSaleMethod());//销售方式
	    contract.setOperate(info.getOperate());//0新增，1修改
	    contract.setCommissionSendTime(info.getCommissionSendTime());//配置端发送时间戳到ms
	    contract.setSapOperateTime(info.getSapOperateTime());//操作时间,到秒级
    	return contract;
    }
    
    @PreDestroy
    public void destroy(){
    	if(consumer!=null){
    		consumer.shutdown();
    	}
    }
    
}
