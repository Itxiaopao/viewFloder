package com.gome.crp.calc.constants;

public enum SapEnum {
    /**
     * 借/贷标识(H贷方,减收货数量,S借方.加收货数量)
     */
    SHKZG_H("H", "贷方,减收货数量"),
    SHKZG_S("S", "借方,加收货数量"),

    /**
     * 取消标识(没有退单号的给正单号打取消标识X，其它N)
     */
    QXBS_X("X", "没有退单号的给正单号打取消标识"),
    QXBS_N("N", "其它"),


    ;
    private String code;
    private String msg;

    SapEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
