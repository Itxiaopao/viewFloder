package com.gome.crp.calc.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

import java.util.*;

@Component
@Slf4j
public class GcacheUtil {
    @Autowired
    private Gcache gcache;

    public void putKeyValue(String key, String value) {
        gcache.set(key, value);
    }

    public void putKeyValue(String key, int seconds, String value) {
        gcache.setex(key, seconds, value);
    }

    public String getKeyValue(String key) {
        return gcache.get(key);
    }

    public void putKeyObject(String key, Object object) {
        putKeyValue(key, JSON.toJSONString(object));
    }

    public Object getKeyObject(String key, Class objectClass) {
        String keyValue = getKeyValue(key);
        return JSONObject.parseObject(keyValue, objectClass);
    }

    /**
     * 分布式锁(原子)
     *
     * @param lockKey  key
     * @param lockTime 时间（单位秒）
     * @param value    value
     * @return 返回1表示第一次上锁成功，返回0表示加锁失败
     */
    public Long distributedLockAtom(String lockKey, int lockTime, String value) {
        return gcache.setnxex(lockKey, lockTime, value);
    }

    /**
     * 设置分布式锁非原子（适用于加锁处理完逻辑释放锁）
     *
     * @param loclKey
     * @param value
     * @return
     */
    public Long distributedLock(String loclKey, String value) {
        return gcache.setnx(loclKey, value);
    }

    /**
     * 设置过期时间
     *
     * @param loclKey
     * @param expireTime
     * @return
     */
    public Long setExpireTime(String loclKey, int expireTime) {
        return gcache.expire(loclKey, expireTime);
    }

    /**
     * 删除缓存、删除锁
     *
     * @param key
     * @return
     */
    public Long deleteKey(String[] key) {
        return gcache.del(key);
    }

    public Long putQueueRight(String key, String value) {
        return gcache.rpush(key, value);
    }

    public Long putQueueLeft(String key, String value) {
        return gcache.lpush(key, value);
    }

    /**
     * 阻塞指定时间去队列左侧获取
     *
     * @param time 时间（单位秒）
     * @param key
     * @return
     */
    public Object getQueryFromLeft(int time, String key) {
        return gcache.blpop(time, key);
    }

    public Object getQueryFromRight(int time, String key) {
        return gcache.brpop(time, key);
    }

    /**
     * @param key
     * @param score 分值
     * @param value
     * @return
     */
    public Long putZset(String key, double score, String value) {
        return gcache.zadd(key, score, value);
    }

    /**
     * 给key的set里面value的值加分
     * 一：此set里面如果value不存在的话即在set里面增加此元素，分值为score
     * 二：此set里面如果存在此元素的话分值为原来的分值+score
     *
     * @param key
     * @param score
     * @param value
     */
    public Double zaddScoreByKey(String key, double score, String value) {
        return gcache.zincrby(key, score, value);
    }

    /**
     * 获取指定分值范围（闭区间）内的元素
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    public Set<String> getFromSetByScoreRange(String key, double min, double max) {
        return gcache.zrangeByScore(key, min, max);
    }

    /**
     * 根据索引获取（从0开始，0为第一个元素）
     * 例：min为0 max为1 获取所以为0到1之间的元素
     * min为0 max为1时获取的是所有的元素
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    public Set<String> getFromSetByIndexRange(String key, int min, int max) {
        return gcache.zrange(key, min, max);
    }

    /**
     * 倒序（以score的值递增排序）获取zset里面的值
     * 里 reverseIndex 0 ，length 1  从最后一个开始是获取两个元素
     *
     * @param key
     * @param reverseIndex
     * @param length
     * @return
     */
    public Set<String> getReverseFromSetByIndexRange(String key, int reverseIndex, int length) {
        return gcache.zrange(key, reverseIndex, reverseIndex);
    }

    /**
     * 获取zset的元素个数
     *
     * @param key
     * @return
     */
    public Long getCountOfSet(String key) {
        return gcache.zcount(key, 0, -1);
    }

    /**
     * 处理hash数据结构
     *
     * @param key
     * @param value
     * @return
     */
    public String putMap(String key, Map<String, String> value) {
        return gcache.hmset(key, value);
    }

    /**
     * 从hash里面获取String集合
     *
     * @param key
     * @param field
     * @return
     */
    public List<String> getValueFromHash(String key, String... field) {
        return gcache.hmget(key, field);
    }

    /**
     * 从hash里面获取String集合
     *
     * @param key
     * @param field
     * @return
     */
    public List getObjectFromHash(String key, Class className, String... field) {
        List<String> hmget = gcache.hmget(key, field);
        ArrayList<Object> objects = new ArrayList<>(hmget.size());
        for (String thisStr : hmget
        ) {
            Object o = JSONObject.parseObject(thisStr, className);
            objects.add(o);
        }
        return objects;
    }

    /**
     * 查询hash（无feild入参）
     *
     * @param key
     * @param className
     * @return
     */
    public List getObjectFromHashNoField(String key, Class className) {
        long startTime = System.currentTimeMillis();
        Map<String, String> hashMap = gcache.hgetAll(key);
        log.info("通过key读gcache耗时: {}", System.currentTimeMillis() - startTime);
        Set<Map.Entry<String, String>> entries = hashMap.entrySet();
        List classNames = new ArrayList<>(entries.size());
        Iterator<Map.Entry<String, String>> iterator = entries.iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, String> next = iterator.next();
            Object o = JSONObject.parseObject(next.getValue(), className);
            classNames.add(o);
        }
        return classNames;
    }

    /**
     * @param key
     * @return
     */
    public Long incr(String key) {
        return gcache.incr(key);
    }

    /**
     * @param key
     * @return
     */
    public Long incrBy(String key, long integer) {
        return gcache.incrBy(key, integer);
    }

    /**
     * @param key
     * @return
     */
    public Long decr(String key) {
        return gcache.decr(key);
    }

    public Long decrBy(String key, long integer) {
        return gcache.decrBy(key, integer);
    }

    public Boolean exists(String key) {
        return gcache.exists(key);
    }

    /**
     * 判断set是否存在
     * @param key
     * @param value
     * @return
     */
    public Boolean sismember(String key,String value){
        return gcache.sismember(key,value);
    }


    /**
     *
     * @param key
     * @param seconds
     * @param value
     * @return
     */
    public Long setnxex(String key, int seconds, String value){
        return gcache.setnxex(key, seconds, value);
    }

    /**
     *
     * @param key
     * @param value
     * @return
     */
    public String set(String key, String value){
        return gcache.set(key, value);
    }

    /**
     *
     * @param key
     * @param value
     * @return
     */
    public Long setnx(String key, String value){
        return gcache.setnx(key, value);
    }

    /**
     *
     * @param key
     * @param seconds
     * @param value
     * @return
     */
    public String setex(String key, int seconds, String value){
        return gcache.setex(key, seconds, value);
    }

    /**
     *
     * @param key
     * @return
     */
    public Long del(String key){
        return gcache.del(key);
    }

    /**
     *
     * @param key
     * @return
     */
    public String get(String key){
        return gcache.get(key);
    }


}
