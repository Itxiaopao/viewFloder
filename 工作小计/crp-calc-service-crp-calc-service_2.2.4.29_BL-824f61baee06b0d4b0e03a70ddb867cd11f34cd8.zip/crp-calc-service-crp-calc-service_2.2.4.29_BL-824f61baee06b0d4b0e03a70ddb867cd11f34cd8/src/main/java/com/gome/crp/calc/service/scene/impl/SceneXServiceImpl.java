package com.gome.crp.calc.service.scene.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.gome.crp.calc.client.employee.IGomeEmployeeInfoService;
import com.gome.crp.calc.dto.employee.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.gome.crp.calc.client.coupon.IConsumerConponService;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.receiver.ILarkService;
import com.gome.crp.calc.client.receiver.IStoreSubscribeService;
import com.gome.crp.calc.client.receiver.ITelTradingService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.dto.profitDto.Receiver;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.scene.abstr.AbstractSceneService;
import com.gome.staff.bind.model.domain.StaffBind;

import lombok.extern.slf4j.Slf4j;

/**
 * x场景 迁移 SceneXServiceImpl2
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class SceneXServiceImpl extends AbstractSceneService {

	public String key = "1";

	@Autowired
	private IStaffInfoService staffInfoService;
	@Autowired
	private IConsumerConponService consumerConponService;
	@Autowired
	private IProblemService problemService;
	@Autowired
	private IStoreSubscribeService storeSubscribeService;
	@Autowired
	private ITelTradingService telTradingService;
	@Autowired
	private ILarkService larkService;
	@Autowired
	private IGomeEmployeeInfoService gomeEmployeeInfoService;

	@Override
	public List<ProfitDto> calc(OrderCalcDto orderDto, PlanDto planDto) {
		List<ProfitDto> list = null;
		String scene = BaseConstants.SCENE_X;
		boolean checPlanCanCalc = this.checkPlanCanCalc(orderDto, planDto, scene);
		if(!checPlanCanCalc) {
			return list;
		}
		List<PersonDto> personList = this.getProfitPerson(orderDto, planDto);
		if (personList != null && personList.size() > 0) {
			int size = personList.size();
			list = new ArrayList<>(size);
			List<BigDecimal> formula = this.sceneFormula(orderDto, planDto, size, scene);
			int i = 0;
			for (PersonDto personDto : personList) {
				ProfitDto profit = new ProfitDto();
				profit.setPersonDto(personDto);
				profit.setScenes(scene);
				profit.setAwardAmount(formula.get(i));
				i++;
				list.add(profit);
			}

			this.addRewardCommit(orderDto, planDto, list, scene);
		} else {
			log.info(String.format("[Warn]x场景获利人:null, orderId:%s, planId:%d", orderDto.getOrderId(), planDto.getPlanId()));
			// 入问题小工具
			addProblem(orderDto, planDto, "X场景获利人:null", ProblemEnum.CODE_124);
		}
		log.info(String.format("X场景-按计划获得提奖获利人[结果], orderId:%s, planId:%s, 计算结果:%s", orderDto.getOrderId(),
				planDto.getPlanId(), JSONObject.toJSONString(list)));
		return list;
	}

	@Override
	public List<PersonDto> getProfitPerson(OrderCalcDto orderDto, PlanDto planDto) {
		List<PersonDto> pl = this.logicSceneXProfitPersons(orderDto, planDto);
		return pl;
	}

	@Override
	public String getScene() {
		return BaseConstants.SCENE_X;
	}

	/**
	 * 
	 * @param orderDto
	 * @return
	 */
	private List<PersonDto> logicSceneXProfitPersons(OrderCalcDto orderDto, PlanDto planDto) {
		// 订单id
		String orderId = orderDto.getOrderId();
		// 判断是否存在门店
		String shopNo = orderDto.getShopNo();
		if (StringUtils.isBlank(shopNo)) {
			log.info(String.format("X场景下获利人信息查询[失败]: orderId:%s, shopNo为NULL", orderId));
			return null;
		}
		// 线下二级品类
		String eaCateSecond = orderDto.getEaGroupCodeSecond();
		if (StringUtils.isBlank(eaCateSecond)) {
			log.info(String.format("X场景下获利人信息查询[失败], orderId:%s, shopNo:%s, eaCateSecond:NULL", orderId,
					shopNo));
			return null;
		}
		// 线下二级品牌
		String eaBrandCode = orderDto.getEaBrandCode();
		if (StringUtils.isBlank(eaBrandCode)) {
			log.info(String.format(
					"X场景下获利人信息查询[失败], orderId:%s, shopNo:%s, eaCateSecond:%s, eaBrandCode:NULL", orderId,
					shopNo, eaCateSecond));
			return null;
		}
		/**
		 * 1. 有开单人: a,判断开单人员工身份匹配成功 -> 返回获利人集合 b,判断开单人员身份信息不匹配 -> 查询门店促销员信息
		 * 
		 * 2. 无开单人: 首先判断商品分享人, 其次判断券分享信息 a.首先判断商品分享人的员工身份, 分享人匹配员工身份一致, 返回获利人集合,
		 * 身份不匹配查询门店促销员 b.券分享人信息 是否存在券分享人信息, 分享人匹配员工身份一致, 返回获利人身份, 身份匹配不一致, 取门店促销员信息
		 * 
		 */

		/**
		 * 1.判断开单人id 员工id
		 * <p>
		 * 2.判断分享人 会员id userId
		 * <p>
		 * 3.判断券分享人会员id userId
		 * <p>
		 */
		// 开单员工id
		log.info(String.format(
				"X场景下获利人信息查询[COPE], orderId:%s, shopNo:%s, eaCateSecond:%s, eaBrandCode:%s", orderId,
				shopNo, eaCateSecond, eaBrandCode));
		String storeSellerId = orderDto.getStoreSellerId(); // 开单人信息
		List<PersonDto> pl = null; // 匹配返回的数据
		String log_pre = String.format("orderId:%s, planId:%s, seller:%s, coupon:%s",
				orderId, planDto.getPlanId(), storeSellerId, JSONObject.toJSONString(orderDto.getCouponsDtoList()));
		log.info("X场景下获利人信息查询字段, " + log_pre);
		// 开单人身份: 有
		if (StringUtils.isNotBlank(storeSellerId)) {
			log.info(String.format("X场景下获利人信息查询[COPE-开单人], orderId:%s, 开单人Id:%s", orderId, storeSellerId));
			// 如果是开单人信息, 直接查询匹配促销员身份,身份匹配正常返回, 匹配不成功查询厂家促销员信息
			pl = this.endQueryShareStaffsOrSellers(storeSellerId, orderDto, null,ProfitBehaviorEnum.BILLING.getCode());
		} else {
			//modify by lsx begin 2020.6.25 承接人判断
			pl = endQueryReceiver(orderDto);
			if(CollectionUtils.isEmpty(pl)){
				pl = this.getShareUserLogic(orderDto);
			}
			//modify by lsx end 2020.6.25 承接人判断
		}
		if(CollectionUtils.isEmpty(pl)){
			log.info(String.format("未查询到员工信息,场景X, orderId:%s, planId:%s", orderId, planDto.getPlanId()));
			this.addProblem(orderDto,planDto, "X未匹配到获利人信息", ProblemEnum.CODE_121);
		}
		return pl;
	}
	
	/**
	 * 分享人 + 券分享人
	 * 开单人身份无: 获取分享人id
	 * 
	 * @param orderDto
	 * @return
	 */
	private List<PersonDto> getShareUserLogic (OrderCalcDto orderDto) {
		String orderId = orderDto.getOrderId();
		String storeLevel = BaseConstants.STAFF_LEVEL_4 + "";// 4 门店
		String shareUserId = orderDto.getShareUserId(); // 赋值 -> 分享人国美会员userId
		List<PersonDto> pl = null; // 匹配返回的数据
		// 如果分享人信息不存在
		if(StringUtils.isBlank(shareUserId)){
			// 券逻辑获取分享人
			pl = this.queryStaffByCouponUserId(storeLevel, orderDto);
			return pl;
		}
		// 分享人存在 -> 员工身份
		log.info(String.format("X场景下获利人信息查询[COPE-分享人], orderId:%s, 分享人Id:%s", orderId, shareUserId));
		StaffBindDto staff = staffInfoService.getStaffInfoByUid(shareUserId);
		// 员工身份判断: 1有查询匹配分享人员工信息, 2没有走券逻辑
		if (staff != null) {
			// 1很够查询到分享人信息, 匹配分享人, 如果没有, 走券逻辑
			pl = this.queryStaffByShareUserId(staff.getStaffCode(), storeLevel, orderDto);
			return pl;
		}else {
			// 2分享人查询的数据不存在, 查询券分享人关系
			pl = this.queryStaffByCouponUserId(storeLevel, orderDto);
			return pl;
		}
	}
	
	
	
	/**
	 * 分享人 身份匹配(分享人, 券)
	 */
	private List<PersonDto> queryStaffByShareUserId(String staffCode, String storeLevel, OrderCalcDto orderDto) {
		
		// 判断是否存在门店
		String shopNo = orderDto.getShopNo();
		// 分享人信息
		String shareUserId = orderDto.getShareUserId();
		// 线下二级品类
		String eaCateSecond = orderDto.getEaGroupCodeSecond();
		// 线下二级品牌
		String eaBrandCode = orderDto.getEaBrandCode();
		List<EmployeeInfoDto> query = null;
		List<PersonDto> personList = null;
		// 查询分享人(员工)身份
		List<String> staffcodes = Arrays.asList(staffCode);
		query = this.queryGomeEmployeeInformation(orderDto.getOrderId(), eaCateSecond, eaBrandCode, staffcodes, shopNo, storeLevel);
		// 匹配分享人(员工)信息
		personList = this.shareStaffMatchRes(query, orderDto, shareUserId,ProfitBehaviorEnum.SERVICE_SHARE_PRODUCTS.getCode());
		// 分享人员工身份不匹配
		if (CollectionUtils.isEmpty(personList)) {
			// 券分享人信息匹配
			personList = this.queryStaffByCouponUserId(storeLevel, orderDto);
		}
		return personList;
	}
	
	/**
	 * 券匹配 员工
	 * @param orderDto
	 * @param storeLevel
	 * @return
	 */
	private List<PersonDto> queryStaffByCouponUserId(String storeLevel, OrderCalcDto orderDto) {
		String orderId = orderDto.getOrderId();
		// 判断是否存在门店
		String shopNo = orderDto.getShopNo();
		// 线下二级品类
		String eaCateSecond = orderDto.getEaGroupCodeSecond();
		// 线下二级品牌
		String eaBrandCode = orderDto.getEaBrandCode();
		
		List<PersonDto> personList = null;
		// 券分享人会员id
		String couponMemberId = this.getCouponMemberId(orderDto);
		log.info(String.format("X场景下获利人信息查询[COPE-券分享人], orderId:%s, 券分享人Id:%s", orderId, couponMemberId));
		// 券信息: 无, 匹配促销员
		if(StringUtils.isBlank(couponMemberId)) {
			personList = this.querySellers(eaCateSecond, eaBrandCode, shopNo, storeLevel, orderDto);
			return personList;
		}
		// 券分享: 有, 券分享人会员id -> 员工Id
		StaffBindDto staff = staffInfoService.getStaffInfoByUid(couponMemberId);
		if (staff != null) {
			String staffCode = staff.getStaffCode();
			// 获取员工 以及 促销员信息
			personList = this.endQueryShareStaffsOrSellers(staffCode, orderDto, couponMemberId,ProfitBehaviorEnum.SERVICE_SHARE_VOUCHER.getCode());
		}else {
			// 券信息: 无, 匹配促销员
			personList = this.querySellers(eaCateSecond, eaBrandCode, shopNo, storeLevel, orderDto);
		}
		return personList;
	}
	
	/**
	 * 最后: 查询厂家促销员并匹配信息
	 */
	private List<PersonDto> endQueryShareStaffsOrSellers(String staffCode, OrderCalcDto orderDto, String shareUserId,Integer profitBehaviorCode) {
		
		// 判断是否存在门店
		String shopNo = orderDto.getShopNo();
		// 线下二级品类
		String eaCateSecond = orderDto.getEaGroupCodeSecond();
		// 线下二级品牌
		String eaBrandCode = orderDto.getEaBrandCode();
		// 4 门店
		String storeLevel = BaseConstants.STAFF_LEVEL_4 + "";
		// 查询分享人信息
		List<PersonDto> personList = this.queryOnlyShareStaffs(staffCode, orderDto, shareUserId,profitBehaviorCode);
		//modify by lsx begin 2020.6.25 承接人判断
		if(CollectionUtils.isEmpty(personList)) {
			personList = endQueryReceiver(orderDto);
		}
		//modify by lsx end 2020.6.25 承接人判断
		// 匹配不一致 逻辑向下
		if(CollectionUtils.isEmpty(personList)) {
			// 分享人信息无得情况下, 查询厂家促销员信息
			personList = this.querySellers(eaCateSecond, eaBrandCode, shopNo, storeLevel, orderDto);
			
		}
		return personList;
	}
	
	/**
	 * 只查询厂家促销员并匹配信息
	 */
	private List<PersonDto> queryOnlyShareStaffs(String staffCode, OrderCalcDto orderDto, String shareUserId,Integer profitBehaviorCode) {
		// 判断是否存在门店
		String shopNo = orderDto.getShopNo();
		// 4 门店
		String storeLevel = BaseConstants.STAFF_LEVEL_4 + "";
		List<EmployeeInfoDto> query = null;
		List<PersonDto> personList = null;
		List<String> staffCodes = Arrays.asList(staffCode);
		// 查询员工信息 -> codes
		query = this.queryGomeEmployeeInformation(orderDto.getOrderId(), "", "", staffCodes, shopNo, storeLevel);
		// 匹配分享人员工信息 -> 和订单信息是否一致 
		personList = this.shareStaffMatchRes(query, orderDto, shareUserId,profitBehaviorCode);
		return personList;
	}
	
	/**
	 * 查询厂家促销员并匹配信息
	 * @param eaCateSecond
	 * @param eaBrandCode
	 * @param shopNo
	 * @param storeLevel
	 * @param orderDto
	 * @return
	 */
	private List<PersonDto> querySellers(String eaCateSecond, String eaBrandCode, String shopNo, String storeLevel, OrderCalcDto orderDto) {
		List<PersonDto> personList = null;
		StaffsIsMainDto staffs = this.queryIsMainStoreSellers(eaBrandCode, eaCateSecond, shopNo, orderDto.getOrderId());
		if(null == staffs) {
			return personList;
		}
		// 主营列表
		List<EmployeeInfoDto> mainList = staffs.getMainStaffs();
		// 兼营列表
		List<EmployeeInfoDto> unmainList = staffs.getUnMainStaffs();
		// 对于含有主营员工来说， 优先， 没有主营员工，在选兼营员工
		if (CollectionUtils.isNotEmpty(mainList)) {
			personList = this.copyPropertiesByEmpls(mainList, shopNo, orderDto.getSupplier(), BaseConstants.IS_MAIN_INT_Y,ProfitBehaviorEnum.MASTER_AVERAGE.getCode());
			log.info(String.format("X场景门店促销员匹配结果[主营], orderId:%s, shopNo:%s, 品牌:%s, 品类:%s,  成员列表:%s", 
					orderDto.getOrderId(), shopNo, orderDto.getEaBrandCode(), orderDto.getEaGroupCodeSecond(), JSONObject.toJSONString(personList)));
		} else if (CollectionUtils.isNotEmpty(unmainList)) {
			personList = this.copyPropertiesByEmpls(unmainList, shopNo, orderDto.getSupplier(), BaseConstants.IS_MAIN_INT_N,ProfitBehaviorEnum.PARTTIME_AVERAGE.getCode());
			log.info(String.format("X场景门店促销员匹配结果[兼营], orderId:%s, shopNo:%s, 品牌:%s, 品类:%s, 成员列表:%s", 
					orderDto.getOrderId(), shopNo, orderDto.getEaBrandCode(), orderDto.getEaGroupCodeSecond(), JSONObject.toJSONString(personList)));
		}
		return personList;
	}

	/**
	 * 获取券履历i
	 * 
	 * @param orderDto
	 * @return
	 */
	private String getCouponMemberId(OrderCalcDto orderDto) {
		// 券信息 -> 领券人历史信息 -> 会员id
		String onlineId = null;
		List<OrderCalcCouponDto> couponsDtoList = orderDto.getCouponsDtoList();
		if (couponsDtoList != null && couponsDtoList.size() > 0) {
			List<OrderCalcCouponDto> cdList = couponsDtoList.stream().map(e -> {
				OrderCalcCouponDto target = new OrderCalcCouponDto();
				BeanUtils.copyProperties(e, target);
				return target;
			}).collect(Collectors.toList());
			// 判断券分享人是否存在-> 会员id
			log.info(String.format("x场景-查询券分享人id查询, orderId:%s, userId:%s, couponList:%s", orderDto.getOrderId(), orderDto.getUserId(), cdList));
			onlineId = consumerConponService.queryCouponGiveInfo(cdList, orderDto.getUserId());
			log.info(String.format("x场景-查询券分享人id查询, orderId:%s, result:%s", orderDto.getOrderId(), onlineId));
		}
		return onlineId;
	}

	/**
	 * 赋值结果
	 */
	private List<PersonDto> copyPropertiesByEmpls(List<EmployeeInfoDto> is_mainList, String shopNo, String orderSupplier,
			int isMain,Integer profitBehaviorCode) {
		List<String> staffCodes = is_mainList.stream().map(x -> x.getBaseInfo().getEmployeeId()).collect(Collectors.toList());
		List<PersonDto> reList = new ArrayList<>();
		Map<String, String> userIdMap = this.matchStaffCodetoId(staffCodes);
		for (EmployeeInfoDto empl : is_mainList) {
			PersonDto p = this.copyProperies(empl, shopNo, orderSupplier, null, isMain,profitBehaviorCode);
			p.setUserId(userIdMap.get(empl.getBaseInfo().getEmployeeId())); // 匹配员工id -> 在线id
			reList.add(p);
		}
		return reList;
	}


	/**
	 * 匹配开单人，分享人，券分享人 information
	 *
	 * null: 表示厂家促销员， 没有分享者Id
	 * 
	 * @since jdk 1.8
	 */
	private List<PersonDto> shareStaffMatchRes(List<EmployeeInfoDto> query, OrderCalcDto orderDto, String sharsUserId,Integer profitBehaviorCode) {
		if (CollectionUtils.isEmpty(query)) {
			return null;
		}
		// 订单id
		String orderId = orderDto.getOrderId();
		// 判断是否存在门店
		String shopNo = orderDto.getShopNo();
		// 线下二级品类
		String eaCateSecond = orderDto.getEaGroupCodeSecond();
		// 线下二级品牌
		String eaBrandCode = orderDto.getEaBrandCode();
		// 供应商Id
		String orderSupplier = orderDto.getSupplier();
		// 分享人只有一个员工
		EmployeeInfoDto empl = query.get(0);
		// 判断商品分享人 计算x
		String employeeId = empl.getBaseInfo().getEmployeeId();
		List<GomeCategoryBrand> gsscbList = empl.getGsscbList();
		if(gsscbList == null || gsscbList.size() <= 0) {
			log.info(String.format("x场景分享人身份[不匹配]品牌品类集合 gsscbList 为NULL, employeeId:%s, orderId:%s, 品牌:%s | 品类:%s ", employeeId, orderId, eaBrandCode, eaCateSecond));
			return null;
		}
		// 判断品类品牌
		boolean gssAnyMatch = gsscbList.stream()
				.anyMatch(x -> eaBrandCode.equals(x.getBrandCode()) && eaCateSecond.equals(x.getCategoryCode()));
		if (!gssAnyMatch) {
			log.info(String.format("x场景分享人身份[不匹配]品类品牌不匹配, employeeId:%s, orderId:%s, 品牌:%s | 品类:%s ", employeeId, orderId, eaBrandCode, eaCateSecond));
			return null;
		}
		// 排重，获取is_main字段数据
		Integer is_main = null;
		Stream<String> distinct = gsscbList.stream().filter(
				gcb -> eaBrandCode.equals(gcb.getBrandCode()) && eaCateSecond.equals(gcb.getCategoryCode()))
				.map(e -> e.getIsMain()).distinct();
		// 有一条主营数据即为主营, 否则为兼营, 匹配条件全部兼营数据, 防止数据空
		boolean match_is_main = distinct.allMatch(x -> BaseConstants.IS_MAIN_STR_N.equals(x));
		if (match_is_main) {
			is_main = BaseConstants.IS_MAIN_INT_N;
		} else {
			is_main = BaseConstants.IS_MAIN_INT_Y;
		}
		// 匹配门店信息
		List<GomeEmployeePostInformation> gepis = empl.getGomeEmployeePostInformationList();
		Optional<List<GomeEmployeePostInformation>> opGEPIS = Optional.ofNullable(gepis);
		gepis = opGEPIS.orElse(new ArrayList<>());
		boolean gepisAnyMatch = gepis.stream().anyMatch(x -> shopNo.equals(x.getShop()));
		if (!gepisAnyMatch) {
			log.info(String.format("x场景分享人身份[不匹配]门店编码信息不匹配, employeeId:%s, orderId:%s, shopNo:%s ", employeeId, orderId, shopNo));
			return null;
		}
		// 反查会员Id
		if(StringUtils.isBlank(sharsUserId)) {
			sharsUserId = this.getUserIdByStaffCode(employeeId);
		}
		PersonDto p = this.copyProperies(empl, shopNo, orderSupplier, sharsUserId, is_main,profitBehaviorCode);
		List<PersonDto> list = Arrays.asList(p);
		return list;
	}
	
	/**
	 * single 员工code 获取 userId
	 * @param staffcode
	 * @return
	 */
	private String getUserIdByStaffCode(String staffcode) {
		String uid = null;
		StaffBind staff = staffInfoService.getUserInfoByStaffCode(staffcode);
		if(staff != null) {
			uid = staff.getZxUid();
		}
		return uid;
	}
	
	/**
	 * 查询门店促销员信息
	 * 
	 * @param eaBrand
	 * @param eaCateSecond
	 * @param shopNo
	 * @param orderId
	 * @return
	 */
	private StaffsIsMainDto queryIsMainStoreSellers(String eaBrand, String eaCateSecond, String shopNo, String orderId) {
		StaffReqsDto staffReq = new StaffReqsDto();
		staffReq.setEaBrandCode(eaBrand);
		staffReq.setEaCateSecond(eaCateSecond);
		staffReq.setShopNo(shopNo);
		staffReq.setLogEmbedPort("场景-X, orderId:" + orderId);
		StaffsIsMainDto staffs = staffInfoService.queryIsMainStoreSellers(staffReq);
		return staffs;
	}
	
	/**
	 * 根据承接服务者匹配
	 */
	private List<PersonDto> endQueryReceiver( OrderCalcDto orderDto) {
		log.info("X场景下获利人信息查询[承接服务者匹配],orderId:{}",orderDto.getOrderId());
		List<Receiver> receiverList = selectReceiver(orderDto);
		if(!CollectionUtils.isEmpty(receiverList)){
			log.info("X场景下获利人信息查询[承接服务者匹配]承接人查询结果,receiverList:{},orderId:{}",JSON.toJSONString(receiverList),orderDto.getOrderId());
			for(Receiver  receiver : receiverList){
				String staffCode = receiver.getStaffId();
				log.info("X场景下获利人信息查询[承接服务者匹配],orderId:{},员工编码staffCode:{}",orderDto.getOrderId(),staffCode);
				List<PersonDto> personList = this.queryOnlyShareStaffs(staffCode, orderDto, null,receiver.getProfitBehaviorCode());
				log.info("X场景下获利人信息查询[承接服务者匹配]结束,orderId:{},员工编码staffCode:{},personList{}",orderDto.getOrderId(),staffCode,JSON.toJSONString(personList));
				if(!CollectionUtils.isEmpty(personList)){
					log.info("X场景下获利人信息查询[承接服务者匹配]结束返回给计算,orderId:{},员工编码staffCode:{},personList{}",orderDto.getOrderId(),staffCode,JSON.toJSONString(personList));
					return personList;
				}
			}
		}
		log.info("X场景下获利人信息查询[承接服务者匹配]结束无结果返回给计算,orderId:{}",orderDto.getOrderId());
		return null;
	}
	/**
	 * 从外呼、rm、到店查询承接者并且排序
	 * add by lsx
	 * @param orderDto
	 * @return
	 */
	private List<Receiver> selectReceiver(OrderCalcDto orderDto){
		List<Receiver> list = new ArrayList<Receiver>();
		List<Receiver> storeSubscribeList = storeSubscribeService.queryReceiver(orderDto);
		List<Receiver> telTradingList = telTradingService.queryReceiverList(orderDto);
		List<Receiver> larkList = larkService.queryReceiverList(orderDto);
		if(!CollectionUtils.isEmpty(storeSubscribeList)){
			list.addAll(storeSubscribeList);
		}
		if(!CollectionUtils.isEmpty(telTradingList)){
			list.addAll(telTradingList);
		}
		if(!CollectionUtils.isEmpty(larkList)){
			list.addAll(larkList);
		}
        Collections.sort(list, new Comparator<Receiver>(){  
            /*  
             * int compare(Receiver o1, Receiver o2) 返回一个基本类型的整型，  
             * 返回负数表示：o1 小于o2，  
             * 返回0 表示：o1和o2相等，  
             * 返回正数表示：o1大于o2。  
             */  
        	@Override
            public int compare(Receiver o1, Receiver o2) {  
                //按照金额大小进行降序排列  
                if(o1.getReceiverTime() < o2.getReceiverTime()){  
                    return 1;  
                }  
                return -1;  
            }
        });
		return list;
	}


	/**
	 * 封装查询门店员工信息
	 */
	private List<EmployeeInfoDto> queryGomeEmployeeInformation (String orderId, String categoryId, String brandId, List<String> employeeIdList, String shopNo, String storeLevel){
		log.info(String.format("Dubbo-查询门店员工入参: orderId-%s, 线下品牌-%s, 线下品类-%s, 门店编码-%s, 员工编码-%s",
					orderId, brandId, categoryId, shopNo, JSONObject.toJSONString(employeeIdList)) );
		List<EmployeeInfoDto> employeeInfoDtos = staffInfoService.queryGomeEmployeeInformation(orderId, categoryId, brandId, employeeIdList, shopNo, storeLevel);
		// 迁移主数据
//		List<EmployeeInfoDto> employeeInfoDtos = gomeEmployeeInfoService.queryGomeEmployeeInfos(orderId, categoryId, brandId, employeeIdList, shopNo);
		log.info(String.format("Dubbo-查询门店员工出参: orderId-%s, 结果-%s",
				orderId, JSONObject.toJSONString(employeeInfoDtos)));
		return employeeInfoDtos;
	}




}
