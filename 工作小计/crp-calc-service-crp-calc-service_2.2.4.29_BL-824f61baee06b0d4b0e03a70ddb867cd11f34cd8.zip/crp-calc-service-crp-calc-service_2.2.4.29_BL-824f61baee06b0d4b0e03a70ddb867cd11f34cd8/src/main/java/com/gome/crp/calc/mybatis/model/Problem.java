package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * 问题小工具 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class Problem {

	private Long id; //id
	private String msgId; //msgId
	private String msg; //msg
	private String orderId; //orderId
	private String deliveryId; //deliveryId
	private String skuNo; // skuNo
	private String detailId; // detailId
	private String description; //description
	private String planId; // 计划 id

	private String calcResultId; // 计算结果主表id

	private String userId; // 会员编码
	private String staffCode; // 员工编码

	private Date createTime; //createTime
	private Date updateTime; //updateTime
	private Integer isDelete; //isDelete
	private String channel; //订单渠道
}