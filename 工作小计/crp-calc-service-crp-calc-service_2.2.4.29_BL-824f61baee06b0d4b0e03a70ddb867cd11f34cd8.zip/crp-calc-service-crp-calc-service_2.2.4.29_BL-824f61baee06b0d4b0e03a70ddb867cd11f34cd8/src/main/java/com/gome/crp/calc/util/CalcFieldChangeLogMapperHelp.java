package com.gome.crp.calc.util;

import com.gome.crp.calc.mybatis.mapper.CalcFieldChangeLogMapper;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CalcFieldChangeLogMapperHelp implements InitializingBean {
    private static CalcFieldChangeLogMapper calcFieldChangeLogMapperHelp;
    @Autowired
    private CalcFieldChangeLogMapper calcFieldChangeLogMapper;

    @Override
    public void afterPropertiesSet() {
        calcFieldChangeLogMapperHelp = calcFieldChangeLogMapper;
    }

    public static CalcFieldChangeLogMapper get() {
        return calcFieldChangeLogMapperHelp;
    }
}
