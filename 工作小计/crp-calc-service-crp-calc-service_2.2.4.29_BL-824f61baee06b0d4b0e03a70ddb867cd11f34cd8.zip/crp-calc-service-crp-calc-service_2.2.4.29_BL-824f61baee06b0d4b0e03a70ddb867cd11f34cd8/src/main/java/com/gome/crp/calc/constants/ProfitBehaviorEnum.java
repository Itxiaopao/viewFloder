package com.gome.crp.calc.constants;

/**
 * 获利行为枚举
 * @author GOME
 *
 */
public enum ProfitBehaviorEnum {
	
	
//	获利行为：
	BILLING(1, "开单"),
	SERVICE_IM(2, "服务承接-IM"),
	SERVICE_OUTBOUND(3, "服务承接-外呼"),
	SERVICE_APPOINTMENT(4, "服务承接-预约到店"),
	SERVICE_SHARE_PRODUCTS(5, "分享商品"),
	SERVICE_SHARE_VOUCHER(6, "分享券"),
	MASTER_AVERAGE(7, "主营均分"),
	PARTTIME_AVERAGE(8, "兼营均分"),
	GATHERING_CUSTOMERS_STAFF(9, "集客"),
	SUPERIOR_STAFF(10, "上级"),
    ;
    ProfitBehaviorEnum(Integer code, String value) {
		this.code = code;
		this.value = value;
	}
	private Integer code;
    private String value;
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	

}
