package com.gome.crp.calc.util;

import com.gome.architect.idgnrt.IdGenUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 序列号生成工具类
 */
@Component
public class SeqGenUtil {
    @Autowired
    private IdGenUtil idGenUtil;
    @Value("${id.generator.crp.calc.common}")
    private String commonId;
    /**
     * result表id
     */
    @Value("${id.generator.crp.calc.result}")
    public String idResult;
    /**
     * result表id
     */
    @Value("${id.generator.crp.calc.no.result}")
    public String idNoResult;
    /**
     * record表id
     */
    @Value("${id.generator.crp.calc.record}")
    public String idRecord;
    /**
     * sap seq
     */
    @Value("${id.generator.crp.sap.seq}")
    public String idCrpSapSeq;
    /**
     * Contract seq
     */
    @Value("${id.generator.crp.contract.seq}")
    public String idCrpContractSeq;
    /**
     * ContractDetail seq
     */
    @Value("${id.generator.crp.contract.detail.seq}")
    public String idCrpContractDetailSeq;

    /**
     * OrderCalcMsg seq
     */
    @Value("${id.generator.crp.order.calc.msg.seq}")
    public String idCrpOrderCalcMsgSeq;
    
    /**
     * ContractDetailMsg seq
     */
    @Value("${id.generator.crp.contract.msg.seq}")
    public String idCrpContractMsgSeq;

    private Long nextSeqNum(String seqName) {
        if (seqName == null) {
            throw new IllegalArgumentException("入参错误");
        }
        return idGenUtil.next(seqName);
    }

    /**
     * 通用序列生成器
     * @return
     */
    public Long nextCrpCalcCommonId() {
        return nextSeqNum(commonId);
    }

    /**
     * 返回crp_calc_result这个表的主键id
     *
     * @param
     * @return
     */
    public Long nextCrpCalcResultId() {
        return nextSeqNum(idResult);
    }

    /**
     * 返回crp_calc_no_result这个表的主键id
     *
     * @param
     * @return
     */
    public Long nextCrpCalcNoResultId() {
        return nextSeqNum(idNoResult);
    }

    /**
     * 返回crp_calc_record这个表的主键id
     *
     * @param
     * @return
     */
    public Long nextCrpCalcRecordId() {
        return nextSeqNum(idRecord);
    }

    /**
     * @param
     * @return
     */
    public Long nextCrpSapSeq() {
        return nextSeqNum(idCrpSapSeq);
    }
    
    /**
     * 返回crp_calc_contract这个表的主键id
     * 
     * @param
     * @return
     */
    public Long nextCrpContractSeq() {
    	return nextSeqNum(idCrpContractSeq);
    }
    
    /**
     * 返回crp_calc_contract_detail这个表的主键id
     * 
     * @param
     * @return
     */
    public Long nextCrpContractDetailSeq() {
    	return nextSeqNum(idCrpContractDetailSeq);
    }

    /**
     * 返回crp_order_calc_msg这个表的主键id
     *
     * @param
     * @return
     */
    public Long nextCrpOrderCalcMsgSeq() {
        return nextSeqNum(idCrpOrderCalcMsgSeq);
    }
    
    /**
     * 返回crp_calc_contract_mq这个表的主键id
     * 
     * @param
     * @return
     */
    public Long nextCrpContractMsgSeq() {
    	return nextSeqNum(idCrpContractMsgSeq);
    }
}
