package com.gome.crp.calc.service.budget.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.client.erm.IErmService;
import com.gome.crp.calc.client.sap.IQueryPlanService;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.dto.ermDto.*;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.sapDto.ResourceOccupyReqDto;
import com.gome.crp.calc.dto.sapDto.ResourceReturnReqDto;
import com.gome.crp.calc.dto.sapDto.ResourceReturnResDto;
import com.gome.crp.calc.dto.sapDto.TerminatePlanReqDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.manager.sendBigData.SendBigDataCopeManager;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.mapper.SapRecordMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.service.budget.IBudgetService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.util.BigDecimalUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class BudgetService implements IBudgetService {


    @Autowired
    private IErmService iErmService;
    @Autowired
    private SapRecordMapper sapRecordMapper;
    @Autowired
    private IProblemService problemService;
    @Autowired
    private SendBigDataCopeManager sendBigDataCopeManager;
    @Autowired
    private IQueryPlanService iQueryPlanService;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private ICalcResultService iCalcResultService;



    @Override
    public List<CalcResult> occupyBudget(List<CalcResult> list) {
        log.info(String.format("预算场景-占用预算流程[START] results:%s", JSONObject.toJSONString(list)));
        return null;
    }

    /**
     * job1预算校验节点, 预算:未校验, CO,DL<p>
     * <p>
     * 无函(签约类型为无函资源池: 4,5), 预算扣减: 1.扣减成功: 设置预算校验成功,  2.扣减失败: job节点:失效, 预算状态:校验失败, 并禁用计划<p>
     * <p>
     * 其他, 预算状态: 成功
     *
     * @param list
     * @return
     */
    @Override
    public void occupyBudgetUncheckedDLOrCO(List<CalcResult> list) {
        log.info(String.format("预算场景job1-占用预算流程[START] results:%s", JSONObject.toJSONString(list)));
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        List<CalcResult> calcResults = new ArrayList<>(list.size());
        for (CalcResult calcResult : list) {
            String orderId = calcResult.getOrderId();
            String log_pre = String.format(" orderId:%s, deliveryId:%s", orderId, calcResult.getDeliveryId());
            log.info("预算场景job1-占用预算流程[COPE]:" + log_pre);
            Boolean isCheckBudget = isBudgetControl(calcResult);
            //费用严控:校验
            if (isCheckBudget) {
                ClientResultDTO result = occupyBudget(calcResult);
                //占用预算成功
                if (result.isSuccess()) {
                    log.info("预算场景job1-占用预算流程[严控+占用预算], 变更job状态1, 预算状态 1, " + log_pre);
                    OccupyBudgetResDto occupyBudgetResDto = (OccupyBudgetResDto) result.getData();
                    calcResults.add(buildUpdateCalcResult(calcResult.getId(), BaseConstants.CRD_JOB_STATUS_1, BaseConstants.BUDGET_CHECK_SUCCESS,occupyBudgetResDto == null ? null : occupyBudgetResDto.getSurplusAmount()));
                } else if (result.getCode() == 1) {
                    //占用预算失败,金额不足
                    log.info("预算场景job1-关闭计划, 占用预算不足, 占用预算返还状态:1, 订单jobStatus变更[4], " + log_pre);
                    // 加入问题小工具
                    this.addProblem(calcResult, "job1预算失败金额不足", ProblemEnum.CODE_102);
                    //关停计划（有重复关闭情况）
                    closePlan(calcResult);
                    // job=4
                    CalcResult updateCalcResult = buildUpdateCalcResult(calcResult.getId(), BaseConstants.CRD_JOB_STATUS_4, BaseConstants.BUDGET_CHECK_FAILED, null);
                    updateCalcResult.setFailureReason("job1预算失败金额不足");
                    calcResults.add(updateCalcResult);
                } else {
                    //占用预算异常
                    log.info("预算场景job1-占用预算[异常], "  + log_pre);
                }
                //费用不需要严控
            } else {
                log.info("预算场景job1-占用预算流程[不占用预算], 变更job状态1, 预算状态 1, " + log_pre);
                calcResults.add(buildUpdateCalcResult(calcResult.getId(), BaseConstants.CRD_JOB_STATUS_1, BaseConstants.BUDGET_CHECK_SUCCESS, null));
            }
        }
        if(CollectionUtils.isNotEmpty(calcResults)){
            // 更新数据数
            log.info(String.format("预算场景job1-占用预算流程, 变更job状态, results:%s", JSONObject.toJSONString(calcResults)));
            updateResultStatus(calcResults, 1);
            log.info(String.format("预算场景job1-占用预算流程[END]"));
        }
    }





    @Transactional
    private void updateResultStatus(List<CalcResult> calcResults, int job_num){
        calcResults.forEach( x -> {
            CalcResult condition = new CalcResult();
            // 订单状态不等于4的情况下加入插入校验
            condition.setId(x.getId());
            condition.setGomeStatus(x.getGomeStatus());
            int update = calcResultMapper.update(x, Wrappers.query(condition));
            if (update <= 0){
                log.info(String.format("预算场景job %d -更新结果[失败], resultId:%s", job_num, JSONObject.toJSONString(x)));
            }
        });
    }

//    /**
//     * logical: 预算扣减
//     * 1. 国美预算: 预算扣减
//     * 2. 无函状态Y: 预算扣减-拓客扣预算
//     * 3. 非差+供应商
//     * 4. 营销
//     *
//     * @param calcResult
//     * @return
//     */
//    private Boolean isCheckBudget(CalcResult calcResult) {
//        // 国美预算
//        log.info(String.format("预算占用检测订单, 费用承担方-%s, 促销费类型-%s, orderId-%s, planId-%s",
//                calcResult.getExpencesOfferType(), calcResult.getPromotionsType(), calcResult.getOrderId(), calcResult.getPlanId()));
//        if(BaseConstants.PLAN_EXPENSE_OFFER_TWO_TYPE.equals(calcResult.getExpencesOfferType() + "")){
//            return true;
//        }
//        // 营销预算
//        if (BaseConstants.PLAN_EXPENSE_OFFER_THIRD_TYPE.equals(calcResult.getExpencesOfferType() + "")){
//            return true;
//        }
//        // 非差 + 供应商
//        if (BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(calcResult.getPromotionsType() + "")
//                && BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE.equals(calcResult.getExpencesOfferType() + "")){
//            return true;
//        }
//        // 无函 y
//        return isHaveNoLetter(calcResult);
//    }

    /**
     * 判断是否是无函资源池
     *  无函资源池类型
     * @param calcResult
     * @return
     */
    private Boolean isHaveNoLetter(CalcResult calcResult) {
        //无函
        int letter = isLetter(calcResult);
        return letter == 2 ? true : false;
    }

    /**
     * 无函Y
     *
     * @param calcResult
     * @return
     */
    private Boolean isHaveNoLetterY(CalcResult calcResult) {
        //无函
        int letter = isLetter(calcResult);
        if (BaseConstants.SCENE_Y.equals(calcResult.getScenes()) && letter == 2) {
            return true;
        }
        return false;
    }

    /**
     * 是否有函
     *
     * @param calcResult
     * @return
     */
    private int isLetter(CalcResult calcResult) {
        String contractType = calcResult.getContractType();
        if (contractType != null){
            // 延保类型, contractType == null
            // 无签约类型
            if (BaseConstants.PLAN_SIGN_NO_TYPE.equals(contractType)) {
                return 0;
            }
            // 差异化 合同 + 协议
            if (BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(contractType) ||
                    BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(contractType) ||
                    BaseConstants.PLAN_SIGN_LETTER_TYPE.equals(contractType)) {
                return 1;
            }
            // 无函资源池类型
            if (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(contractType)
                    || BaseConstants.PLAN_SIGN_NO_LETTER_TYPE_SUPPLIER.equals(contractType)
                ) {
                return 2;
            }
        }
        throw new BusinessException(String.format("签约类型不正确, orderId:%s, calcResultId:%s, contractType:%s",
                calcResult.getOrderId(), calcResult.getId(), contractType));
    }

    /**
     * job2 job:预算校验节点, 预算:校验成功
     * 预算2 无含Y<p>
     * 是: sap确认收货(挂账表, crp_sap_record, 判断状态为 x或者1的表示确认收货) 执行, 1:job=2, 2:推送大数据job->2, 预算校验:成功<p>
     * 否: 1:job=2, 2:推送大数据job->2, 3:合同协议有含的此时需要挂账, 4:预算校验成功<p>
     *
     * @param list
     * @return
     */
    @Override
    public void occupyBudgetHaveNoLetterY(List<CalcResult> list) {
        log.info(String.format("预算场景job2-无函Y场景流程[START] results: %s", JSONObject.toJSONString(list)));
        if (CollectionUtils.isEmpty(list)) {
            return;
        }
        List<CalcResult> calcResults = new ArrayList<>(list.size());
        List<CalcResult> useToBigDataList = new ArrayList<>(list.size());
        for (CalcResult calcResult : list) {
            String log_pre = String.format(" orderId:%s, deliveryId:%s", calcResult.getOrderId(), calcResult.getDeliveryId());
            // 不是无函Y
            Boolean haveNoLetterY;
            try {
                haveNoLetterY = isHaveNoLetterY(calcResult);
            }catch (Exception e){
                log.info("预算场景job2-无函Y场景流程[订单签约类型判断异常], " + e.getMessage());
                continue;
            }
            if (!haveNoLetterY) {
                log.info("预算场景job2-无函Y场景流程[非无函Y4], 变更job状态2, 预算状态1, " + log_pre);
                calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_2);
                useToBigDataList.add(calcResult); // 推送大数据
                calcResults.add(buildUpdateCalcResult(calcResult.getId(), BaseConstants.CRD_JOB_STATUS_2, BaseConstants.BUDGET_CHECK_SUCCESS,null));
                continue;
            }
            // 确认收货
            Integer isReceiptGoods = calcResult.getIsReceiptGoods();
            if (isReceiptGoods != null && IsReceiptGoodsEnum.ALREADY_RECEIPT.getCode() == isReceiptGoods.intValue()) {
                log.info("预算场景job2-无函Y场景流程[无函Y-sap确认收货], 变更job状态2, 预算状态 1, " + log_pre);
                // sap挂账已收货 job= 2,4
                calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_2);
                useToBigDataList.add(calcResult); // 推送大数据
                calcResults.add(buildUpdateCalcResult(calcResult.getId(), BaseConstants.CRD_JOB_STATUS_2, BaseConstants.BUDGET_CHECK_SUCCESS,null));
            } else {
                log.info("预算场景job2-无函Y场景流程[sap挂账未收货], " + log_pre);
            }
        }
        if(CollectionUtils.isNotEmpty(useToBigDataList)){
            // send bigdata job = 2,4推大数据
            log.info(String.format("预算场景job2-无函Y场景流程-推送发送大数据[start], param: %s", JSONObject.toJSONString(useToBigDataList)));
            sendBigDataCopeManager.sendBigDataMSG(useToBigDataList);
            //更新推送大数据状态为已推送
            updatePushBigdataStatus(useToBigDataList);
            log.info(String.format("预算场景job2-无函Y场景流程-推送发送大数据[end]"));
        }
        if(CollectionUtils.isNotEmpty(calcResults)){
            // sap 挂账
            log.info(String.format("预算场景job2-无函Y场景流程-sap挂账-[START], param:%s", JSONObject.toJSONString(calcResults)));
            updateResultStatus(calcResults, 2);
            log.info(String.format("预算场景job2-无函Y场景流程-sap挂账-[END]"));
        }
    }

    private void updatePushBigdataStatus(List<CalcResult> useToBigDataList) {
        List<CalcResult> updateResultList = new ArrayList<>(useToBigDataList.size());
        for(CalcResult calcResult : useToBigDataList){
            CalcResult updateCalcResult = new CalcResult();
            updateCalcResult.setId(calcResult.getId());
            updateCalcResult.setIsPushBigdata(IsPushBigdataEnum.ALREADY_PUSH.getCode());
            updateResultList.add(updateCalcResult);
        }
        iCalcResultService.updateBatchById(updateResultList);
    }


    /**
     * copy properties by source calcResult and inside log journal
     *
     * @param calcResult
     * @return
     */
    private void addProblem(CalcResult calcResult, String problemMSG, ProblemEnum problemEnum) {
        String str = String.format("预算占用-异常加入问题小工具, calcResultId:%s, 问题信息:%s, 类型:%s", calcResult.getId(), problemMSG, problemEnum.getMsg());
        log.info(str, JSONObject.toJSONString(calcResult));
        ProblemDto pd = new ProblemDto(calcResult.getOrderId(), calcResult.getChannel(), calcResult.getSkuNo(), calcResult.getDetailId());
        pd.setDescription(problemMSG);
        pd.setCalcResultId(calcResult.getId() + "");
        pd.setPlanId(calcResult.getPlanId());
        problemService.addData(pd, problemEnum);
    }

    private CalcResult buildUpdateCalcResult(Long id, Integer jobStatus, Integer budgetStatus,Long surplusAmount) {
        CalcResult updateCalcResult = new CalcResult();
        updateCalcResult.setId(id);
        updateCalcResult.setJobStatus(jobStatus);
        updateCalcResult.setBudgetStatus(budgetStatus);
        updateCalcResult.setSurplusAmount(surplusAmount);
        return updateCalcResult;
    }

    private SapRecord selectSapRecord(CalcResult calcResult) {
        SapRecord query = new SapRecord();
        query.setCalcResultId(calcResult.getId());
        QueryWrapper<SapRecord> queryWrapper = Wrappers.query(query);
        return sapRecordMapper.selectOne(queryWrapper);
    }

    private void closePlan(CalcResult calcResult) {
        if (BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            ClosePlanReqDto closePlanReqDto = new ClosePlanReqDto();
            closePlanReqDto.setPlanId(calcResult.getPlanId());
            iErmService.closePlan(closePlanReqDto);
        } else {
            TerminatePlanReqDto terminatePlanReqDto = new TerminatePlanReqDto();
            terminatePlanReqDto.setPlanId(calcResult.getPlanId());
            iQueryPlanService.terminatePlan(terminatePlanReqDto);
        }
    }

    private ClientResultDTO occupyBudget(CalcResult calcResult) {
        // 一期逻辑
        if (calcResult.getVersion() == SystemVersionEnum.FIRST_EDITION.getCode()) {
            OccupyBudgetReqDto reqDto = new OccupyBudgetReqDto();
            reqDto.setMessageId(String.valueOf(calcResult.getId()));
            reqDto.setPlanId(calcResult.getPlanId());
            reqDto.setAmount(BigDecimalUtils.toBigDecimal(calcResult.getAwardAmount()));
            return iErmService.occupyBudget(reqDto);
        } else {
            // 默认二期
            if (BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
                OccupyBudgetReqDto reqDto = new OccupyBudgetReqDto();
                reqDto.setMessageId(String.valueOf(calcResult.getId()));
                reqDto.setPlanId(calcResult.getPlanId());
                reqDto.setAmount(BigDecimalUtils.toBigDecimal(calcResult.getAwardAmount()));
                return iErmService.occupyBudget(reqDto);
            } else {
                ResourceOccupyReqDto reqDto = new ResourceOccupyReqDto();
                reqDto.setPlanId(calcResult.getPlanId());
                reqDto.setRequestUuid(String.valueOf(calcResult.getId()));
                reqDto.setOccupyAmount(BigDecimalUtils.toBigDecimal(calcResult.getAwardAmount()));
                reqDto.setCalcResult(calcResult);
                return iQueryPlanService.occupyResource(reqDto);
            }
        }
    }

    @Override
    public boolean isBudgetControl(CalcResult calcResult) {
        //费用承担方是供应商且促销费类型是非差异化
        if (BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE.equals(String.valueOf(calcResult.getExpencesOfferType())) &&
                BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return true;
        }

        //促销费类型是拓客
        if (BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return true;
        }

        //促销费类型是营销推广
        if (BaseConstants.PLAN_MARKETING_PROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return true;
        }

        log.info(String.format("预算场景-费用严控[否], orderId:%s, result:%s ", calcResult.getOrderId(), calcResult));
        return false;
    }


    @Override
    public void releaseBudget(List<CalcResult> calcResultList) {
        for (CalcResult calcResult : calcResultList) {
            if (calcResult.getVersion() == SystemVersionEnum.FIRST_EDITION.getCode()) {
                ReleaseBudgetReqDto reqDto = new ReleaseBudgetReqDto();
                reqDto.setMessageId(String.valueOf(calcResult.getId()));
                reqDto.setPlanId(calcResult.getPlanId());
                reqDto.setAmount(BigDecimalUtils.toBigDecimal(calcResult.getAwardAmount()));
                ClientResultDTO<ReleaseBudgetResDto> clientResultDTO = iErmService.releaseBudget(reqDto);
                if (!clientResultDTO.isSuccess()) {
                    throw new BusinessException(String.format("释放预算失败messageId:%s,reqDto:%s", calcResult.getId(), JSON.toJSONString(reqDto)));
                }
            } else {
                if (BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
                    ReleaseBudgetReqDto reqDto = new ReleaseBudgetReqDto();
                    reqDto.setMessageId(String.valueOf(calcResult.getId()));
                    reqDto.setPlanId(calcResult.getPlanId());
                    reqDto.setAmount(BigDecimalUtils.toBigDecimal(calcResult.getAwardAmount()));
                    ClientResultDTO<ReleaseBudgetResDto> clientResultDTO = iErmService.releaseBudget(reqDto);
                    if (!clientResultDTO.isSuccess()) {
                        throw new BusinessException(String.format("释放预算失败messageId:%s,reqDto:%s", calcResult.getId(), JSON.toJSONString(reqDto)));
                    }
                } else {
                    ResourceReturnReqDto reqDto = new ResourceReturnReqDto();
                    reqDto.setPlanId(calcResult.getPlanId());
                    reqDto.setRequestUuid(String.valueOf(calcResult.getId()));
                    reqDto.setReturnAmount(BigDecimalUtils.toBigDecimal(calcResult.getAwardAmount()));
                    reqDto.setCalcResult(calcResult);
                    ClientResultDTO<ResourceReturnResDto> clientResultDTO = iQueryPlanService.returnResource(reqDto);
                    if (!clientResultDTO.isSuccess()) {
                        throw new BusinessException(String.format("释放预算失败requestUuid:%s,reqDto:%s", calcResult.getId(), JSON.toJSONString(reqDto)));
                    }
                }
            }
        }
    }
}
