package com.gome.crp.calc.client.message.impl;

import com.gome.crp.calc.mybatis.model.CalcRetry;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.message.ISendMessage;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.constants.SendMsgTypeEnum;
import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.common.util.ListUtil;

import cn.com.gome.rebate.exception.BizException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SendMessageImpl implements ISendMessage {

	@Autowired
	private EmailUtil emailUtil;
	@Autowired
	private WeChatUtil weChatUtil;
	@Autowired
	private ICalcRetryCopeService iCalcRetryCopeService;
	@Autowired
	private GcacheUtil gcacheUtil;
	@Value("${send.msg.time.space}")
	private Integer timeSpace;
	
	
	@Override
	public void sendAsyncMsg(SendMessageDto dto) {
		try {
			Boolean flag = sendSyncMsg(dto);
			if(!flag){
				//仅发送失败时进行重试
				CalcRetry calcRetry = new CalcRetry();
				calcRetry.setType(RetryJobEnum.MESSAGE.getCode());
				calcRetry.setMsgBody(JSON.toJSONString(dto));
				iCalcRetryCopeService.insertRetry(calcRetry);
			}
		} catch (Exception e) {
			log.error("推送信息失败， param is {}, exception is {}",
					JSON.toJSONString(dto), e.getMessage());
		}
	}
	
	@Override
	public boolean sendSyncMsg(SendMessageDto dto) {
		Boolean flag = false;
		try {
			if(dto == null || StringUtils.isBlank(dto.getContent()) 
					|| StringUtils.isBlank(dto.getBusinessType())){
				log.info("推送信息时，消息内容或锁类型为空， param is {}", JSON.toJSONString(dto));
				throw new BizException("内容或锁类型不能为空不能为空");
			}
			//邮件发送
			if(dto.getSendType() == SendMsgTypeEnum.SEND_EMAIL.getCode()){
				flag = sendEmail(dto);
			}
			//微信预警发送 -- 卡片
			if(dto.getSendType() == SendMsgTypeEnum.SEND_WECHAT_CARD.getCode()){
				flag = sendWeChatCard(dto);
			}
			//微信预警发送 -- 文本
			if(dto.getSendType() == SendMsgTypeEnum.SEND_WECHAT_TEXT.getCode()){
				flag = sendWeChatText(dto);
			}
			
		} catch (Exception e) {
			log.error("推送信息失败， param is {}, exception is {}",
					JSON.toJSONString(dto), e.getMessage());
		}
		return flag;
	}
	
	/**
	 * 邮件发送
	 * @param dto
	 * @return
	 */
	private Boolean sendEmail(SendMessageDto dto) {
		Boolean flag = false;
		if(CollectionUtils.isEmpty(dto.getUserList()) || StringUtils.isBlank(dto.getTopic())) {
			log.info("发送邮件失败，邮箱列表或主题不能为空， param is {}, ",
					JSON.toJSONString(dto));
			return flag;
		}
		// TODO 时间放到diamond 不支持动态更改
		String redisKey = CacheKeyConstants.getEmailMsgSendLock(dto.getBusinessType());
		try {
			Long setnxex = gcacheUtil.distributedLockAtom(redisKey, timeSpace, "true");
			if(setnxex <= 0){
				log.info("发送邮件失败， param is {}, 失败原因{}秒内不能重复进行邮件发送",
						JSON.toJSONString(dto), timeSpace);
				return flag;
			}
			String[] array = ListUtil.toArray(dto.getUserList());
			flag = emailUtil.sendEmail(dto.getTopic(), dto.getContent(), array);
		} catch (Exception e) {
			log.error("发送邮件失败， param is {}, exception is {}",
					JSON.toJSONString(dto), e.getMessage());
		} finally {
			//发送失败清除缓存锁
			if(!flag) {
				gcacheUtil.deleteKey(new String[] {redisKey});
			}
		}
		return flag;
	}
	
	/**
	 * 微信预警发送 -- 卡片
	 * @param dto
	 * @return
	 */
	private Boolean sendWeChatCard(SendMessageDto dto) {
		Boolean flag = false;
		String redisKey = CacheKeyConstants.getWeChatMsgSendLock(dto.getBusinessType());
		// TODO 时间放到diamond 不支持动态更改
		try {
			Long setnxex = gcacheUtil.distributedLockAtom(redisKey, timeSpace, "true");
			if(setnxex <= 0){
				log.info("微信卡片报警发送失败， param is {}, 失败原因{}秒内不能重复进行邮件发送",
						JSON.toJSONString(dto), timeSpace);
				return flag;
			}
			flag = weChatUtil.warningCard(dto.getContent());
		} catch (Exception e) {
			log.error("微信卡片报警发送失败， param is {}, exception is {}",
					JSON.toJSONString(dto), e.getMessage());
		} finally {
			//发送失败清除缓存锁
			if(!flag) {
				gcacheUtil.deleteKey(new String[] {redisKey});
			}
		}
		return flag;
		
	}
	
	/**
	 * 微信预警发送 -- 文本
	 * @param dto
	 * @return
	 */
	private Boolean sendWeChatText(SendMessageDto dto) {
		Boolean flag = false;
		String redisKey = CacheKeyConstants.getWeChatMsgSendLock(dto.getBusinessType());
		try {
			Long setnxex = gcacheUtil.distributedLockAtom(redisKey, timeSpace, "true");
			if(setnxex <= 0){
				log.info("微信文本报警发送失败， param is {}, 失败原因{}秒内不能重复进行邮件发送",
						JSON.toJSONString(dto), timeSpace);
				return flag;
			}
			flag = weChatUtil.warningText(dto.getContent());
		} catch (Exception e) {
			log.error("微信文本报警发送失败， param is {}, exception is {}",
					JSON.toJSONString(dto), e.getMessage());
		} finally {
			//发送失败清除缓存锁
			if(!flag) {
				gcacheUtil.deleteKey(new String[] {redisKey});
			}
		}
		return flag;
	}

}
