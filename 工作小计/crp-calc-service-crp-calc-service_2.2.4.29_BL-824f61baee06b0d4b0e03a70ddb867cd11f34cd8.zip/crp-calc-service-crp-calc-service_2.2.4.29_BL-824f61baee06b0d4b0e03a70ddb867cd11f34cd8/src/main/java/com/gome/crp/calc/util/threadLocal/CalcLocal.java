package com.gome.crp.calc.util.threadLocal;

import com.gome.crp.calc.dto.threadLocal.LocalDto;

/**
 * 通用 ThreadLocal 封装
 */
public class CalcLocal {

    private static ThreadLocal<LocalDto> threadLocal = new ThreadLocal<>();
    private static ThreadLocal<Boolean> repairThreadLocal = new ThreadLocal<>();

    public static void setLocalDto(LocalDto localDto) {
        threadLocal.set(localDto);
    }

    public static LocalDto getLocalDto() {
        return threadLocal.get();
    }

    public static void removeLocalDto() {
        threadLocal.remove();
    }

    public static Boolean getRepairThreadLocal() {
        return repairThreadLocal.get();
    }

    public static void setRepairThreadLocal(Boolean enable) {
        repairThreadLocal.set(enable);
    }

    public static void removeRepairThreadLocal() {
        repairThreadLocal.remove();
    }
}
