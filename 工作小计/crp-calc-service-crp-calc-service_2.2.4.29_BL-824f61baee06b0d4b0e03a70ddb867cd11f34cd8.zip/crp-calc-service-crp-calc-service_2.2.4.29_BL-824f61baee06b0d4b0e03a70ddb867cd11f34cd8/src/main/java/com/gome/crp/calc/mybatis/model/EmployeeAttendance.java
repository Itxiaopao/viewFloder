package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * @author chenchen
 *
 */
@Getter
@Setter
@ToString
public class EmployeeAttendance {

    private Long id; //id
    private String staffCode; //员工编码
    private String organizationCode; //组织机构
    private String workMonth; //月份
    private String brandCode; //品牌编码
    private String categoryCode; //商品编码
    private Integer hasday; //考勤天数
    private Date createTime; //createTime
    private Date updateTime; //updateTime
    private Integer isDelete; //0未删除，1已删除
    private String supplier; //采购组织
}