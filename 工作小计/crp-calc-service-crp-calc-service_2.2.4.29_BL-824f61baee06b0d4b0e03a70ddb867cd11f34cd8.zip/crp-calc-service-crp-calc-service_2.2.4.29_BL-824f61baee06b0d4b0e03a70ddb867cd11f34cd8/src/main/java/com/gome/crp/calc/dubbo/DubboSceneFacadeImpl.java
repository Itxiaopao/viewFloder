package com.gome.crp.calc.dubbo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.facade.dto.ResultDTO;
import com.gome.crp.calc.facade.dto.orderCalc.OrderDto;
import com.gome.crp.calc.facade.dto.orderCalc.res.OrderCalcResDto;
import com.gome.crp.calc.facade.dubbo.IDubboProfitStaffFacade;
import com.gome.crp.calc.facade.dubbo.IDubboSceneFacade;

import lombok.extern.slf4j.Slf4j;

/**
 * 目前该接口迁移到 com.gome.crp.calc.dubbo.DubboProfitStaffFacadeImpl
 * 
 * @since com.gome.crp.calc.dubbo.DubboProfitStaffFacadeImpl
 * @author libinbin9
 *
 */
@Slf4j
@Service("dubboSceneFacade")
public class DubboSceneFacadeImpl implements IDubboSceneFacade {
	
	@Autowired
	private IDubboProfitStaffFacade dubboProfitStaffFacade;
	

	@Override
	public ResultDTO<OrderCalcResDto> getSceneUser(OrderDto orderDto) {
		log.info(String.format("提供-员工身份信息识别接口[老接口], 入参:%s", JSONObject.toJSONString(orderDto)));
		ResultDTO<OrderCalcResDto> profitStaff = dubboProfitStaffFacade.getProfitStaff(orderDto);
		log.info(String.format("提供-员工身份信息识别接口[老接口], 结果集:%s", JSONObject.toJSONString(profitStaff)));
		return profitStaff;
	}

}
