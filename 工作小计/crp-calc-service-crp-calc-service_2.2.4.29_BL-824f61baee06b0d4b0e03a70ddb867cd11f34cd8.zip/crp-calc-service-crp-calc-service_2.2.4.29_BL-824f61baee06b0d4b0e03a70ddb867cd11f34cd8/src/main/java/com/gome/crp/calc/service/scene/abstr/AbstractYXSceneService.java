package com.gome.crp.calc.service.scene.abstr;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.formula.JTBasePriceDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.scene.ISceneService;
import com.gome.crp.calc.service.scene.formula.ICalFormulas;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * 处理营销订单的计算逻辑
 * @author GOME
 *
 */
@Slf4j
@Service
public abstract class AbstractYXSceneService implements ISceneService {

    @Autowired
    private ICalFormulas calFormulas;
    @Autowired
    private SceneUtils sceneUtils;
    @Autowired
    private AbsUtils absUtils;

    private static final String scene_log = "营销-";



    /**
     * 场景公式, 单品销售金额（或单品实付金额）×销售数量×Z/M比例 (返回：分) 
     *
     * @param orderDto
     * @param planDto
     * @param number
     * @param scene
     * @return
     */
    public List<BigDecimal> sceneFormula(OrderCalcDto orderDto, PlanDto planDto, int number, String scene) {
        // 调用计算分配接口: 分计算, 截取到 0 以上
        BigDecimal ret = calFormulas.calculatedResult(orderDto, planDto, scene);
        // 向下百分比基数
        long price = ret.setScale(0, RoundingMode.DOWN).longValue();
        // 平分提奖结果
        List<BigDecimal> perAwardPrice = absUtils.getPerAwardPrice(price, number);
        String log_end = scene_log + "计算提奖金额[最终][商品数量:%d][等比分配]结果: order:%s, planId:%s, 场景:%s, 人数:%d, 均分结果:%s";
        log.info(String.format(log_end, orderDto.getBuyNum(), orderDto.getOrderId(), planDto.getPlanId(), scene, number, JSONObject.toJSONString(perAwardPrice)));
        return perAwardPrice;
    }


    /**
     * @param orderDto
     * @param planDto
     * @param scene
     * @return
     */
    public boolean checkPlanCanCalc(OrderCalcDto orderDto, PlanDto planDto, String scene) {
        Integer promotionsType = planDto.getPromotionsType();
        //促销费类型
        if (BaseConstants.SCENE_X.equals(scene)){
            // x类型 RETURN
            log.info(String.format(scene_log + "计算场景检测[不计算]: 场景非scen-X, 该订单不计算 orderId:%s, planId:%d, 场景:%s, 促销费类型:%d",
                    orderDto.getOrderId(), planDto.getPlanId(), scene, promotionsType));
            return false;
        }

        // 计提基数 （0销售金额、1实付金额）
        JTBasePriceDto jtBasesDto = sceneUtils.getJTBases(orderDto, planDto);
        String jtProvisionStr = jtBasesDto.getProvisionStr();
        BigDecimal jtBases = jtBasesDto.getPrice();
        if(jtBases == null || StringUtils.isEmpty(jtProvisionStr)){
            absUtils.addProblem(orderDto, planDto, scene_log + "计提基数不正确", ProblemEnum.CODE_131);
            log.info(String.format(scene_log + "计算场景检测[不计算]: 计提基数类型为不正确, 该订单不计算 orderId:%s, planId:%d, 场景:%s, 促销费类型:%d", orderDto.getOrderId(), planDto.getPlanId(), scene, promotionsType));
            return false;   // 非空判断
        }
        return true;
    }

    /**
     * 处理奖励
     *
     * @param awardPrice 奖励金额
     * @param count      分几份
     * @return
     */
    public List<BigDecimal> getPerAwardPrice(Long awardPrice, int count) {
        return absUtils.getPerAwardPrice(awardPrice, count);
    }



    /**
     * copy properties by source calcResult and inside log journal
     * 异步 推送问题小工具
     *
     * @param orderCalcDto
     * @param problemMSG
     * @param planDto
     * @param problemEnum
     * @return
     */
    public void addProblem(OrderCalcDto orderCalcDto, PlanDto planDto, String problemMSG, ProblemEnum problemEnum) {
        absUtils.addProblem(orderCalcDto, planDto, problemMSG, problemEnum);
    }


    /**
     * 拷贝属性
     *
     * @param empl
     * @param shopNo
     * @param orderSupplier
     * @param userId
     * @param isMain
     * @return
     */
    public PersonDto copyProperies(EmployeeInfoDto empl, String shopNo, String orderSupplier, String userId, Integer isMain, Integer profitBehaviorCode) {
        return absUtils.copyProperies(empl, shopNo, orderSupplier, userId, isMain, profitBehaviorCode);
    }

    // 保存计算公式履历
    public void addRewardCommit(OrderCalcDto orderDto, PlanDto planDto, List<ProfitDto> profitList, String scene){
        absUtils.addRewardCommit(orderDto, planDto, profitList, scene, scene_log);
    }

}



