package com.gome.crp.calc.mybatis.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import org.springframework.stereotype.Service;

@Service
public class CalcResultServiceImpl extends ServiceImpl<CalcResultMapper, CalcResult> implements ICalcResultService {
}
