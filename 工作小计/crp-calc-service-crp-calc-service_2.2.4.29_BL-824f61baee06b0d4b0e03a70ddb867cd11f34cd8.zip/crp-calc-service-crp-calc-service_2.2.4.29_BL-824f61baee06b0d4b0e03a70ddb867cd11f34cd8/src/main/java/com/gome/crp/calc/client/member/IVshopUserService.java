package com.gome.crp.calc.client.member;

import com.gomeo2o.facade.vshop.entity.VshopInfo;

/**
 * 美店主信息查询
 * 
 * @author libinbin9
 *
 */
public interface IVshopUserService {
	
	/**
	 * 获取美店主信息
	 * 
	 * @param userId
	 * @return
	 */
	VshopInfo getVshopUserByUserId(String userId);

}
