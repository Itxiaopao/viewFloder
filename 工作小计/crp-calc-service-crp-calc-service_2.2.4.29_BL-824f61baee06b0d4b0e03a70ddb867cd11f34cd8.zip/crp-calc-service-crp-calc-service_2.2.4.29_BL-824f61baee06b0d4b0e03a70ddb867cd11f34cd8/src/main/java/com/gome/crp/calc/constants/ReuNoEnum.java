package com.gome.crp.calc.constants;

/**
 * 收入项目编码
 */
public enum ReuNoEnum {
    FY0000087("FY0000087", "带单函"),
    FY0000008("FY0000008", "主推"),
    FY0000084("FY0000084", "零售提奖Z605"),
    FY0000078("FY0000078", "无促Z195/Z197"),
    ;

    private String code;
    private String msg;

    ReuNoEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
