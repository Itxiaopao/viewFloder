package com.gome.crp.calc.dto.contractDto;

import lombok.Data;

import java.io.Serializable;

@Data
public class ScsContractDto implements Serializable {

    private static final long serialVersionUID = -379834028056434193L;

    private String comprehensiveContribution;//综贡
    private PushLetterDto commission;//主推返利函
    private ReplaceLetterDto confirmation;//带单确认函
    private ContractDto contractPolicy;//新合同信息
    private ContractDto orderContractPolicy;//订单批次合同信息
    private ExtraDto orderAgreement;//订单批次协议信息（采购协议）
}
