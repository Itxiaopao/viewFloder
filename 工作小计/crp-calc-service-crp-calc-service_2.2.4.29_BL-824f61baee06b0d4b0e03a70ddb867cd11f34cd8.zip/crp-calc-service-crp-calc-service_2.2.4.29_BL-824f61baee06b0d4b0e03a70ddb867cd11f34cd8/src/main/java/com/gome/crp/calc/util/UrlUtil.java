package com.gome.crp.calc.util;

import com.gome.crp.calc.constants.PathEnum;

public class UrlUtil {

    public static String getUrl(String serviceAddress, PathEnum pathEnum) {
        return serviceAddress + pathEnum.getCode();
    }
}
