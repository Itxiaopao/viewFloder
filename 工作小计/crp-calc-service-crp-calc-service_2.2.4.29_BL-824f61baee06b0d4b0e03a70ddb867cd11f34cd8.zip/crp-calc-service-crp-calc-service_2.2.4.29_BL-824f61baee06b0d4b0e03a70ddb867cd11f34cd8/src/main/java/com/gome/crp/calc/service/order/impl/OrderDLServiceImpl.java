package com.gome.crp.calc.service.order.impl;

import com.gome.crp.calc.constants.OrderTypeEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.manager.OrderBaseManager;
import com.gome.crp.calc.service.order.IOrderService;
import com.gome.crp.calc.service.order.abstr.AbstractOrderBaseService;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * 配送单已妥投
 * 修改配送单状态
 */
@Slf4j
@Service
public class OrderDLServiceImpl extends AbstractOrderBaseService implements IOrderService {
    @Autowired
    private OrderBaseManager orderBaseManager;

    /**
     * 订单状态由配送单生效变成已妥投，更新时间
     *
     * @param orderCalcDto
     */
    @Override
    public Integer process(OrderCalcDto orderCalcDto) {
        log.info("妥投单mq消息处理开始orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);

        //货到付款类型,妥投单才有支付时间,匹配计划
        if (OrderTypeEnum.CASH_ON_DELIVERY.getCode().equals(orderCalcDto.getOrderType())) {
            //计算逻辑
            Integer result = super.calcLogic(orderCalcDto);
            log.info("妥投单mq消息处理完成orderId:{},orderCalcDto:{},result:{}", orderCalcDto.getOrderId(), orderCalcDto, result);
            return result;
        } else {
            //查询计划订单
            List<CalcResult> calcResultList = super.selectCalcResult(orderCalcDto);
            if (CollectionUtils.isEmpty(calcResultList)) {
                log.info("妥投单mq消息处理,原始计划订单不存在orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
                return null;
            }

            //过滤数据
            List<CalcResult> filterCalcResult = super.filterCalcResult(calcResultList, orderCalcDto);
            if (CollectionUtils.isEmpty(filterCalcResult)) {
                log.info("妥投单mq消息处理,没有处理数据orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
                return null;
            }

            //计算记录数据,更新计算结果对象
            List<CalcRecord> calcRecords = super.getCalcRecord(filterCalcResult, orderCalcDto);
            List<CalcResult> updateCalcResult = super.getUpdateCalcResult(filterCalcResult, orderCalcDto);
            orderBaseManager.doUpdateCalcResultStatus(updateCalcResult, calcRecords, null);
            log.info("妥投单mq消息处理完成orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
            return null;
        }
    }
}