package com.gome.crp.calc.constants;

public enum SendMsgBusinessTypeEnum {
	
	ERROR_WUCU("ERROR_WUCU", "无促异常报警"),
	RETRY_ALERT("RETRY_ALERT", "重试报警"),
    PURCHASE_INCONSISTENT("PURCHASE_INCONSISTENT", "采购组织不一致"),
    ACCOUNT_AMOUNT("ACCOUNT_AMOUNT", "挂账金额小于奖励金额"),

    ;

    private String code;
    private String msg;

    SendMsgBusinessTypeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
