package com.gome.crp.calc.service.retry;

import com.gome.crp.calc.mybatis.model.CalcRetry;

/**
 * 重推job处理类
 * 
 * 
 * @author libinbin9
 *
 */
public interface ICalcRetryCopeService{
	
	/**
	 * 扫描计划
	 */
	void scan();

    /**
     * 添加到计划重推表中
     *
     * @param calcRetry
     */
    void insertRetry(CalcRetry calcRetry);
}
