package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.SapRecord;

/**
 * sap挂账表 Mapper
 * @author zhangshuang
 *
 */
public interface SapRecordMapper extends BaseMapper<SapRecord>{

}