package com.gome.crp.calc.client.erm.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.client.erm.IErmService;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ErmErrorCodeEnum;
import com.gome.crp.calc.dto.ermDto.*;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.util.BigDecimalUtils;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import com.gome.meidian.common.base.vo.CommonResultEntity;
import com.gome.meidian.crp.facade.CalcOperateFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class ErmServiceImpl implements IErmService {
    @Autowired
    private CalcOperateFacade calcOperateFacade;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private RedisLockHelper redisLockHelper;

    @Override
    public ClientResultDTO<ClosePlanResDto> closePlan(ClosePlanReqDto reqDto) {
        if (reqDto == null || reqDto.getPlanId() == null) {
            throw new IllegalArgumentException("调用erm新后台-关闭计划接口-入参错误");
        }

        try {
            log.info("调用erm新后台-关闭计划接口开始planId:{},reqDto:{}", reqDto.getPlanId(), reqDto);
            CommonResultEntity<String> result = calcOperateFacade.changePlanStatus(Long.valueOf(reqDto.getPlanId()));
            String resultJson = JSON.toJSONString(result);
            log.info("调用erm新后台-关闭计划接口完成planId:{},reqDto:{},result:{}", reqDto.getPlanId(), reqDto, resultJson);
            if (ErmErrorCodeEnum.CLOSE_PLAN_CODE_0.getCode() == result.getCode() ||
                    ErmErrorCodeEnum.CLOSE_PLAN_CODE_10002.getCode() == result.getCode()) {
                return ClientResultDTO.success();
            }

            throw new BusinessException(String.format("调用erm新后台-关闭计划接口失败planId:%s,reqDto:%s,result:%s", reqDto.getPlanId(), JSON.toJSONString(reqDto), resultJson));
        } catch (Exception e) {
            log.error("调用erm新后台-关闭计划接口异常planId:{},reqDto:{}", reqDto.getPlanId(), reqDto, e);
            return ClientResultDTO.error(-1, String.format("调用erm新后台-关闭计划接口异常planId:%s,reqDto:%s", reqDto.getPlanId(), JSON.toJSONString(reqDto)));
        }
    }

    @Override
    public ClientResultDTO<ReleaseBudgetResDto> releaseBudget(ReleaseBudgetReqDto reqDto) {
        if (reqDto == null || reqDto.getMessageId() == null || reqDto.getPlanId() == null || reqDto.getAmount() == null) {
            throw new IllegalArgumentException("调用erm新后台-释放预算接口-入参错误");
        }

        log.info("调用erm新后台-释放预算接口开始messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto);
        String ermBudgetReleaseUniqueKey = CacheKeyConstants.getErmBudgetReleaseUniqueKey(reqDto.getMessageId());
        try {
            //幂等校验
            Long value = gcacheUtil.distributedLockAtom(ermBudgetReleaseUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
            if (value == 1) {
                //加锁
                String ermPlanBudgetLock = CacheKeyConstants.getErmPlanBudgetLock(reqDto.getPlanId());
                RedisLock redisLock = redisLockHelper.getLock(ermPlanBudgetLock);
                if (!redisLock.lock()) {
                    return ClientResultDTO.error(-1, String.format("调用erm新后台-释放预算加锁失败messageId:%s,planId:%s,reqDto:%s", reqDto.getMessageId(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
                }

                try {
                    String planBudgetKey = CacheKeyConstants.getErmPlanBudgetKey(reqDto.getPlanId());
                    boolean isExist = gcacheUtil.exists(planBudgetKey);
                    if (isExist) {
                        log.info("调用erm新后台-释放预算开始");
                        Long surplusAmount = gcacheUtil.incrBy(planBudgetKey, reqDto.getAmount().longValue());
                        log.info("调用erm新后台-释放预算结束,计划剩余金额messageId:{},planId:{},surplusAmount:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), surplusAmount, reqDto);
                    } else {
                        log.info("调用erm新后台-释放预算接口开始");
                        CommonResultEntity<String> result = calcOperateFacade.operateBudget(Long.valueOf(reqDto.getPlanId()), reqDto.getAmount().longValue());
                        String resultJson = JSON.toJSONString(result);
                        log.info("调用erm新后台-释放预算接口完成messageId:{},planId:{},reqDto:{},result:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto, resultJson);
                        if (ErmErrorCodeEnum.RELEASE_BUDGET_CODE_0.getCode() == result.getCode()) {
                            return ClientResultDTO.success();
                        }

                        throw new BusinessException(String.format("调用erm新后台-释放预算接口失败messageId%s,planId:%s,reqDto:%s,result:%s", reqDto.getMessageId(), reqDto.getPlanId(), JSON.toJSONString(reqDto), resultJson));
                    }
                } finally {
                    redisLock.unlock();
                }
            }
            log.info("调用erm新后台-释放预算接口结束messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto);
            return ClientResultDTO.success();
        } catch (Exception e) {
            log.error("调用erm新后台-释放预算接口异常messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto, e);
            try {
                gcacheUtil.deleteKey(new String[]{ermBudgetReleaseUniqueKey});
            } catch (Exception ex) {
                log.error("调用erm新后台-释放预算接口,删除防重键异常messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto, ex);
            }
            return ClientResultDTO.error(-1, String.format("调用erm新后台-释放预算接口异常messageId:%s,planId:%s,reqDto:%s", reqDto.getMessageId(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
        }
    }

    @Override
    public ClientResultDTO<OccupyBudgetResDto> occupyBudget(OccupyBudgetReqDto reqDto) {
        if (reqDto == null || reqDto.getPlanId() == null || reqDto.getAmount() == null) {
            throw new IllegalArgumentException("调用erm新后台-占用预算接口-入参错误");
        }

        log.info("调用erm新后台-占用预算接口开始messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto);
        String ermBudgetOccupyUniqueKey = CacheKeyConstants.getErmBudgetOccupyUniqueKey(reqDto.getMessageId());
        try {
            //幂等校验
            Long value = gcacheUtil.distributedLockAtom(ermBudgetOccupyUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
            if (value == 1) {
                //加锁
                String ermPlanBudgetLock = CacheKeyConstants.getErmPlanBudgetLock(reqDto.getPlanId());
                RedisLock redisLock = redisLockHelper.getLock(ermPlanBudgetLock);
                if (!redisLock.lock()) {
                    return ClientResultDTO.error(-1, String.format("调用erm新后台-占用预算加锁失败messageId:%s,planId:%s,reqDto:%s", reqDto.getMessageId(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
                }

                try {
                    String planBudgetKey = CacheKeyConstants.getErmPlanBudgetKey(reqDto.getPlanId());
                    String budgetAmount = gcacheUtil.getKeyValue(planBudgetKey);
                    log.info("调用erm新后台-占用预算,计划查询金额messageId:{},planId:{},budgetAmount:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), budgetAmount, reqDto);
                    //校验预算金额
                    boolean result = BigDecimalUtils.greaterEqualThan(BigDecimalUtils.toBigDecimal(budgetAmount), reqDto.getAmount());
                    if (result) {
                        Long surplusAmount = gcacheUtil.decrBy(planBudgetKey, reqDto.getAmount().longValue());
                        log.info("调用erm新后台-占用预算,计划剩余金额messageId:{},planId:{},budgetAmount:{}.surplusAmount:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), budgetAmount, surplusAmount, reqDto);
                        OccupyBudgetResDto occupyBudgetResDto = new OccupyBudgetResDto();
                        occupyBudgetResDto.setSurplusAmount(surplusAmount);
                        return ClientResultDTO.success(occupyBudgetResDto);
                    } else {
                        return ClientResultDTO.error(1, "占用预算失败,金额不足");
                    }
                } finally {
                    redisLock.unlock();
                }
            }
            return ClientResultDTO.success(null);
        } catch (Exception e) {
            log.error("调用erm新后台-占用预算接口异常messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto, e);
            try {
                gcacheUtil.deleteKey(new String[]{ermBudgetOccupyUniqueKey});
            } catch (Exception ex) {
                log.error("调用erm新后台-占用预算接口,删除防重键异常messageId:{},planId:{},reqDto:{}", reqDto.getMessageId(), reqDto.getPlanId(), reqDto, ex);
            }
            return ClientResultDTO.error(-1, String.format("调用erm新后台-占用预算接口异常messageId:%s,planId:%s,reqDto:%s", reqDto.getMessageId(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
        }
    }

    @Override
    public String queryNewContractCode(String oldContractCode) {
        String ermContractRelationKey = CacheKeyConstants.getErmContractRelationKey(oldContractCode);
        log.info("调用erm新后台-查询新合同接口开始oldContractCode:{},ermContractRelationKey:{}", oldContractCode, ermContractRelationKey);
        String newContractCode = gcacheUtil.getKeyValue(ermContractRelationKey);
        log.info("调用erm新后台-查询新合同接口完成oldContractCode:{},ermContractRelationKey:{},newContractCode:{}", oldContractCode, ermContractRelationKey, newContractCode);
        return newContractCode;
    }

    @Override
    public List<LetterResDto> queryLetter(LetterReqDto letterReqDto) {
        String ermLetterKey = CacheKeyConstants.getErmLetterKey(letterReqDto.getContractCode(), letterReqDto.getExtraPurchaseCode(), letterReqDto.getOrderSupplierCode(), letterReqDto.getDocty(), letterReqDto.getSkuNo(), letterReqDto.getSalesModel());
        log.info("调用erm新后台-查询函信息接口开始letterReqDto:{},ermLetterKey:{}", letterReqDto, ermLetterKey);
        String letterInfo = gcacheUtil.getKeyValue(ermLetterKey);
        log.info("调用erm新后台-查询函信息接口完成letterReqDto:{},ermLetterKey:{},letterInfo:{}", letterReqDto, ermLetterKey, letterInfo);
        return JSON.parseObject(letterInfo, new TypeReference<ArrayList<LetterResDto>>() {
        });
    }

}