package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboCalcOrderResult15PercentFacade;
import com.gome.crp.calc.service.job.IJob15PercentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DubboCalcOrderResult15PercentFacadeImpl implements IDubboCalcOrderResult15PercentFacade {
    @Autowired
    private IJob15PercentService IJob15PercentService;

    @Override
    public void deal15Percent(){
        IJob15PercentService.deal15Percent();
    }

    @Override
    public void deal15PercentCursor() {
        IJob15PercentService.deal15PercentCursor();
    }

}
