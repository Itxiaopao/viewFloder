package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.mapper.ProblemMapper;
import com.gome.crp.calc.mybatis.model.Problem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProblemManager {
    @Autowired
    ProblemMapper problemMapper;

    public void addProblem(Problem problem) {
        if (problem.getDescription() != null && problem.getDescription().length() > 250) {
            problem.setDescription(problem.getDescription().substring(0, 250));
        }
        problemMapper.insert(problem);
    }

}
