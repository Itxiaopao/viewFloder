package com.gome.crp.calc.util.lock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

@Component
public class RedisLockHelper {
    @Autowired
    private Gcache gcache;

    public RedisLock getLock(String lockKey) {
        return new RedisLock(gcache, lockKey);
    }

    public RedisLock getLock(String lockKey, int internalLockLeaseTime, long timeout) {
        return new RedisLock(gcache, lockKey, internalLockLeaseTime, timeout);
    }

}
