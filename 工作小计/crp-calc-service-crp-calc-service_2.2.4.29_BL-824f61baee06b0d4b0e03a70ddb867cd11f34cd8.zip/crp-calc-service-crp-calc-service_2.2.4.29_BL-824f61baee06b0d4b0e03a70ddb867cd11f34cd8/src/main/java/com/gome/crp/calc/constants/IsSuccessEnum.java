package com.gome.crp.calc.constants;

/**
 * 是否成功
 */
public enum IsSuccessEnum {
    YES(1, "成功"),
    NO(0, "失败"),

    ;

    private int code;
    private String msg;

    IsSuccessEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
