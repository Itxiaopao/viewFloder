package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.mapper.OrderCalcMsgMapper;
import com.gome.crp.calc.mybatis.model.OrderCalcMsg;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderCalcMsgManager {
    @Autowired
    private OrderCalcMsgMapper orderCalcMsgMapper;

    @Transactional
    public void doUpdateOrderCalcMsg(OrderCalcMsg insertOrderCalcMsg, OrderCalcMsg updateOrderCalcMsg) {
        orderCalcMsgMapper.insert(insertOrderCalcMsg);
        orderCalcMsgMapper.updateById(updateOrderCalcMsg);
    }
    @Transactional
    public void updateById(OrderCalcMsg updateOrderCalcMsg){
        orderCalcMsgMapper.updateById(updateOrderCalcMsg);
    }
}
