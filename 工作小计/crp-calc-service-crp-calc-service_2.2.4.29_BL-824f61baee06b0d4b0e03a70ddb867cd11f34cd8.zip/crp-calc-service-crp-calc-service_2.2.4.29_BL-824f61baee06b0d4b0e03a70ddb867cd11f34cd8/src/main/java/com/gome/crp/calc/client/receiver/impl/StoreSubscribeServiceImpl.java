package com.gome.crp.calc.client.receiver.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.receiver.IStoreSubscribeService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.Receiver;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.memberCenter.dao.model.storeReserve.GomeStoreReserveModel;
import com.gome.memberCenter.facade.storeReserve.IGomeStoreReserveDubbloFacade;
import com.gome.memberCenter.model.request.body.storeReserve.CalculationQueryStoreReserveParam;
import com.gome.rpc.base.RequestDTO;
import com.gome.rpc.base.ResponseDTO;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class StoreSubscribeServiceImpl implements IStoreSubscribeService{
	@Autowired
	private IGomeStoreReserveDubbloFacade gomeStoreReserveDubbloFacade;

	/**
	 * 到店预约人
	 * @param orderDto
	 * @return
	 */
	@Override
	public List<Receiver> queryReceiver(OrderCalcDto orderDto) {
		List<Receiver> resutlList = null;
		if(orderDto == null || StringUtils.isEmpty(orderDto.getUserId())){
			log.info("提成计算查询预约信息列表接口/Dubbo校验userId为空:orderDto:{}",JSON.toJSON(orderDto));
			return null;
		}
		RequestDTO<CalculationQueryStoreReserveParam> queryStoreReserveParam = new RequestDTO<CalculationQueryStoreReserveParam> ();
		CalculationQueryStoreReserveParam calculationQueryStoreReserveParam = new CalculationQueryStoreReserveParam();
		calculationQueryStoreReserveParam.setUserId(orderDto.getUserId());
		calculationQueryStoreReserveParam.setStoreCode(orderDto.getShopNo());
		calculationQueryStoreReserveParam.setOrderTime(orderDto.getPayDate());
		calculationQueryStoreReserveParam.setInvokeFrom(BaseConstants.STORESUBSCRIBE_INVOKEFROM);
		queryStoreReserveParam.setBody(calculationQueryStoreReserveParam);
		try{
			log.info("提成计算查询预约信息列表接口开始/Dubbo:userId:{},queryStoreReserveParam:{},orderId:{}",orderDto.getUserId(),JSON.toJSONString(queryStoreReserveParam),orderDto.getOrderId());
			ResponseDTO<List<GomeStoreReserveModel>> response = gomeStoreReserveDubbloFacade.queryStoreReserveForCalculation(queryStoreReserveParam);
			log.info("提成计算查询预约信息列表接口完成/Dubbo:userId:{},response:{},orderId:{}",orderDto.getUserId(),JSON.toJSONString(response),orderDto.getOrderId());
			List<GomeStoreReserveModel> responseList = response.getBody();
			if(!CollectionUtils.isEmpty(responseList)){
				resutlList = new ArrayList<Receiver>();
				for(GomeStoreReserveModel gomeStoreReserveModel : responseList){
					if(gomeStoreReserveModel != null && gomeStoreReserveModel.getSellerNum() != null && gomeStoreReserveModel.getArriveTime() != null ){
						Receiver  receiver = new Receiver();
						receiver.setStaffId(gomeStoreReserveModel.getSellerNum());
						receiver.setReceiverTime(gomeStoreReserveModel.getArriveTime().getTime());
						receiver.setProfitBehaviorCode(ProfitBehaviorEnum.SERVICE_APPOINTMENT.getCode());
						resutlList.add(receiver);
					}
				}
			}
		}catch(Exception e){
			log.error("提成计算查询预约信息列表接口/封装数据异常userId:{},orderId:{},queryStoreReserveParam:{},e:{}", orderDto.getUserId(),orderDto.getOrderId(),JSON.toJSONString(queryStoreReserveParam),e);
			throw new BusinessException(String.format("提成计算查询预约信息列表接口,接口异常,userId:%s,orderDto:%s", orderDto.getUserId(), JSON.toJSONString(orderDto)), e);
		}


		return resutlList;
	}

}
