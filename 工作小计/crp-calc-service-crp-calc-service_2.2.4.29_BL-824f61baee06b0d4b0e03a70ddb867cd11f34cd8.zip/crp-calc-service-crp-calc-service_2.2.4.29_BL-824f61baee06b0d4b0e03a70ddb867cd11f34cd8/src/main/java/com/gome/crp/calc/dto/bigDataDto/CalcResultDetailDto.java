package com.gome.crp.calc.dto.bigDataDto;

import lombok.Data;

import java.io.Serializable;

@Data
public class CalcResultDetailDto implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 7233897016090626946L;
	private String plan_id; // 提奖计划ID
    private String vitae_id; // 计算结果表ID, result 表的 id
    private String profit_type; // 获利场景编码
    private String profit_amount; // 收益，正向单传正的金额，逆向单传负的金额
    private String employee_id; // 获得收益的员工ID, employee_id 和 member_id 必传一个，两个也可以都传
    private String member_id; // 国美的会员ID, employee_id 和 member_id 必传一个，两个也可以都传
    private String update_time; // 此条履历详情的更新时间	
    private String attribution_action;//获利行为:(1:开单;2:服务承接-IM;3:服务承接-外呼;4:服务承接-预约到店;5:分享商品;6:分享券;7:主营均分;8:兼营均分;9:集客;10:上级)
}
