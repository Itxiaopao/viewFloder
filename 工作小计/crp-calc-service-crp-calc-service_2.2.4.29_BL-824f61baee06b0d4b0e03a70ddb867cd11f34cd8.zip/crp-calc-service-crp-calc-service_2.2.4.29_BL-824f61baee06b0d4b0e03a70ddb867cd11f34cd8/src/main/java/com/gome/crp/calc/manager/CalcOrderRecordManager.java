package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.service.ICalcRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CalcOrderRecordManager {
    @Autowired
    private ICalcRecordService iCalcRecordService;

    public boolean save(CalcRecord calcRecord){
        return iCalcRecordService.save(calcRecord);
    }
}
