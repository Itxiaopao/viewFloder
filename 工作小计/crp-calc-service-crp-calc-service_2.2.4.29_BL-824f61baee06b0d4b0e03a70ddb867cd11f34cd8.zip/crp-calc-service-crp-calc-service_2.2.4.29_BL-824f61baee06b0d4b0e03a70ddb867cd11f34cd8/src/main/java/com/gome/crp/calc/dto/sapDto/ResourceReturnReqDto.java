package com.gome.crp.calc.dto.sapDto;

import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ResourceReturnReqDto {
    private String planId;
    private String requestUuid;
    private BigDecimal returnAmount;
    private CalcResult calcResult;
}