package com.gome.crp.calc.util;

import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Spring 容器动态增加删除bean工具类
 * @author lisuo
 *
 */
public class SpringDynamicBeanFactoryUtil {
	
	/**
	 * 向容器增加bean,如果bean存在忽略
	 * @param beanClass bean类型
	 * @param beanName bean名称
	 * @param applicationContext spring上下文
	 */
	public static void addBean(Class<?> beanClass,String beanName,ApplicationContext applicationContext){
        ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext) applicationContext;
        DefaultListableBeanFactory defaultListableBeanFactory = (DefaultListableBeanFactory) configurableApplicationContext.getBeanFactory();
        if(!defaultListableBeanFactory.containsBean(beanName)){
        	BeanDefinitionBuilder beanDefinitionBuilder = BeanDefinitionBuilder.genericBeanDefinition(beanClass);
            AbstractBeanDefinition bean = beanDefinitionBuilder.getBeanDefinition();
        	defaultListableBeanFactory.registerBeanDefinition(beanName, bean);
        	//初始化bean
        	applicationContext.getBean(beanName);
        }
	}
	
	/**
	 * 从容器删除bean,如果bean不存在忽略
	 * @param beanName bean名称
	 * @param applicationContext spring上下文
	 */
	public static void removeBean(String beanName,ApplicationContext applicationContext){
        ConfigurableApplicationContext configurableApplicationContext = (ConfigurableApplicationContext) applicationContext;
        DefaultListableBeanFactory defaultListableBeanFactory = (DefaultListableBeanFactory) configurableApplicationContext.getBeanFactory();
        if(defaultListableBeanFactory.containsBean(beanName)){
        	defaultListableBeanFactory.removeBeanDefinition(beanName);
        }
	}
	
}
