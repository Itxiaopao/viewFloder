package com.gome.crp.calc.client.employee.impl;

import cn.com.gome.mdm.client.dto.employee.*;
import cn.com.gome.mdm.client.server.employee.GomeEmployeeClient;
import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.IGomeEmployeeInfoService;
import com.gome.crp.calc.dto.employee.*;
import com.gome.crp.calc.manager.employee.EmployeeAttendanceSynManager;
import com.gome.rpc.base.RequestDTO;
import com.gome.rpc.base.ResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class GomeEmployeeInfoService implements IGomeEmployeeInfoService {

    @Autowired
    private EmployeeAttendanceSynManager employeeAttendanceSynManager;
	@Autowired
	private GomeEmployeeClient gomeEmployeeClient;

	// 主数据-调用来源-命名
	private static String INVOKE_SOURCE = "CRP-CALC";


	@Override
	public List<EmployeeInfoDto> queryGomeEmployeeInfos(String orderId, String categoryId, String brandId, List<String> employeeIdList, String shop){
		// base condition
		GomeEmployeeRequestDTO condition = new GomeEmployeeRequestDTO();
		if (StringUtils.isNotBlank(shop)){
			Set<String> orgCodeSet = new HashSet<>(1);
			orgCodeSet.add(shop);
			condition.setOrgCodeSet(orgCodeSet);
		}
		if (StringUtils.isNotBlank(categoryId)){
			Set<String> cateSet = new HashSet<>();
			cateSet.add(categoryId);
			condition.setBrandIdSet(cateSet);
		}
		if (StringUtils.isNotBlank(brandId)){
			Set<String> brandSet = new HashSet<>();
			brandSet.add(brandId);
			condition.setBrandIdSet(brandSet);
		}
		if(CollectionUtils.isNotEmpty(employeeIdList)){
			condition.setEmployeeIdSet(employeeIdList.stream().collect(Collectors.toSet()));
		}
		// header condition
		Map<String, String> requestHeader = new HashMap<>();
		requestHeader.put("invokeFrom", INVOKE_SOURCE);
		// collect condition
		RequestDTO<GomeEmployeeRequestDTO> queryCondition = new RequestDTO<>();
		queryCondition.setBody(condition);
		queryCondition.setRequestHeader(requestHeader);

		log.info(String.format("Dubbo/RPC-员工信息查询-新接口-无分页-条件, orderId:%s, condition: %s", orderId, JSONObject.toJSONString(condition)));
		ResponseDTO<ListResult<GomeEmployeeResponseDTO>> listResultResponseDTO = gomeEmployeeClient.queryEmployeeInformation(queryCondition);
		log.info(String.format("Dubbo/RPC-员工信息查询-新接口-无分页-反参, orderId:%s, return: %s", orderId, JSONObject.toJSONString(listResultResponseDTO)));
		List<EmployeeInfoDto> collect = null;
		if(listResultResponseDTO.getSuccess()){
			ListResult<GomeEmployeeResponseDTO> body = listResultResponseDTO.getBody();
			if (CollectionUtils.isNotEmpty(body.entities)){
				collect = body.entities.stream().map(x -> {
					return this.copyRightProperties(x);
				}).collect(Collectors.toList());
			}
		}
		log.info(String.format("Dubbo/RPC-员工信息查询-新接口-无分页-反参-封装-employee, orderId:%s, return: %s", orderId, JSONObject.toJSONString(collect)));
		return collect;
	}

	/**
	 *
	 * @param optional
	 * @return
	 */
	private EmployeeInfoDto copyRightProperties(GomeEmployeeResponseDTO optional){
		GomeEmployeeBaseInfoDTO baseInfo = optional.getGomeEmployeeBaseInfo();
		EmployeeInfoDto ei = new EmployeeInfoDto();
		// 基础信息
		EmployeeInfoBaseDto baseInfoDto = new EmployeeInfoBaseDto();
		baseInfoDto.setEmplClass(baseInfo.getEmployeeType());
		baseInfoDto.setEmployeeId(baseInfo.getEmployeeId());
		baseInfoDto.setEmployeeName(baseInfo.getEmployeeName());
		baseInfoDto.setStatus(baseInfo.getStatus());
		baseInfoDto.setCompanyId(baseInfo.getCompanyId());
		baseInfoDto.setCompanyName(baseInfo.getCompanyDesc());
		ei.setBaseInfo(baseInfoDto);
		// 员工岗位信息
		List<GomeEmployeePositionInfoDTO> gepil = optional.getGomeEmployeePositionInfoList();
		gepil = Optional.ofNullable(gepil).orElse(new ArrayList<>());
		List<GomeEmployeePostInformation> gepil_ = gepil.stream().map(x -> {
			GomeEmployeePostInformation gpi = new GomeEmployeePostInformation();
			gpi.setBranchId1(x.getBranchId1());
			gpi.setBranchId2(x.getBranchId2());
			gpi.setBranchName1(x.getBranchName1());
			gpi.setBranchName2(x.getBranchName2());
			gpi.setOrganizationId(x.getOrganizationId());
			gpi.setOrganizationName(x.getOrganizationName());
			gpi.setPostCode(x.getPositionCode());
			gpi.setPostDesc(x.getPositionName());
			gpi.setPostType(x.getPrimaryPostTag());
			gpi.setRegioneId(x.getRegioneId());
			gpi.setRegioneName(x.getRegioneName());
			gpi.setShop(x.getOrgCode());
			gpi.setStoreId(x.getStoreId());
			return gpi;
		}).collect(Collectors.toList());
		ei.setGomeEmployeePostInformationList(gepil_);

		//	品牌品类信息主营兼营信息
		List<GomeCategoryBrand> gsscbList = new ArrayList<>();
		gepil.stream().forEach(x -> {
			x.getGomeEmployeePositionCategoryBrandList().stream().forEach( y -> {
				GomeCategoryBrand gcb = new GomeCategoryBrand();
				gcb.setBrandCode(y.getBrandCode());
				gcb.setBrandName(y.getBrandName());
				gcb.setCategoryCode(y.getCategoryCode());
				gcb.setCategoryName(y.getCategoryName());
				gcb.setIsMain(y.getIsMain());
				gsscbList.add(gcb);
			});
		});
		ei.setGsscbList(gsscbList);
		// 供应商信息
		List<GomeEmployeeVendorCategoryBrandDTO> gomeEmployeeVendorList = optional.getGomeEmployeeVendorList();
		gomeEmployeeVendorList = Optional.ofNullable(gomeEmployeeVendorList).orElse(new ArrayList<>());
		List<ResponseGroupVendorDto> groupVendorDtos = gomeEmployeeVendorList.stream().map(x -> {
			ResponseGroupVendorDto gv = new ResponseGroupVendorDto();
			gv.setVendorName(x.getVendorName());
			gv.setVendorCode(x.getVendorCode());
			return gv;
		}).collect(Collectors.toList());
		ei.setGomeVendorList(groupVendorDtos);
		return ei;
	}

}
