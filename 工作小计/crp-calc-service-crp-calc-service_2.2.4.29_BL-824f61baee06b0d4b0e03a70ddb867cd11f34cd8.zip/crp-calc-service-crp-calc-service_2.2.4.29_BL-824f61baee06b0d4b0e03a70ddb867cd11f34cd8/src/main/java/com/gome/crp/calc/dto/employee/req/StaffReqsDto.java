package com.gome.crp.calc.dto.employee.req;

import java.util.List;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 员工查询所需要的字段
 * 
 * @author libinbin9
 *
 */
@Setter
@Getter
public class StaffReqsDto {
	
	
	
	public StaffReqsDto() {
		super();
	}
	

	/**
	 * 构造基础信息方法
	 * @param staffCodeList
	 * @param shopNo
	 * @param eaCateSecond
	 * @param eaBrandCode
	 * @param supplierCode
	 */
	public StaffReqsDto(List<String> staffCodeList, String shopNo, String eaCateSecond, String eaBrandCode,
			String supplierCode) {
		this.staffCodeList = staffCodeList;
		this.shopNo = shopNo;
		this.eaCateSecond = eaCateSecond;
		this.eaBrandCode = eaBrandCode;
		this.supplierCode = supplierCode;
	}
	// 订单orderUserId
	private String orderUserId;
	// 门店No
	private String shopNo;
	// 线下二级品类
	private String eaCateSecond; 
	// 线下品牌
	private String eaBrandCode;
	// 门店级别
	private String storeLevel;
	// 供应商编码
	private String supplierCode;
	// log嵌入信息: 需要将多余的外部特殊标识信息添加到该字段中作为下沉标记 
	private String logEmbedPort = "-";
	
	// 员工编码集合
	private List<String> staffCodeList;
	// 券集合
	private List<OrderCalcCouponDto> couponsDtoList;
	// 商品分享人
	private String productShareUserId;
	// 券分享人
	private String couponShareUserId;
	// 渠道编号
	private String channelNo;
	//订单号
	private String orderId;
	//行项目号
	private String commerceItemId;
	
}
