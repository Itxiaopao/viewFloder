package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 订单计算结果防重表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class CalcResultRepeat {

	private Long id; //id
	private String orderId; //订单号
	private String deliveryId; //配送单id
	private String gomeStatus; //订单状态
	private String skuNo; //skuno
	private String detailId; //detailid号
	private String channel; //订单渠道
	private String returnOrderId; //退货单号
}