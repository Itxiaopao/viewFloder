
package com.gome.crp.calc.filter;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcException;
import com.alibaba.fastjson.JSONObject;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Activate(group={ Constants.PROVIDER, Constants.CONSUMER })
public class DubboRuntimeFilter implements Filter {
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        // before filter ...
    	long start_time = System.currentTimeMillis();
        Result result = invoker.invoke(invocation);
        // after filter ...
        long end_time = System.currentTimeMillis();
        String methodName = invocation.getMethodName();
        Object[] arguments = invocation.getArguments();
        String interface_name = invocation.getAttachment("interface");
        URL url = invoker.getUrl();
        String host = url.getHost();
        log.debug(String.format("Dubbo-RPC执行耗时(ms):%s, IP:%s, path: %s, args:%s", (end_time - start_time), host, interface_name+"."+methodName, JSONObject.toJSONString(arguments)));
        return result;
    }
}