package com.gome.crp.calc.client.jk;


import com.gome.crp.calc.dto.jkDto.QueryShareUserReqDto;
import com.gome.crp.calc.dto.jkDto.QueryShareUserResDto;

/**
 * 集客系统接口
 * http://nvwa.gome.inc/gaim/interfaceDetail.do#/api/detail/031a76f9-fa8f-4777-a105-d3ba47e0d9da
 */
public interface IJKService {

    /**
     * 查询下单用户在老集客活动中的链路上级用户
     *
     * @param reqDto
     * @return
     */
    QueryShareUserResDto queryShareUser(QueryShareUserReqDto reqDto);
}