package com.gome.crp.calc.service.scene.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.jk.impl.JKServiceImpl;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.jkDto.QueryShareUserReqDto;
import com.gome.crp.calc.dto.jkDto.QueryShareUserResDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.manager.CalcOrderRecordManager;
import com.gome.crp.calc.manager.CalcResultManager;
import com.gome.crp.calc.manager.CalcSceneYRecordManager;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.scene.abstr.AbstractSceneService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcSceneYRecord;
import com.gome.staff.bind.model.domain.StaffBind;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * y场景
 *
 * @author libinbin9
 */
@Slf4j
@Service
public class SceneYServiceImpl extends AbstractSceneService {

    @Autowired
    private JKServiceImpl jkServiceImpl;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private IProblemService iProblemService;
    @Autowired
    private CalcSceneYRecordManager calcSceneYRecordManager;
    @Autowired
    private CalcResultManager calcResultManager;
    @Autowired
    private IStaffInfoService staffInfoService;
    @Autowired
    private IBillService iBillService;
    @Autowired
    private IProblemService problemService;
    @Autowired
    private CalcOrderRecordManager calcOrderRecordManager;
    @Autowired
    private SeqGenUtil seqGenUtil;
    private static final Integer PAGE_SIZE = 10;

    @Override
    public List<ProfitDto> calc(OrderCalcDto orderDto, PlanDto planDto) {
        log.info("开始处理Y,orderId:{},planId:{}", orderDto.getOrderId(), planDto.getPlanId());
        if (!planDto.getPromotionsType().toString().equals(BaseConstants.PLAN_INVITE_GUEST_TYPE)) {
            log.info("促销费类型非拓客活动,orderId:{},detailId:{},planId:{}", orderDto.getOrderId(), orderDto.getDetailId(), planDto.getPlanId());
            return null;
        }
        List<PersonDto> profitPerson = getProfitPerson(orderDto, planDto);
        if (null == profitPerson || profitPerson.size() == 0) {
            log.info("集客活动查询到的获利人为空,orderId:{},detailId:{},jikeActivityId:{},planId:{}", orderDto.getOrderId(), orderDto.getDetailId(), planDto.getCollectionId(), planDto.getPlanId());
            problemService.addData(orderDto, planDto, null, null, ProblemEnum.CODE_122);
            return null;
        }
        ArrayList<ProfitDto> profitDtos = new ArrayList<>();
        if (!checkRepeat(CacheKeyConstants.getKeyOfSceneYRepeat(orderDto.getOrderId(), orderDto.getDetailId(), planDto.getPlanId().toString()))) {
            log.info("该订单已经计算过Y,orderId:{},planId:{}", orderDto.getOrderId(), planDto.getPlanId());
            iProblemService.addData(orderDto, planDto, null, "该订单已经计算过Y", ProblemEnum.CODE_110);
            return null;
        }
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH, instance.get(Calendar.DAY_OF_MONTH) - 1);
        Date time = instance.getTime();
        if (instance.getTime().compareTo(planDto.getEndTime()) == 1) {
            log.info("mq延迟时间大于计划结束+24h,orderId:{},planId:{}", orderDto.getOrderId(), planDto.getPlanId());
            iProblemService.addData(orderDto, planDto, null, null, ProblemEnum.CODE_112);
            return null;
        }
        try {
            for (PersonDto personDto : profitPerson) {
                //计提基数
                if (planDto.getProvisionType() == BaseConstants.PLAN_PROVISION_REAL) {
                    //实付金额判断
                    if (orderDto.getPrice().longValue() >= planDto.getAwardMoney()) {
                        ProfitDto profitDto = dealParam(orderDto, planDto);
                        profitDto.setPersonDto(personDto);
                        profitDtos.add(profitDto);
                    } else {
                        log.info("订单金额小于提奖金额,orderId:{},planId:{},计提基数:{}", orderDto.getOrderId(), planDto.getPlanId(), planDto.getProvisionType());
                        iProblemService.addData(orderDto, planDto, null, "订单金额低于提奖限价", ProblemEnum.CODE_108);
                    }
                } else {
                    //销售金额判断
                    if (orderDto.getSalePrice().longValue() >= planDto.getAwardMoney()) {
                        ProfitDto profitDto = dealParam(orderDto, planDto);
                        profitDto.setPersonDto(personDto);
                        profitDtos.add(profitDto);
                    } else {
                        log.info("订单金额小于提奖金额,orderId:{},planId:{},计提基数:{}", orderDto.getOrderId(), planDto.getPlanId(), planDto.getProvisionType());
                        iProblemService.addData(orderDto, planDto, null, "订单金额低于提奖限价", ProblemEnum.CODE_108);
                    }
                }
            }

        } catch (Exception e) {
            log.error("计算y场景出错,orderId:{},planId:{},exception: ", orderDto.getOrderId(), planDto.getPlanId(), e);
            gcacheUtil.deleteKey(new String[]{CacheKeyConstants.getKeyOfSceneYRepeat(orderDto.getOrderId(), orderDto.getDetailId(), planDto.getPlanId().toString())});
            iProblemService.addData(orderDto, planDto, null, null, ProblemEnum.CODE_111);
            return null;
        }
        return profitDtos;
    }

    /**
     * 获取获利人
     *
     * @param orderDto
     * @param planDto
     * @return
     */
    @Override
    public List<PersonDto> getProfitPerson(OrderCalcDto orderDto, PlanDto planDto) {
        List<PersonDto> list = new ArrayList<>();
        String activityId = planDto.getCollectionId();
        String userId = orderDto.getUserId();
        Date date = orderDto.getPayDate();
        QueryShareUserReqDto reqDto = new QueryShareUserReqDto();
        reqDto.setOrderDate(date);
        reqDto.setActivityId(activityId);
        reqDto.setUserId(userId);
        QueryShareUserResDto queryShareUser = jkServiceImpl.queryShareUser(reqDto);
        if (queryShareUser == null || StringUtils.isBlank(queryShareUser.getStaffCode())) {
            log.info("集客接口查询获利人为空activityId:{},orderDate:{},userId:{}", activityId, date, userId);
            return null;
        }
        if (queryShareUser != null) {
            //使用员工id去查询
            EmployeeInfoDto empl = staffInfoService.getEmployeeDtoByStaffCode(queryShareUser.getStaffCode());
            log.info(String.format("y场景查询获利人信息, 订单id:%s, staffCode:%s, 结果:%s", orderDto.getOrderId(), queryShareUser.getStaffCode(), JSONObject.toJSONString(empl)));
            PersonDto personDto = null;
            StaffBind userInfoByStaffCode = staffInfoService.getUserInfoByStaffCode(queryShareUser.getStaffCode());
            log.info("y场景查询获利人信息,通过员工编码查询结果,orderId:{},入参:{},返参:{}", orderDto.getOrderId(), queryShareUser.getStaffCode(), JSONObject.toJSONString(userInfoByStaffCode));
            if (empl != null) {
                personDto = this.copyProperies(empl, orderDto.getShopNo(), orderDto.getSupplier(), null != userInfoByStaffCode ? userInfoByStaffCode.getZxUid() : null, null,ProfitBehaviorEnum.GATHERING_CUSTOMERS_STAFF.getCode());
                list.add(personDto);
                return list;
            } else {
                personDto = new PersonDto();
                personDto.setStaffCode(queryShareUser.getStaffCode());
                personDto.setUserId(null != userInfoByStaffCode ? userInfoByStaffCode.getZxUid() : null);
                personDto.setProfitBehaviorCode(ProfitBehaviorEnum.GATHERING_CUSTOMERS_STAFF.getCode());
                list.add(personDto);
            }
        }
        return list;
    }

    @Override
    public String getScene() {
        return BaseConstants.SCENE_Y;
    }

    /**
     * 幂等性校验
     *
     * @param key
     * @return
     */
    public boolean checkRepeat(String key) {
        if (gcacheUtil.distributedLockAtom(CacheKeyConstants.getKeyOfDistributed(key), CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, Long.toString(System.currentTimeMillis())).equals(1L)) {
            return true;
        }
        return false;
    }

    /**
     * 封装数据
     *
     * @param orderDto
     * @param planDto
     * @return
     */
    public ProfitDto dealParam(OrderCalcDto orderDto, PlanDto planDto) {
        ProfitDto profitDto = new ProfitDto();
        profitDto.setAwardAmount(new BigDecimal(0));
        profitDto.setScenes(BaseConstants.SCENE_Y);
        return profitDto;
    }

    /**
     * 插入或者更新处理y的数据
     *
     * @param orderId   订单号
     * @param profileId 下单人
     * @param planId    计划id
     * @param staffCode 获利人员工编码
     */
    public void saveOrUpdateSceneY(String orderId, String profileId, String planId, String staffCode, Date planEndTime, Long paymentMoney) {
        CalcSceneYRecord calcSceneYRecord = new CalcSceneYRecord();
        calcSceneYRecord.setPlanId(planId);
        calcSceneYRecord.setProfileId(profileId);
        calcSceneYRecord.setStaffCode(staffCode);
        calcSceneYRecord.setPlanEndTime(planEndTime);
        if (StringUtils.isBlank(staffCode)) {
            log.info("集客场景处理获利人员工编码为空,orderId:{},profileId:{},planId:{}", orderId, profileId, planId);
            ProblemDto problemDto = new ProblemDto(orderId.toString(), null, null, null);
            problemDto.setDescription("集客场景处理获利人员工编码为空");
            iProblemService.addData(problemDto, ProblemEnum.CODE_120);
            return;
        }
        CalcSceneYRecord calcSceneYRecordRes = calcSceneYRecordManager.queryCalcSceneYRecord(calcSceneYRecord);
        if (null == calcSceneYRecordRes) {
            calcSceneYRecord.setAwardPrice(paymentMoney);
            calcSceneYRecordManager.saveCalcSceneYRecord(calcSceneYRecord);
        }
    }

    public void jobDealSceneY() {
        Integer count = selectCount();
        if (null == count || count == 0) {
            log.info("查询SceneY满足条件条数为0");
        }
        int forCount = count / PAGE_SIZE;
        int times = forCount * PAGE_SIZE == count ? forCount : forCount + 1;
        for (int i = 0; i < times; i++) {
            List<CalcSceneYRecord> calcSceneYRecords = selectData();
            if (null == calcSceneYRecords || calcSceneYRecords.size() == 0) {
                log.info("分页查询sceney表未返回数据");
                return;
            }
            for (CalcSceneYRecord calcSceneYRecord : calcSceneYRecords) {
                execute(calcSceneYRecord);
            }
        }
    }

    /**
     * 扫描总条数
     *
     * @return
     */
    public Integer selectCount() {
        return calcSceneYRecordManager.queryCountOfSceneY();
    }

    /**
     * 扫描数据
     *
     * @return
     */
    public List<CalcSceneYRecord> selectData() {
        return calcSceneYRecordManager.queryListOfSceneY(PAGE_SIZE);
    }

    /**
     * 执行更新状态
     */
    public void execute(CalcSceneYRecord calcSceneYRecord) {
        if (null == calcSceneYRecord) {
            log.error("查询result表入参为空，执行时间：{}", new Date().toString());
            return;
        }
        if (StringUtils.isBlank(calcSceneYRecord.getStaffCode())) {
            log.error("查询result表，userId和staffCode同时为空，执行时间：{}", new Date().toString());
            return;
        }
        if (StringUtils.isBlank(calcSceneYRecord.getPlanId()) || StringUtils.isBlank(calcSceneYRecord.getProfileId())) {
            log.error("查询result表，planId或profileId为空，执行时间：{}", new Date().toString());
            return;
        }
        CalcResult calcResult = new CalcResult();
        BeanUtils.copyProperties(calcSceneYRecord, calcResult);
        List<CalcResult> calcResults = calcResultManager.queryListOfSceneYFromResult(calcResult);
        if (null == calcResults || calcResults.size() == 0) {
            log.error("查询result表未查询出数据，修改已扫描状态，userId:{},staffCode:{},prifileId:{},planId:{}", calcSceneYRecord.getUserId(), calcSceneYRecord.getStaffCode(), calcSceneYRecord.getProfileId(), calcSceneYRecord.getPlanId());
            calcSceneYRecord.setIsScan(BaseConstants.IS_SCAN_ENUM);
            calcSceneYRecordManager.updateCalcSceneYRecord(calcSceneYRecord);
            return;
        }
        ArrayList<CalcResult> updateCalcResult = new ArrayList<CalcResult>(calcResults.size());
        List<BigDecimal> perAwardPrice = getPerAwardPrice(calcSceneYRecord.getAwardPrice(), calcResults.size());
        for (int j = 0; j < calcResults.size(); j++) {
            CalcResult tempClacResult = calcResults.get(j);
            tempClacResult.setAwardAmount(perAwardPrice.get(j).longValue());
            tempClacResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_1_N);
            updateCalcResult.add(tempClacResult);
        }
        if (calcResultManager.updateByList(updateCalcResult)) {
            dealOrderRecordAfterUpdateResult(updateCalcResult);
            calcSceneYRecord.setIsScan(BaseConstants.IS_SCAN_ENUM);
            calcSceneYRecordManager.updateCalcSceneYRecord(calcSceneYRecord);
        }
    }

    /**
     * 计算y金额同步保存到record表中
     * @param calcResults
     */
    public void dealOrderRecordAfterUpdateResult(List<CalcResult> calcResults) {
        if (CollectionUtils.isEmpty(calcResults)) {
            for (CalcResult calcResult : calcResults) {
                CalcRecord calcRecord = new CalcRecord();
                BeanUtils.copyProperties(calcResult, calcRecord);
                calcRecord.setId(seqGenUtil.nextCrpCalcRecordId());
                calcOrderRecordManager.save(calcRecord);
            }
        }

    }


}
