package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Fi475Dto implements Serializable {
    private static final long serialVersionUID = 1L;
    private String flag; //有函标识
    private List<ItemDto> item;
}
