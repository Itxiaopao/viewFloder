package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * sap下发订单消息表 Model
 *
 * @author zhangshuang
 */
@Getter
@Setter
@ToString
public class SapOrderRecord {

    private Long id; //id
    private String saleTicket; //销售单号
    private String saleChannel; //销售渠道
    private String sapItemNum; //sap行项目号
    private String deliveryId; //配送单号
    private String sapDetailId; //sapDetailId号
    private String detailId; //detailId号
    private String productCode; //商品编码
    private BigDecimal num; //数量
    private String purchaseOrganization; //采购组织
    private String address; //地点
    private String stockAddress; //库存地点
    private String supplierCode; //供应商编码
    private String saleModelCode; //业务机型
    private String shipCompanyCode; //发货公司代码
    private String contractCode; //合同号
    private String extraNum; //协议号
    private String saleWayCode;//销售方式
    private Integer operationType; //操作类型
    private Date operationTime; //操作时间
    private Integer isScan; //是否已扫描1:已扫描,0:未扫描
    private Integer isEnable; //是否启用1:启用,0:禁止
    private Date createTime; //createTime
    private Date updateTime; //updateTime
    private Integer isDelete; //0未删除，1已删除

}