package com.gome.crp.calc.dto.threadLocal;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import lombok.Data;

/**
 * 本地 local
 */
@Data
public class LocalDto {
    private Long beginTime;
    private int type;
    private OrderCalcDto orderCalcDto;
    private PlanDto planDto;

}
