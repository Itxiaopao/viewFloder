package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcContractMq;

public interface CalcContractMqMapper extends BaseMapper<CalcContractMq> {

}
