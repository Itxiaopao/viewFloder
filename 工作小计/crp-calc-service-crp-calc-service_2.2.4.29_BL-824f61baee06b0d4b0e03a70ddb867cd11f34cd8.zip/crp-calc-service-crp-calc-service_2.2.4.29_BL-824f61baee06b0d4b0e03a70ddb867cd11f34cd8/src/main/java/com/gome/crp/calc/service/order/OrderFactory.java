package com.gome.crp.calc.service.order;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.service.order.impl.OrderCLServiceImpl;
import com.gome.crp.calc.service.order.impl.OrderCOServiceImpl;
import com.gome.crp.calc.service.order.impl.OrderDLServiceImpl;
import com.gome.crp.calc.service.order.impl.OrderRCOServiceImpl;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class OrderFactory implements InitializingBean {
    private static final Map<String, IOrderService> orderStatusServiceMap = new HashMap<>();
    @Autowired
    private OrderCLServiceImpl orderCLServiceImpl;
    @Autowired
    private OrderCOServiceImpl orderCOServiceImpl;
    @Autowired
    private OrderDLServiceImpl orderDLServiceImpl;
    @Autowired
    private OrderRCOServiceImpl orderRCOServiceImpl;

    public IOrderService getOrderStatusServiceObj(OrderCalcDto orderCalcDto) {
        return orderStatusServiceMap.get(orderCalcDto.getGomeState());
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        orderStatusServiceMap.put(BaseConstants.ORDER_CO_STATUS, orderCOServiceImpl); //配送单已生效
        orderStatusServiceMap.put(BaseConstants.ORDER_DL_STATUS, orderDLServiceImpl); //配送单已妥投

        orderStatusServiceMap.put(BaseConstants.ORDER_CL_STATUS, orderCLServiceImpl); //订单已取消
        orderStatusServiceMap.put(BaseConstants.ORDER_RT_STATUS, orderCLServiceImpl); //配送单拒收

        orderStatusServiceMap.put(BaseConstants.ORDER_RCO_STATUS, orderRCOServiceImpl); //退货审核完成

        /*
        orderStatusServiceMap.put(BaseConstants.ORDER_CL_STATUS, orderCLServiceImpl); //订单已取消
        orderStatusServiceMap.put(BaseConstants.ORDER_RT_STATUS, orderRVServiceImpl); //配送单拒收
        orderStatusServiceMap.put(BaseConstants.ORDER_RCO_STATUS, orderRCOServiceImpl); //退货审核完成
        */
    }


}
