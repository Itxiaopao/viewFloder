package com.gome.crp.calc.dto.contractDto;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * 主推函
 */
@Data
public class PushLetterDto implements Serializable {

    private static final long serialVersionUID = 3697186395823685162L;

    private String contractCode;//合同编号
    private String documentType;//合同类型
    private String protocolCode;//主推函号
    private String brandCode;//品牌编码
    private String classCode;//品类编码
    private String suppCode;//供应商编码
    private String buyOrgCode;//采购组织编码
    private String companyCode;//公司编码
    private String className;//品类名称
    private String brandName;//品牌名称
    private String suppName;//供应商名称
    private String buyOrgName;//采购组织名称
    private String companyName;//公司名称
    private BigDecimal offerPrice;//供价
    private String salesModel;//业务机型
    private BigDecimal costIncrease;//计提限价
    private BigDecimal addEachRebate;//合同政策值(新增台返)
    private BigDecimal addMonthlyRebate;//合同政策值(新增月返)


}
