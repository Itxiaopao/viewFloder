package com.gome.crp.calc.service.scene;

import java.math.BigDecimal;
import java.util.List;

import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

/**
 * 场景接口类
 * <p>1.生效条件</p>
 * <p>2.获利人</p>
 * <p>3.计算逻辑</p>
 *
 * @author libinbin9
 */
public interface ISceneService {

	/**
	 * 根据 订单，计划 进行提成计算
	 * @param orderCalcDto 订单信息
	 * @param planDto 计划信息
	 * @return ProfitDto
	 * @see com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
	 * @see com.gome.crp.calc.dto.planDto.PlanDto
	 * @see com.gome.crp.calc.dto.profitDto
	 */
	List<ProfitDto> calc(OrderCalcDto orderCalcDto, PlanDto planDto);

	/**
	 * 根据 订单，计划 进行获利人的查询
	 * @param orderDto
	 * @param planDto
	 * @return
	 */
	List<PersonDto> getProfitPerson(OrderCalcDto orderDto, PlanDto planDto);

	/**
	 * 获取当前计算场景
	 * @return
	 */
	String getScene();
	
}
