package com.gome.crp.calc.mybatis.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcResultRewardMapper;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.mybatis.service.ICalcResultRewardService;
import org.springframework.stereotype.Service;

@Service
public class CalcResultRewardServiceImpl extends ServiceImpl<CalcResultRewardMapper, CalcResultReward> implements ICalcResultRewardService {
}
