package com.gome.crp.calc.client.message.impl;

import java.io.File;

import javax.mail.util.ByteArrayDataSource;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

/***
 * 邮件发送工具类
 *
 * @author lisuo
 *
 */
@Slf4j
@Service
public class EmailUtil {

	@Value("${email.host.name}")
    private String hostName;
	@Value("${email.smtp.port}")
    private Integer smtpPort;
    @Value("${email.timeout}")
    private Integer timeout;
    @Value("${email.username}")
    private String username;
    @Value("${email.password}")
    private String password;
    private Boolean auth = false;
    private String nickname = "提成系统邮件";
    
    // 根据配置文件创建邮件信息
    private HtmlEmail buildEmail() throws EmailException {
        HtmlEmail email = new HtmlEmail();
        email.setCharset("UTF-8");
        email.setHostName(hostName);
        email.setSmtpPort(smtpPort);
        email.setSSLOnConnect(auth);
        email.setSocketConnectionTimeout(timeout);
        email.setAuthentication(username, password);
        email.setFrom(username, nickname);
        email.setSocketConnectionTimeout(timeout);
        return email;
    }

    /**
     * @param topic  主题
     * @param body   内容
     * @param sendTo 接收人
     */
    public boolean sendEmail(String topic, String body, String... sendTo) {
        try {
            HtmlEmail email = buildEmail();
            email.addTo(sendTo);
            email.setSubject(topic);
            email.setHtmlMsg(body);
            email.send();
        } catch (EmailException e) {
            log.error("发送邮件出现异常，topic is {}, body is {}, sendTo is {}, exception is {}", topic, body, sendTo, e);
            return false;
        }
        return true;
    }

    /**
     * @param topic  主题
     * @param body   内容
     * @param sendTo 接收人
     * @param file   附加文件
     * @return
     */
    public boolean sendEmail(String topic, String body, String[] sendTo, File file) {
        return sendEmail(topic, body, sendTo, new File[]{file});
    }

    /**
     * @param topic  主题
     * @param body   内容
     * @param sendTo 接收人
     * @param fileName 附加文件
     * @return
     */
    public boolean sendEmail(String topic, String body, String[] sendTo, String fileContent, String fileName) {
        try {
            HtmlEmail email = buildEmail();
            email.addTo(sendTo);
            email.setSubject(topic);
            email.setHtmlMsg(body);
            ByteArrayDataSource ds = new ByteArrayDataSource(fileContent, "text/html");
            email.attach(ds, fileName, fileName);
            email.send();
        } catch (Exception e) {
        	log.error("发送邮件出现异常，topic is {}, body is {}, sendTo is {}, exception is {}", topic, body, sendTo, e);
            return false;
        }
        return true;
    }


    /**
     * @param topic  主题
     * @param body   内容
     * @param sendTo 接收人
     * @param files  附加文件
     * @return 发送结果
     */
    public boolean sendEmail(String topic, String body, String[] sendTo, File[] files) {
        try {
            HtmlEmail email = buildEmail();
            email.addTo(sendTo);
            email.setSubject(topic);
            email.setHtmlMsg(body);
            if (ArrayUtils.isNotEmpty(files)) {
                for (File file : files) {
                    email.attach(file);
                }
            }
            email.send();
        } catch (EmailException e) {
        	log.error("发送邮件出现异常，topic is {}, body is {}, sendTo is {}, exception is {}", topic, body, sendTo, e);
            return false;
        }
        return true;
    }

}
