package com.gome.crp.calc.service.bill.impl;

import com.gome.crp.calc.client.sap.ISapService;
import com.gome.crp.calc.client.settlement.IPayService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.LetterEnum;
import com.gome.crp.calc.constants.SapEnum;
import com.gome.crp.calc.dto.payDto.ApplyPayItemDto;
import com.gome.crp.calc.dto.payDto.ApplyPayReqDto;
import com.gome.crp.calc.dto.sapDto.ApplyBillReqDto;
import com.gome.crp.calc.dto.sapDto.Fi475Dto;
import com.gome.crp.calc.dto.sapDto.HeaderDto;
import com.gome.crp.calc.dto.sapDto.ItemDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.util.BigDecimalUtils;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.util.SeqGenUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BillServiceImpl implements IBillService {
    @Autowired
    private ISapService iSapService;
    @Autowired
    private SeqGenUtil seqGenUtil;
    @Autowired
    private IPayService iPayService;
    @Value("${sap.rate.value}")
    private String sapRateValue;


    @Override
    public List<SapRecord> applyBill(List<CalcResult> calcResultList) {
        Map<Integer, List<CalcResult>> letterTypeCalcResultListMap = new HashMap<>();

        List<SapRecord> sapRecordList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            //是否需要挂账
            if (isValid(calcResult)) {

                Integer letterType = null;
                try {
                    //检查函类型
                    letterType = getLetterType(calcResult);
                } catch (Exception e) {
                    log.error("签约类型不正确calcResultId:{},contractType:{}", calcResult.getId(), calcResult.getContractType(), e);
                    continue;
                }

                if (letterType == null) {
                    continue;
                }

                //按函类型封装集合
                if (letterTypeCalcResultListMap.containsKey(letterType)) {
                    letterTypeCalcResultListMap.get(letterType).add(calcResult);
                } else {
                    List<CalcResult> calcResults = new ArrayList<>();
                    calcResults.add(calcResult);
                    letterTypeCalcResultListMap.put(letterType, calcResults);
                }
            }
        }

        for (Map.Entry<Integer, List<CalcResult>> entry : letterTypeCalcResultListMap.entrySet()) {
            List<SapRecord> letterSapRecords = applyBill(entry.getValue(), entry.getKey());
            sapRecordList.addAll(letterSapRecords);
        }

        return sapRecordList;
    }

    //是否有效数据
    private boolean isValid(CalcResult calcResult) {
        //金额不能为空
        if (calcResult.getAwardAmount() == null || calcResult.getAwardAmount() == 0L) {
            return false;
        }

        //正向金额为正
        if ((BaseConstants.ORDER_CO_STATUS.equals(calcResult.getGomeStatus()) ||
                BaseConstants.ORDER_DL_STATUS.equals(calcResult.getGomeStatus())) &&
                calcResult.getAwardAmount() < 0) {
            return false;
        }

        //逆向金额为负
        if (!(BaseConstants.ORDER_CO_STATUS.equals(calcResult.getGomeStatus()) ||
                BaseConstants.ORDER_DL_STATUS.equals(calcResult.getGomeStatus())) &&
                calcResult.getAwardAmount() > 0) {
            return false;
        }

        //费用承担方是供应商承担挂账
        if (calcResult.getExpencesOfferType() != null && BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE.equals(String.valueOf(calcResult.getExpencesOfferType()))) {
            return true;
        } else {
            return false;
        }

    }

    private boolean isSpecialScene(CalcResult calcResult) {
        if ((BaseConstants.SCENE_Z.equals(calcResult.getScenes()) ||
                BaseConstants.SCENE_M.equals(calcResult.getScenes())) && (
                BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(calcResult.getExtraPolicyCode()) ||
                        BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(calcResult.getExtraPolicyCode()))) {
            return true;
        }

        return false;
    }

    @Override
    public List<SapRecord> applyBill(List<CalcResult> calcResultList, Integer letterType) {
        List<SapRecord> sapRecordList = new ArrayList<>(calcResultList.size());
        if (!CollectionUtils.isEmpty(calcResultList)) {
            for (CalcResult calcResult : calcResultList) {
                SapRecord sapRecord = getSapRecord(calcResult, letterType);
                sapRecordList.add(sapRecord);
            }

            //调用接口挂账
            ApplyBillReqDto reqDto = buildApplyBillReqDto(sapRecordList, letterType);
            iSapService.applyBill(reqDto);
        }

        return sapRecordList;
    }

    private ApplyBillReqDto buildApplyBillReqDto(List<SapRecord> sapRecordList, Integer letterType) {
        ApplyBillReqDto reqDto = new ApplyBillReqDto();

        HeaderDto headerDto = new HeaderDto();
        Long seqNum = seqGenUtil.nextCrpCalcCommonId();
        headerDto.setMessageId(String.valueOf(seqNum));
        reqDto.setHeader(headerDto);

        Fi475Dto fi475Dto = new Fi475Dto();
        fi475Dto.setFlag(String.valueOf(letterType));

        List<ItemDto> items = new ArrayList<>(sapRecordList.size());
        for (SapRecord sapRecord : sapRecordList) {
            items.add(getItemDto(sapRecord));
        }
        fi475Dto.setItem(items);
        reqDto.setFi475(fi475Dto);
        return reqDto;
    }

    private ItemDto getItemDto(SapRecord sapRecord) {
        ItemDto itemDto = new ItemDto();
        itemDto.setBstkd(sapRecord.getBstkd());
        itemDto.setQxbs(sapRecord.getQxbs());
        itemDto.setPosrq(DateUtils.formatDate_yyyyMMdd(sapRecord.getPosrq()));
        itemDto.setMatnr(sapRecord.getMatnr());
        itemDto.setFkimg(sapRecord.getFkimg());
        itemDto.setDmbtr(BigDecimalUtils.changeF2Y(sapRecord.getDmbtr()));
        itemDto.setDmbtr1(BigDecimalUtils.changeF2Y(sapRecord.getDmbtr1()));
        //itemDto.setZwerks(sapRecord.getZwerks());
        itemDto.setZwerks("000000");//todo 临时方案
        itemDto.setLifnr(sapRecord.getLifnr());
        itemDto.setLevel4(sapRecord.getLevel4());
        itemDto.setPrdha(sapRecord.getPrdha());
        itemDto.setConno(sapRecord.getConno());
        itemDto.setKonnr(sapRecord.getKonnr());
        itemDto.setFlag1(sapRecord.getFlag1());
        itemDto.setTcjh(String.valueOf(sapRecord.getTcjh()));
        itemDto.setPernr(sapRecord.getPernr());
        itemDto.setCxflx(String.valueOf(sapRecord.getCxflx()));
        itemDto.setCxflxms(sapRecord.getCxflxms());
        return itemDto;
    }

    private SapRecord getSapRecord(CalcResult calcResult, Integer letterType) {
        SapRecord sapRecord = new SapRecord();
        sapRecord.setCalcResultId(calcResult.getId());
        sapRecord.setFlag(letterType);
        sapRecord.setBstkd(calcResult.getSapDetailId());
        sapRecord.setQxbs(SapEnum.QXBS_N.getCode());
        sapRecord.setPosrq(calcResult.getOrderSubmitTime());
        sapRecord.setMatnr(calcResult.getSkuNo());
        sapRecord.setFkimg(new BigDecimal(String.valueOf(calcResult.getBuyNum())));
        sapRecord.setDmbtr(calcResult.getSalePrice());

        //无函&&挂账比例不为空
        if (LetterEnum.NOT_HAVE_LETTER.getCode().equals(letterType)) {
            BigDecimal awardAmount = BigDecimalUtils.changeF2Y(calcResult.getAwardAmount());
            BigDecimal accountRateAwardAmount = BigDecimalUtils.divide(awardAmount, new BigDecimal(sapRateValue), 2);
            sapRecord.setDmbtr1(BigDecimalUtils.changeY2F(accountRateAwardAmount));
        } else {
            sapRecord.setDmbtr1(calcResult.getAwardAmount());
        }

        sapRecord.setZwerks(calcResult.getLogicMasLoc());
        sapRecord.setLifnr(calcResult.getOrderSupplierCode());
        sapRecord.setLevel4(calcResult.getCategoryLevelFour());
        sapRecord.setPrdha(calcResult.getBrandCode());
        sapRecord.setConno(calcResult.getContractCode());
        sapRecord.setKonnr(calcResult.getExtraNum());
        String scenes = calcResult.getScenes();
        sapRecord.setFlag1(scenes.substring(scenes.length() - 1));
        sapRecord.setTcjh(Long.valueOf(calcResult.getPlanId()));
        sapRecord.setPernr(calcResult.getStaffCode() == null ? "" : calcResult.getStaffCode());
        sapRecord.setCxflx(calcResult.getPromotionsType());
        sapRecord.setCxflxms(getPromotionsDesc(calcResult));
        return sapRecord;
    }

    /**
     * 获取促销费类型描述
     *
     * @return
     */
    private String getPromotionsDesc(CalcResult detail) {
        String promotionsType = String.valueOf(detail.getPromotionsType());
        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(promotionsType)) {
            return "无促";
        }

        if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(promotionsType)) {
            return "差异化";
        }

        if (BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(promotionsType)) {
            return "非差异化";
        }

        if (BaseConstants.PLAN_REPLACE_TYPE.equals(promotionsType)) {
            return "带单";
        }

        if (BaseConstants.PLAN_TOTAL_TYPE.equals(promotionsType)) {
            return "总额";
        }

        if (BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(promotionsType)) {
            return "拓客";
        }

        if (BaseConstants.PLAN_O2O_TYPE.equals(promotionsType)) {
            return "O2O";
        }

        throw new BusinessException(String.format("促销费类型不正确calcRecordDetailId:%s,promotionsType:%s", detail.getId(), promotionsType));
    }

    /**
     * 是否有函
     *
     * @param calcResult
     * @return
     */
    private Integer getLetterType(CalcResult calcResult) {
        if (BaseConstants.PLAN_SIGN_NO_TYPE.equals(calcResult.getContractType())) {
            return null;
        }

        if (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(calcResult.getContractType())
                || BaseConstants.PLAN_SIGN_NO_LETTER_TYPE_SUPPLIER.equals(calcResult.getContractType())) {
            return LetterEnum.NOT_HAVE_LETTER.getCode();
        }

        //特殊场景（场景Z或M,政策编码195或197）
        if (isSpecialScene(calcResult)) {
            return LetterEnum.NOT_HAVE_LETTER.getCode();
        }

        if (BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(calcResult.getContractType()) ||
                BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(calcResult.getContractType()) ||
                BaseConstants.PLAN_SIGN_LETTER_TYPE.equals(calcResult.getContractType())) {
            return LetterEnum.HAVE_LETTER.getCode();
        }

        throw new BusinessException(String.format("签约类型不正确calcResultId:%s,contractType:%s", calcResult.getId(), calcResult.getContractType()));
    }

    @Override
    public void applyPay(List<CalcResult> calcResultList) {
        ApplyPayReqDto reqDto = new ApplyPayReqDto();
        List<ApplyPayItemDto> itemList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            //过滤奖励金额是0的记录
            if (calcResult.getAwardAmount() == null || calcResult.getAwardAmount() == 0L) {
                log.info("支付挂账金额为零orderId:{},calcResult:{}", calcResult.getOrderId(), calcResult);
                continue;
            }
            ApplyPayItemDto itemDto = new ApplyPayItemDto();
            itemDto.setCalcResultId(calcResult.getId());
            itemDto.setScenes(calcResult.getScenes());
            itemDto.setGomeStatus(calcResult.getGomeStatus());
            itemDto.setAwardAmount(calcResult.getAwardAmount());
            itemDto.setDeliveryId(calcResult.getDeliveryId());
            itemDto.setExpencesOfferType(calcResult.getExpencesOfferType());
            itemDto.setDetailId(calcResult.getDetailId());
            itemDto.setSkuNo(calcResult.getSkuNo());
            itemDto.setSkuName(calcResult.getSkuName());
            itemDto.setBuyNum(calcResult.getBuyNum());
            itemDto.setOrderEffectTime(calcResult.getOrderEffectTime());
            itemDto.setCompanyCode(calcResult.getCompanyCode());
            itemDto.setShopNo(calcResult.getShopNo());
            itemDto.setUserId(calcResult.getUserId());
            itemDto.setPlanId(calcResult.getPlanId());
            itemDto.setIsGomeOffer(calcResult.getIsGomeOffer());
            itemDto.setIsASellA(calcResult.getIsAsella());
            itemDto.setChannel(calcResult.getChannel());
            itemList.add(itemDto);
        }

        if (CollectionUtils.isEmpty(itemList)) {
            return;
        }

        reqDto.setItems(itemList);
        iPayService.applyPay(reqDto);
    }

}
