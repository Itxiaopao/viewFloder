package com.gome.crp.calc.client.settlement;


import com.gome.crp.settlement.facade.vo.SaReverseOrderDto;

import java.util.List;

/**
 * 调取计算接口
 *
 * @author libinbin9
 */
public interface IClientSettlementService {

    /**
     * 推送计算接口, 当计算失败试, 加入计划重推表
     *
     * @param reverseOrderList
     */
    boolean receiveReverseOrder(List<SaReverseOrderDto> reverseOrderList);


}
