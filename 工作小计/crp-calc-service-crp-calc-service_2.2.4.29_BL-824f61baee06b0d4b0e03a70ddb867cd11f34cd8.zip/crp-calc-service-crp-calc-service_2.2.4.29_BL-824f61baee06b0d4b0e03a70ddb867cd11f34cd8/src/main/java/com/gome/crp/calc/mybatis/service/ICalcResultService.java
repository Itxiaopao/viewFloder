package com.gome.crp.calc.mybatis.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.gome.crp.calc.mybatis.model.CalcResult;

public interface ICalcResultService extends IService<CalcResult> {
}
