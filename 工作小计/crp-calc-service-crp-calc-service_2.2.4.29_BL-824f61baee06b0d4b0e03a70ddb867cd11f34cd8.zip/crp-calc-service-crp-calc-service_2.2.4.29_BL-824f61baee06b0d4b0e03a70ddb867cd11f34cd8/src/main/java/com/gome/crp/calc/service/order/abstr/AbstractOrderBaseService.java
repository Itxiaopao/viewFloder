package com.gome.crp.calc.service.order.abstr;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.sap.IQueryPlanService;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.dto.combiDto.CalcResultRecordDto;
import com.gome.crp.calc.dto.combiDto.SceneYDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.dto.threadLocal.LocalDto;
import com.gome.crp.calc.manager.CalcResultSingleManager;
import com.gome.crp.calc.mybatis.mapper.CalcNoResultMapper;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.mapper.SapAccountMapper;
import com.gome.crp.calc.mybatis.model.*;
import com.gome.crp.calc.service.budget.IBudgetService;
import com.gome.crp.calc.service.calc.CalcFatctory;
import com.gome.crp.calc.service.calc.ICalcService;
import com.gome.crp.calc.service.order.IOrderService;
import com.gome.crp.calc.service.plan.IPlanService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.rule.IRuleService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import com.gome.crp.common.util.ReflectUtil;
import com.gome.dragon.mds.client.dto.gcc.GomeOrganization;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public abstract class AbstractOrderBaseService implements IOrderService {

    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private IBudgetService iBudgetService;
    @Autowired
    private SeqGenUtil seqGenUtil;
    @Autowired
    private IPlanService planService;
    @Autowired
    private IProblemService problemService;
    @Autowired
    private IRuleService rule;
    @Autowired
    private CalcResultSingleManager calcResultSingleManager;
    @Autowired
    private IStaffInfoService iStaffInfoService;
    @Autowired
    private IQueryPlanService iQueryPlanService;
    @Autowired
    private CalcFatctory calcFatctory;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;
    @Autowired
    private SapAccountMapper sapAccountMapper;
    @Autowired
    private CalcNoResultMapper calcNoResultMapper;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private ICalcRewardsService calcRewardsService;
    @Autowired
    private com.gome.crp.calc.service.doctor.IPlanService doctorIPlanService;

    protected List<CalcResult> selectCalcResult(OrderCalcDto orderCalcDto) {
        CalcResult calcResult = new CalcResult();
        calcResult.setOrderId(orderCalcDto.getOrderId());
        calcResult.setSkuNo(orderCalcDto.getSkuNo());
        calcResult.setDetailId(orderCalcDto.getDetailId());
        calcResult.setChannel(orderCalcDto.getChannel());
        //calcResult.setCalcLogic(orderCalcDto.getCalcLogic());
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(calcResult);
        queryWrapper.eq("calc_logic", orderCalcDto.getCalcLogic()).or().eq("calc_logic", "");
        return calcResultMapper.selectList(queryWrapper);
    }

    protected List<CalcResult> getCancelApplyBillCalcResult(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto) {
        List<CalcResult> applyCalcResultList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            CalcResult applyCalcResult = ReflectUtil.converter(calcResult, CalcResult.class);
            applyCalcResult.setGomeStatus(orderCalcDto.getGomeState());
            applyCalcResult.setSapDetailId(orderCalcDto.getSapDetailId());
            if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())) {
                applyCalcResult.setOrderEffectTime(orderCalcDto.getOrderDate());
            }
            applyCalcResult.setAwardAmount(-1 * calcResult.getAwardAmount());

            //已挂账
            if (applyCalcResult.getIsOfflineApplyBill() != null && BaseConstants.Bill_OFFLINE_APPLY_1.equals(String.valueOf(applyCalcResult.getIsOfflineApplyBill()))) {
                applyCalcResultList.add(applyCalcResult);
            }
        }
        return applyCalcResultList;
    }

    /**
     * @param calcResultList
     * @param orderCalcDto
     * @return
     */
    public List<CalcResult> setSendBigDataUtilsService(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto) {

        List<CalcResult> bigDataCalcResultList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            //是否推动大数据判断
            Integer isPushBigdata = calcResult.getIsPushBigdata();
            if (isPushBigdata != null && isPushBigdata == 0) {
                continue;
            }

            CalcResult bigDataCalcResult = ReflectUtil.converter(calcResult, CalcResult.class);
            bigDataCalcResult.setGomeStatus(orderCalcDto.getGomeState());
            bigDataCalcResult.setSapDetailId(orderCalcDto.getSapDetailId());

            if (BaseConstants.ORDER_CL_STATUS.equals(orderCalcDto.getGomeState()) ||
                    BaseConstants.ORDER_RT_STATUS.equals(orderCalcDto.getGomeState())) {
                bigDataCalcResult.setAwardAmount(-1 * bigDataCalcResult.getAwardAmount());
            }

            if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())) {
                bigDataCalcResult.setOrderEffectTime(orderCalcDto.getOrderDate());
            }

            if (BaseConstants.CRD_JOB_STATUS_2 == bigDataCalcResult.getJobStatus()) {
                bigDataCalcResultList.add(bigDataCalcResult);
            }
        }
        return bigDataCalcResultList;
    }

    /**
     * 根据计划计算结果，计算对象获取计算记录数据
     *
     * @param calcResultList
     * @param orderCalcDto
     * @return
     */
    protected List<CalcRecord> getCalcRecord(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto) {
        List<CalcRecord> calcRecordList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            CalcRecord calcRecord = new CalcRecord();
            calcRecord.setId(seqGenUtil.nextCrpCalcRecordId());
            calcRecord.setCalcResultId(String.valueOf(calcResult.getId()));
            calcRecord.setOrderId(calcResult.getOrderId());
            calcRecord.setDeliveryId(calcResult.getDeliveryId());
            calcRecord.setDetailId(calcResult.getDetailId());
            calcRecord.setSkuNo(calcResult.getSkuNo());

            // DL 状态的金额数量不会发生更改(非货到付款)
            if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState()) &&
                    !OrderTypeEnum.CASH_ON_DELIVERY.getCode().equals(orderCalcDto.getOrderType())) {
                calcRecord.setAward(0L);
                calcRecord.setBuyNum(0L);
            } else {
                calcRecord.setAward(calcResult.getAwardAmount());
                calcRecord.setBuyNum(Long.valueOf(calcResult.getBuyNum()));
            }

            calcRecord.setReturnOrderId(orderCalcDto.getReturnOrderId());
            calcRecord.setGomeStatus(orderCalcDto.getGomeState());
            calcRecord.setOrderSubmitTime(orderCalcDto.getSubmittedDate());
            calcRecord.setOrderDate(orderCalcDto.getOrderDate());
            calcRecord.setSapDetailId(orderCalcDto.getSapDetailId());
            calcRecord.setChannel(orderCalcDto.getChannel());
            calcRecordList.add(calcRecord);
        }
        return calcRecordList;
    }

    /**
     * 根据计划计算结果，计算对象获取更新计算结果对象
     *
     * @param calcResultList
     * @param orderCalcDto
     * @return
     */
    protected List<CalcResult> getUpdateCalcResult(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto) {
        List<CalcResult> calcRecordList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            CalcResult updateCalcResult = new CalcResult();
            updateCalcResult.setRebateAccountType(calcResult.getRebateAccountType());
            updateCalcResult.setId(calcResult.getId());
            updateCalcResult.setGomeStatus(orderCalcDto.getGomeState());
            if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())) {
                updateCalcResult.setOrderEffectTime(orderCalcDto.getOrderDate());
                updateCalcResult.setDlMsgBody(JSON.toJSONString(orderCalcDto));
            }

            if (BaseConstants.ORDER_CL_STATUS.equals(orderCalcDto.getGomeState()) ||
                    BaseConstants.ORDER_RT_STATUS.equals(orderCalcDto.getGomeState())) {
                updateCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
                updateCalcResult.setFailureReason(FailureReasonEnum.ORDER_CANCEL_FINISH.getMsg());
            }

            calcRecordList.add(updateCalcResult);
        }
        return calcRecordList;
    }

    /**
     * 根据计划计算结果，计算对象获取更新计算结果对象
     *
     * @param calcResultList
     * @param orderCalcDto
     * @param rebateAccountType
     * @return
     */
    protected List<CalcResult> getUpdateCalcResult(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto, int rebateAccountType) {
        List<CalcResult> calcRecordList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            CalcResult updateCalcResult = new CalcResult();
            updateCalcResult.setRebateAccountType(calcResult.getRebateAccountType());
            updateCalcResult.setId(calcResult.getId());
            updateCalcResult.setGomeStatus(orderCalcDto.getGomeState());
            if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())) {
                updateCalcResult.setOrderEffectTime(orderCalcDto.getOrderDate());
                updateCalcResult.setDlMsgBody(JSON.toJSONString(orderCalcDto));
            }

            if (BaseConstants.ORDER_CL_STATUS.equals(orderCalcDto.getGomeState()) ||
                    BaseConstants.ORDER_RT_STATUS.equals(orderCalcDto.getGomeState())) {
                updateCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
                updateCalcResult.setFailureReason(FailureReasonEnum.ORDER_CANCEL_FINISH.getMsg());
            }
            // 更新 推送 返利入账信息状态
            updateCalcResult.setRebateAccountType(rebateAccountType);
            calcRecordList.add(updateCalcResult);
        }
        return calcRecordList;
    }

    protected List<CalcResult> getBudgetCalcResult(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto) {
        List<CalcResult> budgetCalcResultList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            boolean isBudget = iBudgetService.isBudgetControl(calcResult);
            boolean isBudgetOccupation = calcResult.getBudgetStatus() != null && BaseConstants.BUDGET_CHECK_SUCCESS == calcResult.getBudgetStatus();
            log.info("预算是否已占用resultId:{},budgetStatus:{}", calcResult.getId(), isBudgetOccupation);
            if (isBudget && isBudgetOccupation) {
                CalcResult budgetCalcResult = ReflectUtil.converter(calcResult, CalcResult.class);
                budgetCalcResultList.add(budgetCalcResult);
            }
        }

        return budgetCalcResultList;
    }

    protected List<CalcResult> filterCalcResult(List<CalcResult> calcResultList, OrderCalcDto orderCalcDto) {
        List<CalcResult> filterCalcResult = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            if (!BaseConstants.ORDER_CO_STATUS.equals(calcResult.getGomeStatus())) {
                log.error("mq消息处理,原始计划订单状态不正确orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
                return filterCalcResult;
            }

            filterCalcResult.add(calcResult);
        }
        return filterCalcResult;
    }

    @Override
    public Integer calcLogic(OrderCalcDto orderCalcDto) {
        //修复数据
        List<PlanDto> planDtos;
        Boolean enable = CalcLocal.getRepairThreadLocal();
        if(enable != null && enable){
            //enable 为true  数据修复 ,特殊处理，后续可删除
            planDtos = doctorIPlanService.orderMatchPlan(orderCalcDto);
        }else{
            // 匹配计划
            planDtos = planService.orderMatchPlan(orderCalcDto);
        }

        if (CollectionUtils.isEmpty(planDtos)) {
            problemService.addData(orderCalcDto, null, null, null, ProblemEnum.CODE_101);
            return OrderProcessResultEnum.NO_EXISTS_MATCH_PLAN_AWARD.getCode();
        }

        return dealPlanDto(orderCalcDto, planDtos);
    }

    private Integer dealPlanDto(OrderCalcDto orderCalcDto, List<PlanDto> planDtos) {
        ICalcService calcService = calcFatctory.getCalc(BaseConstants.CALC_CONSTANT_ORDER);
        List<CalcResultRecordDto> calcResultRecordDtoList = new ArrayList<>();
        for (PlanDto planDto : planDtos) {
            // 一个订单 + 一个计划
            List<ProfitDto> profitDtos = calcService.calcOrder(orderCalcDto, planDto);
            if (CollectionUtils.isEmpty(profitDtos)) {
                log.info("detail级order,没有获利人信息orderId:{},deliveryId:{},detailId:{},planId:{}", orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), orderCalcDto.getDetailId(), planDto.getPlanId());
                continue;
            }

            LocalDto localDto = CalcLocal.getLocalDto();
            if (null == localDto) {
                localDto = new LocalDto();
            }
            localDto.setPlanDto(planDto);
            localDto.setOrderCalcDto(orderCalcDto);
            CalcLocal.setLocalDto(localDto);

            // 此处对 calcResultDto 的获利人信息进行筛选
            profitDtos = rule.filterProfiter(profitDtos);
            if (CollectionUtils.isEmpty(profitDtos)) {
                log.info("detail级order处理,没有获利人信息orderId:{},deliveryId:{},detailId:{},planId:{}", orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), orderCalcDto.getDetailId(), planDto.getPlanId());
                continue;
            }

            //按订单匹配计划组装数据
            List<CalcResultRecordDto> calcResultRecordDto = getCalcResultRecord(orderCalcDto, planDto, profitDtos);
            calcResultRecordDtoList.addAll(calcResultRecordDto);
        }

        //过滤奖励金额是0的数据
        List<CalcResultRecordDto> filterCalcList = filterAwardAmountZero(calcResultRecordDtoList, orderCalcDto);
        if (CollectionUtils.isEmpty(filterCalcList)) {
            log.info("detail级order,没有需要保存的数据orderId:{},deliveryId:{},detailId:{}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getDetailId());
            return OrderProcessResultEnum.NO_EXISTS_MATCH_PLAN_AWARD.getCode();
        }

        //订单计算表批量入库
        calcResultSingleManager.doSaveCalcResult(filterCalcList);
        log.info("detail级order处理完成orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
        return OrderProcessResultEnum.EXISTS_MATCH_PLAN_AWARD.getCode();
    }

    private List<CalcResultRecordDto> filterAwardAmountZero(List<CalcResultRecordDto> calcList, OrderCalcDto orderCalcDto) {
        List<CalcResultRecordDto> filterCalcList = new ArrayList<>(calcList.size());
        for (CalcResultRecordDto calcResultRecordDto : calcList) {
            if (calcResultRecordDto.getCalcResult() != null
                    && calcResultRecordDto.getCalcResult().getAwardAmount() != null
                    && (calcResultRecordDto.getCalcResult().getAwardAmount() != 0L || BaseConstants.SCENE_Y.equals(calcResultRecordDto.getCalcResult().getScenes()))) {
                filterCalcList.add(calcResultRecordDto);
            } else {
                CalcResult calcResult = calcResultRecordDto.getCalcResult();
                String planId = calcResult != null ? calcResult.getPlanId() : "";
                String scenes = calcResult != null ? calcResult.getScenes() : "";
                String staffCode = calcResult != null ? calcResult.getStaffCode() : "";
                String userId = calcResult != null ? calcResult.getUserId() : "";
                problemService.addData(orderCalcDto, null, null, planId + "-" + scenes + "-" + staffCode + "-" + userId, ProblemEnum.CODE_127);
            }
        }
        return filterCalcList;
    }

    private List<CalcResultRecordDto> getCalcResultRecord(OrderCalcDto orderCalcDto, PlanDto planDto, List<ProfitDto> profitDtos) {
        List<CalcResultRecordDto> calcResultRecordList = new ArrayList<>(profitDtos.size());
        for (ProfitDto profitDto : profitDtos) {
            CalcResultRecordDto calcResultRecordDto = new CalcResultRecordDto();
            //计算结果表
            CalcResult calcResult = new CalcResult();
            calcResult.setVersion(SystemVersionEnum.SECOND_EDITION.getCode());
            Long calcResultId = seqGenUtil.nextCrpCalcResultId();
            calcResult.setId(calcResultId);
            calcResult.setScenes(profitDto.getScenes());
            calcResult.setAwardAmount(profitDto.getAwardAmount().longValue());
            //获利人信息
            PersonDto personDto = profitDto.getPersonDto();
            calcResult.setStaffCode(personDto.getStaffCode());
            calcResult.setUserId(personDto.getUserId());
            calcResult.setStaffClass(personDto.getStaffClass());
            calcResult.setStaffLevel(personDto.getStaffLevel());
            calcResult.setStaffBranchCodeOne(personDto.getBranchCodeOne());
            calcResult.setStaffBranchCodeTwo(personDto.getBranchCodeTwo());
            calcResult.setStaffStoreCode(personDto.getStoreCode());
            calcResult.setStaffSupplierCode(personDto.getOrderSupplier());
            calcResult.setStaffSuppliers(personDto.getStaffSuppliers());
            //获利行为
            calcResult.setProfitBehavior(personDto.getProfitBehaviorCode());
            //订单信息
            calcResult.setOrderId(orderCalcDto.getOrderId());
            calcResult.setDeliveryId(orderCalcDto.getDeliveryId());
            calcResult.setSkuNo(orderCalcDto.getSkuNo());
            calcResult.setSkuName(orderCalcDto.getSkuName());
            calcResult.setSalesModel(orderCalcDto.getSalesModel());
            calcResult.setBuyNum(orderCalcDto.getBuyNum());
            calcResult.setProfileId(orderCalcDto.getUserId());
            calcResult.setSellerId(orderCalcDto.getStoreSellerId());
            calcResult.setShareId(orderCalcDto.getShareUserId());
            calcResult.setShopNo(orderCalcDto.getShopNo());
            calcResult.setShopType(orderCalcDto.getShopType());
            calcResult.setOrderSupplierCode(orderCalcDto.getSupplier());
            calcResult.setOrderSalePrice(orderCalcDto.getOrderSalePrice().longValue());
            calcResult.setOrderPrice(orderCalcDto.getOrderPrice().longValue());
            calcResult.setSalePrice(orderCalcDto.getSalePrice().longValue());
            calcResult.setPrice(orderCalcDto.getPrice().longValue());
            calcResult.setCommerceItemId(orderCalcDto.getCommerceItemId());
            calcResult.setDetailId(orderCalcDto.getDetailId());
            calcResult.setSapDetailId(orderCalcDto.getSapDetailId());
            calcResult.setOrderSubmitTime(orderCalcDto.getSubmittedDate());
            calcResult.setChannel(orderCalcDto.getChannel());
            calcResult.setDemanderCode(orderCalcDto.getDemanderCode());
            calcResult.setLogicMasLoc(orderCalcDto.getLogicMasLoc());
            calcResult.setBrandCode(orderCalcDto.getEaBrandCode());
            calcResult.setCategoryLevelTwo(orderCalcDto.getEaGroupCodeSecond());
            calcResult.setCategoryLevelThree(orderCalcDto.getEaGroupCodeThird());
            calcResult.setCategoryLevelFour(orderCalcDto.getEaGroupCode());
            calcResult.setGomeStatus(orderCalcDto.getGomeState());
            calcResult.setSalesOrganization(orderCalcDto.getSalesOrganization());
            if (orderCalcDto.getSalesOrganization() != null) {
                GomeOrganization sellingOrganization = iStaffInfoService.getSellingOrganization(orderCalcDto.getSalesOrganization());
                calcResult.setCompanyCode(sellingOrganization == null ? null : sellingOrganization.getCompanyId());
            }

            if (BaseConstants.ORDER_CO_STATUS.equals(orderCalcDto.getGomeState())) {
                calcResult.setCoMsgBody(JSON.toJSONString(orderCalcDto));
            } else if (BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState())) {
                calcResult.setDlMsgBody(JSON.toJSONString(orderCalcDto));
                calcResult.setOrderEffectTime(orderCalcDto.getOrderDate());
            } else {
                log.error("订单状态不正确orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), JSON.toJSONString(orderCalcDto));
            }

            calcResult.setPayDate(orderCalcDto.getPayDate());
            calcResult.setSkuId(orderCalcDto.getSkuId());

            //计划信息
            calcResult.setPlanId(String.valueOf(planDto.getPlanId()));
            calcResult.setMainId(String.valueOf(planDto.getMainId()));
            calcResult.setPlanDetailId(String.valueOf(planDto.getPlanDetailId()));
            calcResult.setMainPlanDetailId(planDto.getMainPlanDetailId());
            calcResult.setProvisionType(planDto.getProvisionType());
            calcResult.setCurrentPrice(planDto.getCurrentPrice());
            calcResult.setExtraPolicyCode(planDto.getPolicyCode());
            calcResult.setPromotionalMoney(planDto.getPromotionalMoney());
            calcResult.setPromotionsType(planDto.getPromotionsType());
            calcResult.setExpencesOfferType(planDto.getExpenseOfferType());
            calcResult.setContractType(planDto.getContractType());
            calcResult.setContractCode(planDto.getContractCode());
            calcResult.setExtraNum(planDto.getExtraNum());
            calcResult.setAccountRate(planDto.getAccountRate());
            calcResult.setContractPurchaseCode(planDto.getContractPurchaseCode());
            calcResult.setExtraPurchaseCode(planDto.getExtraPurchaseCode());
            calcResult.setDocty(planDto.getDocty());
            calcResult.setIsOffset(planDto.getIsOffset());
            calcResult.setSupplierName(planDto.getSupplierName());
            calcResult.setGrantRate(planDto.getIssueRate());
            calcResult.setOfferPrice(planDto.getOfferPrice());
            calcResult.setContractClass(planDto.getContractClass());
            //逻辑信息
            calcResult.setIsAsella(isAsella(personDto, orderCalcDto));
            calcResult.setIsGomeOffer(isGomeOffer(String.valueOf(planDto.getExpenseOfferType())));

            //冲减综贡,不占用预算
            if (planDto.getIsOffset() != null && IsOffsetEnum.YES.getCode() == planDto.getIsOffset()) {
                calcResult.setBudgetStatus(BaseConstants.BUDGET_CHECK_SUCCESS);
            } else {
                calcResult.setBudgetStatus(BaseConstants.BUDGET_UNCHECKED);
            }
            calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_1_N);
            calcResult.setIsOnlineApplyBill(IsOnlineApplyBillEnum.NOT_HAVE_APPLY.getCode());
            calcResult.setIsOfflineApplyBill(Integer.valueOf(BaseConstants.Bill_OFFLINE_APPLY_0));
            calcResult.setIsReceiptGoods(IsReceiptGoodsEnum.NOT_HAVE_RECEIPT.getCode());

            List<String> purchaseCodeList = orderCalcDto.getPurchaseCodeList();
            if (!CollectionUtils.isEmpty(purchaseCodeList)) {
                StringBuilder sb = new StringBuilder(64);
                for (String purchaseCode : purchaseCodeList) {
                    sb.append(purchaseCode);
                    sb.append(",");
                }
                String purchaseCodes = sb.toString();
                calcResult.setPurchaseCode(purchaseCodes.length() > 30 ? purchaseCodes.substring(0, 30) : purchaseCodes);
            }

            String orderPlanBeneficiaryUniqueKey = CacheKeyConstants.getOrderPlanBeneficiaryUniqueKey(calcResult);
            String value = gcacheUtil.getKeyValue(orderPlanBeneficiaryUniqueKey);
            if (StringUtils.isNotEmpty(value)) {
                calcResult.setLimitAwardAmount(Long.valueOf(value));
            }
            calcResult.setIsPushBigdata(IsPushBigdataEnum.NOT_HAVE_PUSH.getCode());
            calcResult.setGoodsType(orderCalcDto.getGoodsType());
            calcResult.setWarrantyFlag(orderCalcDto.getWarrantyFlag());
            calcResult.setCalcLogic(orderCalcDto.getCalcLogic());
            calcResultRecordDto.setCalcResult(calcResult);

            //计算履历表
            CalcRecord calcRecord = new CalcRecord();
            Long calcRecordId = seqGenUtil.nextCrpCalcRecordId();
            calcRecord.setId(calcRecordId);
            calcRecord.setCalcResultId(String.valueOf(calcResultId));
            calcRecord.setOrderId(orderCalcDto.getOrderId());
            calcRecord.setDeliveryId(orderCalcDto.getDeliveryId());
            calcRecord.setGomeStatus(orderCalcDto.getGomeState());
            calcRecord.setDetailId(orderCalcDto.getDetailId());
            calcRecord.setSkuNo(orderCalcDto.getSkuNo());
            calcRecord.setSapDetailId(orderCalcDto.getSapDetailId());
            calcRecord.setAward(profitDto.getAwardAmount().longValue());
            calcRecord.setBuyNum(Long.valueOf(orderCalcDto.getBuyNum()));
            calcRecord.setOrderSubmitTime(orderCalcDto.getSubmittedDate());
            calcRecord.setOrderDate(orderCalcDto.getOrderDate());
            calcRecord.setChannel(orderCalcDto.getChannel());
            calcResultRecordDto.setCalcRecord(calcRecord);
            if (BaseConstants.SCENE_Y.equals(profitDto.getScenes())) {
                //Y场景特殊处理
                calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_SCENE_Y);

                SceneYDto sceneYDto = new SceneYDto();
                sceneYDto.setUserId(orderCalcDto.getUserId());
                sceneYDto.setOrderId(orderCalcDto.getOrderId());
                sceneYDto.setPlanId(String.valueOf(planDto.getPlanId()));
                sceneYDto.setEndTime(planDto.getEndTime());
                sceneYDto.setPaymentMoney(planDto.getPaymentMoney());
                sceneYDto.setStaffCode(personDto.getStaffCode());
                calcResultRecordDto.setSceneYDto(sceneYDto);
            } else {
                if (StringUtils.isNotBlank(orderCalcDto.getChannelCalcNo()) && orderCalcDto.getChannelCalcNo().equals(BaseConstants.ORDER_CHANNEL_O2O)) {
                    calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_2);
                } else {
                    calcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_1_N);
                }
            }
            calcResultRecordList.add(calcResultRecordDto);
        }
        return calcResultRecordList;
    }

    /**
     * 是否A卖A
     * 人员信息条件：主营&&促销员&&所属的供货商与商品供货商一致
     *
     * @param personDto
     * @return
     */
    private Integer isAsella(PersonDto personDto, OrderCalcDto orderCalcDto) {
        if (StringUtils.isEmpty(personDto.getStaffCode())) {
            log.info("是否A卖A判断为假orderId:{},staffCode:{}", orderCalcDto.getOrderId(), personDto.getStaffCode());
            return null;
        }

        if (personDto.getIsMain() != null && BaseConstants.IS_MAIN_INT_Y == personDto.getIsMain() &&
                (BaseConstants.EMPL_CLASS_D.equals(personDto.getStaffClass()) || BaseConstants.EMPL_CLASS_J.equals(personDto.getStaffClass())) &&
                orderCalcDto.getSupplier().equals(personDto.getOrderSupplier())) {
            return BaseConstants.PLAN_IS_A_SELL_A_Y;
        }

        log.info("是否A卖A判断为假orderId:{},isMain:{},staffClass:{},supplier:{},orderSupplier:{}", orderCalcDto.getOrderId(), personDto.getIsMain(), personDto.getStaffClass(), orderCalcDto.getSupplier(), personDto.getOrderSupplier());
        return BaseConstants.PLAN_IS_A_SELL_A_N;
    }

    /**
     * 是否国美承担
     *
     * @param expenseOfferType
     * @return
     */
    private Integer isGomeOffer(String expenseOfferType) {
        if (BaseConstants.PLAN_EXPENSE_OFFER_TWO_TYPE.equals(expenseOfferType) ||
                (BaseConstants.PLAN_EXPENSE_OFFER_THIRD_TYPE.equals(expenseOfferType))) {
            return BaseConstants.PLAN_IS_GOME_OFFER_Y;
        }

        return BaseConstants.PLAN_IS_GOME_OFFER_N;
    }

    @Override
    public Integer redoCalcLogic(OrderCalcDto orderCalcDto, List<CalcResult> calcResultList) {
        LocalDto localDto = new LocalDto();
        localDto.setOrderCalcDto(orderCalcDto);
        CalcLocal.setLocalDto(localDto);

        List<PlanDto> planDtoList = new ArrayList<>();
        Set<String> preventRepeatSet = new HashSet<>();
        for (CalcResult calcResult : calcResultList) {

            //防止重复计算
            String uniqueKey = calcResult.getPlanId();
            if (preventRepeatSet.contains(uniqueKey)) {
                continue;
            } else {
                preventRepeatSet.add(uniqueKey);
            }

            //获取收入项目编码
            String reuNo = getReuNo(calcResult);
            if (reuNo == null) {
                log.error("提成重新计算-收入项目编码为空calcResult:{}", JSON.toJSONString(calcResult));
                continue;
            }

            SapAccount query = new SapAccount();
            query.setReuno(reuNo);
            query.setSoDeliveryDetailId(calcResult.getSapDetailId());
            QueryWrapper<SapAccount> queryWrapper = Wrappers.query(query);
            SapAccount sapAccount = sapAccountMapper.selectOne(queryWrapper);
            if (sapAccount == null) {
                log.error("提成重新计算-sap账目为空calcResult:{}", JSON.toJSONString(calcResult));
                continue;
            }

 //           String planId = calcResult.getPlanId();
//            String promotionsType = String.valueOf(calcResult.getPromotionsType());
//            String no = "";
//            String categoryLevelFour = null;
//            if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(promotionsType)) {
//                no = sapAccount.getNewno();
//                categoryLevelFour = calcResult.getCategoryLevelFour();
//            } else {
//                no = sapAccount.getKonnr();
//            }
//
//            String soBuyOrgCode = sapAccount.getSoBuyorgCode();
            //List<PlanDto> planDtos = iQueryPlanService.queryPlanByParam(orderCalcDto, calcResult.getSkuNo(), calcResult.getSalesModel(), planId, promotionsType, no, categoryLevelFour, soBuyOrgCode , sapAccount, calcResult);
            List<PlanDto> planDtos = iQueryPlanService.queryPlanByParam(orderCalcDto, sapAccount, calcResult);
            if (!CollectionUtils.isEmpty(planDtos)) {
                String offerPrice = gcacheUtil.getKeyValue(CacheKeyConstants.getCronJobSapCompare20OfferPrice(calcResult.getId()));
                if (StringUtils.isNotEmpty(offerPrice)) {
                    log.info("提成重新计算, 供价使用合同中的供价, 合同中的供价为: {} 分", offerPrice);
                    planDtos.get(0).setOfferPrice(Long.valueOf(offerPrice));
                }
                planDtoList.addAll(planDtos);
            } else {
                log.error("提成重新计算-无法匹配到计划planId:{},calcResult:{}", calcResult.getPlanId(), JSON.toJSONString(calcResult));
                continue;
            }

            //检查严控失败的字段与重新计算后字段是否一致,不一致置成一致，避免循环重复计算
            PlanDto planDto = planDtos.get(0);
            if (!checkChangeValue(planDto, calcResult, sapAccount)) {
                try {
                    // 问题小工具
                    problemService.addData(orderCalcDto, planDtos.get(0), null, orderCalcDto.getOrderId(), ProblemEnum.CODE_130);
                } catch (Exception e) {
                    log.error("提成重新计算-检查严控失败的字段与重新计算后字段不一致，错误信息：sapAccount:{},planDtos:{}", sapAccount, planDto, e);
                }
            }
        }

        return dealPlanDto(orderCalcDto, planDtoList);
    }

    private boolean checkChangeValue(PlanDto planDto, CalcResult calcResult, SapAccount sapAccount) {
        if (calcResult.getFailureReason().contains(FailureReasonEnum.SAP_COMPARE_CONTRACT_NO_MATCH.getMsg())) {
            if (sapAccount.getNewno() == null || !sapAccount.getNewno().equals(planDto.getContractCode())) {
                log.error("提成重新计算-合同号字段不一致，错误信息：sapAccount:{},planDtos:{}", sapAccount, planDto);
                planDto.setContractCode(sapAccount.getNewno());
                return false;
            }
        }
        
        if (calcResult.getFailureReason().contains(FailureReasonEnum.SAP_COMPARE_AGREEMENT_NO_MATCH.getMsg())) {
            if (sapAccount.getSoAgreementCode() == null || !sapAccount.getSoAgreementCode().equals(planDto.getExtraNum())) {
                log.error("提成重新计算-协议号字段不一致，错误信息：sapAccount:{},planDtos:{}", sapAccount, planDto);
                planDto.setContractCode(sapAccount.getSoAgreementCode());
                return false;
            }
        }

        if (calcResult.getFailureReason().contains(FailureReasonEnum.SAP_COMPARE_LETTER_NO_MATCH.getMsg())) {
            if (sapAccount.getKonnr() == null || !sapAccount.getKonnr().equals(planDto.getExtraNum())) {
                log.error("提成重新计算-检函号不一致，错误信息：sapAccount:{},planDtos:{}", sapAccount, planDto);
                planDto.setExtraNum(sapAccount.getKonnr());
                return false;
            }
        }

        if (calcResult.getFailureReason().contains(FailureReasonEnum.SAP_COMPARE_OFFER_PRIZE_NO_MATCH.getMsg())) {
            if (sapAccount.getDmbtr1() == null
                    || planDto.getOfferPrice() == null
                    || !sapAccount.getDmbtr1().equals(planDto.getOfferPrice())) {
                log.error("提成重新计算-供价不一致，错误信息：sapAccount:{},planDtos:{}", sapAccount, planDto);
                planDto.setOfferPrice(sapAccount.getDmbtr1());
                return false;
            }
        }

        return true;
    }

    private String getReuNo(CalcResult calcResult) {
        if (calcResult == null) {
            return null;
        }

        if (BaseConstants.PLAN_REPLACE_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return ReuNoEnum.FY0000087.getCode();
        }

        if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return ReuNoEnum.FY0000008.getCode();
        }

        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(calcResult.getExtraPolicyCode())) {
            return ReuNoEnum.FY0000084.getCode();
        }

        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(calcResult.getExtraPolicyCode())
                        || BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(calcResult.getExtraPolicyCode()))) {
            return ReuNoEnum.FY0000078.getCode();
        }

        return null;
    }

    /**
     * 重新计算
     */
    @Override
    public void redoCalc(OrderCalcDto orderCalcDto, List<CalcResult> calcResultList) {
        List<Long> calcResultIds = calcResultList.stream().map(CalcResult::getId).collect(Collectors.toList());
        String calcResultIdsJson = JSON.toJSONString(calcResultIds);
        try {
            log.info("提成计划重新计算开始orderCalcDto:{},calcResultIds:{}", orderCalcDto, calcResultIdsJson);
            Integer result = redoCalcLogic(orderCalcDto, calcResultList);
            recordCalcNoResult(orderCalcDto, result);
            log.info("提成计划重新计算完成orderCalcDto:{},calcResultIds:{},result:{}", orderCalcDto, calcResultIdsJson, result);
        } catch (Exception e) {
            log.error("提成计划重新计算异常orderCalcDto:{},calcResultIds:{}", orderCalcDto, calcResultIdsJson, e);
            try {
                // 问题小工具
                problemService.addData(orderCalcDto, null, null, orderCalcDto.getOrderId(), ProblemEnum.CODE_113);
                // 失败重试
                CalcRetry calcRetry = new CalcRetry();
                calcRetry.setType(RetryJobEnum.REDO_ORDERCALC.getCode());
                calcRetry.setOrderId(orderCalcDto.getOrderId());
                calcRetry.setSapDetailId(orderCalcDto.getSapDetailId());
                calcRetry.setMsgBody(JSON.toJSONString(calcResultList));
                calcRetry.setGomeStatus(orderCalcDto.getGomeState());
                calcRetry.setFailureReason(e.getMessage());
                calcRetryCopeService.insertRetry(calcRetry);
            } catch (Exception e1) {
                log.error("提成重新计算插入问题小工具或插入失败重试失败，错误信息：orderCalcDto:{},calcResultIds:{}", orderCalcDto, calcResultIdsJson, e1);
            }
        }
    }

    @Override
    public void recordCalcNoResult(OrderCalcDto orderCalcDto, Integer result) {
        try {
            if ((BaseConstants.ORDER_CO_STATUS.equals(orderCalcDto.getGomeState())
                    || BaseConstants.ORDER_DL_STATUS.equals(orderCalcDto.getGomeState()))
                    && result != null
                    && OrderProcessResultEnum.NO_EXISTS_MATCH_PLAN_AWARD.getCode().intValue() == result.intValue()) {
                CalcNoResult calcNoResult = new CalcNoResult();
                calcNoResult.setId(seqGenUtil.nextCrpCalcNoResultId());
                calcNoResult.setOrderId(orderCalcDto.getOrderId());
                calcNoResult.setDeliveryId(orderCalcDto.getDeliveryId());
                calcNoResult.setSapDetailId(orderCalcDto.getSapDetailId());
                calcNoResult.setDetailId(orderCalcDto.getDetailId());
                calcNoResult.setChannel(orderCalcDto.getChannel());
                calcNoResultMapper.insert(calcNoResult);
            }
        } catch (DuplicateKeyException e) {
            log.error("未匹配计划奖励结果表被防重orderCalcDto:{}", JSON.toJSONString(orderCalcDto));
        }
    }

//    // 封装提奖记录数据,   willSub 为 正数
//    public CalcResultReward getCalcReward(CalcResult calcResult, String willSub) {
//        return calcRewardsService.getCalcReward(calcResult, willSub);
//    }

}