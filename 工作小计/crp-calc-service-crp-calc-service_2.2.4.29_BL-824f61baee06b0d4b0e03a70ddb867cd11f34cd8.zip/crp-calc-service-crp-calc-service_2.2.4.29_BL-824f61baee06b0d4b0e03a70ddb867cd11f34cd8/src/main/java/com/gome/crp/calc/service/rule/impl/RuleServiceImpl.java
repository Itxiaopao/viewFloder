package com.gome.crp.calc.service.rule.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.rule.IRuleService;
import com.gome.crp.calc.util.threadLocal.CalcLocal;

@Service
public class RuleServiceImpl implements IRuleService {

    @Autowired
    IProblemService problemService;

    /**
     * 获利人叠加规则
     * 获利人是同一个人
     * X>Z;X>M;  Z>M;  Y+X;Y+Z;Y+M
     * 获利人不是同一个人
     * X>Z;X>M;  M>Z;  Y+X;Y+Z;Y+M
     * X 可能是多个人
     * Y 只会是一个人
     * Z 只会是一个人
     * M 只会是一个人
     *
     * @param profitDto
     * @return
     */
    @Override
    public List<ProfitDto> filterProfiter(List<ProfitDto> profitDto) {

        List<ProfitDto> sceneX = new ArrayList<>(); // X可能有多个人拿，X的获利人一定是员工编码
        List<ProfitDto> sceneY = new ArrayList<>(); // Y只能有一个人拿
        List<ProfitDto> sceneZ = new ArrayList<>(); // Z只能有一个人拿
        List<ProfitDto> sceneM = new ArrayList<>(); // M只能有一个人拿
        for (ProfitDto dto : profitDto) {
            switch (dto.getScenes()) {
                case BaseConstants.SCENE_X:
                    sceneX.add(dto);
                    break;
                case BaseConstants.SCENE_Y:
                    sceneY.add(dto);
                    break;
                case BaseConstants.SCENE_Z:
                    sceneZ.add(dto);
                    break;
                case BaseConstants.SCENE_M:
                    sceneM.add(dto);
                    break;
            }
        }

        OrderCalcDto orderCalcDto = CalcLocal.getLocalDto().getOrderCalcDto();
        PlanDto planDto = CalcLocal.getLocalDto().getPlanDto();

        // X > Z; X > M  X 只能是员工
        for (ProfitDto x : sceneX) {
            if (x.getPersonDto().getStaffCode() != null) {
                if (sceneZ.size() > 0 && x.getPersonDto().getStaffCode().equals(sceneZ.get(0).getPersonDto().getStaffCode())) {
                    problemService.addData(orderCalcDto, planDto, x, "依据 X > Z 原则，用户只能得 X 奖励", ProblemEnum.CODE_104);
                    // 依据 X > Z 原则，用户只能得 X 奖励
                    sceneZ.clear();
                }
                if (sceneM.size() > 0 && x.getPersonDto().getStaffCode().equals(sceneM.get(0).getPersonDto().getStaffCode())) {
                    problemService.addData(orderCalcDto, planDto, x, "依据 X > M 原则，用户只能得 X 奖励", ProblemEnum.CODE_104);
                    // 依据 X > M 原则，用户只能得 X 奖励
                    sceneM.clear();
                }
                //如果x中存在获利行为为分享，则clear Z 
                Integer profitBehaviorCode = x.getPersonDto().getProfitBehaviorCode();
                if(profitBehaviorCode != null && 
                		(profitBehaviorCode.intValue() == ProfitBehaviorEnum.SERVICE_SHARE_PRODUCTS.getCode().intValue() ||
                		 profitBehaviorCode.intValue() == ProfitBehaviorEnum.SERVICE_SHARE_VOUCHER.getCode().intValue()
                		) ){
                	problemService.addData(orderCalcDto, planDto, x, "依据  X 中存在获利行为为分享，则clear Z原则，用户只能得 X 奖励", ProblemEnum.CODE_104);
                	sceneZ.clear();
                }
                
            }
        }

        // 获利人是同一个人 Z > M
        for (ProfitDto z : sceneZ) {
            // 获利人可能是员工
            if (z.getPersonDto().getStaffCode() != null) {
                if (sceneM.size() > 0 && z.getPersonDto().getStaffCode().equals(sceneM.get(0).getPersonDto().getStaffCode())) {
                    problemService.addData(orderCalcDto, planDto, z, "依据 Z > M 原则，用户只能得 Z 奖励", ProblemEnum.CODE_104);
                    // 依据 Z > M 原则，用户只能得 Z 奖励
                    sceneM.clear();
                }
            }
            // 获利人可能是国美会员
            if (z.getPersonDto().getUserId() != null) {
                if (sceneM.size() > 0 && z.getPersonDto().getUserId().equals(sceneM.get(0).getPersonDto().getUserId())) {
                    problemService.addData(orderCalcDto, planDto, z, "依据 Z > M 原则，用户只能得 Z 奖励", ProblemEnum.CODE_104);
                    // 依据 Z > M 原则，用户只能得 Z 奖励
                    sceneM.clear();
                }
            }
        }

        // 经过上面的判定，如果 Z 和 M 集合中还有人，则说明 Z 和 M 不是同一个人获得
        // 依据 Z 和 M 不是同一个人获得原则， M > Z
        if (sceneZ.size() > 0 && sceneM.size() > 0) {
            problemService.addData(orderCalcDto, planDto, sceneZ.get(0), "Z 和 M 获利人不相同，M > Z", ProblemEnum.CODE_104);
            // M > Z; 将 Z clear
            sceneZ.clear();
        }

        List<ProfitDto> profitDtoList = new ArrayList<>();
        profitDtoList.addAll(sceneX);
        // 依据叠加规则 Y+X Y+Z Y+M ,所以 Y 不需要参与叠加规则的判断
        profitDtoList.addAll(sceneY);
        profitDtoList.addAll(sceneZ);
        profitDtoList.addAll(sceneM);

        return profitDtoList;
    }

}
