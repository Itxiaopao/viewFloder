package com.gome.crp.calc.client.userLink;

/**
 * 用户链路关系
 */
public interface IUserLink {

    /**
     * 根据用户查询它的上级绑定 user
     *
     * @param userId 国美会员id
     * @return 返回用户的上级 userId，没有返回 null
     */
    String selLinkUser(String userId);

}
