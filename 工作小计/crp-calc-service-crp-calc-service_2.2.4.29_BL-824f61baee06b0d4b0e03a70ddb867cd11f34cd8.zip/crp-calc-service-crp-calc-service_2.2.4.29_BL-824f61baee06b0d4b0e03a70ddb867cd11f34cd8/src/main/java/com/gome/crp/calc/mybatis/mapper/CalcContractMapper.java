package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcContract;

public interface CalcContractMapper extends BaseMapper<CalcContract> {

}
