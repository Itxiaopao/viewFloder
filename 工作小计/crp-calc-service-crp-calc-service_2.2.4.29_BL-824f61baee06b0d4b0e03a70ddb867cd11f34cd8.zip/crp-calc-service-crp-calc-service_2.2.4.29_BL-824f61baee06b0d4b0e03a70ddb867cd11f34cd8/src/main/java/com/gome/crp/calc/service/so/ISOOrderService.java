package com.gome.crp.calc.service.so;

public interface ISOOrderService {
    /**
     * so订单处理核心类
     * @param channel
     * @param sapDetailId
     */
    void handler(String channel,String sapDetailId);
}
