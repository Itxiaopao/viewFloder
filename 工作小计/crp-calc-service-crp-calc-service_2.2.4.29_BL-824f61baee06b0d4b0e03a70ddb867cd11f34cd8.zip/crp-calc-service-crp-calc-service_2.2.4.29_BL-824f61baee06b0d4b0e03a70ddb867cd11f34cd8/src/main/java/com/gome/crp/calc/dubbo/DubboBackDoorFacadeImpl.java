package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.doctor.IDubboBackDoorFacade;
import com.gome.crp.calc.service.doctor.IBackDoorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DubboBackDoorFacadeImpl implements IDubboBackDoorFacade {
    @Autowired
    private IBackDoorService iBackDoorService;

    @Override
    public void recalculateByOrderId(String[] orderIds) {
        iBackDoorService.recalculateByOrderId(orderIds);
    }
}
