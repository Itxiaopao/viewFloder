package com.gome.crp.calc.service.calc.impl;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.calc.abstr.AbstractCalcServiceService;
import com.gome.crp.calc.service.scene.ISceneService;
import com.gome.crp.calc.service.scene.SceneFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CalcServiceOrder extends AbstractCalcServiceService {

    @Autowired
    SceneFactory sceneFactory;

    @Override
    public List<ProfitDto> calcOrder(OrderCalcDto orderCalcDto, PlanDto planDto) {
        List<ProfitDto> profitDtos = new ArrayList<>();

        //List<ISceneService> sceneList = sceneFactory.getSceneList(orderCalcDto.getChannel());
        // O2O, 延保, 常规. 列表
        List<ISceneService> sceneList = sceneFactory.getSceneList(orderCalcDto, planDto);
        for (ISceneService iSceneService : sceneList) {
            List<ProfitDto> calc = iSceneService.calc(orderCalcDto, planDto);
            if (calc != null) {
                profitDtos.addAll(calc);
            }
        }

        return profitDtos;
    }
}
