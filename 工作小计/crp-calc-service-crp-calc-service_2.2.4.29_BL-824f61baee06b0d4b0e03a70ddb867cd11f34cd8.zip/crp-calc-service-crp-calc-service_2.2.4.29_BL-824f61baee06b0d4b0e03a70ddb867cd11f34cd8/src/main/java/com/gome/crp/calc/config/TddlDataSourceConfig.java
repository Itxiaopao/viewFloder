package com.gome.crp.calc.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.druid.pool.DruidDataSource;
import com.taobao.tddl.group.jdbc.TGroupDataSource;

@Configuration
public class TddlDataSourceConfig {
	
	@Value("${appName}")
    private String APP_NAME;
	@Value("${dbGroupKey}")
    private String DB_GROUP_KEY;
	
    /**
     * TDDL数据源
     * @return
     * 
     */
	@Bean(initMethod = "init", destroyMethod = "destroyDataSource")
	public DataSource dataSource() {
		TGroupDataSource tGroupDataSource = new TGroupDataSource();
		tGroupDataSource.setAppName(APP_NAME);
		tGroupDataSource.setDbGroupKey(DB_GROUP_KEY);
		return tGroupDataSource;
	}
	
	//Druid数据源,连接的是开发环境的test数据库
//	@Bean(initMethod = "init", destroyMethod = "close")
//	public DataSource druidDataSource(){
//		DruidDataSource d = new DruidDataSource();
//		d.setDriverClassName("com.mysql.jdbc.Driver");
//		d.setUrl("jdbc:mysql://meixin-mysql-one.dev.cloud.db:5306/test?useUnicode=true&characterEncoding=UTF8");
//		d.setUsername("develop");
//		d.setPassword("ZQ2yGUJfE2");
//		return d;
//	}
}
