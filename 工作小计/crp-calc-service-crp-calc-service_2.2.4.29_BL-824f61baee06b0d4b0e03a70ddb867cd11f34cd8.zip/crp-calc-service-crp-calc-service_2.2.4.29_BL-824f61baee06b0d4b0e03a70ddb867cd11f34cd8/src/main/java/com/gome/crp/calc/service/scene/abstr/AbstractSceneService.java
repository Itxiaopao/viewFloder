package com.gome.crp.calc.service.scene.abstr;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.employee.StaffBindDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.ISceneService;
import com.gome.crp.calc.service.scene.formula.ICalFormulas;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * abstract
 *
 * @author libinbin9
 */
@Slf4j
@Service
public abstract class AbstractSceneService implements ISceneService {

    @Autowired
    private IStaffInfoService staffInfoService;
    @Autowired
    private IProblemService problemService;
    @Autowired
    private ICalFormulas calculatedFormulas;
    @Autowired
    private ICalcRewardsService calcRewardsService;
    @Autowired
    private SceneUtils sceneUtils;
    @Autowired
    private AbsUtils absUtils;

    private static final String scene_log = "Base-";

    /**
     * 场景公式, 购买商品数量 * 个人提奖平分金额  = 计算公式 (返回：分)
     * 实际逻辑: 计算出单个商品提奖金额 * 购买数量 / 获奖人数 = 平分计算提奖结果
     *
     * @param orderDto
     * @param planDto
     * @param number
     * @param scene
     * @return
     */
    public List<BigDecimal> sceneFormula(OrderCalcDto orderDto, PlanDto planDto, int number, String scene) {
        // 调用计算分配接口: 分计算, 截取到 0 以上
        BigDecimal ret = calculatedFormulas.calculatedResult(orderDto, planDto, scene);
        // 向下百分比基数
        long price = ret.setScale(0, RoundingMode.DOWN).longValue();
        // 平分提奖结果
        List<BigDecimal> perAwardPrice = absUtils.getPerAwardPrice(price, number);
        String log_end = "计算提奖金额[最终][商品数量:%d][等比分配]结果: order:%s, planId:%s, 场景:%s, 人数:%d, 均分结果:%s";
        log.info(String.format(log_end, orderDto.getBuyNum(), orderDto.getOrderId(), planDto.getPlanId(), scene, number, JSONObject.toJSONString(perAwardPrice)));
        return perAwardPrice;
    }


    /**
     * @param orderDto
     * @param planDto
     * @param scene
     * @return
     */
    public boolean checkPlanCanCalc(OrderCalcDto orderDto, PlanDto planDto, String scene) {
        return sceneUtils.checkVailCalcPlan(orderDto, planDto, scene);
    }

    /**
     * 拷贝属性
     *
     * @param empl
     * @param shopNo
     * @param orderSupplier
     * @param userId
     * @param isMain
     * @return
     */
    public PersonDto copyProperies(EmployeeInfoDto empl, String shopNo, String orderSupplier, String userId, Integer isMain,Integer profitBehaviorCode) {
        return absUtils.copyProperies(empl, shopNo, orderSupplier, userId, isMain, profitBehaviorCode);
    }

    /**
     * 获取员工code -> 国美线上id
     *
     * @param codes
     * @return
     */
    public Map<String, String> matchStaffCodetoId(List<String> codes) {
        List<StaffBindDto> list = staffInfoService.getBatchUserInfoByStaffCode(codes);
        Optional<List<StaffBindDto>> op = Optional.ofNullable(list);
        list = op.orElse(new ArrayList<>());
        Map<String, String> collect = list.stream().collect(Collectors.toMap(x -> x.getStaffCode(), x -> x.getZxUid()));
        return collect;
    }

    /**
     * 处理奖励
     *
     * @param awardPrice 奖励金额
     * @param count      分几份
     * @return
     */
    public List<BigDecimal> getPerAwardPrice(Long awardPrice, int count) {
        return absUtils.getPerAwardPrice(awardPrice, count);
    }



    /**
     * copy properties by source calcResult and inside log journal
     * 异步 推送问题小工具
     *
     * @param orderCalcDto
     * @param problemMSG
     * @param planDto
     * @param problemEnum
     * @return
     */
    public void addProblem(OrderCalcDto orderCalcDto, PlanDto planDto, String problemMSG, ProblemEnum problemEnum) {
        absUtils.addProblem(orderCalcDto, planDto, problemMSG, problemEnum);
    }

    // 保存计算公式履历
    public void addRewardCommit(OrderCalcDto orderDto, PlanDto planDto, List<ProfitDto> profitList, String scene){
        absUtils.addRewardCommit(orderDto, planDto, profitList, scene, scene_log);
    }

}



