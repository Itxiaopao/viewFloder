package com.gome.crp.calc.service.so.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ProcessNodeEnum;
import com.gome.crp.calc.constants.StatusEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.mybatis.model.OrderCalcMsg;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.calc.service.order.IOrderStatusHandlerService;
import com.gome.crp.calc.service.so.ISOOrderService;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class SOOrderServiceImpl implements ISOOrderService {
    @Autowired
    private IOrderStatusHandlerService orderHandlerService;
    @Autowired
    private IOMSOrderService iomsOrderService;
    @Autowired
    private RedisLockHelper redisLockHelper;

    @Override
    public void handler(String channel, String sapDetailId) {
        List<OrderCalcMsg> orderCalcMsgs = iomsOrderService.matchOrderInfo(channel, sapDetailId);
        if (null == orderCalcMsgs || orderCalcMsgs.size() == 0) {
            log.warn("so查询订单为空，sapDetailId:{},channel:{}", sapDetailId, channel);
            return;
        }
        OrderCalcDto orderCalcDtoLock = JSONObject.parseObject(orderCalcMsgs.get(0).getMsgBody(), OrderCalcDto.class);
        String orderDetailLock = CacheKeyConstants.getOrderDetailLock(orderCalcDtoLock.getOrderId(), orderCalcDtoLock.getChannel(), orderCalcDtoLock.getSkuNo(), orderCalcDtoLock.getDetailId());
        RedisLock redisLock = redisLockHelper.getLock(orderDetailLock);
        if (!redisLock.lock()) {
            log.error("so消息体,detail级提成计算加锁失败orderId:{},orderDetailLock:{}", orderCalcDtoLock.getOrderId(), orderDetailLock);
            throw new BusinessException(String.format("so消息体,detail级提成计算加锁失败orderId:%s,orderDetailLock:%s", orderCalcDtoLock.getOrderId(), orderDetailLock));
        }
        try {
            for (OrderCalcMsg orderCalcMsg : orderCalcMsgs) {
                OrderCalcDto orderCalcDto = JSONObject.parseObject(orderCalcMsg.getMsgBody(), OrderCalcDto.class);
                orderHandlerService.calcOrder(orderCalcDto);
                updateOrderCalcMsg(orderCalcMsg);
            }
        } finally {
            redisLock.unlock();
        }
    }

    /**
     * 更新
     * @param orderCalcMsg
     */
    public void updateOrderCalcMsg(OrderCalcMsg orderCalcMsg){
        OrderCalcMsg updateOrderCalcMsg = new OrderCalcMsg();
        updateOrderCalcMsg.setId(orderCalcMsg.getId());
        updateOrderCalcMsg.setStatus(StatusEnum.FINISHED_PROCESSING.getCode());
        updateOrderCalcMsg.setProcessNode(ProcessNodeEnum.SO_NODE.getCode());
        iomsOrderService.updateById(updateOrderCalcMsg);
    }

}
