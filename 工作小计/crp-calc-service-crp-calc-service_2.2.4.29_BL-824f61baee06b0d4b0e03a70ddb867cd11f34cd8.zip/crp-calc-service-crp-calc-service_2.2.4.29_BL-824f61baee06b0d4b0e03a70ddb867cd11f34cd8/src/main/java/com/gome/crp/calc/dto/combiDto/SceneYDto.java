package com.gome.crp.calc.dto.combiDto;

import lombok.Data;

import java.util.Date;

@Data
public class SceneYDto {
    private String orderId;
    private String userId;
    private String planId;
    private String staffCode;
    private Date endTime;
    private Long paymentMoney;

}
