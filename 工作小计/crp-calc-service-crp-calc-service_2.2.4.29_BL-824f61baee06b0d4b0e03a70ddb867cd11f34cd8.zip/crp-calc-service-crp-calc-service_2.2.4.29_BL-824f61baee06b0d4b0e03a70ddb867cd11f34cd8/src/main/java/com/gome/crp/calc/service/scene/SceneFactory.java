package com.gome.crp.calc.service.scene;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.service.scene.impl.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * 关联流程计算场景普通工厂类
 */
@Component
@Slf4j
public class SceneFactory implements InitializingBean  {
	
	@Autowired
	private SceneXServiceImpl sceneXService;
	@Autowired
	private SceneYServiceImpl sceneYService;
	@Autowired
	private SceneZServiceImpl sceneZService;
	@Autowired
	private SceneMServiceImpl sceneMService;
	
	@Autowired
	private SceneZO2OServiceImpl sceneZO2OService;
	@Autowired
	private SceneMO2OServiceImpl sceneMO2OService;
	@Autowired
	private SceneXYBServiceImpl sceneXYBService;
	@Autowired
	private SceneM_YXServiceImpl sceneM_yxService;
	@Autowired
	private SceneZ_YXServiceImpl sceneZ_yxService;



	@Autowired
	public Map<String, ISceneService> calcSceneServiceMap;

	@Autowired
	public List<ISceneService> calcSceneServices;	// common
	@Autowired
	public List<ISceneService> calcSceneO2OServices;	// O2O
	@Autowired
	public List<ISceneService> calcSceneYBServices;	// 延保
	@Autowired
	public List<ISceneService> calcSceneYXServices;	// 营销


	@Override
	public void afterPropertiesSet() throws Exception {
		// init add scene lists
		this.addInitSceneList();
		// init put scene maps
		this.putInitSceneMap();
	}

	// add init scene list
	private void addInitSceneList(){
		/**
		 * initial (x y z m) compute logic
		 */
		calcSceneServices = new ArrayList<>(4);
		calcSceneServices.add(sceneXService);
		calcSceneServices.add(sceneMService);
		calcSceneServices.add(sceneZService);
		calcSceneServices.add(sceneYService);

		// O2O
		calcSceneO2OServices = new ArrayList<>(4);
		calcSceneO2OServices.add(sceneZO2OService);
		calcSceneO2OServices.add(sceneMO2OService);

		// 延保
		calcSceneYBServices = new ArrayList<>(4);
		calcSceneYBServices.add(sceneXYBService);

		// 营销
		calcSceneYXServices = new ArrayList<>(4);
		calcSceneYXServices.add(sceneM_yxService);
		calcSceneYXServices.add(sceneZ_yxService);
	}

	// 通用xyzm
	private void putInitSceneMap(){
		calcSceneServiceMap = new HashMap<>(4);
		calcSceneServiceMap.put(BaseConstants.SCENE_X, sceneXService);
		calcSceneServiceMap.put(BaseConstants.SCENE_Y, sceneYService);
		calcSceneServiceMap.put(BaseConstants.SCENE_Z, sceneZService);
		calcSceneServiceMap.put(BaseConstants.SCENE_M, sceneMService);
	}

	/**
	 * return list
	 * 1. O2O
	 * 2. 延保
	 * 3. 常规
	 * 4. 营销
	 *
	 * @return
	 */
	public List<ISceneService> getSceneList(OrderCalcDto orderCalcDto, PlanDto planDto){
		String orderId = orderCalcDto.getOrderId();
		Long planId = planDto.getPlanId();
		// 营销
		if (BaseConstants.ORDER_YX_STATUS_1 == orderCalcDto.getIsYX()) {
			log.info(String.format("订单计划场景匹配促销类型-营销, orderId:%s, planId:%s", orderId, planId));
			return calcSceneYXServices;
		}
		// O2O
		if(BaseConstants.ORDER_CHANNEL_O2O.equals(orderCalcDto.getChannel())){
			log.info(String.format("订单计划场景匹配促销类型-O2O, orderId:%s, planId:%s", orderId, planId));
			return calcSceneO2OServices;
		}
		// 延保
		if(BaseConstants.PLAN_PROLONG_ASSURE_TYPE.equals(planDto.getPromotionsType() + "")){
			log.info(String.format("订单计划场景匹配促销类型-延保, orderId:%s, planId:%s", orderId, planId));
			return calcSceneYBServices;
		}
		log.info(String.format("订单计划场景匹配促销类型-常规类型, orderId:%s, planId:%s", orderId, planId));
		// 常规
		return calcSceneServices;
	}
	
	/**
	 * return maps
	 * 
	 * @return
	 */
	public Map<String, ISceneService> getSceneMap(){
		return calcSceneServiceMap;
	}

}
