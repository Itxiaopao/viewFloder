package com.gome.crp.calc.client.employee.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.gome.crp.calc.client.coupon.IConsumerConponService;
import com.gome.crp.calc.client.employee.IProfitStaffService;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.employee.GomeCategoryBrand;
import com.gome.crp.calc.dto.employee.GomeEmployeePostInformation;
import com.gome.crp.calc.dto.employee.ResponseGroupVendorDto;
import com.gome.crp.calc.dto.employee.StaffBindDto;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.service.problem.IProblemService;

import lombok.extern.slf4j.Slf4j;

/**
 * x场景
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class ProfitStaffService implements IProfitStaffService {

	@Autowired
	private IStaffInfoService staffInfoService;
	@Autowired
	private IConsumerConponService consumerConponService;

	//private static String defuat_staff_code_a = "A0000000";
	private static String DEFUAT_STAFF_CODE_C = "C0000000";
    @Autowired
    private IProblemService iProblemService;
	
	/**
	 * 校验员工结果: shopNo, brand, category
	 * 
	 * 1. 分享人 -> 校验员工
	 * 2. 券分享人判断 -> 校验员工
	 * 
	 * 3. 没有结果返回默认C0000000
	 * 
	 * @param staffreq
	 * @return
	 */
	@Override
	public List<PersonDto> memberUserIdFindStaffIdentity(StaffReqsDto staffreq) {
		String logEmbedPort = staffreq.getLogEmbedPort();
		log.info(String.format("员工信息身份-获利人信息查询-start, logEmbedPort:%s, param:%s", logEmbedPort, JSONObject.toJSONString(staffreq)));
		// 判断是否存在门店
		List<PersonDto> default_persons = Arrays.asList(this.getDefualtPerson(null, DEFUAT_STAFF_CODE_C));
		String shopNo = staffreq.getShopNo();
		if (StringUtils.isBlank(shopNo)) {
			log.info(String.format("员工信息身份-获利人信息查询[非法]: logEmbedPort:%s, shopNo为NULL", logEmbedPort));
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"获利人信息查询[非法]门店为空",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return default_persons;
		}
		// 线下二级品类
		String eaCateSecond = staffreq.getEaCateSecond();
		if (StringUtils.isBlank(eaCateSecond)) {
			log.info(String.format("员工信息身份-获利人信息查询[非法], logEmbedPort:%s, shopNo:%s, eaCateSecond:NULL", logEmbedPort,
					shopNo));
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"获利人信息查询[非法]线下二级品类为空",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return default_persons;
		}
		// 线下二级品牌
		String eaBrandCode = staffreq.getEaBrandCode();
		if (StringUtils.isBlank(eaBrandCode)) {
			log.info(String.format(
					"员工信息身份-获利人信息查询[非法], logEmbedPort:%s, shopNo:%s, eaCateSecond:%s, eaBrandCode:NULL", logEmbedPort,
					shopNo, eaCateSecond));
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"获利人信息查询[非法]线下二级品牌为空",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return default_persons;
		}
		List<PersonDto> pl = null; // 匹配返回的数据
		String productShareUserId = staffreq.getProductShareUserId(); // 赋值 -> 分享人国美会员userId
		// 如果分享人信息不存在, 查询券逻辑
		if(StringUtils.isBlank(productShareUserId)){
			// 券逻辑获取分享人
			pl = this.queryPersonListByCouponUserId(staffreq);
		}else {
			// 直接走分享人逻辑
			pl = this.getPersonListByUserIdTurnStaff(productShareUserId, staffreq);
		}
		if(CollectionUtils.isEmpty(pl)) {
			// 任何不符合的数据都返回默认值
			log.info(String.format("员工信息身份-获利人信息查询[失败], logEmbedPort:%s, 返回默认值:C0000000", logEmbedPort));
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"没有查到获利人",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return default_persons;
		}
		log.info(String.format("员工信息身份-获利人信息查询-start, logEmbedPort:%s, param:%s, returen:%s",
				logEmbedPort, JSONObject.toJSONString(staffreq), JSONObject.toJSONString(pl)));
		return pl;
	}
	
	/**
	 * 通过userId 查询员工信息, 校验员工信息
	 * @param memberUserId
	 * @param staffreq
	 * @return
	 */
	private List<PersonDto> getPersonListByUserIdTurnStaff(String memberUserId, StaffReqsDto staffreq) {
		List<PersonDto> pl = null;
		// 分享人存在 -> 员工身份
		StaffBindDto staff = staffInfoService.getStaffInfoByUid(memberUserId);
		// 员工身份判断
		if (staff != null) {
			pl = this.queryStaffByMumberUserId(staff.getStaffCode(), staffreq);
		}
		// 分享人身份赋值默认身份
		if (CollectionUtils.isEmpty(pl)) {
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"通过[券列表查询转赠履历]-通过[会员Id]-查询员工结果[NULL]",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			log.info(String.format("员工信息身份-通过[会员Id]-查询员工结果[NULL], staffCode:C0000000, 基本参数:%s, 会员id:%s", staffreq.getLogEmbedPort(), memberUserId));
		}
		return pl;
	}
	
	
	/**
	 * 分享人 身份(分享人id, 券用户id)匹配, 员工身份 + 校验 身份
	 * 
	 * @param staffCode
	 * @param staffreq
	 * @return
	 */
	private List<PersonDto> queryStaffByMumberUserId(String staffCode, StaffReqsDto staffreq) {
		String storeLevel = staffreq.getStoreLevel();
		if(StringUtils.isBlank(storeLevel)) {
			storeLevel = BaseConstants.STAFF_LEVEL_4 + "";
		}
		// 判断是否存在门店
		String shopNo = staffreq.getShopNo();
		// 线下二级品类
		String eaCateSecond = staffreq.getEaCateSecond();
		// 线下二级品牌
		String eaBrandCode = staffreq.getEaBrandCode();
		// 查询分享人(员工)身份
		List<String> staffcodes = Arrays.asList(staffCode);
		List<EmployeeInfoDto> query = staffInfoService.queryGomeEmployeeInformation(staffreq.getOrderId(), eaCateSecond, eaBrandCode, staffcodes, shopNo, storeLevel);
		// 匹配分享人(员工)信息
		List<PersonDto> personList = this.judgeStaffIsMatch(query, staffreq);
		return personList;
	}

	/**
	 * 券匹配 员工 + 校验身份
	 * @param staffreq
	 * @return
	 */
	private List<PersonDto> queryPersonListByCouponUserId(StaffReqsDto staffreq) {
		// 券分享人会员id
		String couponMemberId = null;
		List<OrderCalcCouponDto> couponsDtoList = staffreq.getCouponsDtoList();
		if (couponsDtoList != null && couponsDtoList.size() > 0) {
			List<OrderCalcCouponDto> cdList = couponsDtoList.stream().map(e -> {
				OrderCalcCouponDto target = new OrderCalcCouponDto();
				BeanUtils.copyProperties(e, target);
				return target;
			}).collect(Collectors.toList());
			// 判断券分享人是否存在-> 会员id
			couponMemberId = consumerConponService.queryCouponGiveInfo(cdList, staffreq.getOrderUserId());
		}
		List<PersonDto> personList = null;
		// 券信息: 无, 匹配促销员
		if(StringUtils.isBlank(couponMemberId)) {
		    iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"通过[券列表查询转赠履历]-查询会员Id结果[NULL]",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			log.info(String.format("员工信息身份-通过[券列表查询转赠履历]-查询会员Id结果[NULL], 默认staffCode:C0000000, 基本参数:%s, 券集合:%s", staffreq.getLogEmbedPort(), JSONObject.toJSONString(couponsDtoList)));
		}else {
			// 券分享: 有, 券分享人会员id -> 员工Id
			personList = this.getPersonListByUserIdTurnStaff(couponMemberId, staffreq);
		}
		return personList;
	}
	

	/**
	 * 匹配员工身份: 
	 * 门店 + 品牌 + 品类
	 * 
	 * @param query
	 * @param staffreq
	 * @return
	 */
	private List<PersonDto> judgeStaffIsMatch(List<EmployeeInfoDto> query, StaffReqsDto staffreq) {
		if (CollectionUtils.isEmpty(query)) {
			return null;
		}
		String sharsUserId = staffreq.getProductShareUserId();
		// 判断是否存在门店
		String shopNo = staffreq.getShopNo();
		// 线下二级品类
		String eaCateSecond = staffreq.getEaCateSecond();
		// 线下二级品牌
		String eaBrandCode = staffreq.getEaBrandCode();
		// 供应商Id
		String supplier = staffreq.getSupplierCode();
		// 渠道 13, 16, 
		String channelNo = staffreq.getChannelNo();
		// 分享人只有一个员工
		EmployeeInfoDto empl = query.get(0);
		String employeeId = empl.getBaseInfo().getEmployeeId();
		String logEmbedPort = staffreq.getLogEmbedPort();
		// 判断商品分享人 计算x
		// 匹配门店信息
		boolean isStorSeller = this.isStoreStaff(empl, shopNo);
		if (!isStorSeller) {
			log.info(String.format("员工信息身份-门店[不匹配], 基本信息:%s, employeeId:%s, 订单shopNo:%s ", logEmbedPort, employeeId, shopNo));
		    iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"员工信息身份-门店[不匹配]",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return null;
		}
		// 主营
		int mainStaff = this.isMainStaff(empl, eaCateSecond, eaBrandCode);
		if(mainStaff != 1) {
			log.info(String.format("员工信息身份-主营[不匹配], 基本信息:%s, employeeId:%s, 订单品牌:%s, 订单品类:%s ", logEmbedPort, employeeId, eaBrandCode, eaCateSecond));
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"员工信息身份-主营[不匹配]",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return null;
		}
		// 供应商 + 渠道
		boolean matchSupplior = this.matchSupplior(empl, supplier, channelNo);
		if(!matchSupplior) {
			log.info(String.format("员工信息身份-供应商[不匹配], 基本信息:%s, employeeId:%s, 供应商编码:%s", logEmbedPort, employeeId, supplier));
			iProblemService.addData(staffreq.getOrderId(), staffreq.getChannelNo(), staffreq.getCommerceItemId(),"员工信息身份-供应商[不匹配],",ProblemEnum.CODE_134,DEFUAT_STAFF_CODE_C);
			return null;
		}
		
		PersonDto p = this.copyProperies(empl, shopNo, supplier, sharsUserId);
		List<PersonDto> list = Arrays.asList(p);
		return list;
	}
	
	
	/**
	 * 拷贝属性
	 * 
	 * @param empl
	 * @param userId
	 * @return
	 */
	public PersonDto copyProperies(EmployeeInfoDto empl, String shopNo, String supplier, String userId) {
		PersonDto p = new PersonDto();
		p.setUserId(userId);
		p.setStaffCode(empl.getBaseInfo().getEmployeeId());
		p.setStaffClass(empl.getBaseInfo().getEmplClass());
		p.setStaffLevel(BaseConstants.STAFF_LEVEL_4);
		p.setStoreCode(shopNo);
		return p;
	}

	/**
	 * 默认员工信息
	 * 
	 * @param userId
	 * @param staffCode
	 * @return
	 */
	private PersonDto getDefualtPerson(String userId, String staffCode) {
		PersonDto p = new PersonDto();
		p.setUserId(userId);
		p.setStaffCode(staffCode);
		return p;
	}

	/**
	 * 匹配供应商: 职匹配主营的数据信息 兼营的用不上
	 *
	 * @param empl
	 * @param supplierCode
	 * @return
	 */
	private boolean matchSupplior(EmployeeInfoDto empl, String supplierCode, String channel) {
//		if(BaseConstants.ORDER_CHANNEL_MEIDIAN.equals(channel)) {
//			// 特殊需求, 13渠道没有供应商id导致这里不能向下正常流转: 带需求确认, 目前开关不放开
//			return true;
//		}
		if(StringUtils.isBlank(supplierCode)) {
			return false;
		}
		String emplClass = empl.getBaseInfo().getEmplClass();
		boolean is_sp = false;
		// emplClass D， J
		if (BaseConstants.EMPL_CLASS_J.equals(emplClass) || BaseConstants.EMPL_CLASS_D.equals(emplClass)) {
			List<ResponseGroupVendorDto> gomeVendorList = empl.getGomeVendorList();
			log.info(String.format("匹配供应商,员工供应商信息:%s,行项目号供应商:%s",JSONObject.toJSONString(gomeVendorList),supplierCode));
			if(gomeVendorList != null && gomeVendorList.size() > 0) {
				is_sp = gomeVendorList.stream().anyMatch(rgvd -> supplierCode.equals(rgvd.getVendorCode()));
			}
		}
		return is_sp;
	}
	
	/**
	 * 匹配供应商: 职匹配主营的数据信息 兼营的用不上
	 *
	 * @param empl
	 * @param supplierCode
	 * @return
	 */
	private boolean matchSupplior(EmployeeInfoDto empl, String supplierCode) {
		if(StringUtils.isBlank(supplierCode)) {
			// 特殊需求, 13渠道没有供应商id导致这里不能向下正常流转: 带需求确认, 目前开关不放开
			return false;
		}
		String emplClass = empl.getBaseInfo().getEmplClass();
		boolean is_sp = false;
		// emplClass D， J
		if (BaseConstants.EMPL_CLASS_J.equals(emplClass) || BaseConstants.EMPL_CLASS_D.equals(emplClass)) {
			List<ResponseGroupVendorDto> gomeVendorList = empl.getGomeVendorList();
			if(gomeVendorList != null && gomeVendorList.size() > 0) {
				is_sp = gomeVendorList.stream().anyMatch(rgvd -> supplierCode.equals(rgvd.getVendorCode()));
			}
		}
		return is_sp;
	}
	
	/**
	 * 判断是否是该门店员工
	 * 
	 * @param empl
	 * @param shopNo
	 * @return
	 */
	private boolean isStoreStaff(EmployeeInfoDto empl, String shopNo) {
		// 匹配门店信息
		List<GomeEmployeePostInformation> gepis = empl.getGomeEmployeePostInformationList();
		Optional<List<GomeEmployeePostInformation>> opGEPIS = Optional.ofNullable(gepis);
		gepis = opGEPIS.orElse(new ArrayList<>());
		boolean gepisAnyMatch = gepis.stream().anyMatch(x -> shopNo.equals(x.getShop()));
		return gepisAnyMatch;
	}
	
	/**
	 * 判断是否是 主营| 兼营
	 * @param empl
	 * @param eaCateSecond
	 * @param eaBrandCode
	 * @return
	 */
	public int isMainStaff(EmployeeInfoDto empl, String eaCateSecond, String eaBrandCode) {
		int is_main = 0;	// 初始值 0 
		List<GomeCategoryBrand> gsscbList = empl.getGsscbList();
		if (null == gsscbList || gsscbList.size() <= 0) {
			return 0; // 数据不匹配
		}
		// 排重，获取is_main字段数据
		Stream<String> distinct = gsscbList.stream().filter(
				gcb -> eaBrandCode.equals(gcb.getBrandCode()) && eaCateSecond.equals(gcb.getCategoryCode()))
				.map(e -> e.getIsMain()).distinct();
		// 有一条主营数据即为主营, 否则为兼营, 匹配条件全部兼营数据, 防止数据空
		boolean match_is_main = distinct.allMatch(x -> BaseConstants.IS_MAIN_STR_N.equals(x));
		if (match_is_main) {
			is_main = BaseConstants.IS_MAIN_INT_N;
		} else {
			is_main = BaseConstants.IS_MAIN_INT_Y;
		}
		return is_main;
	}
	
	/**
	 * 判断是否是 品牌 + 品类
	 * @param empl
	 * @param eaCateSecond
	 * @param eaBrandCode
	 * @return
	 */
	public boolean isBrandAndCate(EmployeeInfoDto empl, String eaCateSecond, String eaBrandCode) {
		boolean is_main = false;	// 初始值 0 
		List<GomeCategoryBrand> gsscbList = empl.getGsscbList();
		if (null == gsscbList || gsscbList.size() <= 0) {
			return is_main; // 数据不匹配
		}
		// 判断 品牌 + 品类
		is_main = gsscbList.stream().anyMatch(
				gcb -> eaBrandCode.equals(gcb.getBrandCode()) && eaCateSecond.equals(gcb.getCategoryCode()));
		return is_main;
	}
	
//	/**
//	 * single 员工code 获取 userId
//	 * @param staffcode
//	 * @return
//	 */
//	private String getUserIdByStaffCode(String staffcode) {
//		String uid = null;
//		StaffBind staff = staffInfoService.getUserInfoByStaffCode(staffcode);
//		if(staff != null) {
//			uid = staff.getZxUid();
//		}
//		return uid;
//	}
	

}
