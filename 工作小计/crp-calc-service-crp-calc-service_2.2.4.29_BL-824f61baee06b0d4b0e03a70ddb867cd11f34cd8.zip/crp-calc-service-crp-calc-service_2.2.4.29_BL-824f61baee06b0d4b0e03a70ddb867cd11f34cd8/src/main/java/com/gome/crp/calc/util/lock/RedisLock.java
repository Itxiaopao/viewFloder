package com.gome.crp.calc.util.lock;

import lombok.extern.slf4j.Slf4j;
import redis.Gcache;
import redis.GcacheClient;
import redis.gcache.core.GcacheCoreImpl;

import java.util.Arrays;
import java.util.Collections;
import java.util.UUID;

@Slf4j
public class RedisLock {
    private static final String LOCK_SCRIPT = "local current = redis.call('setnx',KEYS[1],ARGV[1]); if current == 1 then redis.call('expire',KEYS[1],ARGV[2]) end; return current";
    private static final String UNLOCK_SCRIPT = "if redis.call('get',KEYS[1]) == ARGV[1] then return redis.call('del',KEYS[1]) else return 0 end";
    private String lockValue = UUID.randomUUID().toString();
    private String lockKey = ""; //锁键
    private int internalLockLeaseTime = 20;//锁过期时间（单位秒）
    private long timeout = 60000; //获取锁的超时时间（单位毫秒）
    private GcacheCoreImpl gcacheCoreImpl;

    RedisLock(Gcache gcache, String lockKey, int internalLockLeaseTime, long timeout) {
        this.lockKey = lockKey;
        this.timeout = timeout;
        this.internalLockLeaseTime = internalLockLeaseTime;
        this.gcacheCoreImpl = (GcacheCoreImpl) ((GcacheClient) gcache).getGcache();
    }

    RedisLock(Gcache gcache, String lockKey) {
        this.lockKey = lockKey;
        this.gcacheCoreImpl = (GcacheCoreImpl) ((GcacheClient) gcache).getGcache();
    }

    /**
     * 加锁
     *
     * @return
     */
    public boolean lock() {
        long start = System.currentTimeMillis();
        for (; ; ) {
            //setnxex命令返回1 ，则证明获取锁成功
            long lock = (long) gcacheCoreImpl.eval(LOCK_SCRIPT, Collections.singletonList(gcacheCoreImpl.wrap(lockKey)), Arrays.asList(lockValue, String.valueOf(internalLockLeaseTime)));
            if (lock == 1L) {
                return true;
            }
            //否则循环等待，在timeout时间内仍未获取到锁，则获取失败
            long l = System.currentTimeMillis() - start;
            if (l >= timeout) {
                return false;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                log.warn("Interrupted!", e);
                Thread.currentThread().interrupt();
            }
        }
    }

    /**
     * 解锁
     *
     * @return
     */
    public boolean unlock() {
        //判断加锁与解锁是不是同一个客户端
        long value = (long) gcacheCoreImpl.eval(UNLOCK_SCRIPT, Collections.singletonList(gcacheCoreImpl.wrap(lockKey)), Collections.singletonList(lockValue));
        return value == 1L;
    }

}