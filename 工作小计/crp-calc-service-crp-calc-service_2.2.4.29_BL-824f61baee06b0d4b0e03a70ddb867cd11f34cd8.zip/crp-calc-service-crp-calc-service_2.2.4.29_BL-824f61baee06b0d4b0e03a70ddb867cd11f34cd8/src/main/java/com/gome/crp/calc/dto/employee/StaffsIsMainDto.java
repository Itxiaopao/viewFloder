package com.gome.crp.calc.dto.employee;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 促销员是否值主营兼营DTO
 * 
 * @author libinbin9
 *
 */
@Setter
@Getter
public class StaffsIsMainDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3072115727816355975L;
	
	/** 主营列表 */
	private List<EmployeeInfoDto> mainStaffs;
	/** 兼营列表 */
	private List<EmployeeInfoDto> unMainStaffs;
	
}
