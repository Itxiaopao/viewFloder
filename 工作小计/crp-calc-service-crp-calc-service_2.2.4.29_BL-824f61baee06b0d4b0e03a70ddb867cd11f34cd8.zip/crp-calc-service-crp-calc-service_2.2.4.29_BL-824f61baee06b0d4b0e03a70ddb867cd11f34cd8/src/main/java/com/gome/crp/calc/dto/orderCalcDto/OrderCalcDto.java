package com.gome.crp.calc.dto.orderCalcDto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 提成计算时使用的dto
 */
@Data
public class OrderCalcDto implements Serializable {
    // todo 本地测试以后删除
    private static final long serialVersionUID = -7912092732529004960L;
    /*
            订单
         */
    private String orderId; //订单ID
    private String returnOrderId; // 售后单号，发生逆向时推送，表示是逆向订单号
    private String userId; //购买者
    private String userName; //购买者名称
    private BigDecimal orderPrice; //订单总金额（包含国美币）（实付金额，排除券，美豆后的支付金额）
    private BigDecimal orderSalePrice; //订单总金额（包含国美币）（未排除券美豆后的支付金额）
    private Date submittedDate; //订单创建时间
    private Date payDate; // 订单支付时间
    private String orderType; //订单类型:正常单;1:预售单;2:SMI单;3:货到付款4:全额定金发货
    private String cpsId; //cpsId
    private Map<String, String> requestHeaderMap; //CTX--Map

    /*
        配送单
     */
    private Date orderDate; //订单流转时间
    private String deliveryId; //配送单id
    private String gomeState; //配送单状态：ES映射成OMS的配送单状态
    private String shopNo; //店铺编码
    private String shopType; //店铺类型（线下自营店 线下联营店 线下加盟店 线上pop店 线上旗舰店）
    private String channel; //渠道编码
    private String demanderCode; // 业务方，目前只有12渠道有值

    /*
        商品
     */
    private String categoryFirstId; //线上展示一级类目
    private String categorySecondId; //线上展示二级类目
    private String categoryThirdId; //线上展示三级类目
    private String categoryFourthId; //线上展示四级类目
    private String skuId; //skuId
    private String skuName; //skuName（长）
    private String salesOrganization; //销售组织ID
    private String companyCode; //公司代码
    private String skuNo; //skuNo
    private BigDecimal salePrice; //商品售价（不减券的价格）
    private String microID; //美店店主Id
    private String kid; //追踪分享链Id
    private String shareUserId; //分享人id
    private String storeSellerId; //开单人员工编码（来购开单）
    private String eaBrandCode; //品牌编码
    private String eaGroupCodeFirst; //线下一级品类
    private String eaGroupCodeSecond; //线下二级品类
    private String eaGroupCodeThird; //线下三级品类
    private String eaGroupCode; //线下四级品类
    private String description; //商品名称（短）
    private String commerceItemId; //订单行项目号 旧Mq对应的是，orderItemId
    private String goodsType; // 商品标识：1：主商品；2；赠品；

    private int isYB; // 延保: 线下二级品类为RB0/R46   1为延保,0不是延保

    private String stockType;   // 库存类型: BaseConstants:ORDER_CALC_STOCK_TYPE_*


    /*
        detail
     */
    private String detailId; //detailId
    private String sapDetailId; // sapDetailId
    private Integer buyNum; //购买数量（要想算商品数量需要把detail下的累加）
    private BigDecimal price; //实付价格（已经减掉了优惠的价格）
    private String salesModel; //业务机型（01 02 03）
    private String logicMasLoc; //逻辑DC编码
    private String supplier; //供应商编码（供货商代码）

    /*
        券
     */
    private List<OrderCalcCouponDto> couponsDtoList; //使用券集合

    /*
        【注意】此处往下都是提成计算冗余字段
        【注意】订单消息体的字段有更改在上面新增
     */
    private String channelCalcNo; // 冗余字段，计算端标识线下（1），一店一页（2），线上（3）
    /**
     * 采购组织集合
     */
    private List<String> purchaseCodeList;

    private int isYX; //营销 ：1 为营销推广  0 不是营销推广

    /**
     * 是否是延保    1为延保,0不是延保
     */
    private Integer warrantyFlag;
    
    /**
     * 计算逻辑
     */
    private String calcLogic;//计算逻辑
}