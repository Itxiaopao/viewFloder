package com.gome.crp.calc.service.scene.formula.utils;


import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.formula.JTBasePriceDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.service.problem.IProblemService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * 场景公共方法获取, 加入问题小工具
 */
@Slf4j
@Service
public class SceneUtils {

    //百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);
    private static BigDecimal percent_rate_cent_1 = BigDecimal.valueOf(1.0);

    @Autowired
    private IProblemService problemService;


    // xzm场景 提成比例
    public BigDecimal getSceneValue (PlanDto planDto, String scene) {
        BigDecimal value = null;
        if(BaseConstants.SCENE_X.equals(scene)){
            value = planDto.getXValue();
        }else if (BaseConstants.SCENE_M.equals(scene)){
            value = planDto.getMValue();
        }else if (BaseConstants.SCENE_Z.equals(scene)){
            value = planDto.getZValue();
        }
        if (value == null){
            String format = String.format("planId: %s, 场景: %s, 计划ScenValue提成比例 None", planDto.getPlanId(), scene);
            log.info(format);
            value = BigDecimal.valueOf(0.0);
        }
        return value;
    }

    // 计提现价
    public Long getJTCurrentPrice(PlanDto planDto){
        return planDto.getCurrentPrice();
    }


    // 计提基数获取
    public JTBasePriceDto getJTBases(OrderCalcDto orderCalcDto, PlanDto planDto) {
        JTBasePriceDto dto = new JTBasePriceDto();
        // 0销售金额、1实付金额
        Integer provisionType = planDto.getProvisionType();
        dto.setProvisionType(provisionType);
        BigDecimal jiti_base = null;    // 计提基数
        if (provisionType == BaseConstants.PLAN_PROVISION_SELL) {
            dto.setProvisionStr("销售金额:type=0");
            jiti_base = orderCalcDto.getSalePrice();    // 订单总金额（包含国美币）（实付金额，排除券、美豆后的支付金额）
        } else if (provisionType == BaseConstants.PLAN_PROVISION_REAL) {
            dto.setProvisionStr("实付金额:type=1");
            jiti_base = orderCalcDto.getPrice(); // detail级别sku的单个商品的实付金额
        }
        dto.setPrice(jiti_base);
        if (jiti_base == null){
            String format = String.format("判断计提基数:None, orderId:%s", orderCalcDto.getOrderId());
            log.info(format);
        }
        return dto;
    }


    /**
     * 检测正常运算数据
     *
     * @param orderDto
     * @param planDto
     * @param scene
     * @return
     */
    public boolean checkVailCalcPlan(OrderCalcDto orderDto, PlanDto planDto, String scene) {
        Integer promotionsType = planDto.getPromotionsType();
        if (!(BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(promotionsType)) ||
                BaseConstants.PLAN_DIFFERENT_TYPE.equals(String.valueOf(promotionsType)) ||
                BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(String.valueOf(promotionsType)) ||
                BaseConstants.PLAN_REPLACE_TYPE.equals(String.valueOf(promotionsType)))
        ) {
            // 非促销费类型（0无促、1差异化、2非差异化、3带单） 跳过
            log.info(String.format("计算场景检测[不计算]: 非正常-促销费类型, 该订单不计算 orderId:%s, planId:%d, 场景:%s, 促销费类型:%d",
                    orderDto.getOrderId(), planDto.getPlanId(), scene, promotionsType));
            return false;
        }

        // 计提现价
        Long currentPrice = this.getJTCurrentPrice(planDto);
        if (null == currentPrice) {
            // 没有值得情况下需要返回正常的状态
            log.info(String.format("计算场景检测[不计算]: 计提现价:NULL, 该订单不计算 orderId:%s, planId:%d, 场景:%s, 促销费类型:%d",
                    orderDto.getOrderId(), planDto.getPlanId(), scene, promotionsType));
            this.addProblem(orderDto, planDto, "计提现价:Null,无法计算场景获利金额", ProblemEnum.CODE_116);
            return false;
        }
        // 计提基数 （0销售金额、1实付金额）
        JTBasePriceDto jtBasesDto = this.getJTBases(orderDto, planDto);
        String jtProvisionStr = jtBasesDto.getProvisionStr();
        BigDecimal jtBases = jtBasesDto.getPrice();
        if(jtBases == null){
            return false;   // 非空判断
        }
        // 条件:正向 计提基数 > 计提现价
        if (jtBases.compareTo(BigDecimal.valueOf(currentPrice)) < 0) {
            this.addProblem(orderDto, planDto, "计提基数 < 计提现价,无法计算场景获利金额", ProblemEnum.CODE_108);
            log.info(String.format("计算场景检测[不计算]: 计提基数[%s, %s] < 计提现价[%s], 该订单不计算 orderId:%s, planId:%d, 场景:%s, 促销费类型:%d",
                    jtProvisionStr, jtBases, currentPrice, orderDto.getOrderId(), planDto.getPlanId(), scene, promotionsType));
            return false;
        }
        return true;
    }

    /**
     * copy properties by source calcResult and inside log journal
     * 异步 推送问题小工具
     *
     * @param orderCalcDto
     * @param problemMSG
     * @param planDto
     * @param problemEnum
     * @return
     */
    @Async
    public void addProblem(OrderCalcDto orderCalcDto, PlanDto planDto, String problemMSG, ProblemEnum problemEnum) {
        String str = "添加问题小工具, 数据参数orderId:%s, planId:%d, 问题内容: %s, 类型:%s";
        log.info(String.format(str, orderCalcDto.getOrderId(), planDto.getPlanId(), problemMSG, problemEnum.getMsg()));
        ProblemDto pd = new ProblemDto(orderCalcDto.getOrderId(), orderCalcDto.getChannel(), orderCalcDto.getSkuNo(),
                orderCalcDto.getDetailId());
        pd.setDescription(problemMSG);
        pd.setPlanId(planDto.getPlanId() + "");
        problemService.addData(pd, problemEnum);
    }


}
