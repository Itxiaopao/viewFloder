package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboCalcOrderResultFacade;
import com.gome.crp.calc.service.job.IJobAwardService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 计算履历
 */
@Slf4j
@Service("dubboCalcOrderResultFacade")
public class DubboCalcOrderResultFacadeImpl implements IDubboCalcOrderResultFacade {

    @Autowired
    IJobAwardService iJobAwardService;

    /**
     * 扫sap严控的 数据
     */
    @Override
    public void dealFreezeStatus() {
        log.info("执行DubboCalcOrderResultImpl.dealFreezeStatus()任务");
        iJobAwardService.dealFreezeStatus();
    }

    @Override
    public void dealPromoter(String dateStr) {
        log.info("执行DubboCalcOrderResultImpl.dealPromoter()任务");
        iJobAwardService.dealPromoter(dateStr);
    }
}
