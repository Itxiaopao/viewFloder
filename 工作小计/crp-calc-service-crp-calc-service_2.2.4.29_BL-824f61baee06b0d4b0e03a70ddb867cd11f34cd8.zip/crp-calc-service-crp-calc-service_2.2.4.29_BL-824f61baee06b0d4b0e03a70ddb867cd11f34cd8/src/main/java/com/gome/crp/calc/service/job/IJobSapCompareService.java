package com.gome.crp.calc.service.job;

public interface IJobSapCompareService {

	/**
	 * 处理需要严控的数据
	 */
	void scanNorm();
	
	
	/**
	 * 扫描： 未成功的数据
	 */
	void scanUnSuc();

	/**
	 * 处理不需要严控的数据
	 */
	void scanNoDetect();

	/**
	 * 严控后续处理
	 */
	void scanFollowUp();
}
