package com.gome.crp.calc.service.rewardRecord;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcResultReward;

import java.util.List;

public interface ICalcRewardsService {


    /**
     * 提取预加入信息, 插入库表
     * from: 业务来源
     */
    void addCommit(OrderCalcDto orderDto, PlanDto planDto, List<ProfitDto> profitList, String scene, String from) ;

    /**
     * 逆向单添加
     */
    void addSingleCommit(CalcResultReward calcResultReward);

    /**
     * 批量
     * @param calcResultRewardList
     */
    void addBatchCommit(List<CalcResultReward> calcResultRewardList);


    /**q
     * 封装数据
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @return
     */
    CalcResultReward getPreObj(OrderCalcDto orderCalcDto, PlanDto planDto, String scene);

    /**
     * 扣减数据
     * @param calcResult
     * @param willSub
     * @return
     */
    CalcResultReward getCalcReward(CalcResult calcResult, String willSub);
}
