package com.gome.crp.calc.dto.problemDto;

import lombok.Data;

/**
 *
 */
@Data
public class ProblemDto {

    private String msgId; //msgId
    private String msg; //msg
    private String orderId; //订单ID
    private String channel; // 渠道编码
    private String skuNo; //skuNo
    private String detailId; //detailId
    private String planId; //计划id
    private String userId; // 用户id  部分为null
    private String staffCode; //员工编码  部分为null
    private String calcResultId; // 计算结果的id
    private String description; // 问题描述

    private ProblemDto() {
    }

    public ProblemDto(String msgId, String msg) {
        this.msgId = msgId;
        this.msg = msg;
    }

    public ProblemDto(String orderId, String channel, String skuNo, String detailId) {
        this.orderId = orderId;
        this.channel = channel;
        this.skuNo = skuNo;
        this.detailId = detailId;
    }

    public ProblemDto(String orderId) {
        this.orderId = orderId;
    }

}
