package com.gome.crp.calc.service.job.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.IsOnlineApplyBillEnum;
import com.gome.crp.calc.constants.IsReceiptGoodsEnum;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.service.job.IJobSapOnlineService;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class JobSapOnlineServiceImpl implements IJobSapOnlineService {
    private static final int PAGE_SIZE = 500;
    private static final int EXPIRE_HOURS = 3 * 30 * 24;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private IBillService iBillService;
    @Autowired
    private ICalcResultService iCalcResultService;

    @Override
    public void applyBill() {
        long startTime = System.currentTimeMillis();
        log.info("定时任务-sap线上记账执行开始");

        //幂等校验
        String cronJobSapOnlinePayLock = CacheKeyConstants.getCronJobSapOnlinePayBillLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJobSapOnlinePayLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobSapOnlinePayBillIdIndex = CacheKeyConstants.getCronJobSapOnlinePayBillIdIndex();
                long idIndex = selectIndexPosition(cronJobSapOnlinePayBillIdIndex);

                //查询PAGE_SIZE条数据（-1<jobStatus<4 && awardAmount>0 && budget_status==1）
                List<CalcResult> records = selectCalcResult(idIndex);

                //更新数据下次处理位置
                if (CollectionUtils.isEmpty(records) || records.size() < PAGE_SIZE) {
                    gcacheUtil.putKeyValue(cronJobSapOnlinePayBillIdIndex, "0");
                } else {
                    CalcResult detail = records.get(records.size() - 1);
                    gcacheUtil.putKeyValue(cronJobSapOnlinePayBillIdIndex, String.valueOf(detail.getId()));
                }

                if (!CollectionUtils.isEmpty(records)) {
                    List<CalcResult> applyPayCalcResultList = new ArrayList<>(records.size());
                    List<CalcResult> updateCalcResultList = new ArrayList<>(records.size());

                    for (CalcResult calcResult : records) {
                        //无函y场景，要等收货完成，才能在线上sap记账
                        if (validate(calcResult)) {
                            applyPayCalcResultList.add(calcResult);
                            CalcResult updateCalcResult = getUpdateCalcResult(calcResult);
                            updateCalcResultList.add(updateCalcResult);
                        }
                    }

                    if (!CollectionUtils.isEmpty(applyPayCalcResultList)) {
                        iBillService.applyPay(applyPayCalcResultList);
                        iCalcResultService.updateBatchById(updateCalcResultList);
                    }
                }
            }

            log.info("定时任务-sap线上记账处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-sap线上记账处理异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJobSapOnlinePayLock});
            } catch (Exception ex) {
                log.error("定时任务-删除sap线上记账防重键异常cronJobSapOnlinePayLock:{}", cronJobSapOnlinePayLock, ex);
            }
        }
    }

    private CalcResult getUpdateCalcResult(CalcResult calcResult) {
        CalcResult updateCalcResult = new CalcResult();
        updateCalcResult.setId(calcResult.getId());
        updateCalcResult.setIsOnlineApplyBill(IsOnlineApplyBillEnum.ALREADY_APPLY.getCode());
        return updateCalcResult;
    }

    private boolean validate(CalcResult calcResult) {
        if (BaseConstants.SCENE_Y.equals(calcResult.getScenes()) &&
                (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(calcResult.getContractType())
                        || BaseConstants.PLAN_SIGN_NO_LETTER_TYPE_SUPPLIER.equals(calcResult.getContractType()))
                && (calcResult.getIsReceiptGoods() == null || calcResult.getIsReceiptGoods() != IsReceiptGoodsEnum.ALREADY_RECEIPT.getCode())) {
            return false;
        }

        return true;
    }

    private long selectIndexPosition(String indexPositionKey) {
        long idIndex = 0L;
        String keyValue = gcacheUtil.getKeyValue(indexPositionKey);
        if (keyValue != null) {
            idIndex = Long.parseLong(keyValue);
        }
        return idIndex;
    }


    private List<CalcResult> selectCalcResult(Long idIndex) {
        //检测时间createTime（3个月以内）
        Date now = new Date();
        String startCreateTime = DateUtils.addDateMinut(now, -1 * EXPIRE_HOURS);

        Page<CalcResult> page = new Page<>();
        page.setSearchCount(false);
        page.setSize(PAGE_SIZE);

        CalcResult query = new CalcResult();
        query.setGomeStatus(BaseConstants.ORDER_DL_STATUS);
        query.setIsOnlineApplyBill(IsOnlineApplyBillEnum.NOT_HAVE_APPLY.getCode());
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
        queryWrapper.orderByAsc("id");
        queryWrapper.gt("id", idIndex);
        queryWrapper.gt("job_status", BaseConstants.CRD_JOB_STATUS_1_N);
        queryWrapper.lt("job_status", BaseConstants.CRD_JOB_STATUS_4);
        queryWrapper.eq("budget_status", BaseConstants.BUDGET_CHECK_SUCCESS);
        queryWrapper.isNotNull("award_amount");
        queryWrapper.gt("award_amount", 0);
        queryWrapper.gt("create_time", startCreateTime);

        Page<CalcResult> calcResultDetailPage = calcResultMapper.selectPage(page, queryWrapper);
        return calcResultDetailPage.getRecords();
    }

}
