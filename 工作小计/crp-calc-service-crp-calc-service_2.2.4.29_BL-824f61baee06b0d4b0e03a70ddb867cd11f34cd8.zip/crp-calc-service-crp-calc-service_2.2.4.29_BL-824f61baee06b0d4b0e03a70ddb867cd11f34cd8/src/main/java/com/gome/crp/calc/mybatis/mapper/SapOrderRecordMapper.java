package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.SapOrderRecord;

/**
 * sap下发订单消息表 Mapper
 * @author zhangshuang
 *
 */
public interface SapOrderRecordMapper extends BaseMapper<SapOrderRecord>{

}