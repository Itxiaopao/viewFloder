package com.gome.crp.calc.service.scene.formula;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.math.BigDecimal;

/**
 * 差异化公式计算
 */
public interface IFormulaCYH {

    // **********************************************************
    // 差异化
    // Logical:
    // 1. 厂家承担 + / + 优先级第一：11一步到位机 (厂家承担 + 优先级第二：流水倒扣合同（C005） + 目前生产上只支持：01标准机、02包销机，但不参与逻辑校验)
    // 2. 厂家承担 + 优先级第三：非流水倒扣合同 + /
    // 3. 国美预算 + 非净价合同 + 01标准机
    // 4. 国美预算 + 净价合同（C002\C004） + 01标准机 + 包销机的现综合利润率和原综合利润率的值为空，则不给提奖
    // 5. 国美预算 + 流水倒扣合同（C005） + 02包销机 + 包销机的现综合利润率和原综合利润率的值为空，则不给提奖
    // 6. 国美预算 + 非流水倒扣合同 + 02包销机
    // 7. 国美预算 + / + 11一步到位机 + 现综合利润率没有值
    // 8. 国美预算 + / + 11一步到位机 + 现综合利润率和原综合利润率有值
    //***********************************************************
    BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene);


}
