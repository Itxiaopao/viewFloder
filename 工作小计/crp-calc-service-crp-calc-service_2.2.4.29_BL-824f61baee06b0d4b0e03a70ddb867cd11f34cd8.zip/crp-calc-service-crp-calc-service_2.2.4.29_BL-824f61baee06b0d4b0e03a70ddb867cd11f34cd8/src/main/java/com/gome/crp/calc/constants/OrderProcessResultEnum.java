package com.gome.crp.calc.constants;

public enum OrderProcessResultEnum {
    EXISTS_MATCH_PLAN_AWARD(1, "存在匹配计划奖励"),
    NO_EXISTS_MATCH_PLAN_AWARD(2, "不存在匹配计划奖励"),

    ;

    private Integer code;
    private String msg;

    OrderProcessResultEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
