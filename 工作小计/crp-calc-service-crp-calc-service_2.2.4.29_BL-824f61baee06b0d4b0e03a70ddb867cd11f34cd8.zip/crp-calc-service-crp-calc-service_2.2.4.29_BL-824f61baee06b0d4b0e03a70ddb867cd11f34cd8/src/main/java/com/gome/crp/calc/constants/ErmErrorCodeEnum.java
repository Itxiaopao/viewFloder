package com.gome.crp.calc.constants;

public enum ErmErrorCodeEnum {
    CLOSE_PLAN_CODE_0(0, "正常"),
    CLOSE_PLAN_CODE_10001(10001, "计划类型不允许计算端停用"),
    CLOSE_PLAN_CODE_10002(10002, "相同状态不能修改"),
    CLOSE_PLAN_CODE_500(500, "系统异常"),

    RELEASE_BUDGET_CODE_0(0, "正常"),
    RELEASE_BUDGET_CODE_10001(10001, "计划类型不允许计算端执行回滚操作"),
    RELEASE_BUDGET_CODE_10003(10003, "预算回滚失败"),
    RELEASE_BUDGET_CODE_10004(10004, "未查询到占用流水号，不能进行回滚"),
    RELEASE_BUDGET_CODE_500(500, "系统异常"),

    ;

    private int code;
    private String msg;

    ErmErrorCodeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
