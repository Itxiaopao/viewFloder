package com.gome.crp.calc.constants;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.mybatis.model.CalcResult;

public class CacheKeyConstants {
    public static final int CACHE_KEY_TIMEOUT = 90 * 24 * 60 * 60; //key缓存到期时间,单位秒
    public static final int CACHE_KEY_CLEAN_TIMEOUT = 120; //缓存清理时间,单位秒
    private static final String ORDER_UNIQUE_KEY = "CALC:ORDER:UNIQUE_KEY:%s_%s_%s_%s_%s";//订单唯一键
    private static final String ORDER_PLAN_BENEFICIARY_UNIQUE_KEY = "CALC:ORDER:PLAN:BENEFICIARY:UNIQUE_KEY:%s_%s_%s_%s_%s_%s_%s_%s_%s";//订单计划收益人唯一键
    private static final String ORDER_DETAIL_LOCK = "CALC:ORDER:DETAIL:LOCK:%s_%s_%s_%s";//订单明细锁
    private static final String SAP_ORDER_UNIQUE_KEY = "CALC:SAP_ORDER:UNIQUE_KEY:%s";//sap订单唯一键
    private static final String SAP_ORDER_LOCK = "CALC:SAP_ORDER:LOCK:%s";//sap订单锁
    private static final String SAP_RESULT_UNIQUE_KEY = "CALC:SAP_RESULT:UNIQUE_KEY:%s_%s_%s_%s_%s_%s";//sap挂账唯一键
    private static final String SAP_RESULT_BILL_REPLY_UNIQUE_KEY = "CALC:SAP_RESULT:BILL_REPLY_UNIQUE_KEY:%s_%s_%s_%s_%s_%s";//sap挂账回复唯一键
    private static final String SAP_RESULT_RECEIPT_UNIQUE_KEY = "CALC:SAP_RESULT_RECEIPT:UNIQUE_KEY:%s_%s_%s_%s";//sap收货确认唯一键
    private static final String ERM_BUDGET_RELEASE_UNIQUE_KEY = "CALC:BUDGET_RELEASE:UNIQUE_KEY:%s";//erm计划预算释放唯一键
    private static final String CPQS_BUDGET_RELEASE_UNIQUE_KEY = "CALC:CPQS:BUDGET_RELEASE:UNIQUE_KEY:%s";//cpsq计划预算释放唯一键
    private static final String ERM_BUDGET_OCCUPY_UNIQUE_KEY = "CALC:BUDGET_OCCUPY:UNIQUE_KEY:%s";//计划预算占用唯一键
    private static final String CPQS_BUDGET_OCCUPY_UNIQUE_KEY = "CALC:CPQS:BUDGET_OCCUPY:UNIQUE_KEY:%s";//cpsq计划预算占用唯一键
    private static final String ERM_BUDGET_PLAN_ID_LOCK = "CALC:BUDGET:PLAN_ID:%s:LOCK";//计划预算占用释放锁
    private static final String CPQS_BUDGET_PLAN_ID_LOCK = "CALC:CPQS:BUDGET:PLAN_ID:%s:LOCK";//计划预算占用释放锁
    private static final String ERM_BUDGET_PLAN_ID_KEY = "CALC:BUDGET:%s";//计划预算资源池(erm系統维护)
    private static final String CPQS_BUDGET_PLAN_ID_KEY = "CALC:BUDGET:2:%s";//计划预算资源池(cpsq系統维护)
    private static final String CPQS_BUDGET_YX_PLAN_ID_KEY = "CALC:BUDGET:8:%s";//计划预算资源池(cpsq系統维护)
    private static final String ERM_CONTRACT_RELATION_KEY = "CALC:CONTRACT:RELATION_%s";//新合同号查询(erm系统维护)
    private static final String ERM_LETTER_KEY = "CALC:LETTER:%s:%s:%s:%s:%s:%s";//函信息查询(erm系统维护)
    private static final String CRON_JOB1_BUDGET_OCCUPY_LOCK = "CALC:CRON_JOB1:BUDGET_OCCUPY:LOCK";//定时任务-预算占用锁
    private static final String CRON_JOB2_BUDGET_OCCUPY_LOCK = "CALC:CRON_JOB2:BUDGET_OCCUPY:LOCK";//定时任务-预算占用锁
    private static final String CRON_JOB_BUDGET_OCCUPY_ID_INDEX = "CALC:CRON_JOB:BUDGET_OCCUPY:ID_INDEX"; //定时任务-预算占用,表数据处理位置
    private static final String CRON_JOB_SAP_COMPARE_LOCK = "CALC:CRON_JOB:SAP_COMPARE:LOCK";//定时任务-sap严控占用锁
    private static final String CRON_JOB_SAP_NO_COMPARE_LOCK = "CALC:CRON_JOB:SAP_NO_COMPARE:LOCK";//定时任务-sap不严控占用锁
    private static final String CRON_JOB_SAP_COMPARE_FOLLOW_UP_LOCK = "CALC:CRON_JOB:SAP_COMPARE_FOLLOW_UP:LOCK";//定时任务-sap严控后续处理占用锁
    private static final String CRON_JOB_SAP_COMPARE_2_0_OFFER_PRICE = "CALC:CRON_JOB:SAP_COMPARE:NO_DIFFERENT:EXPENSE_OFFER:OFFER_PRICE:%s";//非差异化供应商承担的供价的key，重复计算的时候需要此key
    private static final String CRON_JOB_SAP_COMPARE_ID_INDEX = "CALC:CRON_JOB:SAP_COMPARE:ID_INDEX"; //定时任务-sap严控,表数据处理位置
    private static final String CRON_JOB_SAP_NO_COMPARE_ID_INDEX = "CALC:CRON_JOB:SAP_NO_COMPARE:ID_INDEX"; //定时任务-sap不严控,表数据处理位置
    private static final String CRON_JOB_SAP_COMPARE_FOLLOW_UP_ID_INDEX = "CALC:CRON_JOB:SAP_COMPARE_FOLLOW_UP:ID_INDEX"; //定时任务-sap严控后续处理,表数据处理位置
    private static final String CRON_JOB_SAP_ONLINE_PAY_BILL_LOCK = "CALC:CRON_JOB:SAP_ONLINE:PAY_BILL:LOCK";//定时任务-线上sap记账
    private static final String CRON_JOB_SAP_ONLINE_PAY_BILL_ID_INDEX = "CALC:CRON_JOB:SAP_ONLINE:PAY_BILL:ID_INDEX";//定时任务-线上sap记账,表数据处理位置
    private static final String CRON_JOB_SAP_OFFLINE_APPLY_BILL_LOCK = "CALC:CRON_JOB:SAP_OFFLINE:APPLY_BILL:LOCK";//定时任务-线下sap挂账
    private static final String CRON_JOB_SAP_OFFLINE_APPLY_BILL_ID_INDEX = "CALC:CRON_JOB:SAP_OFFLINE:APPLY_BILL:ID_INDEX";//定时任务-线下sap挂账,表数据处理位置
    private static final String CRON_JOB_SEND_ACCOUNT_LOCK = "CALC:CRON_JOB:SEND_ACCOUNT:LOCK";//定时任务-正向单推送收入占用锁
    private static final String CRON_JOB_SEND_ACCOUNT_ID_INDEX = "CALC:CRON_JOB:SEND_ACCOUNT::ID_INDEX";//定时任务-正向单推送收入，表数据处理位置
    private static final String PLAN_SKU_SALEMODEL_KEY = "CALC:PLAN:%s:%s";//sku加salemodel获取计划key
    private static final String PLAN_CAT_BRANDCODE_KEY = "CALC:PLAN:%s:%s";//品类加品牌获取计划key
    private static final String PLAN_ID_KEY = "CALC:PLAN:%s";//根据计划id获得缓存的计划信息
    private static final String PLAN_SPECIAL_SKU_KEY = "CALC:SCENE:Y:SPECIAL:%s";//拓客特例品key
    private static final String PLAN_SPECIAL_SKU_VALUE = "%s:%s";//特例品的key拼接
    private static final String SCENEY_REPEAT_KEY = "CALC:SCENE:Y:%s:%s:%s";//Y场景 一个计划只能匹配一个订单
    private static final String SCENEY_DISTRIBUTED_KEY = "CALC:SCENE:Y:%s";//Y场景 分布式锁
    private static final String CALC_RETRY_TASK_LOCK_KEY = "CALC_RETRY_MANAGER#SCAN:KEY_%s";    // 重推计划扫描key, pageNo
    private static final String CALC_MSG_SEND_EMAIL_LOCK_KEY = "CALC:MSG:SEND:EMAIL:%s";    // 邮件发送业务锁
    private static final String CALC_15_PERCENT_INDEX_KEY = "CALC:15:PERCENT:INDEX";    // 15%游标
    private static final String CALC_CONTRACT_INDEX_KEY = "CALC:CONTRACT::INDEX:%s";    // 合同消息幂等
    private static final String CALC_MSG_SEND_WECHAT_LOCK_KEY = "CALC:MSG:SEND:WECHAT:%s";    // 邮件发送业务锁


    public static String getOrderUniqueKey(OrderCalcDto orderCalcDto) {
        String detailId = orderCalcDto.getDetailId();
        if (BaseConstants.ORDER_RCO_STATUS.equals(orderCalcDto.getGomeState())) {
            detailId = detailId + "_" + orderCalcDto.getReturnOrderId();//detailId+退货单号
        }

        return String.format(ORDER_UNIQUE_KEY,
                orderCalcDto.getOrderId(),
                orderCalcDto.getChannel(),
                orderCalcDto.getGomeState(),
                orderCalcDto.getSkuNo(),
                detailId);
    }

    public static String getOrderDetailLock(String orderId, String channel, String skuNo, String detailId) {
        return String.format(ORDER_DETAIL_LOCK, orderId, channel, skuNo, detailId);
    }

    public static String getOrderPlanBeneficiaryUniqueKey(CalcResult calcResult) {
        return String.format(ORDER_PLAN_BENEFICIARY_UNIQUE_KEY,
                calcResult.getOrderId(),
                calcResult.getChannel(),
                calcResult.getGomeStatus(),
                calcResult.getSkuNo(),
                calcResult.getDetailId(),
                calcResult.getPlanId(),
                calcResult.getScenes(),
                calcResult.getStaffCode(),
                calcResult.getUserId());
    }

    public static String getCalcRetryTaskLockKey(String keyword) {
        return String.format(CALC_RETRY_TASK_LOCK_KEY, keyword);
    }

    public static String getSapOrderUniqueKey(String messageId) {
        return String.format(SAP_ORDER_UNIQUE_KEY, messageId);
    }

    public static String getSapRecordUniqueKey(String tcjh, String flag1, String bstkd, String qxbs, String matnr, String pernr) {
        return String.format(SAP_RESULT_UNIQUE_KEY, tcjh, flag1, bstkd, qxbs, matnr, pernr);
    }

    public static String getSapRecordBillReplyUniqueKey(String tcjh, String flag1, String bstkd, String qxbs, String matnr, String pernr) {
        return String.format(SAP_RESULT_BILL_REPLY_UNIQUE_KEY, tcjh, flag1, bstkd, qxbs, matnr, pernr);
    }

    public static String getSapRecordLock(String bstkd) {
        return String.format(SAP_ORDER_LOCK, bstkd);
    }

    public static String getSapRecordReceiptUniqueKey(String ebeln, String belnr, String shkzg, String elikz) {
        return String.format(SAP_RESULT_RECEIPT_UNIQUE_KEY, ebeln, belnr, shkzg, elikz);
    }

    public static String getErmPlanBudgetKey(String planId) {
        return String.format(ERM_BUDGET_PLAN_ID_KEY, planId);
    }

    public static String getCpqsPlanBudgetKey(String planId) {
        return String.format(CPQS_BUDGET_PLAN_ID_KEY, planId);
    }

    public static String getSpecialSkuKey(String planId) {
        return String.format(PLAN_SPECIAL_SKU_KEY, planId);
    }

    public static String getPlanSpecialSkuKey(String salesModel, String skuId) {
        return String.format(PLAN_SPECIAL_SKU_VALUE, salesModel, skuId);
    }

    public static String getErmPlanBudgetLock(String planId) {
        return String.format(ERM_BUDGET_PLAN_ID_LOCK, planId);
    }

    public static String getCpqsPlanBudgetLock(String planId) {
        return String.format(CPQS_BUDGET_PLAN_ID_LOCK, planId);
    }

    public static String getErmBudgetReleaseUniqueKey(String messageId) {
        return String.format(ERM_BUDGET_RELEASE_UNIQUE_KEY, messageId);
    }

    public static String getCpqsBudgetReleaseUniqueKey(String messageId) {
        return String.format(CPQS_BUDGET_RELEASE_UNIQUE_KEY, messageId);
    }


    public static String getErmBudgetOccupyUniqueKey(String messageId) {
        return String.format(ERM_BUDGET_OCCUPY_UNIQUE_KEY, messageId);
    }

    public static String getCpqsBudgetOccupyUniqueKey(String messageId) {
        return String.format(CPQS_BUDGET_OCCUPY_UNIQUE_KEY, messageId);
    }

    public static String getErmContractRelationKey(String contractCode) {
        return String.format(ERM_CONTRACT_RELATION_KEY, contractCode);
    }

    /**
     * 函信息key
     *
     * @param conno 合同编号
     * @param ekorg 函采购组织
     * @param lifnr 供应商
     * @param docty 函类型（主推函（ZB00)，确认函（ZC09)）
     * @param matnr 商品编码 9位
     * @param yewjx 业务机型
     * @return
     */
    public static String getErmLetterKey(String conno, String ekorg, String lifnr, String docty, String matnr, String yewjx) {
        return String.format(ERM_LETTER_KEY, conno, ekorg, lifnr, docty, matnr, yewjx);
    }

    public static String getCronJob1BudgetOccupyLock() {
        return CRON_JOB1_BUDGET_OCCUPY_LOCK;
    }

    public static String getCronJob2BudgetOccupyLock() {
        return CRON_JOB2_BUDGET_OCCUPY_LOCK;
    }

    public static String getCronJobSapCompareLock() {
        return CRON_JOB_SAP_COMPARE_LOCK;
    }

    public static String getCronJobSapCompareFollowUpLock() {
        return CRON_JOB_SAP_COMPARE_FOLLOW_UP_LOCK;
    }

    public static String getCronJobSapNoCompareLock() {
        return CRON_JOB_SAP_NO_COMPARE_LOCK;
    }

    public static String getCronJobBudgetOccupyIdIndex() {
        return CRON_JOB_BUDGET_OCCUPY_ID_INDEX;
    }

    public static String getCronJobSapCompareIdIndex() {
        return CRON_JOB_SAP_COMPARE_ID_INDEX;
    }

    public static String getCronJobSapCompareFollowUpIdIndex() {
        return CRON_JOB_SAP_COMPARE_FOLLOW_UP_ID_INDEX;
    }

    public static String getCronJobSapNoCompareIdIndex() {
        return CRON_JOB_SAP_NO_COMPARE_ID_INDEX;
    }

    public static String getCronJobSapOnlinePayBillLock() {
        return CRON_JOB_SAP_ONLINE_PAY_BILL_LOCK;
    }

    public static String getCronJobSapOnlinePayBillIdIndex() {
        return CRON_JOB_SAP_ONLINE_PAY_BILL_ID_INDEX;
    }

    public static String getCronJobSapOfflineApplyBillLock() {
        return CRON_JOB_SAP_OFFLINE_APPLY_BILL_LOCK;
    }

    public static String getCronJobSapOfflineApplyBillIdIndex() {
        return CRON_JOB_SAP_OFFLINE_APPLY_BILL_ID_INDEX;
    }

    public static String getPlanOfSkuSaleModel(String sku, String saleModel) {
        return String.format(PLAN_SKU_SALEMODEL_KEY, sku, saleModel);
    }

    public static String getPlanOfCatBrand(String cat, String brandCode) {
        return String.format(PLAN_CAT_BRANDCODE_KEY, cat, brandCode);
    }

    public static String getPlanById(String planId) {
        return String.format(PLAN_ID_KEY, planId);
    }

    public static String getKeyOfSceneYRepeat(String orderId, String detailId, String planId) {
        return String.format(SCENEY_REPEAT_KEY, orderId, detailId, planId);
    }

    public static String getKeyOfDistributed(String key) {
        return String.format(SCENEY_DISTRIBUTED_KEY, key);
    }

    public static String getCronJobSapCompare20OfferPrice(Long resultId) {
        return String.format(CRON_JOB_SAP_COMPARE_2_0_OFFER_PRICE, resultId);
    }

    public static String getEmailMsgSendLock(String lockType) {
        return String.format(CALC_MSG_SEND_EMAIL_LOCK_KEY, lockType);
    }

    public static String get15PercentIndexKey() {
        return String.format(CALC_15_PERCENT_INDEX_KEY);
    }

    public static String getCronJobSendAccountLock() {
        return CRON_JOB_SEND_ACCOUNT_LOCK;
    }

    public static String getCronJobSendAccountIdIndex() {
        return CRON_JOB_SEND_ACCOUNT_ID_INDEX;
    }

    public static String getContractIndex(String sapDetailId) {
        return String.format(CALC_CONTRACT_INDEX_KEY, sapDetailId);
    }

    public static String getWeChatMsgSendLock(String lockType) {
    	return String.format(CALC_MSG_SEND_WECHAT_LOCK_KEY, lockType);
    }
    
    public static String getCpqsYxPlanBudgetKey(String planId) {
        return String.format(CPQS_BUDGET_YX_PLAN_ID_KEY, planId);
    }
}
