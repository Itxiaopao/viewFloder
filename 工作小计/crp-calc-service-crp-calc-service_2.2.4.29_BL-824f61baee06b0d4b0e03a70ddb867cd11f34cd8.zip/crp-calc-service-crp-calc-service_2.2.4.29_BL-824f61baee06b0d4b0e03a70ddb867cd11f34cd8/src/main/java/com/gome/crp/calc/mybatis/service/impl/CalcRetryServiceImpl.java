package com.gome.crp.calc.mybatis.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcRetryMapper;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.mybatis.service.ICalcRetryService;
import org.springframework.stereotype.Service;

@Service
public class CalcRetryServiceImpl extends ServiceImpl<CalcRetryMapper, CalcRetry> implements ICalcRetryService {
}
