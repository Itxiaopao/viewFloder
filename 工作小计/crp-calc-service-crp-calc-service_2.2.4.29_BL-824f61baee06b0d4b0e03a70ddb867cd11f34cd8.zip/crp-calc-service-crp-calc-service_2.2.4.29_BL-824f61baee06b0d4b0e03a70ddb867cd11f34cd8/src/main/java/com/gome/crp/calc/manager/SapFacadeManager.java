package com.gome.crp.calc.manager;

import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.gome.crp.calc.mybatis.mapper.SapOrderRecordMapper;
import com.gome.crp.calc.mybatis.model.SapOrderRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class SapFacadeManager {
    @Autowired
    private SapOrderRecordMapper SapOrderRecordMapper;

    @Transactional
    public void doSaveSyncOrder(SapOrderRecord updateSapOrderRecord, UpdateWrapper<SapOrderRecord> updateSapOrderRecordWrapper, SapOrderRecord insertSapOrderRecord) {
        SapOrderRecordMapper.update(updateSapOrderRecord, updateSapOrderRecordWrapper);
        SapOrderRecordMapper.insert(insertSapOrderRecord);
    }

    @Transactional
    public void doSaveSyncOrder(SapOrderRecord insertSapOrderRecord) {
        SapOrderRecordMapper.insert(insertSapOrderRecord);
    }
}
