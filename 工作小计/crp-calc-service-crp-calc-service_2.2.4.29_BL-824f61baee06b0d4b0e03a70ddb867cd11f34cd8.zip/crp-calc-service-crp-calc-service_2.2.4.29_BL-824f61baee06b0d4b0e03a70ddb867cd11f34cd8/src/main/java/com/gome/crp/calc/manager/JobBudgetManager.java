package com.gome.crp.calc.manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.service.ICalcResultService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class JobBudgetManager {
    @Autowired
    private ICalcResultService iCalcResultService;

    @Transactional
    public void doUpdateCalcResultStatus(List<CalcResult> calcResults) {
    	log.info("定时任务-更新占用预算处理, calcResults:{}", calcResults);
        if (CollectionUtils.isNotEmpty(calcResults)) {
            boolean result = iCalcResultService.updateBatchById(calcResults);
            if (!result) {
                log.error("定时任务-占用预算处理失败calcResults:{}", calcResults);
                throw new BusinessException(String.format("定时任务-占用预算处理失败calcResults:%s", JSON.toJSONString(calcResults)));
            }
        }
    }
    
}
