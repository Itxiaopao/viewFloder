package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcRecord;

/**
 * @author zhangshuang
 *
 */
public interface CalcRecordMapper extends BaseMapper<CalcRecord>{

}