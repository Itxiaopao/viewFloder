package com.gome.crp.calc.mq;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.gome.crp.calc.mq.consumer.CalContractMsgConsumer;
import com.gome.crp.calc.mq.consumer.OrderMsgConsumer;
import com.gome.crp.calc.mq.consumer.SapAccountConsumer;
import com.gome.crp.calc.util.SpringDynamicBeanFactoryUtil;
import com.gome.diamond.listen.DiamondListen;

/**
 * Diamond MQ consumer开关监听
 * @author lisuo
 *
 */
@Component
public class DiamondMqConsumerSwitchListen implements DiamondListen {
	
	@Autowired
	private ApplicationContext applicationContext;
	
	//MQConsumer键值对开关列表，key是diamond中配置的mq开关的key
	private Map<String,Class<?>> mqConsumerMap = new HashMap<>();
	
	public DiamondMqConsumerSwitchListen() {
		mqConsumerMap.put("cal_contract_msg_consumer_on", CalContractMsgConsumer.class);
		mqConsumerMap.put("order_msg_consumer_on", OrderMsgConsumer.class);
		mqConsumerMap.put("sap_account_consumer_on", SapAccountConsumer.class);
	}

	/**
	 * diamond配置变化监听
	 * @param key dianmond中的key
	 * @param oldValue diamond的value,第一次启动没值
	 * @param newValue diamond的最新value
	 */
	@Override
	public void listen(String key, String oldValue, String newValue) {
		if(mqConsumerMap.containsKey(key)){
			Class<?> clazz = mqConsumerMap.get(key);
			String beanName  = toLowerCaseFirstOne(clazz.getSimpleName());
			//1：mq启用状态,其它值表示销毁mq,默认调用mq的shutdown方法
			if("1".equals(newValue)){
				SpringDynamicBeanFactoryUtil.addBean(clazz, beanName, applicationContext);
			}else{
				SpringDynamicBeanFactoryUtil.removeBean(beanName, applicationContext);
			}
		}
	}
	
	/**
     * 首字母转小写
     * @param s
     * @return
     */
    private String toLowerCaseFirstOne(String s){
        if(Character.isLowerCase(s.charAt(0)))
            return s;
        else{
        	return Character.isLowerCase(s.charAt(0)) ? s : Character.toLowerCase(s.charAt(0)) + s.substring(1);
        }
    }
    
}
