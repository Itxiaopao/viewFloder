package com.gome.crp.calc.service.scene.formula.impl;


import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.formula.IFormulaFCYH;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Slf4j
@Service
public class FormulaFCYH implements IFormulaFCYH {

    @Autowired
    private SceneUtils sceneUtils;
    @Autowired
    private ICalcRewardsService calcRewardsService;

    //百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);
    private static BigDecimal percent_rate_cent_1 = BigDecimal.valueOf(1.0);

    // 非差异化
    private BigDecimal formulaFCYH(OrderCalcDto orderCalcDto, PlanDto planDto, String scene)  {
        String orderId = orderCalcDto.getOrderId();
        Long planId = planDto.getPlanId();
        String log_pre = String.format("订单: %s, 计划: %s, 场景: %s", orderId, planId, scene);

        BigDecimal ret = BigDecimal.valueOf(0.0);
        // 单台促销费 singleStandardMoney
        Long sigProPrice = planDto.getSingleStandardMoney();
        Assert.notNull(sigProPrice, log_pre + "非差异化计算-单台促销费: null");
        Integer buyNum = orderCalcDto.getBuyNum();
        BigDecimal sceneValue = sceneUtils.getSceneValue(planDto, scene);
        // 提奖金额=单台促消费×销售数量×XYZM比例
        ret = BigDecimal.valueOf(buyNum)
                .multiply(BigDecimal.valueOf(sigProPrice).multiply(percent_rate_normal))
                .multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);

        String logs = String.format("差异化-提奖金额[ %s ]=单台促消费[ %s x 0.01 ]×销售数量[ %s ]×(%s)比例[ %s x 0.01 ], target: [ %s ]"
                , ret, sigProPrice, buyNum, scene, sceneValue, log_pre);
        log.info(logs);
        ret = ret.multiply(percent_rate_cent).setScale(2, RoundingMode.DOWN);   // 转换成分, 保留两位小数
//        // --------------------------------save reward----------------------------------
//        CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//        crr.setReward(ret.toString());
//        crr.setCalcFormulaLog(logs);
//        crr.setCalcFormulaStr("非差异化-提奖金额=单台促消费×销售数量×XYZM比例");
//        savePreRewards(crr);
//        // --------------------------------save reward----------------------------------

        return ret;
    }

    @Override
    public BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        return this.formulaFCYH(orderCalcDto, planDto, scene);
    }
}
