package com.gome.crp.calc.mybatis.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class CalcRecord {
	@TableId(type = IdType.INPUT)
	private Long id; //id
	private String orderId; //订单号
	private String deliveryId; //配送单号
	private String gomeStatus; //订单状态
	private String detailId; //订单detail_id
	private String skuNo; //skuno
	private String sapDetailId; //sapDetailId
	private String returnOrderId; //售后单号（正向为空，逆向有值）
	private Long award; //奖励金额（单位：分）
	private Long buyNum; //购买数量
	private String calcResultId; //计算履历结果标识
	private Date createTime; //createTime
	private Date updateTime; //updateTime
	private Date orderSubmitTime; //orderSubmitTime
	private Date orderDate; //orderDate
	private String channel; //订单渠道
	private String remark;//描述信息
}