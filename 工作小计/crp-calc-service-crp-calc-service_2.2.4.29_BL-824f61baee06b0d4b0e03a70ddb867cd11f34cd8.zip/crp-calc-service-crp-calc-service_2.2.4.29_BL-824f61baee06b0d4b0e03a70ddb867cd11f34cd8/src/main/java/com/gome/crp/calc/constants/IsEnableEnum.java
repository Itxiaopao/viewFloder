package com.gome.crp.calc.constants;

/**
 * 是否启用
 */
public enum IsEnableEnum {
    YES(1, "启用"),
    NO(0, "禁止"),

    ;

    private int code;
    private String msg;

    IsEnableEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
