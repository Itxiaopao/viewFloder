package com.gome.crp.calc.service.retry.cope.impl;

import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.mq.core.producer.MQSendResult;
import com.gome.crp.calc.mq.producer.SendBigDataProducerProcessImpl;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class RetryBigdateService implements IRetrySceneService {

    @Autowired
    private SendBigDataProducerProcessImpl sendBigDataProducerProcess;
    private static String service_name = RetryJobEnum.BIGDATACALC.getMsg();

    @Override
    public boolean cope(CalcRetry calcRetry) {
        boolean boo = retrySendBigDataCalc(calcRetry);
        log.info(String.format("提成计算推送结果, 重推类型:%s, retryId:%s, 处理结果: %b", service_name, calcRetry.getId(), boo));
        return boo;
    }


        /**
     * 提成计算推送大数据失败
     *
     * @param calcRetry
     * @return true:处理成功 false:处理失败
     */
    private boolean retrySendBigDataCalc(CalcRetry calcRetry) {
        boolean boo = false;
        try {
            Integer type = calcRetry.getType();
            if (type == RetryJobEnum.BIGDATACALC.getCode()) {
                log.info("提成计算推送大数据失败，准备重推...");
                MQSendResult mqSendResult = sendBigDataProducerProcess.syncSendBigData(calcRetry.getMsgBody());
                boo = mqSendResult.isSendSuccess();
            }
        } catch (Exception e) {
            log.error("提成推送大数据，失败重推仍然失败", e);
        }
        log.info(String.format("提成计算推送大数据失败>>END, retryId:%s", calcRetry.getId()));
        return boo;
    }


}
