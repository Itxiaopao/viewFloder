package com.gome.crp.calc.dto.ermDto;

import lombok.Data;

@Data
public class OccupyBudgetResDto {
    /**
     * 剩余预算金额
     */
    private Long surplusAmount;
}
