package com.gome.crp.calc.dto.billDto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * 入账推送mq
 */
@Getter
@Setter
@ToString
public class EnrollBillMQDto implements Serializable {

    private String key; // 幂等key 提成系统：account:crp:提成计算结果表ID（crp_calc_result）
    private Integer rebateType; // 返利类型，根据场景做转换 SCENE-Y = 43    SCENE-Z = 44,   SCENE-M = 45
    private Byte itemSource;    // 商品来源，默认：2，暂不需要传
    private String orderId;     //订单号
    private String skuId;
    private String skuNo;
    private String userId;      // 获利人userID
    private Long amount;        // 	获利金额（单位：分）
    private String merchantId;  //  联营商家ID，目前自营默认：888，暂不需要传
    private String childGomeId; // 下单人userID
    private Date rebateTime;    // 返利到账时间，已入账需要，待入账、已失效不需要传
    private Date orderCreateTime;   // 订单提交时间
    private Date createTime;        //  数据推送时间
    private String skuName;         //  商品名称
    private Integer status;         // 订单状态 ，根据订单状态做转换 CO = 1 DL = 5 CL = 2 RT = 3  RCO = 6（包括发放后扣减）
    private Integer accountType;    // 入账类型, 1、待入账 2、已入账 3、已失效
    private Integer level;      // 分享层级，默认：1，暂不需要传


}
