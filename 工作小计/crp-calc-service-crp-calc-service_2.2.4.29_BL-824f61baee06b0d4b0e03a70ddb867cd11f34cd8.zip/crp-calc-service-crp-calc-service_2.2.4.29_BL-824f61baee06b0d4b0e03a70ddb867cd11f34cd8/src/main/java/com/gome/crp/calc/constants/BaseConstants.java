package com.gome.crp.calc.constants;

import java.math.BigDecimal;

public class BaseConstants {
    /** 计算模块根据订单计算的标识 */
    public static final String CALC_CONSTANT_ORDER = "calc_constatnt_order";

    /***********************************************订单信息*******************************************/
    /** 配送单生效 */
    public static final String ORDER_CO_STATUS = "CO";
    /** 配送单已妥投 */
    public static final String ORDER_DL_STATUS = "DL";
    /** 订单已取消 */
    public static final String ORDER_CL_STATUS = "CL";
    /** 配送单拒收入库 */
    public static final String ORDER_RT_STATUS = "RT";
    /** 退货审核完成 */
    public static final String ORDER_RCO_STATUS = "RCO";
    /** 渠道编码：10金立渠道 */
    public static final String ORDER_CHANNEL_JINLI = "10";
    /** 渠道编码：13美店渠道  */
    public static final String ORDER_CHANNEL_MEIDIAN = "13";
    /** 渠道编码：16一店一页 */
    public static final String ORDER_CHANNEL_YDYY = "16";
    /** 渠道编码：60线上 */
    public static final String ORDER_CHANNEL_ONLINE = "60";
    /** 渠道编码：12 O2O*/
    public static final String ORDER_CHANNEL_O2O = "12";
    /** 订单中，ctx 获得应用信息的 key */
    public static final String ORDER_APPLICATION = "app";
    /** 订单中，ctx 获得应用信息为：商城 */
    public static final String ORDER_APPLICATION_SHANGCHENG = "shangcheng";
    /** 订单中，ctx 获得应用信息为：来购 */
    public static final String ORDER_APPLICATION_LAIGOU = "laigou";
    /** 订单中，ctx 获得应用信息为：金立 */
    public static final String ORDER_APPLICATION_JINLI = "jinli";
    /** 订单中，shopType类型：线下实体店 */
    public static final String ORDER_SHOPTYPE_PSHOP = "pshop";
    /** 订单中，shopType类型：线下加盟店*/
    public static final String ORDER_SHOPTYPE_ASHOP = "ashop";
    /** 订单中，shopType类型：商城的自营旗舰店*/
    public static final String ORDER_SHOPTYPE_FSHOP = "fshop";
    /** 订单中，goodsType标识：1：主商品，2：赠品*/
    public static final String ORDER_GOODS_TYPE_MAIN = "1";
    /** 订单中，goodsType标识：2：赠品*/
    public static final String ORDER_GOODS_TYPE_GIFT = "2";
    /** 订单中，goodsType标识：3：延保*/
    public static final String ORDER_GOODS_TYPE_YB = "3";
    /** 订单中，linshika*/
    public static final String ORDER_PROFILE_LINSHIKA = "linShiKa";
    /**延保支持商品 1 为延保  0 不是延保*/
    public static final int ORDER_YB_WARRANTY_FLAG_1 = 1;
    public static final int ORDER_YB_WARRANTY_FLAG_0 = 0;

    /**延保业务机型默认值*/
    public static final String ORDER_YB_SALE_MODEL = "YBSALEMODEL";
    /**延保的默认供应商*/
    public static final String ORDER_YB_SUPPLIER = "0010043697";
    /**是否营销推广 1是  0否*/
    public static final int ORDER_YX_STATUS_1 = 1;
    public static final int ORDER_YX_STATUS_0 = 0;

    /***********************************************计划相关信息*******************************************/
    /** 提成计算，计划有效状态：3有效 */
    public static final String PLAN_CALC_EFFECT = "3";
    /** 计划(促销费)类型,0:无促 */
    public static final String PLAN_NO_RROMOTION_TYPE = "0";
    /** 计划(促销费)类型,1:差异化 */
    public static final String PLAN_DIFFERENT_TYPE = "1";
    /** 计划(促销费)类型,2:非差异化*/
    public static final String PLAN_NO_DIFFERENT_TYPE = "2";
    /** 计划(促销费)类型,3:带单*/
    public static final String PLAN_REPLACE_TYPE = "3";
    /** 计划(促销费)类型,4:总额*/
    public static final String PLAN_TOTAL_TYPE = "4";
    /** 计划(促销费)类型,5:拓客*/
    public static final String PLAN_INVITE_GUEST_TYPE = "5";
    /** 计划(促销费)类型,7:延保*/
    public static final String PLAN_PROLONG_ASSURE_TYPE = "7";
    /** 计划(促销费)类型,12:O2O*/
    public static final String PLAN_O2O_TYPE = "12";
    /** 计划(促销费)类型,8:营销推广*/
    public static final String PLAN_MARKETING_PROMOTION_TYPE = "8";

    /** 签约类型 0:无签约类型*/
    public static final String PLAN_SIGN_NO_TYPE = "0";
    /** 签约类型 1:合同*/
    public static final String PLAN_SIGN_CONTRACT_TYPE = "1";
    /** 签约类型 2:合同+协议*/
    public static final String PLAN_SIGN_PROTOCOL_TYPE = "2";
    /** 签约类型 3:合同+有函*/
    public static final String PLAN_SIGN_LETTER_TYPE = "3";
    /** 签约类型 4:合同+无函资源池*/
    public static final String PLAN_SIGN_NO_LETTER_TYPE = "4";
    /** 签约类型 5:无函资源池*/
    public static final String PLAN_SIGN_NO_LETTER_TYPE_SUPPLIER = "5";
    /** 费用承担方 0:供应商承担-厂家承担*/
    public static final String PLAN_EXPENSE_OFFER_ZERO_TYPE = "0";
    /** 费用承担方 1:国美承担*/
    public static final String PLAN_EXPENSE_OFFER_ONE_TYPE = "1";
    /** 费用承担方 2:国美预算*/
    public static final String PLAN_EXPENSE_OFFER_TWO_TYPE = "2";
    /** 费用承担方 3:营销预算*/
    public static final String PLAN_EXPENSE_OFFER_THIRD_TYPE = "3";
    /** 是否厂家承担 0:国美承担*/
    public static final int PLAN_IS_GOME_OFFER_Y = 0;
    /** 是否厂家承担 1:厂家承担*/
    public static final int PLAN_IS_GOME_OFFER_N = 1;
    /** 政策编码 :605*/
    public static final String PLAN_EXTRA_POLICY_CODE_605 = "Z605";
    /** 政策编码 :195*/
    public static final String PLAN_EXTRA_POLICY_CODE_195 = "Z195";
    /** 政策编码 :197*/
    public static final String PLAN_EXTRA_POLICY_CODE_197 = "Z197";
    /** 政策编码 :Z002*/
    public static final String PLAN_EXTRA_POLICY_CODE_002 = "Z002";
    /** 政策编码 :Z001*/
    public static final String PLAN_EXTRA_POLICY_CODE_001 = "Z001";
    /**provisionType 计提基数（0销售金额）*/
    public static final int PLAN_PROVISION_SELL = 0;
    /**provisionType 计提基数（1实付金额）*/
    public static final int PLAN_PROVISION_REAL = 1;
    /**royaltyType 0.比例*/
    public static final int PLAN_ROYALTY_TYPE_RATE = 0;
    /**royaltyType 1.固额*/
    public static final int PLAN_ROYALTY_TYPE_STATION = 1;
    /** 提成计算，渠道编码：全部 */
    public static final String PLAN_ORDER_CHANNEL_CALC_ALL = "0";
    /** 提成计算，渠道编码：1线下 */
    public static final String PLAN_ORDER_CHANNEL_CALC_OFFLINE = "1";
    /** 提成计算，渠道编码：2一店一页 */
    public static final String PLAN_ORDER_CHANNEL_CALC_YDYE = "2";
    /** 提成计算，渠道编码：3线上 线上商城*/
    public static final String PLAN_ORDER_CHANNEL_CALC_ONLINE = "3";
    /** 提成计算，渠道编码：12 o2o*/
    public static final String PLAN_ORDER_CHANNEL_CALC_O2O = "12";
    /** 计划配置，全国编码：11010000 */
    public static final String PLAN_ALL_COUNTRY_CODE = "11010000";
    /** 是否A卖A 是*/
    public static final int PLAN_IS_A_SELL_A_Y = 0;
    /** 是否A卖A 否*/
    public static final int PLAN_IS_A_SELL_A_N = 1;
    /**默认key*/
    public static final String PLAN_DEFAULT_PREFIX_KEY = "-1";
    /**特例品业务机型  拓客只支持01正常机、02包销机、05特价机、09样机、11一步到位价、17单店协议机*/
    public static final String PLAN_DEFAULT_SPECIAL_SALEMODEL = "01-02-05-09-11-17";
    /**是否存在特例品标识*/
    public static final int PLAN_MATCH_HAS_SPECIAL_SKU = 0;
    /**总部staff_level*/
    public static final int PLAN_MATCH_STAFF_LEVEL_0 = 0;
    /**总部staff_level*/
    public static final int PLAN_MATCH_STAFF_LEVEL_2 = 2;
    /**总部staff_level*/
    public static final int PLAN_MATCH_STAFF_LEVEL_3 = 3;
    /***********************************************计算场景*******************************************/
    /**X场景*/
    public static final String SCENE_X = "SCENE-X";
    /**Y场景*/
    public static final String SCENE_Y = "SCENE-Y";
    /**Z场景*/
    public static final String SCENE_Z = "SCENE-Z";
    /**M场景*/
    public static final String SCENE_M = "SCENE-M";


    /***********************************************获利人员信息*******************************************/
    /**A:正式员工*/
    public static final String EMPL_CLASS_A = "A";
    /**B:劳务派遣*/
    public static final String EMPL_CLASS_B = "B";
    /**C:临时工*/
    public static final String EMPL_CLASS_C = "C";
    /**D:促销员*/
    public static final String EMPL_CLASS_D = "D";
    /**E:实习生*/
    public static final String EMPL_CLASS_E = "E";
    /**F:退休返聘*/
    public static final String EMPL_CLASS_F = "F";
    /**G:挂靠残疾人*/
    public static final String EMPL_CLASS_G = "G";
    /**H:劳务用工*/
    public static final String EMPL_CLASS_H = "H";
    /**I:加盟商员工*/
    public static final String EMPL_CLASS_I = "I";
    /**J:加盟商促销员*/
    public static final String EMPL_CLASS_J = "J";
	/**0.集团*/
	public static final int STAFF_LEVEL_0 = 0;
	/**1.大区*/
	public static final int STAFF_LEVEL_1 = 1;
	/**2.一级分部*/
	public static final int STAFF_LEVEL_2 = 2;
	/**3.二级分部*/
	public static final int STAFF_LEVEL_3 = 3;
	/**4. 门店*/
	public static final int STAFF_LEVEL_4 = 4;
	/**5.DC*/
	public static final int STAFF_LEVEL_5 = 5;
	/**6.售后*/
	public static final int STAFF_LEVEL_6 = 6;
	/**7.异常*/
	public static final int STAFF_LEVEL_7 = 7;
	/**1:主营 STR*/
	public static final String IS_MAIN_STR_Y = "1";
	/**2:兼营 STR*/
	public static final String IS_MAIN_STR_N = "2";
	/**1:主营 INT*/
	public static final int IS_MAIN_INT_Y = 1;
	/**2:兼营 INT*/
	public static final int IS_MAIN_INT_N = 2;


    /***********************************************job节点*******************************************/
	//CalcResultDetail.AwardStatus # 发放状态（-2：y场景特殊状态，-1:初始状态，0：冻结，1：未拉取账单，2：已拉取账单，3：失效）
    /**-2:Y初始状态，  CalcResultDetail.AwardStatus*/
    public static final int CRD_JOB_STATUS_SCENE_Y = -2;
	/**-1:初始状态，  CalcResultDetail.AwardStatus*/
	public static final int CRD_JOB_STATUS_1_N = -1;
	/**1：sap严控， CalcResultDetail.AwardStatus*/
    public static final int CRD_JOB_STATUS_0 = 0;
	/**1：预算校验， CalcResultDetail.AwardStatus*/
    public static final int CRD_JOB_STATUS_1 = 1;
	/**1：待拉取账单， CalcResultDetail.AwardStatus*/
	public static final int CRD_JOB_STATUS_2 = 2;
	/**2：已拉取账单， CalcResultDetail.AwardStatus*/
	public static final int CRD_JOB_STATUS_3 = 3;
	/**3：失效 ， CalcResultDetail.AwardStatus*/
	public static final int CRD_JOB_STATUS_4 = 4;

    /***********************************************券的相关信息*******************************************/
	/**券： 美*/
	public static final int COUPON_TYPE_3001 = 3001;
	/**券： 蓝*/
	public static final int COUPON_TYPE_3002 = 3002;
	/**券： 红*/
	public static final int COUPON_TYPE_3003 = 3003;
	/**券：  运费*/
	public static final int COUPON_TYPE_3004 = 3004;
	/**券： 营销*/
	public static final int COUPON_TYPE_3005 = 3005;

    /*************************预算状态*********************/
    /**未校验*/
    public static final int BUDGET_UNCHECKED = 0;
    /**校验成功（可以是预算的剩余使用金额）*/
    public static final int BUDGET_CHECK_SUCCESS = 1;
    /**校验失败（预算的剩余使用金额）*/
    public static final int BUDGET_CHECK_FAILED = 2;

    /***********************************************sap信息*******************************************/
    /**sap挂账 已收货标识 */
    public static final String Bill_TAKE_DELIVERY = "X";
    /**sap挂账 A补B */
    public static final String Bill_TAKE_DELIVERY_1 = "1";
    /**线下SAP未挂账*/
    public static final String Bill_OFFLINE_APPLY_0 = "0";
    /**线下SAP已挂账*/
    public static final String Bill_OFFLINE_APPLY_1 = "1";
    

    /***********************************************大数据*******************************************/
    /**正向单*/
    public static final String BIGDATA_ORDER_STATUS_0 = "0";
    /**逆向单*/
    public static final String BIGDATA_ORDER_STATUS_1 = "1";
    /**实发前*/
    public static final String BIGDATA_COMPUTE_STATUS_0 = "0";
    /**实发后*/
    public static final String BIGDATA_COMPUTE_STATUS_1 = "1";
    /**Y场景被扫描标识标识*/
    public static final int IS_SCAN_ENUM = 1;
    /**Y场景未被扫描标识标识*/
    public static final int IS_NO_SCAN_ENUM = 0;

    /***********************************************问题小工具*******************************************/
    /**skuNo*/
    public static final String PROBLEM_SKU_NO = "skuNo";
    /**业务机型*/
    public static final String PROBLEM_SALE_MODEL = "saleModel";
    /**线下品牌编码*/
    public static final String PROBLEM_EA_BRAND_CODE = "eaBrandCode";
    /**四级品类编码*/
    public static final String PROBLEM_EA_GROUP_CODE = "eaGroupCode";
    /**四级品类编码*/
    public static final String PROBLEM_PLAN_ID = "planId";

    /*********************************************** result 表 jobStatus 变更 4, 失败原因*******************************************/
    public static final String FAILURE_REASON_4_EMPLOY = "获利人为加盟商员工或者加盟商促销员";
    public static final String FAILURE_REASON_4_PROMOTION = "促销费类型: 无促, 政策编码: 605, 场景: X, 获利人符合 A卖A 条件, 不给提奖";
    public static final String FAILURE_REASON_4_HAVE_SALLER = "通过查询主营为空,或者满足有考勤大于十五天的促销员";


    /****************************业务机型*****************************/
    /**业务机型-01 标准机*/
    public static final String PROBLEM_SALE_MODEL_01 = "01";
    /**业务机型-02 包销机*/
    public static final String PROBLEM_SALE_MODEL_02 = "02";
    /**业务机型-11 一步到位机*/
    public static final String PROBLEM_SALE_MODEL_11 = "11";

    /***************************合同类型********************************/
    /**流水倒扣合同*/
    public static final String COMPACT_CLASS_LSDK = "C005";
    public static final String COMPACT_CLASS_C005 = "C005";
    /*净价合同*/
    public static final String COMPACT_CLASS_C002_C004 = "C002,C004";
    public static final String COMPACT_CLASS_C002 = "C002";
    public static final String COMPACT_CLASS_C004 = "C004";

    /****************************推送返利待入账信息mq******************************/
    /**初始化状态*/
    public static final int ENROLL_BILL_ACCOUNT_TYPE_INIT = -1;
    /**待入账*/
    public static final int ENROLL_BILL_ACCOUNT_TYPE_1 = 1;
    /**以入账*/
    public static final int ENROLL_BILL_ACCOUNT_TYPE_2 = 2;
    /**已失效*/
    public static final int ENROLL_BILL_ACCOUNT_TYPE_3 = 3;

    /***************************合同类型********************************/
    /**未严控*/
    public static final int YK_STATUS_NO = 0;
    /**已严控*/
    public static final int YK_STATUS_YES = 1;

    /***************************计算相关********************************/
    /**提奖限额默认值*/
    public static final int CALC_DEFAULT_LIMIT_AWARD_AMOUNT = -1;
    /***到店预约invokefrom***/
    public static final String STORESUBSCRIBE_INVOKEFROM = "crp-calc-service";
    
    /***商品自助服务平台-sku属性查询服务 业务模型Id***/
    public static final String MID = "XYZP0002";

    // ***************************库存类型 start**********************************
    /** UNKNOW(0, "UNKNOW", "未知")*/
    public static final String ORDER_CALC_STOCK_TYPE_UNKNOW = "UNKNOW";
    /** G3PP_SPU(8, "G3PP_SPU", "门店自提商品")*/
    public static final String ORDER_CALC_STOCK_TYPE_G3PP_SPU = "G3PP_SPU";
    /** G3PP_D(9, "G3PP_D", "带安")*/
    public static final String ORDER_CALC_STOCK_TYPE_G3PP_D = "G3PP_D";
    /** G3PP_L(10, "G3PP_L", "联营")*/
    public static final String ORDER_CALC_STOCK_TYPE_G3PP_L = "G3PP_L";
    /** G3PP_3C(12, "3C", "G3PP小件仓")*/
    public static final String ORDER_CALC_STOCK_TYPE_G3PP_3C = "G3PP_3C";
    /** B3PP_SPU(13, "B3PP_SPU", "联营自提")*/
    public static final String ORDER_CALC_STOCK_TYPE_B3PP_SPU = "B3PP_SPU";
    /**BHS_DE(14, "BHS_DE", "百货")*/
    public static final String ORDER_CALC_STOCK_TYPE_BHS_DE = "BHS_DE";
    /**BHS_JD(15,"BHS_JD","百货京东")*/
    public static final String ORDER_CALC_STOCK_TYPE_BHS_JD = "BHS_JD";
    /** G3PP_SPU_HG(16, "G3PP_SPU_HG", "火锅商品")*/
    public static final String ORDER_CALC_STOCK_TYPE_G3PP_SPU_HG = "G3PP_SPU_HG";

    // *********************************库存类型 end*************************************




}