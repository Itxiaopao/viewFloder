package com.gome.crp.calc.client;


public class ClientResultDTO<T> {
    private String message;
    private int code;
    private T data;

    public ClientResultDTO(T data) {
        this.code = 0;
        this.message = "成功";
        this.data = data;
    }

    public ClientResultDTO(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public boolean isSuccess() {
        boolean flag;
        if (this.code == 0) {
            flag = true;
        } else {
            flag = false;
        }

        return flag;
    }

    public static <T> ClientResultDTO<T> success(T data) {
        return new ClientResultDTO(data);
    }

    @SuppressWarnings("unchecked")
    public static <T> ClientResultDTO<T> success() {
        return (ClientResultDTO<T>) success("");
    }

    public static <T> ClientResultDTO<T> error(int error, String message) {
        return new ClientResultDTO(error, message);
    }

    public T getData() {
        return this.data;
    }

    public String getMessage() {
        return this.message;
    }

    public int getCode() {
        return this.code;
    }
}
