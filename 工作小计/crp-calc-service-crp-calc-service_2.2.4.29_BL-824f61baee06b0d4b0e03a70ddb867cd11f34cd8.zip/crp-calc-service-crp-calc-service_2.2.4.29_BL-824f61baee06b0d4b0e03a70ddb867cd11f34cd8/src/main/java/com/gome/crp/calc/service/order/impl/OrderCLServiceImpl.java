package com.gome.crp.calc.service.order.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.manager.OrderBaseManager;
import com.gome.crp.calc.manager.sendBigData.SendBigDataCopeManager;
import com.gome.crp.calc.mq.producer.SendEnrollBillProcessImpl;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.service.budget.IBudgetService;
import com.gome.crp.calc.service.order.IOrderService;
import com.gome.crp.calc.service.order.abstr.AbstractOrderBaseService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.mybatis.model.SapRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 订单已取消 取消 提成失效
 */
@Slf4j
@Service
public class OrderCLServiceImpl extends AbstractOrderBaseService implements IOrderService {
    @Autowired
    private OrderBaseManager orderBaseManager;
    @Autowired
    private IBillService iBillService;
    @Autowired
    private IBudgetService iBudgetService;
    @Autowired
    private SendBigDataCopeManager sendBigDataUtilsService;
    @Autowired
    private ICalcRewardsService calcRewardsService;
    @Autowired
    private SendEnrollBillProcessImpl sendEnrollBillProcess;

    @Override
    public Integer process(OrderCalcDto orderCalcDto) {
        log.info("取消单mq消息处理开始orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);

        //查询计划订单
        List<CalcResult> calcResultList = super.selectCalcResult(orderCalcDto);
        if (CollectionUtils.isEmpty(calcResultList)) {
            log.info("取消单mq消息处理,原始计划订单不存在orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
            return null;
        }

        //数据过滤处理
        List<CalcResult> filterCalcResult = super.filterCalcResult(calcResultList, orderCalcDto);
        if (CollectionUtils.isEmpty(filterCalcResult)) {
            log.info("取消单mq消息处理,没有处理数据orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
            return null;
        }

        //sap冲账
        List<SapRecord> sapRecordList = Collections.emptyList();
        List<CalcResult> applyCalcResult = super.getCancelApplyBillCalcResult(filterCalcResult, orderCalcDto);
        if (!CollectionUtils.isEmpty(applyCalcResult)) {
            sapRecordList = iBillService.applyBill(applyCalcResult);
        } else {
            log.info("取消单mq消息处理,不需要sap冲账orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
        }

        //预算回滚
        List<CalcResult> budgetCalcResult = super.getBudgetCalcResult(filterCalcResult, orderCalcDto);
        if (!CollectionUtils.isEmpty(budgetCalcResult)) {
            iBudgetService.releaseBudget(budgetCalcResult);
        } else {
            log.info("取消单mq消息处理,不需要预算回滚orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
        }

        //推送大数据
        List<CalcResult> bigDataCalcResult = super.setSendBigDataUtilsService(filterCalcResult, orderCalcDto);
        if (!CollectionUtils.isEmpty(bigDataCalcResult)) {
            sendBigDataUtilsService.sendBigDataMSG(bigDataCalcResult);
        } else {
            log.info("取消单mq消息处理,不需要推送大数据orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
        }
        // 推送入账信息 : 内部变更rebateAccountType
        this.sendEnrollBillProcess(filterCalcResult);

        //计算记录数据,更新计算结果对象,sap冲账数据保存
        List<CalcRecord> calcRecords = super.getCalcRecord(filterCalcResult, orderCalcDto);
        // 变更已推送入账信息状态
        List<CalcResult> updateCalcResult = super.getUpdateCalcResult(filterCalcResult, orderCalcDto, BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_3);
        orderBaseManager.doUpdateCalcResultStatus(updateCalcResult, calcRecords, sapRecordList);

        log.info("取消单mq消息处理完成orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);

        return null;
    }

    // 推送待入账
    private void sendEnrollBillProcess(List<CalcResult> calcResultList){
        if(!CollectionUtils.isEmpty(calcResultList)){
            List<CalcResult> collect = new ArrayList<>();
            for(CalcResult cr: calcResultList){
                if(cr.getRebateAccountType() > BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_INIT){
                    cr.setRebateAccountType(BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_3);
                    collect.add(cr);
                }

            }
            log.info("推送返利入账信息-取消单: {}", JSONObject.toJSONString(collect));
            sendEnrollBillProcess.sendPreBills(collect, BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_3, BaseConstants.ORDER_CL_STATUS);
        }

    }


//    // 保存提奖履历数据
//    private void saveResultRewards(List<CalcResult> calcResultList){
//        log.info(String.format("退单加入"));
//        if(CollectionUtils.isEmpty(calcResultList)){
//            return;
//        }
//
//        List<CalcResultReward> calcResultRewardList = new ArrayList<>(calcResultList.size());
//        for (CalcResult cr: calcResultList){
//            calcResultRewardList.add(this.getCalcReward(cr, cr.getAwardAmount().toString()));
//        }
//        calcRewardsService.addBatchCommit(calcResultRewardList);
//    }


}