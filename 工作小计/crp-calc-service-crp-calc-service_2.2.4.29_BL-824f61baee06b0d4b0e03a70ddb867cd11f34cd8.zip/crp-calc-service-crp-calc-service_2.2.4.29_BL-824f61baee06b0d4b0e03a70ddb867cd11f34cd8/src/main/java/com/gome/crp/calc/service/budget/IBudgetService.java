package com.gome.crp.calc.service.budget;

import com.gome.crp.calc.mybatis.model.CalcResult;

import java.util.List;

/**
 * 预算严控
 */
public interface IBudgetService {


    /**
     * 占用预算
     *
     * @param calcResultList
     * @return
     */
    List<CalcResult> occupyBudget(List<CalcResult> calcResultList);

    /**
     * 释放预算
     *
     * @param calcResultList
     * @return
     */
    void releaseBudget(List<CalcResult> calcResultList);

    /**
     * 是否预算严控
     * @param calcResult
     * @return
     */
    boolean isBudgetControl(CalcResult calcResult);
    
    /**
     * 费用承担方
     * @param list
     */
    void occupyBudgetUncheckedDLOrCO(List<CalcResult> list);
    
    /**
     * 无函Y
     * @param list
     */
    void occupyBudgetHaveNoLetterY(List<CalcResult> list);

}
