package com.gome.crp.calc.dto.employee;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 员工信息
 */
@Setter
@Getter
@ToString
public class EmployeeInfoDto implements Serializable{

	private static final long serialVersionUID = 4859334283191954201L;

	/**
	 * 基础信息
	 */
	private EmployeeInfoBaseDto baseInfo;
    /** 岗位信息 */
    private List<GomeEmployeePostInformation> gomeEmployeePostInformationList;
	/** 品牌品类集合 */
	private List<GomeCategoryBrand> gsscbList;
	/** 供应商信息集合 */
	private List<ResponseGroupVendorDto> gomeVendorList;


}
