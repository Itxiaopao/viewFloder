package com.gome.crp.calc.service.job.impl;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.client.message.ISendMessage;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.FailureReasonEnum;
import com.gome.crp.calc.constants.MailAddressEnum;
import com.gome.crp.calc.constants.SendMsgBusinessTypeEnum;
import com.gome.crp.calc.constants.SendMsgTypeEnum;
import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;
import com.gome.crp.calc.manager.employee.EmployeeAttendanceSynManager;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.EmployeeAttendance;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.service.job.IJobAwardService;
import com.gome.crp.calc.service.job.IJobNoPaymentService;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JobSapNoPaymentServiceImpl implements IJobNoPaymentService {

	@Autowired
	private ICalcResultService iCalcResultService;
	@Autowired
	private IJobAwardService iJobAwardService;
	@Autowired
	private ISendMessage iSendMessage;
	@Autowired
	private EmployeeAttendanceSynManager employeeAttendanceSynManager;

	public void changeJobStatus() {
		log.info("订单计算履历修改Job状态  Start");
		long startTime = System.currentTimeMillis();
		try{
			execute();
		}catch(Exception e){
			log.error("订单计算履历修改Job状态发生异常",e);
		}finally{
			log.info("订单计算履历修改Job状态 End 耗时 "+(System.currentTimeMillis()-startTime)+"ms");
		}
	}

	// 执行业务逻辑
	private void execute() {
		int pageSize = 500;
		int pageNo = 1;
		Date date = getSearchEndDate();
		List<CalcResult> list = Collections.emptyList();
		do {
			// 这里catch为了不影响下一页数据处理
			try {
				log.info("订单计算履历修改Job状态：分页处理数据：查询截止时间为{} pageNo {} pageSize {}", date, pageNo, pageSize);
				list = fetchList(pageNo, pageSize, date);
				List<CalcResult> filterList = filterList(list);
				update(filterList);
			} catch (Exception e) {
				log.error("订单计算履历修改Job状态：分页处理数据发生异常", e);
			}
			pageNo++;
		} while (pageSize == list.size());
		
	}

	//获取本次查询截止日期时间,当前月份的上个月1号零点
	private Date getSearchEndDate(){
		LocalDate dateTime = LocalDate.now().minusMonths(1).with(TemporalAdjusters.firstDayOfMonth());
		Instant instant = dateTime.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant();
		return Date.from(instant);
	}
	
	// 拉取数据
	public List<CalcResult> fetchList(int pageNo, int pageSize, Date date) {
		QueryWrapper<CalcResult> q = Wrappers.query();
		q.eq("yk_status", BaseConstants.YK_STATUS_NO)// 0：未严控
				.eq("job_status", BaseConstants.CRD_JOB_STATUS_1_N)// -1:初始状态
				.isNotNull("limit_award_amount")// 百分之十五计提限价不是空
				.lt("order_submit_time", date)// 一个月前的数据
				.and(t -> t.and(w -> w.in("extra_policy_code", BaseConstants.PLAN_EXTRA_POLICY_CODE_605).eq("is_asella",BaseConstants.PLAN_IS_A_SELL_A_Y))// z605 and A卖A
						.or(y -> y.in("extra_policy_code", BaseConstants.PLAN_EXTRA_POLICY_CODE_195,BaseConstants.PLAN_EXTRA_POLICY_CODE_197)));
		Page<CalcResult> page = new Page<>(pageNo, pageSize);
		page.setSearchCount(false);
		IPage<CalcResult> result = iCalcResultService.page(page, q);
		return result.getRecords();
	}

	// 过滤数据
	private List<CalcResult> filterList(List<CalcResult> list) {
		if (CollectionUtils.isNotEmpty(list)) {
			List<CalcResult> result = new ArrayList<>(list.size());
			for (CalcResult r : list) {
				if (!BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(r.getExtraPolicyCode())) {
					// Z195 OR Z197,有促
					String time = iJobAwardService.dealTimeToString(r.getOrderSubmitTime());
					if (checkPromotion(time, r.getStaffCode())) {
						result.add(r);
					}else{
						//发送报警邮件
						String content = String.format("数据ID为:%s", r.getId());
						SendMessageDto sendMessageDto = new SendMessageDto(SendMsgTypeEnum.SEND_EMAIL.getCode(),content,SendMsgBusinessTypeEnum.ERROR_WUCU.getCode());
						List<String> mailAddressList = MailAddressEnum.getMailAddressList();
						sendMessageDto.setTopic("提成二期系統-清理无促异常报警");
						sendMessageDto.setUserList(mailAddressList);
						iSendMessage.sendAsyncMsg(sendMessageDto);
					}
				} else {
					// Z605 不过滤
					result.add(r);
				}
			}
			return result;
		}
		return list;
	}
	
	private boolean checkPromotion(String month,String staffCodes){
        List<EmployeeAttendance> employeeAttendances = employeeAttendanceSynManager.queryEmployeeAttendanceByStaffCode(Lists.newArrayList(staffCodes), month);
        if (CollectionUtils.isEmpty(employeeAttendances)) {
            return false;
        }
		return true;
	}

	// 更新数据
	private void update(Collection<CalcResult> entityList) {
		if (CollectionUtils.isNotEmpty(entityList)) {
			List<CalcResult> updateList = new ArrayList<>(entityList.size());
			for (CalcResult r : entityList) {
				CalcResult nr = new CalcResult();
				nr.setId(r.getId());
				nr.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
				nr.setFailureReason(FailureReasonEnum.SAP_NO_PAYMENT.getMsg());
				updateList.add(nr);
			}
			iCalcResultService.updateBatchById(updateList);
		}
	}

}
