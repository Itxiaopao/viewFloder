package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * 字段值变动日志表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class CalcFieldChangeLog {

	private Long id; //主键id
	private String tableName; //表名
	private Long rowId; //行id
	private String fieldName; //字段名
	private String fieldValue; //字段值
	private String remark; //备注
	private Integer isDelete; //0未删除，1已删除
	private Date createTime; //创建时间
	private Date updateTime; //更新时间
}