package com.gome.crp.calc.service.retry.cope;

import com.gome.crp.calc.mybatis.model.CalcRetry;

/**
 * 重推接口
 *
  */
public interface IRetrySceneService {


    boolean cope(CalcRetry calcRetry);


}
