package com.gome.crp.calc.dto.profitDto;

import lombok.Data;

/**
 * 查询承接人用入参
 */
@Data
public class QueryReceiverReqDto {
    private String txId; //幂等Id
    private String invokeFrom; //调用来源
    private String storeId; //门店id
    private String userId; //用户Id
    private String StringOrderTime; //下单时间
    private Long LongOrderTime; //下单时间时间戳


}
