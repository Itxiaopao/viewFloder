package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.SapAccount;

/**
 * sap账目表 Mapper
 */
public interface SapAccountMapper extends BaseMapper<SapAccount> {

}