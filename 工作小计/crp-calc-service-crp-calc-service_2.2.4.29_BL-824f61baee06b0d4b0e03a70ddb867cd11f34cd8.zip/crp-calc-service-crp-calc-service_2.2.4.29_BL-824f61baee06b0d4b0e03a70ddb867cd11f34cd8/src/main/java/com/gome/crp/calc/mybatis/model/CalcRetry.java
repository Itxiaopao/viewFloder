package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * 失败重试表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class CalcRetry {

	private Long id; //id
	private String msgBody; //消息体
	private Integer type; //类型
	private Integer repeatTime; //重试次数
	private Integer isDelete; //isDelete
	private Date createTime; //createTime
	private Date updateTime; //updateTime
	private Integer isSuc;	// 重试成功: 1:成功, 0:失败
	private String orderId;//订单号
	private String sapDetailId;//sapDetailId
	private String gomeStatus;//订单状态
	private String failureReason;//失败原因
	private String remark;//备注
}