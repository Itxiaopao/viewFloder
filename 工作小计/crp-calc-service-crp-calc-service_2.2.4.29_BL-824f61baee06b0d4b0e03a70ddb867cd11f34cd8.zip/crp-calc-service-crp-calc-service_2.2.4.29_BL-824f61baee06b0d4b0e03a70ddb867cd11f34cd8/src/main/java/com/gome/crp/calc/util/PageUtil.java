package com.gome.crp.calc.util;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.common.util.ReflectUtil;
import com.gome.meidian.common.base.vo.PageCollection;

/**
 * Page 工具类
 * @author lisuo
 *
 */
public class PageUtil {
	
	/**
	 * Mybatis plus的page映射成PageCollection结果集 
	 * @param page MybatisPage信息
	 * @param clazz 返回结果Page泛型
	 * @return
	 */
	public static <T> PageCollection<T> toPageCollection(Page<?> page, Class<T> clazz){
		PageCollection<T> resultPage = new PageCollection<>();
		resultPage.setRows(ReflectUtil.converterList(page.getRecords(), clazz));
		resultPage.setTotal(page.getTotal());
		resultPage.setTotalPage(page.getPages());
		resultPage.setPageSize(page.getSize());
		resultPage.setPageNumber(page.getCurrent());
		return resultPage;
	}
	
}
