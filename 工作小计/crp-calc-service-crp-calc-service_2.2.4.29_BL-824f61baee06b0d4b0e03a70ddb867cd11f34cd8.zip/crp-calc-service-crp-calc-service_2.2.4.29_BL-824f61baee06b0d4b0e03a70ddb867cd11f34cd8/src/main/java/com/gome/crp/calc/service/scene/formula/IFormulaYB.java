package com.gome.crp.calc.service.scene.formula;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.math.BigDecimal;

/**
 * 延保公式计算
 */
public interface IFormulaYB {

    // **********************************************************
    // YB
    // 延保
    // condition:
    // 国美预算:
    // 计提现价,
    // 延保只计算 X,
    // Formula:
    // 提奖金额=销售金额（或实付金额）×销售数量×发放比例×X比例
    //***********************************************************
    BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene);


}
