package com.gome.crp.calc.service.calc;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.service.calc.impl.CalcServiceOrder;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 计算工厂
 * 目前只有根据订单计算：CalcServiceOrder
 * 以后可以封装别的计算
 */
@Component
public class CalcFatctory implements InitializingBean {

    private Map<String, ICalcService> calcFactoryMap = new HashMap<>();

    @Autowired
    CalcServiceOrder calcOrder;

    public ICalcService getCalc(String key) {
        return calcFactoryMap.get(key);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        calcFactoryMap.put(BaseConstants.CALC_CONSTANT_ORDER, calcOrder);
    }
}
