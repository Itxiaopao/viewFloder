package com.gome.crp.calc.dto.profitDto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSON;

import lombok.Getter;
import lombok.Setter;
/**
 * 承接者包装类
 * @author GOME
 *
 */
@Getter
@Setter
public class Receiver implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4873305040277679709L;
	private String staffId;
	private Long receiverTime;
    private Integer profitBehaviorCode;//获利行为编码 	(2, "服务承接-IM"),(3, "服务承接-外呼"),(4, "服务承接-预约到店"),

//	public static void main(String[] args) {
//		List<Receiver> list = new ArrayList<>();
//		for(int i= 0 ;i<100;i++){
//			Receiver receiver = new Receiver();
//			receiver.setStaffId(i+"");
//			receiver.setReceiverTime(new Date().getTime());
//			list.add(receiver);
//		}
//		
//        Collections.sort(list, new Comparator<Receiver>(){  
//            /*  
//             * int compare(Student o1, Student o2) 返回一个基本类型的整型，  
//             * 返回负数表示：o1 小于o2，  
//             * 返回0 表示：o1和o2相等，  
//             * 返回正数表示：o1大于o2。  
//             */  
//        	@Override
//            public int compare(Receiver o1, Receiver o2) {  
//                //按照金额大小进行降序排列  
//                if(o1.getReceiverTime() < o2.getReceiverTime()){  
//                    return 1;  
//                }  
//                return -1;  
//            }
//        });
//        
//        for(Receiver receiver : list){
//        	System.err.println(JSON.toJSON(receiver));
//        }
//	}

}
