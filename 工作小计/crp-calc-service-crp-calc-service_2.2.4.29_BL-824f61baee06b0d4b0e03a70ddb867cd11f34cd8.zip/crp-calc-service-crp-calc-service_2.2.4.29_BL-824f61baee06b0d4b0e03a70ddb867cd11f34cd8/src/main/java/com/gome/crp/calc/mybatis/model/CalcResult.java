package com.gome.crp.calc.mybatis.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 订单计算履历主表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class CalcResult {
    @TableId(type = IdType.INPUT)
    private Long id;

    /**
     * 订单号
     */
    private String orderId;

    /**
     * 配送单号
     */
    private String deliveryId;

    /**
     * skuNo
     */
    private String skuNo;

    /**
     * skuName
     */
    private String skuName;

    /**
     * 业务机型
     */
    private String salesModel;

    /**
     * 购买数量
     */
    private Integer buyNum;

    /**
     * 下单人
     */
    private String profileId;

    /**
     * 开单人userId
     */
    private String sellerId;

    /**
     * 分享人userId
     */
    private String shareId;

    /**
     * 门店编码
     */
    private String shopNo;

    /**
     * 门店编码
     */
    private String shopType;

    /**
     * 订单总金额（包含国美币）（不排除券，不排除美豆的）
     */
    private Long orderSalePrice;

    /**
     * 订单总金额（包含国美币）（实付金额，排除券、美豆后的支付金额）
     */
    private Long orderPrice;

    /**
     * 销售金额
     */
    private Long salePrice;

    /**
     * detail级别sku的单个商品的实付金额，已经减掉了优惠的价格
     */
    private Long price;

    /**
     * 行项目号
     */
    private String commerceItemId;

    private String detailId;

    private String sapDetailId;

    /**
     * 订单的供应商编码
     */
    private String orderSupplierCode;

    /**
     * 主订单生成时间
     */
    private Date orderSubmitTime;

    /**
     * 订单妥投时间
     */
    private Date orderEffectTime;

    /**
     * 订单渠道
     */
    private String channel;

    /**
     * 逻辑DC编码
     */
    private String logicMasLoc;

    /**
     * 品牌编码
     */
    private String brandCode;

    /**
     * 线下二级品类
     */
    private String categoryLevelTwo;

    /**
     * 线下三级品类
     */
    private String categoryLevelThree;

    /**
     * 线下四级品类
     */
    private String categoryLevelFour;

    /**
     * 公司代码
     */
    private String companyCode;

    /**
     * 获利人员工编码
     */
    private String staffCode;

    /**
     * 获利人会员id
     */
    private String userId;

    /**
     * 获利场景
     */
    private String scenes;

    /**
     * 获利金额
     */
    private Long awardAmount;

    /**
     * 员工类别（A:正式员工B:劳务派遣C:临时工D:促销员E:实习生F:退休返聘G:挂靠残疾人H:劳务用工I:加盟商员工J:加盟商促销员）
     */
    private String staffClass;

    /**
     * 岗位类型（0集团,1大区,2一级分部,3二级分部,4门店,5DC,6售后,7异常）
     */
    private Integer staffLevel;

    /**
     * 获利人一级分部
     */
    private String staffBranchCodeOne;

    /**
     * 获利人二级分部
     */
    private String staffBranchCodeTwo;

    /**
     * 获利人所在门店
     */
    private String staffStoreCode;

    /**
     * 获利人的供应商编码
     */
    private String staffSupplierCode;

    /**
     * 是否A卖A 0:是,1:不是
     */
    private Integer isAsella;

    /**
     * 是否厂家承担 0:国美承担,1:厂家承担
     */
    private Integer isGomeOffer;

    /**
     * 计划号
     */
    private String planId;

    /**
     * 计提限价
     */
    private Long currentPrice;

    /**
     * 政策编码
     */
    private String extraPolicyCode;

    /**
     * 促销费
     */
    private Long promotionalMoney;

    /**
     * 促销费类型 （0 无促、1 差异化、2 非差异化、3 带单、4 总额、5 拓客）
     */
    private Integer promotionsType;

    /**
     * 费用承担类型 （0 供应商承担、1 国美承担、2 国美预算、3 营销预算）
     */
    private Integer expencesOfferType;

    /**
     * 签约类型
     */
    private String contractType;

    /**
     * 合同号
     */
    private String contractCode;

    /**
     * 协议号
     */
    private String extraNum;

    /**
     * 订单状态
     */
    private String gomeStatus;

    /**
     * 0：未校验；1：校验成功（可以是预算的剩余使用金额）；2:校验失败（预算的剩余使用金额）
     */
    private Integer budgetStatus;

    /**
     * -2:y特殊的状态，-1:初始状态，0：SAP严控，1：预算校验，2：待拉取账单，3：已拉取账单，4：失效
     预算状态
     */
    private Integer jobStatus;

    private Date createTime;

    private Date updateTime;
    /**
     * 计划结束时间
     */
//    private Date planEndTime;
    /**
     * 0未删除，1已删除
     */
    private Integer isDelete;
    /**
     * 失败原因
     */
    private String failureReason;
    /**
     * 挂账比例 （无函有值）
     */
    private BigDecimal accountRate;
    /**
     * 员工所属供应商
     */
    private String staffSuppliers;

    /**
     * 是否收货
     */
    private Integer isReceiptGoods;

    /**
     * 是否已线上挂账
     */
    private Integer isOnlineApplyBill;

    /**
     * 是否已线下挂账
     */
    private Integer isOfflineApplyBill;

    /**
     * 合同所属采购组织编码
     */
    private String contractPurchaseCode;

    /**
     * 协议或函采购组织编码
     */
    private String extraPurchaseCode;

    /**
     * 函类型（主推函（ZB00)，确认函（ZC09)）
     */
    private String docty;

    /**
     * 销售组织ID
     */
    private String salesOrganization;

    /**
     * 采购组织(通过逻辑DC编码查询)
     */
    private String purchaseCode;

    /**
     * 供价
     */
    private Long offerPrice;

    /**
     * 订单生效消息体
     */
    private String coMsgBody;

    /**
     * 订单妥投消息体
     */
    private String dlMsgBody;

    /**
     * 是否冲减综贡 （0是、1否）
     */
    private Integer isOffset;

    /**
     * 供应商名称
     */
    private String supplierName;

    /**
     * 发放比例
     */
    private BigDecimal grantRate;

    /**
     * 签约类型
     */
    private String contractClass;

    /**
     * 计划行项目ID
     */
    private String planDetailId;

    /**
     *主计划id
     */
    private String mainId;

    /**
     * 剩余预算金额
     */
    private Long surplusAmount;

    /**
     * 订单支付时间
     */
    private Date payDate;

    /**
     * 版本号
     */
    private Integer version;

    /**
     * skuId
     */
    private String skuId;

    /**
     * 差异非差的计划行项目id
     */
    private String mainPlanDetailId;

    /**
     * 计提基数
     */
    private Integer provisionType;

    /**
     * 业务方，目前只有12渠道有值
     */
    private String demanderCode;

    /**
     * 是否推送大数据 0:未推送 1:已推送
     */
    private Integer isPushBigdata;
    /**
     * 返利入账信息类型推送
     * 返利入账信息: -1 未推送, 1, 待入账, 2, 已入账, 3, 已失效'
     */
    private Integer rebateAccountType;

    /**
     * 严控标识
     * 0：未严控；1：已严控；
     */
    private Integer ykStatus;

    /**
     * 百分之十五计提限价
     */
    private Long limitAwardAmount;
    
    /**
     * 获利行为
     */
    private Integer profitBehavior;//获利行为:(1:开单;2:服务承接-IM;3:服务承接-外呼;4:服务承接-预约到店;5:分享商品;6:分享券;7:主营均分;8:兼营均分;9:集客;10:上级)

    /**
     * 商品标识。1.主商品；2.赠品；3.延保
     */
    private String goodsType;

    /**
     * 延保状态标识 1:延保  0:非延保
     */
    private Integer warrantyFlag;
    
    /**
     * 计算逻辑
     */
    private String calcLogic;//计算逻辑
}