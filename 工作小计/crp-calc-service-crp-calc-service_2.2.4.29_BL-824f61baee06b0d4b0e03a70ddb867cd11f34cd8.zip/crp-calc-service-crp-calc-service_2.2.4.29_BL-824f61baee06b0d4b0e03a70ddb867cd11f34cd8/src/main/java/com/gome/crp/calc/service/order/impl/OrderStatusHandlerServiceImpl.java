package com.gome.crp.calc.service.order.impl;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.threadLocal.LocalDto;
import com.gome.crp.calc.service.order.IOrderService;
import com.gome.crp.calc.service.order.IOrderStatusHandlerService;
import com.gome.crp.calc.service.order.OrderFactory;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class OrderStatusHandlerServiceImpl implements IOrderStatusHandlerService {
    @Autowired
    private OrderFactory orderFactory;

    @Override
    public void calcOrder(OrderCalcDto orderCalcDto) {
        cacheOrderCalcDto(orderCalcDto);

        //按订单状态获取处理类
        IOrderService orderService = orderFactory.getOrderStatusServiceObj(orderCalcDto);
        if (orderService == null) {
            log.error("订单计算,按订单状态获取不到处理类orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
            return;
        }

        //执行订单计算任务
        Integer result = orderService.process(orderCalcDto);
        //记录未匹配结果
        orderService.recordCalcNoResult(orderCalcDto, result);
        LocalDto localDto = CalcLocal.getLocalDto();
        Long beginTime = localDto.getBeginTime();
        Long consumeTime = 0L;
        if(null != beginTime){
            consumeTime = System.currentTimeMillis() - beginTime;
        }
        log.info("提成计算耗时:{},channel:{},type:{},orderId:{}", consumeTime, orderCalcDto.getChannel(),localDto.getType(), orderCalcDto.getOrderId());
    }

    private void cacheOrderCalcDto(OrderCalcDto orderCalcDto) {
        LocalDto localDto = new LocalDto();
        localDto.setOrderCalcDto(orderCalcDto);
        CalcLocal.setLocalDto(localDto);
    }


}
