package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcResultReward;

/**
 * 计算提奖列表 Mapper
 * @author zhangshuang
 *
 */
public interface CalcResultRewardMapper extends BaseMapper<CalcResultReward>{

}