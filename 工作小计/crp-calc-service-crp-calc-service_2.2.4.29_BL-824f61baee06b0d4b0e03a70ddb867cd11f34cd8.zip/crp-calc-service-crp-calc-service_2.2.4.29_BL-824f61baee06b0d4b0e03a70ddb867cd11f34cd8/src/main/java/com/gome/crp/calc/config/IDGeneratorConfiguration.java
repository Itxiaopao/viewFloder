package com.gome.crp.calc.config;

import com.gome.architect.idgnrt.IdGenUtil;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.retry.RetryNTimes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * IDGenerator配置
 */
@Configuration
public class IDGeneratorConfiguration {
    @Value("${idGenerator.zk.address}")
    private String address;
    @Value("${idGenerator.zk.retryNum}")
    private int retryNum;
    @Value("${idGenerator.zk.sleepMsBetweenRetries}")
    private int sleepMsBetweenRetries;
    @Value("${idGenerator.zk.connectionTimeoutMs}")
    private int connectionTimeoutMs;

    @Bean
    public IdGenUtil getIdGenUtil() {
        IdGenUtil util = new IdGenUtil();
        CuratorFramework zkClient = CuratorFrameworkFactory.builder()
                .connectString(address)
                .retryPolicy(new RetryNTimes(this.retryNum, this.sleepMsBetweenRetries))
                .connectionTimeoutMs(this.connectionTimeoutMs)
                .defaultData("".getBytes()).build();
        zkClient.start();
        util.setZkClient(zkClient);
        //源码中默认给sequenceKey加了个后缀.id，我们使用时可设置suffix为空
        util.setSuffix("");
        return util;
    }

}
