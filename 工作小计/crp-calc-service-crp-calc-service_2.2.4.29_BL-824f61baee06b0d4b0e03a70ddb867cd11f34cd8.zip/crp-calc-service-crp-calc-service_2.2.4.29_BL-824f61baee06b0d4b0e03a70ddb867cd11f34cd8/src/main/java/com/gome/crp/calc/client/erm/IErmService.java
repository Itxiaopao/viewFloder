package com.gome.crp.calc.client.erm;

import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.dto.ermDto.*;

import java.util.List;

public interface IErmService {

    /**
     * 关停计划
     *
     * @param reqDto
     * @return
     */
    ClientResultDTO<ClosePlanResDto> closePlan(ClosePlanReqDto reqDto);

    /**
     * 释放预算
     *
     * @param reqDto
     * @return
     */
    ClientResultDTO<ReleaseBudgetResDto> releaseBudget(ReleaseBudgetReqDto reqDto);

    /**
     * 占用预算
     *
     * @param reqDto
     * @return
     */
    ClientResultDTO<OccupyBudgetResDto> occupyBudget(OccupyBudgetReqDto reqDto);

    /**
     * 查询新合同
     *
     * @param oldContractCode
     * @return
     */
    String queryNewContractCode(String oldContractCode);

    /**
     * 函信息查询
     */
    List<LetterResDto> queryLetter(LetterReqDto letterReqDto);
}