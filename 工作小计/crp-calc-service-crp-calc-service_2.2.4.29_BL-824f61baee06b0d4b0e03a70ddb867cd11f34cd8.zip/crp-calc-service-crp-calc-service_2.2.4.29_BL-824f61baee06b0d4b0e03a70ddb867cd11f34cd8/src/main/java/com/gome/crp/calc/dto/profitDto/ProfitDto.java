package com.gome.crp.calc.dto.profitDto;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Data;

/**
 * 一个计划的
 * 获利信息
 */
@Data
public class ProfitDto implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1824021726395830481L;
	
	private String scenes; //场景    x,y,z,m
    private BigDecimal awardAmount; //获利金额

	/*
		获利人信息
	 */
    private PersonDto personDto;

}
