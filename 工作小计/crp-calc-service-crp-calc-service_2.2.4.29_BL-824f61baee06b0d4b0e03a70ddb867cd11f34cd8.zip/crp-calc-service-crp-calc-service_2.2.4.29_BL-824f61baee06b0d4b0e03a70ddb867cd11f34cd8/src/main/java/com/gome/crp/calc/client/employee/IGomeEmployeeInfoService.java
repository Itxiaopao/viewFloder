package com.gome.crp.calc.client.employee;

import com.gome.crp.calc.dto.employee.EmployeeInfoDto;

import java.util.List;

/**
 * gome employee upgrade
 * 
 * @author libinbin9
 *
 */
public interface IGomeEmployeeInfoService {

	/**
	 * 查询员工信息
	 *
	 *
	 * @param orderId
	 * @param categoryId
	 * @param brandId
	 * @param employeeIdList
	 * @param shop
	 * @return
	 */
	List<EmployeeInfoDto> queryGomeEmployeeInfos(String orderId, String categoryId, String brandId, List<String> employeeIdList, String shop);

}
