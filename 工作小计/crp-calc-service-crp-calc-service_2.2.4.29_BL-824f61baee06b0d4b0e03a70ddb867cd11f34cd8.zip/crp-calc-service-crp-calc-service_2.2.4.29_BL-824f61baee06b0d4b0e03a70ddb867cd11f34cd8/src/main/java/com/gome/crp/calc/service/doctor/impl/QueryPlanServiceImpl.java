package com.gome.crp.calc.service.doctor.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.cpqs.facade.CommissionPlanQueryFacade;
import com.gome.cpqs.model.CommissionPlanQueryReq;
import com.gome.cpqs.model.CommissionPlanQueryResp;
import com.gome.cpqs.model.CommissionPlanTerminateReq;
import com.gome.cpqs.model.ResourceReturnReq;
import com.gome.crp.calc.client.ClientResultDTO;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.ermDto.OccupyBudgetResDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.sapDto.*;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.service.doctor.IQueryPlanService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.util.BigDecimalUtils;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import com.gome.scot.ocqs.api.model.*;
import com.gome.scot.ocqs.api.service.OrderContractQueryService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Slf4j
@Service("queryPlanServiceImpl2")
public class QueryPlanServiceImpl implements IQueryPlanService {
    @Value("${system.id}")
    private String systemId;
    @Autowired
    private CommissionPlanQueryFacade commissionPlanQueryFacade;
    @Autowired
    private OrderContractQueryService orderContractQueryService;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private RedisLockHelper redisLockHelper;
    @Autowired
    private IProblemService problemService;

    /**
     * 综合体查询合同接口
     *
     * @param orderCalcDto
     * @return
     */
    @Override
    public ContractDetailVO queryContractByParam(OrderCalcDto orderCalcDto) {
        ContractDetailParam contractDetailParam = new ContractDetailParam();
        contractDetailParam.setSkuId(orderCalcDto.getSkuId());
        contractDetailParam.setSkuCode(orderCalcDto.getSkuNo());
        contractDetailParam.setClassFourthCode(orderCalcDto.getEaGroupCode());
        contractDetailParam.setBrandCode(orderCalcDto.getEaBrandCode());
        contractDetailParam.setSuppCode(orderCalcDto.getSupplier());
        contractDetailParam.setLogicMasLoc(orderCalcDto.getLogicMasLoc());
        contractDetailParam.setSubmittedDate(orderCalcDto.getSubmittedDate());
        contractDetailParam.setSaleOrgCode(orderCalcDto.getSalesOrganization());
        contractDetailParam.setSalesModel(orderCalcDto.getSalesModel());
        log.info("查询合同入参:{}", JSON.toJSONString(contractDetailParam));
        ContractDetailVO contractDetail = orderContractQueryService.getContractDetail(contractDetailParam);
        if (null == contractDetail || null == contractDetail.getContractPolicy()) {
            log.error("查询合同接口返回为空或者合同vo为空,查询合同接口为空response:{}", contractDetail);
            return null;
        } else {
            log.info("查询合同返参:{}", JSON.toJSONString(contractDetail));
        }
        return contractDetail;
    }

    /**
     * 综合体查询计划
     *
     * @param orderCalcDto
     * @param contractDetail
     * @return
     */
    @Override
    public List<PlanDto> queryPlanByParam(OrderCalcDto orderCalcDto, ContractDetailVO contractDetail) {
        ArrayList<CommissionPlanQueryReq> arrayList = getCommissionPlanQueryReqs(orderCalcDto, contractDetail);

        log.info("查询综合体dubbo计划入参,requestParam:{}", JSON.toJSONString(arrayList));
        List<CommissionPlanQueryResp> commissionPlanQueryResps = commissionPlanQueryFacade.queryPlans(arrayList);
        log.info("查询综合体dubbo计划返参,responseParam:{}", JSON.toJSONString(commissionPlanQueryResps));
        return dealPlanDtos(commissionPlanQueryResps, contractDetail);
    }

    @Override
    public List<PlanDto> queryPlanByParam(OrderCalcDto orderCalcDto, String skuCode, String salesMode, String planId, String promotionType, String no, String classFourthCode, String soBuyOrgCode) {
        ContractDetailVO contractDetailVO = new ContractDetailVO();

        ContractPolicyVO contractPolicy = null;
        CommissionVO mdCommission = null;
        ConfirmationVO confirmationVO = null;
        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(promotionType) || BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(promotionType)) {
            contractPolicy = getContractPolicy(no, classFourthCode);
            contractPolicy.setBuyOrgCode(soBuyOrgCode);
        } else if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(promotionType)) {
            mdCommission = getMdCommission(no, skuCode, salesMode);
            mdCommission.setBuyOrgCode(soBuyOrgCode);
        } else if (BaseConstants.PLAN_REPLACE_TYPE.equals(promotionType)) {
            confirmationVO = getMdConfirmation(no, soBuyOrgCode, skuCode, salesMode);
        }
        contractDetailVO.setContractPolicy(contractPolicy);
        contractDetailVO.setCommission(mdCommission);
        contractDetailVO.setConfirmation(confirmationVO);

        // 封装查询计划的请求体
        ArrayList<CommissionPlanQueryReq> commissionPlanQueryReqs = getCommissionPlanQueryReqs(orderCalcDto, contractDetailVO);
        log.info("查询综合体dubbo计划入参,requestParam:{}", JSON.toJSONString(commissionPlanQueryReqs));
        List<CommissionPlanQueryResp> commissionPlanQueryResps = commissionPlanQueryFacade.queryPlans(commissionPlanQueryReqs);
        log.info("查询综合体dubbo计划返参,responseParam:{}", JSON.toJSONString(commissionPlanQueryResps));

        // 查找到上游需要的 planId
        if (StringUtils.isNotEmpty(planId)) {
            Iterator<CommissionPlanQueryResp> iterator = commissionPlanQueryResps.iterator();
            while (iterator.hasNext()) {
                if (!planId.equals(iterator.next().getPlanId())) {
                    iterator.remove();
                }
            }
        }

        if (commissionPlanQueryReqs != null) {
            // 封装提成计算的 planDto
            return dealPlanDtos(commissionPlanQueryResps, contractDetailVO);
        } else {
            return null;
        }

    }

    @Override
    public ContractPolicyVO getContractPolicy(String contractCode, String classFourthCode) {
        log.info("根据合同号查询合同信息开始contractCode:{},classFourthCode:{}", contractCode, classFourthCode);
        ContractPolicyVO contractPolicy = orderContractQueryService.getContractPolicy(contractCode, classFourthCode);
        log.info("根据合同号查询合同信息完成contractCode:{},classFourthCode:{},contractPolicy:{}", contractCode, classFourthCode, JSON.toJSONString(contractPolicy));
        return contractPolicy;
    }

    @Override
    public ConfirmationVO getMdConfirmation(String confirmationNo, String buyOrgCode, String skuCode, String salesModel) {
        log.info("根据函号查询带单函开始confirmationNo:{},buyOrgCode:{},skuCode:{},salesModel:{}", confirmationNo, buyOrgCode, skuCode, salesModel);
        ConfirmationVO mdConfirmation = orderContractQueryService.getMdConfirmation(confirmationNo, buyOrgCode, skuCode, salesModel);
        log.info("根据函号查询带单函完成confirmationNo:{},buyOrgCode:{},skuCode:{},salesModel:{},mdConfirmation:{}", confirmationNo, buyOrgCode, skuCode, salesModel, JSON.toJSONString(mdConfirmation));
        return mdConfirmation;
    }

    @Override
    public CommissionVO getMdCommission(String protocolCode, String skuCode, String salesModel) {
        log.info("根据函号查询主推函信息开始protocolCode:{},skuCode:{},salesModel:{}", protocolCode, skuCode, salesModel);
        CommissionVO mdCommission = orderContractQueryService.getMdCommission(protocolCode, skuCode, salesModel);
        log.info("根据函号查询主推函信息完成protocolCode:{},skuCode:{},salesModel:{},mdCommission:{}", protocolCode, skuCode, salesModel, JSON.toJSONString(mdCommission));
        return mdCommission;
    }

    private ArrayList<CommissionPlanQueryReq> getCommissionPlanQueryReqs(OrderCalcDto orderCalcDto, ContractDetailVO contractDetail) {
        CommissionPlanQueryReq commissionPlanQueryReq = new CommissionPlanQueryReq();
        commissionPlanQueryReq.setRequestUuid(UUID.randomUUID().toString());
        commissionPlanQueryReq.setCategoryCode(orderCalcDto.getEaGroupCode());
        commissionPlanQueryReq.setBrandCode(orderCalcDto.getEaBrandCode());
        commissionPlanQueryReq.setSku(orderCalcDto.getSkuNo());
        if(contractDetail != null){
            if (contractDetail.getContractPolicy() != null) {
                commissionPlanQueryReq.setPurchaseOrgCode(contractDetail.getContractPolicy().getBuyOrgCode());
            } else if (contractDetail.getCommission() != null) {
                commissionPlanQueryReq.setPurchaseOrgCode(contractDetail.getCommission().getBuyOrgCode());
            } else {
                commissionPlanQueryReq.setPurchaseOrgCode(contractDetail.getConfirmation().getBuyOrgCode());
            }
        }
        commissionPlanQueryReq.setSupplierCode(orderCalcDto.getSupplier());
        commissionPlanQueryReq.setPurchaseOrderType(orderCalcDto.getSalesModel());
        commissionPlanQueryReq.setChannelCode(orderCalcDto.getChannelCalcNo());
        commissionPlanQueryReq.setSaleGrpCode(orderCalcDto.getSalesOrganization());
        commissionPlanQueryReq.setStoreCode(orderCalcDto.getShopNo());
        commissionPlanQueryReq.setOrderCreateTime(orderCalcDto.getPayDate().getTime());
        commissionPlanQueryReq.setBusinessFlag(orderCalcDto.getDemanderCode());
        commissionPlanQueryReq.setOrderId(orderCalcDto.getOrderId());
        
        if(!StringUtils.isEmpty(orderCalcDto.getChannelCalcNo()) && orderCalcDto.getChannelCalcNo().equals(BaseConstants.PLAN_ORDER_CHANNEL_CALC_O2O) ){
        	commissionPlanQueryReq.setPurchaseOrgCode(null);
        	commissionPlanQueryReq.setSupplierCode(null);
        	commissionPlanQueryReq.setPurchaseOrderType(null);
        	commissionPlanQueryReq.setSaleGrpCode(null);
        }else{
       	    commissionPlanQueryReq.setBusinessFlag(null);
        }
        
        ArrayList<CommissionPlanQueryReq> arrayList = new ArrayList<>(1);
        arrayList.add(commissionPlanQueryReq);
        return arrayList;
    }

    /**
     * 封装数据
     *
     * @param commissionPlanQueryResps
     * @return
     */
    public List<PlanDto> dealPlanDtos(List<CommissionPlanQueryResp> commissionPlanQueryResps, ContractDetailVO contractDetail) {
        if (CollectionUtils.isEmpty(commissionPlanQueryResps)) {
            log.info("查询计划返回为空");
            return null;
        }
        ArrayList<PlanDto> planDtos = new ArrayList<>(commissionPlanQueryResps.size());
        for (CommissionPlanQueryResp commissionPlanQueryResp : commissionPlanQueryResps) {
            log.info("planId:{}, mainPlanId:{}, 计划详情:{}", commissionPlanQueryResp.getPlanId(), commissionPlanQueryResp.getMainPlanId(), commissionPlanQueryResp);
            // 计划信息封装
            PlanDto planDto = getPlanDtoByPlan(commissionPlanQueryResp);
            OrderCalcDto orderCalcDto = CalcLocal.getLocalDto().getOrderCalcDto();
            ProblemDto problemDto = new ProblemDto(orderCalcDto.getOrderId(), orderCalcDto.getChannelCalcNo(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
            // 合同信息封装
            switch (commissionPlanQueryResp.getPlanType()) {
                case BaseConstants.PLAN_NO_RROMOTION_TYPE: // 无促 封装 合同信息
                    ContractPolicyVO contractPolicy = contractDetail.getContractPolicy();
                    if (contractPolicy == null) {
                        String msg = String.format("计划id: %s, 计划类型(无促): %s, 未匹配到合同信息.", planDto.getPlanId(), planDto.getPromotionsType());
                        log.info(msg);
                        problemDto.setDescription(msg);
                        problemDto.setPlanId(problemDto.getPlanId());
                        problemService.addData(problemDto, ProblemEnum.CODE_101);
                        continue;
                    }
                    planDto.setContractCode(contractPolicy.getContractCode()); // 合同号
                    planDto.setContractPurchaseCode(contractPolicy.getBuyOrgCode()); // 合同所属采购组织编码
                    planDto.setCompanyCategoryCode(contractPolicy.getCompanyCode()); // 公司类别编码
                    planDto.setCompanyCategoryName(contractPolicy.getCompanyName()); // 公司类别名称
                    planDto.setBrandCode(contractPolicy.getBrandCode()); // 品牌编码
                    planDto.setBrandName(contractPolicy.getBrandName()); // 品牌名称
                    planDto.setCategoryLevelTwo(contractPolicy.getClassCode()); // 二级品类编码
                    planDto.setContractSupplierCode(contractPolicy.getSuppCode()); // 供应商编码
                    planDto.setSupplierName(contractPolicy.getSuppName()); // 供应商名称
                    planDto.setContractStartTime(contractPolicy.getEffectStartDate()); // 合同有效开始时间
                    planDto.setContractEndTime(contractPolicy.getEffectEndDate()); // 合同有效结束时间
                    HashMap<String, Object> policy = dealPolicy(contractPolicy.getPolicies());
                    if (null == policy) {
                        String msg = String.format("计划id:%s, 计划类型(无促):%s, 合同:%s, 政策编码、点位为空.", commissionPlanQueryResp.getPlanId(), commissionPlanQueryResp.getPlanType(), contractPolicy.getContractCode());
                        log.info(msg);
                        problemDto.setDescription(msg);
                        problemDto.setPlanId(commissionPlanQueryResp.getPlanId());
                        problemService.addData(problemDto, ProblemEnum.CODE_101);
                        continue;
                    }
                    planDto.setPolicyCode(policy.get("policyCode").toString());
                    //policy.get("policyValue")==>当 policyCode 是 195 605 时，表示是点位，当 policyCode 是 197 时表示是台返
                    if (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(policy.get("policyCode")) || BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(policy.get("policyCode"))) {
                        planDto.setPolicyRatio(new BigDecimal(policy.get("policyValue").toString())); // 政策点位
                    } else {
                        planDto.setSingleStandard(new BigDecimal(String.valueOf(policy.get("policyValue"))).multiply(new BigDecimal(100))); // 单台标准，该字段表示的是固额。单位是元，我们需要转换成分
                    }

                    planDto.setContractClass(contractPolicy.getDocumentType()); // 合同类型，用来区分是否是流水倒扣合同
                    break;
                case BaseConstants.PLAN_NO_DIFFERENT_TYPE: // 非差异化 封装 合同信息
                    ContractPolicyVO policyVO = contractDetail.getContractPolicy();
                    if (policyVO == null) {
                        String msg = String.format("计划id: %s, 计划类型(非差异化): %s, 未匹配到合同信息.", planDto.getMainId(), planDto.getPromotionsType());
                        log.info(msg);
                        problemDto.setDescription(msg);
                        problemDto.setPlanId(problemDto.getPlanId());
                        problemService.addData(problemDto, ProblemEnum.CODE_101);
                        continue;
                    }
                    planDto.setContractCode(policyVO.getContractCode()); // 合同号
                    planDto.setContractPurchaseCode(policyVO.getBuyOrgCode()); // 合同所属采购组织编码
                    planDto.setCompanyCategoryCode(policyVO.getCompanyCode()); // 公司类别编码
                    planDto.setCompanyCategoryName(policyVO.getCompanyName()); // 公司类别名称
                    planDto.setBrandCode(policyVO.getBrandCode()); // 品牌编码
                    planDto.setBrandName(policyVO.getBrandName()); // 品牌名称
                    planDto.setCategoryLevelTwo(policyVO.getClassCode()); // 二级品类编码
                    planDto.setContractSupplierCode(policyVO.getSuppCode()); // 供应商编码
                    planDto.setSupplierName(policyVO.getSuppName()); // 供应商名称
                    planDto.setContractStartTime(policyVO.getEffectStartDate()); // 合同有效开始时间
                    planDto.setContractEndTime(policyVO.getEffectEndDate()); // 合同有效结束时间
                    planDto.setContractClass(policyVO.getDocumentType()); // 合同类型，用来区分是否是流水倒扣合同
                    break;
                // 差异化 封装 主推函的信息
                case BaseConstants.PLAN_DIFFERENT_TYPE:
                    CommissionVO commission = contractDetail.getCommission();
                    if (commission == null) {
                        String msg = String.format("计划id: %s, 计划类型(差异化): %s, 未匹配到主推函信息.", planDto.getMainId(), planDto.getPromotionsType());
                        log.info(msg);
                        problemDto.setDescription(msg);
                        problemDto.setPlanId(problemDto.getPlanId());
                        problemService.addData(problemDto, ProblemEnum.CODE_101);
                        continue;
                    }
                    if (StringUtils.isNotEmpty(commission.getContractCode())) {
                        planDto.setContractCode(commission.getContractCode()); // 合同号
                    }
                    planDto.setContractClass(commission.getDocumentType()); // 合同类型，用来区分是否是流水倒扣合同
                    planDto.setExtraType(Integer.valueOf(BaseConstants.PLAN_SIGN_LETTER_TYPE)); // 合同+有函
                    planDto.setExtraNum(commission.getProtocolCode()); // 函号
                    planDto.setCategoryLevelTwo(commission.getClassCode()); // 品类编码？？二三四级都有可能
                    planDto.setBrandCode(commission.getBrandCode()); // 品牌编码
                    planDto.setBrandName(commission.getBrandName()); // 品牌名称
                    planDto.setExtraCompanyCode(commission.getCompanyCode()); // 公司编码
                    planDto.setExtraPurchaseCode(commission.getBuyOrgCode()); // 采购组织编码
                    planDto.setExtraSupplierCode(commission.getSuppCode()); // 供应商编码
                    planDto.setSupplierName(commission.getSuppName()); // 函的供应商名称
                    planDto.setAddMonthlyRebate(commission.getAddMonthlyRebate()); // 新增月返
                    planDto.setAddEachRebate(commission.getAddEachRebate().multiply(new BigDecimal(100)).longValue()); // 新增台返
                    planDto.setOfferPrice(commission.getOfferPrice().multiply(new BigDecimal(100)).longValue()); // 供价，单位为元
                    break;
                // 带单 封装 带单函信息
                case BaseConstants.PLAN_REPLACE_TYPE:
                    ConfirmationVO confirmation = contractDetail.getConfirmation();
                    if (confirmation == null) {
                        String msg = String.format("计划id: %s, 计划类型(带单): %s, 未匹配到带单函信息.", planDto.getPlanId(), planDto.getPromotionsType());
                        log.info(msg);
                        problemDto.setDescription(msg);
                        problemDto.setPlanId(problemDto.getPlanId());
                        problemService.addData(problemDto, ProblemEnum.CODE_101);
                        continue;
                    }
                    planDto.setContractCode(confirmation.getContractCode()); // 合同号
                    planDto.setContractClass(confirmation.getDocumentType()); // 合同类型，用来区分是否是流水倒扣合同
                    planDto.setExtraType(Integer.valueOf(BaseConstants.PLAN_SIGN_LETTER_TYPE)); // 合同+有函
                    planDto.setExtraNum(confirmation.getConfirmationNo()); // 函号
                    planDto.setCompanyCategoryCode(confirmation.getCompanyCode()); // 公司编码
                    planDto.setExtraCompanyCode(confirmation.getCompanyCode()); // 公司编码
                    planDto.setExtraPurchaseCode(confirmation.getBuyOrgCode()); // 采购组织编码
                    planDto.setExtraSupplierCode(confirmation.getSuppCode()); // 供应商编码
                    planDto.setSupplierName(confirmation.getSuppName()); // 函的供应商名称
                    planDto.setCategoryLevelTwo(confirmation.getClassTwo()); // 品类编码？？二三四级都有可能
                    planDto.setBrandCode(confirmation.getBrandCode()); // 品牌编码
                    planDto.setSingleStandard(confirmation.getSingleStandard().multiply(new BigDecimal(100))); // 单台标准
                    planDto.setIssueRate(confirmation.getDistributionRate()); // 带单的发放比例取函上的  比例0.7即70%
                    planDto.setCurrentPrice(confirmation.getLimitPrice().multiply(new BigDecimal(100)).longValue()); // 计提现价需要取函上的计提现价，此处的计提现价将会覆盖上面计划中的计提现价
                    break;
            }
            planDtos.add(planDto);
        }
        return planDtos;
    }

    /**
     * 根据计划信息封装 planDto
     *
     * @param commissionPlanQueryResp
     * @return planDto
     */
    private PlanDto getPlanDtoByPlan(CommissionPlanQueryResp commissionPlanQueryResp) {
        PlanDto planDto = new PlanDto();
        planDto.setPlanId(Long.valueOf(commissionPlanQueryResp.getPlanId())); // 计划id
        planDto.setPlanDetailId(Long.valueOf(commissionPlanQueryResp.getPlanDetailId()));
        // 签约类型
        switch (commissionPlanQueryResp.getPlanType()) {
            case BaseConstants.PLAN_DIFFERENT_TYPE:
            case BaseConstants.PLAN_REPLACE_TYPE:
                planDto.setContractType(BaseConstants.PLAN_SIGN_LETTER_TYPE);
                break;
            case BaseConstants.PLAN_NO_DIFFERENT_TYPE:
                // 供应商承担
                if (BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE.equals(commissionPlanQueryResp.getPlanSource())) {
                    planDto.setContractType(BaseConstants.PLAN_SIGN_NO_LETTER_TYPE);
                } else {
                    // 国美承担
                    planDto.setContractType(BaseConstants.PLAN_SIGN_CONTRACT_TYPE);
                }
                break;
            case BaseConstants.PLAN_NO_RROMOTION_TYPE:
                planDto.setContractType(BaseConstants.PLAN_SIGN_CONTRACT_TYPE);
                break;
        }
        //差异化或者非差
        boolean flag = BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType())
                || BaseConstants.PLAN_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType());
        if (flag) {
            planDto.setMainId(Long.valueOf(commissionPlanQueryResp.getMainPlanId())); // 主计划id
            planDto.setMainPlanDetailId(commissionPlanQueryResp.getMainPlanDetailId());
            planDto.setCurrentPrice(new BigDecimal(commissionPlanQueryResp.getLimitPrice()).multiply(new BigDecimal(100)).longValue()); // 计提限价
        }
        planDto.setPromotionsType(Integer.valueOf(commissionPlanQueryResp.getPlanType())); // 计划类型/促销费类型
        //无促、差异化、非差 有计提限价
        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(commissionPlanQueryResp.getPlanType())) {
            planDto.setCurrentPrice(0L); // 无促（此字段没有默认值为0）、差异化、非差==>这三个类型会有值
            planDto.setZValue(new BigDecimal(0)); // Z值，百分比
            planDto.setMValue(new BigDecimal(0)); // M值，百分比
        } else {
            planDto.setZValue(new BigDecimal(commissionPlanQueryResp.getGrantPercentZ())); // Z值，百分比默认为 70 即是70%
            planDto.setMValue(new BigDecimal(commissionPlanQueryResp.getGrantPercentM())); // M值，百分比默认为 70 即是70%
        }
        // 计提基数 入参，0实付金额,1销售金额===>对应提成系统 0销售金额,1实付金额
        planDto.setProvisionType(Integer.valueOf(commissionPlanQueryResp.getAccrualBase()) == BaseConstants.PLAN_PROVISION_SELL ? BaseConstants.PLAN_PROVISION_REAL : BaseConstants.PLAN_PROVISION_SELL);
        planDto.setXValue(new BigDecimal(commissionPlanQueryResp.getGrantPercentX())); // X值，百分比 70 即是70%
        planDto.setStartTime(new Date(commissionPlanQueryResp.getEffectStartDate())); // 生效时间
        planDto.setEndTime(new Date(commissionPlanQueryResp.getEffectEndDate())); // 失效时间
        //无促和差异化
        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(commissionPlanQueryResp.getPlanType())
                || BaseConstants.PLAN_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType())) {
            planDto.setIssueRate(new BigDecimal(commissionPlanQueryResp.getTotalGrantPercent())); // 发放比例，百分比，无促和差异化有这个字段 70 即是70%
        }
        if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType())) {
            planDto.setAdditionalAward(new BigDecimal(commissionPlanQueryResp.getAdditionalAward())); // 追加比例
        }
        if (BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType())) {
            planDto.setSingleStandardMoney(new BigDecimal(commissionPlanQueryResp.getSinglePromotionFee()).multiply(new BigDecimal(100)).longValue()); // 单台促销费 转为单位：分
        }
        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(commissionPlanQueryResp.getPlanType())
                || BaseConstants.PLAN_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType())
                || BaseConstants.PLAN_REPLACE_TYPE.equals(commissionPlanQueryResp.getPlanType())) {
            planDto.setExpenseOfferType(Integer.valueOf(BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE)); // 无促默认供应商承担
        } else {
            planDto.setExpenseOfferType(Integer.valueOf(commissionPlanQueryResp.getPlanSource())); // 费用类型（0 供应商承担、1 国美承担、2 国美预算、3 营销预算）
        }

        if (BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(commissionPlanQueryResp.getPlanType())
                || BaseConstants.PLAN_EXPENSE_OFFER_ONE_TYPE.equals(commissionPlanQueryResp.getPlanSource())) {
            planDto.setIsOffset(commissionPlanQueryResp.getCjzg()); // 是否冲减综控
        }
        return planDto;
    }

    /**
     * 处理政策编码优先级问题
     * Z605>Z195>Z197
     *
     * @param policies
     * @return
     */
    public HashMap<String, Object> dealPolicy(List<Policy> policies) {
        if (CollectionUtils.isEmpty(policies)) {
            log.info("政策编码为空");
            return null;
        }
        HashMap<String, Object> rtnMap = new HashMap<>(2);
        for (Policy policy : policies) {
            if (BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(policy.getPolicyCode())) {
                rtnMap.put("policyCode", BaseConstants.PLAN_EXTRA_POLICY_CODE_605);
                rtnMap.put("policyValue", policy.getPolicyValue());
                return rtnMap;
            }
        }
        for (Policy policy : policies) {
            if (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(policy.getPolicyCode())) {
                rtnMap.put("policyCode", BaseConstants.PLAN_EXTRA_POLICY_CODE_195);
                rtnMap.put("policyValue", policy.getPolicyValue());
                return rtnMap;
            }
        }
        for (Policy policy : policies) {
            if (BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(policy.getPolicyCode())) {
                rtnMap.put("policyCode", BaseConstants.PLAN_EXTRA_POLICY_CODE_197);
                rtnMap.put("policyValue", policy.getPolicyValue());
                return rtnMap;
            }
        }
        return null;
    }

    @Override
    public TerminatePlanResDto terminatePlan(TerminatePlanReqDto terminatePlanReqDto) {
        TerminatePlanResDto res = new TerminatePlanResDto();

        CommissionPlanTerminateReq req = new CommissionPlanTerminateReq();
        req.setPlanId(terminatePlanReqDto.getPlanId());
        req.setRequestUuid(UUID.randomUUID().toString());
        req.setRequesterCode(systemId);
        req.setReasonCode("1");//固定值，表示因为资源不足终止计划
        boolean success = false;
        String reqJson = null;
        try {
            reqJson = JSON.toJSONString(req);
            log.info("调用终止非差异化计划接口开始planId:{},req:{}", req.getPlanId(), reqJson);
            success = commissionPlanQueryFacade.planTerminate(req);
            log.info("调用终止非差异化计划接口完成planId:{},req:{},res:{}", req.getPlanId(), reqJson, success);
        } catch (Exception e) {
            log.error("调用终止非差异化计划接口异常planId:{},req:{}", req.getPlanId(), reqJson, e);
        }

        res.setSuccess(success);
        return res;
    }

    @Override
    public ClientResultDTO<ResourceReturnResDto> returnResource(ResourceReturnReqDto reqDto) {
        if (reqDto == null || reqDto.getRequestUuid() == null || reqDto.getPlanId() == null || reqDto.getReturnAmount() == null) {
            throw new IllegalArgumentException("调用cpqs后台-释放预算接口-入参错误");
        }

        log.info("调用cpqs后台-释放预算接口开始requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto);
        String cpqsBudgetReleaseUniqueKey = CacheKeyConstants.getCpqsBudgetReleaseUniqueKey(reqDto.getRequestUuid());
        try {
            //幂等校验
            Long value = gcacheUtil.distributedLockAtom(cpqsBudgetReleaseUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
            if (value == 1) {
                //加锁
                String cpqsPlanBudgetLock = CacheKeyConstants.getCpqsPlanBudgetLock(reqDto.getPlanId());
                RedisLock redisLock = redisLockHelper.getLock(cpqsPlanBudgetLock);
                if (!redisLock.lock()) {
                    return ClientResultDTO.error(-1, String.format("调用cpqs后台-释放预算加锁失败requestUuid:%s,planId:%s,reqDto:%s", reqDto.getRequestUuid(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
                }

                try {
                    String planBudgetKey = CacheKeyConstants.getCpqsPlanBudgetKey(reqDto.getPlanId());
                    boolean isExist = gcacheUtil.exists(planBudgetKey);
                    if (isExist) {
                        log.info("调用cpqs后台-释放预算开始requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto);
                        Long surplusAmount = gcacheUtil.incrBy(planBudgetKey, reqDto.getReturnAmount().longValue());
                        log.info("调用cpqs后台-释放预算完成requestUuid:{},planId:{},reqDto:{},surplusAmount:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto, surplusAmount);
                    } else {
                        ResourceReturnReq req = new ResourceReturnReq();
                        req.setRequestUuid(reqDto.getRequestUuid());
                        req.setPlanId(reqDto.getPlanId());
                        req.setRequesterCode(systemId);
                        req.setReturnAmount(reqDto.getReturnAmount().toString());
                        String reqJson = JSON.toJSONString(req);
                        log.info("调用归还非差资源接口开始requestUuid:{},planId:{},req:{}", reqDto.getRequestUuid(), req.getPlanId(), reqJson);
                        boolean success = commissionPlanQueryFacade.resourceReturn(req);
                        log.info("调用归还非差资源接口完成requestUuid:{},planId:{},req:{},res:{}", reqDto.getRequestUuid(), req.getPlanId(), reqJson, success);
                        if (!success) {
                            throw new BusinessException(String.format("调用cpqs后台-释放预算接口失败requestUuid:%s,planId:%s,reqDto:%s,result:%s", reqDto.getRequestUuid(), reqDto.getPlanId(), JSON.toJSONString(reqDto), success));
                        }
                    }
                } finally {
                    redisLock.unlock();
                }
            }
            log.info("调用cpqs后台-释放预算接口结束requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto);
            return ClientResultDTO.success();
        } catch (Exception e) {
            log.error("调用cpqs后台-释放预算接口异常requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto, e);
            try {
                gcacheUtil.deleteKey(new String[]{cpqsBudgetReleaseUniqueKey});
            } catch (Exception ex) {
                log.error("调用cpqs后台-释放预算接口,删除防重键异常requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto, ex);
            }
            return ClientResultDTO.error(-1, String.format("调用cpqs后台-释放预算接口异常requestUuid:%s,planId:%s,reqDto:%s", reqDto.getRequestUuid(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
        }
    }

    @Override
    public ClientResultDTO<OccupyBudgetResDto> occupyResource(ResourceOccupyReqDto reqDto) {
        if (reqDto == null || reqDto.getRequestUuid() == null || reqDto.getPlanId() == null || reqDto.getOccupyAmount() == null) {
            throw new IllegalArgumentException("调用cpqs后台-占用预算接口-入参错误");
        }

        log.info("调用cpqs后台-占用预算接口开始requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto);
        String cpqsBudgetOccupyUniqueKey = CacheKeyConstants.getCpqsBudgetOccupyUniqueKey(reqDto.getRequestUuid());
        try {
            //幂等校验
            Long value = gcacheUtil.distributedLockAtom(cpqsBudgetOccupyUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
            if (value == 1) {
                //加锁
                String cpqsPlanBudgetLock = CacheKeyConstants.getCpqsPlanBudgetLock(reqDto.getPlanId());
                RedisLock redisLock = redisLockHelper.getLock(cpqsPlanBudgetLock);
                if (!redisLock.lock()) {
                    return ClientResultDTO.error(-1, String.format("调用cpqs后台-占用预算加锁失败requestUuid:%s,planId:%s,reqDto:%s", reqDto.getRequestUuid(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
                }

                try {
                    String planBudgetKey = CacheKeyConstants.getCpqsPlanBudgetKey(reqDto.getPlanId());
                    String budgetAmount = gcacheUtil.getKeyValue(planBudgetKey);
                    log.info("调用cpqs后台-占用预算,计划查询金额requestUuid:{},planId:{},budgetAmount:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), budgetAmount, reqDto);

                    //校验预算金额
                    boolean result = BigDecimalUtils.greaterEqualThan(BigDecimalUtils.toBigDecimal(budgetAmount), reqDto.getOccupyAmount());
                    if (result) {
                        Long surplusAmount = gcacheUtil.decrBy(planBudgetKey, reqDto.getOccupyAmount().longValue());
                        log.info("调用cpqs后台-占用预算,计划剩余金额requestUuid:{},planId:{},budgetAmount:{}.surplusAmount:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), budgetAmount, surplusAmount, reqDto);
                        OccupyBudgetResDto occupyBudgetResDto = new OccupyBudgetResDto();
                        occupyBudgetResDto.setSurplusAmount(surplusAmount);
                        return ClientResultDTO.success(occupyBudgetResDto);
                    } else {
                        return ClientResultDTO.error(1, "占用预算失败,金额不足");
                    }
                } finally {
                    redisLock.unlock();
                }
            }
            return ClientResultDTO.success(null);
        } catch (Exception e) {
            log.error("调用cpqs后台-占用预算接口异常requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto, e);
            try {
                gcacheUtil.deleteKey(new String[]{cpqsBudgetOccupyUniqueKey});
            } catch (Exception ex) {
                log.error("调用cpqs后台-占用预算接口,删除防重键异常requestUuid:{},planId:{},reqDto:{}", reqDto.getRequestUuid(), reqDto.getPlanId(), reqDto, ex);
            }
            return ClientResultDTO.error(-1, String.format("调用erm后台-占用预算接口异常requestUuid:%s,planId:%s,reqDto:%s", reqDto.getRequestUuid(), reqDto.getPlanId(), JSON.toJSONString(reqDto)));
        }
    }


    // 根据四级品类编码查询十大品类编码
    public DivisionDto getDivisionByFourthCode(String categoryOffline) {
        log.info(String.format("调用品牌cod获取十大品类编码, 参数:%s", categoryOffline));
        DivisionVO divisionByFourthCode = orderContractQueryService.getDivisionByFourthCode(categoryOffline);
        log.info(String.format("调用品牌cod获取十大品类编码, 参数:%s, 反参:%s", categoryOffline, JSONObject.toJSONString(divisionByFourthCode)));
        if (divisionByFourthCode == null) {
            return null;
        } else {
            DivisionDto dto = new DivisionDto();
            dto.setDivisionCode(divisionByFourthCode.getDivisionCode());
            dto.setDivisionName(divisionByFourthCode.getDivisionName());
            return dto;
        }
    }

	@Override
	public List<PlanDto> queryPlanByParam(OrderCalcDto orderCalcDto) {
        ArrayList<CommissionPlanQueryReq> arrayList = getCommissionPlanQueryReqs(orderCalcDto,null);

        log.info("查询综合体dubbo计划入参,requestParam:{}", JSON.toJSONString(arrayList));
        List<CommissionPlanQueryResp> commissionPlanQueryResps = commissionPlanQueryFacade.queryPlans(arrayList);
        log.info("查询综合体dubbo计划返参,responseParam:{}", JSON.toJSONString(commissionPlanQueryResps));
        return dealPlanDtos(commissionPlanQueryResps);
	}

    /**
     * 针对12渠道计划封装
     * @param commissionPlanQueryResps
     * @return
     */
    public List<PlanDto> dealPlanDtos(List<CommissionPlanQueryResp> commissionPlanQueryResps){
        if (CollectionUtils.isEmpty(commissionPlanQueryResps)) {
            log.info("查询计划返回为空");
            return null;
        }
        ArrayList<PlanDto> planDtos = new ArrayList<>(commissionPlanQueryResps.size());
        for (CommissionPlanQueryResp commissionPlanQueryResp : commissionPlanQueryResps) {
            log.info("planId:{},计划详情:{}", commissionPlanQueryResp.getPlanId(), commissionPlanQueryResp);
            // 计划信息封装
            PlanDto planDto = getPlanDtoByPlanO2O(commissionPlanQueryResp);
            planDtos.add(planDto);
        }
        return planDtos;
    }
    /**
     * 针对12渠道计划封装
     * @param commissionPlanQueryResp
     * @return
     */
	private PlanDto getPlanDtoByPlanO2O(CommissionPlanQueryResp commissionPlanQueryResp) {
		PlanDto planDto = new PlanDto();
		planDto.setPlanId(StringUtils.isEmpty(commissionPlanQueryResp.getPlanId())? null : Long.valueOf(commissionPlanQueryResp.getPlanId())); // 计划id
		planDto.setPlanDetailId(StringUtils.isEmpty(commissionPlanQueryResp.getPlanDetailId())? null : Long.valueOf(commissionPlanQueryResp.getPlanDetailId()));//计划行项目ID
		planDto.setMainId(StringUtils.isEmpty(commissionPlanQueryResp.getMainPlanId())? null : Long.valueOf(commissionPlanQueryResp.getMainPlanId())); // 主计划id
		planDto.setPromotionsType(Integer.valueOf(commissionPlanQueryResp.getPlanType())); // 计划类型/促销费类型
		if(StringUtils.isEmpty(commissionPlanQueryResp.getLimitPrice())){
			planDto.setCurrentPrice(0L);
		}else{
			planDto.setCurrentPrice(new BigDecimal(commissionPlanQueryResp.getLimitPrice()).multiply(new BigDecimal(100)).longValue());
		}
		// 计提基数 入参，0实付金额,1销售金额===>对应提成系统 0销售金额,1实付金额
		planDto.setProvisionType(
				Integer.valueOf(commissionPlanQueryResp.getAccrualBase()) == BaseConstants.PLAN_PROVISION_SELL
						? BaseConstants.PLAN_PROVISION_REAL : BaseConstants.PLAN_PROVISION_SELL);
		if(!StringUtils.isEmpty(commissionPlanQueryResp.getGrantPercentZ())){
			planDto.setZValue(new BigDecimal(commissionPlanQueryResp.getGrantPercentZ())); // Z值
		}
		if(!StringUtils.isEmpty(commissionPlanQueryResp.getGrantPercentM())){
			planDto.setMValue(new BigDecimal(commissionPlanQueryResp.getGrantPercentM())); // M值
		}
		planDto.setStartTime(new Date(commissionPlanQueryResp.getEffectStartDate())); // 生效时间
		planDto.setEndTime(new Date(commissionPlanQueryResp.getEffectEndDate())); // 失效时间
		planDto.setExpenseOfferType(Integer.valueOf(commissionPlanQueryResp.getPlanSource())); // 费用类型（0 供应商承担、1 国美承担、2 国美预算、3 营销预算）
		planDto.setIsOffset(commissionPlanQueryResp.getCjzg()); // 是否冲减综控
		return planDto;
	}
}
