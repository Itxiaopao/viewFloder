package com.gome.crp.calc.mq.producer;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.bigDataDto.CalcResultDetailDto;
import com.gome.crp.calc.dto.bigDataDto.CalcResultDto;
import com.gome.crp.calc.dto.bigDataDto.SendBigDataDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.mq.core.producer.MQProducerSendMsgProcessor;
import com.gome.crp.calc.mq.core.producer.MQSendResult;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 提奖订单信息发送大数据
 */
@Component
@Slf4j
public class SendBigDataProducerProcessImpl extends MQProducerSendMsgProcessor {

    @Value("${gome.crp.bigdata.order.topic}")
    private String topic;
    @Value("${gome.crp.bigdata.order.tag}")
    private String tag;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;

    /**
     * 推送大数据提奖信息
     *
     * @param calcResultDto 提奖信息 detail
     */
    public void sendBigData(CalcResultDto calcResultDto) {
        log.info("推送大数据入参: {}", calcResultDto);
        // 正向单
        boolean CO_DL_Status = BaseConstants.ORDER_CO_STATUS.equals(calcResultDto.getGomeStatus()) || BaseConstants.ORDER_DL_STATUS.equals(calcResultDto.getGomeStatus());
        if (CO_DL_Status) { // 正向单
            if (calcResultDto.getJobStatus() != BaseConstants.CRD_JOB_STATUS_2) {
                log.error("推大数据的节点不正确。jobStatus=1只能推CO和DL的订单。订单号:{},skuNo{},detailId{}", calcResultDto.getOrder_id(),
                        calcResultDto.getSku_no(), calcResultDto.getDetail_id());
                return;
            }
        } else { // 逆向单  CL_RV_RCO
            // 逆向单，不需要管 jobStatus
        }

        SendBigDataDto sendBigDataDto = new SendBigDataDto();
        BeanUtils.copyProperties(calcResultDto, sendBigDataDto);
        // jobStatus、gomeStatus、submittedDate 这几个字段没定义在结构体内, 不需要传
        sendBigDataDto.setJobStatus(null);
        sendBigDataDto.setGomeStatus(null);
        sendBigDataDto.setSubmittedDate(null);

        Date date = new Date();
        String strDate = DateUtils.formatDateTime(date);
        sendBigDataDto.setSend_time(strDate);
        sendBigDataDto.setUpdate_time(strDate); // updateTime 和 sendTime 需要一致
        sendBigDataDto.setOrder_create_time(calcResultDto.getSubmittedDate());
        switch (calcResultDto.getGomeStatus()) {
            case BaseConstants.ORDER_CO_STATUS:
            case BaseConstants.ORDER_DL_STATUS:
                sendBigDataDto.setOrder_sign(BaseConstants.BIGDATA_ORDER_STATUS_0);
                break;
            case BaseConstants.ORDER_CL_STATUS:
            case BaseConstants.ORDER_RT_STATUS:
            case BaseConstants.ORDER_RCO_STATUS:
                sendBigDataDto.setOrder_sign(BaseConstants.BIGDATA_ORDER_STATUS_1);
                break;
        }
        sendBigDataDto.setCompute_status(BaseConstants.BIGDATA_COMPUTE_STATUS_0);
        if (sendBigDataDto.getReturn_order_id() == null) {
            sendBigDataDto.setReturn_order_id(""); // 正向单时，return_order_id 可能为 null，这时传空字符串
        }
        // 逆向逻辑，计算结果id加个负号
        if (!CO_DL_Status) {
            List<CalcResultDetailDto> datas = sendBigDataDto.getDatas();
            for (CalcResultDetailDto data : datas) {
                data.setVitae_id("-" + data.getVitae_id());
                // 逆向单的金额需要是负数，所以，当入参金额大于 0 的时候，此处做判断兼容
                if (new BigDecimal(data.getProfit_amount()).compareTo(new BigDecimal(0)) == 1) {
                    data.setProfit_amount("-" + data.getProfit_amount());
                }
            }
        }

        sendBigData(JSON.toJSONString(sendBigDataDto),calcResultDto);
    }

    /**
     * 异步推送大数据，保证最终成功
     *
     * @param jsonString 消息体
     */
    public void sendBigData(String jsonString, CalcResultDto calcResultDto) {
        try {
            log.info("提成计算推送大数据，topic：{}, tag:{}, param：{}", topic, tag, jsonString);
            MQSendResult send = syncSendBigData(jsonString);

            if (!send.isSendSuccess()) {
                log.info("提成计算推送大数据失败");
                CalcRetry calcRetry = new CalcRetry();
                calcRetry.setType(RetryJobEnum.ORDERCALC.getCode());
                calcRetry.setOrderId(calcResultDto.getOrder_id());
                calcRetry.setSapDetailId(calcResultDto.getSap_detail_id());
                calcRetry.setMsgBody(jsonString);
                calcRetry.setGomeStatus(calcResultDto.getGomeStatus());
                calcRetry.setFailureReason(send.getErrMsg());
                calcRetryCopeService.insertRetry(calcRetry);
            }
            log.info("提成计算推送大数据成功");
        } catch (Exception e) {
            log.error("推送大数据提成计算失败，异常信息", e);

            CalcRetry calcRetry = new CalcRetry();
            calcRetry.setType(RetryJobEnum.BIGDATACALC.getCode());
            calcRetry.setOrderId(calcResultDto.getOrder_id());
            calcRetry.setSapDetailId(calcResultDto.getSap_detail_id());
            calcRetry.setMsgBody(jsonString);
            calcRetry.setGomeStatus(calcResultDto.getGomeStatus());
            calcRetry.setFailureReason(e.getMessage());
            calcRetryCopeService.insertRetry(calcRetry);
        }
    }

    /**
     * 推送大数据，同步返回结果
     *
     * @param jsonString 消息体
     * @return MQSendResult
     * @see com.gome.crp.calc.mq.core.producer.MQSendResult
     */
    public MQSendResult syncSendBigData(String jsonString) {
        log.info("同步推送大数据，topic：{}, tag:{}, param：{}", topic, tag, jsonString);
        MQSendResult send = send(topic, tag, jsonString);
        log.info("同步推送大数据，消息id：{}", send.getMsgId());

        if (!send.isSendSuccess()) {
            log.info("同步推送大数据失败，消息id：{}", send.getMsgId());
        }

        return send;
    }

}
