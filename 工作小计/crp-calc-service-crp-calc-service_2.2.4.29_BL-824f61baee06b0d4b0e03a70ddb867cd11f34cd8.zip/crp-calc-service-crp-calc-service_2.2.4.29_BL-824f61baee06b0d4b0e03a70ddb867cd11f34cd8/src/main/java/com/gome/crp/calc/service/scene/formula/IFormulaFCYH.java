package com.gome.crp.calc.service.scene.formula;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.math.BigDecimal;

/**
 * 非差异化公式计算
 */
public interface IFormulaFCYH {

    // **********************************************************
    // FCYH
    // 非差异化
    // 提奖金额=单台促消费×销售数量×XYZM比例
    //***********************************************************
    BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene);


}
