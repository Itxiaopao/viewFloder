package com.gome.crp.calc.service.scene.formula.impl;

import com.gome.crp.calc.client.sap.impl.QueryPlanServiceImpl;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.formula.CategroyPointRateDto;
import com.gome.crp.calc.dto.formula.JTBasePriceDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.sapDto.DivisionDto;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.service.scene.formula.*;
import com.gome.crp.calc.service.scene.formula.utils.CalcCategreyProfitRate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.math.RoundingMode;


/**
 * 20200530 新计算公式
 */
@Slf4j
@Service
public class CalculatedFormulas implements ICalFormulas {

    @Autowired
    private IProblemService problemService;
    @Autowired
    private QueryPlanServiceImpl queryPlanService;
    @Autowired
    private CalcCategreyProfitRate calcCategreyProfitRate;
    @Autowired
    private ICalcRewardsService calcRewardsService;
    @Autowired
    private IFormulaCYH formulaCYH;
    @Autowired
    private IFormulaWC formulaWC;
    @Autowired
    private IFormulaFCYH formulaFCYH;
    @Autowired
    private IFormulaDD formulaDD;
    @Autowired
    private IFormulaO2O formulaO2O;
    @Autowired
    private IFormulaYB formulaYB;
    @Autowired
    private IFormulaYX formulaYX;


    // 百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);

    public CalculatedFormulas() {
    }

    // 计算结果
    public BigDecimal calculatedResult(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        // 促销费新型
        Integer promotionsType = planDto.getPromotionsType();

        log.info(String.format("计算公式-类型, orderId:%s, planId:%s, promotionType:%s",
                orderCalcDto.getOrderId(), planDto.getPlanId(), promotionsType));
        // 无促
        if(BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(promotionsType.toString())){
            ret = formulaWC.calc(orderCalcDto, planDto, scene);
            return ret;
        }
        // 差异化
        if(BaseConstants.PLAN_DIFFERENT_TYPE.equals(promotionsType.toString())){
            ret = formulaCYH.calc(orderCalcDto, planDto, scene);
            return ret;
        }
        // 非差
        if(BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(promotionsType.toString())){
            ret = formulaFCYH.calc(orderCalcDto, planDto, scene);
            return ret;
        }
        // 带单
        if(BaseConstants.PLAN_REPLACE_TYPE.equals(promotionsType.toString())){
            ret = formulaDD.calc(orderCalcDto, planDto, scene);
            return ret;
        }
        //O2O
        if(BaseConstants.PLAN_O2O_TYPE.equals(promotionsType.toString())){
            ret = formulaO2O.calc(orderCalcDto, planDto, scene);
            return ret;
        }

        //延保
        if(BaseConstants.PLAN_PROLONG_ASSURE_TYPE.equals(promotionsType.toString())){
            ret = formulaYB.calc(orderCalcDto, planDto, scene);
            return ret;
        }

        //营销
        if(BaseConstants.PLAN_MARKETING_PROMOTION_TYPE.equals(promotionsType.toString())){
            ret = formulaYX.calc(orderCalcDto, planDto, scene);
            return ret;
        }

        return ret;
    }

    
    public static void main(String[] args) {
        // this is test function
//        BigDecimal ret = BigDecimal.valueOf(0.0);
//
//    	ret = BigDecimal.valueOf(1).multiply(BigDecimal.valueOf(890)).multiply(BigDecimal.valueOf(10).multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
//	    System.out.println(ret.toString());
    }

}

