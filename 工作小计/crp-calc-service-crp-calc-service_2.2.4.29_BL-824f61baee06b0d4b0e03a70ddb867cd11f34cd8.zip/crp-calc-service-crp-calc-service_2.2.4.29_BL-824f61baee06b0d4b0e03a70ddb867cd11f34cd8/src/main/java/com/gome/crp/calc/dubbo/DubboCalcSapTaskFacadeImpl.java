package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboCalcSapTaskFacade;
import com.gome.crp.calc.service.job.IJobSapCompareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * SAP job SCAN
 *
 * @author libinbin9
 */
@Service
public class DubboCalcSapTaskFacadeImpl implements IDubboCalcSapTaskFacade {

    @Autowired
    private IJobSapCompareService jobSapCompareService;

    @Override
    public void scanNorm() {
        jobSapCompareService.scanNorm();

    }

    @Override
    public void scanUnSuc() {
        jobSapCompareService.scanUnSuc();

    }

    @Override
    public void scanNoDetect() {
        jobSapCompareService.scanNoDetect();
    }

    @Override
    public void scanFollowUp() {
        jobSapCompareService.scanFollowUp();
    }


}
