package com.gome.crp.calc.manager.employee;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gome.crp.calc.mybatis.model.EmployeeAttendance;
import com.gome.crp.calc.mybatis.service.impl.EmployeeAttendanceServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeAttendanceSynManager  {
    @Autowired
    private EmployeeAttendanceServiceImpl employeeAttendanceService;

    public Boolean insertEmployeeAttendance(EmployeeAttendance employeeAttendance){
        return employeeAttendanceService.save(employeeAttendance);
    }

    public List<EmployeeAttendance> queryEmployeeAttendanceByStaffCode(List<String> staffCode,String workMonth){
        QueryWrapper<EmployeeAttendance> queryWrapper = new QueryWrapper<EmployeeAttendance>().in("staff_code", staffCode).eq("work_month",workMonth);
        return employeeAttendanceService.list(queryWrapper);
    }

}
