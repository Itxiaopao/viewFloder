package com.gome.crp.calc.dto.contractDto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 合同
 */
@Data
public class ContractDto implements Serializable {
    private static final long serialVersionUID = 8565490408969313048L;

    private String contractCode;//合同号
    private String buyOrgCode;//采购组织编码
    private String suppCode;//供应商编码
    private String companyCode;//公司编码
    private String brandCode;//品牌编码
    private String classCode;//品类编码
    private String documentType;//合同类型
    private String buyGrpCode;//采购组
    private String className;//品类名称
    private String brandName;//品牌名称
    private String suppName;//供应商名称
    private String buyOrgName;//采购组织名称
    private String companyName;//公司名称
    private Date effectEndDate;//有效截至时间
    private Date effectStartDate;//有效开始时间
    private BigDecimal offerPrice;//供价 -- 订单批次合同信息有值 20200707
    private List<PoliciesDto> policies;//政策

}
