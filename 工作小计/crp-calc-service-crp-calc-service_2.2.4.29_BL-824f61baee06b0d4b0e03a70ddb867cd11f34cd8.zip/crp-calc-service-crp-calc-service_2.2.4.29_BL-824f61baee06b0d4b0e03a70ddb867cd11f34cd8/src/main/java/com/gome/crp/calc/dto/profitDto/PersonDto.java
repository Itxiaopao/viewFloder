package com.gome.crp.calc.dto.profitDto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 550349334828501684L;
	
	private String userId; // 用户id  部分为null
	private String staffCode;	//员工编码  部分为null
	
    private String staffClass; //员工类别（a:正式员工b:劳务派遣c:临时工d:促销员e:实习生f:退休返聘g:挂靠残疾人h:劳务用工i:加盟商员工j:加盟商促销员）
    private Integer staffLevel; //岗位类型（0集团,1大区,2一级分部,3二级分部,4门店,5dc,6售后,7异常）
    private String branchCodeOne; //一级分部
    private String branchCodeTwo; //二级分部
    private Integer newRetailStatus; //是否加盟店
	private Integer isMain; // 主营兼营，1主营；2兼营；
	private String storeCode;//获利人所在门店
	private String orderSupplier; //order供应商编码（供货商代码）
	private String staffSuppliers; //员工供应商编码 集 [,]隔开（供货商代码）
	private Integer profitBehaviorCode;//获利行为编码
}
