package com.gome.crp.calc.dto.ermDto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OccupyBudgetReqDto {
    private String messageId;
    private String planId;
    private BigDecimal amount;
}
