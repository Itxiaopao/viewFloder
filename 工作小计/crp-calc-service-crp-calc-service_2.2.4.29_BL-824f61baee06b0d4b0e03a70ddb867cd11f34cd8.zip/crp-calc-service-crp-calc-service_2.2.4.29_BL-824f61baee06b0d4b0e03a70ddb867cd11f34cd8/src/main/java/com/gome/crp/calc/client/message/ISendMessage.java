package com.gome.crp.calc.client.message;

import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;

public interface ISendMessage {

    /**
     * 异步发送报警信息，内部保证成功，失败入重推表，内部保证成功
     *
     * @param dto topic 邮件主题
     *            content 发送内容
     *            userList 邮件接受用户
     *            sendType 发送类型（1、邮件;2:微信报警(卡片形式); 3:微信报警(文本形式);）
     */
    void sendAsyncMsg(SendMessageDto dto);

    /**
     * 同步发送报警信息，返回发送成功失败
     *
     * @param dto topic 邮件主题
     *            content 发送内容
     *            userList 邮件接受用户
     *            sendType 发送类型（1、邮件;2:微信报警(卡片形式); 3:微信报警(文本形式);）
     *            
	 * @return Boolean
     */
    boolean sendSyncMsg(SendMessageDto dto);
}
