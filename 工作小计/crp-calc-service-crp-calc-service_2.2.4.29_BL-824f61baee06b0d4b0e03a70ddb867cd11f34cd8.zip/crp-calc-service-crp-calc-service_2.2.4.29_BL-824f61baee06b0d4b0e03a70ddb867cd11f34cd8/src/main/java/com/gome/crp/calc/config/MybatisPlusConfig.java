package com.gome.crp.calc.config;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.config.GlobalConfig;
import com.baomidou.mybatisplus.core.config.GlobalConfig.DbConfig;
import com.baomidou.mybatisplus.extension.plugins.OptimisticLockerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.extension.spring.MybatisSqlSessionFactoryBean;
import com.gome.crp.calc.filter.MybatisSqInterceptor;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import javax.sql.DataSource;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Mybatis Plus Config
 * 
 * @author lisuo
 */
@Configuration
@MapperScan({"com.gome.crp.calc.mybatis.mapper"})
public class MybatisPlusConfig {

	@Value("${mybatis-plus.config-location}")
	private String configLocation;
	@Value("${mybatis-plus.mapper-locations}")
	private String mapperLocations;
	@Value("${mybatis-plus.tablePrefix}")
	private String tablePrefix;
	@Value("${mybatis-plus.logicDeleteField}")
	private String logicDeleteField;
	
	private static final ResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();

	@Bean
	public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws Exception {
		// TODO 使用 MybatisSqlSessionFactoryBean 而不是 SqlSessionFactoryBean
		MybatisSqlSessionFactoryBean factory = new MybatisSqlSessionFactoryBean();
		factory.setDataSource(dataSource);
		//mybatis xml配置文件位置
		factory.setConfigLocation(getResources(configLocation)[0]);
		factory.setMapperLocations(getResources(mapperLocations));
		//mp 全局配置
		factory.setGlobalConfig(globalConfig());
		factory.setPlugins(plugins());
		
		factory.setTypeAliasesPackage("com.gome.crp.calc.mybatis.model");
		
		
		
		return factory.getObject();
	}
	
	private Interceptor [] plugins(){
		List<Interceptor> list = new ArrayList<>();
		//分页插件
		PaginationInterceptor interceptor = new PaginationInterceptor();
		//不限制分页查询条数
		interceptor.setLimit(-1);
		list.add(new PaginationInterceptor());
		//乐观锁插件
		list.add(new OptimisticLockerInterceptor());
		// 打印sql时间
		list.add(new MybatisSqInterceptor());
		
		Interceptor [] temp = new Interceptor[list.size()];
		for (int i = 0; i < list.size(); i++) {
			temp[i] = list.get(i);
		}
		return temp;
	}

	
	public GlobalConfig globalConfig() {
		GlobalConfig conf = new GlobalConfig();
		DbConfig dbConfig = new GlobalConfig.DbConfig();
		// 默认使用数据库自增主键生成ID
		dbConfig.setIdType(IdType.AUTO);
		// 默认带isDelete字段的model全部是逻辑删除,不带的物理删除
		dbConfig.setLogicDeleteField(logicDeleteField);
		//表名前缀
		dbConfig.setTablePrefix(tablePrefix);
		conf.setDbConfig(dbConfig);
		return conf;
	}
	
	private Resource[] getResources(String location) {
        try {
            return resourceResolver.getResources(location);
        } catch (IOException e) {
            return new Resource[0];
        }
    }
}
