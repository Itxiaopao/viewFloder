package com.gome.crp.calc.mq.consumer;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import com.gome.crp.calc.dto.threadLocal.LocalDto;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.boot.common.logging.trace.mq.MqUtil;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.mq.core.consumer.MQConsumeResult;
import com.gome.crp.calc.mybatis.mapper.OrderRecordMapper;
import com.gome.crp.calc.mybatis.model.OrderRecord;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.order.calc.dto.DeliveryDto;
import com.gome.crp.order.calc.dto.DetailGoodsDto;
import com.gome.crp.order.calc.dto.GoodsDto;
import com.gome.crp.order.calc.dto.OrderDto;
import com.gome.crp.order.calc.util.SerializeUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 接收订单 MQ
 */
@Slf4j
public class OrderMsgConsumer {

    @Value("${rocketmq.consumer.namesrvAddr}")
    private String namesrvAddr;
    @Value("${gome_crp_order_topic}")
    private String topic;
    @Value("${gome_crp_calc_order_group}")
    private String group;
    @Autowired
    private IOMSOrderService iOMSOrderService;
    @Autowired
    private OrderRecordMapper orderRecordMapper;
    @Autowired
    private IProblemService iProblemService;
    
    private DefaultMQPushConsumer consumer;
    
    
    @PostConstruct
    public void init() {
        try {
            /**
             * 一个应用创建一个Consumer，由应用来维护此对象，可以设置为全局对象或者单例<br>
             * 注意：ConsumerGroupName需要由应用来保证唯一
             */
            log.info("init MQ:namesrvAddr'{}' topic'{}' group'{}'",namesrvAddr,topic,group);
            consumer = new DefaultMQPushConsumer(group);
            consumer.setNamesrvAddr(namesrvAddr);
            /**
             * 订阅指定topic下tags分别等于TagU或TagFX
             * 注意：一个consumer对象可以订阅多个topic
             */
            consumer.subscribe(topic, null);
            //CONSUME_FROM_FIRST_OFFSET（默认）:一个【新的订阅组】第一次启动从队列的【最前】位置开始消费，后续再启动接着上次消费的进度开始消费
            //CONSUME_FROM_LAST_OFFSET:一个【新的订阅组】第一次启动从队列的【最后】位置开始消费，后续再启动接着上次消费的进度开始消费
            consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
            consumer.setMessageModel(MessageModel.CLUSTERING);
            //设置批次处理消息的条数,默认是1
            //consumer.setConsumeMessageBatchMaxSize(1);
            consumer.registerMessageListener(new MessageListenerConcurrently() {
                /**
                 * 默认msgs里只有一条消息，可以通过设置consumeMessageBatchMaxSize参数来批量接收消息
                 */
                @Override
                public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                	if (CollectionUtils.isEmpty(msgs)) {
                		log.info("接受到的mq消息为空，不处理，直接返回成功");
                        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                    }
                    MessageExt msg = msgs.get(0);
                    log.info("处理mq消息，ID{}", msg.getMsgId());
                    return handler(msg);
                }
                
            });
            /**
             * Consumer对象在使用之前必须要调用start初始化，初始化一次即可<br>
             */
            consumer.start();
            log.info("{} Started.",this.getClass().getSimpleName());
        } catch (Exception e) {
            log.error("init MQ ERROR: ",e);
        }
    }
    
    private ConsumeConcurrentlyStatus handler(MessageExt messageExt) {
        long startTime = System.currentTimeMillis();
        MQConsumeResult result = new MQConsumeResult();
        try {
            String msgId = null;
            String msg = null;
            OrderDto orderDto;
            try {
                msg = String.valueOf(SerializeUtil.unSerialize(messageExt.getBody()));
                msgId = messageExt.getMsgId();
                MqUtil.startLogTrack(msgId);
                log.info("oms-es-mq处理开始, 时间: {}", startTime);
                orderDto = JSON.parseObject(msg, OrderDto.class);
            } catch (Exception e) {
                iProblemService.addData(msgId, msg, ProblemEnum.CODE_115);
                result.setSuccess(false);
                throw e;
            }

            // 过滤提成系统不需要的订单数据
            orderDto = filterOrder(orderDto, msgId, msg);

            log.info("接收订单mq消息开始msgId:{}, msg:{}, orderDto:{}", msgId, msg, orderDto);
            if (orderDto != null && CollectionUtils.isNotEmpty(orderDto.getDeliveryList())) {
                dealOrder(msgId, msg, orderDto);
            }

            result.setSuccess(true);
            log.info("接收订单mq消息,处理完成msgId:{}", msgId);
        } catch (Exception e) {
            log.error("接收订单mq消息,处理异常, 异常信息: ", e);
            result.setSuccess(false);
        } finally {
            log.info("mq处理结束, 耗时: {}", System.currentTimeMillis() - startTime);
            MqUtil.stopLogTrack();
        }
        return result.isSuccess() ? ConsumeConcurrentlyStatus.CONSUME_SUCCESS : ConsumeConcurrentlyStatus.RECONSUME_LATER;
    }

    private OrderDto filterOrder(OrderDto orderDto, String msgId, String msg) {
        // 临时卡不处理
        if (StringUtils.isEmpty(orderDto.getProfileId()) || BaseConstants.ORDER_PROFILE_LINSHIKA.equals(orderDto.getProfileId())) {
            addProblem(msgId, msg, orderDto.getOrderId(), "临时卡不处理");
            return null;
        }

        // 对于oms来说，一个消息体里，只会有一个配送单。但是为了兼容，此处还是用了 remove
        List<DeliveryDto> deliveryList = orderDto.getDeliveryList();
        Iterator<DeliveryDto> iterator = deliveryList.iterator();
        while (iterator.hasNext()) {
            // 订单状态
            DeliveryDto deliveryDto = iterator.next();
            String gomeState = deliveryDto.getGomeState();

            if (BaseConstants.ORDER_CO_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_DL_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_CL_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_RT_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_RCO_STATUS.equals(gomeState)) {
                Map<String, String> requestHeaderMap = orderDto.getRequestHeaderMap();

                String desc = null;
                //非12渠道顶单requestHeaderMap要做非空校验
                if ((!deliveryDto.getChannelNo().equals(BaseConstants.ORDER_CHANNEL_O2O)) && (requestHeaderMap == null || requestHeaderMap.size() == 0)) {
                    log.info("orderId: {}, requestHeaderMap为空，提成计算不处理", orderDto.getOrderId());
                    desc = "requestHeaderMap为null";
                }
                // 逆向单子没有支付时间
                if ((BaseConstants.ORDER_CO_STATUS.equals(gomeState)
                        || BaseConstants.ORDER_DL_STATUS.equals(gomeState))
                        && orderDto.getPayDate() == null) {
                    log.info("orderId: {}, payDate为空，提成计算不处理", orderDto.getOrderId());
                    desc = "payDate为空";
                }

                if (StringUtils.isNotEmpty(desc)) {
                    addProblem(msgId, msg, orderDto.getOrderId(), desc);
                    return null;
                }
            } else {
                log.info("orderId: {}, deliveryId: {}, 配送单状态为: {}, 提成计算不处理，将此状态过滤",
                        orderDto.getOrderId(), deliveryDto.getShippingGroupId(), gomeState);
                iterator.remove();
                continue;
            }

            List<GoodsDto> goodsList = deliveryDto.getGoodsList();
            Iterator<GoodsDto> goodsDtoIterator = goodsList.iterator();
            while (goodsDtoIterator.hasNext()) {
                GoodsDto goodsDto = goodsDtoIterator.next();
                // 赠品
                if (BaseConstants.ORDER_GOODS_TYPE_GIFT.equals(goodsDto.getGoodsType())) {
                    log.info("orderId: {}, deliveryId: {}, 商品为赠品, 不参与计算逻辑处理", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                    addProblem(msgId, msg, orderDto.getOrderId(), "商品为赠品");
                    goodsDtoIterator.remove();
                    continue;
                }
                if (StringUtils.isEmpty(goodsDto.getEaGroupCode())){
                    log.info("orderId: {}, deliveryId: {}, 线下品类为空, 不参与计算逻辑处理", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                    addProblem(msgId, msg, orderDto.getOrderId(), "线下品类为空");
                    goodsDtoIterator.remove();
                    continue;
                }
                List<DetailGoodsDto> detailList = goodsDto.getDetailList();
                Iterator<DetailGoodsDto> detailGoodsDtoIterator = detailList.iterator();
                while (detailGoodsDtoIterator.hasNext()) {
                    DetailGoodsDto detailGoods = detailGoodsDtoIterator.next();
                    // sapDetailId
                    //非12渠道订单要做非空校验
                    if (StringUtils.isEmpty(detailGoods.getSapDetailId())) {
                        log.info("orderId: {}, deliveryId: {}, sapDetailId 为 null", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                        addProblem(msgId, msg, orderDto.getOrderId(), "sapDetailId 为 null");
                        detailGoodsDtoIterator.remove();
                        continue;
                    }
                    // 延保/百货 商品，业务机型为 null
                    if (StringUtils.isEmpty(detailGoods.getSalesModel())) {
                        // 表示是延保商品，延保商品业务机型可以为 null
                        if (Integer.valueOf(BaseConstants.ORDER_YB_WARRANTY_FLAG_1).equals(goodsDto.getWarrantyFlag())) {
                            continue;
                        }
                        log.info("orderId: {}, deliveryId: {}, salesModel 为 null", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                        addProblem(msgId, msg, orderDto.getOrderId(), "salesModel 为 null");
                        detailGoodsDtoIterator.remove();
                        continue;
                    }
                }
            }
        }

        return orderDto;
    }

    private void dealOrder(String msgId, String msg, OrderDto orderDto) {
        LocalDto localDto = new LocalDto();
        localDto.setBeginTime(System.currentTimeMillis());
        localDto.setType(1);
        CalcLocal.setLocalDto(localDto);
        // 保存 mq 消息入库
        recordOrderMsg(msgId, msg, orderDto);
        // 订单处理模块
        iOMSOrderService.handler(orderDto);
    }

    private void recordOrderMsg(String msgId, String msg, OrderDto orderDto) {
        try {
            OrderRecord orderRecord = new OrderRecord();
            orderRecord.setMsgId(msgId);
            orderRecord.setOrderId(orderDto.getOrderId());
            orderRecord.setMsgBody(msg);
            orderRecordMapper.insert(orderRecord);
        } catch (Exception e) {
            log.error("接收订单mq消息,保存异常msgId:{},msg:{},orderDto:{}", msgId, msg, orderDto, e);
        }
    }

    private void addProblem(String msgId, String msg, String oderId, String desc) {
        try {
            ProblemDto problemDto = new ProblemDto(oderId);
            problemDto.setMsgId(msgId);
            problemDto.setMsg(msg);
            problemDto.setDescription(desc);
            iProblemService.addData(problemDto, ProblemEnum.CODE_115);
        } catch (Exception e) {
            log.error("提成计算插入问题小工具或插入失败重试失败，错误信息：", e);
        }
    }
    
    @PreDestroy
    public void destroy(){
    	if(consumer!=null){
    		consumer.shutdown();
    	}
    }
    
}
