package com.gome.crp.calc.service.job;

public interface IJob15PercentService {
    public void deal15Percent();
    public void deal15PercentCursor();
}
