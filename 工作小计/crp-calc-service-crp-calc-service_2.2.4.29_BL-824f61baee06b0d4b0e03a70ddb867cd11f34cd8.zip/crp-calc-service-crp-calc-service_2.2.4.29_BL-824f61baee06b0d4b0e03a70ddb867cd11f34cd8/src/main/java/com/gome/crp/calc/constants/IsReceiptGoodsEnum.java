package com.gome.crp.calc.constants;

/**
 * 挂账是否已收货
 */
public enum IsReceiptGoodsEnum {
    ALREADY_RECEIPT(1, "已收货"),
    NOT_HAVE_RECEIPT(0, "未收货"),

    ;

    private int code;
    private String msg;

    IsReceiptGoodsEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
