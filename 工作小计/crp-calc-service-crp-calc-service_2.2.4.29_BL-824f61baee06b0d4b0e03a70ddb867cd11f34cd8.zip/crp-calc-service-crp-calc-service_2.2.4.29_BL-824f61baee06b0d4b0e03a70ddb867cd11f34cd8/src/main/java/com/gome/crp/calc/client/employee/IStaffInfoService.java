package com.gome.crp.calc.client.employee;

import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.employee.StaffBindDto;
import com.gome.crp.calc.dto.employee.StaffsIsMainDto;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.dragon.mds.client.dto.gcc.GomeOrganization;
import com.gome.staff.bind.model.domain.StaffBind;

import java.util.List;

/**
 * STAFF
 * 
 * @author libinbin9
 *
 */
public interface IStaffInfoService {
	
	/**
	 * 员工数据信息 <过期><p/>
	 * 原因: 会员信息接口, 迁移 <p/>
	 * @Source com.gome.crp.calc.client.employee.IGomeEmployeeInfoService.queryGomeEmployeeInfos(...)
	 * @param categoryId
	 * @param brandId
	 * @param employeeIdList
	 * @param shop
	 * @param staffLevel
	 * @return
	 */
	@Deprecated
	List<EmployeeInfoDto> queryGomeEmployeeInformation(String categoryId, String brandId, List<String> employeeIdList, String shop, String staffLevel);

	/**
	 * 员工数据信息 <过期><p/>
	 * 原因: 会员信息接口, 迁移 <p/>
	 * @Source com.gome.crp.calc.client.employee.IGomeEmployeeInfoService.queryGomeEmployeeInfos(...)
	 * @param categoryId
	 * @param brandId
	 * @param employeeIdList
	 * @param shop
	 * @param staffLevel
	 * @return
	 */
	@Deprecated
	List<EmployeeInfoDto> queryGomeEmployeeInformation(String orderId, String categoryId, String brandId, List<String> employeeIdList, String shop, String staffLevel);

	/**
	 * userIds 获取员工集合
	 * @param ids
	 * @return
	 */
	List<StaffBindDto> getBatchStaffInfoByUid(List<String> ids);
	
	/**
	 * userId获取员工
	 * @param id
	 * @return
	 */
	StaffBindDto getStaffInfoByUid(String id);
	

	/**
	 * codes 取员工信息, 在线员工信息
	 * @param codes
	 * @return
	 */
	List<StaffBindDto> getBatchUserInfoByStaffCode(List<String> codes);
	
	/**
	 * codes 取员工信息 在线员工信息
	 * 
	 * @param code
	 * @return
	 */
	StaffBind getUserInfoByStaffCode(String code);

	/**
	 * 校验门店有促无促（一个门店在某个月份是否有促销员）
	 *  有促：true
	 * 	无促：false
	 * @param calcResult 订单
	 * @param month 月份
	 * @return
	 */
	Boolean checkPromotion(CalcResult calcResult, String month);

	/**
	 * 通过userid 获取员工信息 + 所在门店信息
	 * @param userId 会员id
	 * @return
	 */
	EmployeeInfoDto getEmployeeDtoByUserId(String userId);

	/**
	 * 通过员工编码查询 员工信息
	 * @param staffCode 员工编码
	 * @return
	 */
	EmployeeInfoDto getEmployeeDtoByStaffCode(String staffCode);
	
	/**
	 * 查询厂家促销员并匹配信息 匹配主营兼营列表
	 * 
	 * @param staffReq
	 * @return
	 */
	StaffsIsMainDto queryIsMainStoreSellers(StaffReqsDto staffReq);
	
	/**
	 * 查询销售组织
	 * @param organizationId
	 * @return
	 */
	GomeOrganization getSellingOrganization(String organizationId);
	
	/**
	 * 查询销售组织集合
	 * @param organizationIds
	 * @return
	 */
	List<GomeOrganization> getSellingOrganization(String[] organizationIds);

}
