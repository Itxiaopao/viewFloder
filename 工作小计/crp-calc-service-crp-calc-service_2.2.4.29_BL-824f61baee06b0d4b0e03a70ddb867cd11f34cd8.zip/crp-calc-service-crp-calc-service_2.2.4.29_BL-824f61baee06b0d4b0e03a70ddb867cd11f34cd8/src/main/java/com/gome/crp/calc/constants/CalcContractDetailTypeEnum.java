package com.gome.crp.calc.constants;

public enum CalcContractDetailTypeEnum {

	//合同查询类型 0:主推返利函,1:带单确认函,2:新合同信息,3:订单批次合同信息,4:订单批次协议信息
	COMMISSION(0, "主推返利函"),
	CONFIRMATION(1, "带单确认函"),
	CONTRACT_POLICY(2, "新合同信息"),
	ORDER_CONTRACT_POLICY(3, "订单批次合同信息"),
	ORDER_AGREEMENT(4, "订单批次协议信息"),
    ;

    private int code;
    private String msg;

    CalcContractDetailTypeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
