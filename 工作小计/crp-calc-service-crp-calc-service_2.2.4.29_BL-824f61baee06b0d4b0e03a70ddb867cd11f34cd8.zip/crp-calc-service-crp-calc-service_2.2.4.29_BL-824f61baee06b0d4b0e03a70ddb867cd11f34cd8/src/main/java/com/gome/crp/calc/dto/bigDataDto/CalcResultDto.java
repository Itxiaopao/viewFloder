package com.gome.crp.calc.dto.bigDataDto;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class CalcResultDto implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = -7731909911175149405L;
	
	
	private String order_id; // 主订单ID、必传
    private String delivery_order_id; // 配送单ID、必传
    private String sku_no; // sku_no、必传
    private String commerce_item_id; // commerce_item_id、必传
    private String detail_id; // detail_id、必传
    private String sap_detail_id; // sap_detail_id、必传
    private String return_order_id; // 退货单号、逆向单时必传
    private String sales_model; // 业务机型、必传
    private String sales_channel; // 渠道、必传
    private Integer jobStatus; // job节点, 正向单必传
    private String gomeStatus; // 订单状态。CO、DL 推大数据正向；CL、RV、RCO 推大数据逆向
    private String submittedDate; // 订单创建时间
    private String pay_date;//订单支付时间
    private List<CalcResultDetailDto> datas;

}
