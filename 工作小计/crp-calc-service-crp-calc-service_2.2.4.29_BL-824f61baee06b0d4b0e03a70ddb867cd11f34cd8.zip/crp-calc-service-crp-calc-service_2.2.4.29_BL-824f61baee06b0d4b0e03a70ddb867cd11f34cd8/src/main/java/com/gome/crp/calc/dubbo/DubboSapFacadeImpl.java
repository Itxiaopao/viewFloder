package com.gome.crp.calc.dubbo;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.facade.dto.ResultDTO;
import com.gome.crp.calc.facade.dto.sap.*;
import com.gome.crp.calc.facade.dubbo.sap.IDubboSapFacade;
import com.gome.crp.calc.manager.DubboSapFacadeManager;
import com.gome.crp.calc.manager.SapFacadeManager;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import com.gome.crp.common.util.ReflectUtil;
import com.gome.crp.calc.mybatis.mapper.SapOrderRecordMapper;
import com.gome.crp.calc.mybatis.mapper.SapRecordMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapOrderRecord;
import com.gome.crp.calc.mybatis.model.SapRecord;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class DubboSapFacadeImpl implements IDubboSapFacade {
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private RedisLockHelper redisLockHelper;
    @Autowired
    private SapOrderRecordMapper sapOrderRecordMapper;
    @Autowired
    private SapFacadeManager sapFacadeManager;
    @Autowired
    private SapRecordMapper sapRecordMapper;
    @Autowired
    private DubboSapFacadeManager dubboSapFacadeManager;

    @Override
    public ResultDTO<OrderResDto> syncOrder(OrderReqDto reqDto, List<OrderItemDto> reqItemDtoList) {
        String reqItemDtoListJson = JSON.toJSONString(reqItemDtoList);
        log.info("接收sap订单信息开始messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson);
        String sapOrderUniqueKey = CacheKeyConstants.getSapOrderUniqueKey(reqDto.getMessageId());
        try {
            Long value = gcacheUtil.distributedLockAtom(sapOrderUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
            if (value == 1) {
                //过滤重复数据（Bstkd）
                List<OrderItemDto> orderItemDtos = removalDuplicate(reqItemDtoList);

                for (OrderItemDto itemDto : orderItemDtos) {
                    String sapRecordLock = CacheKeyConstants.getSapRecordLock(itemDto.getBstkd());
                    RedisLock redisLock = redisLockHelper.getLock(sapRecordLock);
                    if (!redisLock.lock()) {
                        throw new BusinessException(String.format("接收sap订单信息加锁失败messageId:%s,sapRecordLock:%s", reqDto.getMessageId(), sapRecordLock));
                    }

                    try {
                        //转换数据对象
                        SapOrderRecord sapOrderRecord = translate(itemDto);
                        //查询启用的历史记录
                        List<SapOrderRecord> sapOrderRecordList = querySapOrderRecords(sapOrderRecord);
                        if (!CollectionUtils.isEmpty(sapOrderRecordList)) {
                            boolean isAllow = true;
                            for (SapOrderRecord record : sapOrderRecordList) {
                                if (sapOrderRecord.getOperationTime().before(record.getOperationTime()) ||
                                        record.getIsScan() != IsScanEnum.NO.getCode()) {//历史数据不是未扫描的,当前记录变动置为无效
                                    sapOrderRecord.setIsEnable(IsEnableEnum.NO.getCode());
                                    sapFacadeManager.doSaveSyncOrder(sapOrderRecord);
                                    log.info("接收sap订单信息处理A完成messageId:{},reqDto:{},itemDto:{}", reqDto.getMessageId(), reqDto, itemDto);
                                    isAllow = false;
                                    break;
                                }
                            }

                            //设置历史记录为失效,保存新订单数据
                            if (isAllow) {
                                insertSapOrderRecord(sapOrderRecord, sapOrderRecordList);
                                log.info("接收sap订单信息处理B完成messageId:{},reqDto:{},itemDto:{}", reqDto.getMessageId(), reqDto, itemDto);
                            }
                        } else {
                            sapFacadeManager.doSaveSyncOrder(sapOrderRecord);
                            log.info("接收sap订单信息处理C完成messageId:{},reqDto:{},itemDto:{}", reqDto.getMessageId(), reqDto, itemDto);
                        }

                    } finally {
                        redisLock.unlock();
                    }
                }
            }

            return ResultDTO.success();
        } catch (Exception e) {
            log.error("接收sap订单信息,处理异常messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoList, e);
            try {
                gcacheUtil.deleteKey(new String[]{sapOrderUniqueKey});
            } catch (Exception ex) {
                log.error("接收sap订单信息,删除防重键异常messageId:{},reqDto:{},uniqueKey:{}", reqDto.getMessageId(), reqDto, sapOrderUniqueKey, ex);
            }

            return ResultDTO.error(-1, e.getMessage());
        }
    }

    private List<OrderItemDto> removalDuplicate(List<OrderItemDto> reqItemDtoList) {
        Set<String> set = new HashSet<>();
        List<OrderItemDto> uniqueOrderItemList = new ArrayList<>(reqItemDtoList.size());

        for (OrderItemDto itemDto : reqItemDtoList) {
            if (!set.contains(itemDto.getBstkd())) {
                set.add(itemDto.getBstkd());
                OrderItemDto converterOrderItemDto = ReflectUtil.converter(itemDto, OrderItemDto.class);
                uniqueOrderItemList.add(converterOrderItemDto);
            }
        }

        return uniqueOrderItemList;
    }

    private void insertSapOrderRecord(SapOrderRecord sapOrderRecord, List<SapOrderRecord> sapOrderRecordList) {
        List<Long> idList = sapOrderRecordList.stream().map(SapOrderRecord::getId).collect(Collectors.toList());

        SapOrderRecord update = new SapOrderRecord();
        update.setIsEnable(IsEnableEnum.NO.getCode());
        UpdateWrapper<SapOrderRecord> updateWrapper = Wrappers.update();
        updateWrapper.in("id", idList);
        updateWrapper.eq("is_enable", IsEnableEnum.YES.getCode());
        sapFacadeManager.doSaveSyncOrder(update, updateWrapper, sapOrderRecord);
    }

    private List<SapOrderRecord> querySapOrderRecords(SapOrderRecord sapOrderRecord) {
        SapOrderRecord query = new SapOrderRecord();
        query.setDeliveryId(sapOrderRecord.getDeliveryId());
        query.setSapDetailId(sapOrderRecord.getSapDetailId());
        query.setIsEnable(IsEnableEnum.YES.getCode());
        QueryWrapper<SapOrderRecord> queryWrapper = Wrappers.query(query);
        return sapOrderRecordMapper.selectList(queryWrapper);
    }

    private SapOrderRecord translate(OrderItemDto reqDto) {
        SapOrderRecord sapOrderRecord = new SapOrderRecord();
        sapOrderRecord.setSaleTicket(reqDto.getVbeln());
        sapOrderRecord.setSaleChannel(reqDto.getVtweg());
        sapOrderRecord.setSapItemNum(reqDto.getPosnr());
        sapOrderRecord.setSapDetailId(reqDto.getBstkd());

        String bstkd = reqDto.getBstkd();
        //16,13,60渠道：sapDetailId(配送单号+10位detail号)；10渠道：配送单号（4位销售组织+提货单号）
        if (!reqDto.getVtweg().equals(BaseConstants.ORDER_CHANNEL_JINLI)) {
            if (bstkd.length() > 10) {
                sapOrderRecord.setDeliveryId(bstkd.substring(0, bstkd.length() - 10));
                sapOrderRecord.setDetailId(bstkd.substring(bstkd.length() - 10));
                //退货单
            } else {
                log.info("sap退货销售单号bstkd:{},reqDto:{}", bstkd, reqDto);
            }
        } else {
            sapOrderRecord.setDeliveryId(bstkd);
            sapOrderRecord.setDetailId(bstkd);
        }
        sapOrderRecord.setProductCode(reqDto.getMabnr());
        sapOrderRecord.setNum(new BigDecimal(reqDto.getKwmeng()));
        sapOrderRecord.setPurchaseOrganization(reqDto.getZekorg());
        sapOrderRecord.setAddress(reqDto.getWerks());
        sapOrderRecord.setStockAddress(reqDto.getLgort());
        sapOrderRecord.setSupplierCode(reqDto.getZlifnr());
        sapOrderRecord.setSaleModelCode(reqDto.getZywjx());
        sapOrderRecord.setShipCompanyCode(reqDto.getZdbukrs());
        sapOrderRecord.setContractCode(reqDto.getZzconno());
        sapOrderRecord.setExtraNum(reqDto.getZelpak());
        sapOrderRecord.setSaleWayCode(reqDto.getZzxsbj());
        sapOrderRecord.setOperationType(Integer.valueOf(reqDto.getFlag()));
        sapOrderRecord.setOperationTime(DateUtils.parseDate_yyyyMMddHHmmss(reqDto.getErdat()));
        sapOrderRecord.setIsScan(IsScanEnum.NO.getCode());
        sapOrderRecord.setIsEnable(IsEnableEnum.YES.getCode());
        return sapOrderRecord;
    }

    @Override
    public ResultDTO<BillReplyResDto> syncBillReply(BillReplyReqDto reqDto, List<BillReplyItemDto> reqItemDtoList) {
        String reqItemDtoListJson = JSON.toJSONString(reqItemDtoList);
        log.info("接收sap挂账回复信息开始messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson);
        List<String> uniqueKeyList = new ArrayList<>(reqItemDtoList.size());
        try {
            for (BillReplyItemDto itemDto : reqItemDtoList) {
                String sapRecordBillReplyKey = CacheKeyConstants.getSapRecordBillReplyUniqueKey(itemDto.getTcjh(), itemDto.getFlag1(), itemDto.getBstkd(), itemDto.getQxbs(), itemDto.getMatnr(), itemDto.getPernr());
                Long value = gcacheUtil.distributedLockAtom(sapRecordBillReplyKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
                uniqueKeyList.add(sapRecordBillReplyKey);
                if (value == 1) {
                    //更新费用订单号等字段
                    int result = updateBillReplySapRecord(itemDto);
                    if (result != 1) {
                        log.error("接收sap挂账回复信息,更新处理失败messageId:{},reqDto:{},uniqueKey:{}", reqDto.getMessageId(), reqDto, sapRecordBillReplyKey);
                        uniqueKeyList.remove(sapRecordBillReplyKey);
                        continue;
                    }
                }
                uniqueKeyList.remove(sapRecordBillReplyKey);
            }

            log.info("接收sap挂账回复信息处理完成messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson);
            return ResultDTO.success();
        } catch (Exception e) {
            log.error("接收sap挂账回复信息,处理异常messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson, e);
            try {
                gcacheUtil.deleteKey(uniqueKeyList.toArray(new String[]{}));
            } catch (Exception ex) {
                String uniqueKeyListJson = JSON.toJSONString(uniqueKeyList);
                log.error("接收sap挂账回复信息,删除防重键异常messageId:{},reqDto:{},uniqueKeyList:{}", reqDto.getMessageId(), reqDto, uniqueKeyListJson, ex);
            }
            return ResultDTO.error(-1, e.getMessage());
        }
    }

    private int updateBillReplySapRecord(BillReplyItemDto itemDto) {
        SapRecord update = new SapRecord();
        update.setJsrq(DateUtils.parseDate_yyyyMMdd(itemDto.getJsrq()));
        update.setVbeln(itemDto.getVbeln());
        update.setPosnr(itemDto.getPosnr());
        update.setVbeln1(itemDto.getVbeln1());
        update.setPosnr1(itemDto.getPosnr1());
        update.setFkdat(DateUtils.parseDate_yyyyMMdd(itemDto.getFkdat()));
        update.setEbeln(itemDto.getEbeln());
        update.setBudat(DateUtils.parseDate_yyyyMMdd(itemDto.getBudat()));

        UpdateWrapper<SapRecord> updateWrapper = Wrappers.update();
        updateWrapper.eq("tcjh", itemDto.getTcjh());
        updateWrapper.eq("flag1", itemDto.getFlag1());
        updateWrapper.eq("bstkd", itemDto.getBstkd());
        updateWrapper.eq("qxbs", itemDto.getQxbs());
        updateWrapper.eq("matnr", itemDto.getMatnr());
        updateWrapper.eq("pernr", itemDto.getPernr() == null ? "" : itemDto.getPernr());
        return sapRecordMapper.update(update, updateWrapper);
    }

    @Override
    public ResultDTO<ConfirmReceiptReplyResDto> syncConfirmReceiptReply(ConfirmReceiptReplyReqDto reqDto, List<ConfirmReceiptReplyItemDto> reqItemDtoList) {
        String reqItemDtoListJson = JSON.toJSONString(reqItemDtoList);
        log.info("接收sap确认收货回复信息开始messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson);

        List<String> uniqueKeyList = new ArrayList<>(reqItemDtoList.size());
        try {
            for (ConfirmReceiptReplyItemDto itemDto : reqItemDtoList) {
                String sapRecordReceiptUniqueKey = CacheKeyConstants.getSapRecordReceiptUniqueKey(itemDto.getEbeln(), itemDto.getBelnr(), itemDto.getShkzg(), itemDto.getElikz());
                Long value = gcacheUtil.distributedLockAtom(sapRecordReceiptUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
                uniqueKeyList.add(sapRecordReceiptUniqueKey);
                if (value == 1) {
                    List<SapRecord> sapRecordList = selectSapRecord(itemDto.getEbeln());
                    if (CollectionUtils.isEmpty(sapRecordList)) {
                        log.error("接收sap确认收货回复信息,更新处理失败messageId:{},reqDto:{},uniqueKey:{}", reqDto.getMessageId(), reqDto, sapRecordReceiptUniqueKey);
                        uniqueKeyList.remove(sapRecordReceiptUniqueKey);
                        continue;
                    }

                    //挂账已收货
                    List<CalcResult> updateCalcResultList = Collections.emptyList();
                    if (BaseConstants.Bill_TAKE_DELIVERY.equals(itemDto.getElikz()) || BaseConstants.Bill_TAKE_DELIVERY_1.equals(itemDto.getElikz())) {
                        updateCalcResultList = getUpdateCalcResultList(sapRecordList);
                    }

                    //更新收货标示,采购凭证的项目编号等字段
                    List<SapRecord> updateSapRecordList = getUpdateSapRecord(itemDto, sapRecordList);
                    dubboSapFacadeManager.updateConfirmReceiptSapRecord(updateSapRecordList, updateCalcResultList);
                }
                uniqueKeyList.remove(sapRecordReceiptUniqueKey);
            }

            log.info("接收sap确认收货回复信息处理完成messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson);
            return ResultDTO.success();
        } catch (Exception e) {
            log.error("接收sap确认收货回复信息,处理异常messageId:{},reqDto:{},reqItemDtoList:{}", reqDto.getMessageId(), reqDto, reqItemDtoListJson, e);
            try {
                gcacheUtil.deleteKey(uniqueKeyList.toArray(new String[]{}));
            } catch (Exception ex) {
                String uniqueKeyListJson = JSON.toJSONString(uniqueKeyList);
                log.error("接收sap确认收货回复信息,删除防重键异常messageId:{},reqDto:{},uniqueKeyList:{}", reqDto.getMessageId(), reqDto, uniqueKeyListJson, ex);
            }
            return ResultDTO.error(-1, e.getMessage());
        }
    }

    private List<SapRecord> getUpdateSapRecord(ConfirmReceiptReplyItemDto itemDto, List<SapRecord> sapRecordList) {
        List<SapRecord> updateSapRecordList = new ArrayList<>(sapRecordList.size());

        for (SapRecord sapRecord : sapRecordList) {
            SapRecord updateSapRecord = new SapRecord();
            updateSapRecord.setId(sapRecord.getId());
            //A补B场景
            if (BaseConstants.Bill_TAKE_DELIVERY_1.equals(itemDto.getElikz())) {
                updateSapRecord.setBudatA(DateUtils.parseDate_yyyyMMdd(itemDto.getBudat()));
                updateSapRecord.setElikz(itemDto.getElikz());
            } else {
                updateSapRecord.setEbelp(itemDto.getEbelp());
                updateSapRecord.setBelnr(itemDto.getBelnr());
                updateSapRecord.setBuzei(itemDto.getBuzei());
                updateSapRecord.setBudatA(DateUtils.parseDate_yyyyMMdd(itemDto.getBudat()));
                updateSapRecord.setMenge(new BigDecimal(itemDto.getMenge()));
                updateSapRecord.setShkzg(itemDto.getShkzg());
                updateSapRecord.setElikz(itemDto.getElikz());
            }
            updateSapRecordList.add(updateSapRecord);
        }

        return updateSapRecordList;
    }

    private List<CalcResult> getUpdateCalcResultList(List<SapRecord> sapRecordList) {
        List<CalcResult> updateCalcResultList = new ArrayList<>(sapRecordList.size());
        for (SapRecord sapRecord : sapRecordList) {
            CalcResult calcResult = new CalcResult();
            calcResult.setId(sapRecord.getCalcResultId());
            calcResult.setIsReceiptGoods(IsReceiptGoodsEnum.ALREADY_RECEIPT.getCode());
            updateCalcResultList.add(calcResult);
        }
        return updateCalcResultList;
    }

    private List<SapRecord> selectSapRecord(String ebeln) {
        SapRecord sapRecord = new SapRecord();
        sapRecord.setEbeln(ebeln);
        QueryWrapper<SapRecord> queryWrapper = Wrappers.query(sapRecord);
        return sapRecordMapper.selectList(queryWrapper);
    }
}