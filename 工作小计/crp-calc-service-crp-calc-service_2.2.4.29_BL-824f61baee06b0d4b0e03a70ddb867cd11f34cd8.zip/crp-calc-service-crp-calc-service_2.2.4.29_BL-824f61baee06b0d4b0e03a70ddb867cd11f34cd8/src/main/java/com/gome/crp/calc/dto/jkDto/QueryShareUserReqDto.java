package com.gome.crp.calc.dto.jkDto;

import lombok.Data;

import java.util.Date;

@Data
public class QueryShareUserReqDto {
    private String txId; //幂等Id
    private String invokeFrom; //调用来源
    private String activityId; //集客活动ID
    private String userId; //用户Id
    private Date orderDate; //订单下单时间
}
