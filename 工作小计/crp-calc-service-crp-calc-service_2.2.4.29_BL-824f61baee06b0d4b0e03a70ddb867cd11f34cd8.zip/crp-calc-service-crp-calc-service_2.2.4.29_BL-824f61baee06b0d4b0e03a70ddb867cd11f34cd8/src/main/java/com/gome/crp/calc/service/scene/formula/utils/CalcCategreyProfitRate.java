package com.gome.crp.calc.service.scene.formula.utils;

import com.gome.crp.calc.dto.formula.CategroyPointRateDto;
import com.gome.crp.calc.dto.sapDto.DivisionDto;
import com.gome.crp.calc.service.problem.IProblemService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

/**
 * 特定品类比例数据计算类
 *
 */
@Slf4j
@Service
public class CalcCategreyProfitRate {

    @Autowired
    private IProblemService problemService;

    //*********************************************************************
    // 品类数据:
    // 标准提奖品类比例: 1,2,3,4,5,6
    // 舒适家提奖比例: 7
    // 1. 计算提奖比例需要根据, 新增点位(@newPointRat)
    // 2. 比较品类提奖标准列表, 返回结果
    // 3. 封装结果到CategroyPointRateDto, 字段: 比例, 信息(log)
    //**********************************************************************
    public CategroyPointRateDto categoryPointRate(@NonNull BigDecimal newPointRat, DivisionDto divisionDto, String eaGroupCate) {
        CategroyPointRateDto cp = new CategroyPointRateDto();
        BigDecimal rateConclusion = getRateConclusion(newPointRat, divisionDto, eaGroupCate);
        cp.setRate(rateConclusion);
        cp.setDesc(String.format("计算结果, 品类: %s -> 编码: %s, 点位:%s, 比例:%s" ,
                eaGroupCate, divisionDto.getDivisionCode(), newPointRat,  rateConclusion));
        log.info(String.format("差异化-匹配-十大品类提成比例, desc: %s", cp.getDesc()));
        return cp;
    }

    //********************************
    // Catalogue:
    // 1. 传统
    // 2. 电脑
    // 3. 通讯
    // 4. 数码二级,
    // 5. 数码4级 (1)
    // 6. 数码4级 (2)
    // 7. 舒适家
    // -------------------------------
    // Critically:
    // 获取数据集: a > b > c > d
    // 新增点位比较: 依次从 "左向右" 比较数据
    //**************************************
    private BigDecimal getRateConclusion(@NonNull BigDecimal newPointRate, DivisionDto divisionDto, String eaGroupCate){
        // 1
        List<Double> doubles = this.normal_life(divisionDto);
        if(doubles!=null){
            BigDecimal bigDecimal = this.fn_bonus_rate_1(newPointRate, doubles);
            return bigDecimal;
        }
        // 2
        doubles = this.computer(divisionDto);
        if(doubles != null){
            BigDecimal bigDecimal = this.fn_bonus_rate_1(newPointRate, doubles);
            return bigDecimal;
        }
        // 3
        doubles = this.information(divisionDto);
        if(doubles != null){
            BigDecimal bigDecimal = this.fn_bonus_rate_1(newPointRate, doubles);
            return bigDecimal;
        }
        // 4
        doubles = this.get_Digital_L2Cate_Intelligent(eaGroupCate);
        if(doubles != null){
            BigDecimal bigDecimal = this.fn_bonus_rate_1(newPointRate, doubles);
            return bigDecimal;
        }
        // 5
        doubles = this.get_Digital_L4Cate_Camera1(eaGroupCate);
        if(doubles != null){
            BigDecimal bigDecimal = this.fn_bonus_rate_1(newPointRate, doubles);
            return bigDecimal;
        }
        // 6
        doubles = this.get_Digital_L4Cate_Camera2(eaGroupCate);
        if(doubles != null){
            BigDecimal bigDecimal = this.fn_bonus_rate_1(newPointRate, doubles);
            return bigDecimal;
        }

        //************************产品弃用 2020-7-24****************************
        // 7. 舒适家, 拆分二级品类 弃用
        //************************产品弃用 2020-7-24****************************
        /*
        doubles = this.get_SSJ_L2Cate(eaGroupCate);
        if(doubles!=null){
            BigDecimal bigDecimal = this.fn_bonus_rate_2(newPointRate, doubles);
            return bigDecimal;
        }*/
        //**************************产品弃用 2020-7-24**************************

        return null;
    }

    // *******************************
    // 标准: 提奖金额
    // *******************************
    private BigDecimal fn_bonus_rate_1(@NonNull BigDecimal newPointRat, List<Double> rateList){
        BigDecimal rate_value = null;
        if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(0))) >= 0){
            rate_value = BigDecimal.valueOf(0.25);
        }else if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(1))) >= 0){
            rate_value = BigDecimal.valueOf(0.16);
        }else if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(2))) >= 0){
            rate_value = BigDecimal.valueOf(0.12);
        }else if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(3))) >= 0){
            rate_value = BigDecimal.valueOf(0.08);
        }
        return rate_value;
    }

    // *****************************
    // 舒适家(special): 提奖标准
    //******************************
    private BigDecimal fn_bonus_rate_2(@NonNull BigDecimal newPointRat, List<Double> rateList){
        BigDecimal rate_value = null;
        if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(0))) >= 0){
            rate_value = BigDecimal.valueOf(0.35);
        }else if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(1))) >= 0){
            rate_value = BigDecimal.valueOf(0.30);
        }else if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(2))) >= 0){
            rate_value = BigDecimal.valueOf(0.25);
        }else if(newPointRat.compareTo(BigDecimal.valueOf(rateList.get(3))) >= 0){
            rate_value = BigDecimal.valueOf(0.20);
        }
        return rate_value;
    }

    // 传统（含彩电、冰洗、空调、音响）、生活家电（含厨卫、小家电）
    public final static String CODES_NORMAL_LIFE = "0001,0002,0003,0004,0005,0006";

    // *******************************************************
    // 传统（含彩电、冰洗、空调、音响）、生活家电（含厨卫、小家电）
    // *******************************************************
    private List<Double> normal_life(DivisionDto divisionDto){
        if(null == divisionDto){
            return null;
        }
        String codes = CODES_NORMAL_LIFE;
        int i = codes.indexOf(divisionDto.getDivisionCode());
        if(i > -1){
            return Arrays.asList(0.08, 0.06, 0.05, 0.03);
        }else{
            return null;
        }
    }


    // 电脑
    public final static String CODES_COMPUTER = "0009,0010";

    // ********
    // 电脑
    // ********
    private List<Double> computer(DivisionDto divisionDto){
        if(null == divisionDto){
            return null;
        }
        String codes = CODES_COMPUTER;
        int i = codes.indexOf(divisionDto.getDivisionCode());
        if(i > -1){
            return Arrays.asList(0.08, 0.06, 0.04, 0.02);
        }else{
            return null;
        }
    }


    // 通讯
    public final static String CODES_INFORMATION = "0007";

    // ********
    // 通讯
    // ********
    private List<Double> information(DivisionDto divisionDto){
        if(null == divisionDto){
            return null;
        }
        String codes = CODES_INFORMATION;
        int i = codes.indexOf(divisionDto.getDivisionCode());
        if(i > -1){
            return Arrays.asList(0.095, 0.075, 0.055, 0.02);
        }else{
            return null;
        }
    }

    //  "数码二级品类：摄像机、智能设备"
    public final static String CODES_GET_DIGITAL_L_2_CATE_INTELLIGENT = "R1601001,R1601002,R1601003,R1601004,R1601005,R6501001,"
            + "R6501002,R6501003,R6501004,R6501005,R6501006,R6501007,R6501008"
            + "R6501009,R6501010,R6501011,R6502001";

    //*******************
    // "数码二级品类：
    //摄像机、智能设备"
    //********************
    private List<Double> get_Digital_L2Cate_Intelligent(String cateL4){
        if(StringUtils.isBlank(cateL4)){
            return null;
        }
        // 二级品类获取
        String cateL2 = cateL4.substring(0, 3);
        String codes = CODES_GET_DIGITAL_L_2_CATE_INTELLIGENT;
        int i = codes.indexOf(cateL2);
        if(i > -1){
            return Arrays.asList(0.08, 0.06, 0.04, 0.02);
        }else{
            return null;
        }
    }

    // 数码四级品类：卡片相机、长焦相机
    public final static String CODES_GET_DIGITAL_L_4_CATE_CAMERA_1 = "R1701001,R1701003";


    //******************
    // 数码四级品类：
    //卡片相机、长焦相机
    //*******************
    private List<Double> get_Digital_L4Cate_Camera1(String cateL4){
        if(StringUtils.isBlank(cateL4)){
            return null;
        }
        String codes = CODES_GET_DIGITAL_L_4_CATE_CAMERA_1;
        int i = codes.indexOf(cateL4);
        if(i > -1){
            return Arrays.asList(0.08, 0.06, 0.04, 0.02);
        }else{
            return null;
        }
    }

    // 数码四级品类：单反相机、单电相机
    public final static String CODES_GET_DIGITAL_L_4_CATE_CAMERA_2 = "C2111002,R1701002,R6201003,R1701004";

    
    // *********************
    // 数码四级品类：
    //单反相机、单电相机
    //***********************
    private List<Double> get_Digital_L4Cate_Camera2(String cateL4){
        if(StringUtils.isBlank(cateL4)){
            return null;
        }
        String codes = CODES_GET_DIGITAL_L_4_CATE_CAMERA_2;
        int i = codes.indexOf(cateL4);
        if(i > -1){
            return Arrays.asList(0.05, 0.04, 0.03, 0.02);
        }else{
            return null;
        }
    }

    // 舒适家 :
    public final static String CODE_GET_SSJ_L_2_CATE_1 = "RB3,RB5";
    public final static String CODE_GET_SSJ_L_2_CATE_2 = "RB6,";
    public final static String CODE_GET_SSJ_L_2_CATE_3 = "RB9";

    // **************************
    // 业务"摒弃"
    // 舒适家 : 2020-7-24,
    // 1. "舒适家二级品类：环境治理系统、中央空调系统, RB3,RB5";
    // 2. "舒适家二级品类：供暖系统, RB6,";
    // 3. "舒适家二级品类：安防系统, RB9";
    // ***************************
    @Deprecated
    private List<Double> get_SSJ_L2Cate(String cateL4){
        if(StringUtils.isBlank(cateL4)){
            return null;
        }
        String cateL2 = cateL4.substring(0, 3);
        // 环境治理系统, 中央空调系统
        String code1 = CODE_GET_SSJ_L_2_CATE_1;
        String code2 = CODE_GET_SSJ_L_2_CATE_2;
        String code3 = CODE_GET_SSJ_L_2_CATE_3;
        if(code1.indexOf(cateL2) > -1){
            return Arrays.asList(0.05, 0.04, 0.03, 0.02);
        }
        // 供暖系统
        if(code2.indexOf(cateL2) > -1){
            return Arrays.asList(0.06, 0.05, 0.04, 0.03);
        }
        // 安防系统
        if(code3.indexOf(cateL2) > -1){
            // *****注: 安防系统只有 0.03 数值, 其他值都赋值为100.0 防止null指针,导致运算失败
            return Arrays.asList(100.0, 100.0, 0.03, 100.0);
        }
        return null;
    }


    //******************************************
    // 比例调整项值:
    //通讯品类	10.50%
    //数码二级品类(摄像机、智能设备)：	7%
    //数码四级品类(卡片相机、长焦相机)：	7%
    //数码四级品类(单反相机、单电相机)：	3%
    // 返回值: 百分比 -> 小数 直接运算使用
    // **************************************
    public BigDecimal resetCateOptions(String categery, DivisionDto divisionDto){
        if(categery == null && divisionDto == null) {
            return null;
        }
        if (CODES_INFORMATION.indexOf(divisionDto.getDivisionCode()) > -1){
            return BigDecimal.valueOf(0.1050);
        }
        if(CODES_GET_DIGITAL_L_2_CATE_INTELLIGENT.indexOf(categery.substring(0,3)) > -1){
            return BigDecimal.valueOf(0.07);
        }
        if(CODES_GET_DIGITAL_L_4_CATE_CAMERA_1.indexOf(categery) > -1){
            return BigDecimal.valueOf(0.07);
        }
        if(CODES_GET_DIGITAL_L_4_CATE_CAMERA_2.indexOf(categery) > -1) {
            return BigDecimal.valueOf(0.03);
        }
        return null;
    }


    public static void main(String[] args) {
        // test multiple
        System.out.println(BigDecimal.valueOf(0.0600).compareTo(BigDecimal.valueOf(0.06)));
    }

}
