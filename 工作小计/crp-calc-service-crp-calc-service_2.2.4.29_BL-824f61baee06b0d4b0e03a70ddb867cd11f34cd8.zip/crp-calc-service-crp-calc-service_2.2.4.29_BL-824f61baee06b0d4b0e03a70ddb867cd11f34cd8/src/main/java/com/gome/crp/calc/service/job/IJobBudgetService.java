package com.gome.crp.calc.service.job;

public interface IJobBudgetService {

    /**
     * 占用预算定时任务
     */
    void occupyBudget();
    
    /**
     * 占用预算定时任务: 费用承担方
     */
    void occupyBudget1();
   
    
    /**
     * 占用预算定时任务:无函Y
     */
    void occupyBudget2();

}
