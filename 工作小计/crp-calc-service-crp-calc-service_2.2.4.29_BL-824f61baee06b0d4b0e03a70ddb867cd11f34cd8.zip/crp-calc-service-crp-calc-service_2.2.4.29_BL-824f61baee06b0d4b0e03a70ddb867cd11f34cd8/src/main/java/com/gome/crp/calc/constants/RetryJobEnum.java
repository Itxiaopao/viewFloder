package com.gome.crp.calc.constants;

/**
 * job重推枚举
 *
 * @author libinbin9
 */
public enum RetryJobEnum {

    SETTLEMENT(1, "结算重推"),
    ORDERCALC(2, "计算重推"),
    BIGDATACALC(3, "提成计算推大数据"),
    SAP_RELEASE_ONLINE(4, "线下sap冲账重推"),
    SAP_RELEASE_OFFLINE(5, "线上sap冲账重推"),
    REDO_ORDERCALC(6, "重新计算-计算重推"),
    MESSAGE(7, "邮件重推"),
    PRE_ENROLL_BILL(8, "待入账mq"),
    SO_CALC_RETRY(9, "SO重新计算"),

    ;


    private int code;
    private String msg;

    RetryJobEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
