package com.gome.crp.calc.dto.bigDataDto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class SendBigDataDto extends CalcResultDto {

    /**
	 * 
	 */
	private static final long serialVersionUID = 7518295659985272348L;
	private String send_time; // 提奖消息创建时间，提奖系统的mq消息下发时的系统时间、必传
    private String update_time; // 预估转实发动作时的更新时间。
    private String order_create_time; // 订单系统传过来订单提交时间、必传
    private String order_sign; // 正向单、逆向单标识	正向单0(CO) 逆向单1、计算端传0
    private String compute_status; // 提奖系统的计算流转状态，实发前0 实发后1、计算端传0

}
