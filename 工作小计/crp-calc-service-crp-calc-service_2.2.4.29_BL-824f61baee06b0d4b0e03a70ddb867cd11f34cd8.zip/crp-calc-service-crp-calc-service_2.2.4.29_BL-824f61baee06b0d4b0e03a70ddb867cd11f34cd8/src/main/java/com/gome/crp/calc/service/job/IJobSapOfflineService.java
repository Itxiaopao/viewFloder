package com.gome.crp.calc.service.job;

public interface IJobSapOfflineService {
    /**
     * 挂账
     */
    void applyBill();
}
