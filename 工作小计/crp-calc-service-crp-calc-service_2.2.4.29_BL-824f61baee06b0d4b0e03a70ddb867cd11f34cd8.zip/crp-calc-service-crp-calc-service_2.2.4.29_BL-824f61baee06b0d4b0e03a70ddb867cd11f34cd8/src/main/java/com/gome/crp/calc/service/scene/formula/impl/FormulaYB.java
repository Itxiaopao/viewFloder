package com.gome.crp.calc.service.scene.formula.impl;

import com.gome.crp.calc.dto.formula.JTBasePriceDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.formula.IFormulaYB;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;


/**
 * 延保
 */
@Slf4j
@Service
public class FormulaYB implements IFormulaYB {


    @Autowired
    private SceneUtils sceneUtils;
    @Autowired
    private ICalcRewardsService calcRewardsService;

    //百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);
    private static BigDecimal percent_rate_cent_1 = BigDecimal.valueOf(1.0);


    @Override
    public BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        String orderId = orderCalcDto.getOrderId();
        Long planId = planDto.getPlanId();
        String log_pre = String.format("订单: %s, 计划: %s, 场景-(延保): %s ", orderId, planId, scene);

        BigDecimal ret = BigDecimal.valueOf(0.0);
        Integer buyNum = orderCalcDto.getBuyNum();
        BigDecimal issueRate = planDto.getIssueRate();
        BigDecimal sceneValue = sceneUtils.getSceneValue(planDto, scene);

        // 计提现价,
        // Long jtCurrentPrice = sceneUtils.getJTCurrentPrice(planDto);
        // 计提基数:
        JTBasePriceDto jtBasesDto = sceneUtils.getJTBases(orderCalcDto, planDto);
        BigDecimal jtBases = jtBasesDto.getPrice();
        if (jtBases == null){
            return ret;
        }
        String jtProvisionStr = jtBasesDto.getProvisionStr(); // 类型
        // 提奖金额=销售金额（或实付金额）×销售数量×发放比例×X比例
        ret = jtBases.multiply(BigDecimal.valueOf(buyNum))
                .multiply(issueRate.multiply(percent_rate_normal))
                .multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);;

        String logs = String.format("提奖金额[%s 分] = 金额[%s 分, %s] × 销售数量[%s] × 发放比例[%s x 0.01] × X比例[%s x 0.01], target:%s"
                ,ret.toString(), jtBases, jtProvisionStr, buyNum, issueRate, sceneValue, log_pre);
        log.info(logs);
        return ret;
    }
}
