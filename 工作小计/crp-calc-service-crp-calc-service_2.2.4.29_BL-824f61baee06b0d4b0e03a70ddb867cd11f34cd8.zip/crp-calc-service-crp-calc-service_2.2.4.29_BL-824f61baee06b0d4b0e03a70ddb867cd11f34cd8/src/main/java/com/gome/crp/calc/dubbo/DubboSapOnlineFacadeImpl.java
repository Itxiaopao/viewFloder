package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboSapOnlineFacade;
import com.gome.crp.calc.service.job.IJobSapOnlineService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DubboSapOnlineFacadeImpl implements IDubboSapOnlineFacade {
    @Autowired
    private IJobSapOnlineService iJobSapOnlineService;

    @Override
    public void applyBill() {
        iJobSapOnlineService.applyBill();
    }
}
