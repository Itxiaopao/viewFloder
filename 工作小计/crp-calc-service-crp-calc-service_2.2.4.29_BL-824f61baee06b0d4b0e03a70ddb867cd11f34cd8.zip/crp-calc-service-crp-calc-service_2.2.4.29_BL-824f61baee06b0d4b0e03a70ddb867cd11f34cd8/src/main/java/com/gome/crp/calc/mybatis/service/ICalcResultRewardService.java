package com.gome.crp.calc.mybatis.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.gome.crp.calc.mybatis.model.CalcResultReward;

public interface ICalcResultRewardService extends IService<CalcResultReward> {
}
