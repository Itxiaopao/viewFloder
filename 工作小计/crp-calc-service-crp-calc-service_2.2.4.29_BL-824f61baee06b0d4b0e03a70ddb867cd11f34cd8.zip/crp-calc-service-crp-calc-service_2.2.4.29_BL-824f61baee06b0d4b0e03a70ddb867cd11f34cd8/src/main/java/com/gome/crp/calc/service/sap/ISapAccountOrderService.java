package com.gome.crp.calc.service.sap;

import com.gome.crp.calc.dto.sapDto.SapAccountInfo;

public interface ISapAccountOrderService {

    void handler(SapAccountInfo sapAccountInfo);
}
