package com.gome.crp.calc.mq.consumer;

import java.nio.charset.StandardCharsets;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.boot.common.logging.trace.mq.MqUtil;
import com.gome.crp.calc.dto.sapDto.SapAccountInfo;
import com.gome.crp.calc.service.sap.ISapAccountOrderService;

import lombok.extern.slf4j.Slf4j;

/**
 * 接收sap账目 MQ
 */
@Slf4j
public class SapAccountConsumer {

    @Value("${rocketmq.consumer.namesrvAddr}")
    private String namesrvAddr;
    @Value("${sap_account_topic}")
    private String topic;
    @Value("${gome_crp_calc_sap_account_group}")
    private String group;
    @Autowired
    private ISapAccountOrderService iSapAccountOrderService;
    
    private DefaultMQPushConsumer consumer;
    
    
    @PostConstruct
    public void init() {
        try {
            /**
             * 一个应用创建一个Consumer，由应用来维护此对象，可以设置为全局对象或者单例<br>
             * 注意：ConsumerGroupName需要由应用来保证唯一
             */
            log.info("init MQ:namesrvAddr'{}' topic'{}' group'{}'",namesrvAddr,topic,group);
            consumer = new DefaultMQPushConsumer(group);
            consumer.setNamesrvAddr(namesrvAddr);
            /**
             * 订阅指定topic下tags分别等于TagU或TagFX
             * 注意：一个consumer对象可以订阅多个topic
             */
            consumer.subscribe(topic, null);
            //CONSUME_FROM_FIRST_OFFSET（默认）:一个【新的订阅组】第一次启动从队列的【最前】位置开始消费，后续再启动接着上次消费的进度开始消费
            //CONSUME_FROM_LAST_OFFSET:一个【新的订阅组】第一次启动从队列的【最后】位置开始消费，后续再启动接着上次消费的进度开始消费
            consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_FIRST_OFFSET);
            consumer.setMessageModel(MessageModel.CLUSTERING);
            //设置批次处理消息的条数,默认是1
            //consumer.setConsumeMessageBatchMaxSize(1);
            consumer.registerMessageListener(new MessageListenerConcurrently() {
                /**
                 * 默认msgs里只有一条消息，可以通过设置consumeMessageBatchMaxSize参数来批量接收消息
                 */
                @Override
                public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                	if (CollectionUtils.isEmpty(msgs)) {
                		log.info("接受到的mq消息为空，不处理，直接返回成功");
                        return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                    }
                    MessageExt msg = msgs.get(0);
                    log.info("处理mq消息，ID{}", msg.getMsgId());
                    return handler(msg);
                }
                
            });
            /**
             * Consumer对象在使用之前必须要调用start初始化，初始化一次即可<br>
             */
            consumer.start();
            log.info("{} Started.",this.getClass().getSimpleName());
        } catch (Exception e) {
            log.error("init MQ ERROR: ",e);
        }
    }
    
    
    private ConsumeConcurrentlyStatus handler(MessageExt messageExt) {
        String msgId = null;
        String msg = null;
        SapAccountInfo sapAccountInfo = null;
        try {
            msgId = messageExt.getMsgId();
            msg = new String(messageExt.getBody(), StandardCharsets.UTF_8);
            MqUtil.startLogTrack(msgId);
            sapAccountInfo = JSON.parseObject(msg, SapAccountInfo.class);
            log.info("接收sap账目消息开始msgId:{},msg:{},sapAccountInfo:{}", msgId, msg, sapAccountInfo);
            if (StringUtils.isEmpty(sapAccountInfo.getReuno()) || StringUtils.isEmpty(sapAccountInfo.getSoDeliveryDetailId())) {
                log.error("接收sap账目消息-必输项为空msgId:{},msg:{},sapAccountInfo:{}", msgId, msg, sapAccountInfo);
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }

            iSapAccountOrderService.handler(sapAccountInfo);
            log.info("接收sap账目消息完成msgId:{},msg:{},sapAccountInfo:{}", msgId, msg, sapAccountInfo);
            return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
        } catch (Exception e) {
            log.error("接收sap账目消息异常msgId:{},msg:{},sapAccountInfo:{}", msgId, msg, sapAccountInfo, e);
            return ConsumeConcurrentlyStatus.RECONSUME_LATER;
        } finally {
            MqUtil.stopLogTrack();
        }
    }
    
    @PreDestroy
    public void destroy(){
    	if(consumer!=null){
    		consumer.shutdown();
    	}
    }
    
}
