package com.gome.crp.calc.service.rewardRecord.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.dto.formula.JTBasePriceDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.mybatis.mapper.CalcResultRewardMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.mybatis.service.ICalcResultRewardService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.formula.ICalFormulas;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import com.gome.crp.calc.util.GcacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


@Slf4j
@Service
public class CalcRewardsService implements ICalcRewardsService {

    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private ICalcResultRewardService calcResultRewardService;
    @Autowired
    private CalcResultRewardMapper calcResultRewardMapper;
    @Autowired
    private ICalFormulas calculatedFormulas;
    @Autowired
    private SceneUtils sceneUtils;


    private static String gcache_key = "CalcRewardsService:";


    @Override
    public void addCommit(OrderCalcDto orderDto, PlanDto planDto, List<ProfitDto> profitList, String scene, String from) {
        log.info(String.format("提奖履历信息执行: from:%s, orderId:%s, planid:%s, scene: %s, 提奖人: %s",
                from, orderDto.getOrderId(), planDto.getPlanId(), scene, JSONObject.toJSONString(profitList)));
        CalcResultReward crr = this.getPreObj(orderDto,planDto,scene);
        List<CalcResultReward> crrl = new ArrayList<>(profitList.size());
        for (ProfitDto profitDto: profitList){
            BigDecimal bigDecimal = profitDto.getAwardAmount();
            if(bigDecimal.compareTo(BigDecimal.valueOf(0)) <= 0){
                // 该条件下不计算
                continue;
            }
            PersonDto personDto = profitDto.getPersonDto();
            crr.setUserId(personDto.getUserId());
            crr.setStaffCode(personDto.getStaffCode());
            crr.setReward(bigDecimal.toString());
            crrl.add(crr);
        }
        log.info(String.format("提奖履历信息执行-预保存转换后-保存: from:%s, orderId:%s, planid:%s, scene: %s, data:%s",
                from, orderDto.getOrderId(), planDto.getPlanId(), scene, JSONObject.toJSONString(crrl)));
        calcResultRewardService.saveBatch(crrl);
    }

    @Override
    public void addSingleCommit(CalcResultReward calcResultReward) {
        log.info(String.format("提奖履历信息执行-single保存: data:%s", JSONObject.toJSONString(calcResultReward)));
        calcResultRewardMapper.insert(calcResultReward);
    }

    @Override
    public void addBatchCommit(List<CalcResultReward> calcResultRewardList) {
        log.info(String.format("提奖履历信息执行-批量保存: data:%s", JSONObject.toJSONString(calcResultRewardList)));
        calcResultRewardService.saveBatch(calcResultRewardList);
    }


    // key consist
    private String getKey(String orderId, String detailId, String channel, String scene, String planId){
        String key = orderId + detailId + channel + scene + planId;
        return gcache_key + key;
    }

    @Override
    public CalcResultReward getPreObj (OrderCalcDto orderCalcDto, PlanDto planDto, String scene){
        CalcResultReward crr = new CalcResultReward();
        crr.setOrderId(orderCalcDto.getOrderId());
        crr.setDetailId(orderCalcDto.getDetailId());
        crr.setChannel(orderCalcDto.getChannel());
        crr.setGomeStatus(orderCalcDto.getGomeState());
        if(planDto.getPlanId() != null){
            crr.setPlanId(planDto.getPlanId().toString());
        }
        crr.setScene(scene);
        crr.setPromotionsType(planDto.getPromotionsType());
        crr.setPolicyCode(planDto.getPolicyCode());
        crr.setBuyNum(orderCalcDto.getBuyNum().toString());
        crr.setSalesModel(planDto.getSalesModelCode()); // salesModel;
        crr.setContractClass(planDto.getContractClass());
        if(planDto.getPolicyRatio() != null){
            crr.setPolicyValue(planDto.getPolicyRatio().toString());
        }
        if(planDto.getIssueRate() != null ){
            crr.setIssueRate(planDto.getIssueRate().toString());
        }
        if(planDto.getSingleStandard() != null){
            crr.setSingleStandard(planDto.getSingleStandard().toString());
        }
        if(planDto.getCurrentPrice()!=null){
            crr.setCurrentPrice(planDto.getCurrentPrice().toString());
        }
        if(planDto.getAddEachRebate() != null){
            crr.setAddEachRebate(planDto.getAddEachRebate().toString());
        }
        if (planDto.getAddMonthlyRebate() != null){
            crr.setAddMonthlyRebate(planDto.getAddMonthlyRebate().toString());
        }
        if (planDto.getAdditionalAward() != null){
            crr.setAdditionalAward(planDto.getAdditionalAward().toString());
        }
        if (planDto.getOfferPrice() != null){
            crr.setOfferPrice(planDto.getOfferPrice().toString());
        }
        if(planDto.getSingleStandardMoney() != null){
            crr.setSingleStandardMoney(planDto.getSingleStandardMoney().toString());
        }
        BigDecimal sceneValue = sceneUtils.getSceneValue(planDto, scene);
        if(sceneValue != null){
            crr.setSceneValue(sceneValue.toString());
        }
        JTBasePriceDto jtBases = sceneUtils.getJTBases(orderCalcDto, planDto);
        crr.setJtBases(jtBases.getPrice().toString());
        crr.setJtBasesType(jtBases.getProvisionType());
//        profitRate;  // 促销费提奖比例
//        reward;  // 提奖金额 :正向单"+", 逆向单"-"
//        userId;
//        staffCode;
//        calcFormulaStr;  // 计算公式
//        calcFormulaLog;  // 计算公式log
        return crr;
    }

    @Override
    // 封装提奖记录数据,   willSub 为 正数
    public CalcResultReward getCalcReward(CalcResult calcResult, String willSub){
        //    private String orderId;
        //    private String detailId;
        //    private String channel;     // 渠道
        //    private String gomeStatus;   // 订单状态
        //    private String scene;   // 场景
        // reward
        CalcResultReward c = new CalcResultReward();
        c.setOrderId(calcResult.getOrderId());
        c.setDetailId(calcResult.getDetailId());
        c.setPlanId(calcResult.getPlanId());
        c.setChannel(calcResult.getChannel());
        c.setGomeStatus(calcResult.getGomeStatus());
        c.setScene(calcResult.getScenes());
        c.setReward('-' + willSub);	// 数据变为负数, 为后期计算
        c.setCalcFormulaStr("(退/取消)单:减去订单提奖金额");
        c.setCalcFormulaLog("(退/取消)单:减去订单提奖金额:" + willSub);
        return c;
    }

}
