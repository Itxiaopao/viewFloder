package com.gome.crp.calc.service.scene.formula.impl;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.formula.IFormulaO2O;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Slf4j
@Service
public class FormulaO2O implements IFormulaO2O {

    @Autowired
    private SceneUtils sceneUtils;
    @Autowired
    private ICalcRewardsService calcRewardsService;

    //百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);
    private static BigDecimal percent_rate_cent_1 = BigDecimal.valueOf(1.0);

    // O2O
    private BigDecimal formulaO2O(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        String orderId = orderCalcDto.getOrderId();
        Long planId = planDto.getPlanId();
        String log_pre = String.format("订单: %s, 计划: %s, 场景: %s", orderId, planId, scene);

        BigDecimal ret = BigDecimal.valueOf(0.0);
        // 购买数量
        Integer buyNum = orderCalcDto.getBuyNum();
        // 场景比例
        BigDecimal sceneValue = sceneUtils.getSceneValue(planDto, scene);

        // "O2O-提奖金额=单品销售金额（或单品实付金额）×销售数量×Z/M比例
        String saleDes = "单品实付金额";
        BigDecimal unitPrice = orderCalcDto.getPrice();//默认取结算价
        if(BaseConstants.PLAN_PROVISION_SELL  == planDto.getProvisionType().intValue()){
            //计提基数（0销售金额）
            saleDes = "单品销售金额";
            unitPrice = orderCalcDto.getSalePrice();
        }
        ret = BigDecimal.valueOf(buyNum).multiply(unitPrice.multiply(percent_rate_normal)).multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
        String logs = String.format("O2O-提奖金额[ %s ]=%s[ %s × 0.01 ]×销售数量[ %s ]×[ %s ]比例[ %s × 0.01 ], target: [ %s ]"
                , ret, saleDes , unitPrice, buyNum, scene, sceneValue, log_pre);
        log.info(logs);
        ret = ret.multiply(percent_rate_cent).setScale(2, RoundingMode.DOWN);   // 转换成分, 保留两位小数
//        // --------------------------------save reward----------------------------------
//        CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//        crr.setReward(ret.toString());
//        crr.setCalcFormulaLog(logs);
//        crr.setCalcFormulaStr("O2O-提奖金额=单品销售金额（或单品实付金额）×销售数量×Z/M比例");
//        savePreRewards(crr);
//        // --------------------------------save reward----------------------------------

        return ret;
    }

    @Override
    public BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        return this.formulaO2O(orderCalcDto, planDto, scene);
    }
}
