package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

@Data
public class TerminatePlanReqDto {
    private String planId;
}
