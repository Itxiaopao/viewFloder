package com.gome.crp.calc.client.employee.impl;

import cn.com.gome.mdm.client.server.employee.GomeEmployeeClient;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.IGomeEmployeeInfoService;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.employee.*;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.manager.employee.EmployeeAttendanceSynManager;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.EmployeeAttendance;
import com.gome.dragon.mds.client.dto.gcc.GomeEmployeeInformation;
import com.gome.dragon.mds.client.dto.gcc.GomeOrganization;
import com.gome.dragon.mds.client.dto.gcc.GomeSalesStaffDto;
import com.gome.dragon.mds.client.gcc.GomeInternetSalesStaffClient;
import com.gome.dragon.mds.client.gcc.SellingOrganizationQueryClient;
import com.gome.staff.bind.api.StaffBindService;
import com.gome.staff.bind.model.domain.CommonResult;
import com.gome.staff.bind.model.domain.StaffBind;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * 
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class StaffInfoService implements IStaffInfoService {

    @Autowired
    private GomeInternetSalesStaffClient gomeInternetSalesStaffClient;

    @Autowired
    private StaffBindService staffBindService;
    @Autowired
    private EmployeeAttendanceSynManager employeeAttendanceSynManager;
    @Autowired
    private SellingOrganizationQueryClient sellingOrganizationQueryClient;
	@Autowired
	private GomeEmployeeClient gomeEmployeeClient;
	@Autowired
	private IGomeEmployeeInfoService gomeEmployeeInfoService;

    /**
     * 员工数据信息
     *
     * @param categoryId
     * @param brandId
     * @param employeeIdList
     * @param shop
     * @param staffLevel
     * @return
     */
    @Override
    public List<EmployeeInfoDto> queryGomeEmployeeInformation(String categoryId, String brandId, List<String> employeeIdList, String shop, String staffLevel) {
        GomeSalesStaffDto req = new GomeSalesStaffDto();
        req.setBrandId(brandId);
        req.setCategoryId(categoryId);
        req.setEmployeeIdList(employeeIdList);
        req.setShop(shop);
        req.setStaffLevel(staffLevel);
        List<EmployeeInfoDto> list = null;
		log.info("Dubbo查询员工/促销员信息, 入参: {}", JSON.toJSONString(req));
		List<GomeEmployeeInformation> resp = gomeInternetSalesStaffClient.queryGomeEmployeeInformation(req);
		log.info("Dubbo查询员工/促销员信息, 出参: {}", JSON.toJSONString(resp));
		if (resp != null) {
			list = new ArrayList<EmployeeInfoDto>();
			for (GomeEmployeeInformation gei : resp) {
				String json = JSONObject.toJSONString(gei);
				EmployeeInfoDto ei = JSONObject.parseObject(json, EmployeeInfoDto.class);
				EmployeeInfoBaseDto baseDto = new EmployeeInfoBaseDto();
				BeanUtils.copyProperties(gei, baseDto);
				ei.setBaseInfo(baseDto);
				list.add(ei);
			}
		}
        return list;
    }

    /**
     * 员工数据信息
     */
    @Override
    public List<EmployeeInfoDto> queryGomeEmployeeInformation(String orderId, String categoryId, String brandId, List<String> employeeIdList, String shop, String staffLevel) {
		log.info(String.format("Dubbo查询员工/促销员信息入参: orderId-%s, 线下品牌-%s, 线下品类-%s, 门店编码-%s, 员工编码-%s",
				orderId, brandId, categoryId, shop, JSONObject.toJSONString(employeeIdList)) );
		List<EmployeeInfoDto> list = this.queryGomeEmployeeInformation(categoryId,brandId,employeeIdList,shop,staffLevel);
		log.info(String.format("Dubbo查询员工/促销员信息出参: orderId-%s, 结果-%s",
				orderId, JSONObject.toJSONString(list)));
        return list;
    }

    /**
     * 员工id获取
     *
     * @param ids
     * @return
     */
    @Override
    public List<StaffBindDto> getBatchStaffInfoByUid(List<String> ids) {
        List<StaffBindDto> list = null;
        try {
            log.info(String.format("批量查询会员信息, 参数:%s", JSONObject.toJSONString(ids)));
            CommonResult<List<StaffBind>> resp = staffBindService.getBatchStaffInfoByUid(ids);
            log.info(String.format("批量查询会员信息, 结果:%s", JSONObject.toJSONString(resp)));
            List<StaffBind> data = resp.getData();
            if (data != null) {
                list = new ArrayList<>();
                for (StaffBind staffBind : data) {
                    StaffBindDto e = new StaffBindDto();
                    BeanUtils.copyProperties(staffBind, e);
                    list.add(e);
                }
            }
        } catch (Exception e) {
            log.error(String.format("批量查询会员信息异常, 参数:%s", JSONObject.toJSONString(ids)), e);
        }
        return list;
    }

    /**
     * 单笔获取
     *
     * @param code
     * @return
     */
    @Override
    public StaffBind getUserInfoByStaffCode(String code) {
        StaffBind user = null;
        try {
            log.info(String.format("通过员工编码查询会员信息, 参数:%s", code));
            CommonResult<StaffBind> resp = staffBindService.getUserInfoByStaffCode(code);
            log.info(String.format("通过员工编码查询会员信息, 参数:%s", JSONObject.toJSONString(resp)));
            if (resp.isSuccess()) {
                user = resp.getData();
            }
        } catch (Exception e) {
            log.error(String.format("通过员工编码查询会员信息异常, 参数:%s", JSONObject.toJSONString(code)), e);
        }
        return user;
    }

    /**
     * codes 取员工信息
     *
     * @param codes
     * @return
     */
    @Override
    public List<StaffBindDto> getBatchUserInfoByStaffCode(List<String> codes) {
        List<StaffBindDto> list = null;
        try {
            log.info(String.format("批量查询会员信息,通过员工编码查询会员信息, 参数:%s", JSONObject.toJSONString(codes)));
            CommonResult<List<StaffBind>> resp = staffBindService.getBatchUserInfoByStaffCode(codes);
            log.info(String.format("批量查询会员信息,通过员工编码查询会员信息, 返回值:%s", JSONObject.toJSONString(resp)));
            if (resp.isSuccess()) {
                List<StaffBind> data = resp.getData();
                list = new ArrayList<>();
                for (StaffBind staffBind : data) {
                    StaffBindDto e = new StaffBindDto();
                    BeanUtils.copyProperties(staffBind, e);
                    list.add(e);
                }
            }
        } catch (Exception e) {
            log.error(String.format("通过员工编码查询会员信息异常, 参数:%s", JSONObject.toJSONString(codes)), e);
        }
        return list;
    }

    /**
     * * 校验门店是否有促销员
     * * 有促：true
     * * 无促：false
     * * @param storeCode
     * * @param month 示例数据：202003
     *
     * @param month
     * @return
     */
    @Override
    public Boolean checkPromotion(CalcResult calcResult, String month) {
        StaffReqsDto staffReqsDto = new StaffReqsDto();
        staffReqsDto.setEaCateSecond(calcResult.getCategoryLevelTwo());
        staffReqsDto.setEaBrandCode(calcResult.getBrandCode());
        staffReqsDto.setShopNo(calcResult.getShopNo());
		staffReqsDto.setSupplierCode(calcResult.getOrderSupplierCode());
        log.info("校验门店是否无促,orderId:{},detailId:{},eaCateSecond:{},EaBrandCode:{},shopNo:{},supplierCode:{},month:{}", calcResult.getOrderId(), calcResult.getDetailId(), staffReqsDto.getEaCateSecond(),
                staffReqsDto.getEaBrandCode(), staffReqsDto.getShopNo(),calcResult.getOrderSupplierCode(),month);
        StaffsIsMainDto staffsIsMainDto = queryIsMainStoreSellers(staffReqsDto);
		log.info("校验门店是否无促,调用员工信息返参,orderId:{},detailId:{},mainStaffs:{},unMainStaffs:{}", calcResult.getOrderId(), calcResult.getDetailId(),
				null != staffsIsMainDto ? staffsIsMainDto.getMainStaffs() : null , null != staffsIsMainDto ? staffsIsMainDto.getUnMainStaffs() : null);
		if(null == staffsIsMainDto || CollectionUtils.isEmpty(staffsIsMainDto.getMainStaffs())){
			log.info("该门店没有主营,orderId:{},detailId:{},返回主营为空",calcResult.getOrderId(), calcResult.getDetailId());
			return false;
		}
        ArrayList<String> staffCodes = new ArrayList<>();
        for (EmployeeInfoDto thisEmployeeInfoDto : staffsIsMainDto.getMainStaffs()) {
            staffCodes.add(thisEmployeeInfoDto.getBaseInfo().getEmployeeId());
        }
        try {
            log.info(String.format("查询员工/门店促销员信息, staffCodes=%s | month=%s", JSONObject.toJSONString(staffCodes), JSONObject.toJSONString(month)));
            List<EmployeeAttendance> employeeAttendances = employeeAttendanceSynManager.queryEmployeeAttendanceByStaffCode(staffCodes, month);
            log.info(String.format("查询员工/门店促销员信息, 返回值:%s", JSONObject.toJSONString(employeeAttendances)));
            if (null == employeeAttendances || employeeAttendances.size() == 0) {
            	// 说明考勤没有大于十五天的员工  改提奖
				log.info("该门店没有主营,orderId:{},detailId:{},门店没有大于十五天的员工，给提奖",calcResult.getOrderId(), calcResult.getDetailId());
                return false;
            }
        } catch (Exception e) {
            log.error(String.format("查询员工/门店促销员信息异常, 参数: staffCodes=%s | month=%s", JSONObject.toJSONString(staffCodes), JSONObject.toJSONString(month)), e);
        }
		log.info("该门店没有主营,orderId:{},detailId:{},门店有大于十五天的员工，不给提奖",calcResult.getOrderId(), calcResult.getDetailId());
        return true;
    }


    public static void main(String[] args) {
        String jsonString = JSONObject.toJSONString(new EmployeeInfoDto());
        System.out.println(String.format("%s", jsonString));


    }

    /**
     * userId 查询员工信息
     *
     * @param id
     * @return
     */
    @Override
    public StaffBindDto getStaffInfoByUid(String id) {
        StaffBindDto sbd = null;
        try {
            log.info(String.format("通过会员ID获取员工信息Dubbo接口, id:%s ", id));
            CommonResult<StaffBind> resp = staffBindService.getStaffInfoByUid(id);
            log.info(String.format("通过会员ID获取员工信息Dubbo接口, 返回值:%s ", JSONObject.toJSONString(resp)));
            StaffBind data = resp.getData();
            if (data != null) {
                sbd = new StaffBindDto();
                BeanUtils.copyProperties(data, sbd);
            }
        } catch (Exception e) {
            log.error(String.format("通过会员ID获取员工信息Dubbo接口异常, 参数:%s", id), e);
        }
        return sbd;
    }


    @Override
    public EmployeeInfoDto getEmployeeDtoByUserId(String userId) {
        StaffBindDto staff = this.getStaffInfoByUid(userId);
        if (null == staff) {
            return null;
        }
        return getEmployeeDtoByStaffCode(staff.getStaffCode());
    }

    @Override
    public EmployeeInfoDto getEmployeeDtoByStaffCode(String staffCode) {
        List<EmployeeInfoDto> empls = this.queryGomeEmployeeInformation("", "", Arrays.asList(staffCode), "", "");
        if (empls != null && empls.size() > 0) {
            return empls.get(0);
        } else {
            return null;
        }
    }


	/**
	 * 查询厂家促销员并匹配信息 匹配主营兼营列表
	 * 
	 * @param staffReq
	 * @return
	 */
	@Override
	public StaffsIsMainDto queryIsMainStoreSellers(StaffReqsDto staffReq) {
		String logEmbedPort = staffReq.getLogEmbedPort();
		log.info(String.format("门店[主营|兼营]员工信息匹配查询结果: 基本信息:%s, 参数: %s", logEmbedPort, JSONObject.toJSONString(staffReq)));
		String shopNo = staffReq.getShopNo();
		if(StringUtils.isBlank(shopNo)) {
			log.info(String.format("门店[主营|兼营]员工信息匹配查询结果-异常: 基本信息:%s, 参数: %s, shopNo:NULL", logEmbedPort, JSONObject.toJSONString(staffReq)));
			return null;
		}
		String eaBrandCode = staffReq.getEaBrandCode();
		if(StringUtils.isBlank(eaBrandCode)) {
			log.info(String.format("门店[主营|兼营]员工信息匹配查询结果-异常: 基本信息:%s, 参数: %s, eaBrandCode:NULL", logEmbedPort, JSONObject.toJSONString(staffReq)));
			return null;
		}
		String eaCateSecond = staffReq.getEaCateSecond();
		if(StringUtils.isBlank(eaCateSecond)) {
			log.info(String.format("门店[主营|兼营]员工信息匹配查询结果-异常: 基本信息:%s, 参数: %s, eaCateSecond:NULL", logEmbedPort, JSONObject.toJSONString(staffReq)));
			return null;
		}
		List<String> staffCodeList = staffReq.getStaffCodeList();
		String storeLevel = staffReq.getStoreLevel();
		if(StringUtils.isBlank(storeLevel)){
			storeLevel = BaseConstants.STAFF_LEVEL_4 + "";	// 门店级别
		}
		List<EmployeeInfoDto> query = null;
//		query = this.queryGomeEmployeeInformation(eaCateSecond, eaBrandCode, staffCodeList,
//				shopNo, storeLevel);
		query = this.queryGomeEmployeeInformation(staffReq.getOrderId(), eaCateSecond, eaBrandCode, staffCodeList,
				shopNo, storeLevel);
		// 需要获取员工->会员id
		StaffsIsMainDto mainStorePersons = this.isMainStorePersons(query, staffReq);
		log.info(String.format("门店[主营|兼营]员工信息匹配查询结果: 基本信息:%s, 参数: %s, 查询结果: %s", logEmbedPort, JSONObject.toJSONString(staffReq), JSONObject.toJSONString(mainStorePersons)));
		return mainStorePersons;
	}

	/**
	 * 匹配供应商: 职匹配主营的数据信息 兼营的用不上
	 * @param empl
	 * @param staffReq
	 * @return
	 */
	private boolean matchSupplior(EmployeeInfoDto empl, StaffReqsDto staffReq) {
		String supplierCode = staffReq.getSupplierCode();
		if(StringUtils.isBlank(supplierCode)) {
			// 供应商编码没有输入的情况下不需要判断一下逻辑
			return true;
		}
		String logEmbedPort = staffReq.getLogEmbedPort();
		String emplClass = empl.getBaseInfo().getEmplClass();
		boolean is_sp = false;
		// emplClass D， J
		if (BaseConstants.EMPL_CLASS_J.equals(emplClass) || BaseConstants.EMPL_CLASS_D.equals(emplClass)) {
			List<ResponseGroupVendorDto> gomeVendorList = empl.getGomeVendorList();
			if(gomeVendorList != null && gomeVendorList.size() > 0) {
				is_sp = gomeVendorList.stream().anyMatch(rgvd -> supplierCode.equals(rgvd.getVendorCode()));
			}
		}
		if(!is_sp) {
			log.info(String.format("门店[主营]促销员与供应商信息[不匹配]: 基本信息:%s, employeeId:%s, supplierCode:%s", logEmbedPort, empl.getBaseInfo().getEmployeeId(), supplierCode));
		}
		return is_sp;
	}

	/**
	 * 匹配门店员工集合
	 *
	 * @param query
	 * @param staffReq
	 * @return
	 */
	private StaffsIsMainDto isMainStorePersons(List<EmployeeInfoDto> query, StaffReqsDto staffReq) {
		if(CollectionUtils.isEmpty(query)) {
			return null;
		}
		// 主营员工集合
		List<EmployeeInfoDto> mainList = new ArrayList<>();
		// 兼营员工集合
		List<EmployeeInfoDto> unmainList = new ArrayList<>();
		for (EmployeeInfoDto empl : query) {
			// 判断员工是否是主营|兼营
			int is_main = this.matchStaffIsMain(empl, staffReq);
			if (is_main > 0) {
				// 主营： 判断供应商代码 + 品牌 + 品类 + 门店
				if (BaseConstants.IS_MAIN_INT_Y == is_main) {
					// 匹配供应商员工
					boolean is_sp = this.matchSupplior(empl, staffReq);
					if(is_sp) {
						mainList.add(empl);
					}
				} else if (BaseConstants.IS_MAIN_INT_N == is_main) {
					unmainList.add(empl);
				}
			}
		}
		// 对于含有主营员工来说， 优先， 没有主营员工，在选兼营员工
		StaffsIsMainDto sd = new StaffsIsMainDto();
		if (mainList.size() > 0) {
			sd.setMainStaffs(mainList);
		} else if (unmainList.size() > 0) {
			sd.setUnMainStaffs(unmainList);
		}
		return sd;
	}


	/**
	 * 匹配是否是主营
	 * <p>
	 * 1:主营, 2:兼营, 0:错误数据
	 *
	 * @param empl
	 * @param staffReq
	 * @return
	 */
	private int matchStaffIsMain(EmployeeInfoDto empl, StaffReqsDto staffReq) {

		// 判断主营兼营字段
		List<GomeCategoryBrand> gsscbList = empl.getGsscbList();
		if (null == gsscbList || gsscbList.size() <= 0) {
			return 0; // 数据不匹配
		}
		int is_main = 0;
		String logEmbedPort = staffReq.getLogEmbedPort();
		String shopNo = staffReq.getShopNo();
		String eaBrandCode = staffReq.getEaBrandCode();
		String eaCateSecond = staffReq.getEaCateSecond();
		/**
		 * 匹配品牌_品类_门店 数据:
		 * <p>
		 * 第一步： 判断品牌+品类 赋值 is_match_br_ct_store = 1，
		 * <p>
		 * 第二部，判断是否是本门店员工 is_match_br_ct_store = 2
		 * <p>
		 */
		int is_match_br_ct_store = 0;
		// 过滤对应条件的数据
		String employeeId = empl.getBaseInfo().getEmployeeId();
		boolean is_br_ct = gsscbList.stream().anyMatch(
				gcb -> eaBrandCode.equals(gcb.getBrandCode()) && eaCateSecond.equals(gcb.getCategoryCode()));
		if (is_br_ct) {
			is_match_br_ct_store = 1;
		} else {
			log.info(String.format("门店促销员员工与订单品牌/品类[不匹配], 基本信息:%s, employeeId:%s, 品牌:%s, 品类:%s", logEmbedPort, employeeId, eaBrandCode, eaCateSecond));
			return 0; // 跳过一下所有操作
		}
		// 排重，获取is_main字段数据
		Stream<String> distinct = gsscbList.stream().filter(
				gcb -> eaBrandCode.equals(gcb.getBrandCode()) && eaCateSecond.equals(gcb.getCategoryCode()))
				.map(e -> e.getIsMain()).distinct();
		// 有一条主营数据即为主营, 否则为兼营, 匹配条件全部兼营数据, 防止数据空
		boolean match_is_main = distinct.allMatch(x -> BaseConstants.IS_MAIN_STR_N.equals(x));
		if (match_is_main) {
			is_main = BaseConstants.IS_MAIN_INT_N;
		} else {
			is_main = BaseConstants.IS_MAIN_INT_Y;
		}
		// 判断门店促销员信息
		if (is_match_br_ct_store == 1) {
			List<GomeEmployeePostInformation> gepis = empl.getGomeEmployeePostInformationList();
			if (null == gepis || gepis.size() <= 0) {
				return 0; // 数据不匹配
			}
			// 匹配一条门店促销员对应门店信息
			boolean has_shop = gepis.stream().anyMatch(gei -> shopNo.equals(gei.getShop()));
			if (has_shop) {
				is_match_br_ct_store = 2;
			} else {
				// 有问题的信息加入日志
				log.info(String.format("门店促销员工身份门店信息[不匹配], 基本信息:%s, employeeId:%s, shopNo:%s", logEmbedPort, employeeId, shopNo));
			}
		}
		
		if (is_match_br_ct_store != 2) {
			return 0;// 没有匹配到数据， 跳过循环
		}
		return is_main;
	}
	
	//	销售组织代码 single
	public GomeOrganization getSellingOrganization(String organizationId) {
		log.info(String.format("查询销售组织代码信息, 参数:%s", organizationId));
		GomeOrganization ret = sellingOrganizationQueryClient.getSellingOrganization(organizationId);
		log.info(String.format("查询销售组织代码信息, 结果:%s", JSONObject.toJSONString(ret)));
		return ret;
	}
	
	//	销售组织代码 array
	public List<GomeOrganization> getSellingOrganization(String[] organizationIds) {
		log.info(String.format("查询销售组织代码信息集合, 参数:%s", JSONObject.toJSONString(organizationIds)));
		List<GomeOrganization> ret = sellingOrganizationQueryClient.getSellingOrganization(organizationIds);
		log.info(String.format("查询销售组织代码信息集合, 结果:%s", JSONObject.toJSONString(ret)));
		return ret;
	}

	/**
	 *
	 * @param orderId
	 * @param categoryId
	 * @param brandId
	 * @param employeeIdList
	 * @param shop
	 * @return
	 */
	private List<EmployeeInfoDto> queryGomeEmployeeInfos(String orderId, String categoryId, String brandId, List<String> employeeIdList, String shop){
		return gomeEmployeeInfoService.queryGomeEmployeeInfos(orderId, categoryId, brandId, employeeIdList, shop);
	}

}
