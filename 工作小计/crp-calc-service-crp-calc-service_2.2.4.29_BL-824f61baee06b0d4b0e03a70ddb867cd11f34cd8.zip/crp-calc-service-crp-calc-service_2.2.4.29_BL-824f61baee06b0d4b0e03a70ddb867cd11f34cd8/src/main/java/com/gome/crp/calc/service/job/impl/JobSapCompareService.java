package com.gome.crp.calc.service.job.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.client.message.ISendMessage;
import com.gome.crp.calc.constants.*;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;
import com.gome.crp.calc.manager.JobSapCompareManager;
import com.gome.crp.calc.mybatis.mapper.CalcNoResultMapper;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.mapper.SapAccountMapper;
import com.gome.crp.calc.mybatis.model.CalcNoResult;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapAccount;
import com.gome.crp.calc.service.order.impl.OrderCOServiceImpl;
import com.gome.crp.calc.service.order.impl.OrderDLServiceImpl;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.util.GcacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

@Slf4j
@Service
public class JobSapCompareService {
    private static final int PAGE_SIZE = 500;
    private static final int EXPIRE_HOURS = 7 * 24;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private SapAccountMapper sapAccountMapper;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private JobSapCompareManager jobSapCompareManager;
    @Autowired
    private CalcNoResultMapper calcNoResultMapper;
    @Autowired
    private OrderCOServiceImpl orderCOServiceImpl;
    @Autowired
    private OrderDLServiceImpl orderDLServiceImpl;
    @Autowired
    private ISendMessage iSendMessage;

    public void scanNorm() {
        long startTime = System.currentTimeMillis();
        log.info("定时任务-sap严控执行开始");

        //幂等校验
        String cronJobSapCompareLock = CacheKeyConstants.getCronJobSapCompareLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJobSapCompareLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobSapCompareIdIndex = CacheKeyConstants.getCronJobSapCompareIdIndex();
                long idIndex = selectIndexPosition(cronJobSapCompareIdIndex);

                //查询PAGE_SIZE条数据（启动,未扫描）,时间createTime（-7天至当前）
                List<SapAccount> records = selectSapAccounts(idIndex);

                //更新数据下次处理位置
                updateSapAccountNextIndexPosition(cronJobSapCompareIdIndex, records);

                if (!CollectionUtils.isEmpty(records)) {
                    for (SapAccount sapAccount : records) {
                        //循环比较
                        compareStoreCalcResult(sapAccount);
                    }
                }
            }

            log.info("定时任务-sap严控处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-sap严控处理异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJobSapCompareLock});
            } catch (Exception ex) {
                log.error("定时任务-删除sap严控防重键异常cronJobSapCompareLock:{}", cronJobSapCompareLock, ex);
            }
        }
    }

    private void compareStoreCalcResult(SapAccount sapAccount) {
        //查询提成计算订单
        List<CalcResult> calcResultList = selectCalcResults(sapAccount);
        if (!CollectionUtils.isEmpty(calcResultList)) {
            //匹配计划奖励
            processRelation(sapAccount, calcResultList);
        } else {
            //未匹配计划奖励
            boolean isExists = isExistsCalcNoResult(sapAccount);
            if (isExists) {
                SapAccount updateSapAccount = getUpdateSapAccount(sapAccount);
                sapAccountMapper.updateById(updateSapAccount);
            }
        }
    }

    private void processRelation(SapAccount sapAccount, List<CalcResult> calcResultList) {
        //更新计算数据集合
        List<CalcResult> updateCalcResultList = new ArrayList<>(calcResultList.size());

        //按促销费类型统计金额
        Map<String, Long> promotionsAwardAmount = getPromotionsAwardAmount(calcResultList);
        boolean isAllMatch = true;
        for (CalcResult calcResult : calcResultList) {
            //订单匹配
            boolean isMatch = isMatch(sapAccount, calcResult);
            if (isMatch) {
                // 校验采购组织
                if (!isMatchPurchaseCode(sapAccount, calcResult)) {
                    String content = String.format("采购组织不一致calcResultId:%s", calcResult.getId());
                    SendMessageDto sendMessageDto = new SendMessageDto(SendMsgTypeEnum.SEND_EMAIL.getCode(), content, SendMsgBusinessTypeEnum.PURCHASE_INCONSISTENT.getCode());
                    sendMessageDto.setTopic("提成二期系統-严控异常报警");
                    sendMessageDto.setUserList(MailAddressEnum.getMailAddressList());
                    iSendMessage.sendAsyncMsg(sendMessageDto);
                    updateCalcResultList.add(getFailureCalcResult(calcResult));
                    continue;
                }

                //校验挂账挂账金额是否大于奖励金额
                String promotionsType = String.valueOf(calcResult.getPromotionsType());
                Long awardAmountTotal = promotionsAwardAmount.get(promotionsType);
                if (awardAmountTotal != null && sapAccount.getDmbtr3() != null && awardAmountTotal <= sapAccount.getDmbtr3()) {
                    updateCalcResultList.add(getUpdateCalcResult(calcResult));
                } else {
                    calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_PRIZE_AMOUNT_OVER_LIMIT.getMsg());
                    updateCalcResultList.add(getFailureCalcResult(calcResult));

                    String content = String.format("挂账金额小于奖励金额calcResultId:%s", calcResult.getId());
                    SendMessageDto sendMessageDto = new SendMessageDto(SendMsgTypeEnum.SEND_EMAIL.getCode(), content, SendMsgBusinessTypeEnum.ACCOUNT_AMOUNT.getCode());
                    sendMessageDto.setTopic("提成二期系統-严控异常报警");
                    sendMessageDto.setUserList(MailAddressEnum.getMailAddressList());
                    iSendMessage.sendAsyncMsg(sendMessageDto);
                }

                // 校验提奖限额是否小于提奖金额，重复计算的时候，也会走到此处的
                if (BaseConstants.CALC_DEFAULT_LIMIT_AWARD_AMOUNT != calcResult.getLimitAwardAmount() && calcResult.getLimitAwardAmount() < calcResult.getAwardAmount()) {
                    updateCalcResultList.add(getUpdateCalcResultAmount(calcResult));
                }

            } else {
                isAllMatch = false;
            }
        }

        //更新匹配结果
        if (isAllMatch) {
            SapAccount updateSapAccount = getUpdateSapAccount(sapAccount);
            jobSapCompareManager.doUpdateCalcResultJobStatus(updateSapAccount, updateCalcResultList);
        } else {
            //更新旧数据为无效
            List<CalcResult> updateRecalculateResultList = getUpdateRecalculateResult(calcResultList);
            List<Long> deletedRecalculateResultIds = getDeletedRecalculateResultId(updateRecalculateResultList);

            CalcResult calcResult = calcResultMapper.selectById(calcResultList.get(0).getId());
            jobSapCompareManager.doUpdateCalcResultJobStatus(updateRecalculateResultList, deletedRecalculateResultIds);

            //根据状态重新计算
            switch (calcResult.getGomeStatus()) {
                case BaseConstants.ORDER_CO_STATUS:
                    OrderCalcDto coOrderCalcDto = JSON.parseObject(calcResult.getCoMsgBody(), OrderCalcDto.class);
                    orderCOServiceImpl.redoCalc(coOrderCalcDto, calcResultList);
                    break;
                case BaseConstants.ORDER_DL_STATUS:
                    OrderCalcDto dlOrderCalcDto = JSON.parseObject(calcResult.getDlMsgBody(), OrderCalcDto.class);
                    orderDLServiceImpl.redoCalc(dlOrderCalcDto, calcResultList);
                    break;
                default:
                    log.error("重新计算,订单状态不正确calcResult:" + JSON.toJSONString(calcResult));
            }
        }
    }

    /**
     * 按促销费类型统计金额
     *
     * @param calcResultList
     * @return
     */
    private Map<String, Long> getPromotionsAwardAmount(List<CalcResult> calcResultList) {
        Map<String, Long> promotionsAmountMap = new HashMap<>();
        for (CalcResult calcResult : calcResultList) {
            String promotionsType = String.valueOf(calcResult.getPromotionsType());
            if (promotionsAmountMap.containsKey(promotionsType)) {
                Long awardAmountTotal = promotionsAmountMap.get(promotionsType) == null ? 0L : promotionsAmountMap.get(promotionsType);
                Long awardAmount = calcResult.getAwardAmount() == null ? Long.valueOf(0L) : calcResult.getAwardAmount();
                promotionsAmountMap.put(promotionsType, awardAmountTotal + awardAmount);
            } else {
                Long awardAmount = calcResult.getAwardAmount() == null ? Long.valueOf(0L) : calcResult.getAwardAmount();
                promotionsAmountMap.put(promotionsType, awardAmount);
            }
        }

        return promotionsAmountMap;
    }

    private List<Long> getDeletedRecalculateResultId(List<CalcResult> calcResultList) {
        List<Long> deletedRecalculateResultIdList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            deletedRecalculateResultIdList.add(calcResult.getId());
        }

        return deletedRecalculateResultIdList;
    }

    private List<CalcResult> getUpdateRecalculateResult(List<CalcResult> calcResultList) {
        List<CalcResult> calcRecalculateList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            CalcResult updateCalcResult = new CalcResult();
            updateCalcResult.setId(calcResult.getId());
            updateCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
            updateCalcResult.setFailureReason(calcResult.getFailureReason());
            updateCalcResult.setIsDelete(IsDeleteEnum.YES.getCode());
            calcRecalculateList.add(updateCalcResult);
        }

        return calcRecalculateList;
    }

    /**
     * 校验合同号函号供价是否相同
     *
     * @param sapAccount
     * @param calcResult
     * @return
     */
    private boolean isMatch(SapAccount sapAccount, CalcResult calcResult) {
        String contractType = calcResult.getContractType();
        //签约类型-合同
        if (BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+协议（该场景暂时没有）
        if (BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+有函
        if (BaseConstants.PLAN_SIGN_LETTER_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult) && isSameLetterNo(sapAccount, calcResult) && isSameOfferPrize(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+无函资源池
        if (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 校验采购组织是否相同
     *
     * @param sapAccount
     * @param calcResult
     * @return
     */
    private boolean isMatchPurchaseCode(SapAccount sapAccount, CalcResult calcResult) {
        String contractType = calcResult.getContractType();
        //签约类型-合同
        if (BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(contractType)) {
            if (isSameContractPurchaseCode(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+协议（该场景暂时没有）
        if (BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(contractType)) {
            return true;
        }

        //签约类型-合同+有函
        if (BaseConstants.PLAN_SIGN_LETTER_TYPE.equals(contractType)) {
            if (isSameLetterPurchaseCode(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+无函资源池
        if (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(contractType)) {
            if (isSameContractPurchaseCode(sapAccount, calcResult)) {
                return true;
            }
        }

        return false;
    }

    private boolean isSameOfferPrize(SapAccount sapAccount, CalcResult calcResult) {
        if (ReuNoEnum.FY0000008.getCode().equals(sapAccount.getReuno()) &&
                BaseConstants.PLAN_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                !BaseConstants.COMPACT_CLASS_LSDK.equals(calcResult.getContractClass()) &&
                !BaseConstants.PROBLEM_SALE_MODEL_11.equals(calcResult.getSalesModel())) {
            //供价比较
            if (sapAccount.getDmbtr1() != null && calcResult.getOfferPrice() != null && sapAccount.getDmbtr1().longValue() == calcResult.getOfferPrice().longValue()) {
                return true;
            } else {
                String offerPrice = gcacheUtil.getKeyValue(CacheKeyConstants.getCronJobSapCompare20OfferPrice(calcResult.getId()));
                if (StringUtils.isEmpty(offerPrice)) {
                    // 把供价放到缓存，后续需要供价重新计算
                    gcacheUtil.putKeyValue(CacheKeyConstants.getCronJobSapCompare20OfferPrice(calcResult.getId()), CacheKeyConstants.CACHE_KEY_TIMEOUT, sapAccount.getDmbtr1().toString());
                    calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_OFFER_PRIZE_NO_MATCH.getMsg() + sapAccount.getDmbtr1());
                    return false;
                } else {
                    // 假如说已经存在供价，逻辑还走到这里，证明，此订单一定是重复计算过，且供价还不一致了，这时，我们不再重新计算，但是要报警
                    return true;
                }
            }
        }

        return true;
    }

    private boolean isSameContractPurchaseCode(SapAccount sapAccount, CalcResult calcResult) {
        if (calcResult.getContractPurchaseCode() != null &&
                calcResult.getContractPurchaseCode().equals(sapAccount.getSoBuyorgCode())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_CONTRACT_PURCHASE_CODE_NO_MATCH.getMsg() + sapAccount.getSoBuyorgCode());
        return false;
    }

    private boolean isSameLetterPurchaseCode(SapAccount sapAccount, CalcResult calcResult) {
        if (calcResult.getExtraPurchaseCode() != null &&
                calcResult.getExtraPurchaseCode().equals(sapAccount.getSoBuyorgCode())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_EXTRA_PURCHASE_CODE_NO_MATCH.getMsg() + sapAccount.getSoBuyorgCode());
        return false;
    }

    private boolean isSameContractNo(SapAccount sapAccount, CalcResult calcResult) {
        if (sapAccount.getNewno() != null && sapAccount.getNewno().equals(calcResult.getContractCode())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_CONTRACT_NO_MATCH.getMsg() + sapAccount.getNewno());
        return false;
    }

    private boolean isSameLetterNo(SapAccount sapAccount, CalcResult calcResult) {
        if (sapAccount.getKonnr() != null && sapAccount.getKonnr().equals(calcResult.getExtraNum())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_LETTER_NO_MATCH.getMsg() + sapAccount.getKonnr());
        return false;
    }

    private long selectIndexPosition(String indexPositionKey) {
        long idIndex = 0L;
        String keyValue = gcacheUtil.getKeyValue(indexPositionKey);
        if (keyValue != null) {
            idIndex = Long.parseLong(keyValue);
        }
        return idIndex;
    }

    private boolean isExistsCalcNoResult(SapAccount sapAccount) {
        CalcNoResult query = new CalcNoResult();
        query.setSapDetailId(sapAccount.getSoDeliveryDetailId());
        query.setChannel(sapAccount.getSoSaleChannel());
        QueryWrapper<CalcNoResult> queryWrapper = Wrappers.query(query);
        Integer count = calcNoResultMapper.selectCount(queryWrapper);
        if (count != null && count > 0) {
            return true;
        } else {
            return false;
        }
    }

    private List<CalcResult> selectCalcResults(SapAccount sapAccount) {
        List<CalcResult> filterCalcResults = Collections.emptyList();

        CalcResult query = new CalcResult();
        query.setSapDetailId(sapAccount.getSoDeliveryDetailId());
        query.setChannel(sapAccount.getSoSaleChannel());
        query.setJobStatus(BaseConstants.CRD_JOB_STATUS_1_N);
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
        queryWrapper.and(wrapper -> wrapper.eq("gome_status", BaseConstants.ORDER_CO_STATUS).or().eq("gome_status", BaseConstants.ORDER_DL_STATUS));

        List<CalcResult> calcResults = calcResultMapper.selectList(queryWrapper);
        if (!CollectionUtils.isEmpty(calcResults)) {
            filterCalcResults = new ArrayList<>(calcResults.size());
            for (CalcResult calcResult : calcResults) {
                if (isSapCompare(calcResult) && isSameReuno(calcResult, sapAccount)) {
                    filterCalcResults.add(calcResult);
                }
            }
        }

        return filterCalcResults;
    }

    /**
     * 收入项目编码是否相同
     *
     * @param calcResult
     * @param sapAccount
     * @return
     */
    private boolean isSameReuno(CalcResult calcResult, SapAccount sapAccount) {
        String reuno = sapAccount.getReuno();
        if (ReuNoEnum.FY0000087.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_REPLACE_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
                return true;
            }
        }

        if (ReuNoEnum.FY0000008.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
                return true;
            }
        }

        if (ReuNoEnum.FY0000084.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                    BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(calcResult.getExtraPolicyCode())) {
                return true;
            }
        }

        if (ReuNoEnum.FY0000078.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                    (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(calcResult.getExtraPolicyCode())
                            || BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(calcResult.getExtraPolicyCode()))) {
                return true;
            }
        }
        return false;
    }

    //是否严控判断
    private boolean isSapCompare(CalcResult calcResult) {
        if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return true;
        }

        if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return true;
        }

        if (BaseConstants.PLAN_REPLACE_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return true;
        }

        return false;
    }

    private SapAccount getUpdateSapAccount(SapAccount sapAccount) {
        SapAccount updateSapAccount = new SapAccount();
        updateSapAccount.setId(sapAccount.getId());
        updateSapAccount.setIsScan(IsScanEnum.YES.getCode());
        return updateSapAccount;
    }

    private CalcResult getUpdateCalcResult(CalcResult calcResult) {
        CalcResult updateCalcResult = new CalcResult();
        updateCalcResult.setId(calcResult.getId());
        updateCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_0);
        return updateCalcResult;
    }

    private CalcResult getFailureCalcResult(CalcResult calcResult) {
        CalcResult failureCalcResult = new CalcResult();
        failureCalcResult.setId(calcResult.getId());
        failureCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
        failureCalcResult.setFailureReason(calcResult.getFailureReason());
        return failureCalcResult;
    }

    private CalcResult getUpdateCalcResultAmount(CalcResult calcResult) {
        CalcResult updateCalcResult = new CalcResult();
        updateCalcResult.setId(calcResult.getId());
        updateCalcResult.setAwardAmount(calcResult.getLimitAwardAmount());
        return updateCalcResult;
    }

    private List<SapAccount> selectSapAccounts(Long idIndex) {
        Page<SapAccount> page = new Page<>();
        page.setSearchCount(false);
        page.setSize(PAGE_SIZE);

        SapAccount query = new SapAccount();
        query.setIsScan(IsScanEnum.NO.getCode());
        QueryWrapper<SapAccount> queryWrapper = Wrappers.query(query);
        queryWrapper.orderByAsc("id");
        queryWrapper.gt("create_time", DateUtils.addDateMinut(new Date(), -1 * EXPIRE_HOURS));
        queryWrapper.gt("id", idIndex);

        Page<SapAccount> sapAccountPage = sapAccountMapper.selectPage(page, queryWrapper);
        return sapAccountPage.getRecords();
    }

    public void scanUnSuc() {
        long startTime = System.currentTimeMillis();
        log.info("定时任务-sap严控,未匹配订单状态变更开始");
        //检测时间createTime（-3*7天至-2*7天）
        Date now = new Date();
        String startCreateTime = DateUtils.addDateMinut(now, -3 * EXPIRE_HOURS);
        String endCreateTime = DateUtils.addDateMinut(now, -2 * EXPIRE_HOURS);

        //提成订单jobStatus状态（-1初始状态至4失效)
        CalcResult updateCalcResult = new CalcResult();
        updateCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
        updateCalcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_SEVEN_DAYS_NO_MATCH.getMsg());
        UpdateWrapper<CalcResult> calcResultWrapper = Wrappers.update();
        calcResultWrapper.between("create_time", startCreateTime, endCreateTime);
        calcResultWrapper.eq("job_status", BaseConstants.CRD_JOB_STATUS_1_N);
        calcResultWrapper.and(wrapper -> wrapper.eq("gome_status", BaseConstants.ORDER_CO_STATUS).or().eq("gome_status", BaseConstants.ORDER_DL_STATUS));

        try {
            calcResultMapper.update(updateCalcResult, calcResultWrapper);
        } catch (Exception e) {
            log.error("定时任务-sap严控,未匹配订单状态变更异常", e);
            return;
        }

        log.info("定时任务-sap严控,未匹配订单状态变更完成,耗时:{}", (System.currentTimeMillis() - startTime));
    }

    public void scanNoDetect() {
        long startTime = System.currentTimeMillis();
        log.info("定时任务-sap不严控,数据状态变更开始");

        //幂等校验
        String cronJobSapNoCompareLock = CacheKeyConstants.getCronJobSapNoCompareLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJobSapNoCompareLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobSapNoCompareIdIndex = CacheKeyConstants.getCronJobSapNoCompareIdIndex();
                long idIndex = selectIndexPosition(cronJobSapNoCompareIdIndex);

                //查询PAGE_SIZE条数据,时间createTime（-7天至当前）
                List<CalcResult> calcResults = selectNoDetectCalcResult(idIndex);

                //更新数据下次处理位置
                updateCalcResultNextIndexPosition(cronJobSapNoCompareIdIndex, calcResults);

                //更新匹配结果
                if (!CollectionUtils.isEmpty(calcResults)) {
                    List<CalcResult> updateCalcResults = new ArrayList<>(calcResults.size());
                    for (CalcResult calcResult : calcResults) {
                        if (!isSapCompare(calcResult)) {
                            CalcResult updateCalcResult = getUpdateCalcResult(calcResult);
                            updateCalcResults.add(updateCalcResult);
                        }
                    }

                    if (!CollectionUtils.isEmpty(updateCalcResults)) {
                        jobSapCompareManager.doUpdateCalcResultJobStatus(updateCalcResults);
                    }
                }
            }

            log.info("定时任务-sap不严控,数据状态变更完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-sap不严控,数据状态变更异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJobSapNoCompareLock});
            } catch (Exception ex) {
                log.error("定时任务-删除sap不严控防重键异常cronJobSapNoCompareLock:{}", cronJobSapNoCompareLock, ex);
            }
        }
    }

    private List<CalcResult> selectNoDetectCalcResult(Long idIndex) {
        Page<CalcResult> page = new Page<>();
        page.setSearchCount(false);
        page.setSize(PAGE_SIZE);

        //检测时间createTime（-7天至当前）
        Date now = new Date();
        String startCreateTime = DateUtils.addDateMinut(now, -1 * EXPIRE_HOURS);

        CalcResult query = new CalcResult();
        QueryWrapper<CalcResult> queryWrapper = Wrappers.query(query);
        queryWrapper.orderByAsc("id");
        queryWrapper.gt("id", idIndex);
        queryWrapper.gt("create_time", startCreateTime);
        queryWrapper.eq("job_status", BaseConstants.CRD_JOB_STATUS_1_N);
        queryWrapper.and(wrapper -> wrapper.eq("gome_status", BaseConstants.ORDER_CO_STATUS).or().eq("gome_status", BaseConstants.ORDER_DL_STATUS));

        Page<CalcResult> calcResultPage = calcResultMapper.selectPage(page, queryWrapper);
        return calcResultPage.getRecords();
    }

    private void updateSapAccountNextIndexPosition(String idIndexName, List<SapAccount> sapAccounts) {
        if (CollectionUtils.isEmpty(sapAccounts) || sapAccounts.size() < PAGE_SIZE) {
            gcacheUtil.putKeyValue(idIndexName, "0");
        } else {
            SapAccount sapAccount = sapAccounts.get(sapAccounts.size() - 1);
            gcacheUtil.putKeyValue(idIndexName, String.valueOf(sapAccount.getId()));
        }
    }

    private void updateCalcResultNextIndexPosition(String idIndexName, List<CalcResult> calcResults) {
        if (CollectionUtils.isEmpty(calcResults) || calcResults.size() < PAGE_SIZE) {
            gcacheUtil.putKeyValue(idIndexName, "0");
        } else {
            CalcResult calcResult = calcResults.get(calcResults.size() - 1);
            gcacheUtil.putKeyValue(idIndexName, String.valueOf(calcResult.getId()));
        }
    }
}