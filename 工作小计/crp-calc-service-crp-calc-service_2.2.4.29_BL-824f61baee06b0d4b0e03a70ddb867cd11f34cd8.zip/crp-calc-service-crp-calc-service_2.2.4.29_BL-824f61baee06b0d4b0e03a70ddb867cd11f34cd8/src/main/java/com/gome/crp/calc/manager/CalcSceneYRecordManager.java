package com.gome.crp.calc.manager;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.mybatis.model.CalcSceneYRecord;
import com.gome.crp.calc.mybatis.service.ICalcSceneYRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.List;

/**
 * 处理计算Y 关账金额的表
 */
@Service
public class CalcSceneYRecordManager {
    @Autowired
    private ICalcSceneYRecordService iCalcSceneYRecordService;

    @Transactional(rollbackFor = Exception.class)
    public boolean saveCalcSceneYRecord(CalcSceneYRecord calcSceneYRecord){
        return iCalcSceneYRecordService.save(calcSceneYRecord);
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean updateCalcSceneYRecord(CalcSceneYRecord calcSceneYRecord){
        UpdateWrapper<CalcSceneYRecord> updateWrapper = new UpdateWrapper<CalcSceneYRecord>().eq("id", calcSceneYRecord.getId());
        return iCalcSceneYRecordService.update(calcSceneYRecord, updateWrapper);
}

    public CalcSceneYRecord queryCalcSceneYRecord(CalcSceneYRecord calcSceneYRecord){
        QueryWrapper<CalcSceneYRecord> queryWrapper = new QueryWrapper<CalcSceneYRecord>().select(new String[]{"id","user_id","staff_code","plan_id","profile_id","award_price"})
                .eq("staff_code", calcSceneYRecord.getStaffCode()).eq("profile_id", calcSceneYRecord.getProfileId())
                .eq("plan_id",calcSceneYRecord.getPlanId()).eq("is_scan", BaseConstants.IS_NO_SCAN_ENUM);
        return iCalcSceneYRecordService.getOne(queryWrapper);
    }
    /**
     * 扫描满足条件的总条数
     * @return
     */
    public Integer queryCountOfSceneY(){
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH, instance.get(Calendar.DAY_OF_MONTH) - 1);
        QueryWrapper<CalcSceneYRecord> queryWrapper = new QueryWrapper<CalcSceneYRecord>().le("plan_end_time", instance.getTime()).eq("is_scan", BaseConstants.IS_NO_SCAN_ENUM).orderByAsc("id");
        return iCalcSceneYRecordService.count(queryWrapper);
    }


    /**
     * 定时任务处理Y场景数据
     *
     * @return
     */
    public List<CalcSceneYRecord> queryListOfSceneY(int pageSize) {
        Calendar instance = Calendar.getInstance();
        instance.set(Calendar.DAY_OF_MONTH, instance.get(Calendar.DAY_OF_MONTH) - 1);
        Page<CalcSceneYRecord> page = new Page<>();
        page.setSize(pageSize);
        QueryWrapper<CalcSceneYRecord> queryWrapper = new QueryWrapper<CalcSceneYRecord>().select(new String[]{"id","user_id","staff_code","plan_id","profile_id","award_price","plan_end_time","is_delete"})
                .le("plan_end_time", instance.getTime()).eq("is_scan", BaseConstants.IS_NO_SCAN_ENUM).orderByAsc("ID");
        Page<CalcSceneYRecord> pageResult = iCalcSceneYRecordService.page(page, queryWrapper);
        return pageResult.getRecords();
    }

    /**
     * 处理百分之15提奖限价
     * @return
     */
    public CalcSceneYRecord queryCalcSceneYRecordByParam(String staffCode,String profileId,String planId){
        QueryWrapper<CalcSceneYRecord> queryWrapper = new QueryWrapper<CalcSceneYRecord>().select(new String[]{"id","user_id","staff_code","plan_id","profile_id","award_price"})
                .eq("profile_id", profileId)
                .eq("plan_id",planId)
                .eq("staff_code", staffCode);
        return iCalcSceneYRecordService.getOne(queryWrapper);
    }

}
