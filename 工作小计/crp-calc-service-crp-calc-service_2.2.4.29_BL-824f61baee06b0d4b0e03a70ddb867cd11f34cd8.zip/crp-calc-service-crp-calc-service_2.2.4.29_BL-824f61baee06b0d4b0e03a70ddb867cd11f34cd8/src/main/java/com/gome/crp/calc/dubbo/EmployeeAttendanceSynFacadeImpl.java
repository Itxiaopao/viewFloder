package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dto.EmployeeAttendanceDto;
import com.gome.crp.calc.facade.dto.ResultDTO;
import com.gome.crp.calc.facade.dubbo.IDubboEmployeeAttendanceSynFacade;
import com.gome.crp.calc.manager.employee.EmployeeAttendanceSynManager;
import com.gome.crp.calc.mybatis.model.EmployeeAttendance;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Slf4j
@Service("iDubboEmployeeAttendanceSynFacade")
public class EmployeeAttendanceSynFacadeImpl implements IDubboEmployeeAttendanceSynFacade {
    @Autowired
    private EmployeeAttendanceSynManager employeeAttendanceSynManager;
    @Override
    public ResultDTO<Boolean> synEmployeeAttendance(ArrayList<EmployeeAttendanceDto> employeeAttendanceVoList) {
        log.info("同步促销员考勤信息,总条数:{}",employeeAttendanceVoList.size());
        long l = System.currentTimeMillis();
        try {
            for (EmployeeAttendanceDto thisEmployeeAttendanceDto : employeeAttendanceVoList
            ) {
                log.info("同步考勤员:{}",thisEmployeeAttendanceDto);
                EmployeeAttendance employeeAttendanceDto = new EmployeeAttendance();
                BeanUtils.copyProperties(thisEmployeeAttendanceDto,employeeAttendanceDto);
                employeeAttendanceSynManager.insertEmployeeAttendance(employeeAttendanceDto);
            }
            long l1 = System.currentTimeMillis();
            log.info("批处理耗时:{}",l1 - l);
        }catch (Exception e){
            log.error("同步促销员考勤信息,异常信息如: ",e);
            return new ResultDTO<Boolean>(false);
        }
        return new ResultDTO<Boolean>(true);
    }

}
