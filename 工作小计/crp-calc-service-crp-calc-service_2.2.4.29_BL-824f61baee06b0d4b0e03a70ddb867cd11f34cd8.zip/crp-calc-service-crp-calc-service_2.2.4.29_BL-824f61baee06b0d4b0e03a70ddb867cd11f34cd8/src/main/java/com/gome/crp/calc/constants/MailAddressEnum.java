package com.gome.crp.calc.constants;

import java.util.ArrayList;
import java.util.List;

public enum MailAddressEnum {
    CHAYUBIN_ADDRESS("chayubing@gome.com.cn", "查雨兵"),
    LIUBIN_ADDRESS("liubin30@gome.com.cn", "刘斌"),
    ZHANGSHUANG_ADDRESS("zhangshuang29@gome.com.cn", "张爽"),
    CHENCHEN_ADDRESS("chenchen56@gome.com.cn", "陈晨"),
    GAOPENGFEI_ADDRESS("gaopengfei5@gome.com.cn", "高鹏飞"),
    LIBINBIN_ADDRESS("libinbin9@gome.com.cn", "李彬彬"),
    LIUHAIBIN_ADDRESS("liuhaibin2@gome.com.cn", "刘海滨"),
//    ZHULIBIN_ADDRESS("zhulibin@gome.com.cn", "朱礼彬"),
//    LIZHONGWEN_ADDRESS("lizhongwen@gome.com.cn", "李忠文"),
    ;

    private String code;
    private String msg;

    MailAddressEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

    public static List<String> getMailAddressList() {
        List<String> mailAddressList = new ArrayList<>();
        for (MailAddressEnum mailAddressEnum : MailAddressEnum.values()) {
            mailAddressList.add(mailAddressEnum.getCode());
        }

        return mailAddressList;
    }
}
