package com.gome.crp.calc.service.scene.formula.impl;

import com.gome.crp.calc.client.sap.impl.QueryPlanServiceImpl;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.formula.CategroyPointRateDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.sapDto.DivisionDto;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.formula.utils.CalcCategreyProfitRate;
import com.gome.crp.calc.service.scene.formula.IFormulaCYH;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * 差异化公式计算
 */
@Slf4j
@Service
public class FormulaCYH implements IFormulaCYH {
    @Autowired
    private IProblemService problemService;
    @Autowired
    private ICalcRewardsService calcRewardsService;
    @Autowired
    private QueryPlanServiceImpl queryPlanService;
    @Autowired
    private CalcCategreyProfitRate calcCategreyProfitRate;
    @Autowired
    private SceneUtils sceneUtils;

    //百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);
    private static BigDecimal percent_rate_cent_1 = BigDecimal.valueOf(1.0);

    // **********************************************************
    // 差异化
    // Logical:
    // 1. 厂家承担 + / + 优先级第一：11一步到位机
    // 1.1. (厂家承担 + 优先级第二：流水倒扣合同（C005） + 目前生产上只支持：01标准机、02包销机，但不参与逻辑校验)
    // 2. 厂家承担 + 优先级第三：非流水倒扣合同 + /
    // 3. 国美预算 + 非净价合同 + 01标准机
    // 4. 国美预算 + 净价合同（C002\C004） + 01标准机 + 包销机的现综合利润率和原综合利润率的值为空，则不给提奖
    // 5. 国美预算 + 流水倒扣合同（C005） + 02包销机 + 包销机的现综合利润率和原综合利润率的值为空，则不给提奖
    // 6. 国美预算 + 非流水倒扣合同 + 02包销机
    // 7. 国美预算 + / + 11一步到位机 + 现综合利润率没有值
    // 8. 国美预算 + / + 11一步到位机 + 现综合利润率和原综合利润率有值
    //***********************************************************
    public BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        String orderId = orderCalcDto.getOrderId();
        Long planId = planDto.getPlanId();
        String log_pre = String.format("订单: %s, 计划: %s, 场景: %s", orderId, planId, scene);
        BigDecimal ret = BigDecimal.valueOf(0.0);

        // 承担类型: 厂家承担, 国美承担
        Integer expenseOfferType = planDto.getExpenseOfferType();
        // 业务机型
        String salesModel = orderCalcDto.getSalesModel();
        // 合同类型
        String contractClass = planDto.getContractClass();
        String formula_log_pre = String.format("差异化-%s, 匹配计算公式参数: 承担类型-%s, 业务机型-%s, 合同类型-%s",
                log_pre, expenseOfferType, salesModel, contractClass);
        log.info(formula_log_pre);
        // 厂家承担 + / + 优先级第一：11一步到位机 (厂家承担 + 优先级第二：流水倒扣合同（C005） + 目前生产上只支持：01标准机、02包销机，但不参与逻辑校验)
        String formula_suffix = "公式-未匹配";
        if (BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE.equals(expenseOfferType + "")) {
            if (BaseConstants.PROBLEM_SALE_MODEL_11.equals(salesModel) || BaseConstants.COMPACT_CLASS_C005.equals(contractClass)) {
                formula_suffix = "公式-1";
                ret = this.formulaCYH_v2_fn1(orderCalcDto, planDto, scene, log_pre);
            } else if (!BaseConstants.COMPACT_CLASS_C005.equals(contractClass)) {
                // 厂家承担 + 优先级第三：非流水倒扣合同 + /
                formula_suffix = "公式-2";
                ret = this.formulaCYH_v2_fn2(orderCalcDto, planDto, scene, log_pre);
            }
            log.info(formula_log_pre + ", " + formula_suffix);
            return ret;
        } else if (BaseConstants.PLAN_EXPENSE_OFFER_TWO_TYPE.equals(expenseOfferType + "")) {
            if (BaseConstants.PROBLEM_SALE_MODEL_01.equals(salesModel)) {
                // 国美预算 + 非净价合同 + 01标准机
                if (BaseConstants.COMPACT_CLASS_C002_C004.indexOf(contractClass) < 0) {
                    formula_suffix = "公式-3";
                    ret = this.formulaCYH_v2_fn3(orderCalcDto, planDto, scene, log_pre);
                } else {
                    // 国美预算 + 净价合同（C002\C004） + 01标准机 + 包销机的现综合利润率和原综合利润率的值为空，则不给提奖
                    formula_suffix = "公式-4";
                    ret = this.formulaCYH_v2_fn4(orderCalcDto, planDto, scene, log_pre);
                }
                log.info(formula_log_pre + ", " + formula_suffix);
                return ret;
            }

            if (BaseConstants.PROBLEM_SALE_MODEL_02.equals(salesModel)) {
                // 国美预算 + 流水倒扣合同（C005） + 02包销机 + 包销机的现综合利润率和原综合利润率的值为空，则不给提奖
                if (BaseConstants.COMPACT_CLASS_C005.equals(contractClass)) {
                    formula_suffix = "公式-5";
                    ret = this.formulaCYH_v2_fn5(orderCalcDto, planDto, scene, log_pre);
                } else {
                    // 国美预算 + 非流水倒扣合同 + 02包销机
                    formula_suffix = "公式-6";
                    ret = this.formulaCYH_v2_fn6(orderCalcDto, planDto, scene, log_pre);
                }
                log.info(formula_log_pre + ", " + formula_suffix);
                return ret;
            }
            if (BaseConstants.PROBLEM_SALE_MODEL_11.equals(salesModel)) {
                // 国美预算 + / + 11一步到位机 + 现综合利润率没有值
                if (planDto.getNowRateProfit() == null) {
                    formula_suffix = "公式-7";
                    ret = this.formulaCYH_v2_fn7(orderCalcDto, planDto, scene, log_pre);
                } else if (planDto.getNowRateProfit() != null && planDto.getOldRateProfit() != null) {
                    // 国美预算 + / + 11一步到位机 + 现综合利润率和原综合利润率有值
                    formula_suffix = "公式-8";
                    ret = this.formulaCYH_v2_fn8(orderCalcDto, planDto, scene, log_pre);
                }
                log.info(formula_log_pre + ", " + formula_suffix);
                return ret;
            }
        }
        return ret;
    }

    /**
     * 差异化计算公式1
     * "提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例
     * 新增点位=新增月返+新增台返
     * 新增台返=台返金额÷计提现价×百分之100"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn1(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算1";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //台返金额，新增月返，校验是否有值
        checkAddRebate(orderCalcDto, planDto, log_pre, log_type);
        //台返金额
        BigDecimal stage_price = BigDecimal.valueOf(planDto.getAddEachRebate());
        //新增月返
        BigDecimal new_month_refune = planDto.getAddMonthlyRebate();
        //计提现价
        Assert.notNull(planDto.getCurrentPrice(), log_pre + log_type + "-计提现价金额: null");
        if (planDto.getCurrentPrice() == 0) {
            log.info(log_type + "-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        BigDecimal current = BigDecimal.valueOf(planDto.getCurrentPrice());
        //计算新增台返
        BigDecimal new_stage_refune = stage_price.multiply(percent_rate_cent_1).divide(current, 5, RoundingMode.DOWN);
        logs = String.format("%s-新增台返[ %s ]=台返金额[ %s ]÷计提现价[ %s ]×百分之100, target: %s"
                , log_type, new_stage_refune, stage_price, current, log_pre);
        log.info(logs);
        //计算新增点位
        BigDecimal new_point_rate = new_month_refune.multiply(percent_rate_normal).add(new_stage_refune);
        logs = String.format("%s-新增点位[ %s ]=新增月返[ %s x 0.01 ]+新增台返[ %s ], target: %s"
                , log_type, new_point_rate, new_month_refune, new_stage_refune, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=新增月返+新增台返; " +
                "新增台返=台返金额÷计提现价×百分之100";
        return getCalculatedResult(orderCalcDto, planDto, "计提现价", current, new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 差异化计算公司2
     * "提奖金额=（供价×新增点位×促消费提奖比例×发放比例+供价×新增点位×追加比例）×销售数量×XYZM比例
     * 新增点位=新增月返+新增台返
     * 新增台返=台返金额÷供价×百分之100"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn2(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算2";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //台返金额，新增月返，校验是否有值
        checkAddRebate(orderCalcDto, planDto, log_pre, log_type);
        //台返金额
        BigDecimal stage_price = BigDecimal.valueOf(planDto.getAddEachRebate());
        //新增月返
        BigDecimal new_month_refune = planDto.getAddMonthlyRebate();
        //供价
        Assert.notNull(planDto.getOfferPrice(), log_pre + log_type + "-共价金额: null");
        if (planDto.getOfferPrice() == 0) {
            log.info(log_type + "-供价为零, return 0.0, " + log_pre);
            return ret;
        }
        BigDecimal offer = BigDecimal.valueOf(planDto.getOfferPrice());
        //新增台返=台返金额÷供价×百分之100(以计算正常比例)
        BigDecimal new_stage_refune = stage_price.multiply(percent_rate_cent_1).divide(offer, 5, RoundingMode.DOWN);
        logs = String.format("%s-新增台返[ %s ]=台返金额[ %s ]÷供价[ %s ]×百分之100, target: %s"
                , log_type, new_stage_refune, stage_price, offer, log_pre);
        log.info(logs);
        //新增点位=新增月返+新增台返
        BigDecimal new_point_rate = new_month_refune.multiply(percent_rate_normal).add(new_stage_refune);
        logs = String.format("%s-新增点位[ %s ]合同=新增月返[ %s x 0.01 ]+新增台返[ %s ], target: %s"
                , log_type, new_point_rate, new_month_refune, new_stage_refune, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（供价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=新增月返+新增台返; " +
                "新增台返=台返金额÷供价×百分之100(以计算正常比例)";
        return getCalculatedResult(orderCalcDto, planDto, "供价", offer, new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 差异化计算公式3
     * "提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XZM比例
     * 新增点位=（计提现价-供价）÷计提现价×百分之100"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn3(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算3";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //计提现价
        Assert.notNull(planDto.getCurrentPrice(), log_pre + log_type + "-计提现价金额: null");
        if (planDto.getCurrentPrice() == 0) {
            log.info(log_type + "-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        //供价
        Assert.notNull(planDto.getOfferPrice(), log_pre + log_type + "-共价金额: null");
        if (planDto.getOfferPrice() == 0) {
            log.info(log_type + "-供价为零, return 0.0, " + log_pre);
            return ret;
        }
        //计提现价 供价
        BigDecimal current = BigDecimal.valueOf(planDto.getCurrentPrice());
        BigDecimal offer = BigDecimal.valueOf(planDto.getOfferPrice());
        //新增点位=（计提现价-供价）÷计提现价×百分之100"
        BigDecimal new_point_rate = current.subtract(offer).multiply(percent_rate_cent_1).divide(current, 5, RoundingMode.DOWN);
        logs = String.format("%s-新增点位[ %s ]=(计提现价[ %s ]-供价[ %s ])÷计提现价[ %s ]×百分之100, target: %s"
                , log_type, new_point_rate, current, offer, current, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=（计提现价-供价）÷计提现价×百分之100";
        return getCalculatedResult(orderCalcDto, planDto, "计提现价", BigDecimal.valueOf(planDto.getCurrentPrice()), new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 差异化计算公式4
     * "提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XZM比例
     * 新增点位=新增月返+（台返金额÷计提现价×百分之100）+【（计提现价-供价）÷计提现价×百分之100】-调整项"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn4(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算4";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //台返金额，新增月返，校验是否有值
        checkAddRebate(orderCalcDto, planDto, log_pre, log_type);
        //台返金额
        BigDecimal stage_price = BigDecimal.valueOf(planDto.getAddEachRebate());
        //新增月返
        BigDecimal new_month_refune = planDto.getAddMonthlyRebate();
        //调整项
        String comprehensiveContribution = planDto.getComprehensiveContribution();
        Assert.notNull(comprehensiveContribution, log_pre + log_type + "-调整项: null");
        // 调整项 数据
        BigDecimal comprehensiveContribution_big = null;
        if (StringUtils.isEmpty(comprehensiveContribution)) {
            // 线下四级品类获取十大品类编码信息
            DivisionDto divisionByFourthCode = queryPlanService.getDivisionByFourthCode(orderCalcDto.getEaGroupCode());
            comprehensiveContribution_big = calcCategreyProfitRate.resetCateOptions(orderCalcDto.getEaGroupCode(), divisionByFourthCode);
        } else {
            // 百分比 -> 小数点
            comprehensiveContribution_big = new BigDecimal(comprehensiveContribution).multiply(percent_rate_normal);
        }
        //计提现价
        Assert.notNull(planDto.getCurrentPrice(), log_pre + log_type + "-计提现价金额: null");
        if (planDto.getCurrentPrice() == 0) {
            log.info(log_type + "-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        //供价
        Assert.notNull(planDto.getOfferPrice(), log_pre + log_type + "-共价金额: null");
        if (planDto.getOfferPrice() == 0) {
            log.info(log_type + "-供价为零, return 0.0, " + log_pre);
            return ret;
        }
        //计提现价 供价
        BigDecimal current = BigDecimal.valueOf(planDto.getCurrentPrice());
        BigDecimal offer = BigDecimal.valueOf(planDto.getOfferPrice());
        //新增点位=新增月返+（台返金额÷计提现价×百分之100）+【（计提现价-供价）÷计提现价×百分之100】-调整项
        //新增月返
        BigDecimal refune1 = new_month_refune.multiply(percent_rate_normal);
        //（台返金额÷计提现价×百分之100）
        BigDecimal refune2 = stage_price.multiply(percent_rate_cent_1).divide(current, 5, RoundingMode.DOWN);
        //【（计提现价-供价）÷计提现价×百分之100】
        BigDecimal refune3 = current.subtract(offer).multiply(percent_rate_cent_1).divide(current, 5, RoundingMode.DOWN);
        //新增点位
        BigDecimal new_point_rate = refune1.add(refune2).add(refune3).subtract(comprehensiveContribution_big);
        logs = String.format("%s-新增点位[ %s ]=新增月返[ %s x 0.01 ]+（台返金额[ %s ]÷计提现价[ %s ]×百分之100）+【（计提现价[ %s ]-供价[ %s ]）÷计提现价[ %s ]×百分之100】-调整项[ %s ], target: %s"
                , log_type, new_point_rate, new_month_refune, stage_price, current, current, offer, current, comprehensiveContribution_big, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=新增月返+（台返金额÷计提现价×百分之100）+【（计提现价-供价）÷计提现价×百分之100】-调整项";
        return getCalculatedResult(orderCalcDto, planDto, "计提现价", BigDecimal.valueOf(planDto.getCurrentPrice()), new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }


    /**
     * 差异化计算公式5
     * "提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XZM比例
     * 新增点位=现综合利润率-原综合利润率"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn5(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算5";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //现综合利润率
        BigDecimal nowRateProfit = planDto.getNowRateProfit();
        //原综合利润率
        BigDecimal oldRateProfit = planDto.getOldRateProfit();
        //综合利润率，校验是否为负数，并加入问题小工具
        checkMinusRateProfit(orderCalcDto, planDto, nowRateProfit, oldRateProfit, log_pre, log_type);
        if (planDto.getCurrentPrice() == 0) {
            //计提现价0 不计算
            log.info(log_type + "-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        //新增点位=现综合利润率-原综合利润率
        BigDecimal new_point_rate = nowRateProfit.subtract(oldRateProfit).multiply(percent_rate_normal);
        logs = String.format("%s-新增点位[ %s ]=现综合利润率[ %s x 0.01 ]-原综合利润率[ %s x 0.01 ], target: %s"
                , log_type, new_point_rate, nowRateProfit, oldRateProfit, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=现综合利润率-原综合利润率";
        return getCalculatedResult(orderCalcDto, planDto, "计提现价", BigDecimal.valueOf(planDto.getCurrentPrice()), new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 差异化计算公司6
     * "提奖金额=（供价×新增点位×促消费提奖比例×发放比例+供价×新增点位×追加比例）×销售数量×XZM比例
     * 新增点位=现综合利润率-原综合利润率"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn6(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算6";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //现综合利润率
        BigDecimal nowRateProfit = planDto.getNowRateProfit();
        //原综合利润率
        BigDecimal oldRateProfit = planDto.getOldRateProfit();
        //综合利润率，校验是否为负数，并加入问题小工具
        checkMinusRateProfit(orderCalcDto, planDto, nowRateProfit, oldRateProfit, log_pre, log_type);
        //供价
        Assert.notNull(planDto.getOfferPrice(), log_pre + log_type + "-共价金额: null");
        if (planDto.getOfferPrice() == 0) {
            log.info(log_type + "-供价为零, return 0.0, " + log_pre);
            return ret;
        }
        //新增点位=现综合利润率-原综合利润率
        BigDecimal new_point_rate = nowRateProfit.subtract(oldRateProfit).multiply(percent_rate_normal);
        logs = String.format("%s-新增点位[ %s ]=现综合利润率[ %s x 0.01 ]-原综合利润率[ %s x 0.01 ], target: %s"
                , log_type, new_point_rate, nowRateProfit, oldRateProfit, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（供价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=现综合利润率-原综合利润率";
        return getCalculatedResult(orderCalcDto, planDto, "供价", BigDecimal.valueOf(planDto.getOfferPrice()), new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 差异化计算公式7
     * "现综合利润率=（计提限价-供价）/计提限价*百分之100；这个现综合利润率和有现综合利润率的计算公式是不一样的；
     * 新增点位=现综合利润率-原综合利润率
     * 提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XZM比例"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn7(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算7";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        Assert.notNull(planDto.getOldRateProfit(), log_pre + log_type + "-原综合利润率: null");
        //原综合利润率
        BigDecimal oldRateProfit = planDto.getOldRateProfit();
        //计提现价
        Assert.notNull(planDto.getCurrentPrice(), log_pre + log_type + "-计提现价金额: null");
        if (planDto.getCurrentPrice() == 0) {
            log.info(log_type + "-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        //供价
        Assert.notNull(planDto.getOfferPrice(), log_pre + log_type + "-共价金额: null");
        if (planDto.getOfferPrice() == 0) {
            log.info(log_type + "-供价为零, return 0.0, " + log_pre);
            return ret;
        }
        //计提现价 供价
        BigDecimal current = BigDecimal.valueOf(planDto.getCurrentPrice());
        BigDecimal offer = BigDecimal.valueOf(planDto.getOfferPrice());
        //现综合利润率=（计提现价-供价）÷计提现价×百分之100"
        BigDecimal nowRateProfit = current.subtract(offer).multiply(percent_rate_cent_1).divide(current, 5, RoundingMode.DOWN);
        logs = String.format("%s-现综合利润率[ %s ]=(计提现价[ %s ]-供价[ %s ])÷计提现价[ %s ]×百分之100, target: %s"
                , log_type, nowRateProfit, current, offer, current, log_pre);
        log.info(logs);
        //综合利润率，校验是否为负数，并加入问题小工具
        checkMinusRateProfit(orderCalcDto, planDto, nowRateProfit, oldRateProfit, log_pre, log_type);
        //新增点位=现综合利润率-原综合利润率
        BigDecimal new_point_rate = nowRateProfit.subtract(oldRateProfit.multiply(percent_rate_normal));
        logs = String.format("%s-新增点位[ %s ]=现综合利润率[ %s ]-原综合利润率[ %s x 0.01 ], target: %s"
                , log_type, new_point_rate, nowRateProfit, oldRateProfit, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=现综合利润率-原综合利润率";
        return getCalculatedResult(orderCalcDto, planDto, "计提现价", BigDecimal.valueOf(planDto.getCurrentPrice()), new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 差异化计算公式8
     * "提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XZM比例
     * 新增点位=现综合利润率-原综合利润率"
     *
     * @param orderCalcDto
     * @param planDto
     * @param scene
     * @param log_pre
     * @return
     */
    public BigDecimal formulaCYH_v2_fn8(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String log_type = "差异化公式计算8";
        String logs = "";
        //展示计算入参
        showFormulaCYHLog(orderCalcDto, planDto, log_pre, log_type);
        Assert.notNull(planDto.getAdditionalAward(), log_pre + log_type + "-追加金额: null");
        Assert.notNull(planDto.getIssueRate(), log_pre + log_type + "-发放比例: null");
        //现综合利润率
        BigDecimal nowRateProfit = planDto.getNowRateProfit();
        //原综合利润率
        BigDecimal oldRateProfit = planDto.getOldRateProfit();
        //综合利润率，校验是否为负数，并加入问题小工具
        checkMinusRateProfit(orderCalcDto, planDto, nowRateProfit, oldRateProfit, log_pre, log_type);
        if (planDto.getCurrentPrice() == 0) {
            //计提现价0 不计算
            log.info(log_type + "-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        //新增点位=现综合利润率-原综合利润率
        BigDecimal new_point_rate = nowRateProfit.subtract(oldRateProfit).multiply(percent_rate_normal);
        logs = String.format("%s-新增点位[ %s ]=现综合利润率[ %s x 0.01 ]-原综合利润率[ %s x 0.01 ], target: %s"
                , log_type, new_point_rate, nowRateProfit, oldRateProfit, log_pre);
        log.info(logs);
        //计算
        String log_calcFormulaStr = log_type + "-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
                "新增点位=现综合利润率-原综合利润率";
        return getCalculatedResult(orderCalcDto, planDto, "计提现价", BigDecimal.valueOf(planDto.getCurrentPrice()), new_point_rate
                , scene, log_pre, log_type, log_calcFormulaStr);
    }

    /**
     * 十大品类数据
     *
     * @param new_point_rate
     * @param orderCalcDto
     * @param planDto
     * @return
     */
    private BigDecimal getCatePointRate(BigDecimal new_point_rate, OrderCalcDto orderCalcDto, PlanDto planDto) {
        //十大品类编码
        String order_logs = String.format("orderId: %s, planId: %s ", orderCalcDto.getOrderId(), planDto.getPlanId());
        String eaGroupCode = orderCalcDto.getEaGroupCode();
        DivisionDto divisionByFourthCode = queryPlanService.getDivisionByFourthCode(eaGroupCode);
        if (divisionByFourthCode == null) {
            log.info(String.format("差异化-[DUBBO]订单线下品类十大品类编码:null, desc: %s, category: %s", order_logs, eaGroupCode));
            return null;
        }
        CategroyPointRateDto categroyPointRateDto = calcCategreyProfitRate.categoryPointRate(new_point_rate, divisionByFourthCode, eaGroupCode);
        BigDecimal rate = categroyPointRateDto.getRate();
        log.info(String.format("差异化-匹配-十大品类提成比例: desc: %s, %s", order_logs, categroyPointRateDto.getDesc()));
        if (rate == null) {
            //加入问题小工具
            addProblem(orderCalcDto, planDto, categroyPointRateDto.getDesc(), ProblemEnum.CODE_116);
        }
        return rate;
    }

    /**
     * xzm场景 提成比例
     *
     * @param planDto
     * @param scene
     * @return
     */
    private BigDecimal getSceneValue(PlanDto planDto, String scene) {
        BigDecimal value = null;
        if (BaseConstants.SCENE_X.equals(scene)) {
            value = planDto.getXValue();
        } else if (BaseConstants.SCENE_M.equals(scene)) {
            value = planDto.getMValue();
        } else if (BaseConstants.SCENE_Z.equals(scene)) {
            value = planDto.getZValue();
        }
        if (value == null) {
            String format = String.format("planId: %s, 场景: %s, 计划ScenValue提成比例 None", planDto.getPlanId(), scene);
            log.info(format);
            value = BigDecimal.valueOf(0.0);
        }
        return value;
    }

//    /**
//     * 预处理添加计算结果履历
//     *
//     * @param calcResultReward
//     */
//    private void savePreRewards(CalcResultReward calcResultReward) {
//        Double reward = Double.valueOf(calcResultReward.getReward());
//        if (BigDecimal.valueOf(reward).compareTo(BigDecimal.valueOf(0)) > 0) {
//            //大于零的情况下, 加入与计算
//            calcRewardsService.preAdd(calcResultReward);
//        }
//    }

    /**
     * copy properties by source calcResult and inside log journal
     * 异步 推送问题小工具
     *
     * @param orderCalcDto
     * @param problemMSG
     * @param planDto
     * @param problemEnum
     * @return
     */
    @Async
    public void addProblem(OrderCalcDto orderCalcDto, PlanDto planDto, String problemMSG, ProblemEnum problemEnum) {
        String str = "添加问题小工具, 数据参数orderId:%s, planId:%d, 问题内容: %s, 类型:%s";
        log.info(String.format(str, orderCalcDto.getOrderId(), planDto.getPlanId(), problemMSG, problemEnum.getMsg()));
        ProblemDto pd = new ProblemDto(orderCalcDto.getOrderId(), orderCalcDto.getChannel(), orderCalcDto.getSkuNo(),
                orderCalcDto.getDetailId());
        pd.setDescription(problemMSG);
        pd.setPlanId(planDto.getPlanId() + "");
        problemService.addData(pd, problemEnum);
    }


    /**
     * 计算提奖金额
     * 提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XZM比例
     *
     * @param orderCalcDto
     * @param planDto
     * @param price
     * @param new_point_rate
     * @param scene
     * @param log_pre
     * @return
     */
    private BigDecimal getCalculatedResult(OrderCalcDto orderCalcDto, PlanDto planDto, String priceName, BigDecimal price, BigDecimal new_point_rate
            , String scene, String log_pre, String log_type, String log_calcFormulaStr) {
        BigDecimal ret = BigDecimal.valueOf(0.0);
        //新增点位为负数
        if (new_point_rate.compareTo(new BigDecimal("0")) < 0) {
            String log_msg = log_type + "-新增点位为负数";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, log_msg, ProblemEnum.CODE_116);
            return ret;
        }
        // 追加比例
        BigDecimal addition_price = planDto.getAdditionalAward();
        String logs = "";
        //xzm 比例
        BigDecimal sceneValue = getSceneValue(planDto, scene);
        //计算提成奖励金额比例
        BigDecimal profit_rate = this.getCatePointRate(new_point_rate, orderCalcDto, planDto);
        if (profit_rate == null) {
            // "-促消费提奖比例为null";
            return ret; // 直接返回零
        }
        //"提奖金额=（供价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例
        BigDecimal pre1 = price.multiply(percent_rate_normal)
                .multiply(new_point_rate)
                .multiply(profit_rate)
                .multiply(planDto.getIssueRate().multiply(percent_rate_normal));
        BigDecimal pre2 = price.multiply(percent_rate_normal)
                .multiply(new_point_rate)
                .multiply(addition_price.multiply(percent_rate_normal));
        ret = pre1.add(pre2).multiply(BigDecimal.valueOf(orderCalcDto.getBuyNum())).multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
        logs = String.format("%s-提奖金额[ %s ]=（%s[ %s x 0.01 ]×新增点位[ %s ]×促消费提奖比例[ %s ]×发放比例[ %s x 0.01 ]+%s[ %s x 0.01 ]×新增点位[ %s ]×追加比例[ %s x 0.01]）×销售数量[ %s ]×场景[ %s ]比例[ %s x 0.01 ], target: %s"
                , log_type, ret, priceName, price, new_point_rate, profit_rate, planDto.getIssueRate(), priceName, price, new_point_rate, addition_price, orderCalcDto.getBuyNum(), scene, sceneValue, log_pre);
        log.info(logs);
        ret = ret.multiply(percent_rate_cent).setScale(2, RoundingMode.DOWN);   //转换成分, 保留两位小数
//        //--------------------------------save reward----------------------------------
//        CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//        crr.setProfitRate(profit_rate.toString());
//        crr.setReward(ret.toString());
//        crr.setCalcFormulaLog(logs);
//        crr.setCalcFormulaStr(log_calcFormulaStr);
//        savePreRewards(crr);
//        //--------------------------------save reward----------------------------------
        return ret;
    }

    /**
     * 综合利润率，校验是否为负数
     *
     * @param orderCalcDto
     * @param planDto
     * @param nowRateProfit
     * @param oldRateProfit
     * @param log_pre
     * @param log_type
     */
    public void checkMinusRateProfit(OrderCalcDto orderCalcDto, PlanDto planDto, BigDecimal nowRateProfit,
                                     BigDecimal oldRateProfit, String log_pre, String log_type) {
        //现综合利润率
        if (null == nowRateProfit) {
            String lts_now_nil = log_type + "-现综合利润率为null";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, lts_now_nil, ProblemEnum.CODE_116);
            throw new IllegalArgumentException(log_pre + lts_now_nil);
        }

        if (nowRateProfit.compareTo(new BigDecimal("0")) < 0) {
            String lts_now_neg = log_type + "-现综合利润率为负数";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, lts_now_neg, ProblemEnum.CODE_116);
            throw new IllegalArgumentException(log_pre + lts_now_neg);
        }
        //原综合利润率
        if (null == oldRateProfit) {
            String lts_old_nil = log_type + "-原综合利润率为null";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, lts_old_nil, ProblemEnum.CODE_116);
            throw new IllegalArgumentException(log_pre + lts_old_nil);
        }
        if (oldRateProfit.compareTo(new BigDecimal("0")) < 0) {
            String lts_old_neg = log_type + "-原综合利润率为负数";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, lts_old_neg, ProblemEnum.CODE_116);
            throw new IllegalArgumentException(log_pre + lts_old_neg);
        }
    }

    /**
     * 台返金额，新增月返，校验是否有值
     *
     * @param orderCalcDto
     * @param planDto
     * @param log_pre
     * @param log_type
     */
    public void checkAddRebate(OrderCalcDto orderCalcDto, PlanDto planDto, String log_pre, String log_type) {
        //台返金额
        if (planDto.getAddEachRebate() == null) {
            String log_msg = log_type + "台返金额为null";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, log_msg, ProblemEnum.CODE_128);
            throw new IllegalArgumentException(log_pre + log_msg);
        }
        //新增月返
        if (planDto.getAddMonthlyRebate() == null) {
            String log_msg = log_type + "新增月返为null";
            //加入问题小工具
            addProblem(orderCalcDto, planDto, log_msg, ProblemEnum.CODE_128);
            throw new IllegalArgumentException(log_pre + log_msg);
        }
    }

    /**
     * 展示计算入参
     *
     * @param orderCalcDto
     * @param planDto
     * @param log_pre
     * @param log_type
     */
    public void showFormulaCYHLog(OrderCalcDto orderCalcDto, PlanDto planDto, String log_pre, String log_type) {
        //承担类型: 厂家承担, 国美承担
        Integer expenseOfferType = planDto.getExpenseOfferType();
        //业务机型
        String salesModel = orderCalcDto.getSalesModel();
        //合同类型
        String contractClass = planDto.getContractClass();
        //计提现价
        Long current = planDto.getCurrentPrice();
        //供价
        Long offer = planDto.getOfferPrice();
        //追加金额
        BigDecimal additionalAward = planDto.getAdditionalAward();
        //发放比例
        BigDecimal issueRate = planDto.getIssueRate();
        //台返金额
        Long addEachRebate = planDto.getAddEachRebate();
        //新增月返
        BigDecimal addMonthlyRebate = planDto.getAddMonthlyRebate();
        //调整项
        String comprehensiveContribution = planDto.getComprehensiveContribution();
        //现综合利润率
        BigDecimal nowRateProfit = planDto.getNowRateProfit();
        //原综合利润率
        BigDecimal oldRateProfit = planDto.getOldRateProfit();
        log.info(String.format("%s-%s: 承担类型-%s, 业务机型-%s, 合同类型-%s, 计提现价-%s, 供价-%s, 追加金额-%s, 发放比例-%s, 台返金额-%s, 新增月返-%s, 调整项-%s, 现综合利润率-%s, 原综合利润率-%s",
                log_type, log_pre, expenseOfferType, salesModel, contractClass, current, offer, additionalAward
                , issueRate, addEachRebate, addMonthlyRebate, comprehensiveContribution, nowRateProfit, oldRateProfit));
    }


    //-------------------------------
    // 差异化计算公式1 (已过期)
    //------------------------------
    @Deprecated
    private BigDecimal formulaCYH_fn1(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre){
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String logs = "";
        // 台返金额
        Long addEachRebate = planDto.getAddEachRebate();
        Assert.notNull(addEachRebate, log_pre + "差异化计算-台返金额: null");
        BigDecimal stage_price = BigDecimal.valueOf(addEachRebate);
        // 新增月返
        BigDecimal addMonthlyRebate = planDto.getAddMonthlyRebate();
        Assert.notNull(addMonthlyRebate, log_pre + "差异化计算-新增月返: null");
        BigDecimal new_month_refune = addMonthlyRebate;
        // 追加金额
        BigDecimal addition_price = planDto.getAdditionalAward();
        Assert.notNull(addition_price, log_pre + "差异化计算-追加金额: null");
        // 发放比例
        BigDecimal issueRate = planDto.getIssueRate();
        // xzm 比例
        BigDecimal sceneValue = getSceneValue(planDto, scene);
        // buy_mun
        Integer buyNum = orderCalcDto.getBuyNum();
        // 促销费提奖比例
        BigDecimal profit_rate = null;
        // 十大品类编码
        Assert.notNull(issueRate, log_pre + "差异化计算-发放比例: null");

        //"提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例
        //新增点位=新增月返+新增台返
        //新增台返=台返金额÷计提现价×百分之100"

        Long jtCurrentPrice = sceneUtils.getJTCurrentPrice(planDto);
        if(jtCurrentPrice == 0){
            // 计提现价0 不计算
            log.info("差异化-流水倒扣合同-计提现价为零, return 0.0, " + log_pre);
            return ret;
        }
        // 以计算为正常数据 计提现价
        BigDecimal jtcurrent = BigDecimal.valueOf(jtCurrentPrice).multiply(percent_rate_normal);
        BigDecimal new_stage_refune = stage_price.multiply(percent_rate_normal)
                .divide(jtcurrent)
                .multiply(BigDecimal.valueOf(1));
        logs = String.format("差异化-流水倒扣合同-新增台返[ %s ]=台返金额[ %s x 0.01 ]÷计提现价[ %s x 0.01 ]×百分之100, target: %s"
                , new_stage_refune, stage_price, jtCurrentPrice, log_pre);
        log.info(logs);
        BigDecimal new_point_rate = new_month_refune.multiply(percent_rate_normal).add(new_stage_refune);
        logs = String.format("差异化-流水倒扣合同-新增点位[ %s ]=新增月返[ %s x 0.01 ]+新增台返[ %s ], target: %s"
                , new_point_rate, new_month_refune, new_month_refune, log_pre);
        log.info(logs);
        // 计算提成奖励金额比例
        profit_rate = this. getCatePointRate(new_point_rate, orderCalcDto, planDto);
        if(profit_rate == null){
            return ret;
        }
        //"提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例
        BigDecimal pre1 = jtcurrent.multiply(new_point_rate)
                .multiply(profit_rate)
                .multiply(issueRate.multiply(percent_rate_normal));
        BigDecimal pre2 = jtcurrent.multiply(new_point_rate)
                .multiply(addition_price.multiply(percent_rate_normal));
        ret = pre1.add(pre2).multiply(BigDecimal.valueOf(buyNum)).multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
        logs = String.format("差异化-流水倒扣合同-提奖金额[ %s ]=（计提现价[ %s ]×新增点位[ %s ]×促消费提奖比例[ %s ]×发放比例[ %s x 0.01 ]+计提现价[ %s ]×新增点位[ %s ]×追加比例[ %s x 0.01 ]）×销售数量[ %s ]×场景[ %s ]比例[ %s ], target: %s"
                , ret, jtCurrentPrice, new_point_rate, profit_rate, issueRate, jtCurrentPrice,new_point_rate, addition_price, buyNum, scene, sceneValue, log_pre);
        log.info(logs);
        ret = ret.multiply(percent_rate_cent).setScale(2, RoundingMode.DOWN);   // 转换成分, 保留两位小数
//        // --------------------------------save reward----------------------------------
//        CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//        crr.setProfitRate(profit_rate.toString());
//        crr.setReward(ret.toString());
//        crr.setCalcFormulaLog(logs);
//        crr.setCalcFormulaStr("差异化-流水倒扣-提奖金额=（计提现价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
//                "新增点位=新增月返+新增台返; " +
//                "新增台返=台返金额÷计提现价×百分之100");
//        savePreRewards(crr);
//        // --------------------------------save reward----------------------------------
        return ret;

    }


    // --------------------------------
    // 差异化计算公司2 (已过期)
    //---------------------------------
    @Deprecated
    private BigDecimal formulaCYH_fn2(OrderCalcDto orderCalcDto, PlanDto planDto, String scene, String log_pre){
        BigDecimal ret = BigDecimal.valueOf(0.0);
        String logs = "";
        // 台返金额
        Assert.notNull(planDto.getAddEachRebate(), log_pre + "差异化2计算-台返金额: null");
        BigDecimal stage_price = BigDecimal.valueOf(planDto.getAddEachRebate());
        // 新增月返
        Assert.notNull(planDto.getAddMonthlyRebate(), log_pre + "差异化2计算-新增月返: null");
        BigDecimal new_month_refune = planDto.getAddMonthlyRebate();
        // 追加金额
        Assert.notNull(planDto.getAdditionalAward(), log_pre + "差异化2计算-追加金额: null");
        BigDecimal addition_price = planDto.getAdditionalAward();
        // 发放比例
        BigDecimal issueRate = planDto.getIssueRate();
        // xzm 比例
        BigDecimal sceneValue = getSceneValue(planDto, scene);
        // buy_mun
        Integer buyNum = orderCalcDto.getBuyNum();
        // 共价
        Long offerPrice = planDto.getOfferPrice();
        Assert.notNull(offerPrice, log_pre + "差异化2计算-共价金额: null");
        BigDecimal gj = BigDecimal.valueOf(offerPrice);
        if(gj.compareTo(BigDecimal.valueOf(0))==0){
            // 供价0不计算
            log.info("差异化-流水倒扣合同-供价为零, return 0.0, " + log_pre);
            return ret;
        }

        // 计提现价
        // Long jtCurrentPrice = getJTCurrentPrice(planDto);
        // 促销费提奖比例 **
        BigDecimal profit_rate = null;
        // 新增台返=台返金额÷供价×百分之100(以计算正常比例)
        BigDecimal new_stage_refune = stage_price.multiply(percent_rate_normal)
                .divide(gj.multiply(percent_rate_normal))
                .multiply(BigDecimal.valueOf(1));
        logs = String.format("差异化-非流水倒扣合同-新增台返[ %s ]=台返金额[ %s x 0.01 ]÷共价[ %s x 0.01 ]×百分之100, target: %s"
                , new_stage_refune, stage_price, gj, log_pre);
        log.info(logs);
        // 新增点位=新增月返+新增台返 (已经计算正常比例)
        BigDecimal new_point_rate = new_month_refune.multiply(percent_rate_normal).add(new_stage_refune);
        logs = String.format("差异化-非流水倒扣新增点位[ %s ]合同-=新增月返[ %s x 0.01 ]+新增台返[ %s ], target: %s"
                , new_point_rate, new_month_refune, new_month_refune, log_pre);
        log.info(logs);
        // 计算提成奖励金额比例
        profit_rate = this.getCatePointRate(new_point_rate, orderCalcDto, planDto);
        if(profit_rate == null){
            return ret;
        }
        //"提奖金额=（供价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例
        BigDecimal pre1 = gj.multiply(percent_rate_normal)
                .multiply(new_point_rate)
                .multiply(profit_rate)
                .multiply(issueRate.multiply(percent_rate_normal));
        BigDecimal pre2 = gj.multiply(percent_rate_normal)
                .multiply(new_point_rate)
                .multiply(addition_price.multiply(percent_rate_normal));
        ret = pre1.add(pre2).multiply(BigDecimal.valueOf(buyNum)).multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
        logs = String.format("差异化-非流水倒扣合同-提奖金额[ %s ]=（供价[ %s x 0.01 ]×新增点位[ %s ]×促消费提奖比例[ %s ]×发放比例[ %s x 0.01 ]+供价[ %s x 0.01 ]×新增点位[ %s ]×追加比例[ %s x 0.01]）×销售数量[ %s ]×场景[ %s ]比例[ %s x 0.01 ], target: %s"
                , ret, gj, new_point_rate, profit_rate, issueRate, gj, new_point_rate, addition_price, buyNum, scene, sceneValue, log_pre);
        log.info(logs);
        ret = ret.multiply(percent_rate_cent).setScale(2, RoundingMode.DOWN);   // 转换成分, 保留两位小数
//        // --------------------------------save reward----------------------------------
//        CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//        crr.setReward(ret.toString());
//        crr.setCalcFormulaLog(logs);
//        crr.setCalcFormulaStr("差异化非流水倒扣-提奖金额=（供价×新增点位×促消费提奖比例×发放比例+计提现价×新增点位×追加比例）×销售数量×XYZM比例; " +
//                "新增点位=新增月返+新增台返 (已经计算正常比例); " +
//                "新增台返=台返金额÷供价×百分之100(以计算正常比例)");
//        savePreRewards(crr);
//        // --------------------------------save reward----------------------------------

        return ret;
    }

}
