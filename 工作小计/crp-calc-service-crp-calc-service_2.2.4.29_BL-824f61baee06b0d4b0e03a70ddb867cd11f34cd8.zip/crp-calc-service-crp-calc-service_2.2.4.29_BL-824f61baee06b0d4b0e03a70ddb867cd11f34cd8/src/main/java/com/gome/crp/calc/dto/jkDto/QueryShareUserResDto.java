package com.gome.crp.calc.dto.jkDto;

import lombok.Data;

@Data
public class QueryShareUserResDto {
    private String staffCode; //员工编码
    private String isSham; //是否虚假 1-虚假 0-真实
}
