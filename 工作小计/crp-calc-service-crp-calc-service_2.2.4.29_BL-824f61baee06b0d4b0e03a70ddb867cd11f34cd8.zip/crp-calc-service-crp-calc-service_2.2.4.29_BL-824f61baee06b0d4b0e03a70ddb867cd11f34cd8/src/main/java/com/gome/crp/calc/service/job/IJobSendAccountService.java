package com.gome.crp.calc.service.job;
/**
 * 推送收入服务job
 * @author GOME
 *
 */
public interface IJobSendAccountService {

	void sentIncome();
}
