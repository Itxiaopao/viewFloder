package com.gome.crp.calc.constants;

public enum OrderTypeEnum {
	NORMAL_ORDER("0", "正常单"),
    PRESALE_ORDER("1", "预售单"),
    CASH_ON_DELIVERY("2", "货到付款"),
    FULL_DEPOSIT_DELIVERY("3", "全额定金发货"),

    ;

    private String code;
    private String msg;

    OrderTypeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
