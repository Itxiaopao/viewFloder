package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

@Setter
@Getter
@ToString
public class CalcResultReward implements Serializable {

    private Long id;
    private String orderId;
    private String detailId;
    private String channel;     // 渠道
    private String gomeStatus;   // 订单状态
    private String planId; // 计划id
    private String scene;   // 场景
    private Integer promotionsType; // 计划提奖类型
    private String policyCode;  // 政策编码
    private String buyNum;
    private String issueRate;
    private String sceneValue;
    private String policyValue;
    private String singleStandard;
    private String jtBases; // 计提基数
    private Integer jtBasesType;
    private String currentPrice;  // 计提现价
    private String salesModel;
    private String contractClass;
    private String addEachRebate;
    private String addMonthlyRebate;
    private String additionalAward;
    private String profitRate;  // 促销费提奖比例
    private String offerPrice;
    private String reward;  // 提奖金额 :正向单"+", 逆向单"-"
    private String singleStandardMoney;
    private String userId;
    private String staffCode;
    private String calcFormulaStr;  // 计算公式
    private String calcFormulaLog;  // 计算公式log


    private Integer isDelete;
    private Date createTime;








}
