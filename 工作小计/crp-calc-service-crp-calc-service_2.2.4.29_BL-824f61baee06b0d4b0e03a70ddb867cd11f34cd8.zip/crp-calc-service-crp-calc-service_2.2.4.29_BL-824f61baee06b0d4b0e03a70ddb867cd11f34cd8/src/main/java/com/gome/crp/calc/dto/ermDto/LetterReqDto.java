package com.gome.crp.calc.dto.ermDto;

import lombok.Data;

@Data
public class LetterReqDto {
    private String contractCode;
    private String extraPurchaseCode;
    private String orderSupplierCode;
    private String docty;
    private String skuNo;
    private String salesModel;
}
