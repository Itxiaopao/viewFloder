package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.mybatis.service.ISapRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class DubboSapFacadeManager {
    @Autowired
    private ISapRecordService iSapRecordService;
    @Autowired
    private ICalcResultService iCalcResultService;

    @Transactional
    public void updateConfirmReceiptSapRecord(List<SapRecord> updateSapRecordList, List<CalcResult> updateCalcResultList) {
        iSapRecordService.updateBatchById(updateSapRecordList);

        if (!CollectionUtils.isEmpty(updateCalcResultList)) {
            iCalcResultService.updateBatchById(updateCalcResultList);
        }
    }
}
