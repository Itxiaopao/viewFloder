package com.gome.crp.calc.dubbo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.employee.IProfitStaffService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.employee.req.StaffReqsDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.facade.dto.ResultDTO;
import com.gome.crp.calc.facade.dto.orderCalc.CouponsDto;
import com.gome.crp.calc.facade.dto.orderCalc.DetailGoodsDto;
import com.gome.crp.calc.facade.dto.orderCalc.OrderDto;
import com.gome.crp.calc.facade.dto.orderCalc.res.DetailGoodsResDto;
import com.gome.crp.calc.facade.dto.orderCalc.res.ExtendDto;
import com.gome.crp.calc.facade.dto.orderCalc.res.OrderCalcResDto;
import com.gome.crp.calc.facade.dubbo.IDubboProfitStaffFacade;
import com.gome.crp.calc.facade.exception.ExceptionCodeEnum;
import com.gome.crp.calc.service.problem.IProblemService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service("dubboProfitStaffFacade")
public class DubboProfitStaffFacadeImpl implements IDubboProfitStaffFacade {
	@Autowired
	private IProfitStaffService profitStaffService;
	@Autowired
	private static String DEFAULT_STAFFCODE_A = "A0000000";
    @Autowired
    private IProblemService iProblemService;
	

	@Override
	public ResultDTO<OrderCalcResDto> getProfitStaff(OrderDto orderDto) {
		String order_param = JSONObject.toJSONString(orderDto);
		log.info(String.format("提供-员工身份信息识别接口: param:%s", order_param));
		String orderId = orderDto.getOrderId();
		if (null == orderDto || null == orderDto.getDetailGoodsVos() || null == orderId) {
			log.info(String.format("提供-员工身份信息识别接口[异常]: 必要信息没有传递 %s", order_param));
			iProblemService.addData(orderId, null, null,"必要信息没有传递 ",ProblemEnum.CODE_133,null);
			return ResultDTO.error(ExceptionCodeEnum.EMPTY_PARAM.getErrorCode(),
					ExceptionCodeEnum.EMPTY_PARAM.getErrorMessage());
		}
		List<DetailGoodsResDto> dgrdL = new ArrayList<>();
		try {
			log.info(String.format("提供-员工身份信息识别接口: 入参:%s", order_param));
			for (DetailGoodsDto dd : orderDto.getDetailGoodsVos()) {
				DetailGoodsResDto dgrd = this.judgeOrderDimension(orderDto, dd);
				dgrdL.add(dgrd);
			}
			OrderCalcResDto ret = new OrderCalcResDto();
			ret.setOrderId(orderId);
			if (dgrdL.size() > 0) {
				ret.setDetailGoodsDto(dgrdL);
			}else{
				iProblemService.addData(orderId, null, null,"员工身份信息识别接口没有查到获益人 ",ProblemEnum.CODE_134,null);
			}
			log.info(String.format("提供-员工身份信息识别接口, 结果集:%s", JSONObject.toJSONString(ret)));
			return ResultDTO.success(ret);
		} catch (Exception e) {
			log.error(String.format("提供-员工身份信息识别接口[异常], 入参:%s ", order_param), e);
			iProblemService.addData(orderId, null, null,"员工身份信息识别接口异常 ",ProblemEnum.CODE_135,null);
			return ResultDTO.error(ExceptionCodeEnum.EMPTY_PARAM.getErrorCode(),
					ExceptionCodeEnum.EMPTY_PARAM.getErrorMessage());
		}
	}

	/**
	 * 判断渠道
	 * @param order
	 * @param dd
	 * @return
	 */
	private DetailGoodsResDto judgeOrderDimension(OrderDto order, DetailGoodsDto dd) {
		DetailGoodsResDto ddreq = null;
		String storeSellerId = dd.getStoreSellerId();
		if(StringUtils.isNotBlank(storeSellerId)) {
			// 16来购 -> 直接
			ddreq = this.copyProperties(dd, storeSellerId);
		}else {
			String channelNo = dd.getChannelNo();		
			if(BaseConstants.ORDER_CHANNEL_ONLINE.equals(channelNo)) {
				// 60 渠道
				ddreq = this.copyProperties(dd, DEFAULT_STAFFCODE_A);
			} else if(BaseConstants.ORDER_CHANNEL_YDYY.equals(channelNo) || BaseConstants.ORDER_CHANNEL_MEIDIAN.equals(channelNo)) {
				// 16 渠道 13 渠道
				StaffReqsDto staffreq = getStaffReqsDto(order, dd);
				List<PersonDto> pl = profitStaffService.memberUserIdFindStaffIdentity(staffreq);
				ddreq = this.copyProperties(dd.getCommerceItemId(), pl);
			}
		}
		return ddreq;
	}
	
	
	/**
	 * 封装反参结果:DetailGoodsResDto
	 * 
	 * @param detailGoodsDto
	 * @param staffCode
	 * @return
	 */
	private DetailGoodsResDto copyProperties(DetailGoodsDto detailGoodsDto, String staffCode) {
		DetailGoodsResDto dgrd = new DetailGoodsResDto();
		dgrd.setCommerceItemId(detailGoodsDto.getCommerceItemId());
		List<String> employIds = Arrays.asList(staffCode);
		ExtendDto extendDto = new ExtendDto();
		extendDto.setEmployeeId(employIds);
		dgrd.setExtendDto(extendDto);
		return dgrd;
	}
	
	/**
	 * 封装反参: DetailGoodsResDto
	 * 
	 * @param commerceItemId
	 * @param profitPerson
	 * @return
	 */
	private DetailGoodsResDto copyProperties(String commerceItemId, List<PersonDto> profitPerson) {
		DetailGoodsResDto dgrd = new DetailGoodsResDto();
		dgrd.setCommerceItemId(commerceItemId);
		ExtendDto extendDto = new ExtendDto();
		List<String> employIds = new ArrayList<>();
		for (PersonDto personDto : profitPerson) {
			employIds.add(personDto.getStaffCode());
		}
		extendDto.setEmployeeId(employIds);
		dgrd.setExtendDto(extendDto);
		return dgrd;
	}
	
	/**
	 * StaffReqsDto 封装入参对象
	 * @param detailGoodsDto
	 * @return
	 */
	private StaffReqsDto getStaffReqsDto(OrderDto order, DetailGoodsDto detailGoodsDto) {
		StaffReqsDto sr = new StaffReqsDto();
		List<OrderCalcCouponDto> occl = new ArrayList<>();;
		List<CouponsDto> couponsDtos = detailGoodsDto.getCouponsDtos();
		if (couponsDtos != null && couponsDtos.size() > 0) {
			couponsDtos.forEach(x -> {
				OrderCalcCouponDto nocc = new OrderCalcCouponDto();
				BeanUtils.copyProperties(x, nocc);
				occl.add(nocc);
			});
		}
		sr.setCouponsDtoList(occl);
		sr.setEaBrandCode(detailGoodsDto.getEaBrandCode());
		String eaGroupCode = detailGoodsDto.getEaGroupCode();
		if (StringUtils.isNotBlank(eaGroupCode)) {
			sr.setEaCateSecond(eaGroupCode.substring(0, 3));
		}
		String commerceItemId = detailGoodsDto.getCommerceItemId();
		sr.setLogEmbedPort(String.format("[为OMS提供服务]-orderId:%s, 行项目号:%s ", order.getOrderId(), commerceItemId));
		sr.setProductShareUserId(detailGoodsDto.getShareUserId());
		sr.setShopNo(detailGoodsDto.getShopNo());
		sr.setStoreLevel(BaseConstants.STAFF_LEVEL_4 + "");
		sr.setSupplierCode(detailGoodsDto.getSupplier());
		sr.setOrderUserId(order.getUserId());
		sr.setChannelNo(detailGoodsDto.getChannelNo());	// 
		sr.setOrderId(order.getOrderId());
		sr.setCommerceItemId(commerceItemId);
		return sr;
	}
	
	/**
	 * 创建默认券
	 * 
	 * @return
	 */
	public OrderCalcCouponDto defualtCouponDto() {
		OrderCalcCouponDto c = new OrderCalcCouponDto();
		c.setCouponId("1111");
		c.setCouponType(3001L);
		return c;
	}
}
