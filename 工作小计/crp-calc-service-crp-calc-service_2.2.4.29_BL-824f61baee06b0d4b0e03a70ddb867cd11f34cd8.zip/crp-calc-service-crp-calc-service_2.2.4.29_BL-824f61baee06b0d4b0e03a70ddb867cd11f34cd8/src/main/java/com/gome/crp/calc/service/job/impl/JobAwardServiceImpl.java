package com.gome.crp.calc.service.job.impl;

import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.manager.CalcResultManager;
import com.gome.crp.calc.service.job.IJobAwardService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class JobAwardServiceImpl implements IJobAwardService {

    @Autowired
    private CalcResultManager calcResultDetailManager;
    @Autowired
    private IStaffInfoService iStaffInfoService;
    @Autowired
    private IProblemService iProblemService;

    @Override
    public void dealFreezeStatus() {
        List<CalcResult> calcResultDetails = selectTask();
        execute(calcResultDetails);
    }

    @Override
    public void dealPromoter(String dateStr) {
        List<CalcResult> calcResultDetails = selectTaskOfPromoterTask(dateStr);
        execute(calcResultDetails);
    }

    /**
     * 查询数量
     * 条件：扫描SAP严控的数据
     * 功能 1.SAP严控 --> 预算校验；2.SAP严控 --> 失效
     */
    private List<CalcResult> selectTask() {
        log.info("job执行到sap严控的数据,time:{}", new Date().toString());
        List<CalcResult> calcResultDetails = calcResultDetailManager.queryListOfFreeze();
        String timeShow = new Date().toString();
        if (null == calcResultDetails || calcResultDetails.size() == 0) {
            log.info("未查询到冻结状态数据，time:{}", timeShow);
        }
        ArrayList<CalcResult> updateList = new ArrayList<>();
        for (CalcResult thisCalcResultDetail : calcResultDetails) {
            if (BaseConstants.EMPL_CLASS_I.equals(thisCalcResultDetail.getStaffClass())
                    || BaseConstants.EMPL_CLASS_J.equals(thisCalcResultDetail.getStaffClass())) {
                //获利人为加盟店 状态改为失效
                thisCalcResultDetail.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
                thisCalcResultDetail.setFailureReason(BaseConstants.FAILURE_REASON_4_EMPLOY);
                updateList.add(thisCalcResultDetail);
                dealJobStatusFour(thisCalcResultDetail, "加盟店员工需要改为失效状态");
                continue;
            }
            if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(thisCalcResultDetail.getPromotionsType().toString())
                    && BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(thisCalcResultDetail.getExtraPolicyCode())
                    && BaseConstants.SCENE_X.equals(thisCalcResultDetail.getScenes())
                    && BaseConstants.PLAN_IS_A_SELL_A_Y == thisCalcResultDetail.getIsAsella()
                    && thisCalcResultDetail.getStaffSupplierCode().contains(thisCalcResultDetail.getOrderSupplierCode())) {
                //无促 并且政策编码为605 并且是X 并且是A买A的 并且 获利人供应商编码包含订单供应商编码
                thisCalcResultDetail.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
                thisCalcResultDetail.setFailureReason(BaseConstants.FAILURE_REASON_4_PROMOTION);
                updateList.add(thisCalcResultDetail);
                dealJobStatusFour(thisCalcResultDetail, "计划为无促并且政策编码为605并且Scene-X场景并且是A卖A的需要改为失效状态");
            } else {
                thisCalcResultDetail.setJobStatus(BaseConstants.CRD_JOB_STATUS_1);
                updateList.add(thisCalcResultDetail);
            }
        }
        return updateList;
    }

    /**
     * 查询数量
     * 条件：扫描SAP严控\195/197的数据
     * 功能 1.SAP严控 --> 预算校验；2.SAP严控 --> 失效
     */
    public List<CalcResult> selectTaskOfPromoterTask(String dateStr) {
        Date[] dates = dealTimeOfRequest(dateStr);
        List<CalcResult> calcResultDetails = calcResultDetailManager.queryListOfALL(dates[0],dates[1]);//只查195/197的
        log.info("每月跑一次校验195、197门店是否存在促销员考勤满15天的,time:{}", new Date().toString());
        ArrayList<CalcResult> updateList = new ArrayList<>();
        for (CalcResult thisCalcResultDetail : calcResultDetails) {
            //TODO 优化空间
            String time = dealTimeToString(thisCalcResultDetail.getOrderSubmitTime());
            if (iStaffInfoService.checkPromotion(thisCalcResultDetail, time)) {
                //有促
                thisCalcResultDetail.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
                thisCalcResultDetail.setFailureReason(BaseConstants.FAILURE_REASON_4_HAVE_SALLER);
                updateList.add(thisCalcResultDetail);
                dealJobStatusFour(thisCalcResultDetail, String.format("%s门店有促%s月,修改为无效状", thisCalcResultDetail.getShopNo(), time));
            } else {
                //无促
                thisCalcResultDetail.setJobStatus(BaseConstants.CRD_JOB_STATUS_1);
                updateList.add(thisCalcResultDetail);
            }
        }
        return updateList;
    }

    public boolean execute(List<CalcResult> updateList) {
        if (null == updateList || updateList.size() == 0) {
            log.info("job执行过滤出结果为空");
            return false;
        }
        Boolean aBoolean = calcResultDetailManager.updateByList(updateList);
        log.info("job 执行返回状态:{},时间:{}", aBoolean, new Date().toString());
        return aBoolean;
    }


    /**
     * 处理时间为字符串
     * 实例数据：202003
     *
     * @param time
     * @return
     */
    @Override
    public String dealTimeToString(Date time) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(time);
        instance.add(Calendar.MONTH, -1);
        String year = String.valueOf(instance.get(Calendar.YEAR));
        int i = instance.get(Calendar.MONTH) + 1;
        String month = i < 10 ? "0" + String.valueOf(i) : String.valueOf(i);
        return year + month;
    }

    /**
     * 处理定时任务传参时间
     *
     * @return
     */
    public Date[] dealTimeOfRequest(String dateStr) {
        Date[] dates = new Date[2];
        Calendar startInstance;
        Calendar endInstance;
        if (StringUtils.isBlank(dateStr)) {
            startInstance = Calendar.getInstance();
            startInstance.add(Calendar.MONTH, -1);
            endInstance = Calendar.getInstance();
        }else{
            Date date = DateUtils.parseDate(dateStr);
            startInstance = Calendar.getInstance();
            startInstance.setTime(date);
            endInstance = Calendar.getInstance();
            endInstance.setTime(date);
            endInstance.add(Calendar.MONTH, 1);
        }
        startInstance.set(Calendar.DAY_OF_MONTH, 1);
        startInstance.set(Calendar.HOUR_OF_DAY, 00);
        startInstance.set(Calendar.MINUTE, 00);
        startInstance.set(Calendar.SECOND, 00);
        startInstance.set(Calendar.MILLISECOND, 00);
        dates[0] = startInstance.getTime();
        endInstance.set(Calendar.DAY_OF_MONTH, 1);
        endInstance.set(Calendar.HOUR_OF_DAY, 00);
        endInstance.set(Calendar.MINUTE, 00);
        endInstance.set(Calendar.SECOND, 00);
        endInstance.set(Calendar.MILLISECOND, 00);
        dates[1] = endInstance.getTime();
        return dates;
    }


    /**
     * 入问题小工具
     *
     * @param calcResult
     * @param description
     */
    public void dealJobStatusFour(CalcResult calcResult, String description) {
        ProblemDto problem = new ProblemDto(calcResult.getOrderId(), calcResult.getChannel(), calcResult.getSkuNo(), calcResult.getDetailId());
        problem.setDescription(description);
        iProblemService.addData(problem, ProblemEnum.CODE_118);
    }
}
