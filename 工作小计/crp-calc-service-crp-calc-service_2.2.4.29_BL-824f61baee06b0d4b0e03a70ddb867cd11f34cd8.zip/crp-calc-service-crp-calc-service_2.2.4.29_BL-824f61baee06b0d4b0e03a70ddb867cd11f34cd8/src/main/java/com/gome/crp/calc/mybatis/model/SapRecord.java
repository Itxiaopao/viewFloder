package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

/**
 * sap挂账表 Model
 */
@Getter
@Setter
@ToString
public class SapRecord {

    private Long id; //id
    private Long calcResultId;//订单计算履历表id
    private Integer flag; //有函标识
    private String bstkd; //销售单号
    private String qxbs; //取消标识
    private Date posrq; //销售日期
    private String matnr; //商品skuno
    private BigDecimal fkimg; //销售数据量
    private Long dmbtr; //销售价格
    private Long dmbtr1; //发放金额
    private String zwerks; //实际dc仓
    private String lifnr; //供应商代码
    private String level4; //品类
    private String prdha; //品牌
    private String conno; //合同号
    private String konnr; //协议号
    private String flag1; //计划类型
    private Long tcjh; //计划号
    private String pernr; //营业员代码
    private Date jsrq; //接收日期
    private Integer cxflx; //促销费类型
    private String cxflxms; //促销费类型描述
    private String vbeln; //销售凭证
    private String posnr; //销售凭证项目
    private String vbeln1; //开票凭证
    private String posnr1; //出具发票项目
    private Date fkdat; //出具发票索引和打印的出具发票日期
    private String ebeln; //费用订单
    private Date budat; //费用订单创建日期
    private String ebelp; //采购凭证的项目编号
    private String belnr; //商品凭证编号(收货凭证号)
    private String buzei; //商品凭证中的项目(收货凭证行项目)
    private Date budatA; //收货日期
    private BigDecimal menge; //费用订单金额
    private String shkzg; //借/贷标识
    private String elikz; //交货已完成(x已完成)
    private Integer isDelete; //删除标识,0:未删除,1:已删除
    private Date createTime; //创建时间
    private Date updateTime; //更新时间
}