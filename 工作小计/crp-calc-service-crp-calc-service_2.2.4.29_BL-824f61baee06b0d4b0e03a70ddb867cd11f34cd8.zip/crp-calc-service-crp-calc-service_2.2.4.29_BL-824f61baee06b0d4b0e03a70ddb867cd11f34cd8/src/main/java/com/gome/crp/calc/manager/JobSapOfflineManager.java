package com.gome.crp.calc.manager;

import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.mybatis.service.ISapRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class JobSapOfflineManager {
    @Autowired
    private ISapRecordService iSapRecordService;
    @Autowired
    private ICalcResultService iCalcResultService;

    @Transactional
    public void doInsertApplyBill(List<SapRecord> sapRecords, List<CalcResult> updateCalcResult) {
        iSapRecordService.saveBatch(sapRecords);
        iCalcResultService.updateBatchById(updateCalcResult);
    }

}
