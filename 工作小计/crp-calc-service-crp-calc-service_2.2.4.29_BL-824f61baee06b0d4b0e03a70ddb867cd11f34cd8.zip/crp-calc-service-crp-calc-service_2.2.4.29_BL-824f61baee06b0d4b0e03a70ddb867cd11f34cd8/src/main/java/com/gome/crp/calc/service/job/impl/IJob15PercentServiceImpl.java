package com.gome.crp.calc.service.job.impl;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.dto.combiDto.CalcResultRecordDto;
import com.gome.crp.calc.manager.CalcResultManager;
import com.gome.crp.calc.service.job.IJob15PercentService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.SeqGenUtil;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.diamond.annotations.DiamondValue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;


@Slf4j
@Service
public class IJob15PercentServiceImpl implements IJob15PercentService {

    @Autowired
    private CalcResultManager calcResultManager;
    @Autowired
    private SeqGenUtil seqGenUtil;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private GcacheUtil gcacheUtil;
    @DiamondValue("${reset.cursor.time}")
    private int timeExpire;
    @Override
    public void deal15Percent() {
        log.info("job执行处理严控百分之十五,time:{}", new Date().toString());
        selectTask();
    }

    @Override
    public void deal15PercentCursor() {
        log.info("重置百分之十五提奖限额游标为0,time:{}", new Date().toString());
        gcacheUtil.putKeyValue(CacheKeyConstants.get15PercentIndexKey(), "0");
    }

    /**
     * 查询job status -2 -1 ykstatus = 1(已严控)
     *
     * @return
     */
    private void selectTask() {
        String index = gcacheUtil.getKeyValue(CacheKeyConstants.get15PercentIndexKey());
        if(null == index){
            index = "0";
        }
        List<CalcResult> queryCalcResults = calcResultManager.query15Percent(Long.valueOf(index));
        //更新数据下次处理位置
        if (null == queryCalcResults || queryCalcResults.size() == 0) {
            log.info("处理提奖百分之十五查询结果为空,time:{}", new Date().toString());
            return;
        }
        gcacheUtil.putKeyValue(CacheKeyConstants.get15PercentIndexKey(), queryCalcResults.get(queryCalcResults.size() - 1).getId().toString());
        gcacheUtil.setExpireTime(CacheKeyConstants.get15PercentIndexKey(),timeExpire);
        for (CalcResult calcResult : queryCalcResults) {
            List<CalcResult> calcResults = calcResultManager.queryListByOrderIdAndDetailId(calcResult.getOrderId(), calcResult.getDetailId());
            if (calcResults == null || calcResults.size() == 0) {
                log.info("处理百分之十五通过orderId:{},detailId:{},查询严控数据为空", calcResult.getOrderId(), calcResult.getDetailId());
                continue;
            }
            // orderId + detailId 下的所有数据必须都严控通过了，才进行提奖限额判断
            boolean ykStatusAll = false;
            // 拓客逻辑特殊处理
            Iterator<CalcResult> calcResultIterator = calcResults.iterator();
            while (calcResultIterator.hasNext()) {
                CalcResult result = calcResultIterator.next();
                // 拓客本身不走严控，所以，严控的job执行拓客逻辑应该还是很快的，但是为了防止逻辑漏洞，这里对拓客的也增加个严控的校验，此处的拓客的状态一定是 jobStatus = -1
                // 拓客延保不走提奖限额逻辑
                if ((BaseConstants.SCENE_Y.equals(result.getScenes()) && BaseConstants.YK_STATUS_YES == result.getYkStatus())
                        || BaseConstants.ORDER_GOODS_TYPE_YB.equals(result.getGoodsType())
                        || BaseConstants.PLAN_MARKETING_PROMOTION_TYPE.equals(result.getPromotionsType().toString())) {
                    CalcResult upResult = new CalcResult();
                    upResult.setId(result.getId());
                    upResult.setLimitAwardAmount(-1L);
                    calcResultMapper.updateById(upResult);
                    calcResultIterator.remove();
                } else {
                    // 促销费类型为空不处理（12渠道）
                    if (null == result.getPromotionsType()) {
                        ykStatusAll = true;
                        break;
                    }
                    // 没有严控，且还不是无促197/195的，也不是无促605的A卖A，那么，这条数据，则不能参与提奖限额的判断。因为 197 195 的没有严控，也是可以参与提奖限额判断的
                    boolean noYKData = (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(result.getExtraPolicyCode()) || BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(result.getExtraPolicyCode())) || BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(result.getExtraPolicyCode());
                    if (BaseConstants.YK_STATUS_NO == result.getYkStatus() && !noYKData) {
                        ykStatusAll = true;
                        break;
                    }
                }
            }
            // ykStatusAll 为 false 才参与提奖限额的判断
            if (ykStatusAll) {
                continue;
            }
            List<CalcResultRecordDto> updateCalcResultList = dealAwardPriceLe15Percent(calcResults);
            execute(updateCalcResultList);
        }
    }

    private long selectIndexPosition(String indexPositionKey) {
        long idIndex = 0L;
        String keyValue = gcacheUtil.getKeyValue(indexPositionKey);
        if (keyValue != null) {
            idIndex = Long.parseLong(keyValue);
        }
        return idIndex;
    }

    /**
     * 更新提奖金额，更新jobstatus
     *
     * @param calcResultRecordDtoList 受提奖限额影响的数据
     */
    private void execute(List<CalcResultRecordDto> calcResultRecordDtoList) {
        if (null == calcResultRecordDtoList || calcResultRecordDtoList.size() == 0) {
            log.error("计算百分之十五计提限价更新库入参为空，time:{}", new Date().toString());
            return;
        }
        List<CalcResult> updateCalcResultList = new ArrayList<>(calcResultRecordDtoList.size());
        for (CalcResultRecordDto calcResultRecordDto : calcResultRecordDtoList) {
            updateCalcResultList.add(calcResultRecordDto.getCalcResult());
        }

        calcResultManager.updateByList(updateCalcResultList);

        // 更新提奖限额的数据
        calcResultManager.saveOrUpdate(calcResultRecordDtoList);
    }

    /**
     * 处理提奖金额小于等于15
     *
     * @param updateCalcResultList
     * @return
     */
    public List<CalcResultRecordDto> dealAwardPriceLe15Percent(List<CalcResult> updateCalcResultList) {
        List<CalcResultRecordDto> calcResultRecordDtoList = new ArrayList();
        if (CollectionUtils.isEmpty(updateCalcResultList)) {
            log.info("处理平均计提基数金额入参为空,不进行逻辑处理");
            return null;
        }
        // orderId+detailId 的总提奖金额
        BigDecimal sumAward = new BigDecimal(0);
        // orderId+detailId 的总提奖金额
        BigDecimal sumJtjs = new BigDecimal(0);
        // key:计划id value:什么也不存 主要利用 hashMap 的 key 的唯一特性, 来得知 updateCalcResultList 的计划id有多少个
        Map<String, BigDecimal> planIdHashMap = new HashMap<>(updateCalcResultList.size());

        Iterator<CalcResult> calcResultIterator = updateCalcResultList.iterator();
        while (calcResultIterator.hasNext()) {
            CalcResult calcResult = calcResultIterator.next();
            if (calcResult.getProvisionType() == null || BaseConstants.SCENE_Y.equals(calcResult.getScenes())) {
                log.info("orderId:{},detailId:{} 的计提基数为空或者该场景为Y场景, 场景：{}", calcResult.getOrderId(), calcResult.getDetailId(), calcResult.getScenes());
                calcResultIterator.remove();
                // TODO 此处需要报警，人工处理，正常情况下不会没有 计提基数这个字段的
                continue;
            }
            // 同一个计划的 计提基数 只需要计算一次即可
            if (planIdHashMap.get(calcResult.getPlanId()) == null) {
                if (BaseConstants.PLAN_PROVISION_SELL == calcResult.getProvisionType()) {
                    sumJtjs = sumJtjs.add(new BigDecimal(calcResult.getSalePrice()));
                } else {
                    sumJtjs = sumJtjs.add(new BigDecimal(calcResult.getPrice()));
                }
                planIdHashMap.put(calcResult.getPlanId(), sumJtjs);
            }
            sumAward = sumAward.add(new BigDecimal(calcResult.getAwardAmount()));
        }

        if (planIdHashMap != null && planIdHashMap.size() > 0) {
            // 平均计提基数=【计划类型1（无促）计提基数+计划类型2（带单）计提基数+计划类型3（差异）计提基数+计划类型4（非差）计提基数】 ÷ 计划类型数量 * 15%
            BigDecimal avgPrice = sumJtjs.divide(new BigDecimal(planIdHashMap.size()), 2, RoundingMode.DOWN).multiply(new BigDecimal("0.15")).setScale(0, RoundingMode.DOWN);
            if (sumAward.compareTo(avgPrice) > 0) {
                Iterator<CalcResult> resultIterator = updateCalcResultList.iterator();
                while (resultIterator.hasNext()) {
                    CalcResult calcResult = resultIterator.next();
                    long actualAwardAmount = avgPrice.divide(sumAward, 2, RoundingMode.DOWN).multiply(new BigDecimal(calcResult.getAwardAmount())).setScale(0, RoundingMode.DOWN).longValue();

                    CalcResultRecordDto calcResultRecordDto = new CalcResultRecordDto();
                    CalcRecord calcRecord = new CalcRecord();
                    calcRecord.setId(seqGenUtil.nextCrpCalcRecordId());
                    calcRecord.setOrderId(calcResult.getOrderId());
                    calcRecord.setDetailId(calcResult.getDetailId());
                    calcRecord.setAward(calcResult.getAwardAmount() - actualAwardAmount);
                    calcRecord.setRemark("15%计提限价处理");
                    calcResultRecordDto.setCalcRecord(calcRecord);

                    CalcResult calcAwardResult = new CalcResult();
                    calcAwardResult.setId(calcResult.getId());
                    // 197 195 的这个时候，可能严控了，也可能未严控，所以，这个时候，直接拿 ykStatus 做逻辑判断
                    if (BaseConstants.YK_STATUS_YES == calcResult.getYkStatus()) {
                        calcAwardResult.setAwardAmount(actualAwardAmount);
                    }
                    calcAwardResult.setLimitAwardAmount(actualAwardAmount);
                    calcResultRecordDto.setCalcResult(calcAwardResult);

                    calcResultRecordDtoList.add(calcResultRecordDto);
                }
            } else {
                Iterator<CalcResult> resultIterator = updateCalcResultList.iterator();
                while (resultIterator.hasNext()) {
                    CalcResult calcResult = resultIterator.next();
                    CalcResultRecordDto calcResultRecordDto = new CalcResultRecordDto();
                    CalcResult calcAwardResult = new CalcResult();
                    calcAwardResult.setId(calcResult.getId());
                    calcAwardResult.setLimitAwardAmount(-1L);
                    calcResultRecordDto.setCalcResult(calcAwardResult);

                    calcResultRecordDtoList.add(calcResultRecordDto);
                }
            }
        }

        return calcResultRecordDtoList;
    }

}
