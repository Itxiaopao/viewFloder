package com.gome.crp.calc.service.order.impl;

import com.gome.crp.calc.constants.OrderProcessResultEnum;
import com.gome.crp.calc.constants.OrderTypeEnum;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.service.order.abstr.AbstractOrderBaseService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

/**
 * 配送单已生效
 * 支付后第一个物流状态
 * 提成计算
 */
@Slf4j
@Service
public class OrderCOServiceImpl extends AbstractOrderBaseService {
    @Autowired
    private IProblemService iProblemService;

    @Override
    public Integer process(OrderCalcDto orderCalcDto) {
        log.info("配送单mq消息处理开始orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);

        //查询计划订单
        List<CalcResult> calcResultList = super.selectCalcResult(orderCalcDto);
        if (!CollectionUtils.isEmpty(calcResultList)) {
            log.error("配送单mq消息处理,计划订单已存在orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
            return OrderProcessResultEnum.EXISTS_MATCH_PLAN_AWARD.getCode();
        }

        //货到付款类型,妥投单才有支付时间,匹配计划
        if (OrderTypeEnum.CASH_ON_DELIVERY.getCode().equals(orderCalcDto.getOrderType())) {
            log.info("配送单mq消息处理完成orderId:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto);
            // 问题小工具
            iProblemService.addData(orderCalcDto, null, null, orderCalcDto.getOrderId(), ProblemEnum.CODE_129);
            return null;
        } else {
            //计算逻辑
            Integer result = super.calcLogic(orderCalcDto);
            log.info("配送单mq消息处理完成orderId:{},orderCalcDto:{},result:{}", orderCalcDto.getOrderId(), orderCalcDto, result);
            return result;
        }
    }

}
