package com.gome.crp.calc.mybatis.model;

import java.util.Date;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 订单计算对象表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class OrderCalcMsg {

	@TableId(type = IdType.INPUT)
	private Long id; //id
	private String orderId; //订单号
	private String channel; //订单渠道
	private String gomeStatus; //订单状态
	private String skuNo; //skuno
	private String detailId; //detailId
	private String returnOrderId; //售后单号
	private String deliveryId; //配送单号
	private String sapDetailId; //sapDetailId
	private Integer orderType;//订单类型0:正常单;1:预售单;2:SMI单;3:货到付款4:全额定金发货
	private Date orderDate;//订单流转时间
	private Integer status; //0未处理;1已处理
	private Integer processNode; //处理节点0:oms节点;1:so节点
	private String msgBody; //消息体
	private Integer isDelete; //0未删除，1已删除
	private Date createTime; //createTime
	private Date updateTime; //updateTime
	private String ipAddress;//ip地址
}