package com.gome.crp.calc.client.receiver.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.gome.crp.calc.client.receiver.ILarkService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.QueryReceiverReqDto;
import com.gome.crp.calc.dto.profitDto.Receiver;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.lark.dubbo.IAgentServiceInfo;
import com.gome.lark.model.dto.ResultDTO;
import com.gome.lark.model.entity.AgentServiceForSkuNo;
import com.gome.stage.bean.BombDTO;
import com.gome.stage.item.GomeBombSkuService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * IM服务
 */
@Slf4j
@Service
public class LarkServiceImpl implements ILarkService {

    @Autowired
    private IAgentServiceInfo iAgentServiceInfo;
    @Autowired
    private GomeBombSkuService gomeBombSkuService;

    /**
     * 查询近7天国美会员的IM服务记录
     * https://www.kdocs.cn/l/cbS2U9w0u
     *
     * @param orderDto
     * @return
     */
    public List<Receiver> queryReceiverList(OrderCalcDto orderDto) {
        List<Receiver> receiverList = new ArrayList<>();
        QueryReceiverReqDto reqDto = new QueryReceiverReqDto();
        //入参校验
        if (orderDto == null || orderDto.getUserId() == null || orderDto.getShopNo() == null || orderDto.getPayDate() == null || orderDto.getSkuNo() == null) {
            log.info("通过IM服务记录查询承接人,入参错误,orderDto:{}", JSON.toJSONString(orderDto));
            return receiverList;
        }
        try {
            reqDto.setStoreId(orderDto.getShopNo());
            reqDto.setUserId(orderDto.getUserId());
            reqDto.setLongOrderTime(orderDto.getPayDate().getTime());
            //接口调用
            log.info("通过IM服务记录查询承接人,接口开始,userId:{},orderDto:{},reqDto:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto);
            ResultDTO<List<AgentServiceForSkuNo>> resultDTO = iAgentServiceInfo.getLastSevendaysList(
                    reqDto.getUserId(), reqDto.getStoreId(), reqDto.getLongOrderTime());
            log.info("通过IM服务记录查询承接人,接口完成,userId:{},orderDto:{},reqDto:{},result:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto, JSON.toJSONString(resultDTO));
            //结果解析
            if (resultDTO == null || !resultDTO.isSuccess()) {
                log.info("通过IM服务记录查询承接人,接口失败,userId:{},orderDto:{},reqDto:{},result:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto, JSON.toJSONString(resultDTO));
                return receiverList;
            }
            if (resultDTO.getResultObj() != null) {
                List<AgentServiceForSkuNo> data = resultDTO.getResultObj();
                for (AgentServiceForSkuNo dto : data) {
                    //匹配skuNo
//                    if (dto.getSkuNoList() == null || !dto.getSkuNoList().contains(orderDto.getSkuNo())) {
//                        log.error("通过IM服务记录查询承接人,sku匹配失败,userId:{},orderDto:{},result:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), JSON.toJSONString(resultDTO));
//                        continue;
//                    }
//                    Receiver receiver = new Receiver();
//                    receiver.setStaffId(dto.getStaffId());
//                    receiver.setReceiverTime(dto.getStartTime());
//                    receiverList.add(receiver);
                	
                	if(StringUtils.isNotBlank(dto.getSkuNoList())){
                		//匹配skuNo
                		 if(dto.getSkuNoList().contains(orderDto.getSkuNo())){
                             Receiver receiver = new Receiver();
                             receiver.setStaffId(dto.getStaffId());
                             receiver.setReceiverTime(dto.getStartTime());
                             receiver.setProfitBehaviorCode(ProfitBehaviorEnum.SERVICE_IM.getCode());
                             receiverList.add(receiver);
                		 }else{
                			 log.info("通过IM服务记录查询承接人,sku匹配失败,userId:{},orderDto:{},Rim承接人:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), JSON.toJSONString(dto));
                			 //匹配spid
                			 log.info("通过IM服务记录查询承接人,开始匹配spu,userId:{},orderDto:{},Rim承接人:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), JSON.toJSONString(dto));
                			 boolean flag = matchSpuId(orderDto,dto);
                			 if(flag){
                                 Receiver receiver = new Receiver();
                                 receiver.setStaffId(dto.getStaffId());
                                 receiver.setReceiverTime(dto.getStartTime());
                                 receiver.setProfitBehaviorCode(ProfitBehaviorEnum.SERVICE_IM.getCode());
                                 receiverList.add(receiver);
                			 }else{
                				 log.info("通过IM服务记录查询承接人,匹配spu失败,userId:{},orderDto:{},Rim承接人:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), JSON.toJSONString(dto));
                			 }
                		 }
                	}else{
                		log.info("通过IM服务记录查询承接人,匹配失败,userId:{},orderDto:{},Rim承接人:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), JSON.toJSONString(dto));
                	}
                	
                	
                	
                	
                	
                }
            }
        } catch (Exception e) {
            log.error("通过IM服务记录查询承接人,接口异常,userId:{},orderDto:{},reqDto:{},e:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto, e);
            throw new BusinessException(String.format("通过IM服务记录查询承接人,接口异常,userId:%s,orderDto:%s", orderDto.getUserId(), JSON.toJSONString(orderDto)), e);
        }
        return receiverList;
    }
    
    /**
     * 匹配spuId
     * @param orderDto
     * @param skuNoList
     * @return
     */
    public boolean matchSpuId(OrderCalcDto orderDto,AgentServiceForSkuNo dto){
    	if(StringUtils.isBlank(dto.getSkuNoList())){
    		log.info("通过IM服务记录查询承接人,无法匹配spu,skuNoList为null,userId:{},orderDto:{},AgentServiceForSkuNo:{}", orderDto.getUserId(), JSON.toJSONString(orderDto),  JSON.toJSONString(dto));
    		return false;
    	}
    	String orderSpid = queryorderDtoSpid(orderDto);
    	String rimSpid = queryRimSpid(dto,orderDto);
    	if(StringUtils.isNotBlank(orderSpid) && StringUtils.isNotBlank(rimSpid) && rimSpid.contains(orderSpid) ){
    		log.info("通过IM服务记录查询承接人,匹配spu成功,userId:{},order:{},orderSpid:{},rimSpid:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), orderSpid,rimSpid);
    		return true;
    	}
    	log.info("通过IM服务记录查询承接人,匹配spu失败,userId:{},order:{},orderSpid:{},rimSpid:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), orderSpid,rimSpid);
        return false;
    } 
    
    
    /**
     * 查询detial订单的 商品的spid
     * @param orderDto
     * @return
     */
    public String queryorderDtoSpid(OrderCalcDto orderDto){
    	String result = null;
    	try{
    		log.info("开始调用sku属性查询服务接口入参,orderDto:{},mId:{},SkuNo:{}",JSON.toJSONString(orderDto),BaseConstants.MID, orderDto.getSkuNo());
        	BombDTO<Map<String, String>> bombDTO = gomeBombSkuService.getSkuModelInfo(BaseConstants.MID, orderDto.getSkuNo());
        	log.info("调用sku属性查询服务接口结束,orderDto:{},bombDTO:{}", JSON.toJSONString(orderDto),JSON.toJSONString(bombDTO));
        	if (StringUtils.isNotBlank(bombDTO.getErrCode()) && bombDTO.getErrCode().equals("200")) {
        		 Map<String, String> map = bombDTO.getData();
        		 if (map != null && map.size() > 0) {
        			 String productId = map.get("productId");
        			 result = productId;
        		 }
        	}
    	}catch(Exception e){
            log.error("sku属性查询服务接口异常,userId:{},orderDto:{},e:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), e);
            throw new BusinessException(String.format("sku属性查询服务接口异常,接口异常,userId:%s,orderDto:%s", orderDto.getUserId(), JSON.toJSONString(orderDto)), e);
    	}

    	return result;
    }

    
    /**
     * 查询rim spids
     * @param skuNoList
     * @return
     */
	public String queryRimSpid(AgentServiceForSkuNo dto,OrderCalcDto orderDto) {
		String skuNoArray[] = dto.getSkuNoList().split(",");
		List<String> list = new ArrayList<String>();
		Collections.addAll(list, skuNoArray);
		StringBuilder sb = new StringBuilder("");
		int pagesize = 25;
        int totalcount = list.size();
        int pagecount = 0;
        List<String> subList = null;;
        int m = totalcount % pagesize;
        if (m > 0) {
            pagecount = totalcount / pagesize + 1;
        } else {
            pagecount = totalcount / pagesize;
        }
        for(int currentPage = 1;currentPage <= pagecount; currentPage++){
            if (m == 0) {
                subList = list.subList((currentPage - 1) * pagesize, pagesize * (currentPage));
            } else {
                if (currentPage == pagecount) {
                    subList = list.subList((currentPage - 1) * pagesize, totalcount);
                } else {
                    subList = list.subList((currentPage - 1) * pagesize, pagesize * (currentPage));
                }
            }
			try {
				log.info("开始调用sku属性批量查询服务接口入参,orderDto:{},AgentServiceForSkuNo:{},mId:{},SkuNos:{}",JSON.toJSONString(orderDto), JSON.toJSONString(dto), BaseConstants.MID,JSON.toJSONString(subList));
				BombDTO<Map<String, Map<String, String>>> bombDTO = gomeBombSkuService.getSkuModelInfos(BaseConstants.MID, subList);
				log.info("调用sku属性批量查询服务接口结束,orderDto:{},AgentServiceForSkuNo:{},bombDTO:{}",JSON.toJSONString(orderDto), JSON.toJSONString(dto), JSON.toJSONString(bombDTO));
				if (StringUtils.isNotBlank(bombDTO.getErrCode()) && bombDTO.getErrCode().equals("200")) {
					Map<String, Map<String, String>> map = bombDTO.getData();
					if (map != null && map.size() > 0) {
						for (String skuNo : subList) {
							Map<String, String> result = map.get(skuNo);
							if (result != null && map.size() > 0) {
								String productId = result.get("productId");
								if (StringUtils.isNotBlank(productId)) {
									sb.append(productId).append(",");
								}
							}
						}
					}
				}
			} catch (Exception e) {
				log.error("sku属性批量查询服务接口异常,userId:{},orderDto:{},AgentServiceForSkuNo:{},e:{}", orderDto.getUserId(),JSON.toJSONString(orderDto), JSON.toJSONString(dto), e);
				throw new BusinessException(String.format("sku属性批量查询服务接口异常,接口异常,userId:%s,orderDto:%s", orderDto.getUserId(), JSON.toJSONString(orderDto)), e);
			}
		}
		
      return sb.toString();
	}
	
	

	/**
     * 利用subList方法进行分页
     * @param list 分页数据
     * @param pagesize  页面大小
     * @param currentPage   当前页面
     */
    public static List<String> pageBySubList(List<String> list, int pagesize, int currentPage) {
        int totalcount = list.size();
        int pagecount = 0;
        List<String> subList;
        int m = totalcount % pagesize;
        if (m > 0) {
            pagecount = totalcount / pagesize + 1;
        } else {
            pagecount = totalcount / pagesize;
        }
        if (m == 0) {
            subList = list.subList((currentPage - 1) * pagesize, pagesize * (currentPage));
        } else {
            if (currentPage == pagecount) {
                subList = list.subList((currentPage - 1) * pagesize, totalcount);
            } else {
                subList = list.subList((currentPage - 1) * pagesize, pagesize * (currentPage));
            }
        }
        return subList;
    }

    
    
    
}
