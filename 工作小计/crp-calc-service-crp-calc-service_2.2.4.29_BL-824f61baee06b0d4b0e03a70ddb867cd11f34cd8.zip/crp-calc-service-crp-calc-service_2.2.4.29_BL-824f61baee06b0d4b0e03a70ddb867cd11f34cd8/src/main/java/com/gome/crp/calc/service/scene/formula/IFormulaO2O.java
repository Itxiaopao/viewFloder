package com.gome.crp.calc.service.scene.formula;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.math.BigDecimal;

/**
 * O2O公式计算
 */
public interface IFormulaO2O {

    // **********************************************************
    // O2O
    // "O2O-提奖金额=单品销售金额（或单品实付金额）×销售数量×Z/M比例
    //***********************************************************
    BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene);


}
