package com.gome.crp.calc.service.order;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.mybatis.model.CalcResult;

import java.util.List;

public interface IOrderService {

    /**
     * 订单逻辑处理类
     *
     * @param orderCalcDto
     * @see com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
     */
    Integer process(OrderCalcDto orderCalcDto);

    /**
     * 计算主逻辑
     *
     * @param orderCalcDto
     * @return
     */
    Integer calcLogic(OrderCalcDto orderCalcDto);

    /**
     * 重新计算
     *
     * @param orderCalcDto
     * @param calcResultList
     * @return
     */
    void redoCalc(OrderCalcDto orderCalcDto, List<CalcResult> calcResultList);

    /**
     * 记录未匹配结果
     *
     * @param orderCalcDto
     */
    void recordCalcNoResult(OrderCalcDto orderCalcDto, Integer result);

    /**
     * 重新计算
     *
     * @param orderCalcDto
     * @param calcResultList 同一个sapDetailId
     * @return
     */
    Integer redoCalcLogic(OrderCalcDto orderCalcDto, List<CalcResult> calcResultList);
}
