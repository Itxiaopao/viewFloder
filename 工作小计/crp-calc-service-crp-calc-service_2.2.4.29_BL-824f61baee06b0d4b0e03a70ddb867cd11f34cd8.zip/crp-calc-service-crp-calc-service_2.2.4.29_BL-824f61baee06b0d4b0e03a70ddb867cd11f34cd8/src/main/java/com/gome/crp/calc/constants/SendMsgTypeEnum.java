package com.gome.crp.calc.constants;

public enum SendMsgTypeEnum {
	/**
	 * 消息推送类型， 邮件
	 */
	SEND_EMAIL(1, "发送邮件"),
	/**
	 * 消息推送类型， 微信报警(卡片形式)
	 */
	SEND_WECHAT_CARD(2, "微信报警(卡片形式)"),
	/**
	 * 消息推送类型， 微信报警(文本形式);
	 */
	SEND_WECHAT_TEXT(3, "微信报警(文本形式)"),

    ;

    private Integer code;
    private String msg;

    SendMsgTypeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
