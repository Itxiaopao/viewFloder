package com.gome.crp.calc.constants;

public enum ProcessNodeEnum {
    OMS_NODE(0, "oms节点"),
    SO_NODE(1, "so节点"),
    ;

    private Integer code;
    private String msg;

    ProcessNodeEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
