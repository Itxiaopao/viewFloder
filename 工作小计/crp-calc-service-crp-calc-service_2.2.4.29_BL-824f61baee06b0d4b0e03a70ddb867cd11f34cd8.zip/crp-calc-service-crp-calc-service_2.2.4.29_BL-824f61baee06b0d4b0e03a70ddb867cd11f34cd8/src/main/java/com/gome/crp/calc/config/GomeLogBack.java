package com.gome.crp.calc.config;

import com.gome.boot.common.logging.switcher.initializer.DiamondLoggerSwitchInitializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GomeLogBack {

    @Value("${diamond.dataId}")
    private String diamondDataId;
    @Value("${diamond.group}")
    private String diamondGroup;

    @Bean
    public DiamondLoggerSwitchInitializer loggerSwitchInitializer() {
        return DiamondLoggerSwitchInitializer.of(diamondGroup, diamondDataId);
    }

}
