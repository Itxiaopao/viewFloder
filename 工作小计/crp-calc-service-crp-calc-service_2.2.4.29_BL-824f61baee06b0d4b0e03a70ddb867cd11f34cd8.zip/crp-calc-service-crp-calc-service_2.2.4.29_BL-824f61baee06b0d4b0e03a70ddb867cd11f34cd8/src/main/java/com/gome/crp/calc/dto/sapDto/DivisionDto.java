package com.gome.crp.calc.dto.sapDto;


import lombok.Getter;
import lombok.Setter;

/**
 * 十大品类编码 -> 通过四级品类获得
 */
@Setter
@Getter
public class DivisionDto {

    private String divisionCode;
    private String divisionName;


}
