package com.gome.crp.calc.service.scene.formula;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.math.BigDecimal;

/**
 * WC公式计算
 */
public interface IFormulaWC {

    // **********************************************************
    // WC无促 (促销费类型 + 签约类型)
    // 政策编码
    // 1. z195/z605 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例
    // 2.z197 提奖金额=单台标准×销售数量×发放比例×XYZM比例
    // singleStandardMoney * buyNum * issueRate * sceneValue
    // 无促单台标准 singleStandard
    //***********************************************************
    BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene);


}
