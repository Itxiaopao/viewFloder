package com.gome.crp.calc.dto.employee;

import java.io.Serializable;

/**
 * 供应商信息.
 */
public class ResponseGroupVendorDto implements Serializable{


	private static final long serialVersionUID = 5196313493612940617L;

	/** 供应商代码 */
    private String vendorCode;
    /** 供应商名称 */
    private String vendorName;
    /** 供应商类型 */
    private String vendorType;
    /** 供应商类型描述 */
    private String vendorTypeDesc;
    /** 法人代表 */
    private String corporate;
    /** 联系人名称 */
    private String contactName;
    /** 联系人电话 */
    private String contactTelephone;
    /** 手机 */
    private String contactPhone;
    /** 传真 */
    private String fax;
    /** 电子邮箱 */
    private String mail;
    /** 邮编 */
    private String zip;
    /** 地址 */
    private String address;
    /** 备注 */
    private String remarks;
    /** 纳税人识别号 */
    private String invoiceCode;


    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getVendorType() {
        return vendorType;
    }

    public void setVendorType(String vendorType) {
        this.vendorType = vendorType;
    }

    public String getVendorTypeDesc() {
        return vendorTypeDesc;
    }

    public void setVendorTypeDesc(String vendorTypeDesc) {
        this.vendorTypeDesc = vendorTypeDesc;
    }

    public String getCorporate() {
        return corporate;
    }

    public void setCorporate(String corporate) {
        this.corporate = corporate;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactTelephone() {
        return contactTelephone;
    }

    public void setContactTelephone(String contactTelephone) {
        this.contactTelephone = contactTelephone;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getInvoiceCode() {
        return invoiceCode;
    }

    public void setInvoiceCode(String invoiceCode) {
        this.invoiceCode = invoiceCode;
    }
}
