package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboDealSceneYFacade;
import com.gome.crp.calc.service.job.IJobDealSceneYService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 计算履历
 */
@Slf4j
@Service("dubboDealSceneYFacade")
public class DubboDealSceneYFacadeImpl implements IDubboDealSceneYFacade {
    @Autowired
    private IJobDealSceneYService iJobDealSceneYService;
    @Override
    public void executeJob() {
        iJobDealSceneYService.dealSceneY();
    }
}
