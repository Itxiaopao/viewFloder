package com.gome.crp.calc.service.job;

public interface IJobDealSceneYService {

    void dealSceneY();
}
