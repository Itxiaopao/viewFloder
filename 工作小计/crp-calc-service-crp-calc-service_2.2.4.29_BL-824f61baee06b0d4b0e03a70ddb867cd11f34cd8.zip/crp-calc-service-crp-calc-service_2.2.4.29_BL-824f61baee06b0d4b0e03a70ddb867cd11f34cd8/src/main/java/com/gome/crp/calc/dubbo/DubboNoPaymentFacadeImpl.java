package com.gome.crp.calc.dubbo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.crp.calc.facade.dubbo.task.IDubboNoPaymentFacade;
import com.gome.crp.calc.service.job.IJobNoPaymentService;

@Service("iDubboNoPaymentFacade")
public class DubboNoPaymentFacadeImpl implements IDubboNoPaymentFacade{

	@Autowired
	private IJobNoPaymentService iJobNoPaymentService;
	
	@Override
	public void process() {
		iJobNoPaymentService.changeJobStatus();
	}

}
