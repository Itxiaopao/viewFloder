package com.gome.crp.calc.client.coupon.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.gome.crp.calc.client.coupon.IConsumerConponService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.pangu.promotionapply.client.coupongive.CouponQueryInnoClient;
import com.gome.pangu.promotionapply.client.coupongive.dto.CouponGiveParamDTO;
import com.gome.pangu.promotionapply.client.coupongive.dto.CouponGiveResultDTO;
import com.gome.rpc.base.RequestDTO;
import com.gome.rpc.base.ResponseDTO;

import lombok.extern.slf4j.Slf4j;

/**
 * 券接口调用
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class ConsumerCouponServiceImpl implements IConsumerConponService {
	
	@Autowired
	private CouponQueryInnoClient couponQueryInnoClient;

	/**
	 * couponIdList 与 ticketIdList 二选一传入， couponType：必穿, userId必穿
	 * @param userId
	 * @param couponIdList
	 * @param ticketIdList
	 * @param couponType
	 * @return
	 */
	private List<CouponGiveResultDTO> queryCouponGiveInfo(String userId, List<String> couponIdList, List<String> ticketIdList,
			long couponType) {
		if(CollectionUtils.isEmpty(couponIdList) && CollectionUtils.isEmpty(ticketIdList)) {
			log.info("查询券会员历史记录Dubbo[非法], (couponIdList or ticketIdList):null");
			return null;
		}
		if(StringUtils.isBlank(userId)) {
			log.info("查询券会员历史记录Dubbo[非法], userId:null");
			return null;
		}
		RequestDTO<CouponGiveParamDTO> reqs = new RequestDTO<>();
		CouponGiveParamDTO body = new CouponGiveParamDTO();
		body.setCouponIdList(couponIdList);
		body.setCouponType(couponType);
		body.setTicketIdList(ticketIdList);
		body.setUserId(userId);
		reqs.setBody(body);
		ResponseDTO<List<CouponGiveResultDTO>> repso = null;
		List<CouponGiveResultDTO> resp = null;
		try {
			log.info(String.format("查询券会员历史记录Dubbo, param:%s", JSONObject.toJSONString(reqs)));
			repso = couponQueryInnoClient.queryCouponGiveInfo(reqs);
			log.info(String.format("查询券会员历史记录Dubbo, result:%s", JSONObject.toJSONString(repso)));
			if (CollectionUtils.isNotEmpty(repso.getBody())){
				resp = repso.getBody();
			}
		} catch (Exception e) {
			log.error(String.format("查询券会员历史记录Dubbo, param:%s", JSONObject.toJSONString(reqs)),e);
		}
		return resp;
	}

	// 60/13 不管
	@Override
	public String queryCouponGiveInfo(List<OrderCalcCouponDto> couponList) {
		if(null == couponList || couponList.size() <= 0) {
			return null;
		}
		List<String> c3001s = new ArrayList<>();
		List<String> c3002s = new ArrayList<>();
		List<String> c3003s = new ArrayList<>();
		List<String> c3005s = new ArrayList<>();
		for(OrderCalcCouponDto dto : couponList) {
			Long type = dto.getCouponType();
			// 3001:美券 3002:蓝券 3003:红券 3004:运费券 3005:营销券
			// "couponId":"券id（红券3003、蓝券3002）"
			// "ticketId":"券号（美券3001、营销券3005）"
			// 后期使用美券 营销券
			if (type == BaseConstants.COUPON_TYPE_3001) {
				c3001s.add(dto.getTicketId());
			}
			if (type == BaseConstants.COUPON_TYPE_3002) {
				c3002s.add(dto.getCouponId());
			}
			if (type == BaseConstants.COUPON_TYPE_3005) {
				c3005s.add(dto.getTicketId());
			}
			if (type == BaseConstants.COUPON_TYPE_3003) {
				c3003s.add(dto.getCouponId());
			}
		}
		List<CouponGiveResultDTO> query3001s = this.queryCouponGiveInfo(null, null, c3001s, BaseConstants.COUPON_TYPE_3001);
		List<CouponGiveResultDTO> query3005s = this.queryCouponGiveInfo(null, null, c3005s, BaseConstants.COUPON_TYPE_3005);
		List<CouponGiveResultDTO> query3002s = this.queryCouponGiveInfo(null, c3002s, null, BaseConstants.COUPON_TYPE_3002);
		List<CouponGiveResultDTO> query3003s = this.queryCouponGiveInfo(null, c3003s, null, BaseConstants.COUPON_TYPE_3003);
		
		String userId = "";
		// 以当前时间为基准， 券领取时间大于当前时间  replace 当前值
		long lastTime = System.currentTimeMillis();
		
		if(query3001s != null && query3001s.size() > 0) {
			/*for (CouponGiveResultDTO dto : query3001s) {
				Date createDate = dto.getCreateDate();
				long time = createDate.getTime();
				if(time < lastTime) {
					lastTime = time;
					userId = dto.getUserId();
				}
			}*/
			Optional<CouponGiveResultDTO> min = query3001s.stream().min((x, y) -> Long.valueOf(x.getCreateDate().getTime()).compareTo(y.getCreateDate().getTime()));
			long time = min.get().getCreateDate().getTime();
			if(lastTime > time) {
				lastTime = time;
				userId = min.get().getUserId();
			}
		}
		if(query3002s != null && query3002s.size() > 0) {
			/*for (CouponGiveResultDTO dto : query3002s) {
				Date createDate = dto.getCreateDate();
				long time = createDate.getTime();
				if(time < lastTime) {
					lastTime = time;
					userId = dto.getUserId();
				}
			}*/
			Optional<CouponGiveResultDTO> min = query3002s.stream().min((x, y) -> Long.valueOf(x.getCreateDate().getTime()).compareTo(y.getCreateDate().getTime()));
			long time = min.get().getCreateDate().getTime();
			if(lastTime > time) {
				lastTime = time;
				userId = min.get().getUserId();
			}
		}
		if(query3003s != null && query3003s.size() > 0) {
			/*for (CouponGiveResultDTO dto : query3003s) {
				Date createDate = dto.getCreateDate();
				long time = createDate.getTime();
				if(time < lastTime) {
					lastTime = time;
					userId = dto.getUserId();
				}
			}*/
			Optional<CouponGiveResultDTO> min = query3003s.stream().min((x, y) -> Long.valueOf(x.getCreateDate().getTime()).compareTo(y.getCreateDate().getTime()));
			long time = min.get().getCreateDate().getTime();
			if(lastTime > time) {
				lastTime = time;
				userId = min.get().getUserId();
			}
		}
		if(query3005s != null && query3005s.size() > 0) {
			/*for (CouponGiveResultDTO dto : query3005s) {
				Date createDate = dto.getCreateDate();
				long time = createDate.getTime();
				if(time < lastTime) {
					lastTime = time;
					userId = dto.getUserId();
				}
			}*/
			Optional<CouponGiveResultDTO> min = query3005s.stream().min((x, y) -> Long.valueOf(x.getCreateDate().getTime()).compareTo(y.getCreateDate().getTime()));
			long time = min.get().getCreateDate().getTime();
			if(lastTime > time) {
				lastTime = time;
				userId = min.get().getUserId();
			}
		}
		return userId;
	}

	@Override
	public String queryCouponGiveInfo(List<OrderCalcCouponDto> couponList, String userId) {
		if(null == couponList || couponList.size() <= 0) {
			return null;
		}
		List<String> c3001s = new ArrayList<>();
		List<String> c3002s = new ArrayList<>();
		List<String> c3003s = new ArrayList<>();
		List<String> c3005s = new ArrayList<>();
		for(OrderCalcCouponDto dto : couponList) {
			Long type = dto.getCouponType();
			// 3001:美券 3002:蓝券 3003:红券 3004:运费券 3005:营销券
			// "couponId":"券id（红券3003、蓝券3002）"
			// "ticketId":"券号（美券3001、营销券3005）"
			// 后期使用美券 营销券
			if (type == BaseConstants.COUPON_TYPE_3001) {
				c3001s.add(dto.getTicketId());
			}
			if (type == BaseConstants.COUPON_TYPE_3002) {
				c3002s.add(dto.getCouponId());
			}
			if (type == BaseConstants.COUPON_TYPE_3005) {
				c3005s.add(dto.getTicketId());
			}
			if (type == BaseConstants.COUPON_TYPE_3003) {
				c3003s.add(dto.getCouponId());
			}
		}
		List<CouponGiveResultDTO> query3001s = queryCouponGiveInfo(userId, null, c3001s, BaseConstants.COUPON_TYPE_3001);
		List<CouponGiveResultDTO> query3005s = queryCouponGiveInfo(userId, null, c3005s, BaseConstants.COUPON_TYPE_3005);
		List<CouponGiveResultDTO> query3002s = queryCouponGiveInfo(userId, c3002s, null, BaseConstants.COUPON_TYPE_3002);
		List<CouponGiveResultDTO> query3003s = queryCouponGiveInfo(userId, c3003s, null, BaseConstants.COUPON_TYPE_3003);
		
		// 以当前时间为基准， 券领取时间大于当前时间  replace 当前值
		// key: id/code value: timeStep
		Map<String, CouponGiveResultDTO> map_coupon = new HashMap<>();
		if(CollectionUtils.isNotEmpty(query3001s)) {
			query3001s.stream().forEach(x -> {
				this.getSameCouponMaxTime(x, map_coupon, BaseConstants.COUPON_TYPE_3001);
			});
		}
		if(CollectionUtils.isNotEmpty(query3002s)) {
			query3002s.stream().forEach(x -> {
				this.getSameCouponMaxTime(x, map_coupon, BaseConstants.COUPON_TYPE_3002);
			});
		}
		if(CollectionUtils.isNotEmpty(query3003s)) {
			query3003s.stream().forEach(x -> {
				this.getSameCouponMaxTime(x, map_coupon, BaseConstants.COUPON_TYPE_3003);
			});
		}
		if(CollectionUtils.isNotEmpty(query3005s)) {
			query3005s.stream().forEach(x -> {
				this.getSameCouponMaxTime(x, map_coupon, BaseConstants.COUPON_TYPE_3005);
			});
		}
		String userId_coupon = "";
		if(map_coupon.size() <= 0) {
			return userId_coupon;
		}
		long currentTime = System.currentTimeMillis();
		for(String key: map_coupon.keySet()) {
			CouponGiveResultDTO gd = map_coupon.get(key);
			long coupon_time = gd.getCreateDate().getTime();
			if(coupon_time < currentTime) {
				currentTime = coupon_time;	// 当前时间 > 用户券时间
				String couponRemarkRegular = couponRemarkRegular(gd.getRemark());
				userId_coupon = couponRemarkRegular;	// 券用户Id
			}
		}
		return userId_coupon;
	}
	
	/**
	 * 取同意链路的券分享人最晚的时间节点
	 * 
	 * @param target
	 * @param map_coupon
	 */
	private void getSameCouponMaxTime(CouponGiveResultDTO target, Map<String, CouponGiveResultDTO> map_coupon, int type) {
		String ticket = "";
		if (type == BaseConstants.COUPON_TYPE_3001) {
			ticket = target.getTicketId();
		}
		if (type == BaseConstants.COUPON_TYPE_3002) {
			ticket = target.getCouponId();
		}
		if (type == BaseConstants.COUPON_TYPE_3005) {
			ticket = target.getTicketId();
		}
		if (type == BaseConstants.COUPON_TYPE_3003) {
			ticket = target.getCouponId();
		}
		CouponGiveResultDTO intra_cgm = map_coupon.get(ticket);
		if(null == intra_cgm) {
			map_coupon.put(ticket, target);
		}else {
			Long intra_time = intra_cgm.getCreateDate().getTime();
			Long compare_time = target.getCreateDate().getTime();
			if(intra_time.compareTo(compare_time) < 0) {
				map_coupon.put(ticket, target);
			}
		}
	}
	
	/**
	 * 使用正则表达式提取券分享人的 userid
	 * @param remark 券分享标注
	 * @return 分享人
	 */
	public static String couponRemarkRegular(String remark){
	   String shareUserId = null;
	   Pattern p = Pattern.compile("(\\[[^\\]]*\\])");
	   Matcher m = p.matcher(remark);
	   while(m.find()){
	      shareUserId = m.group().substring(1, m.group().length()-1);
	      break;
	   }
	   return shareUserId;
	}


}
