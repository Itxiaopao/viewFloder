package com.gome.crp.calc.service.scene.formula;


import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;

import java.math.BigDecimal;

/**
 * 综合计算公式公共接口
 */
public interface ICalFormulas {
    // 计算结果
    BigDecimal calculatedResult(OrderCalcDto orderDto, PlanDto planDto, String scene);
}
