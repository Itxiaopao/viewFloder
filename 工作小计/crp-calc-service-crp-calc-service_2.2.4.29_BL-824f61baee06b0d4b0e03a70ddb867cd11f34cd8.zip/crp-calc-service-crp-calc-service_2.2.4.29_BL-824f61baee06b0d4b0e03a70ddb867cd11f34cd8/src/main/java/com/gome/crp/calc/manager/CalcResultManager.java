package com.gome.crp.calc.manager;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.combiDto.CalcResultRecordDto;
import com.gome.crp.calc.mybatis.mapper.CalcRecordMapper;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class CalcResultManager {

    @Autowired
    private ICalcResultService iCalcResultService;
    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private CalcRecordMapper calcRecordMapper;
    private static final int PAGE_SIZE = 500;

//    @Transactional(rollbackFor = Exception.class)
//    public void doSaveCalcResult(List<CalcResult> calcResults) {
//        iCalcResultService.saveBatch(calcResults);
//    }

    /**
     * 查询严控的数据
     *
     * @return
     */
    public List<CalcResult> queryListOfFreeze() {
        Page<CalcResult> page = new Page<>();
        page.setSize(PAGE_SIZE);
        page.setSearchCount(false);
        QueryWrapper<CalcResult> queryWrapper = new QueryWrapper<CalcResult>()
                .select(new String[]{"id","staff_class","promotions_type","extra_policy_code","scenes","is_asella","staff_supplier_code","order_supplier_code"})
                .eq("job_status", BaseConstants.CRD_JOB_STATUS_0)
                .in("gome_status", new String[]{BaseConstants.ORDER_CO_STATUS, BaseConstants.ORDER_DL_STATUS})
                .notIn("extra_policy_code", new String[]{BaseConstants.PLAN_EXTRA_POLICY_CODE_195, BaseConstants.PLAN_EXTRA_POLICY_CODE_197})
                .orderByAsc("id");
        Page<CalcResult> page1 = iCalcResultService.page(page, queryWrapper);
        return page1.getRecords();
    }

    public Boolean updateByList(List<CalcResult> calcResultDetails) {
        return iCalcResultService.updateBatchById(calcResultDetails, 1000);
    }

    public void saveOrUpdate(List<CalcResultRecordDto> calcResultRecordDtoList) {
        for (CalcResultRecordDto calcResultRecordDto : calcResultRecordDtoList) {
            if(null == calcResultRecordDto.getCalcRecord()){
                continue;
            }
            calcRecordMapper.insert(calcResultRecordDto.getCalcRecord());
        }
    }

    /**
     * 查询所有
     *
     * @return
     */
    public List<CalcResult> queryListOfALL(Date startTime,Date endTime) {
        Page<CalcResult> page = new Page<>();
        page.setSize(PAGE_SIZE);
        page.setSearchCount(false);
        QueryWrapper<CalcResult> queryWrapper = new QueryWrapper<CalcResult>()
                .select(new String[]{"id","order_submit_time","category_level_two","brand_code","shop_no","order_supplier_code"})
                .eq("job_status", BaseConstants.CRD_JOB_STATUS_0)
                .ge("order_submit_time",startTime).lt("order_submit_time",endTime)
                .in("gome_status", new String[]{BaseConstants.ORDER_CO_STATUS, BaseConstants.ORDER_DL_STATUS})
                .in("extra_policy_code", new String[]{BaseConstants.PLAN_EXTRA_POLICY_CODE_195, BaseConstants.PLAN_EXTRA_POLICY_CODE_197})
                .orderByAsc("id");
        Page<CalcResult> page1 = iCalcResultService.page(page, queryWrapper);
        return page1.getRecords();
    }


    /**
     * 定时任务处理Y场景数据
     *
     * @return
     */
    public List<CalcResult> queryListOfSceneYFromResult(CalcResult calcResult) {
        QueryWrapper<CalcResult> queryWrapper = new QueryWrapper<CalcResult>()
                .select(new String[]{"id"})
                .eq("job_status", BaseConstants.CRD_JOB_STATUS_SCENE_Y)
                .eq("scenes", BaseConstants.SCENE_Y).eq("profile_id", calcResult.getProfileId()).eq("plan_id", calcResult.getPlanId())
                .eq("staff_code", calcResult.getStaffCode()).in("gome_status", new String[]{BaseConstants.ORDER_CO_STATUS, BaseConstants.ORDER_DL_STATUS});
        return iCalcResultService.list(queryWrapper);
    }

    /**
     * 百分之15查询
     */
    public List<CalcResult> query15Percent(Long idIndex){
        Page<CalcResult> page = new Page<>();
        page.setSize(PAGE_SIZE);
        page.setSearchCount(false);
        QueryWrapper<CalcResult> queryWrapper = new QueryWrapper<CalcResult>()
                .select(new String[]{"id","order_id","plan_id","detail_id","scenes","yk_status","profile_id","staff_code","job_status","award_amount","provision_type","sale_price","price","promotions_type","extra_policy_code","warranty_flag"})
                .gt("id", idIndex)
//                .in("id",new Integer[]{225821,225823,225824,225825,225826})
                .eq("job_status", BaseConstants.CRD_JOB_STATUS_1_N)
                .in("channel", new String[]{BaseConstants.ORDER_CHANNEL_JINLI, BaseConstants.ORDER_CHANNEL_MEIDIAN, BaseConstants.ORDER_CHANNEL_YDYY, BaseConstants.ORDER_CHANNEL_ONLINE})
                .isNull("limit_award_amount")
                .orderByAsc("id");
        Page<CalcResult> page1 = iCalcResultService.page(page, queryWrapper);
        return page1.getRecords();
    }

    /**
     * 通过orderId 和 detailId查询
     * @param orderId
     * @param detailId
     * @return
     */
    public List<CalcResult> queryListByOrderIdAndDetailId(String orderId,String detailId){
        QueryWrapper<CalcResult> queryWrapper = new QueryWrapper<CalcResult>()
                .select(new String[]{"id","order_id","plan_id","detail_id","scenes","yk_status","profile_id","staff_code","job_status","award_amount","provision_type","sale_price","price","promotions_type","extra_policy_code","warranty_flag"})
                .eq("job_status", BaseConstants.CRD_JOB_STATUS_1_N)
                .eq("order_id",orderId)
                .eq("detail_id",detailId)
                .isNull("limit_award_amount")
                .in("channel", new String[]{BaseConstants.ORDER_CHANNEL_JINLI, BaseConstants.ORDER_CHANNEL_MEIDIAN, BaseConstants.ORDER_CHANNEL_YDYY, BaseConstants.ORDER_CHANNEL_ONLINE})
                .orderByAsc("id");
        return iCalcResultService.list(queryWrapper);
    }
}
