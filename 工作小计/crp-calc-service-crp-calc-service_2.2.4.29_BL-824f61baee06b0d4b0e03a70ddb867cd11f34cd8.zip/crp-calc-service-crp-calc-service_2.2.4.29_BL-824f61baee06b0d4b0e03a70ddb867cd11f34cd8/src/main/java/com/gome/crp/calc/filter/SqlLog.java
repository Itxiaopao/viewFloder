package com.gome.crp.calc.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;

@Slf4j
public class SqlLog {
    private static final ThreadLocal<SimpleDateFormat> DATE_FORMAT_THREAD_LOCAL = new ThreadLocal<SimpleDateFormat>() {
        @Override
        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        }
    };

    //替换参数格式化Sql语句，去除换行符
    public static void print(String beautifySql, MybatisSqInterceptor.Property property, long sqlCost) {
        if (property == null || CollectionUtils.isEmpty(property.getPropertyValueList())) {
            return;
        }

        //值列表
        List<Object> propertyValueList = property.getPropertyValueList();
        for (Object value : propertyValueList) {
            String paramValueStr = "";
            if (value instanceof String) {
                paramValueStr = "'" + value + "'";
            } else if (value instanceof Date) {
                paramValueStr = "'" + DATE_FORMAT_THREAD_LOCAL.get().format(value) + "'";
            } else {
                paramValueStr = value + "";
            }
            // mybatis generator 中的参数不打印出来
//                    if(!propertyName.contains("frch_criterion")){
//                        paramValueStr = "/*" + propertyName + "*/" + paramValueStr;
//                    }
            beautifySql = beautifySql.replaceFirst("\\?", Matcher.quoteReplacement(paramValueStr));
        }

        log.debug("SQL:{}    执行耗时={}", beautifySql, sqlCost);
    }
}
