package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcResult;

/**
 * 订单计算履历主表 Mapper
 * @author zhangshuang
 *
 */
public interface CalcResultMapper extends BaseMapper<CalcResult>{

}