package com.gome.crp.calc.dto.payDto;

import lombok.Data;

import java.util.Date;

@Data
public class ApplyPayItemDto {
    private Long calcResultId;
    private String scenes;
    private String gomeStatus;
    private Long awardAmount;
    private String deliveryId;
    private Integer expencesOfferType;
    private String detailId;
    private String skuNo;
    private String skuName;
    private Integer buyNum;
    private Date orderEffectTime;
    private String companyCode;
    private String shopNo;
    private String userId;
    private String planId;
    private Integer isGomeOffer;
    private Integer isASellA;
    private String channel;
}
