package com.gome.crp.calc.dto.payDto;

import lombok.Data;

import java.util.List;

@Data
public class ApplyPayReqDto {
    private List<ApplyPayItemDto> items;
}
