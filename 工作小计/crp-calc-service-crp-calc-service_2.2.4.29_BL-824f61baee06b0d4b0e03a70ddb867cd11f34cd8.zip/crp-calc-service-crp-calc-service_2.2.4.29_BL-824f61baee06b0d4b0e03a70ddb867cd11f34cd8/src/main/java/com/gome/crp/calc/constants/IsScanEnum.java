package com.gome.crp.calc.constants;

/**
 * 是否已扫描
 */
public enum IsScanEnum {
	UN_SUC(2, "未成功"),
    YES(1, "已扫描"),
    NO(0, "未扫描"),

    ;

    private int code;
    private String msg;

    IsScanEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
