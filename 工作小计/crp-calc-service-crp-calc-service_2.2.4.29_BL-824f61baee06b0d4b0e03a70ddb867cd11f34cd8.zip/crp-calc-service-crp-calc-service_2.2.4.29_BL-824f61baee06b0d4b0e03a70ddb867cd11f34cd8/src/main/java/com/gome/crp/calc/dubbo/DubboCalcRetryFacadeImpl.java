package com.gome.crp.calc.dubbo;

import org.springframework.beans.factory.annotation.Autowired;

import com.gome.crp.calc.facade.dubbo.task.IDubboCalcRetryFacade;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import org.springframework.stereotype.Service;

@Service
public class DubboCalcRetryFacadeImpl implements IDubboCalcRetryFacade {
	
	@Autowired
	private ICalcRetryCopeService calcRetryCopeService;

	@Override
	public void scan() {
		calcRetryCopeService.scan();
	}
	
	
	

}
