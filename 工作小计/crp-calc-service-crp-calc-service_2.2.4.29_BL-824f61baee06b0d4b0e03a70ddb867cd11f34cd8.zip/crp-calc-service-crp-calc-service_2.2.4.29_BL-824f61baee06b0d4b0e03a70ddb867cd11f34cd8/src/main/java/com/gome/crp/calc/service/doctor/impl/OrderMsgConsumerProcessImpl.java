package com.gome.crp.calc.service.doctor.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.mybatis.mapper.CalcResultRepeatMapper;
import com.gome.crp.calc.mybatis.mapper.OrderRecordMapper;
import com.gome.crp.calc.mybatis.model.CalcResultRepeat;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.mybatis.model.OrderRecord;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.calc.service.order.IOrderStatusHandlerService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.util.lock.RedisLock;
import com.gome.crp.calc.util.lock.RedisLockHelper;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import com.gome.crp.order.calc.dto.DeliveryDto;
import com.gome.crp.order.calc.dto.DetailGoodsDto;
import com.gome.crp.order.calc.dto.GoodsDto;
import com.gome.crp.order.calc.dto.OrderDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * 接收订单 MQ
 */
@Slf4j
@Component
public class OrderMsgConsumerProcessImpl {
    @Autowired
    private OrderRecordMapper orderRecordMapper;
    @Autowired
    private IProblemService iProblemService;
    @Autowired
    private IOMSOrderService iOMSOrderService;
    @Autowired
    private IOrderStatusHandlerService iOrderStatusHandlerService;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private CalcResultRepeatMapper calcResultRepeatMapper;
    @Autowired
    private RedisLockHelper redisLockHelper;

    public void processMessage(String msg, String msgId) {
        //消息解析
        OrderDto orderDto = JSON.parseObject(msg, OrderDto.class);
        // 过滤提成系统不需要的订单数据
        orderDto = filterOrder(orderDto, msgId, msg);

        log.info("接收订单mq消息开始msgId:{}, msg:{}, orderDto:{}", msgId, msg, orderDto);
        if (orderDto != null && CollectionUtils.isNotEmpty(orderDto.getDeliveryList())) {
            dealOrder(msgId, msg, orderDto);
        }
    }

    private OrderDto filterOrder(OrderDto orderDto, String msgId, String msg) {
        // 临时卡不处理
        if (StringUtils.isEmpty(orderDto.getProfileId()) || BaseConstants.ORDER_PROFILE_LINSHIKA.equals(orderDto.getProfileId())) {
            addProblem(msgId, msg, orderDto.getOrderId(), "临时卡不处理");
            return null;
        }

        // 对于oms来说，一个消息体里，只会有一个配送单。但是为了兼容，此处还是用了 remove
        List<DeliveryDto> deliveryList = orderDto.getDeliveryList();
        Iterator<DeliveryDto> iterator = deliveryList.iterator();
        while (iterator.hasNext()) {
            // 订单状态
            DeliveryDto deliveryDto = iterator.next();
            String gomeState = deliveryDto.getGomeState();

            if (BaseConstants.ORDER_CO_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_DL_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_CL_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_RT_STATUS.equals(gomeState)
                    || BaseConstants.ORDER_RCO_STATUS.equals(gomeState)) {
                Map<String, String> requestHeaderMap = orderDto.getRequestHeaderMap();

                String desc = null;
                //非12渠道顶单requestHeaderMap要做非空校验
                if ((!deliveryDto.getChannelNo().equals(BaseConstants.ORDER_CHANNEL_O2O)) && (requestHeaderMap == null || requestHeaderMap.size() == 0)) {
                    log.info("orderId: {}, requestHeaderMap为空，提成计算不处理", orderDto.getOrderId());
                    desc = "requestHeaderMap为null";
                }
                // 逆向单子没有支付时间
                if ((BaseConstants.ORDER_CO_STATUS.equals(gomeState)
                        || BaseConstants.ORDER_DL_STATUS.equals(gomeState))
                        && orderDto.getPayDate() == null) {
                    log.info("orderId: {}, payDate为空，提成计算不处理", orderDto.getOrderId());
                    desc = "payDate为空";
                }

                if (StringUtils.isNotEmpty(desc)) {
                    addProblem(msgId, msg, orderDto.getOrderId(), desc);
                    return null;
                }
            } else {
                log.info("orderId: {}, deliveryId: {}, 配送单状态为: {}, 提成计算不处理，将此状态过滤",
                        orderDto.getOrderId(), deliveryDto.getShippingGroupId(), gomeState);
                iterator.remove();
                continue;
            }

            List<GoodsDto> goodsList = deliveryDto.getGoodsList();
            Iterator<GoodsDto> goodsDtoIterator = goodsList.iterator();
            while (goodsDtoIterator.hasNext()) {
                GoodsDto goodsDto = goodsDtoIterator.next();
                // 赠品
                if (BaseConstants.ORDER_GOODS_TYPE_GIFT.equals(goodsDto.getGoodsType())) {
                    log.info("orderId: {}, deliveryId: {}, 商品为赠品, 不参与计算逻辑处理", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                    addProblem(msgId, msg, orderDto.getOrderId(), "商品为赠品");
                    goodsDtoIterator.remove();
                    continue;
                }

                List<DetailGoodsDto> detailList = goodsDto.getDetailList();
                Iterator<DetailGoodsDto> detailGoodsDtoIterator = detailList.iterator();
                while (detailGoodsDtoIterator.hasNext()) {
                    DetailGoodsDto detailGoods = detailGoodsDtoIterator.next();
                    // sapDetailId
                    //非12渠道订单要做非空校验
                    if (StringUtils.isEmpty(detailGoods.getSapDetailId())) {
                        log.info("orderId: {}, deliveryId: {}, sapDetailId 为 null", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                        addProblem(msgId, msg, orderDto.getOrderId(), "sapDetailId 为 null");
                        detailGoodsDtoIterator.remove();
                        continue;
                    }
                    // 延保/百货 商品，业务机型为 null
                    if (StringUtils.isEmpty(detailGoods.getSalesModel())) {
                        log.info("orderId: {}, deliveryId: {}, salesModel 为 null", orderDto.getOrderId(), deliveryDto.getShippingGroupId());
                        addProblem(msgId, msg, orderDto.getOrderId(), "salesModel 为 null");
                        detailGoodsDtoIterator.remove();
                        continue;
                    }
                }
            }
        }

        return orderDto;
    }

    private void dealOrder(String msgId, String msg, OrderDto orderDto) {
        // 保存 mq 消息入库
        recordOrderMsg(msgId, msg, orderDto);
        List<OrderCalcDto> orderCalcDtos = iOMSOrderService.transferOrderCalcDto(orderDto);
        if (orderCalcDtos != null) {
            dealOrderDetail(orderCalcDtos);
        }

    }

    private void dealOrderDetail(List<OrderCalcDto> orderCalcDtos) {
        for (OrderCalcDto orderCalcDto : orderCalcDtos) {
            long startTime = System.currentTimeMillis();
            log.info("detail级提成计算开始, 时间: {}", startTime);

            //订单幂等校验
            String orderUniqueKey = CacheKeyConstants.getOrderUniqueKey(orderCalcDto);
            try {
                log.info("detail级提成计算开始, orderId: {}, deliveryId: {}, skuNo: {}, detailId: {}, orderUniqueKey:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId(), orderUniqueKey, orderCalcDto);

                gcacheUtil.deleteKey(new String[]{orderUniqueKey});
                Long value = gcacheUtil.distributedLockAtom(orderUniqueKey, CacheKeyConstants.CACHE_KEY_TIMEOUT, "1");
                if (value == 1L) {
                    //防重
                    try {
                        CalcResultRepeat calcResultRepeat = getCalcResultRepeat(orderCalcDto);
                        calcResultRepeatMapper.insert(calcResultRepeat);
                    } catch (DuplicateKeyException e) {
                        log.error("detail级提成计算被防重, orderId: {}, deliveryId: {}, skuNo: {}, detailId: {}, orderUniqueKey:{},orderCalcDto:{}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId(), orderUniqueKey, orderCalcDto, e);
                    }

                    //订单预计算
                    String orderDetailLock = CacheKeyConstants.getOrderDetailLock(orderCalcDto.getOrderId(), orderCalcDto.getChannel(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
                    RedisLock redisLock = redisLockHelper.getLock(orderDetailLock);
                    if (!redisLock.lock()) {
                        log.error("detail级提成计算加锁失败orderId:{},orderDetailLock:{}", orderCalcDto.getOrderId(), orderDetailLock);
                        throw new BusinessException(String.format("detail级提成计算加锁失败orderId:%s,orderDetailLock:%s", orderCalcDto.getOrderId(), orderDetailLock));
                    }

                    try {
                        iOrderStatusHandlerService.calcOrder(orderCalcDto);
                    } finally {
                        redisLock.unlock();
                    }

                } else {
                    log.info("幂等性校验失败");
                }

                log.info("detail级提成计算结束, orderId: {}, deliveryId: {}, skuNo: {}, detailId: {}", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
            } catch (Exception e) {
                log.error("detail级提成计算失败, 错误信息: ", e);
                try {
                    // 问题小工具
                    iProblemService.addData(orderCalcDto, null, null, orderCalcDto.getOrderId(), ProblemEnum.CODE_113);
                    // 失败重试
                    CalcRetry calcRetry = new CalcRetry();
                    calcRetry.setType(RetryJobEnum.ORDERCALC.getCode());
                    calcRetry.setOrderId(orderCalcDto.getOrderId());
                    calcRetry.setSapDetailId(orderCalcDto.getSapDetailId());
                    calcRetry.setMsgBody(JSON.toJSONString(orderCalcDto));
                    calcRetry.setGomeStatus(orderCalcDto.getGomeState());
                    calcRetry.setFailureReason(e.getMessage());
                    calcRetryCopeService.insertRetry(calcRetry);
                } catch (Exception e1) {
                    log.error("提成计算插入问题小工具或插入失败重试失败，错误信息：", e1);
                }
            } finally {
                CalcLocal.removeLocalDto();
                log.info("detail级提成计算结束, 耗时: {}", System.currentTimeMillis() - startTime);
            }
        }
    }

    private void recordOrderMsg(String msgId, String msg, OrderDto orderDto) {
        try {
            OrderRecord orderRecord = new OrderRecord();
            orderRecord.setMsgId(msgId);
            orderRecord.setOrderId(orderDto.getOrderId());
            orderRecord.setMsgBody(msg);
            orderRecordMapper.insert(orderRecord);
        } catch (Exception e) {
            log.error("接收订单mq消息,保存异常msgId:{},msg:{},orderDto:{}", msgId, msg, orderDto, e);
        }
    }

    private void addProblem(String msgId, String msg, String oderId, String desc) {
        try {
            ProblemDto problemDto = new ProblemDto(oderId);
            problemDto.setMsgId(msgId);
            problemDto.setMsg(msg);
            problemDto.setDescription(desc);
            iProblemService.addData(problemDto, ProblemEnum.CODE_115);
        } catch (Exception e) {
            log.error("提成计算插入问题小工具或插入失败重试失败，错误信息：", e);
        }
    }

    private CalcResultRepeat getCalcResultRepeat(OrderCalcDto orderCalcDto) {
        CalcResultRepeat calcResultRepeat = new CalcResultRepeat();
        calcResultRepeat.setOrderId(orderCalcDto.getOrderId());
        calcResultRepeat.setGomeStatus(orderCalcDto.getGomeState());
        calcResultRepeat.setSkuNo(orderCalcDto.getSkuNo());
        calcResultRepeat.setDetailId(orderCalcDto.getDetailId());
        calcResultRepeat.setChannel(orderCalcDto.getChannel());
        String returnOrderId = "";
        if (BaseConstants.ORDER_RCO_STATUS.equals(orderCalcDto.getGomeState())) {
            returnOrderId = orderCalcDto.getReturnOrderId();
        }
        calcResultRepeat.setReturnOrderId(returnOrderId);
        return calcResultRepeat;
    }

}
