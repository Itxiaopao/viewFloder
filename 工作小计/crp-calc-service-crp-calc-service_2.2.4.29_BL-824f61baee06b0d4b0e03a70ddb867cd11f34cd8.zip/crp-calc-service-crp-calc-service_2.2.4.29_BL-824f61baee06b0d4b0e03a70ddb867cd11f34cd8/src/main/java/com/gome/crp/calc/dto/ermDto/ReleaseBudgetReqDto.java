package com.gome.crp.calc.dto.ermDto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ReleaseBudgetReqDto {
    public ReleaseBudgetReqDto() {
		super();
	}
	public ReleaseBudgetReqDto(String messageId, String planId, BigDecimal amount) {
		this.messageId = messageId;
		this.planId = planId;
		this.amount = amount;
	}
	private String messageId;
    private String planId;
    private BigDecimal amount;
}
