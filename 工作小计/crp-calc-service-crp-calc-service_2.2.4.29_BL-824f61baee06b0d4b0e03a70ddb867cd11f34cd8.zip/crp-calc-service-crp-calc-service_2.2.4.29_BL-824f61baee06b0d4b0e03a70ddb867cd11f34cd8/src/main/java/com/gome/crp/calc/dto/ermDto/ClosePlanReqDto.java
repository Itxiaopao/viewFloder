package com.gome.crp.calc.dto.ermDto;

import lombok.Data;

@Data
public class ClosePlanReqDto {
    private String planId;
}
