package com.gome.crp.calc.service.job;

import java.util.Date;

public interface IJobAwardService {

    void dealFreezeStatus();

    void dealPromoter(String dateStr);

    String dealTimeToString(Date time);
}
