package com.gome.crp.calc.client.message.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.gome.eagle.entity.Alarm;
import com.gome.eagle.service.AlarmService;
import com.gome.meidian.common.base.exceptions.BizExcepition;

import lombok.extern.slf4j.Slf4j;

/*
 * 企业微信预警
 */
@Slf4j
@Component
public class WeChatUtil {

	@Value("${wechat.source.app}")
	private String sourceApp;
	@Value("${wechat.break.url}")
	private String defaultUrl;
	private final static String title = "CRP-CALC预警";
	
	@Autowired
	private AlarmService alarmService;
	
	/**
	 * 发送报警信息 文本 DUBBO 形式
	 * @param content 发送内容
	 * @return Boolean
	 */
	public Boolean warningText(String content) {
		return warningTextByDubbo(content);
	}
	
	/**
	 * 发送报警信息 卡片 DUBBO形式
	 * @param content 发送内容
	 * @return Boolean
	 */
	public Boolean warningCard(String content) {
		return warningCard(content, defaultUrl);
	}
	
	/**
	 * 发送报警信息 卡片
	 * @param content 发送内容
	 * @param url 详情跳转连接
	 * @return Boolean
	 */
	public Boolean warningCard(String content, String url) {
		if(StringUtils.isBlank(content)) {
			throw new BizExcepition(1, "内容不能为空");
		}
		return warningCardByDubbo(content, url);
	}
	
	/**
	 * 发送微信报警 dubbo + text 文本形式
	 * @param content
	 * @return Boolean
	 */
	public Boolean warningTextByDubbo(String content) {
		try {
			Alarm alarm = new Alarm();
			alarm.setType("text");
			alarm.setMessage(content);
			String wechat = alarmService.wechat(sourceApp, alarm);
			log.info("发送微信警报成功，方式：dubbo-text，发送内容：{}，返回结果：{}",content,wechat);
		} catch (Exception e) {
			log.error("发送微信警报失败，方式：dubbo-text，发送内容：{}，exception is {}", content, e);
			return false;
		}
		return true;
	}
	
	/**
	 * 发送微信报警 dubbo + 卡片形式
	 * @param content
	 * @return Boolean
	 */
	public Boolean warningCardByDubbo(String content, String url) {
		try {
			Alarm alarm = new Alarm();
			alarm.setType("textcard");
			alarm.setTitle(title);
			alarm.setMessage(content);
			alarm.setUrl(url);
			String wechat = alarmService.wechat(sourceApp, alarm);
			log.info("发送微信警报成功，方式：dubbo-crad，发送内容：{}，返回结果：{}",content,wechat);
		} catch (Exception e) {
			log.error("发送微信警报失败，方式：dubbo-crad，发送内容：{}，exception is {}", content, e);
			return false;
		}
		return true;
	}
	
}
