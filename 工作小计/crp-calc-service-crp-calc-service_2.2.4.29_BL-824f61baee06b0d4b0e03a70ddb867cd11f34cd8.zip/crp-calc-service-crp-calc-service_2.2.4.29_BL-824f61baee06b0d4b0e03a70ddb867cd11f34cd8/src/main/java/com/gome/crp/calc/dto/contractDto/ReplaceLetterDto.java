package com.gome.crp.calc.dto.contractDto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 带单函
 */
@Data
public class ReplaceLetterDto implements Serializable {
    private static final long serialVersionUID = 3013536413975056036L;

    private String contractCode;//合同编号
    private String documentType;//合同类型
    private String confirmationNo;//带单确认函号
    private String classTwo;//二级品类
    private String brandCode;//品牌编码
    private String buyOrgCode;//采购组织编码
    private String buyOrgGroup;//采购组
    private String suppCode;//供应商编码
    private String companyCode;//公司编码
    private String brandName;//品牌名称
    private String className;//品类名称
    private String suppName;//供应商名称
    private String buyOrgName;//采购组织名称
    private String companyName;//公司名称
    private BigDecimal limitPrice;//计提限价
    private BigDecimal singleStandard;//单台标准
    private BigDecimal distributionRate;//发放比例
    private String salesModel;//业务机型

}
