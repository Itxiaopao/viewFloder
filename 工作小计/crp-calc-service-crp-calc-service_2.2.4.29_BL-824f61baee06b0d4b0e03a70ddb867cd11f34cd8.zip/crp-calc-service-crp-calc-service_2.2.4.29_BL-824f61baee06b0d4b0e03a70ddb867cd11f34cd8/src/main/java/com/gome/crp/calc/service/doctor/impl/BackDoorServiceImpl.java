package com.gome.crp.calc.service.doctor.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.gome.crp.calc.mybatis.mapper.OrderRecordMapper;
import com.gome.crp.calc.mybatis.model.OrderRecord;
import com.gome.crp.calc.service.doctor.IBackDoorService;
import com.gome.crp.calc.util.threadLocal.CalcLocal;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class BackDoorServiceImpl implements IBackDoorService {
    @Autowired
    private OrderRecordMapper orderRecordMapper;
    @Autowired
    private OrderMsgConsumerProcessImpl orderMsgConsumerProcessImpl;

    @Override
    public void recalculateByOrderId(String[] orderIds) {
        if (orderIds == null || orderIds.length == 0) {
            log.error("后门重新计算-入参为空orderIds");
            return;
        }

        CalcLocal.setRepairThreadLocal(true);
        try {
            for (String orderId : orderIds) {
                QueryWrapper<OrderRecord> queryWrapper = new QueryWrapper<>();
                queryWrapper.eq("order_id", orderId);
                queryWrapper.orderByAsc("create_time");
                List<OrderRecord> orderRecords = orderRecordMapper.selectList(queryWrapper);
                for (OrderRecord orderRecord : orderRecords) {
                    String msgBody = orderRecord.getMsgBody();
                    try {
                        log.info("后门重新计算开始orderId:{},msgId:{}", orderRecord.getOrderId(), orderRecord.getMsgId());
                        orderMsgConsumerProcessImpl.processMessage(msgBody, orderRecord.getMsgId());
                        log.info("后门重新计算完成orderId:{},msgId:{}", orderRecord.getOrderId(), orderRecord.getMsgId());
                    } catch (Exception e) {
                        log.error("后门重新计算异常orderId:{},msgId:{}", orderRecord.getOrderId(), orderRecord.getMsgId(), e);
                    }
                }
            }
        } finally {
            CalcLocal.removeRepairThreadLocal();
        }

    }
}
