package com.gome.crp.calc.annotation.aspect;



import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.annotation.RunningTime;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Aspect
@Component
public class AspectRunTimeStamp {

	
	/**
	 * 添加扫描方法体运行时间打印方法
	 * @param joinPoint
	 * @param runningTime
	 * @return
	 * @throws Throwable
	 */
    @Around("@annotation(runningTime)")
    public Object doAround(ProceedingJoinPoint joinPoint, RunningTime runningTime) throws Throwable {
    	String methodName = joinPoint.toLongString();
    	Object[] args = joinPoint.getArgs();
    	
        String nackName = runningTime.nickName();
        if(StringUtils.isBlank(nackName)) {
        	nackName = "";
        }
        long start_time = System.currentTimeMillis();
        Object proceed = joinPoint.proceed();
        long end_time = System.currentTimeMillis();
        log.info(String.format("别名:%s, 运行方法体:%s, 运行时间(ms):%s, 参数:%s, ", nackName, methodName, (end_time - start_time), JSONObject.toJSONString(args)));
        return proceed;
    }



}
