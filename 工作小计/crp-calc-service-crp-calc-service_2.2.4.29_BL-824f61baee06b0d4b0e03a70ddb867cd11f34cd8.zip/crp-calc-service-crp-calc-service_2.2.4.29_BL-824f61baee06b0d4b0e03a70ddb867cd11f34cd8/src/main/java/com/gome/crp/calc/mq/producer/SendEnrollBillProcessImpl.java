package com.gome.crp.calc.mq.producer;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.billDto.EnrollBillMQDto;
import com.gome.crp.calc.mq.core.producer.MQProducerSendMsgProcessor;
import com.gome.crp.calc.mq.core.producer.MQSendResult;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.service.retry.ICalcRetryCopeService;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
    * 待入账推送
 */
@Component
@Slf4j
public class SendEnrollBillProcessImpl extends MQProducerSendMsgProcessor {

    @Value("${gome.crp.account.topic}")
    private String topic;
    @Value("${gome.crp.account.tag}")
    private String tag;
    @Value("${gome.crp.account.groupName}")
    private String groupName;
    @Autowired
    private ICalcRetryCopeService calcRetryCopeService;

    public static final String BILL_ACK_KEY = "account:crp:";


    /**
     * 目前 只有 1, 3 推送
     * @since BaseConstants.PRE_BILL_ACCOUNT_TYPE_1, _3
     * @param list
     * @param accountType 入账类型: 1、待入账 2、已入账 3、已失效
     */
    public void sendPreBills(List<CalcResult> list, int accountType, String orderStatus){
        log.info("推送返利入账信息-start:  accountType: {}, orderstatus:{}, data: {}", accountType, orderStatus, JSONObject.toJSONString(list));
        if (CollectionUtils.isEmpty(list)){
            return ;
        }
        for (CalcResult calc:list){
            EnrollBillMQDto enrollBillMQDto = this.copyProperties(calc, accountType);
            if(enrollBillMQDto != null){
                String jsonString = JSONObject.toJSONString(enrollBillMQDto);
                this.sendPreEnrollMQ(jsonString, calc.getOrderId(), getGomeStatus(enrollBillMQDto.getStatus()));
            }
        }
        log.info("推送返利入账信息-end, accountType: {}, orderStatus:{}", accountType, orderStatus);
    }

    // 判断推送数据类型
    private boolean checkSendData(CalcResult calc, int accountType){
        // 正向单逻辑
        if(accountType == BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_1){
            return true;
        }
        // 逆向单逻辑
        if(accountType == BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_3){
            Integer jobStatus = calc.getJobStatus();
            Integer rebateAccountType = calc.getRebateAccountType();
            if(BaseConstants.ENROLL_BILL_ACCOUNT_TYPE_INIT < rebateAccountType
                    && BaseConstants.CRD_JOB_STATUS_3 > jobStatus){
                return true;
            }else{
                return false;
            }
        }
        return false;
    }


    private int getSceneType(String scene){
        if(BaseConstants.SCENE_Y.equals(scene)){
            return 43;
        }else if(BaseConstants.SCENE_Z.equals(scene)){
            return 44;
        }else if(BaseConstants.SCENE_M.equals(scene)){
            return 45;
        }
        return 0;
    }

    private int getOrderType(String gomeStatus){
        if(BaseConstants.ORDER_CO_STATUS.equals(gomeStatus)){
            return 1;
        }else if(BaseConstants.ORDER_DL_STATUS.equals(gomeStatus)){
            return 5;
        }else if(BaseConstants.ORDER_CL_STATUS.equals(gomeStatus)){
            return 2;
        }else if(BaseConstants.ORDER_RT_STATUS.equals(gomeStatus)){
            return 3;
        }else if(BaseConstants.ORDER_RCO_STATUS.equals(gomeStatus)){
            return 6;
        }
        return 0;
    }


    /**
     * copy properties
     */
    public EnrollBillMQDto copyProperties(CalcResult result, int accountType){
        EnrollBillMQDto dto = new EnrollBillMQDto();
        int sceneType = this.getSceneType(result.getScenes());
        if (sceneType <= 0){
            return null;
        }
        dto.setKey(BILL_ACK_KEY + result.getId());
        dto.setRebateType(sceneType);
        dto.setOrderId(result.getOrderId());
        dto.setSkuId(result.getSkuId());
        dto.setSkuNo(result.getSkuNo());
        dto.setAmount(result.getAwardAmount());
        dto.setChildGomeId(result.getProfileId());
        dto.setUserId(result.getUserId());
        dto.setOrderCreateTime(result.getOrderSubmitTime());
        dto.setCreateTime(new Date());
        dto.setSkuName(result.getSkuName());
        dto.setStatus(this.getOrderType(result.getGomeStatus()));
        dto.setAccountType(accountType);
        dto.setItemSource(Byte.valueOf(result.getChannel()));
        // 默认值 --------
        dto.setMerchantId("888");
        dto.setLevel(1);
        // 默认值 --------
        return dto;
    }

    /**
     * 异步推送待入账信息，保证最终成功
     *
     * @param dataSet 消息体
     */
    private MQSendResult sendPreEnrollMQ(String dataSet, String sortkey, String gomeState) {
        try {
            log.info("提成计算推送-cope-入账信息，topic：{}, tag:{}, param：{}", topic, tag, dataSet);
            //MQSendResult send = this.syncPreEnroll(dataset, sortkey);
            // 发送统一消息队列
            MQSendResult send = this.sendUniqueue(topic, tag, dataSet, sortkey);
            if (!send.isSendSuccess()) {
                log.info("提成计算推送-cope-入账信息失败");
                CalcRetry calcRetry = new CalcRetry();
                calcRetry.setType(RetryJobEnum.PRE_ENROLL_BILL.getCode());
                calcRetry.setOrderId(sortkey);
                calcRetry.setMsgBody(dataSet);
                calcRetry.setGomeStatus(gomeState);
                calcRetry.setFailureReason(send.getErrMsg());
                calcRetryCopeService.insertRetry(calcRetry);
            }
            log.info("提成计算推送-cope-入账信息成功, msgId:{}", send.getSendResult().getMsgId());
            return send;
        } catch (Exception e) {
            log.error("提成计算推送-cope-入账信息失败，异常信息", e);
            CalcRetry calcRetry = new CalcRetry();
            calcRetry.setType(RetryJobEnum.PRE_ENROLL_BILL.getCode());
            calcRetry.setOrderId(sortkey);
            calcRetry.setMsgBody(dataSet);
            calcRetry.setGomeStatus(gomeState);
            calcRetry.setFailureReason(e.getMessage());
            calcRetryCopeService.insertRetry(calcRetry);
            return new MQSendResult();
        }
    }


    // retry
    public MQSendResult sendPreEnrollRetry(String dataSet) {
        log.info("重推推送返利入账信息-start: {}", dataSet);
        EnrollBillMQDto enrollBillMQDto = JSONObject.parseObject(dataSet, EnrollBillMQDto.class);
        MQSendResult mq = this.sendPreEnrollMQ(dataSet, enrollBillMQDto.getOrderId(), getGomeStatus(enrollBillMQDto.getStatus()));
        log.info("重推推送返利入账信息-end");
        return mq;
    }


    private String getGomeStatus(Integer status) {
        if (status == null) {
            return null;
        }

        if (status == 1) {
            return BaseConstants.ORDER_CO_STATUS;
        } else if (status == 5) {
            return BaseConstants.ORDER_DL_STATUS;
        } else if (status == 2) {
            return BaseConstants.ORDER_CL_STATUS;
        } else if (status == 3) {
            return BaseConstants.ORDER_RT_STATUS;
        } else if (status == 6) {
            return BaseConstants.ORDER_RCO_STATUS;
        } else {
            return null;
        }
    }

}
