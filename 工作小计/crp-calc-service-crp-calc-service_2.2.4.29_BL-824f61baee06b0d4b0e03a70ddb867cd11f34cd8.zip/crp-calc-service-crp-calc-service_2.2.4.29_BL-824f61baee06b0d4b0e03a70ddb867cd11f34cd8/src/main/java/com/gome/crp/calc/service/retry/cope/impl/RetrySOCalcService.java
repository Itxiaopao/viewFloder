package com.gome.crp.calc.service.retry.cope.impl;

import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import com.gome.crp.calc.service.so.ISOOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Slf4j
@Service
public class RetrySOCalcService implements IRetrySceneService {

    @Autowired
    private ISOOrderService soOrderService;

    @Override
    public boolean cope(CalcRetry calcRetry) {
        String msgBody = calcRetry.getMsgBody();
        try {
            log.info("so 合同重复计算,channel:{},sapDetailId:{},time:{}",msgBody.split("-")[0],msgBody.split("-")[1],new Date().toString());
            soOrderService.handler(msgBody.split("-")[0], msgBody.split("-")[1]);
            return true;
        } catch (Exception e) {
            log.error("SO计算异常channel:{},sapDetailId:{},time:{},ErrorMsg:{}",msgBody.split("-")[0],msgBody.split("-")[1],new Date().toString(), e);
        }
        return false;
    }
}
