package com.gome.crp.calc.constants;

/**
 * 是否冲减综贡
 */
public enum IsOffsetEnum {
    YES(0, "是"),
    NO(1, "否"),

    ;

    private int code;
    private String msg;

    IsOffsetEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
