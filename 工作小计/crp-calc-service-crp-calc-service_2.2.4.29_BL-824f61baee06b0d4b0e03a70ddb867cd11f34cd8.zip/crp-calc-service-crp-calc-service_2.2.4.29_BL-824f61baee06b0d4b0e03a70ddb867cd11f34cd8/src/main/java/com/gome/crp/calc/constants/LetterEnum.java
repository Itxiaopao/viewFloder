package com.gome.crp.calc.constants;

public enum LetterEnum {
    HAVE_LETTER(1, "有函"),
    NOT_HAVE_LETTER(2, "无函"),
    OFFSET(3, "冲减综贡"),
    ;

    private Integer code;
    private String msg;

    LetterEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
