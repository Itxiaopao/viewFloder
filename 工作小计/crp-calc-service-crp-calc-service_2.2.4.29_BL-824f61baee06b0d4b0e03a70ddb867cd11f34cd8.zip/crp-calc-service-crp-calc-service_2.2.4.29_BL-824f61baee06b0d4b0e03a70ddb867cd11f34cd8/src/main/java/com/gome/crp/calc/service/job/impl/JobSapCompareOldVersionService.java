package com.gome.crp.calc.service.job.impl;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.FailureReasonEnum;
import com.gome.crp.calc.constants.IsScanEnum;
import com.gome.crp.calc.constants.ReuNoEnum;
import com.gome.crp.calc.manager.JobSapCompareManager;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapAccount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class JobSapCompareOldVersionService {
    @Autowired
    private JobSapCompareManager jobSapCompareManager;

    public void processRelation(SapAccount sapAccount, List<CalcResult> calcResultList) {
        List<CalcResult> updateCalcResultList = new ArrayList<>(calcResultList.size());
        for (CalcResult calcResult : calcResultList) {
            //sap订单匹配
            boolean isMatch = isMatch(sapAccount, calcResult);
            if (isMatch) {
                updateCalcResultList.add(getUpdateCalcResult(calcResult));
            } else {
                updateCalcResultList.add(getFailureCalcResult(calcResult));
            }
        }

        //更新匹配结果
        SapAccount updateSapAccount = getUpdateSapAccount(sapAccount);
        jobSapCompareManager.doUpdateCalcResultJobStatus(updateSapAccount, updateCalcResultList);
    }

    private SapAccount getUpdateSapAccount(SapAccount sapAccount) {
        SapAccount updateSapAccount = new SapAccount();
        updateSapAccount.setId(sapAccount.getId());
        updateSapAccount.setIsScan(IsScanEnum.YES.getCode());
        return updateSapAccount;
    }

    private boolean isMatch(SapAccount sapAccount, CalcResult calcResult) {
        String contractType = calcResult.getContractType();
        //签约类型-合同
        if (BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult) && isSameContractPurchaseCode(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+协议
        if (BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult) && isSameAgreementNo(sapAccount, calcResult) && isSameContractPurchaseCode(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+有函
        if (BaseConstants.PLAN_SIGN_LETTER_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult) && isSameLetterPurchaseCode(sapAccount, calcResult) && isSameLetterNo(sapAccount, calcResult)) {
                return true;
            }
        }

        //签约类型-合同+无函资源池
        if (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(contractType)) {
            if (isSameContractNo(sapAccount, calcResult) && isSameContractPurchaseCode(sapAccount, calcResult)) {
                return true;
            }
        }

        return false;
    }

    private boolean isSameContractPurchaseCode(SapAccount sapAccount, CalcResult calcResult) {
        if (calcResult.getContractPurchaseCode() != null &&
                calcResult.getContractPurchaseCode().equals(sapAccount.getSoBuyorgCode())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_CONTRACT_PURCHASE_CODE_NO_MATCH.getMsg() + sapAccount.getSoBuyorgCode());
        return false;
    }

    private boolean isSameLetterPurchaseCode(SapAccount sapAccount, CalcResult calcResult) {
        if (calcResult.getExtraPurchaseCode() != null &&
                calcResult.getExtraPurchaseCode().equals(sapAccount.getSoBuyorgCode())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_EXTRA_PURCHASE_CODE_NO_MATCH.getMsg() + sapAccount.getSoBuyorgCode());
        return false;
    }

    private boolean isSameAgreementNo(SapAccount sapAccount, CalcResult calcResult) {
        if (calcResult.getExtraNum() != null && calcResult.getExtraNum().equals(sapAccount.getKonnr())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_AGREEMENT_NO_MATCH.getMsg() + sapAccount.getKonnr());
        return false;
    }

    private boolean isSameContractNo(SapAccount sapAccount, CalcResult calcResult) {
        if (calcResult.getContractCode() != null && sapAccount.getNewno() != null && calcResult.getContractCode().equals(sapAccount.getNewno())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_CONTRACT_NO_MATCH.getMsg() + sapAccount.getNewno());
        return false;
    }

    private boolean isSameLetterNo(SapAccount sapAccount, CalcResult calcResult) {
        if (sapAccount.getKonnr() != null && sapAccount.getKonnr().equals(calcResult.getExtraNum())) {
            return true;
        }

        calcResult.setFailureReason(FailureReasonEnum.SAP_COMPARE_LETTER_NO_MATCH.getMsg() + sapAccount.getKonnr());
        return false;
    }

    private CalcResult getUpdateCalcResult(CalcResult calcResult) {
        CalcResult updateCalcResult = new CalcResult();
        updateCalcResult.setId(calcResult.getId());
        updateCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_0);
        return updateCalcResult;
    }

    private CalcResult getFailureCalcResult(CalcResult calcResult) {
        CalcResult failureCalcResult = new CalcResult();
        failureCalcResult.setId(calcResult.getId());
        failureCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
        failureCalcResult.setFailureReason(calcResult.getFailureReason());
        return failureCalcResult;
    }

    public boolean isSapCompare(CalcResult calcResult) {
        //一期非差异化不严控
        if (BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            return false;
        }

        //合同
        if (BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(calcResult.getContractType())) {
            return true;
        }

        //合同协议
        if (BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(calcResult.getContractType())) {
            return true;
        }

        //合同有函
        if (BaseConstants.PLAN_SIGN_LETTER_TYPE.equals(calcResult.getContractType())) {
            return true;
        }

        //合同无函资源池
        if (BaseConstants.PLAN_SIGN_NO_LETTER_TYPE.equals(calcResult.getContractType())) {
            return true;
        }

        return false;
    }

    /**
     * 收入项目编码是否相同
     *
     * @param calcResult
     * @param sapAccount
     * @return
     */
    public boolean isSameReuno(CalcResult calcResult, SapAccount sapAccount) {
        if (BaseConstants.PLAN_NO_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
            CalcResult failureCalcResult = new CalcResult();
            failureCalcResult.setId(calcResult.getId());
            failureCalcResult.setJobStatus(BaseConstants.CRD_JOB_STATUS_4);
            failureCalcResult.setFailureReason("一期非差异化订单-无法处理");
            return false;
        }

        String reuno = sapAccount.getReuno();
        if (ReuNoEnum.FY0000087.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_REPLACE_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
                return true;
            }
        }

        if (ReuNoEnum.FY0000008.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_DIFFERENT_TYPE.equals(String.valueOf(calcResult.getPromotionsType()))) {
                return true;
            }
        }

        if (ReuNoEnum.FY0000084.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                    BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(calcResult.getExtraPolicyCode())) {
                return true;
            }
        }

        if (ReuNoEnum.FY0000078.getCode().equals(reuno)) {
            if (BaseConstants.PLAN_NO_RROMOTION_TYPE.equals(String.valueOf(calcResult.getPromotionsType())) &&
                    (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(calcResult.getExtraPolicyCode())
                            || BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(calcResult.getExtraPolicyCode()))) {
                return true;
            }
        }

        return false;
    }
}