package com.gome.crp.calc.dubbo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.crp.calc.facade.dubbo.task.IDubboSendAccountFcade;
import com.gome.crp.calc.service.job.IJobSendAccountService;
@Service
public class DubboSendAccountFcadeImpl implements IDubboSendAccountFcade{
	@Autowired
    private IJobSendAccountService iJobSendAccountService;
	@Override
	public void sentIncome() {
		iJobSendAccountService.sentIncome();
		
	}

}
