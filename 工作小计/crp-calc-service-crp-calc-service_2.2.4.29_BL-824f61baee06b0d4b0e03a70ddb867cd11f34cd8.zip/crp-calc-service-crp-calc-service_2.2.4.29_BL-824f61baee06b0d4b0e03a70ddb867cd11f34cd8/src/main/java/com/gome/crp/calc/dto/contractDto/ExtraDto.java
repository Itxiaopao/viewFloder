package com.gome.crp.calc.dto.contractDto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * 协议
 */
@Data
public class ExtraDto implements Serializable {
    private static final long serialVersionUID = -7629100201401184809L;

    private String agreementCode;//协议号
    private String contractCode;//合同号
    private String buyOrgCode;//采购组织编码
    private String suppCode;//供应商编码
    private String companyCode;//公司编码
    private String brandCode;//品牌编码
    private String classCode;//品类编码
    private String agreementType;//合同类型
    private String className;//品类名称
    private String brandName;//品牌名称
    private String suppName;//供应商名称
    private String buyOrgName;//采购组织名称
    private String companyName;//公司名称
    private Date effectEndDate;//有效截至时间
    private Date effectStartDate;//有效开始时间
    private BigDecimal nowRateProfit;//现综合利润率
    private BigDecimal oldRateProfit;//原综合利润率
    private BigDecimal offerPrice;//供价
    private List<PoliciesDto> policies;//政策

}
