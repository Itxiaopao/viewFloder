package com.gome.crp.calc.dto.planDto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 金额都是分
 * 比例的都要百分比
 */
@Data
public class PlanDto {
    private Long planDetailId;// 计划行项目ID
    private Long mainId; // 主计划id
    private Long planId; //计划id
    private String mainPlanDetailId; //差异非差的计划行项目id
    private Integer promotionsType; //促销费类型（0无促、1差异化、2非差异化、3带单、4总额、5拓客）
    private Long currentPrice; //计提现价
    private Integer provisionType; //计提基数（0销售金额、1实付金额）
    private BigDecimal xValue; //当前skuno对应x提成比例
    private Long awardMoney; //提奖金额（促销费*发放比例）
    private BigDecimal zValue; //当前skuno对应z提成比例
    private BigDecimal mValue; //当前skuno对应m提成比例
    private Date startTime; //计划开始时间
    private Date endTime; //计划结束时间
    private BigDecimal issueRate; //差异化、带单、延保商品集中的发放比例
    private BigDecimal additionalAward;//追加比例
    private Long singleStandardMoney;  // 非差异化公式使用的字段
    private Integer expenseOfferType; //费用承担类型（0供应商承担、1国美承担、2国美预算、3营销预算）
    private Integer isOffset; //是否冲减综贡（0是、1否）

    private String contractType; //计划签约类型(0无【费控为国美预算的传0】，1合同【无促】，2合同+协议【暂没有】，3合同+有函【差异化+带单】，4合同+无函资源池【非差异化、费用承担为供应商承担】，5无函资源池【费用承担为供应商承担】)
    private String contractCode; // 合同编码
    private String contractClass;//合同类型
    private String contractPurchaseCode; //合同所属采购组织编码？？？
    private String companyCategoryName; //公司类别名称
    private String contractSupplierCode; //合同所属供应商编码
    private String companyCategoryCode; //公司类别编码
    private Date contractStartTime; //合同开始时间date
    private Date contractEndTime; //合同结束时间date
    private String policyCode; //政策编码
    private BigDecimal policyRatio; // 政策点位
    private BigDecimal singleStandard; // 单台台返，单台标准
    private BigDecimal issuePoint;//发放点位

    private Integer extraType; //附加类型（1无、2协议、3有函、4无函）
    private String extraNum; //附加类型号（函号，协议号）
    private String extraPurchaseCode; //协议或函采购组织编码
    private String extraSupplierCode; //协议或函供应商编码
    private String extraSupplierName; //协议或函供应商名称
    private String extraCompanyCode; //协议或函公司编码
    private BigDecimal addMonthlyRebate;//新增月返
    private Long addEachRebate; // 新增台返
    private Long offerPrice; //供价

    private String supplierName; // 供应商名称
    private String categoryLevelTwo; //品类编码，需要按照长度拆分
    private String brandCode; //品牌编码
    private String brandName; //品牌名称
    private Integer isSpecialSku; //是否有特例品  （0是、1否）
    private Integer staffLevel; //员工所属机构级别// 0集团,1大区,2一级分部,3二级分部,4门店,5dc,6售后,7异常

    private Integer collectionType; //拓客类型（0自主集客、1外出拓客）
    private String collectionId; //集客活动id
    private Long promotionalMoney; //差异化和非差异化中的促销费 到分为单位
    private BigDecimal accountRate; //挂账比例（无函有值）
    private String docty; //函类型(主推函(ZB00)-差异化)，确认函(ZC09)-带单)
    private Long paymentMoney; //发放金额
    private String salesModelCode; //业务机型编码
    private String skuNo; //商品编码（skuno）
    private String categoryLevelThree; //三级品类id
    private String categoryLevelFour; //四级品类id
    private int planCategory;//sku+salemodel:0  品牌+四级:1  品牌+三级：2  品牌+二级：3
    private Integer status; //状态（0待提审，1审核中，2待生效，3已生效，4停用，5审核不通过，6已失效）
    private String extensionCoverageType; //推广范围类型 0全部，1线下，2一店一页，3线上商城 多选逗号分隔
    private Map<String ,Map<String ,List<String>>>  orgToStore; //销售组织和门店映射。Map<推广渠道 ,Map<全国/销售组织编码 ,List<门店编码>>，0和3，此对象为null

    private String comprehensiveContribution;//调整项
    private BigDecimal nowRateProfit;//综合利用率
    private BigDecimal oldRateProfit;//原综合利用率

    //2.1.1版本 陈晨提交时删除无用字段
}
