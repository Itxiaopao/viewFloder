package com.gome.crp.calc.manager.contract;

import com.gome.crp.calc.util.AddressUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.crp.calc.mybatis.mapper.CalcContractMqMapper;
import com.gome.crp.calc.mybatis.model.CalcContractMq;
import com.gome.crp.calc.util.SeqGenUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CalcContractMqManager {

	@Autowired
	private CalcContractMqMapper calcContractMqMapper;
	
    @Autowired
    private SeqGenUtil seqGenUtil;
	
	public void saveMq(String msgId, String msgBody, String sapDetailId) {
		try {
			CalcContractMq info = new CalcContractMq();	
			Long id = seqGenUtil.nextCrpContractMsgSeq();
			info.setId(id);
			info.setMsgId(msgId);
			info.setMsgBody(msgBody);
			info.setSapDetailId(sapDetailId);
            String localAddress = AddressUtil.getLocalAddress();
            if (localAddress == null) {
                localAddress = "";
            } else if (localAddress.length() > 40) {
                localAddress = localAddress.substring(0, 40);
            }
            info.setIpAddress(localAddress);
			calcContractMqMapper.insert(info);
		} catch (Exception e) {
			log.error("保存so合同MQ消息失败，msgId is {}, msgBody is {}, sapDetailId is {},exception is {}",
					msgId, msgBody, sapDetailId);
		}
	}
	
}
