package com.gome.crp.calc.service.retry.cope.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import com.gome.crp.calc.service.oms.IOMSOrderService;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class RetryCalcService implements IRetrySceneService {
    private static String service_name = RetryJobEnum.ORDERCALC.getMsg();
    @Autowired
    private IOMSOrderService iOMSOrderService;

    @Override
    public boolean cope(CalcRetry calcRetry) {
        boolean boo = this.retryOrderCalc(calcRetry);
        log.info(String.format("提成计算推送结果, 重推类型:%s, retryId:%s, 处理结果: %b", service_name, calcRetry.getId(), boo));
        return boo;
    }


    /**
     * 订单计算，失败重推
     *
     * @param calcRetry
     * @return true:处理成功 false:处理失败
     */
    private boolean retryOrderCalc(CalcRetry calcRetry) {
        boolean boo = false;
        try {
            Integer type = calcRetry.getType();
            if (type == RetryJobEnum.ORDERCALC.getCode()) {
                OrderCalcDto orderCalcDto = JSON.parseObject(calcRetry.getMsgBody(), OrderCalcDto.class);
                log.info(String.format("订单计算失败，准备重推：订单号：%s，配送单号:%s, detailId：%s", orderCalcDto.getOrderId(), orderCalcDto.getDeliveryId(), orderCalcDto.getDetailId()));
                iOMSOrderService.calcOrderProxy(orderCalcDto);
                boo = true;
            }
        } catch (Exception e) {
            log.error("重推订单异常: retryId: {}", calcRetry != null ? calcRetry.getId() : "", e);
            boo = false;
        }
        return boo;
    }


}
