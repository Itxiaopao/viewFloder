package com.gome.crp.calc.dto.formula;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class JTBasePriceDto {

    private BigDecimal price;   // 分cent
    private Integer provisionType;  // 类型 销售金额:type=0, 实付金额:type=1
    private String provisionStr;    // 类型说明
}
