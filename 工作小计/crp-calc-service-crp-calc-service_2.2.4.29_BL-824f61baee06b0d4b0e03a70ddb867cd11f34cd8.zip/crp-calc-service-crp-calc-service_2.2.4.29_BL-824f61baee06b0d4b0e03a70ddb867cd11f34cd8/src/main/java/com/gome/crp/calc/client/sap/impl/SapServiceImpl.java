package com.gome.crp.calc.client.sap.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.sap.ISapService;
import com.gome.crp.calc.constants.PathEnum;
import com.gome.crp.calc.dto.HttpClientResult;
import com.gome.crp.calc.dto.sapDto.*;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.util.DateUtils;
import com.gome.crp.calc.util.HttpClientUtils;
import com.gome.crp.calc.util.UrlUtil;
import com.gome.dragon.mds.client.dto.mstMasLoc.GomeLogicDcRequestDTO;
import com.gome.dragon.mds.client.dto.mstMasLoc.GomeLogicDcResponseDTO;
import com.gome.dragon.mds.client.mstMasLoc.GomeMstMasLocClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class SapServiceImpl implements ISapService {
    @Value("${sap.service.address}")
    private String sapServiceAddress;
    @Value("${system.id}")
    private String systemId;
    @Autowired
    private GomeMstMasLocClient gomeMstMasLocClient;

    @Override
    public ApplyBillResDto applyBill(ApplyBillReqDto reqDto) {
        if (reqDto == null || reqDto.getHeader() == null || reqDto.getHeader().getMessageId() == null) {
            throw new IllegalArgumentException("调用sap挂账接口-入参错误");
        }

        HeaderDto header = reqDto.getHeader();
        header.setInterfaceId(PathEnum.SAP_FI475.getInterfaceId());
        header.setSender(systemId);
        header.setReceiver(PathEnum.SAP_FI475.getSystemId());
        header.setDtsend(DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSS"));

        String url = UrlUtil.getUrl(sapServiceAddress, PathEnum.SAP_FI475);
        try {
            log.info("调用sap挂账接口开始url:{},messageId:{},reqDto:{}", url, reqDto.getHeader().getMessageId(), reqDto);
            HttpClientResult result = HttpClientUtils.doPostJson(url, JSON.toJSONString(reqDto));
            log.info("调用sap挂账接口完成url:{},messageId:{},reqDto:{},result:{}", url, reqDto.getHeader().getMessageId(), reqDto, result);
            if (String.valueOf(result.getCode()).startsWith("2")) {
                return JSON.parseObject(result.getContent(), ApplyBillResDto.class);
            }

            throw new BusinessException("调用sap挂账接口失败");
        } catch (Exception e) {
            log.error("调用sap挂账接口异常url:{},messageId:{},reqDto:{}", url, reqDto.getHeader().getMessageId(), reqDto, e);
            throw new BusinessException(String.format("调用sap挂账接口异常url:%s,messageId:%s,reqDto:%s", url, reqDto.getHeader().getMessageId(), JSON.toJSONString(reqDto)), e);
        }
    }

    @Override
    @Deprecated
    public QueryPurchaseCodeResDto queryPurchaseCode(QueryPurchaseCodeReqDto reqDto) {
        if (reqDto == null || reqDto.getLogicDcPlaceId() == null) {
            throw new IllegalArgumentException("调用sap获取采购组织接口-入参错误");
        }

        GomeLogicDcRequestDTO gomeLogicDcRequestDTO = new GomeLogicDcRequestDTO();
        gomeLogicDcRequestDTO.setLogicDcPlaceIds(new String[]{reqDto.getLogicDcPlaceId()});

        try {
            log.info("调用sap获取采购组织接口开始gomeLogicDcRequestDTO:{}", JSON.toJSONString(gomeLogicDcRequestDTO));
            Map<String, List<GomeLogicDcResponseDTO>> logicDcPlaceMap = gomeMstMasLocClient.getLogicDcPlace(gomeLogicDcRequestDTO);
            log.info("调用sap获取采购组织接口完成gomeLogicDcRequestDTO:{},logicDcPlaceMap:{}", JSON.toJSONString(gomeLogicDcRequestDTO), JSON.toJSONString(logicDcPlaceMap));
            if (logicDcPlaceMap != null) {
                for (Map.Entry<String, List<GomeLogicDcResponseDTO>> per : logicDcPlaceMap.entrySet()) {
                    if (reqDto.getLogicDcPlaceId() != null && reqDto.getLogicDcPlaceId().equals(per.getKey())) {
                        List<GomeLogicDcResponseDTO> value = per.getValue();
                        if (!CollectionUtils.isEmpty(value)) {
                            List<String> purchasingOrganizationIdList = new ArrayList<>();
                            QueryPurchaseCodeResDto queryPurchaseCodeResDto = new QueryPurchaseCodeResDto();
                            for (GomeLogicDcResponseDTO gomeLogicDcResponseDTO : value) {
                                String purchasingOrganizationId = gomeLogicDcResponseDTO.getPurchasingOrganizationId();
                                purchasingOrganizationIdList.add(purchasingOrganizationId);
                            }
                            queryPurchaseCodeResDto.setPurchasingOrganizationIdList(purchasingOrganizationIdList);
                            return queryPurchaseCodeResDto;
                        }
                    }
                }
            }

            throw new BusinessException("调用sap获取采购组织接口失败");
        } catch (Exception e) {
            log.error("调用sap获取采购组织接口异常reqDto:{}", reqDto, e);
            throw new BusinessException(String.format("调用sap获取采购组织接口异常reqDto:%s", JSON.toJSONString(reqDto)), e);
        }
    }
}