package com.gome.crp.calc.client.receiver;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.Receiver;

import java.util.List;

/**
 * 外呼服务
 */
public interface ITelTradingService {

    /**
     * 提成系统查询拓客电话通话记录
     * http://nvwa.gome.inc/gaim/interfaceDetail.do?#/api/detail/6b511dad-124a-401b-bb9a-5ac89ac75ee1#sidebar2
     *
     * @param orderDto
     * @return
     */
    List<Receiver> queryReceiverList(OrderCalcDto orderDto);


}
