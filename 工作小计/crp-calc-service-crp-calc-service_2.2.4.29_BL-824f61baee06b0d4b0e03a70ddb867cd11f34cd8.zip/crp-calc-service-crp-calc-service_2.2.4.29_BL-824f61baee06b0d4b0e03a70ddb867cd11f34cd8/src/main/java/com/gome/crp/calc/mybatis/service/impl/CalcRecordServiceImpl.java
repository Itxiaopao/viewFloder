package com.gome.crp.calc.mybatis.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcRecordMapper;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.service.ICalcRecordService;
import org.springframework.stereotype.Service;

@Service
public class CalcRecordServiceImpl extends ServiceImpl<CalcRecordMapper, CalcRecord> implements ICalcRecordService {
}
