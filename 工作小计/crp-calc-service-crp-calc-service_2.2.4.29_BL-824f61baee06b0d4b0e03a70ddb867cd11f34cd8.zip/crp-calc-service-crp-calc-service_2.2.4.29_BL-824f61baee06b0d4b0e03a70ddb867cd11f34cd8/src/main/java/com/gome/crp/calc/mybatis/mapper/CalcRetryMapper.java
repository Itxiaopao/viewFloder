package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcRetry;

/**
 * 失败重试表 Mapper
 * @author zhangshuang
 *
 */
public interface CalcRetryMapper extends BaseMapper<CalcRetry>{

}