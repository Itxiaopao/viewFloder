package com.gome.crp.calc.client.settlement;

import com.gome.crp.calc.dto.payDto.ApplyPayReqDto;
import com.gome.crp.calc.dto.payDto.ApplyPayResDto;

/**
 * 结算接口
 */
public interface IPayService {

    /**
     * 支付挂账或冲账
     * 挂账，冲账金额都是正数，通过gomeStatus订单状态类型区分
     *
     * @param reqDto
     * @return
     */
    ApplyPayResDto applyPay(ApplyPayReqDto reqDto);
}
