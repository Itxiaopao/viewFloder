package com.gome.crp.calc.service.job.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.manager.JobSapOfflineManager;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.service.job.IJobSapOfflineService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class JobSapOfflineServiceImpl implements IJobSapOfflineService {
    private static final int PAGE_SIZE = 500;
    @Autowired
    private IBillService iBillService;
    @Autowired
    private JobSapOfflineManager jobSapOfflineManager;
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private ICalcResultService iCalcResultService;

    @Override
    public void applyBill() {
        long startTime = System.currentTimeMillis();
        log.info("定时任务-sap线下挂账执行开始");

        //幂等校验
        String cronJobSapOfflineApplyBillLock = CacheKeyConstants.getCronJobSapOfflineApplyBillLock();
        try {
            Long value = gcacheUtil.distributedLockAtom(cronJobSapOfflineApplyBillLock, CacheKeyConstants.CACHE_KEY_CLEAN_TIMEOUT, "1");
            if (value == 1) {
                //获取数据当前处理位置
                String cronJobSapOfflineApplyBillIdIndex = CacheKeyConstants.getCronJobSapOfflineApplyBillIdIndex();
                long idIndex = selectIndexPosition(cronJobSapOfflineApplyBillIdIndex);

                //查询PAGE_SIZE条数据
                List<CalcResult> records = queryListOfSendOfflineSAP(idIndex);

                //更新数据下次处理位置
                if (CollectionUtils.isEmpty(records) || records.size() < PAGE_SIZE) {
                    gcacheUtil.putKeyValue(cronJobSapOfflineApplyBillIdIndex, "0");
                } else {
                    CalcResult detail = records.get(records.size() - 1);
                    gcacheUtil.putKeyValue(cronJobSapOfflineApplyBillIdIndex, String.valueOf(detail.getId()));
                }

                if (CollectionUtils.isNotEmpty(records)) {
                    List<SapRecord> sapRecords = iBillService.applyBill(records);
                    if (!CollectionUtils.isEmpty(sapRecords)) {
                        //sap挂账信息入库, 更新计算结果表挂账完成状态
                        List<CalcResult> updateCalcResult = getUpdateCalcResult(sapRecords);
                        jobSapOfflineManager.doInsertApplyBill(sapRecords, updateCalcResult);
                    }
                }
            }

            log.info("定时任务-sap线下挂账处理完成,耗时:{}", (System.currentTimeMillis() - startTime));
        } catch (Exception e) {
            log.error("定时任务-sap线下挂账处理异常", e);
        } finally {
            try {
                gcacheUtil.deleteKey(new String[]{cronJobSapOfflineApplyBillLock});
            } catch (Exception ex) {
                log.error("定时任务-删除sap线下挂账防重键异常cronJobSapOfflineApplyBillLock:{}", cronJobSapOfflineApplyBillLock, ex);
            }
        }

    }

    private List<CalcResult> getUpdateCalcResult(List<SapRecord> sapRecords) {
        List<CalcResult> updateCalcResultList = new ArrayList<>(sapRecords.size());
        for (SapRecord sapRecord : sapRecords) {
            CalcResult updateCalcResult = new CalcResult();
            updateCalcResult.setId(sapRecord.getCalcResultId());
            updateCalcResult.setIsOfflineApplyBill(Integer.valueOf(BaseConstants.Bill_OFFLINE_APPLY_1));
            updateCalcResultList.add(updateCalcResult);
        }

        return updateCalcResultList;
    }

    private long selectIndexPosition(String indexPositionKey) {
        long idIndex = 0L;
        String keyValue = gcacheUtil.getKeyValue(indexPositionKey);
        if (keyValue != null) {
            idIndex = Long.parseLong(keyValue);
        }
        return idIndex;
    }

    /**
     * 查询推送线下 SAP 的数据
     *
     * @return List
     */
    public List<CalcResult> queryListOfSendOfflineSAP(Long idIndex) {
        Page<CalcResult> page = new Page<>();
        page.setSize(PAGE_SIZE);
        page.setSearchCount(false);
        // 未挂账的 且 jobStatus大于SAP严控小于失效的数据 且 费用承担方是供应商且是正向单（CO/DL） 且 提奖金额>0
        QueryWrapper<CalcResult> queryWrapper = new QueryWrapper<CalcResult>()
                .gt("id", idIndex)
                .in("gome_status", new String[]{BaseConstants.ORDER_CO_STATUS, BaseConstants.ORDER_DL_STATUS})
                .gt("job_status", BaseConstants.CRD_JOB_STATUS_1_N)
                .lt("job_status", BaseConstants.CRD_JOB_STATUS_4)
                .eq("budget_status", BaseConstants.BUDGET_CHECK_SUCCESS)
                .eq("is_offline_apply_bill", BaseConstants.Bill_OFFLINE_APPLY_0)
                .isNotNull("award_amount")
                .gt("award_amount", 0)
                .orderByAsc("id");
        Page<CalcResult> page1 = iCalcResultService.page(page, queryWrapper);
        return page1.getRecords();
    }
}
