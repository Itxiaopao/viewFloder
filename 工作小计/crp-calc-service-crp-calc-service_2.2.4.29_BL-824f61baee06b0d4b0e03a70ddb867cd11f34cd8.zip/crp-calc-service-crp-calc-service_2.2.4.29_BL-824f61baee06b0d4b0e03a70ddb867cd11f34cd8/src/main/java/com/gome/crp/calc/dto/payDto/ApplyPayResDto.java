package com.gome.crp.calc.dto.payDto;

import lombok.Data;

@Data
public class ApplyPayResDto {
}
