package com.gome.crp.calc.dto.ermDto;

import lombok.Data;

import java.util.Date;
import java.util.Map;

@Data
public class LetterResDto {
    private String qrnno; //函编号
    private Date datab; //行开始生效日期（行没有取抬头）
    private Date datbi; //行有效截至日期（行没有取抬头）
    private Date aedat; //记录的创建日期（抬头）
    private Map<String, String> extra;// 扩展字段
}