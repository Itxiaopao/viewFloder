package com.gome.crp.calc.manager.plan;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 匹配计划
 */
@Slf4j
@Service
public class PlanManager {

}
