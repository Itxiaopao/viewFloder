package com.gome.crp.calc.service.order;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;

public interface IOrderStatusHandlerService {

    /**
     * 根据订单处理计算
     * 适用于 job 重试
     * 没有幂等性校验
     *
     * @param orderCalcDtos
     * @see com.gome.crp.calc.dto.orderCalcDto
     */
    void calcOrder(OrderCalcDto orderCalcDtos);


}
