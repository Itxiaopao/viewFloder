package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboGcacheFacade;
import com.gome.crp.calc.util.GcacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class DubboGcacheFacadeImpl implements IDubboGcacheFacade {
    @Autowired
    private GcacheUtil gcacheUtil;

    public void putKeyValue(String key, String value) {
        try {
            log.info("更新gcache缓存值开始key:{},value:{}", key, value);
            gcacheUtil.putKeyValue(key, value);
            log.info("更新gcache缓存值完成key:{},value:{}", key, value);
        } catch (Exception e) {
            log.error("更新gcache缓存值异常key:{},value:{}", key, value, e);
        }
    }
}
