package com.gome.crp.calc.mybatis.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gome.crp.calc.mybatis.model.CalcSceneYRecord;

public interface CalcSceneYRecordMapper extends BaseMapper<CalcSceneYRecord> {
}
