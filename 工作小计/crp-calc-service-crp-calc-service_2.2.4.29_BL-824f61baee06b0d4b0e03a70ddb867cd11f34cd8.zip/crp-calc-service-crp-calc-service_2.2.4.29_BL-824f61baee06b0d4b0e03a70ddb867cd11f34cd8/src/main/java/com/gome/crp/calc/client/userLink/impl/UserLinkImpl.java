package com.gome.crp.calc.client.userLink.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.userLink.IUserLink;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopRebateDto;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class UserLinkImpl implements IUserLink {

    @Autowired
    IUserShareBindingManager iUserShareBindingManager;
    @Value("${system.id}")
    private String systemId;

    @Override
    public String selLinkUser(String userId) {
        log.info("根据会员id查询链路关系，入参：{}", userId);
        // 此处不能捕获异常，因为要保证事务一致性
        MshopRebateDto mshopRebateDto = new MshopRebateDto();
        mshopRebateDto.setUserId(Long.valueOf(userId));
        MapResults<MshopRebateDto> mshopRebateDtoMapResults = iUserShareBindingManager.queryMshopRebateDtoByUserIdOrMid(mshopRebateDto);
        log.info("根据会员id查询链路关系，出参：{}", mshopRebateDtoMapResults != null ? JSON.toJSONString(mshopRebateDtoMapResults) : " ");

        if (mshopRebateDtoMapResults.getCode() == 0) {
            mshopRebateDto =  mshopRebateDtoMapResults.getBuessObj();
            if(null == mshopRebateDto){
                log.info("查询z的关系链userId:{},返回为空,原因可能没有关系链,或者九十天过期",userId);
                return null;
            }
            return mshopRebateDto.getUpUserId() != null ? String.valueOf(mshopRebateDto.getUpUserId()) : null;
        }

        return null;
    }
}
