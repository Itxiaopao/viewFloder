package com.gome.crp.calc.service.retry.cope.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.message.ISendMessage;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.sendMsgDto.SendMessageDto;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class RetryMessageService implements IRetrySceneService {

    @Autowired
    private ISendMessage sendMessage;
    private static String service_name = RetryJobEnum.MESSAGE.getMsg();

    @Override
    public boolean cope(CalcRetry calcRetry) {
        boolean boo = retrySendMsg(calcRetry);
        log.info(String.format("提成计算推送结果, 重推类型:%s, retryId:%s, 处理结果: %b", service_name, calcRetry.getId(), boo));
        return boo;
    }

        /**
     * 提成发送消息失败重推
     * @param calcRetry
     * @return true:处理成功 false:处理失败
     */
    private boolean retrySendMsg(CalcRetry calcRetry){
    	boolean boo = false;
    	try {
            Integer type = calcRetry.getType();
            if (type == RetryJobEnum.MESSAGE.getCode()) {
                log.info("提成发送信息失败，准备重推...");
                SendMessageDto sendMessageDto = JSON.parseObject(calcRetry.getMsgBody(), SendMessageDto.class);
                boo = sendMessage.sendSyncMsg(sendMessageDto);
            }
        } catch (Exception e) {
            log.error("提成发送信息失败，失败重推仍然失败", e);
        }
        log.info(String.format("提成发送信息失败>>END, retryId:%s", calcRetry.getId()));
        return boo;
    }

}
