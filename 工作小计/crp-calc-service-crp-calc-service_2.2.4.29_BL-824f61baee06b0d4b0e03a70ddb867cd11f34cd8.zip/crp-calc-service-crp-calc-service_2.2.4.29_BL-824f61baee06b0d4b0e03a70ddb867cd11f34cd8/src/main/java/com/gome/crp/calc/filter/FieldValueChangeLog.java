package com.gome.crp.calc.filter;

import com.gome.crp.calc.mybatis.mapper.CalcFieldChangeLogMapper;
import com.gome.crp.calc.mybatis.model.CalcFieldChangeLog;
import com.gome.crp.calc.util.CalcFieldChangeLogMapperHelp;
import com.gome.crp.calc.util.CaseUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class FieldValueChangeLog {
    //监控的表字段
    private static final Map<String, List<String>> MONITOR_TABLE_FIELDS_MAP = new HashMap<>();
    //监控的字段
    private static final List<String> MONITOR_CRP_CALC_RESULT_FIELDS_LIST = Arrays.asList("job_status", "yk_status", "limit_award_amount", "is_push_bigdata", "rebate_account_type", "is_offline_apply_bill", "surplus_amount");

    static {
        MONITOR_TABLE_FIELDS_MAP.put("crp_calc_result", MONITOR_CRP_CALC_RESULT_FIELDS_LIST);
    }

    //字段值变动记录
    public static void recordChange(String beautifySql, MybatisSqInterceptor.Property property) {
        if (property == null || CollectionUtils.isEmpty(property.getPropertyValueList())) {
            return;
        }

        //变动字段值
        Map<String, List<Object>> propertyNameValueMap = property.getPropertyNameValueMap();
        //获取记录mapper
        CalcFieldChangeLogMapper calcFieldChangeLogMapper = CalcFieldChangeLogMapperHelp.get();
        String lowerSql = beautifySql.toLowerCase();

        for (String tableName : MONITOR_TABLE_FIELDS_MAP.keySet()) {
            if (lowerSql.contains(tableName)) {
                for (String fieldName : MONITOR_TABLE_FIELDS_MAP.get(tableName)) {
                    if (lowerSql.contains(fieldName)) {
                        //修改变动
                        boolean updated = lowerSql.contains("update");
                        if (updated || lowerSql.contains("insert")) {
                            String fieldNameCamel = CaseUtils.toCamelCase(fieldName, false, new char[]{'_'});
                            String primaryId = "id";
                            if (updated) {
                                fieldNameCamel = "et." + fieldNameCamel;
                                primaryId = "et." + primaryId;
                            }

                            CalcFieldChangeLog fieldChangeLog = new CalcFieldChangeLog();
                            fieldChangeLog.setTableName(tableName);
                            Long rowId = 0L;
                            if (propertyNameValueMap.get(primaryId) != null && propertyNameValueMap.get(primaryId).get(0) != null) {
                                rowId = (Long) propertyNameValueMap.get(primaryId).get(0);
                            }
                            fieldChangeLog.setRowId(rowId);
                            fieldChangeLog.setFieldName(fieldName);
                            String fieldValue = "";
                            if (propertyNameValueMap.get(fieldNameCamel) != null && propertyNameValueMap.get(fieldNameCamel).get(0) != null) {
                                fieldValue = String.valueOf(propertyNameValueMap.get(fieldNameCamel).get(0));
                            }
                            fieldChangeLog.setFieldValue(fieldValue);
                            calcFieldChangeLogMapper.insert(fieldChangeLog);
                        }
                    }
                }
            }
        }
    }
}
