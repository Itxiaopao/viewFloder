package com.gome.crp.calc.service.oms;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.mybatis.model.OrderCalcMsg;
import com.gome.crp.order.calc.dto.OrderDto;

import java.util.List;

public interface IOMSOrderService {
    /**
     * 订单处理核心类
     *
     * @param orderDto
     * @see com.gome.crp.order.calc.dto
     */
    void handler(OrderDto orderDto);

    /**
     * 订单状态处理
     * @param orderCalcDto
     */
    void calcOrderProxy(OrderCalcDto orderCalcDto);

    /**
     * 匹配订单信息
     *
     * @param saleChannel 销售渠道
     * @param sapDetailId sap销售单号
     * @return
     */
    List<OrderCalcMsg> matchOrderInfo(String saleChannel, String sapDetailId);

    void updateById(OrderCalcMsg orderCalcMsg);

    /**
     * 消息对象转换计算对象
     * @param orderDto
     * @return
     */
    List<OrderCalcDto> transferOrderCalcDto(OrderDto orderDto);

}
