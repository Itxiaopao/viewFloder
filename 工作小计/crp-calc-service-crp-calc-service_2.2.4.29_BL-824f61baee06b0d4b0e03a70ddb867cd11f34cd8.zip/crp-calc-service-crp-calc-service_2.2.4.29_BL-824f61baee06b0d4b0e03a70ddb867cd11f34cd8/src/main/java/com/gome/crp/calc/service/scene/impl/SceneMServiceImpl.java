package com.gome.crp.calc.service.scene.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.service.problem.IProblemService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.coupon.IConsumerConponService;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.member.IVshopUserService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.scene.abstr.AbstractSceneService;
import com.gomeo2o.facade.vshop.entity.VshopInfo;

import lombok.extern.slf4j.Slf4j;

/**
 * M场景
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class SceneMServiceImpl extends AbstractSceneService {

	@Autowired
	private IConsumerConponService iConsumerConponService;
	@Autowired
	private IStaffInfoService staffInfoService;
	@Autowired
	private IVshopUserService vshopFacade;
	@Autowired
	private IProblemService problemService;
	

	@Override
	public List<ProfitDto> calc(OrderCalcDto orderDto, PlanDto planDto) {
		List<ProfitDto> list = null;
		String scenes = BaseConstants.SCENE_M;
		boolean checPlanCanCalc = this.checkPlanCanCalc(orderDto, planDto, scenes);
		if(!checPlanCanCalc) {
			return list;
		}
		List<PersonDto> personList = this.getProfitPerson(orderDto, planDto);
		if(personList != null && personList.size() > 0) {
			int size = personList.size();
			list = new ArrayList<>(size);
			List<BigDecimal> formula = super.sceneFormula(orderDto, planDto, size, scenes);
			int i = 0;
			for (PersonDto personDto : personList) {
				ProfitDto profit = new ProfitDto();
				profit.setPersonDto(personDto);
				profit.setScenes(scenes);
				if(formula != null) {
					profit.setAwardAmount(formula.get(i));
				}
				i++;
				list.add(profit);
			}
			this.addRewardCommit(orderDto, planDto, list, scenes);
		} else {
			log.info(String.format("[Warn]M场景获利人:null, orderId:%s, planId:%d", orderDto.getOrderId(), planDto.getPlanId()));
			// 入问题小工具
			addProblem(orderDto, planDto, "M场景获利人:null", ProblemEnum.CODE_124);
		}
		log.info(String.format("M场景获利人最终提奖金额分配[End], orderId:%s, planId:%d, 列表:%s",
				orderDto.getOrderId(), planDto.getPlanId(), JSONObject.toJSONString(list)));
		return list;
	}
	
	/**
	 * 获得 M 的获利人
	 * 商品分享人 > 券的分享人
	 * @param orderDto
	 * @param planDto
	 * @return
	 */
	@Override
	public List<PersonDto> getProfitPerson(OrderCalcDto orderDto, PlanDto planDto) {
		List<PersonDto> personDtos = null;
		String userId_share = "";
		String orderId = orderDto.getOrderId();
		Integer ProfitBehaviorCode = null;
		if (StringUtils.isNotEmpty(orderDto.getShareUserId())) {
			ProfitBehaviorCode = ProfitBehaviorEnum.SERVICE_SHARE_PRODUCTS.getCode();
			userId_share = orderDto.getShareUserId();
			log.info(String.format("M场景获利人查询[分享人ID], orderId:%s, userId:%s", orderId, userId_share));
		}
		List<OrderCalcCouponDto> couponsDtoList = orderDto.getCouponsDtoList();
		if (StringUtils.isEmpty(userId_share) && CollectionUtils.isNotEmpty(couponsDtoList)) {
			ProfitBehaviorCode = ProfitBehaviorEnum.SERVICE_SHARE_VOUCHER.getCode();
			userId_share = iConsumerConponService.queryCouponGiveInfo(couponsDtoList, orderDto.getUserId());
			log.info(String.format("M场景获利人查询[券分享人ID], orderId:%s, userId:%s", orderId, userId_share));
		}
		if (StringUtils.isNotEmpty(userId_share)) {
			// 判断是否是美店主
			VshopInfo vshopUser = vshopFacade.getVshopUserByUserId(userId_share);
			if(vshopUser != null) {
				personDtos = new ArrayList<>();
				EmployeeInfoDto empl = staffInfoService.getEmployeeDtoByUserId(userId_share);
				log.info(String.format("M场景获利人查询[员工], orderId:%s, 员工信息:%s", orderId, JSONObject.toJSONString(empl)));
				PersonDto personDto = null;
				if(empl != null) {
					personDto = this.copyProperies(empl, orderDto.getShopNo(), orderDto.getSupplier(), userId_share, null,ProfitBehaviorCode);
					personDtos.add(personDto);
				}else {
					personDto = new PersonDto();
					personDto.setUserId(userId_share);
					personDto.setProfitBehaviorCode(ProfitBehaviorCode);
					personDtos.add(personDto);
				}
			}else {
				log.info(String.format("M场景获利人查询[美店主-失败], orderId:%s, 用户id:%s, 美店主信息:null", orderId, userId_share));
			}
		}else {
			log.info(String.format("M场景获利人查询[失败], orderId:%s, 查询券履历信息 null", orderId));
		}
		log.info(String.format("M场景获利人查询[END], orderId:%s, 获利人列表:%s", orderId, JSONObject.toJSONString(personDtos)));
		return personDtos;
	}

	@Override
	public String getScene() {
		return BaseConstants.SCENE_M;
	}


}
