package com.gome.crp.calc.dto.calcDto;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import lombok.Data;

import java.util.List;

@Data
public class CalcResultDto {

    private OrderCalcDto orderCalcDto;
    private PlanDto planDto;
    private List<ProfitDto> profitDtos;

}
