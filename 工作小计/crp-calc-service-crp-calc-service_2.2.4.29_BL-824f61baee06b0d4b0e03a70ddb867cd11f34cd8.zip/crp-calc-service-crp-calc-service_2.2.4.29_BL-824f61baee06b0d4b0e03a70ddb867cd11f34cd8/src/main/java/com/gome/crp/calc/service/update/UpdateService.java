package com.gome.crp.calc.service.update;

import com.gome.crp.calc.mybatis.model.CalcResult;

public interface UpdateService {
    void updateParamById(CalcResult calcResult);
}
