package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.IDubboProblemFacade;
import com.gome.crp.calc.service.plan.IPlanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DubboProblemFacadeImpl implements IDubboProblemFacade {

    @Autowired
    IPlanService planService;

    @Override
    public List<String> skuIsMatchPlan(Map<String, String> skuMap) {
        return planService.skuIsMatchPlan(skuMap);
    }
}
