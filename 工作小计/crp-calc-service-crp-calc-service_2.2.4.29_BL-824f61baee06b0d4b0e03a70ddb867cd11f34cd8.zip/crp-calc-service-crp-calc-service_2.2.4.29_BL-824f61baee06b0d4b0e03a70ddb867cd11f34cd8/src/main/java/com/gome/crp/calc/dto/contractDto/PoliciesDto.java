package com.gome.crp.calc.dto.contractDto;

import lombok.Data;

import java.io.Serializable;

/**
 * 政策
 */
@Data
public class PoliciesDto implements Serializable {
    private static final long serialVersionUID = 5405780003168277728L;

    private String policyCode;//政策编码
    private String policyValue;//政策值
    private String policyClassCode;//政策的品类

}
