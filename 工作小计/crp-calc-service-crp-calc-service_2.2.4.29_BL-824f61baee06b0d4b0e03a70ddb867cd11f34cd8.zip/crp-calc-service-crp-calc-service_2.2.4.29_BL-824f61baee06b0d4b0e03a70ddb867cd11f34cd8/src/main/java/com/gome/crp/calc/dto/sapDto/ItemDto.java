package com.gome.crp.calc.dto.sapDto;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class ItemDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private String bstkd;//销售单号
    private String qxbs;//取消标识
    private String posrq;//销售日期
    private String matnr;//商品
    private BigDecimal fkimg;//销售数据量
    private BigDecimal dmbtr;//销售价格
    private BigDecimal dmbtr1;//发放金额
    private String zwerks;//实际DC仓
    private String lifnr;//供应商代码
    private String level4;//品类
    private String prdha;//品牌
    private String conno;//合同号
    private String konnr;//协议号
    private String flag1;//计划类型
    private String tcjh;//计划号
    private String pernr;//营业员代码
    private String cxflx;//促销费类型
    private String cxflxms;//促销费类型描述
}
