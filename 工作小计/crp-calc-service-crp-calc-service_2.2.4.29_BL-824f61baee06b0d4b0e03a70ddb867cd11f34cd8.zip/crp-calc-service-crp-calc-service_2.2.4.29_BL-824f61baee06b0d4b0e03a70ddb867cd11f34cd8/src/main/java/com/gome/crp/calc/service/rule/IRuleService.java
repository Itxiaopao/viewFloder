package com.gome.crp.calc.service.rule;

import com.gome.crp.calc.dto.profitDto.ProfitDto;

import java.util.List;

/**
 * 规则解析模块
 * 1.规则解析
 * 2.公式解析
 * 3.场景（获利人）互斥叠加解析
 */
public interface IRuleService {

    /**
     * 获利人叠加规则的解析
     * @param profitDto
     */
    List<ProfitDto> filterProfiter(List<ProfitDto> profitDto);

}
