package com.gome.crp.calc.client.receiver.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.client.receiver.ITelTradingService;
import com.gome.crp.calc.constants.ProfitBehaviorEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.profitDto.QueryReceiverReqDto;
import com.gome.crp.calc.dto.profitDto.Receiver;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.util.DateUtils;
import com.gome.framework.base.ResultDTO;
import com.gome.mkt.tel.trading.client.CallLogClient;
import com.gome.mkt.tel.trading.client.dto.CallLogPercentageDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * 外呼服务
 */
@Slf4j
@Service
public class TelTradingServiceImpl implements ITelTradingService {
    @Value("${system.id}")
    private String systemId;
    @Autowired
    private CallLogClient callLogClient;

    /**
     * 提成系统查询拓客电话通话记录
     * http://nvwa.gome.inc/gaim/interfaceDetail.do?#/api/detail/6b511dad-124a-401b-bb9a-5ac89ac75ee1#sidebar2
     * !!!!!!txid和systeimId的处理
     *
     * @param orderDto
     * @return
     */
    public List<Receiver> queryReceiverList(OrderCalcDto orderDto) {
        List<Receiver> receiverList = new ArrayList<>();
        QueryReceiverReqDto reqDto = new QueryReceiverReqDto();
        //入参校验
        if (orderDto == null || orderDto.getUserId() == null || orderDto.getShopNo() == null || orderDto.getPayDate() == null) {
            log.info("通过拓客通话记录查询承接人,入参错误,,orderDto:{}", JSON.toJSONString(orderDto));
            return receiverList;
        }
        try {
            reqDto.setTxId(UUID.randomUUID().toString());
            reqDto.setInvokeFrom(systemId);
            reqDto.setStoreId(orderDto.getShopNo());
            reqDto.setUserId(orderDto.getUserId());
            reqDto.setStringOrderTime(DateUtils.formatDateTime(orderDto.getPayDate()));
            //接口调用
            log.info("通过拓客通话记录查询承接人,接口开始,userId:{},orderDto:{},reqDto:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto);
            ResultDTO<List<CallLogPercentageDTO>> resultDTO = callLogClient.queryCallLogPercentage(
                    reqDto.getTxId(), reqDto.getInvokeFrom(), reqDto.getStoreId(), reqDto.getStringOrderTime(), reqDto.getUserId());
            log.info("通过拓客通话记录查询承接人,接口完成,userId:{},orderDto:{},reqDto:{},result:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto, JSON.toJSONString(resultDTO));
            //结果解析
            if (resultDTO == null || !resultDTO.isSuccess()) {
                log.error("通过拓客通话记录查询承接人,接口失败,userId:{},orderDto:{},reqDto:{},result:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto, JSON.toJSONString(resultDTO));
                return receiverList;
            }
            if (resultDTO.getData() != null) {
                List<CallLogPercentageDTO> data = resultDTO.getData();
                for (CallLogPercentageDTO dto : data) {
                    Receiver receiver = new Receiver();
                    receiver.setStaffId(dto.getStaffId());
                    receiver.setReceiverTime(DateUtils.parseDate(dto.getStartTime()).getTime());
                    receiver.setProfitBehaviorCode(ProfitBehaviorEnum.SERVICE_OUTBOUND.getCode());
                    receiverList.add(receiver);
                }
            }
        } catch (Exception e) {
            log.error("通过拓客通话记录查询承接人,接口异常,userId:{},orderDto:{},reqDto:{},e:{}", orderDto.getUserId(), JSON.toJSONString(orderDto), reqDto, e);
            throw new BusinessException(String.format("通过拓客通话记录查询承接人,接口异常,userId:%s,orderDto:%s", orderDto.getUserId(), JSON.toJSONString(orderDto)), e);
        }
        return receiverList;
    }


}
