package com.gome.crp.calc.mybatis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

/**
 * mq消息流水表 Model
 * @author zhangshuang
 *
 */
@Getter
@Setter
@ToString
public class OrderRecord {

	private Long id; //id
	private String orderId; //订单号
	private String msgId; //msgId
	private String msgBody; //消息体
	private Date createTime; //createTime
	private Date updateTime; //updateTime
	private Integer isDelete; //0未删除，1已删除
}