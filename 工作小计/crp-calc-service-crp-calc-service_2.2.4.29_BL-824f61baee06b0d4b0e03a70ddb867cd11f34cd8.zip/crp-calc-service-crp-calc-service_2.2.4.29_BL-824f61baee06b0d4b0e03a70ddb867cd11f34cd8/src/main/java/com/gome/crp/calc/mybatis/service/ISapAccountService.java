package com.gome.crp.calc.mybatis.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gome.crp.calc.mybatis.model.SapAccount;

public interface ISapAccountService extends IService<SapAccount> {
}
