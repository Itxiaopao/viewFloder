package com.gome.crp.calc.service.scene.abstr;


import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.employee.EmployeeInfoDto;
import com.gome.crp.calc.dto.employee.GomeEmployeePostInformation;
import com.gome.crp.calc.dto.employee.ResponseGroupVendorDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * 提取 abs 抽象类中共有方法
 */
@Slf4j
@Service
public class AbsUtils {

    @Autowired
    private ICalcRewardsService calcRewardsService;
    @Autowired
    private IProblemService problemService;

    /**
     * 处理奖励
     *
     * @param awardPrice 奖励金额
     * @param count      分几份
     * @return
     */
    public List<BigDecimal> getPerAwardPrice(Long awardPrice, int count) {
        ArrayList<BigDecimal> priceList = null;
        BigDecimal bigDecimalOfAward = new BigDecimal(awardPrice);
        BigDecimal orderCount = new BigDecimal(count);
        BigDecimal avgPrice = bigDecimalOfAward.divide(orderCount, 0, RoundingMode.DOWN);
        BigDecimal firstPrice = null;
        if (orderCount.multiply(avgPrice).equals(bigDecimalOfAward)) {
            firstPrice = avgPrice;
        } else {
            firstPrice = bigDecimalOfAward.subtract(avgPrice.multiply(new BigDecimal(count - 1)));
        }
        // 计算之后的
        priceList = new ArrayList<BigDecimal>(orderCount.intValue());
        for (int i = 0; i < orderCount.intValue(); i++) {
            if (i == 0) {
                priceList.add(firstPrice);
            } else {
                priceList.add(avgPrice);
            }
        }
        return priceList;
    }

    /**
     * copy properties by source calcResult and inside log journal
     * 异步 推送问题小工具
     *
     * @param orderCalcDto
     * @param problemMSG
     * @param planDto
     * @param problemEnum
     * @return
     */
    @Async
    public void addProblem(OrderCalcDto orderCalcDto, PlanDto planDto, String problemMSG, ProblemEnum problemEnum) {
        String str = "添加问题小工具, 数据参数orderId:%s, planId:%d, 问题内容: %s, 类型:%s";
        log.info(String.format(str, orderCalcDto.getOrderId(), planDto.getPlanId(), problemMSG, problemEnum.getMsg()));
        ProblemDto pd = new ProblemDto(orderCalcDto.getOrderId(), orderCalcDto.getChannel(), orderCalcDto.getSkuNo(),
                orderCalcDto.getDetailId());
        pd.setDescription(problemMSG);
        pd.setPlanId(planDto.getPlanId() + "");
        problemService.addData(pd, problemEnum);
    }


    /**
     * 拷贝属性
     *
     * @param empl
     * @param shopNo
     * @param orderSupplier
     * @param userId
     * @param isMain
     * @return
     */
    public PersonDto copyProperies(EmployeeInfoDto empl, String shopNo, String orderSupplier, String userId, Integer isMain, Integer profitBehaviorCode) {
        PersonDto p = new PersonDto();
        p.setUserId(userId);
        p.setIsMain(isMain);
        String emplClass = empl.getBaseInfo().getEmplClass();
        p.setStaffCode(empl.getBaseInfo().getEmployeeId());
        p.setStaffClass(empl.getBaseInfo().getEmplClass());
        p.setStaffLevel(BaseConstants.STAFF_LEVEL_4);
        p.setStoreCode(shopNo);
        p.setOrderSupplier(orderSupplier);
        //获利行为
        p.setProfitBehaviorCode(profitBehaviorCode);
        // 判断加盟商
        p.setNewRetailStatus(0);
        if (BaseConstants.EMPL_CLASS_I.equals(emplClass) || BaseConstants.EMPL_CLASS_J.equals(emplClass)) {
            p.setNewRetailStatus(1);
        }
        // 赋值一二级品牌
        if(StringUtils.isNotBlank(shopNo)) {
            List<GomeEmployeePostInformation> gepil = empl.getGomeEmployeePostInformationList();
            if (gepil != null && gepil.size() > 0) {
                for (GomeEmployeePostInformation gepi : gepil) {
                    String storeId = gepi.getStoreId();
                    if(StringUtils.isBlank(storeId)) {
                        continue;
                    }
                    if(shopNo.equals(storeId)) {
                        p.setBranchCodeOne(gepi.getBranchId1());
                        p.setBranchCodeTwo(gepi.getBranchId2());
                        break;
                    }
                }
            }
        }
        // emplClass D， J	截取供应商编码
        if (BaseConstants.EMPL_CLASS_J.equals(emplClass) || BaseConstants.EMPL_CLASS_D.equals(emplClass)) {
            List<ResponseGroupVendorDto> gomeVendorList = empl.getGomeVendorList();
            if(gomeVendorList != null && gomeVendorList.size() > 0) {
                StringBuffer sb = new StringBuffer();
                gomeVendorList.forEach(rgvd -> {
                    String vendorCode = rgvd.getVendorCode();
                    if(StringUtils.isNotBlank(vendorCode)) {
                        sb.append(vendorCode).append(",");	// 拼接供应商编码 [,]隔开
                    }
                });
                // 拼接供应商编码
                p.setStaffSuppliers(sb.toString());
            }
        }
        return p;
    }

    // 保存计算公式履历
    public void addRewardCommit(OrderCalcDto orderDto, PlanDto planDto, List<ProfitDto> profitList, String scene, String from){
        log.info(String.format("提奖计算履历数据保存: from:%s, orderId:%s, planId:%s, scene:%s, 提奖人:%s",
                from, orderDto.getOrderId(), planDto.getPlanId(), scene, JSONObject.toJSONString(profitList)));
        calcRewardsService.addCommit(orderDto, planDto, profitList, scene, from);
    }

}
