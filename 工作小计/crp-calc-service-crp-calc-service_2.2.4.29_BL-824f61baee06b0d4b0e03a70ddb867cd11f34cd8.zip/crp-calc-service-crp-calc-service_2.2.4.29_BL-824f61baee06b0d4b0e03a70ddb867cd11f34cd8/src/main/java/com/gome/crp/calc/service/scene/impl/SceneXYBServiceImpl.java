package com.gome.crp.calc.service.scene.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.coupon.IConsumerConponService;
import com.gome.crp.calc.client.employee.IStaffInfoService;
import com.gome.crp.calc.client.receiver.ILarkService;
import com.gome.crp.calc.client.receiver.IStoreSubscribeService;
import com.gome.crp.calc.client.receiver.ITelTradingService;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.profitDto.PersonDto;
import com.gome.crp.calc.dto.profitDto.ProfitDto;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.service.scene.abstr.AbsUtils;
import com.gome.crp.calc.service.scene.abstr.AbstractYBSceneService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * 场景 延保
 * 1. 目前只计算x
 * 
 * @author libinbin9
 *
 */
@Slf4j
@Service
public class SceneXYBServiceImpl extends AbstractYBSceneService {

	public String key = "1";

	@Autowired
	private IStaffInfoService staffInfoService;
	@Autowired
	private IConsumerConponService consumerConponService;
	@Autowired
	private IProblemService problemService;
	@Autowired
	private IStoreSubscribeService storeSubscribeService;
	@Autowired
	private ITelTradingService telTradingService;
	@Autowired
	private ILarkService larkService;
	@Autowired
	private AbsUtils absUtils;
	@Autowired
	private SceneXServiceImpl sceneXServiceImpl;

	@Override
	public List<ProfitDto> calc(OrderCalcDto orderDto, PlanDto planDto) {
		List<ProfitDto> list = null;
		String scene = BaseConstants.SCENE_X;
		boolean checPlanCanCalc = this.checkPlanCanCalc(orderDto, planDto, scene);
		if(!checPlanCanCalc) {
			return list;
		}
		List<PersonDto> personList = this.getProfitPerson(orderDto, planDto);
		if (personList != null && personList.size() > 0) {
			int size = personList.size();
			list = new ArrayList<>(size);
			List<BigDecimal> formula = this.sceneFormula(orderDto, planDto, size, scene);
			int i = 0;
			for (PersonDto personDto : personList) {
				ProfitDto profit = new ProfitDto();
				profit.setPersonDto(personDto);
				profit.setScenes(scene);
				profit.setAwardAmount(formula.get(i));
				i++;
				list.add(profit);
			}
			this.addRewardCommit(orderDto, planDto, list, scene);
		} else {
			log.info(String.format("X场景[延保][Warn]-获利人:null, orderId:%s, planId:%d", orderDto.getOrderId(), planDto.getPlanId()));
			// 入问题小工具
			absUtils.addProblem(orderDto, planDto, "X场景[延保]-获利人:null", ProblemEnum.CODE_124);
		}
		log.info(String.format("X场景[延保]-按计划获得提奖获利人[结果], orderId:%s, planId:%s, 计算结果:%s", orderDto.getOrderId(),
				planDto.getPlanId(), JSONObject.toJSONString(list)));
		return list;
	}

	@Override
	public List<PersonDto> getProfitPerson(OrderCalcDto orderDto, PlanDto planDto) {
		List<PersonDto> pl = sceneXServiceImpl.getProfitPerson(orderDto, planDto);
		return pl;
	}

	@Override
	public String getScene() {
		return BaseConstants.SCENE_X;
	}


}
