package com.gome.crp.calc.service.scene.formula.impl;

import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.dto.formula.JTBasePriceDto;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.mybatis.model.CalcResultReward;
import com.gome.crp.calc.service.rewardRecord.ICalcRewardsService;
import com.gome.crp.calc.service.scene.formula.IFormulaWC;
import com.gome.crp.calc.service.scene.formula.utils.SceneUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.math.RoundingMode;


@Slf4j
@Service
public class FormulaWC implements IFormulaWC {

    @Autowired
    private SceneUtils sceneUtils;
    @Autowired
    private ICalcRewardsService calcRewardsService;

    //百分比数据除数
    private static BigDecimal percent_rate_normal = BigDecimal.valueOf(0.01);
    private static BigDecimal percent_rate_cent = BigDecimal.valueOf(100);
    private static BigDecimal percent_rate_cent_1 = BigDecimal.valueOf(1.0);

    @Override
    public BigDecimal calc(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        return this.formulaWC(orderCalcDto, planDto, scene);
    }

    // 无促
    // 1. 费用承担方: 厂家承担
    // 2. 签约类型: 新合同/合同+采购协议
    // 3. 业务机型: 01标准机（合同）/11一步到位机（采购协议）
    // 4. 一步到位机的库存类型是带安的，不给提奖
    // 5. 计提现价
    // 6. 政策编码:
    // 6.1 Z195/Z605 -> 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例
    // 6.2 Z197 -> 提奖金额=单台标准(台返)×销售数量×发放比例×XYZM比例
    // @since:2020-8-5; by:libinbin9;
    private BigDecimal formulaWC_2 (OrderCalcDto orderCalcDto, PlanDto planDto, String scene){
        String orderId = orderCalcDto.getOrderId();
        Long planId = planDto.getPlanId();
        String log_pre = String.format("订单: %s, 计划: %s, 场景: %s ", orderId, planId, scene);
        // cent分
        BigDecimal ret = BigDecimal.valueOf(0.0);

        // 费用承担方: 厂家承担
        if(!BaseConstants.PLAN_EXPENSE_OFFER_ZERO_TYPE.equals(planDto.getExpenseOfferType().toString())){
            log.info("无促计算逻辑-非-厂家承担[不计算], " + log_pre);
            return ret;
        }
        // 签约类型: 新合同/合同+采购协议
        if(!(BaseConstants.PLAN_SIGN_CONTRACT_TYPE.equals(planDto.getContractPurchaseCode())
                || BaseConstants.PLAN_SIGN_PROTOCOL_TYPE.equals(planDto.getExtraPurchaseCode())) ) {
            // ContractPurchaseCode-新合同
            // ExtraPurchaseCode-合同+采购协议
            log.info("无促计算逻辑-非-新合同/合同+采购协议[不计算], " + log_pre);
            return ret;
        }
        // 业务机型: 01标准机（合同）/11一步到位机（采购协议）
        if(!(BaseConstants.PROBLEM_SALE_MODEL_11.equals(orderCalcDto.getSalesModel())
                || BaseConstants.PROBLEM_SALE_MODEL_01.equals(orderCalcDto.getSalesModel()))){
            log.info("无促计算逻辑-非-01标准机（合同）/11一步到位机（采购协议）[不计算], " + log_pre);
            return ret;
        }
        //一步到位机的库存类型是带安的，不给提奖
        if (BaseConstants.PROBLEM_SALE_MODEL_11.equals(orderCalcDto.getSalesModel())
                && BaseConstants.ORDER_CALC_STOCK_TYPE_G3PP_D.equals(orderCalcDto.getStockType())) {
            log.info("无促计算逻辑-一步到位机的库存类型是带安[不计算], " + log_pre);
            return ret;
        }

        /*
         * "政策点位：合同/协议（policyValue，Z605/Z195）--policyRatio
         * 发放比例：配置端--issueRate
         * XYZM比例：配置端
         * 单台标准：合同/协议（policyValue,Z197）--singleStandard（固额）"
         */
        String policyCode = planDto.getPolicyCode();
        Integer buyNum = orderCalcDto.getBuyNum();
        BigDecimal issueRate = planDto.getIssueRate();
        BigDecimal sceneValue = sceneUtils.getSceneValue(planDto, scene);
        BigDecimal policyValue = planDto.getPolicyRatio();
        BigDecimal singleStandard = planDto.getSingleStandard();

        // Z195/Z605 -> 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例
        if (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(policyCode)
                || BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(policyCode)){
            Assert.notNull(policyValue, log_pre + "无促计算-政策点位: null");
            // 1. z195/z605 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例
            JTBasePriceDto jtBasesDto = sceneUtils.getJTBases(orderCalcDto, planDto);
            BigDecimal jtBases = jtBasesDto.getPrice();
            String jtProvisionStr = jtBasesDto.getProvisionStr(); // 类型
            // 5. 计提现价
            if (jtBases == null){
                return ret;
            }
            ret = jtBases
                    .multiply(BigDecimal.valueOf(buyNum))
                    .multiply(policyValue.multiply(percent_rate_normal))
                    .multiply(issueRate.multiply(percent_rate_normal))
                    .multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
            String logs = String.format("无促- z195/z605 提奖金额[ %s ]=商品[%s]金额[ %s x 0.01 ]×销售数量[ %s ]×政策点位[ %s x 0.01 ]×发放比例[ %s x 0.01]×(%s)比例[ %s x 0.01 ], target:%s"
                    ,ret.toString(), jtProvisionStr, jtBases, buyNum, policyValue, issueRate, scene, sceneValue, log_pre);
            log.info(logs);// log
            return ret;
        }
        // Z197 -> 提奖金额=单台标准(台返)×销售数量×发放比例×XYZM比例
        if(BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(policyCode)){
            // 2.z197 提奖金额=单台标准×销售数量×发放比例×XYZM比例
            Assert.notNull(singleStandard, log_pre + "无促计算-单台标准: null");
            ret = singleStandard
                    .multiply(BigDecimal.valueOf(buyNum))
                    .multiply(issueRate.multiply(percent_rate_normal))
                    .multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
            String logs = String.format("无促- z197 提奖金额[ %s ]=单台标准[ %s x 0.01 ]×销售数量[ %s ]×发放比例[ %s x 0.01 ]×(%s)比例[ %s x 0.01 ], target:%s"
                    , ret.toString(), singleStandard, buyNum, issueRate, scene, sceneValue, log_pre );
            log.info(logs); // log
            return ret;
        }
        return ret;
    }

    // 无促 (促销费类型 + 签约类型)
    @Deprecated
    private BigDecimal formulaWC(OrderCalcDto orderCalcDto, PlanDto planDto, String scene) {
        BigDecimal ret = BigDecimal.valueOf(0.0);

        String orderId = orderCalcDto.getOrderId();
        Long planId = planDto.getPlanId();
        String log_pre = String.format("订单: %s, 计划: %s, 场景: %s ", orderId, planId, scene);

        //一步到位机的库存类型是带安的，不给提奖
        if (BaseConstants.PROBLEM_SALE_MODEL_11.equals(orderCalcDto.getSalesModel())
                && BaseConstants.ORDER_CALC_STOCK_TYPE_G3PP_D.equals(orderCalcDto.getStockType())) {
            log.info("无促计算逻辑-一步到位机的库存类型是带安[不计算], " + log_pre);
            return ret;
        }

        String policyCode = planDto.getPolicyCode();
        Integer buyNum = orderCalcDto.getBuyNum();
        BigDecimal issueRate = planDto.getIssueRate();
        BigDecimal sceneValue = sceneUtils.getSceneValue(planDto, scene);
        BigDecimal policyValue = planDto.getPolicyRatio();
        BigDecimal singleStandard = planDto.getSingleStandard();

        // 政策编码
        if (BaseConstants.PLAN_EXTRA_POLICY_CODE_195.equals(policyCode)
                || BaseConstants.PLAN_EXTRA_POLICY_CODE_605.equals(policyCode)){
            Assert.notNull(policyValue, log_pre + "无促计算-政策点位: null");
            // 1. z195/z605 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例
            JTBasePriceDto jtBasesDto = sceneUtils.getJTBases(orderCalcDto, planDto);
            BigDecimal jtBases = jtBasesDto.getPrice();
            String jtProvisionStr = jtBasesDto.getProvisionStr(); // 类型
            if (jtBases == null){
                return ret;
            }
            ret = jtBases.multiply(BigDecimal.valueOf(buyNum))
                    .multiply(policyValue.multiply(percent_rate_normal))
                    .multiply(issueRate.multiply(percent_rate_normal))
                    .multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
            String logs = String.format("无促- z195/z605 提奖金额[ %s ]=商品[%s]金额[ %s ]×销售数量[ %s ]×政策点位[ %s x 0.01 ]×发放比例[ %s x 0.01]×(%s)比例[ %s x 0.01 ], target:%s"
                    ,ret.toString(), jtProvisionStr, jtBases, buyNum, policyValue, issueRate, scene, sceneValue, log_pre);
            log.info(logs);
//            // --------------------------------save reward----------------------------------
//            CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//            crr.setJtBases(jtBases.toString());
//            crr.setJtBasesType(jtBasesDto.getProvisionType());
//            crr.setReward(ret.toString());
//            crr.setCalcFormulaLog(logs);
//            crr.setCalcFormulaStr("无促-z195/z605 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例");
//            savePreRewards(crr);
//            // --------------------------------save reward----------------------------------
            return ret;
        }
        if(BaseConstants.PLAN_EXTRA_POLICY_CODE_197.equals(policyCode)){
            // 2.z197 提奖金额=单台标准×销售数量×发放比例×XYZM比例
            // singleStandardMoney * buyNum * issueRate * sceneValue
            // 无促单台标准 singleStandard
            Assert.notNull(singleStandard, log_pre + "无促计算-单台标准: null");
            ret = singleStandard.multiply(BigDecimal.valueOf(buyNum))
                    .multiply(issueRate.multiply(percent_rate_normal))
                    .multiply(sceneValue.multiply(percent_rate_normal)).setScale(4, RoundingMode.DOWN);
            String logs = String.format("无促- z197 提奖金额[ %s 分 ]=单台标准[ %s ]×销售数量[ %s ]×发放比例[ %s x 0.01 ]×(%s)比例[ %s x 0.01 ], target:%s"
                    , ret.toString(), singleStandard, buyNum, issueRate, scene, sceneValue, log_pre );
            log.info(logs);
//            // --------------------------------save reward----------------------------------
//            CalcResultReward crr = calcRewardsService.getPreObj(orderCalcDto, planDto, scene);
//            crr.setCalcFormulaLog(logs);
//            crr.setReward(ret.toString());
//            crr.setCalcFormulaStr("无促- z197 提奖金额=商品销售金额（或实付金额）×销售数量×政策点位×发放比例×XYZM比例");
//            savePreRewards(crr);
//            // --------------------------------save reward----------------------------------
            return ret;
        }

        return ret;
    }


}
