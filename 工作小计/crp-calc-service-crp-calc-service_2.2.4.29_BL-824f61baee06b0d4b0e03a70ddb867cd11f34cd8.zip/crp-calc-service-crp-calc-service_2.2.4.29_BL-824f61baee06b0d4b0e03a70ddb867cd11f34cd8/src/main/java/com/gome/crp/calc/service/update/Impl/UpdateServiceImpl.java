package com.gome.crp.calc.service.update.Impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.manager.CalcResultSingleManager;
import com.gome.crp.calc.service.update.UpdateService;
import com.gome.crp.calc.mybatis.model.CalcResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Slf4j
@Service
public class UpdateServiceImpl implements UpdateService {
    @Autowired
    CalcResultSingleManager calcResultSingleManager;
    @Override
    public void updateParamById(CalcResult calcResult) {
        log.info("更新数据:{},时间:{}", JSONObject.toJSONString(calcResult),new Date());
        calcResultSingleManager.updateByParam(calcResult);
    }
}
