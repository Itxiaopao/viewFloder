package com.gome.crp.calc.dto.sendMsgDto;

import java.util.List;

import lombok.Data;

@Data
public class SendMessageDto {

	// 主题 仅发送邮件时有值
	private String topic;
	// 发送内容
	private String content;
	// 邮箱列表 仅发送邮件时有值
	private List<String> userList;
	// 发送类型，为空默认为邮箱，1:邮箱; 2:微信报警(卡片形式); 3:微信报警(文本形式);
	private Integer sendType;
	//重复发送缓存锁业务类型
	private String businessType;
	
	public SendMessageDto(Integer sendType, String content, 
			String businessType) {
		this.sendType = sendType;
		if(sendType == null) {
			this.sendType = 1;
		}
		this.content = content;
		this.businessType = businessType;
	}
}
