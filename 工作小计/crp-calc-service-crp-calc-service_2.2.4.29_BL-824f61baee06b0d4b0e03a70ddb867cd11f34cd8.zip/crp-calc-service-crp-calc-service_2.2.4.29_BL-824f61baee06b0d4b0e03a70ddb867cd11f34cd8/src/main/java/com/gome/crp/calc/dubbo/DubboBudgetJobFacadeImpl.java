package com.gome.crp.calc.dubbo;

import com.gome.crp.calc.facade.dubbo.task.IDubboBudgetJobFacade;
import com.gome.crp.calc.service.job.IJobBudgetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DubboBudgetJobFacadeImpl implements IDubboBudgetJobFacade {
    @Autowired
    private IJobBudgetService iJobBudgetService;

    @Override
    public void process() {
        //iJobBudgetService.occupyBudget();
    }

	@Override
	public void processPlanExpense() {
		iJobBudgetService.occupyBudget1();
	}

	@Override
	public void processNoLetterY() {
		iJobBudgetService.occupyBudget2();
	}
}
