package com.gome.crp.calc.client.coupon;

import com.gome.crp.calc.dto.orderCalcDto.OrderCalcCouponDto;

import java.util.List;

/**
 * 券查询
 * 
 * @author libinbin9
 *
 */
public interface IConsumerConponService {

	/**
	 * 券集合查询user中最早获取的用户id
	 * @param list
	 * @return userId
	 */
	String queryCouponGiveInfo(List<OrderCalcCouponDto> couponList);
	
	/**
	 * 券集合查询user中最早获取的用户id
	 * 
	 * @param couponList
	 * @param userId
	 * @return
	 */
	String queryCouponGiveInfo(List<OrderCalcCouponDto> couponList, String userId);
	
}
