package com.gome.crp.calc.service.doctor.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.CacheKeyConstants;
import com.gome.crp.calc.constants.ProblemEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.dto.planDto.PlanDto;
import com.gome.crp.calc.dto.problemDto.ProblemDto;
import com.gome.crp.calc.service.doctor.IPlanService;
import com.gome.crp.calc.service.doctor.IQueryPlanService;
import com.gome.crp.calc.service.problem.IProblemService;
import com.gome.crp.calc.util.GcacheUtil;
import com.gome.crp.common.vo.PlanDetialForCal;
import com.gome.scot.ocqs.api.model.ContractDetailVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 匹配计划
 *
 * @author chenchen
 */
@Slf4j
@Service("planServiceImpl2")
public class PlanServiceImpl implements IPlanService {
    @Autowired
    private GcacheUtil gcacheUtil;
    @Autowired
    private IProblemService iProblemService;
    @Autowired
    private IQueryPlanService queryPlanService;

    /**
     * 计算订单匹配的计划
     *
     * @param orderCalcDto
     * @return
     */
    @Override
    public List<PlanDto> orderMatchPlan(OrderCalcDto orderCalcDto) {
        long startTime = System.currentTimeMillis();
        log.info("开始匹配计划, 时间: {}", startTime);
        //如果是O2O  12渠道订单 直接查询计划
        if(orderCalcDto.getChannel().equals(BaseConstants.ORDER_CHANNEL_O2O)){
        	 log.info("匹配O2O计划开始");
        	 List<PlanDto> rtnPlanDtos = null;
            List<PlanDto> plans = queryPlanService.queryPlanByParam(orderCalcDto);
            if (CollectionUtils.isNotEmpty(plans)) {
                if (rtnPlanDtos == null) {
                    rtnPlanDtos = new ArrayList<>();
                }
                rtnPlanDtos.addAll(plans);
            }
            log.info("匹配O2O计划结束");
        	return rtnPlanDtos;
        }
        
        
        List<PlanDto> planDtos = matchPlanBySkuSaleModel(orderCalcDto);
        List<PlanDto> brandCategroyPlanDtos = matchPlanByBrandCategroy(orderCalcDto);
        if (null != brandCategroyPlanDtos && brandCategroyPlanDtos.size() > 0) {
            for (PlanDto thisPlanDto : brandCategroyPlanDtos) {
                if (null == planDtos) {
                    planDtos = new ArrayList<PlanDto>(brandCategroyPlanDtos.size());
                }
                planDtos.add(thisPlanDto);
            }
        }
        //日志打印
        if (null != planDtos && planDtos.size() > 0) {
            StringBuilder stringBuilder = new StringBuilder("");
            for (PlanDto planDto : planDtos) {
                stringBuilder.append(planDto.getPlanId()).append(",");
            }
            log.info("orderId:{},sku品类过滤之前:{}", orderCalcDto.getOrderId(), stringBuilder.toString());
        }
        List<PlanDto> rtnPlanDtos = dealPreviousPlan(planDtos);

        rtnPlanDtos = planOverlay(orderCalcDto, rtnPlanDtos);
        log.info("匹配计划结束, 耗时: {}", System.currentTimeMillis() - startTime);

        log.info("匹配无促-差异化-非差-带单计划开始");
        ContractDetailVO queryContractByParam = queryPlanService.queryContractByParam(orderCalcDto);
        if (queryContractByParam != null) {
            List<PlanDto> plans = queryPlanService.queryPlanByParam(orderCalcDto, queryContractByParam);
            if (CollectionUtils.isNotEmpty(plans)) {
                if (rtnPlanDtos == null) {
                    rtnPlanDtos = new ArrayList<>();
                }
                rtnPlanDtos.addAll(plans);
            }
        }
        log.info("匹配无促-差异化-非差-带单计划结束");

        return rtnPlanDtos;
    }

    @Override
    public List<PlanDto> getPlansById(String[] planId) {
        List planAll = new ArrayList();
        for (String s : planId) {
            String key = CacheKeyConstants.getPlanById(s);

            log.info("根据计划id去缓存查询计划, 计划 id 的 key: {}", key);
            String keyValue = gcacheUtil.getKeyValue(key);
            log.info("根据计划id查询到的缓存计划为: {}", keyValue);
            List<PlanDetialForCal> planDetialForCals = new ArrayList<>();
            if (StringUtils.isNotEmpty(keyValue)) {
                PlanDetialForCal planDetialForCal = JSONObject.parseObject(keyValue, PlanDetialForCal.class);
                planDetialForCals.add(planDetialForCal);
            } else {
                return null;
            }

            // 转换到我们自己的 dto
            List<PlanDto> planDtos = dealPlanVoToPlanDto(planDetialForCals);
            if (planDtos != null) {
                planAll.addAll(planDtos);
            }
        }
        return planAll;
    }

    @Override
    public List<String> skuIsMatchPlan(Map<String, String> skuMap) {
        // key:必传  skuNo,saleModel,eaGroupCode,eaBrandCode,planId
        String eaBrandCode = skuMap.get(BaseConstants.PROBLEM_EA_BRAND_CODE);
        String eaGroupCode = skuMap.get(BaseConstants.PROBLEM_EA_GROUP_CODE);
        String skuNo = skuMap.get(BaseConstants.PROBLEM_SKU_NO);
        String saleModel = skuMap.get(BaseConstants.PROBLEM_SALE_MODEL);
        String planId = skuMap.get(BaseConstants.PROBLEM_PLAN_ID);
        log.info("根据商品判断是否能匹配到某个计划. eaBrandCode: {}, eaGroupCode: {}, skuNo {}, saleModel {}, planId {}", eaBrandCode, eaGroupCode, skuNo, saleModel, planId);

        // sku+业务机型  品牌+品类
        String skuSaleModelKey = CacheKeyConstants.getPlanOfSkuSaleModel(skuNo, saleModel);
        String eaGroupCodeKey = CacheKeyConstants.getPlanOfCatBrand(eaBrandCode, eaGroupCode);
        String eaGroupCodeThirdKey = CacheKeyConstants.getPlanOfCatBrand(eaBrandCode, eaGroupCode.substring(0, 5));
        String eaGroupCodeSecondKey = CacheKeyConstants.getPlanOfCatBrand(eaBrandCode, eaGroupCode.substring(0, 3));

        log.info("匹配计划商品信息key. sku+业务机型: {}, 品牌+四级品类: {}, 品牌+三级品类: {}, 品牌+二级品类: {}, ", skuSaleModelKey, eaGroupCodeKey, eaGroupCodeThirdKey, eaGroupCodeSecondKey);

        String skuSaleModelKeyByPlan = "";
        String eaGroupCodeKeyByPlan = "";
        String eaGroupCodeThirdKeyByPlan = "";
        String eaGroupCodeSecondKeyByPlan = "";
        List<PlanDto> plans = getPlansById(new String[]{planId});
        if (plans != null && plans.size() > 0) {
            PlanDto planDto = plans.get(0);
            log.info("从缓存中获得到的计划是: {}", planDto);
            skuSaleModelKeyByPlan = CacheKeyConstants.getPlanOfSkuSaleModel(planDto.getSkuNo(), planDto.getSalesModelCode());
            eaGroupCodeKeyByPlan = CacheKeyConstants.getPlanOfCatBrand(planDto.getBrandCode(), planDto.getCategoryLevelFour());
            eaGroupCodeThirdKeyByPlan = CacheKeyConstants.getPlanOfCatBrand(planDto.getBrandCode(), planDto.getCategoryLevelThree());
            eaGroupCodeSecondKeyByPlan = CacheKeyConstants.getPlanOfCatBrand(planDto.getBrandCode(), planDto.getCategoryLevelTwo());
        }

        List<String> resList = new ArrayList<>();
        resList.add(String.format("订单中的sku和业务机型的key: %s, 计划中的sku和业务机型的key: %s", skuSaleModelKey, skuSaleModelKeyByPlan));
        resList.add(String.format("订单中的品牌编码和四级品类的key: %s, 计划中的品牌编码和四级品类的key: %s", eaGroupCodeKey, eaGroupCodeKeyByPlan));
        resList.add(String.format("订单中的品牌编码和三级品类的key: %s, 计划中的品牌编码和三级品类的key: %s", eaGroupCodeThirdKey, eaGroupCodeThirdKeyByPlan));
        resList.add(String.format("订单中的品牌编码和二级品类的key: %s, 计划中的品牌编码和二级品类的key: %s", eaGroupCodeSecondKey, eaGroupCodeSecondKeyByPlan));

        return resList;
    }

    /**
     * 通过商品sku和业务机型匹配计划
     *
     * @param orderCalcDto
     * @return
     */
    public List<PlanDto> matchPlanBySkuSaleModel(OrderCalcDto orderCalcDto) {
        log.info("通过skuNo和业务机型获取计划");
        String key = CacheKeyConstants.getPlanOfSkuSaleModel(orderCalcDto.getSkuNo(), orderCalcDto.getSalesModel());
        List<PlanDto> planDtos = getPlanDtosFromCache(key);
        if (null == planDtos || planDtos.size() == 0) {
            log.info("通过skuNo和业务机型未获取到计划，orderId:{},detailId:{},skuNo:{},saleModel:{},key:{}", orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), orderCalcDto.getSkuNo(), orderCalcDto.getSalesModel(), key);
            return null;
        }
        StringBuffer plans = new StringBuffer("planId:");
        ArrayList<PlanDto> rtnPlanDtos = new ArrayList<PlanDto>(planDtos.size());
        for (PlanDto thisPlanDto : planDtos) {
            thisPlanDto.setPlanCategory(0);
            if (checkPlan(thisPlanDto, orderCalcDto)) {
                rtnPlanDtos.add(thisPlanDto);
                plans.append(",").append(thisPlanDto.getPlanId());
            }
        }
        log.info("orderId:{},deatail:{},通过sku+saleModel获取到的计划为:{}", orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), plans.toString());
        return rtnPlanDtos;
    }

    /**
     * 通过商品分类匹配计划
     *
     * @param orderCalcDto
     * @return
     */
    public List<PlanDto> matchPlanByBrandCategroy(OrderCalcDto orderCalcDto) {
        log.info("通过品类品牌查找计划");
        List<PlanDto> rtnPlanDtos = new ArrayList<PlanDto>();
        ArrayList<String> keyList = new ArrayList<>(7);
        //品牌+四级品类
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(orderCalcDto.getEaBrandCode(), orderCalcDto.getEaGroupCode()));
        //品牌+三级品类
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(orderCalcDto.getEaBrandCode(), orderCalcDto.getEaGroupCodeThird()));
        //品牌+二级品类
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(orderCalcDto.getEaBrandCode(), orderCalcDto.getEaGroupCodeSecond()));
        //独四级品类
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(BaseConstants.PLAN_DEFAULT_PREFIX_KEY, orderCalcDto.getEaGroupCode()));
        //独三级品类
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(BaseConstants.PLAN_DEFAULT_PREFIX_KEY, orderCalcDto.getEaGroupCodeThird()));
        //独二级品类
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(BaseConstants.PLAN_DEFAULT_PREFIX_KEY, orderCalcDto.getEaGroupCodeSecond()));
        //品牌
        keyList.add(CacheKeyConstants.getPlanOfCatBrand(orderCalcDto.getEaBrandCode(), BaseConstants.PLAN_DEFAULT_PREFIX_KEY));
        for (int i = 0; i < keyList.size(); i++) {
            List<PlanDto> planDtos = getPlanDtosFromCache(keyList.get(i));
            if (null != planDtos && planDtos.size() > 0) {
                for (PlanDto thisPlanDto : planDtos) {
                    if (checkPlan(thisPlanDto, orderCalcDto)) {
                        thisPlanDto.setPlanCategory(i + 1);//分类
                        rtnPlanDtos.add(thisPlanDto);
                    }
                }
            }
        }
        if (null != rtnPlanDtos && rtnPlanDtos.size() > 0) {
            return rtnPlanDtos;
        }
        log.info("通过订单线下四级、三级、二级品类加品牌没有找到可用计划，orderId:{},detailId:{},fourKey:{},thirdKey:{},secondKey:{}", orderCalcDto.getOrderId(), orderCalcDto.getDetailId()
                , keyList.get(0), keyList.get(1), keyList.get(2));
        return null;
    }

    /**
     * 从缓存获取计划x
     *
     * @param key
     * @return
     */
    public List<PlanDto> getPlanDtosFromCache(String key) {
        log.info("获取缓存的key:{}", key);
        List<PlanDetialForCal> planVos = gcacheUtil.getObjectFromHashNoField(key, PlanDetialForCal.class);
        List<PlanDto> planDtos = dealPlanVoToPlanDto(planVos);
        log.info("通过 key:{} 查询到缓存计划:{}", key, planDtos);
        if (null == planDtos && planDtos.size() == 0) {
            log.info("未查询到计划,sku业务机型key:{}", key);
            return null;
        }
        return planDtos;
    }

    /**
     * 校验计划是否有效
     *
     * @param planDto
     * @param orderCalcDto
     * @return
     */
    public Boolean checkPlan(PlanDto planDto, OrderCalcDto orderCalcDto) {
        String problemDesc = "";
        if (!BaseConstants.PLAN_DEFAULT_SPECIAL_SALEMODEL.contains(orderCalcDto.getSalesModel())) {
            problemDesc = String.format("计划无效,拓客计划进行特例品校验不通过,planId:%s,orderId:%s,detialId:%s,planStatus:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getStatus());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        //校验计划状态
        if (!BaseConstants.PLAN_CALC_EFFECT.equals(planDto.getStatus().toString())) {
            problemDesc = String.format("计划无效,计划不是有效状态,planId:%s,orderId:%s,detialId:%s,planStatus:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getStatus());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        if (orderCalcDto.getPayDate().compareTo(planDto.getStartTime()) != 1 || planDto.getEndTime().compareTo(orderCalcDto.getPayDate()) != 1) {
            problemDesc = String.format("计划无效,订单支付时间不在计划的有效时间范围内,planId:%s,orderId:%s,detialId:%s,planBeginTime:%s,planEndTime:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getStartTime(), planDto.getEndTime());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        //促销费类型是拓客或者是承担方是国美预算的
        Boolean flag = BaseConstants.PLAN_EXPENSE_OFFER_TWO_TYPE.equals(planDto.getExpenseOfferType().toString())
                || BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(planDto.getPromotionsType().toString());
        if (!flag && CollectionUtils.isEmpty(orderCalcDto.getPurchaseCodeList())) {
            problemDesc = String.format("不是拓客或国美预算订单采购组织为空,planId:%s,orderId:%s,detialId:%s,planContractPurchaseCode:%s,orderPurchaseCode:%s,expenseOfferType:%s,promotionsType:%s",
                    planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getContractPurchaseCode(), orderCalcDto.getPurchaseCodeList(), planDto.getExpenseOfferType(), planDto.getPromotionsType().toString());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        //校验采购组织
        if (!flag && !orderCalcDto.getPurchaseCodeList().contains(planDto.getContractPurchaseCode())) {
            problemDesc = String.format("不是拓客或国美预算计划采购组织为空,或者和订单采购组织不匹配,planId:%s,orderId:%s,detialId:%s,planContractPurchaseCode:%s,orderPurchaseCode:%s,expenseOfferType:%s,promotionsType:%s",
                    planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getContractPurchaseCode(), orderCalcDto.getPurchaseCodeList(), planDto.getExpenseOfferType(), planDto.getPromotionsType().toString());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        if (!flag && !orderCalcDto.getSupplier().equals(planDto.getContractSupplierCode())) {
            problemDesc = String.format("计划无效,计划不是国美预算并且不是拓客,而且订单供应商和计划配置供应商不匹配,planId:%s,orderId:%s,detialId:%s,planSupplierCode:%s,orderSupplierCode:%s,expenseOfferType:%s,promotionsType:%s",
                    planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getContractSupplierCode(), orderCalcDto.getSupplier(), planDto.getExpenseOfferType(), planDto.getPromotionsType().toString());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        //订单渠道为空
        if (StringUtils.isBlank(orderCalcDto.getChannelCalcNo())) {
            problemDesc = String.format("计划无效,订单渠道为空不进行计划匹配,planId:%s,orderId:%s,detialId:%s,计划推广类型:%s,订单渠道:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getExtensionCoverageType(), orderCalcDto.getChannelCalcNo());
            //计划推广类型 与订单渠道不符
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        //推广渠道只能处理订单中的 1 2 3 的
        if (!planDto.getExtensionCoverageType().contains(BaseConstants.PLAN_ORDER_CHANNEL_CALC_ALL)
                && !planDto.getExtensionCoverageType().contains(orderCalcDto.getChannelCalcNo())) {
            problemDesc = String.format("计划无效,计划推广范围不是全部,订单推广范围不是线下（1）,一店一页（2）,线上（3）计划推广范围不符合,planId:%s,orderId:%s,detialId:%s,计划推广类型:%s,订单渠道:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getExtensionCoverageType(), orderCalcDto.getChannelCalcNo());
            //计划推广类型 与订单渠道不符
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        //促销费类型是否未拓客
        boolean inviteGuestFlag = BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(planDto.getPromotionsType().toString());
        if (inviteGuestFlag && BaseConstants.PLAN_MATCH_HAS_SPECIAL_SKU == planDto.getIsSpecialSku()
                && gcacheUtil.sismember(CacheKeyConstants.getSpecialSkuKey(planDto.getPlanId().toString()), CacheKeyConstants.getPlanSpecialSkuKey(orderCalcDto.getSalesModel(), orderCalcDto.getSkuNo()))) {
            problemDesc = String.format("特例品不为空，并且sku商品包含在特例品中,planId:%s,orderId:%s,detialId:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        // 推广类型为 0 和 3 ，planDto 中 orgToStore 是为 null 的
        if (planDto.getExtensionCoverageType().contains(BaseConstants.PLAN_ORDER_CHANNEL_CALC_ALL)
                || planDto.getExtensionCoverageType().contains(BaseConstants.PLAN_ORDER_CHANNEL_CALC_ONLINE)) {
            log.info("计划推广范围: {}", planDto.getExtensionCoverageType());
            return true;
        }
        // Map<推广渠道 ,Map<全国/销售组织编码 ,List<门店编码>>
        Map<String, Map<String, List<String>>> orgToStore = planDto.getOrgToStore();
        if (null == orgToStore || orgToStore.isEmpty()) {
            problemDesc = String.format("计划无效,orgToStore为null(Map<推广渠道 ,Map<全国/销售组织编码 ,List<门店编码>>)，配置有误！planId:%s,orderId:%s,detialId:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        // Map<全国/销售组织编码 ,List<门店编码>
        Map<String, List<String>> stringListMap = orgToStore.get(orderCalcDto.getChannelCalcNo());
        if (null == stringListMap || stringListMap.isEmpty()) {
            problemDesc = String.format("计划无效,stringListMap为null(Map<推广渠道 ,Map<全国/销售组织编码 ,List<门店编码>>)，配置有误！planId:%s,orderId:%s,detialId:%s,planChannel:%s,orderChannel:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), planDto.getExtensionCoverageType(), orderCalcDto.getChannelCalcNo());
            //标识订单渠道和计划配置渠道不对应
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        if (stringListMap.containsKey(BaseConstants.PLAN_ALL_COUNTRY_CODE)) {
            //全国
            return true;
        }
        boolean tempFlag = stringListMap.containsKey(orderCalcDto.getSalesOrganization());
        //不是全国
        //标识计划里面配置的推广范围不包含订单上的销售组织
        if (!tempFlag) {
            problemDesc = String.format("表示计划里面配置的推广范围不包含订单上的销售组织,planId:%s,orderId:%s,detialId:%s,orderStoreCode:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), orderCalcDto.getShopNo());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        List<String> storeList = stringListMap.get(orderCalcDto.getSalesOrganization());
        //包含这个销售组织并且销售最值对应的value为空
        if (null == storeList || storeList.size() == 0) {
            //销售组织下的所有门店
            return true;
        }
        if (!storeList.contains(orderCalcDto.getShopNo())) {
            problemDesc = String.format("计划配置门店与订单上的门店不对应,planId:%s,orderId:%s,detialId:%s,orderStoreCode:%s", planDto.getPlanId(), orderCalcDto.getOrderId(), orderCalcDto.getDetailId(), orderCalcDto.getShopNo());
            log.info(problemDesc);
            iProblemService.addData(orderCalcDto, planDto, null, problemDesc, ProblemEnum.CODE_101);
            return false;
        }
        return true;
    }

    /**
     * 计划的叠加
     *
     * @param planDtos
     * @return
     */
    public List<PlanDto> planOverlay(OrderCalcDto orderCalcDto, List<PlanDto> planDtos) {
        log.info("计划准备开始叠加");
        StringBuffer plans = new StringBuffer("匹配过滤之后");
        if (null != planDtos && planDtos.size() > 0) {
            for (PlanDto thisPlan : planDtos) {
                plans.append(",").append(thisPlan.getPlanId());
            }
            log.info("orderId:{},detailId:{},skuNo:{},saleModel:{},brand:{},fourCat:{},threeCat:{},two:{},sku品牌品类:{}", orderCalcDto.getOrderId(),
                    orderCalcDto.getDetailId(), orderCalcDto.getSkuNo(), orderCalcDto.getSalesModel(), orderCalcDto.getEaBrandCode(),
                    orderCalcDto.getEaGroupCode(), orderCalcDto.getEaGroupCodeThird(), orderCalcDto.getEaGroupCodeSecond(), plans.toString());
        } else {
            log.info("计划为空,不进行计划叠加");
            return null;
        }

        ArrayList<PlanDto> rtnPlanDtos = new ArrayList<PlanDto>();
        ArrayList<PlanDto> promotionPlanTypeFive = new ArrayList<PlanDto>();
        for (PlanDto thisPlanDto : planDtos) {
            if (BaseConstants.PLAN_INVITE_GUEST_TYPE.equals(thisPlanDto.getPromotionsType().toString())) {
                promotionPlanTypeFive.add(thisPlanDto);
            }
        }
        // 拓客的
        PlanDto inviteGuestPlandDto = dealWithPlanOfInviteGuest(orderCalcDto, promotionPlanTypeFive);

        if (null != inviteGuestPlandDto) {
            rtnPlanDtos.add(inviteGuestPlandDto);
        }

        //日志打印
        if (null != rtnPlanDtos && rtnPlanDtos.size() > 0) {
            StringBuilder stringBuilder = new StringBuilder("计划叠加之后");
            for (PlanDto p : rtnPlanDtos) {
                stringBuilder.append(",").append(p.getPlanId());
            }

            // 叠加之后，计划产生变化，将数据入问题小工具
            if (plans.length() == stringBuilder.length()) {
                ProblemDto problemDto = new ProblemDto(orderCalcDto.getOrderId(), orderCalcDto.getChannel(), orderCalcDto.getSkuNo(), orderCalcDto.getDetailId());
                problemDto.setDescription(String.format("叠加前计划id为: %s, 叠加后计划id为: %s", plans.toString(), stringBuilder.toString()));
                iProblemService.addData(problemDto, ProblemEnum.CODE_101);
            }

            log.info("orderId:{},detailId:{},skuNo:{},saleModel:{},brand:{},fourCat:{},threeCat:{},two:{},叠加之后的计划为:{}", orderCalcDto.getOrderId(),
                    orderCalcDto.getDetailId(), orderCalcDto.getSkuNo(), orderCalcDto.getSalesModel(), orderCalcDto.getEaBrandCode(),
                    orderCalcDto.getEaGroupCode(), orderCalcDto.getEaGroupCodeThird(), orderCalcDto.getEaGroupCodeSecond(), stringBuilder.toString());
        }

        return rtnPlanDtos;
    }

    /**
     * 处理拓客的计划
     *
     * @param planDtos
     * @return
     */
    public PlanDto dealWithPlanOfInviteGuest(OrderCalcDto orderCalcDto, ArrayList<PlanDto> planDtos) {
        if (null == planDtos || planDtos.size() == 0) {
            log.info("拓客类型计划为空，无法处理");
            return null;
        }
        List<PlanDto> rtnPlanDtos = dealWithSameStaffLevel(planDtos);
        Collections.sort(rtnPlanDtos, getComparator());
        log.info("拓客计划按计划生效时间取最新,orderId:{},rtn:{}", orderCalcDto.getOrderId(), planDtos.get(0));
        return rtnPlanDtos.get(0);
    }


    /**
     * 处理相同签约类型的计划
     *
     * @param planDtos
     * @return
     */
    public List<PlanDto> dealWithSameStaffLevel(List<PlanDto> planDtos) {
        if (null == planDtos || planDtos.size() == 0) {
            log.info("处理相同类型计划为空，无法处理");
            return null;
        }
        HashMap<Integer, List<PlanDto>> calcPlanListMap = new HashMap<>(planDtos.size());
        for (PlanDto thisPlanDto : planDtos) {
            List<PlanDto> sameStaffLevelList = calcPlanListMap.get(thisPlanDto.getStaffLevel());
            if (null == sameStaffLevelList || sameStaffLevelList.size() == 0) {
                sameStaffLevelList = new ArrayList<PlanDto>();
            }
            sameStaffLevelList.add(thisPlanDto);
            calcPlanListMap.put(thisPlanDto.getStaffLevel(), sameStaffLevelList);
        }
        if(calcPlanListMap.containsKey(BaseConstants.PLAN_MATCH_STAFF_LEVEL_0)){
            return calcPlanListMap.get(BaseConstants.PLAN_MATCH_STAFF_LEVEL_0);
        }
        if(calcPlanListMap.containsKey(BaseConstants.PLAN_MATCH_STAFF_LEVEL_2)){
            return calcPlanListMap.get(BaseConstants.PLAN_MATCH_STAFF_LEVEL_2);
        }
        if(calcPlanListMap.containsKey(BaseConstants.PLAN_MATCH_STAFF_LEVEL_3)){
            return calcPlanListMap.get(BaseConstants.PLAN_MATCH_STAFF_LEVEL_3);
        }
        return null;
    }

    /**
     * 配置端计划实体转换计算端计划实体
     *
     * @return
     */
    public List<PlanDto> dealPlanVoToPlanDto(List<PlanDetialForCal> planVos) {
        ArrayList<PlanDto> planDtos = new ArrayList<>();
        for (PlanDetialForCal planVo : planVos) {
            PlanDto planDto = new PlanDto();
            BeanUtils.copyProperties(planVo, planDto);
            planDto.setPlanId(planVo.getId());
            planDtos.add(planDto);
        }
        return planDtos;
    }

    /**
     * 返回Comparator
     *
     * @return
     */
    public Comparator<PlanDto> getComparator() {
        Comparator<PlanDto> comparator = new Comparator<PlanDto>() {
            @Override
            public int compare(PlanDto o1, PlanDto o2) {
                //新增采购组织字段以后 去除取最新的逻辑
                //无函 或者 没有签约类型
                Date startTime1 = o1.getStartTime();
                Date startTime2 = o2.getStartTime();
                if (startTime1.compareTo(startTime2) == 1) {
                    return -1;
                } else {
                    if (startTime1.compareTo(startTime2) != 0) {
                        return 1;
                    } else {
                        return o1.getPlanId() > o2.getPlanId() ? -1 : 1;
                    }
                }
            }
        };
        return comparator;
    }

    /**
     * 处理查询到的计划优先级
     *
     * @param planDtos
     * @return
     */
    public List<PlanDto> dealPreviousPlan(List<PlanDto> planDtos) {
        if (null == planDtos || planDtos.size() == 0) {
            return null;
        }
        List<PlanDto> rtnPlanDtos = new ArrayList<PlanDto>(planDtos.size());
        HashMap<Long, PlanDto> integerPlanDtoHashMap = new HashMap<>(planDtos.size());
        for (PlanDto thisPlanDto : planDtos) {
            if (integerPlanDtoHashMap.containsKey(thisPlanDto.getPlanId())) {
                PlanDto planDto = integerPlanDtoHashMap.get(thisPlanDto.getPlanId());
                if (planDto.getPlanCategory() > thisPlanDto.getPlanCategory()) {
                    integerPlanDtoHashMap.put(thisPlanDto.getPlanId(), thisPlanDto);
                }
            } else {
                integerPlanDtoHashMap.put(thisPlanDto.getPlanId(), thisPlanDto);
            }
        }
        if (!integerPlanDtoHashMap.isEmpty()) {
            Set<Long> keys = integerPlanDtoHashMap.keySet();
            for (Long key : keys) {
                rtnPlanDtos.add(integerPlanDtoHashMap.get(key));
            }
        }
        return rtnPlanDtos;
    }
}
