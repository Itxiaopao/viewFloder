package com.gome.crp.calc.service.retry.cope.impl;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.service.bill.IBillService;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class RetrySapOnlineService implements IRetrySceneService {

    @Autowired
    private IBillService billService;
    private static String service_name = RetryJobEnum.SAP_RELEASE_ONLINE.getMsg();

    @Override
    public boolean cope(CalcRetry calcRetry) {
        // 推送结算 RPC 服务
        boolean boo = this.sapOnline(calcRetry);
        log.info(String.format("提成计算推送结果, 重推类型:%s, retryId:%s, 处理结果: %b", service_name, calcRetry.getId(), boo));
        return boo;
    }


    /**
     * 结算推送:
     * 返回成功与否,做重试
     *
     * @param calcRetry
     * @return
     */
    private boolean sapOnline(CalcRetry calcRetry) {
        // 推送结算 RPC 服务
        boolean ret = false;
        try {
            String msgBody = calcRetry.getMsgBody();
            List<CalcResult> ccrds = JSONObject.parseArray(msgBody, CalcResult.class);
            billService.applyPay(ccrds);
            ret = true;
        } catch (Exception e) {
            log.error(String.format("结算重推操作失败: retryId:%d, 处理结果异常", calcRetry.getId()));
            ret = false;
        }
        return ret;
    }

}
