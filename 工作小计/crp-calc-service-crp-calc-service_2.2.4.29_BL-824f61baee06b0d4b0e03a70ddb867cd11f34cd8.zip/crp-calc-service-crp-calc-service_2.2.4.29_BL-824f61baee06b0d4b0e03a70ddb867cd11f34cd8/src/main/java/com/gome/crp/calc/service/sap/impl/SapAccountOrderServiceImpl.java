package com.gome.crp.calc.service.sap.impl;

import com.gome.crp.calc.constants.IsScanEnum;
import com.gome.crp.calc.dto.sapDto.SapAccountInfo;
import com.gome.crp.calc.service.sap.ISapAccountOrderService;
import com.gome.crp.calc.util.BigDecimalUtils;
import com.gome.crp.calc.mybatis.mapper.SapAccountMapper;
import com.gome.crp.calc.mybatis.model.SapAccount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class SapAccountOrderServiceImpl implements ISapAccountOrderService {
    @Autowired
    private SapAccountMapper sapAccountMapper;

    @Override
    public void handler(SapAccountInfo sapAccountInfo) {
        SapAccount sapAccount = getSapAccount(sapAccountInfo);
        try {
            sapAccountMapper.insert(sapAccount);
        } catch (DuplicateKeyException e) {
            log.error("保存sap账目被防重soDeliveryDetailId:{},soSaleChannel:{},sapAccountInfo:{}", sapAccountInfo.getSoDeliveryDetailId(), sapAccountInfo.getSoSaleChannel(), sapAccountInfo);
        }
    }

    private SapAccount getSapAccount(SapAccountInfo sapAccountInfo) {
        SapAccount sapAccount = new SapAccount();
        sapAccount.setBukrs(sapAccountInfo.getBukrs()); //公司代码
        sapAccount.setLifnr(sapAccountInfo.getLifnr()); //供应商或债权人的帐号
        sapAccount.setConno(sapAccountInfo.getConno()); //合同编号
        sapAccount.setNewno(sapAccountInfo.getNewno()); //合同编号
        sapAccount.setReuno(sapAccountInfo.getReuno()); //收入项目编码(带单函 fy0000087， 主推 fy0000008， 零售提奖z605 fy0000084， 无促 z195/z197  fy0000078)
        sapAccount.setBudat1(sapAccountInfo.getBudat1()); //计算开始日期
        sapAccount.setBudat2(sapAccountInfo.getBudat2()); //计算结束日期
        sapAccount.setBukrs0(sapAccountInfo.getBukrs0()); //公司代码
        sapAccount.setMblnr(sapAccountInfo.getMblnr()); //商品凭证编号
        sapAccount.setZeile(sapAccountInfo.getZeile()); //销售凭证项目
        sapAccount.setBudat(sapAccountInfo.getBudat()); //凭证中的过帐日期
        sapAccount.setKonnr(sapAccountInfo.getKonnr()); //协议编号或函号
        sapAccount.setMatnr(sapAccountInfo.getMatnr()); //商品编码
        sapAccount.setCharg(sapAccountInfo.getCharg()); //批号
        sapAccount.setEbeln(sapAccountInfo.getEbeln()); //采购凭证号
        sapAccount.setEbelp(sapAccountInfo.getEbelp()); //采购凭证的项目编号
        sapAccount.setVbeln(sapAccountInfo.getVbeln()); //开票凭证
        sapAccount.setPosnr(sapAccountInfo.getPosnr()); //销售凭证项目
        sapAccount.setFkimg(sapAccountInfo.getFkimg()); //实际已开票数量
        sapAccount.setMeins(sapAccountInfo.getMeins()); //基本计量单位
        sapAccount.setDmbtr1(BigDecimalUtils.changeY2F(sapAccountInfo.getDmbtr1())); //供价金额（含税）
        sapAccount.setDmbtr2(BigDecimalUtils.changeY2F(sapAccountInfo.getDmbtr2())); //售价额（含税）
        sapAccount.setDmbtr3(BigDecimalUtils.changeY2F(sapAccountInfo.getDmbtr3())); //返利额（含税）
        sapAccount.setLevel4(sapAccountInfo.getLevel4()); //四级品类
        sapAccount.setLevel3(sapAccountInfo.getLevel3()); //三级品类
        sapAccount.setLevel2(sapAccountInfo.getLevel2()); //二级品类
        sapAccount.setUpdats(sapAccountInfo.getUpdats()); //更新日期
        sapAccount.setZdtbz(sapAccountInfo.getZdtbz()); //单台标准
        sapAccount.setZdmbt1(sapAccountInfo.getZdmbt1()); //计提限价
        sapAccount.setZcxfy(BigDecimalUtils.changeY2F(sapAccountInfo.getZcxfy())); //促销费金额
        sapAccount.setZyfje(BigDecimalUtils.changeY2F(sapAccountInfo.getZyfje())); //应发金额
        sapAccount.setSoSaleChannel(sapAccountInfo.getSoSaleChannel()); //销售渠道
        sapAccount.setSoSapItemNum(sapAccountInfo.getSoSapItemNum()); //sap行项目号
        sapAccount.setSoDeliveryDetailId(sapAccountInfo.getSoDeliveryDetailId()); //配送单+detail_id(13/16/60渠道订单：前10位配送单号，后10位detail号；10渠道订单：销售组织+提货单号（位数不固定）)
        sapAccount.setSoCommodityCode(sapAccountInfo.getSoCommodityCode()); //商品编码
        sapAccount.setSoCommodityNum(sapAccountInfo.getSoCommodityNum()); //商品数量
        sapAccount.setSoBuyorgCode(sapAccountInfo.getSoBuyorgCode()); //采购组织
        sapAccount.setSoPlace(sapAccountInfo.getSoPlace()); //地点
        sapAccount.setSoStockPlace(sapAccountInfo.getSoStockPlace()); //库存地点
        sapAccount.setSoSuppCode(sapAccountInfo.getSoSuppCode()); //供应商编码
        sapAccount.setSoBusinessModel(sapAccountInfo.getSoBusinessModel()); //业务机型(01 标准机02 包销机03 定制机04 临采机05 特价06 工程机07 会员商品08 赠品09 样机11 一步到位价)
        sapAccount.setSoDeliverCompanyCode(sapAccountInfo.getSoDeliverCompanyCode()); //发货公司代码
        sapAccount.setSoContractCode(sapAccountInfo.getSoContractCode()); //合同号
        sapAccount.setSoAgreementCode(sapAccountInfo.getSoAgreementCode()); //协议号
        sapAccount.setSoSaleMethod(sapAccountInfo.getSoSaleMethod()); //销售方式(01带安；02联营；09联营带安，null其他)
        sapAccount.setIsScan(IsScanEnum.NO.getCode()); //是否已扫描1:已扫描,0:未扫描
        return sapAccount;
    }

}
