package com.gome.crp.calc.manager;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.exception.BusinessException;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.SapRecord;
import com.gome.crp.calc.mybatis.service.ICalcRecordService;
import com.gome.crp.calc.mybatis.service.ICalcResultService;
import com.gome.crp.calc.mybatis.service.ISapRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class OrderBaseManager {

    @Autowired
    private ICalcResultService iCalcResultService;
    @Autowired
    private ICalcRecordService iCalcRecordService;
    @Autowired
    private ISapRecordService iSapRecordService;

    @Transactional
    public void doUpdateCalcResultStatus(List<CalcResult> updateCalcResultList, List<CalcRecord> calcRecordList, List<SapRecord> sapRecordList) {
        boolean result = iCalcResultService.updateBatchById(updateCalcResultList);
        if (!result) {
            throw new BusinessException(String.format("批量更新计算结果失败updateCalcResultList:%s", JSON.toJSONString(updateCalcResultList)));
        }

        boolean result2 = iCalcRecordService.saveBatch(calcRecordList);
        if (!result2) {
            throw new BusinessException(String.format("批量保存计算履历失败updateCalcResultList:%s", JSON.toJSONString(updateCalcResultList)));
        }

        if (!CollectionUtils.isEmpty(sapRecordList)) {
            //sap挂账信息入库
            boolean result3 = iSapRecordService.saveBatch(sapRecordList);
            if (!result3) {
                throw new BusinessException(String.format("批量保存挂账数据失败sapRecordId:%s-%s", sapRecordList.get(0).getId(), sapRecordList.get(sapRecordList.size() - 1).getId()));
            }
        }
    }
}
