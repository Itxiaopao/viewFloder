package com.gome.crp.calc.service.retry.cope.impl;

import com.alibaba.fastjson.JSON;
import com.gome.crp.calc.constants.BaseConstants;
import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.dto.orderCalcDto.OrderCalcDto;
import com.gome.crp.calc.service.order.impl.OrderCOServiceImpl;
import com.gome.crp.calc.service.order.impl.OrderDLServiceImpl;
import com.gome.crp.calc.service.retry.cope.IRetrySceneService;
import com.gome.crp.calc.mybatis.model.CalcResult;
import com.gome.crp.calc.mybatis.model.CalcRetry;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class RetryReCalcService implements IRetrySceneService {


    @Autowired
    private OrderCOServiceImpl orderCOServiceImpl;
    @Autowired
    private OrderDLServiceImpl orderDLServiceImpl;

    private static String service_name = RetryJobEnum.REDO_ORDERCALC.getMsg();

    @Override
    public boolean cope(CalcRetry calcRetry) {
        boolean boo = this.redoRetryOrderCalc(calcRetry);
        log.info(String.format("提成计算推送结果, 重推类型:%s, retryId:%s, 处理结果: %b", service_name, calcRetry.getId(), boo));
        return boo;
    }


    /**
     * 重新计算订单，失败重推
     *
     * @param calcRetry
     * @return true:处理成功 false:处理失败
     */
    private boolean redoRetryOrderCalc(CalcRetry calcRetry) {
        boolean boo = false;
        try {
            Integer type = calcRetry.getType();
            if (type == RetryJobEnum.REDO_ORDERCALC.getCode()) {
                List<CalcResult> calcResultList = JSON.parseArray(calcRetry.getMsgBody(), CalcResult.class);
                CalcResult calcResult = calcResultList.get(0);
                if (BaseConstants.ORDER_CO_STATUS.equals(calcResult.getGomeStatus())) {
                    OrderCalcDto coOrderCalcDto = JSON.parseObject(calcResultList.get(0).getCoMsgBody(), OrderCalcDto.class);
                    log.info(String.format("重新计算-重推CO订单失败，准备重推：订单号：%s，配送单号:%s, detailId：%s", coOrderCalcDto.getOrderId(), coOrderCalcDto.getDeliveryId(), coOrderCalcDto.getDetailId()));
                    orderCOServiceImpl.redoCalcLogic(coOrderCalcDto, calcResultList);
                } else if (BaseConstants.ORDER_DL_STATUS.equals(calcResult.getGomeStatus())) {
                    OrderCalcDto dlOrderCalcDto = JSON.parseObject(calcResultList.get(0).getDlMsgBody(), OrderCalcDto.class);
                    log.info(String.format("重新计算-重推DL订单失败，准备重推：订单号：%s，配送单号:%s, detailId：%s", dlOrderCalcDto.getOrderId(), dlOrderCalcDto.getDeliveryId(), dlOrderCalcDto.getDetailId()));
                    orderDLServiceImpl.redoCalcLogic(dlOrderCalcDto, calcResultList);
                } else {
                    log.error("重新计算-重推订单失败,冲推类型不正确retryId:{},type:{}", calcRetry.getId(), type);
                }
                boo = true;
            }
        } catch (Exception e) {
            log.error(String.format("重新计算-重推订单异常, retryId:%s", calcRetry.getId()), e);
            boo = false;
        }
        return boo;
    }
}
