package com.gome.crp.calc.dto.formula;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

// 十大品类返回值结果
@Getter
@Setter
public class CategroyPointRateDto {
    // 报告
    private String desc;
    // 点位值
    private BigDecimal rate;
}
