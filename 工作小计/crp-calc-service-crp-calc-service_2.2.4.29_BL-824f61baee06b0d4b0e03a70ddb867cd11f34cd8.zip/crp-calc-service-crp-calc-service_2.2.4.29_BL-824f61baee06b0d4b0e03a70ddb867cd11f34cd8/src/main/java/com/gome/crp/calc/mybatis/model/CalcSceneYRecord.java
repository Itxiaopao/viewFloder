package com.gome.crp.calc.mybatis.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 计算y场景的记录表
 * @author chenchen56
 */
@Data
public class CalcSceneYRecord implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long id;

    /**
     * 计划id
     */
    private String planId;

    /**
     * 获利人
     */
    private String userId;

    private String staffCode;

    /**
     * 下单人
     */
    private String profileId;

    /**
     * 计划提奖金额
     */
    private Long awardPrice;

    private Date createTime;

    private Date updateTime;

    private Date planEndTime;

    private Integer isDelete; //删除标识,0:未删除,1:已删除

    private Integer isScan;//扫描标识，0:未扫描,1:已被扫描
}