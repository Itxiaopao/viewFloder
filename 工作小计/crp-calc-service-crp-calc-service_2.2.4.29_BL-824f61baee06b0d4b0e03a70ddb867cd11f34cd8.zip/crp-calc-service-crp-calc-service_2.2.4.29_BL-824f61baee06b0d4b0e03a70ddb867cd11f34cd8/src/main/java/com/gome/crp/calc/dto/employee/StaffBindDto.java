package com.gome.crp.calc.dto.employee;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author libinbin9
 *
 */
@Setter
@Getter
public class StaffBindDto implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -8968129717540576369L;

	private java.lang.String id;

	private java.lang.String mxUid;

	private java.lang.String zxUid;

	private java.lang.String staffName;

	private java.lang.String staffCode;

	private java.lang.String staffPostCode;

	private java.lang.String isAppoint;

	private java.lang.String staffPostName;

	private java.lang.String fDivisionCode;

	private java.lang.String fDivisionName;

	private java.lang.String sDivisionCode;

	private java.lang.String sDivisionName;

	private java.lang.String storeCode;

	private java.lang.String storeName;

	private java.lang.String staffLevel;

	private java.lang.String staffCategory;

	private java.lang.String categoryBrand;

	private java.lang.String introduction;

	private java.lang.String isstore;

	private java.lang.String organizationCode;

	private java.lang.String brandCode;

	private java.lang.String status;

	private java.util.Date ctime;

	private java.util.Date utime;

	private java.lang.String headerStatus;

	private java.lang.String mid;

	private java.lang.String staffPhone;

	private java.lang.String staffDeptCode;

	private java.lang.String staffDeptName;

	private java.lang.String staffCompanyCode;

	private java.lang.String staffCompanyName;

	private java.lang.String staffPostId;

}
