package com.gome.crp.calc.constants;

public enum StatusEnum {
    UN_TREATED(0, "未处理"),
    FINISHED_PROCESSING(1, "处理完成"),
    ;

    private Integer code;
    private String msg;

    StatusEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
