package com.gome.crp.calc.constants;

public enum FailureReasonEnum {
    SAP_COMPARE_CONTRACT_NO_MATCH(1, "sap严控-合同号未匹配"),
    SAP_COMPARE_AGREEMENT_NO_MATCH(2, "sap严控-协议号未匹配"),
    SAP_COMPARE_LETTER_NO_MATCH(3, "sap严控-函号未匹配"),
    SAP_COMPARE_CONTRACT_PURCHASE_CODE_NO_MATCH(4, "sap严控-合同采购组织未匹配"),
    SAP_COMPARE_EXTRA_PURCHASE_CODE_NO_MATCH(5, "sap严控-函采购组织未匹配"),
    SAP_COMPARE_SEVEN_DAYS_NO_MATCH(6, "sap严控-超7天没有匹配订单"),
    ORDER_CANCEL_FINISH(7, "订单取消完成"),
    SAP_COMPARE_CONTRACT_NEW_NO_MATCH(8, "sap严控-合同新号未匹配"),
    SAP_COMPARE_OFFER_PRIZE_NO_MATCH(9, "sap严控-供价未匹配"),
    SAP_COMPARE_PRIZE_AMOUNT_OVER_LIMIT(10, "sap严控-奖励金额超限"),
    SAP_NO_PAYMENT(11, "没有挂账"),

    ;

    private int code;
    private String msg;

    FailureReasonEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }
}
