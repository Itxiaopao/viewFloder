package com.gome.crp.calc.constants;

/**
 * 是否推送大数据
 */
public enum IsPushBigdataEnum {
    ALREADY_PUSH(1, "已推送"),
    NOT_HAVE_PUSH(0, "未推送"),

    ;

    private int code;
    private String msg;

    IsPushBigdataEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return this.code;
    }

    public String getMsg() {
        return this.msg;
    }

}
