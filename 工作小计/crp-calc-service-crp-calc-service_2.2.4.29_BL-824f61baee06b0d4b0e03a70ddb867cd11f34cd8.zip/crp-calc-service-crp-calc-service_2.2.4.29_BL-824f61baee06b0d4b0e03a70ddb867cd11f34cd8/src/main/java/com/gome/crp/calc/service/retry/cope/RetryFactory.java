package com.gome.crp.calc.service.retry.cope;

import com.gome.crp.calc.constants.RetryJobEnum;
import com.gome.crp.calc.service.retry.cope.impl.*;
import com.gome.crp.calc.service.so.ISOOrderService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * 重推场景
 */
@Component
public class RetryFactory implements InitializingBean {


    @Autowired
    private RetryBigdateService retryBigdateService;
    @Autowired
    private RetryCalcService retryCalcService;
    @Autowired
    private RetryMessageService retryEmailService;
    @Autowired
    private RetryReCalcService retryReCalcService;
    @Autowired
    private RetrySapOnlineService retrySapOnlineService;
    @Autowired
    private RetrySapOfflineService retrySapOfflineService;
    @Autowired
    private RetrySettlementService retrySettlementService;
    @Autowired
    private Map<String, IRetrySceneService> retryCopeMap;
    @Autowired
    private RetrySOCalcService retrySOCalcService;


    // 取处理类
    public IRetrySceneService getCopeService(int type){
        return retryCopeMap.get(type + "");
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        retryCopeMap.put(RetryJobEnum.SETTLEMENT.getCode() + "", retrySettlementService);
        retryCopeMap.put(RetryJobEnum.ORDERCALC.getCode()+"", retryCalcService);
        retryCopeMap.put(RetryJobEnum.BIGDATACALC.getCode() + "", retryBigdateService);
        retryCopeMap.put(RetryJobEnum.SAP_RELEASE_OFFLINE.getCode() + "", retrySapOfflineService);
        retryCopeMap.put(RetryJobEnum.SAP_RELEASE_ONLINE.getCode() + "", retrySapOnlineService);
        retryCopeMap.put(RetryJobEnum.REDO_ORDERCALC.getCode() + "", retryReCalcService);
        retryCopeMap.put(RetryJobEnum.MESSAGE.getCode() + "", retryEmailService);
        retryCopeMap.put(RetryJobEnum.SO_CALC_RETRY.getCode() + "", retrySOCalcService);
    }
}
