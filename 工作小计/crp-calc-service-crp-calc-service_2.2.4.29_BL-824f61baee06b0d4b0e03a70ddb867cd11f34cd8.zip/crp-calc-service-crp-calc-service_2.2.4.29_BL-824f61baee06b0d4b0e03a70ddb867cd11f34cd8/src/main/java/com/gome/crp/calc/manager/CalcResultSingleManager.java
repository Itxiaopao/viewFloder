package com.gome.crp.calc.manager;

import com.gome.crp.calc.dto.combiDto.CalcResultRecordDto;
import com.gome.crp.calc.dto.combiDto.SceneYDto;
import com.gome.crp.calc.service.scene.impl.SceneYServiceImpl;
import com.gome.crp.calc.mybatis.mapper.CalcRecordMapper;
import com.gome.crp.calc.mybatis.mapper.CalcResultMapper;
import com.gome.crp.calc.mybatis.model.CalcRecord;
import com.gome.crp.calc.mybatis.model.CalcResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CalcResultSingleManager {

    @Autowired
    private CalcResultMapper calcResultMapper;
    @Autowired
    private CalcRecordMapper calcRecordMapper;
    @Autowired
    private SceneYServiceImpl sceneYServiceImpl;

    @Transactional
    public void doSaveCalcResult(List<CalcResultRecordDto> calcResultRecordDtoList) {
        for (CalcResultRecordDto calcResultRecordDto : calcResultRecordDtoList) {
            CalcResult calcResult = calcResultRecordDto.getCalcResult();
            calcResultMapper.insert(calcResult);

            CalcRecord calcRecord = calcResultRecordDto.getCalcRecord();
            calcRecordMapper.insert(calcRecord);

            SceneYDto sceneYDto = calcResultRecordDto.getSceneYDto();
            if (sceneYDto != null) {
                sceneYServiceImpl.saveOrUpdateSceneY(sceneYDto.getOrderId(), sceneYDto.getUserId(), sceneYDto.getPlanId(), sceneYDto.getStaffCode(), sceneYDto.getEndTime(), sceneYDto.getPaymentMoney());
            }
        }

    }

    @Transactional
    public void updateByParam(CalcResult calcResult) {
        calcResultMapper.updateById(calcResult);
    }
}
