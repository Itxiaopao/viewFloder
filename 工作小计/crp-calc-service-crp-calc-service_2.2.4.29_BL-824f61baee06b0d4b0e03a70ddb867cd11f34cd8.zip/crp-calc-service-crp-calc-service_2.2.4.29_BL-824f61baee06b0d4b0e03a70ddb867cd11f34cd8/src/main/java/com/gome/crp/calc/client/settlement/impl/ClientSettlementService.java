package com.gome.crp.calc.client.settlement.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.crp.calc.client.settlement.IClientSettlementService;
import com.gome.crp.settlement.facade.ICrpCalcFacade;
import com.gome.crp.settlement.facade.vo.SaReverseOrderDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ClientSettlementService implements IClientSettlementService {

    @Autowired
    private ICrpCalcFacade crpCalcFacade;



    @Override
    public boolean receiveReverseOrder(List<SaReverseOrderDto> saReverseOrderList) {
        boolean ret = false;
        String text = JSONObject.toJSONString(saReverseOrderList);
        try {
        	log.info(String.format("推送结算接口Dubbo, 参数:%s", JSONObject.toJSONString(saReverseOrderList)));
            Map<String, Object> result = crpCalcFacade.receiveReverseOrder(saReverseOrderList);
            log.info(String.format("推送结算接口Dubbo, 结果:%s", JSONObject.toJSONString(result)));
            ret = (boolean) result.get("success");
        } catch (Exception e) {
            log.error(String.format("推送结算接口Dubbo, param: orderCalcDto:%s", text), e);
        }
        return ret;
    }


}
