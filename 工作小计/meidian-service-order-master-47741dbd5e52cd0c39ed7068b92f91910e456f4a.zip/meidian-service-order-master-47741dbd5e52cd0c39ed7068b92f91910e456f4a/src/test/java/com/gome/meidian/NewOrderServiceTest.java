package com.gome.meidian;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.entity.OrderInfo;
import com.gome.meidian.entity.OrderListParam;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.vo.Pagination;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;

import java.util.Date;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class NewOrderServiceTest {

    @Autowired

    INewOrderService iNewOrderService;

    @Autowired
    Gcache gcache;

    @Test
    public void getMyGradesTest() {
        OrderInfo orderInfo = new OrderInfo();
        long serialVersionUID = OrderInfo.getSerialVersionUID();
        ResultEntity<Boolean> result = iNewOrderService.savePickGoods("2570318418",100042888004L,1);
        System.out.println(JSON.toJSON(result));

    }

    @Test
    public void getOrderListTest() {


        OrderListParam param = new OrderListParam();
        //param.setStatus(1);
       // "bizSource":"2","dateState":"2","endDate":1577376000000,"filter":"","orderStatus":900,"pageNo":1,"pageSize":14,"startDate":1577289600000,"userId":100049055308}
       param.setBizSource("2");
       param.setDateState("2");
       param.setStartDate(new Date(1577289600000L));
       param.setEndDate(new Date(1577376000000L));
       param.setPageNo(1);
       param.setPageSize(14);
       param.setUserId(100049055308L);
        ResultEntity<Pagination<OrderInfo>> orderList = iNewOrderService.getOrderList(param);
        System.out.println();
    }

    @Test
    public void getUserAccumAmount() {

        iNewOrderService.getUserOrderList(100049064004L, "1", 1, 10);
        iNewOrderService.getUserAccumAmount(100049064004L, "1");

        System.out.println();
    }

    @Test
    public void getUserOrderList() {

        iNewOrderService.getUserOrderList(100049055306L, "4", 1, 10);

        System.out.println();
    }
    

    @Test
    public void getMyAward() {
        iNewOrderService.getMasAward(199720249L, 901, DateUtils.getCurrentMonth(), DateUtils.getNextMonth(), 1, 10);
        System.out.println();
    }


}
