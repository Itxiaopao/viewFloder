package com.gome.meidian;


import com.gome.meidian.entity.OrderCountResponse;
import com.gome.meidian.mapper.readorder.OrderOccurReadMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class ExportOrderOfMidTest {
    @Autowired
    private OrderOccurReadMapper orderOccurMapper;
    @Test
    public void report(){
       ArrayList<String> list = new ArrayList<>();
            try {
            //1、获取文件输入流
            InputStream inputStream = new FileInputStream("C:\\活动美店.xlsx");
            //2、获取Excel工作簿对象
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            //3、得到Excel工作表对象
            XSSFSheet sheetAt = workbook.getSheetAt(0);
                //4、循环读取表格数据
            System.out.println("excel一共："+sheetAt.getLastRowNum());
            HashMap<String, String> hashMap = new HashMap<String, String>();
            ArrayList<String> arrayList = new ArrayList<>();
            for (Row row : sheetAt) {
                //首行（即表头）不读取
                if (row.getRowNum() == 0) {
                continue;
                }
                //读取当前行中单元格数据，索引从0开始
                String shopName = row.getCell(0).getStringCellValue();
                row.getCell(1).setCellType(Cell.CELL_TYPE_STRING);
                String mid = row.getCell(1).getStringCellValue();
                arrayList.add(mid);
                System.out.println("key"+mid+":"+"value"+shopName+"#"+mid);
                //key56657:value海南琼海银海路店#56657
                hashMap.put(mid,shopName+"#"+mid);
            }
            HashMap<String, Object> queryHashMap = new HashMap<>(3);
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            queryHashMap.put("startDate","2019-01-01 00:00:00");
            queryHashMap.put("endDate","2019-02-13 00:00:00");
            String[] splitStr = StringUtils.strip(arrayList.toString(), "[]").split(",");
            String temp = convertList(splitStr);
            queryHashMap.put("mid", temp);
            ArrayList<OrderCountResponse> orderCountResponses = orderOccurMapper.queryGMVOfMid(queryHashMap);
            for (OrderCountResponse thisObj:orderCountResponses) {
                String tempMid = thisObj.getGroupName();
                String buyNum = thisObj.getBuyNum()+"";//订单量
                String orderNum = thisObj.getOrderNum()+"";//销售额
                String orderValue = hashMap.get(tempMid);
                String resultStr = orderValue+"#"+orderNum+"#"+buyNum;
                hashMap.put(tempMid,resultStr);
            }
            //写Excel
            XSSFWorkbook writeWorkBook = new XSSFWorkbook();
            XSSFSheet sheet = writeWorkBook.createSheet();
            XSSFRow row = sheet.createRow(0);
            row.createCell(0).setCellValue("门店名称");
            row.createCell(1).setCellValue("Mid");
            row.createCell(2).setCellValue("销售额");
            row.createCell(3).setCellValue("销量");
            Iterator<Map.Entry<String, String>> iterator = hashMap.entrySet().iterator();
            int index = 1;
            while(iterator.hasNext()){
                Map.Entry<String, String> next = iterator.next();
                System.out.println(next.getKey()+"*****"+next.getValue());
                String value = next.getValue();
                String[] split = value.split("#");
                int length = split.length;
                XSSFRow tempRow = sheet.createRow(index);
                for (int i = 0 ,j = split.length ; i < j ; i++){
                    tempRow.createCell(0).setCellValue(split[0]);
                    tempRow.createCell(1).setCellValue(split[1]);
                    if(length>=3){
                        tempRow.createCell(2).setCellValue(split[2]);
                    }else{
                        tempRow.createCell(2).setCellValue(0);
                    }
                    if(length>=4) {
                        tempRow.createCell(3).setCellValue(split[3]);
                    }else{
                        tempRow.createCell(3).setCellValue(0);
                    }
                }
                index++;
            }
            String fileNameExport = "E:\\0213报表统计.xlsx";
            FileOutputStream fo = new FileOutputStream(fileNameExport); // 输出到文件
            writeWorkBook.write(fo);
            fo.close();
                //5、关闭流
        }catch(Exception e){
                e.printStackTrace();
        }
    }
    //写excel测试
    @Test
    public void export(){
        //导出
        //1.在内存中创建一个excel文件
        XSSFWorkbook workbook = new XSSFWorkbook();
        //2.创建工作簿
        XSSFSheet sheet = workbook.createSheet();
        //3.创建行
        for(int i = 0 ; i <=20 ;i++){
            XSSFRow row = sheet.createRow(i);
            row.createCell(0).setCellValue("门店名称");
            row.createCell(1).setCellValue("Mid");
            row.createCell(2).setCellValue("销售额");
            row.createCell(3).setCellValue("销量");
            row.createCell(4).setCellValue("销量1");
        }

        //4.数据填充
        //5.创建文件名
        String fileName = "E:\\报表统计test.xlsx";
        try {
            FileOutputStream fo = new FileOutputStream(fileName); // 输出到文件
            workbook.write(fo);
            fo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Test
    public void testOfMidList(){
        HashMap<String, Object> queryHashMap = new HashMap<>(3);
        Calendar instance = Calendar.getInstance();
        instance.set(2019,00,1,00,00,00);
        Calendar instance1 = Calendar.getInstance();
        instance1.set(2019,01,13,00,00,00);
        ArrayList<String> arrayList = new ArrayList<>();
        for(int i = 0 ,j = 10 ; i < j ; i++){
            arrayList.add("100"+i);
        }
        queryHashMap.put("startDate",instance.getTime());
        queryHashMap.put("endDate",instance1.getTime());
        queryHashMap.put("mid",arrayList);
        String object = queryHashMap.get("mid").toString();
        String[] splitStr = StringUtils.strip(object, "[]").split(",");
        String temp = convertList(splitStr);
        queryHashMap.put("mid", temp);
        ArrayList<OrderCountResponse> orderCountResponses = orderOccurMapper.queryGMVOfMid(queryHashMap);
    }

    private String convertList(String[] params) {
        String temp = "";
        int size = params.length;
        for (int i = 0 ; i < size ; i++) {
            if(i != size - 1) {
                temp += "'"+params[i].trim()+"',";
            }else {
                temp += "'"+params[i].trim()+"'";
            }
        }
        return temp;
    }
    @Test
    public void dealWithOrderException(){
        String pathname = "C:\\meidian-service-order_20190529.log"; // 绝对路径或相对路径都可以，写入文件时演示相对路径,读取以上路径的input.txt文件
        //防止文件建立或读取失败，用catch捕捉错误并打印，也可以throw;
        //不关闭文件会导致资源的泄露，读写文件都同理
        //Java7的try-with-resources可以优雅关闭文件，异常时自动关闭文件；详细解读https://stackoverflow.com/a/12665271
        try (FileReader reader = new FileReader(pathname);
             BufferedReader br = new BufferedReader(reader) // 建立一个对象，它把文件内容转成计算机能读懂的语言
        ) {
            String line;
            //网友推荐更加简洁的写法
            System.out.println("开始时间:"+System.currentTimeMillis());
            while ((line = br.readLine()) != null) {
                if(line.contains("解析异常,失败msgId")) {
                    // 一次读入一行数据
                    System.out.println(line);
                    String[] split = line.split(":");
                    String[] split1 = split[1].split(",");
                    System.out.println(split1[0]);
                }
            }
            System.out.println("结束时间:"+System.currentTimeMillis());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    @Test
    public void testSql(){
        ArrayList<String> list = new ArrayList<>();
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\insertMasLoc.txt"));
            String sql = "insert into hub_process_matrix (ID,RULE_NAME, COLUMN1, COLUMN2, COLUMN3, COLUMN4, COLUMN5, COLUMN6, COLUMN7, COLUMN8, COLUMN9, COLUMN10, COLUMN11, COLUMN12, COLUMN13, COLUMN14, COLUMN15, OPERATION_CODE, HUB_CODE, MAS_LOC, LINE_HAUL, CARRIER_CODE, PRIORITY, SORTING_CENTER_CODE, DA_ID, SELF_PICKUP_FLAG, INSERT_BY, INSERT_DATE, MODIFIED_BY, MODIFIED_DATE, LINE_HAUL2, DELIVERYMAN_ID, ENABLED, DELIVERY_LEAD_TIME, LINEHAUL_DAY, DELIVERY_DAY, RETURN_DAY, PICKUP_DAY, IS_CASH, IS_POS)\n" +
                    "values ('autoid','CCC_RULE', 'masloc0', 'ALL', 'ALL', 'ALL', '2010-01-01 00:00:00', '2010-01-01 23:59:59', 'ALL', 'ALL', 'ALL', 'ALL', '2099-12-31 00:00:00', 'ALL', 'ALL', 'ALL', 'ALL', 'VLSP', 'C071', 'masloc1', 'VLSP', null, 1, 'P001', null, 'N', 'DRG_ADMIN', null, 'DRG_ADMIN', null, null, null, 1, 0.00, 0, 0, 0, 70, null, null);";
            //1、获取文件输入流
            InputStream inputStream = new FileInputStream("C:\\masloc.xlsx");
            //2、获取Excel工作簿对象
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            //3、得到Excel工作表对象
            XSSFSheet sheetAt = workbook.getSheetAt(0);
            //4、循环读取表格数据
            System.out.println("excel一共："+sheetAt.getLastRowNum());
            HashMap<String, String> hashMap = new HashMap<String, String>();
            ArrayList<String> arrayList = new ArrayList<>();
            bw.write("excel一共："+sheetAt.getLastRowNum());
            bw.newLine();
            for (Row row : sheetAt) {
                //首行（即表头）不读取
//                if (row.getRowNum() == 0) {
//                    continue;
//                }
                //读取当前行中单元格数据，索引从0开始
                row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
                String id = row.getCell(0).getStringCellValue();
                String masloc = row.getCell(1).getStringCellValue();
                String result1 = sql.replace("autoid", id);
                String result2 = result1.replace("masloc0", masloc);
                String result3 = result2.replace("masloc1", masloc);
                System.out.println(result3);
                bw.write(result3);
                bw.newLine();
                bw.flush();
            }
            bw.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void testSys(){
        String sql = "insert into hub_process_matrix (ID,RULE_NAME, COLUMN1, COLUMN2, COLUMN3, COLUMN4, COLUMN5, COLUMN6, COLUMN7, COLUMN8, COLUMN9, COLUMN10, COLUMN11, COLUMN12, COLUMN13, COLUMN14, COLUMN15, OPERATION_CODE, HUB_CODE, MAS_LOC, LINE_HAUL, CARRIER_CODE, PRIORITY, SORTING_CENTER_CODE, DA_ID, SELF_PICKUP_FLAG, INSERT_BY, INSERT_DATE, MODIFIED_BY, MODIFIED_DATE, LINE_HAUL2, DELIVERYMAN_ID, ENABLED, DELIVERY_LEAD_TIME, LINEHAUL_DAY, DELIVERY_DAY, RETURN_DAY, PICKUP_DAY, IS_CASH, IS_POS)\n" +
                "values ('autoid','CCC_RULE', 'masloc0', 'ALL', 'ALL', 'ALL', '2010-01-01 00:00:00', '2010-01-01 23:59:59', 'ALL', 'ALL', 'ALL', 'ALL', '2099-12-31 00:00:00', 'ALL', 'ALL', 'ALL', 'ALL', 'VLSP', 'C071', 'masloc1', 'VLSP', null, 1, 'P001', null, 'N', 'DRG_ADMIN', null, 'DRG_ADMIN', null, null, null, 1, 0.00, 0, 0, 0, 70, null, null);";
        String autoid = sql.replace("autoid", "2008524171");

        String replace = autoid.replace("masloc0", "A0011");
        String replace1 = replace.replace("masloc1", "A0011");
        System.out.println(replace1);
    }

    @Test
    public void writeFile() {
        try{
            ArrayList<String> array = new ArrayList<String>();
            array.add("hello");
            array.add("world");
            array.add("java");
            //封装目的地
            BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\a.txt"));
            //遍历集合
            for (String s : array) {
                //写数据
                bw.write(s);
                bw.newLine();
                bw.flush();
            }
            //释放资源
            bw.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void readExcel(){
        ArrayList<String> list = new ArrayList<>();
        try {
            //1、获取文件输入流
            InputStream inputStream = new FileInputStream("C:\\活动美店.xlsx");
            //2、获取Excel工作簿对象
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            //3、得到Excel工作表对象
            XSSFSheet sheetAt = workbook.getSheetAt(0);
            //4、循环读取表格数据
            System.out.println("excel一共："+sheetAt.getLastRowNum());
//            for (Row row : sheetAt) {
//                //首行（即表头）不读取
//                if (row.getRowNum() == 0) {
//                    continue;
//                }
                //读取当前行中单元格数据，索引从0开始
                XSSFRow row = sheetAt.getRow(6);
                String shopName = row.getCell(0).getStringCellValue();
                String mid = row.getCell(1).getStringCellValue();
                System.out.println("key"+mid+":"+"value"+shopName+"#"+mid);

//            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Test
    public void readSXSSFWorkbook(){
        ArrayList<String> list = new ArrayList<>();
        try {
            long l = System.currentTimeMillis();
            //1、获取文件输入流
            InputStream inputStream = new FileInputStream("C:\\活动美店.xlsx");
            //2、获取Excel工作簿对象
            XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
            //3、得到Excel工作表对象
            XSSFSheet sheetAt = workbook.getSheetAt(0);
            //4、循环读取表格数据
            System.out.println("excel一共："+sheetAt.getLastRowNum());
            //读取当前行中单元格数据，索引从0开始
            int count = 0;
            for(int i = 0 ; i < sheetAt.getLastRowNum() ; i++) {
                XSSFRow row = sheetAt.getRow(i);
                String shopName = row.getCell(0).getStringCellValue();
                row.getCell(1).setCellType(Cell.CELL_TYPE_STRING);
                String mid = row.getCell(1).getStringCellValue();
                System.out.println("key"+mid+":"+"value"+shopName+"#"+mid);
                count++;
            }
            long l1 = System.currentTimeMillis();
            long time = l1 - l;System.out.println("共耗时："+time+":"+count);

//            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
