package com.gome.meidian;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.service.GenericService;
import com.alibaba.fastjson.JSON;
import com.gome.common.util.ResourceUtils;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.service.IcSmDqlStaffService;
import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoDescFacade;
import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author limenghui-ds
 * @create 2019-10-26 14:19
 */
@Slf4j
public class RemoteIntefaceTest {

    @Test
    public void user(){
        // dubbo 泛化调用
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName("meidian-service-order");
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(
                "10.58.22.192:2181,10.58.22.193:2181,10.58.22.191:2181");
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连 测试环境
        reference.setUrl("dubbo://10.115.37.197:20880?scope=remote");
        reference.setRegistry(registryConfig);
        //                reference.setVersion("3.0.0");
        //                reference.setGroup("techisan-beta");
        reference.setInterface(IOrderShopService.class);
        //true声明为泛化接口
        reference.setGeneric(true);

        /*ReferenceConfig实例很重，封装了与注册中心的连接以及与提供者的连接，
        需要缓存，否则重复生成ReferenceConfig可能造成性能问题并且会有内存和连接泄漏。
        API方式编程时，容易忽略此问题。
        这里使用dubbo内置的简单缓存工具类进行缓存*/


        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        // 泛化调用,接口方法名称+方法参数类型+方法参数值
        Map<String, Object> result = (Map<String, Object>) genericService
                .$invoke("findOrganizationByUserId", new String[] {"java.lang.Long"}, new Object[] { 72002016890L});

        //Map封装pojo的参数
        //        Map<String, Object> param = new HashMap<>();
        //        param.put("userId",77818001982l);
        //        param.put("vshopIdentity",3);
        //        param.put("vshopId",861512l);
        //        Map<String, Object> result = (Map<String, Object>) genericService
        //                .$invoke("updateVshop", new String[] { "com.gomeo2o.facade.vshop.entity.VshopInfo" }, new Object[] { param });
        System.err.println("结果是："+ JSON.toJSONString(result));

    }

    @Test
    public void vshopInfo() {
        // dubbo 泛化调用
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName("venus-vshop");
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(
                "10.58.22.192:2181,10.58.22.193:2181,10.58.22.191:2181,10.58.166.145:2181,10.58.166.146:2181,10.58.188.146:2181,10.58.188.147:2181,10.58.188.148:2181,10.58.166.147:2181,10.58.166.148:2181");
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连
        reference.setUrl("dubbo://10.125.140.109:30003?scope=remote");
        reference.setRegistry(registryConfig);
                        reference.setVersion("3.0.0");
        //                reference.setGroup("techisan-beta");
        reference.setInterface(VshopInfoDescFacade.class);
        //true声明为泛化接口
        reference.setGeneric(true);

        /*ReferenceConfig实例很重，封装了与注册中心的连接以及与提供者的连接，
        需要缓存，否则重复生成ReferenceConfig可能造成性能问题并且会有内存和连接泄漏。
        API方式编程时，容易忽略此问题。
        这里使用dubbo内置的简单缓存工具类进行缓存*/


        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        List<VshopInfoDesc> list = packageData();

        Map<String, Object> result = (Map<String, Object>) genericService
                .$invoke("synVshopInfoDesc", new String[] { "java.util.List" }, new Object[] { list });
        System.err.println("结果是："+result);
    }




    public List<VshopInfoDesc> packageData(){
        List<Long> list=Lists.newArrayList(77818001982L, 61263710240L, 81709191691L, 54249830335L, 72032760079L, 72006657874L, 72714007966L);
        List<VshopInfoDesc> descs = Lists.newArrayList();
        for (Long dc : list) {
            VshopInfoDesc vshopInfoDesc = new VshopInfoDesc();
            vshopInfoDesc.setUserId(dc);
            vshopInfoDesc.setStoreCode("A00V");
            vshopInfoDesc.setOrganization("1001");
            vshopInfoDesc.setRewardStatus(1);
            descs.add(vshopInfoDesc);
        }
        return descs;

    }

    @Test
    public void staffDataHandler() {
        // dubbo 泛化调用
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName("meidian-service-order");
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(
                "10.58.22.192:2181,10.58.22.193:2181,10.58.22.191:2181,10.58.166.145:2181,10.58.166.146:2181,10.58.188.146:2181,10.58.188.147:2181,10.58.188.148:2181,10.58.166.147:2181,10.58.166.148:2181");
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连
        reference.setUrl("dubbo://10.115.41.56:20880?scope=remote");
        reference.setRegistry(registryConfig);
        reference.setInterface(IcSmDqlStaffService.class);
        //true声明为泛化接口
        reference.setGeneric(true);

        /*ReferenceConfig实例很重，封装了与注册中心的连接以及与提供者的连接，
        需要缓存，否则重复生成ReferenceConfig可能造成性能问题并且会有内存和连接泄漏。
        API方式编程时，容易忽略此问题。
        这里使用dubbo内置的简单缓存工具类进行缓存*/

        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        // 泛化调用,接口方法名称+方法参数类型+方法参数值
        Map<String, Object> result = (Map<String, Object>) genericService.$invoke("staffDataHandle", new String[] {}, new Object[] {});
        log.info("业绩还原的结果是 {} ",JSON.toJSONString(result));
    }
    @Test
    public void order() {
        // dubbo 泛化调用
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName("meidian-service-order");
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setAddress(
                "10.58.22.192:2181,10.58.22.193:2181,10.58.22.191:2181,10.58.166.145:2181,10.58.166.146:2181,10.58.188.146:2181,10.58.188.147:2181,10.58.188.148:2181,10.58.166.147:2181,10.58.166.148:2181");
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连
//        reference.setUrl("dubbo://10.115.37.197:20880?scope=remote");
        reference.setUrl("dubbo://10.115.41.56:20880?scope=remote");
        reference.setRegistry(registryConfig);
        //        reference.setVersion("3.0.0");
        reference.setInterface(IOrderShopService.class);
        //true声明为泛化接口
        reference.setGeneric(true);

        /*ReferenceConfig实例很重，封装了与注册中心的连接以及与提供者的连接，
        需要缓存，否则重复生成ReferenceConfig可能造成性能问题并且会有内存和连接泄漏。
        API方式编程时，容易忽略此问题。
        这里使用dubbo内置的简单缓存工具类进行缓存*/

        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        List<Long> userIds = getUserId();
        Map<String, String> resultMap = new HashMap<>();
        for (Long uid : userIds) {
            // 泛化调用,接口方法名称+方法参数类型+方法参数值
            Map<String, Object> result = (Map<String, Object>) genericService.$invoke("getStaffInfoWithParam",
                    new String[] { "java.lang.Long", "java.lang.Long", "java.lang.Long", "java.util.List",
                            "java.lang.String" }, new Object[] { uid, null, null, Lists.newArrayList(), null });
            Map<String, Object> businessObj = (Map<String, Object>) result.get("businessObj");
            Integer shareType = (Integer) businessObj.get("shareType");
            Map<String, Object> staffInfo1 = (Map<String, Object>) businessObj.get("staffInfo");
            String staffCode = null;
            String storeCode = null;
            if (null != staffInfo1) {
                staffCode = (String) staffInfo1.get("staffCode");
                storeCode = (String) staffInfo1.get("storeCode");
            }
                resultMap.put(String.valueOf(uid), "shareType:" + shareType + " - staffCode:" + staffCode + " - storeCode:" + storeCode);
//            System.err.println("结果是:" + JSON.toJSONString(resultMap));
        }
        log.info("业绩还原的结果是 {} ",JSON.toJSONString(resultMap));
    }

    public void writeFile(){
        Map<String, String> resultMap1 = new HashMap<>();
        for (int i = 0; i < 1000; i++) {
            resultMap1.put(String.valueOf(i), "数据测试");
        }
        //输出到文件
        final File newFile = new File("classpath:resultMap.properties");
        try
        {
//            Files.asCharSink(new File("classpath:resultMap.properties"), Charsets.UTF_8).write("测试数据出不来呢");
            Files.append("咋出不来呢",newFile,Charsets.UTF_8); //追加文件
        }
        catch (IOException e)
        {
            System.err.println("异常：" + e);
        }
    }

    public List<VshopInfoDesc> getVshopInfoDesc(){
        String content = null;
        try {
            content = Files.toString(ResourceUtils.getFile("classpath:read2.properties"),
                    Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(content);
        List<String> split = Lists.newArrayList(content.split(";"));
        List<VshopInfoDesc>  list= Lists.newArrayList();
        for (String s : split) {
            VshopInfoDesc desc = new VshopInfoDesc();
            String[] split1 = s.split(",");
            desc.setUserId(Long.valueOf(split1[0]));
            desc.setStoreCode(split1[1]);
            desc.setOrganization(split1[2]);
            list.add(desc);
        }
        return list;
    }

    public List<Long> getUserId(){
        String content = null;
        try {
            content = Files.toString(ResourceUtils.getFile("classpath:read2.properties"),
                    Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(content);
        List<String> split = Lists.newArrayList(content.split(","));
        List<Long> strings = Lists.newArrayList();
        for (String s : split) {
            strings.add(Long.valueOf(s));
        }
        System.err.println("集合的长度是：" + strings.size());
        return strings;
    }

    @Test
    public void test(){
        String content = null;
        try {
            content = Files.toString(ResourceUtils.getFile("classpath:read2.properties"),
                    Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(content);
        List<String> split = Lists.newArrayList(content.split(","));
        List<Long> strings = Lists.newArrayList();
        for (String s : split) {
            strings.add(Long.valueOf(s));
        }
        System.err.println("集合的长度是：" + strings.size());
    }

    @Test
    public void test02(){
        String content = null;
        try {
            content = Files.toString(ResourceUtils.getFile("classpath:read2.properties"),
                    Charset.forName("UTF-8"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println(content);
        List<String> split = Lists.newArrayList(content.split(";"));
        List<VshopInfoDesc>  list= Lists.newArrayList();
        for (String s : split) {
            VshopInfoDesc desc = new VshopInfoDesc();
            String[] split1 = s.split(",");
            desc.setUserId(Long.valueOf(split1[0]));
            desc.setStoreCode(split1[1]);
            desc.setOrganization(split1[2]);
            list.add(desc);
        }
        System.err.println("集合的长度是：" + list.size());
        System.err.println("集合的长度是：" + list);

    }

}
