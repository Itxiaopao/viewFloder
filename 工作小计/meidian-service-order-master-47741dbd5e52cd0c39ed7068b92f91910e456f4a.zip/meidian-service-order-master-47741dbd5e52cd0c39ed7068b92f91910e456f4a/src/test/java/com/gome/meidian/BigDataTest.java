package com.gome.meidian;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.dao.OrderDeliveryBodyDao;
import com.gome.meidian.dao.OrderDetailDao;
import com.gome.meidian.dao.OrderRebateDetailDao;
import com.gome.meidian.dto.GoodsDto;
import com.gome.meidian.entity.*;
import com.gome.meidian.mapper.order.OrderOccurMapper;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.service.IOrderRebateService;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.service.biz.*;
import com.gome.meidian.service.impl.IcSmDqlStaffServiceImpl;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MogOrderDetail;
import com.gome.meidian.vo.MogOrderInfo;
import com.gome.meidian.vo.MogOrderRebateDetail;
import com.gome.stage.interfaces.whale.IProductInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class)
@EnableAutoConfiguration
@Slf4j
public class BigDataTest {

	@Autowired
	IProductInfoService iProductInfoService;

	@Autowired
	ReceiveOrderBiz receiveOrderBiz;

	@Autowired
	ReceiveOrderCoreBiz receiveOrderCoreBiz;

	@Autowired
	IOrderRebateService iOrderRebateService;
	@Autowired
	MedianUserBiz medianUserBiz;

	@Autowired
	IcSmDqlStaffServiceImpl icSmDqlStaffService;

	@Autowired
	INewOrderService iNewOrderService;

	@Autowired
	private IOrderShopService orderShopServiceImpl;

	@Autowired
	Gcache gcache;
	@Autowired
	OrderRebateDetailDao orderRebateDetailDao;

	@Autowired
	OrderDetailDao orderDetailDao;

	@Autowired
    OrderOccurMapper orderOccurMapper;

	@Autowired
	OrderDeliveryBodyDao orderDeliveryBodyDao;

	@Autowired
	private INewOrderService newOrderService;
	@Autowired
	private CheckSaleRaceUtils checkSaleRaceUtils;

	public static void main(String[] args) {
		String userId = "45687";
		List<GoodsDto> goodsList = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		goodsDto.setRetailId("");
		goodsDto.setCategoryFirstId("1233");
		GoodsDto goodsDto2 = new GoodsDto();
		goodsDto2.setRetailId(null);
		GoodsDto goodsDto3 = new GoodsDto();
		goodsDto3.setRetailId("12323");
		GoodsDto goodsDto4 = new GoodsDto();
		goodsDto2.setRetailId(null);
		goodsList.add(goodsDto);
		goodsList.add(goodsDto2);
		goodsList.add(goodsDto3);
		goodsList.add(goodsDto4);
		Set<String> collect = goodsList.stream().map(item -> StringUtils.isEmpty(item.getRetailId()) ? userId : item.getRetailId()).collect(Collectors.toSet());
		boolean add = collect.add("45687");
		System.out.println(add);
		System.out.println(JSON.toJSON(collect));
	}



	@Test // 测试修改和 查询
	public void Tes2t() throws Exception {
		boolean b = checkSaleRaceUtils.checkActivityIsEffective();
		System.out.println(b);
	}

	public void tes2()  {
		throw new RuntimeException("自定义异常");
	}


	public void  defual(){
    	MogOrderDetail detail = new MogOrderDetail();
		detail.setId("1");
		detail.setOrderId(11358853511L);
		detail.setCommerceId(4807041003L);
		detail.setDeliveryId("2776971284");
		detail.setKid("TUAN_1026");
		detail.setUserId(75766434311L);
		detail.setUserType(3);
		detail.setParentUserId(75766434311L);
		detail.setTopLeaderUser(75766434311L);
		detail.setUserIdRelation(Arrays.asList(75766434311L));
		detail.setSkuId("1130544632");
		detail.setSkuNo("241212");
		detail.setSkuName("21212");
		detail.setItemId("12121");
		detail.setBuyNum(2);
		detail.setPriceTotal(10000L);
		detail.setUnitPrice(500L);
		detail.setMerchantId("12454564");
		detail.setSiteId("124");
		detail.setOrderStatus(1);
		detail.setShowStatus(1);
		detail.setOrderCreateTime(new Date());
		detail.setOrderTime(new Date());
		detail.setAfterSalesOrderId(123456L);
		detail.setCategoryFirstId("1");
		detail.setCategoryFirstName("1");
		detail.setCategorySecondId("2");
		detail.setCategorySecondName("2");
		detail.setCategoryThirdId("3");
		detail.setCategoryThirdName("3");
		detail.setCategoryFourthId("4");
		detail.setCategoryFourthName("4");
		detail.setMarketingOrganizationId("123232");
		detail.setCompanyCode("123235454");
		detail.setOrderItemId("1232157676");
		detail.setSellerId("123232");
		detail.setSourceType(1);
		detail.setSpuId("2323232");
		detail.setIsWarranty("0");
		detail.setShopCode("1232323");
		detail.setAddressFirst("a1");
		detail.setAddressSecond("a2");
		detail.setAddressThird("a3");
		detail.setAddressFourth("a4");
		detail.setBusinessType(1);
		detail.setBrandCode("2");
		detail.setChannelType("3");
		detail.setMerchantName("1");
		detail.setRegionId("123");
		detail.setRegionName("232");
		detail.setBrandId("1232");
		detail.setBrandName("12323");
		detail.setBrandSecondId("12323");
		detail.setBrandSecondName("12323");
		detail.setIsElectric(1);
		detail.setPurchaseType("2323");
		detail.setSaleType("1232");
		detail.setSaleChannel("1232");
		detail.setCmsEffective(1);
		detail.setBusinessCenter("232");
		detail.setBusinessCategroy("2323");
		detail.setBSaleA(1);
		detail.setCreateTime(new Date());
		detail.setUpdateTime(new Date());
		orderDetailDao.saveRecord(detail);
		MogOrderRebateDetail orderRebateDetail = new MogOrderRebateDetail();
		orderRebateDetail.setId("1");
		orderRebateDetail.setOrderId(11358853511L);
		orderRebateDetail.setDeliveryId("2776971284");
		orderRebateDetail.setSkuId("1130544632");
		orderRebateDetail.setCommMoney(500L);
		orderRebateDetail.setStatus(1);
		orderRebateDetail.setOrderTime(new Date());
		orderRebateDetailDao.saveRecord(orderRebateDetail);
	}

	@Test // 测试修改和 查询
	public void TestSyncData() {
	//	medianUserBiz.getUserInfo(1000L);
		IcSmDqlStaff staff=new IcSmDqlStaff();
		staff.setZxUid(100049110601l);
		//icSmDqlStaffService.updateVshopInfoIdentity(staff);
	 	icSmDqlStaffService.syncIcSmStaffToVshopInfo(0);
	}

	@Test // 同步线下数据
	public void syncIcSmStaffToVshopInfo() {
		//icSmDqlStaffService.syncIcSmStaffToVshopInfo(1);
	String str=	orderShopServiceImpl.findOrganizationByUserId(1213l);
	System.out.println("result"+str);
	}


	@Test // 测试修改和 查询
	public void TestMogDb() {
		MogOrderInfo mogInfo = receiveOrderBiz.getOrderInfoById(11459838409L, "1130005175", "");
		mogInfo.setAwardMoney(100l);
		mogInfo.setCommMoney(25l);
		receiveOrderBiz.updateOrderInfo(mogInfo);
		System.out.println(mogInfo);
	}

	@Test // 测试修改和 查询
	public void TestMogDbList() {
		OrderRebateParm parm = new OrderRebateParm();
		parm.setDeliveryId("2570249061");
		parm.setOrderId(19015089115L);
		parm.setPid(1000L);
		parm.setSkuId("pop8003764524");
		parm.setRebateAmount(0L);
		parm.setRewardAmount(0L);
		parm.setOrderStatus(6);
		iOrderRebateService.orderRebateSync(parm);

		/*
		 * MogOrderInfo mogInfo=receiveOrderBiz.getOrderInfoById(11459838409L,
		 * "1130005175"); mogInfo.setAwardMoney(100l); mogInfo.setCommMoney(25l);
		 * receiveOrderBiz.savePickGoods(mogInfo);
		 * System.out.println(mogInfo);
		 */
	}
	Long userId=65788426447L;
	@Test
	public void testQian() {
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		iNewOrderService.getMyGrades(userId, "1");
		System.out.println();
	}
	// 测试未支付状态的订单
	@Test
	public void testouge() {
		String json = getFileContent("WaitPay.txt");
		String msgId = UUID.randomUUID().toString();
		receiveOrderCoreBiz.processOrder(msgId, json);

	}


	// 测试拆单后的订单
	@Test
	public void Payed_testMQ() {
//		gcache.del(Constant.ORDER_CREATION_TIME_STR_CACHE_PREFIX + 19015102929L);
		String json = getFileContent("Payed.txt");
		String msgId = UUID.randomUUID().toString();
		receiveOrderCoreBiz.processOrder(msgId, json);

	}

	// 测试拆单后的订单
	@Test
	public void WaitPay_OneSku() {
		String json = getFileContent("WaitPay_OneSku.txt");
		String msgId = UUID.randomUUID().toString();
   		receiveOrderCoreBiz.processOrder(msgId, json);
	}

	@Test
	public void Payed_OneSku() {
		String json = getFileContent("Payed_OneSku.txt");
		String msgId = UUID.randomUUID().toString();
		receiveOrderCoreBiz.processOrder(msgId, json);
	}

	// 测试拆单后的订单
	@Test
	public void WaitPay_MoreSku() {
		String json = getFileContent("WaitPay_MoreSku.txt");
		String msgId = UUID.randomUUID().toString();
		receiveOrderCoreBiz.processOrder(msgId, json);
	}

	@Test
	public void Payed_MoreSku() {
		String json = getFileContent("Payed_MoreSku.txt");
		String msgId = UUID.randomUUID().toString();
		receiveOrderCoreBiz.processOrder(msgId, json);
	}


	@Test
	public void handleData() {
		try {
			ResultEntity result = icSmDqlStaffService.staffDataHandle();
			System.out.println(result);
		} catch (Exception ex) {
		}
	}



	@Test
	public void getStaffInfoByUserId() {
//		ResultEntity result = orderShopServiceImpl.getStaffInfoByUserId(100051604302L);
		ResultEntity result = orderShopServiceImpl.getStaffInfoByUserId(100051604302L);
		ResultEntity result2 = orderShopServiceImpl.getStaffInfoByUserId(100051604302L);
		System.err.println("结果是：" + JSON.toJSONString(result.getBusinessObj()));

	}

	@Test
	public void get() {
		String ordeer = "123";
		String[] strs = ordeer.split(",");
		System.out.println(1);
	}

	private String getFileContent(String fileName) {
		String path = this.getClass().getClassLoader().getResource("").getPath().toString();
		String filePath = path.substring(1) + fileName;
		File file = new File(filePath);
		StringBuffer sb = new StringBuffer();
		BufferedReader input = null;
		try {
			input = new BufferedReader(new FileReader(file));
			String text;
			while ((text = input.readLine()) != null)
				sb.append(text);

		} catch (Exception ex) {
		} finally {
			if (input != null)
				try {
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		System.out.println("编译后src路径：" + sb.toString());
		return sb.toString();
	}
	@Test
	public void testBigdate(){
		icSmDqlStaffService.staffDataHandle();
	}

}
