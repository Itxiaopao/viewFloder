package com.gome.meidian.service;

import com.gome.meidian.BaseTest;
import com.gome.meidian.vo.DefaultHammer;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
public class DynamicConfigServiceTest extends BaseTest {

    @Test
    public void test1() throws InterruptedException {
        Thread thread = new Thread();
        ClassLoader contextClassLoader = thread.getContextClassLoader();
        System.out.println(contextClassLoader);
        ThreadLocal<Object> objectThreadLocal = new ThreadLocal<>();

    }
}