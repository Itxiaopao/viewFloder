package com.gome.meidian;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import cn.com.gome.rebate.calc.Delivery;
import cn.com.gome.rebate.calc.GoodsDto;
import cn.com.gome.rebate.calc.OrderDto;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.gome.dragon.mds.client.dto.gcc.GomeStoreFull;
import com.gome.dragon.mds.client.gcc.GomeStoreFullClient;
import com.gome.frontSe.interfaces.IProdDetailService;
import com.gome.meidian.config.GCacheConfig;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.CouponVo;
import com.gome.meidian.entity.EmployeeInfo;
import com.gome.meidian.entity.IcSmDqlStaff;
import com.gome.meidian.entity.MshopInfo;
import com.gome.meidian.entity.Order;
import com.gome.meidian.entity.OrderBasedTask;
import com.gome.meidian.entity.OrderCategory;
import com.gome.meidian.entity.OrderCountRequest;
import com.gome.meidian.entity.OrderCountResponse;
import com.gome.meidian.entity.OrderDetailRequest;
import com.gome.meidian.entity.OrderDetailResponse;
import com.gome.meidian.entity.OrderEffect;
import com.gome.meidian.entity.OrderFullMessage;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.entity.OrderShopSame;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.StaffInfo;
import com.gome.meidian.entity.StidInfo;
import com.gome.meidian.mapper.bigData.IcSmDqlStaffMapper;
import com.gome.meidian.mapper.order.OrderOccurMapper;
import com.gome.meidian.mapper.order.OrderShopMapper;
import com.gome.meidian.service.IGrantRebateService;
import com.gome.meidian.service.IOrderChannelService;
import com.gome.meidian.service.IOrderCountService;
import com.gome.meidian.service.IOrderDetailService;
import com.gome.meidian.service.IOrderEffectService;
import com.gome.meidian.service.IOrderFullMessageService;
import com.gome.meidian.service.IOrderOccurService;
import com.gome.meidian.service.IOrderRefundService;
import com.gome.meidian.service.IOrderService;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.service.IcSmDqlStaffService;
import com.gome.meidian.service.OrderBasedTaskService;
import com.gome.meidian.service.OrderBranchTaskService;
import com.gome.meidian.service.OrderImportUvDataService;
import com.gome.meidian.service.impl.OrderShopServiceImpl;
import com.gome.meidian.service.util.OrderErrorLogUtil;
import com.gome.meidian.service.util.OrderFullMessageUtil;
import com.gome.meidian.util.CouponUtils;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.util.JSONUtils;
import com.gome.stage.page.ProductItemPage;
import com.gomeo2o.common.page.PageParam;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfoDesc;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoDescFacade;
import com.gomeplus.bs.interfaces.channel.api.MshopChannelService;
import com.gomeplus.bs.interfaces.channel.dto.base.ResponseApiDto;
import com.google.common.base.Stopwatch;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import redis.Gcache;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class MeidianServiceOrderApplicationTests {

	@Autowired
	IOrderChannelService channelService;
	@Autowired
	IOrderRefundService refundService;
	@Autowired
	IOrderEffectService effectService;
	@Autowired
	IOrderDetailService detailService;
	@Autowired
	IOrderOccurService occurService;
	@Autowired
	IOrderOccurService occursvc;
	@Autowired
	GCacheConfig gCacheService;
	@Autowired
	IOrderCountService countService;
	@Autowired
	IOrderService orderSvc;
	@Autowired
	OrderErrorLogUtil errorLogUtil;
	@Autowired
	IOrderFullMessageService orderFullMessageService;
	@Autowired
	OrderFullMessageUtil orderFullMessageUtil;
	@Autowired
	IOrderShopService  iOrderShopImport;
	@Autowired
	OrderBasedTaskService orderBasedTaskService;
	@Autowired
    OrderBranchTaskService orderBranchTaskService;
	@Autowired
    OrderImportUvDataService orderImportUvDataService;

	@Autowired
	private GCacheConfig gCacheConfig;
	@Autowired
	IcSmDqlStaffService icSmDqlStaffService;
	@Autowired
	OrderShopServiceImpl orderShopServiceImpl;
	@Autowired
	private OrderShopMapper orderShopMapper;
	@Autowired
	private IGrantRebateService grantRebateService;

	private static final ThreadPoolExecutor EXECUTOR = new ThreadPoolExecutor(10, 20, 60L, TimeUnit.SECONDS,
			new ArrayBlockingQueue<Runnable>(1000), new ThreadFactoryBuilder().setNameFormat("同步社会美店主数据-线程%d").build(),
			new ThreadPoolExecutor.AbortPolicy());

	@Autowired IcSmDqlStaffMapper icSmDqlStaffMapper;

	@Test
	public void predictionIncomeByUserIdList(){
		ArrayList<Long> longs = Lists.newArrayList(100051627124L);
		ResultEntity<Map<Long, Double>> mapResultEntity = grantRebateService.predictionIncomeByUserIdList(longs);
		System.err.println("结果是：" + JSON.toJSONString(mapResultEntity));

	}
	@Test
	public void predictionIncomeByPuserIdList(){
		ArrayList<Long> longs = Lists.newArrayList(100038055221L,100037711631L);
		ResultEntity<Map<Long, Double>> mapResultEntity = grantRebateService.predictionIncomeByPuserIdList(longs);
		System.err.println("结果是：" + JSON.toJSONString(mapResultEntity));

	}
	
	
	
	@Test
	public void test05(){
		int totalCount = icSmDqlStaffMapper.getTotalCount();
		System.err.println("结果是：" + totalCount);
	}
	@Autowired
	Gcache gcache;
	private final String VSHOP_INFO_DESC_KEY = "vshop:vshopInfoDesc_userId:";

	@Test
	public void delCacheIcSmDf(){
//		List<IcSmDqlStaff> list = icSmDqlStaffMapper.selectAll();
		List<IcSmDqlStaff> list = null;
		List<List<IcSmDqlStaff>> partition = Lists.partition(list, 5000);
		CountDownLatch countDownLatch = new CountDownLatch(partition.size());
		for (List<IcSmDqlStaff> info : partition) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			final List<IcSmDqlStaff> list1 = info;
			final CountDownLatch latch = countDownLatch;
			new Thread(new Runnable() {
				@Override public void run() {
					try {
						for (IcSmDqlStaff vshopInfo : list1) {
                            gcache.del(VSHOP_INFO_DESC_KEY + vshopInfo.getZxUid());
                        }
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						latch.countDown();
					}
				}
			}).start();
		}
		try {
			countDownLatch.await();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void test01(){
		//分页查询same表的数据
		int totalCount = orderShopMapper.selectAllCount();
		int totalPage = getTotalPage(2000,totalCount);
		for (int i = 1; i <= totalPage; i++) {
			Map<String, Object> map = new HashMap<>();
			map.put("offSet", (i - 1) * 2000);
			map.put("pageSize", 2000);
			//每页展示2000条
			List<OrderShopSame> orderShopSames = orderShopMapper.selectAllLimit(map);
			//一个线程处理500条
			List<List<OrderShopSame>> partition = Lists.partition(orderShopSames, 100);
			for (List<OrderShopSame> orderShopSameList : partition) {
//				icSmDqlStaffService.handlerVshopInfoDesc(orderShopSameList);
			}
//			CountDownLatch countDownLatch = new CountDownLatch(partition.size());
//			//同步数据
//			handlerData(partition,countDownLatch);
//			try {
//				countDownLatch.await();
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
		}
	}

	private void handlerData(final List<List<OrderShopSame>> partition, final CountDownLatch countDownLatch) {
		//线程数量
		for (int i = 0; i < partition.size(); i++) {
			//每次循换创建一个线程
			final List<OrderShopSame> orderShopSameList = partition.get(i);
			final int index = i;
			EXECUTOR.execute(new Runnable() {
				@Override
				public void run() {
					int count = 0;
					Stopwatch stopwatch = Stopwatch.createStarted();
					try {
//						icSmDqlStaffService.handlerVshopInfoDesc(orderShopSameList);
						Thread.sleep(2000);
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						System.err.println(
								"线程: " + Thread.currentThread() + " 数据同步完成,总任务条数是" + 500 + ",同步接口调用"
										+ count + "次数,耗时：" + stopwatch.elapsed(TimeUnit.SECONDS));
						countDownLatch.countDown();
					}
				}
			});
		}
	}

	public int getTotalPage(int pageSize,int totalCount) {
		//总页数
		int totalPage = totalCount / pageSize;
		if (totalCount == 0 || totalCount % pageSize != 0) {
			totalPage++;
		}
		return totalPage;
	}

	private Long newUserId = 100049475501L;

	@Test
	public void selectByNewUserId(){
		EmployeeInfo employeeInfo = iOrderShopImport.selectByNewUserId(newUserId );
		System.out.println("结果是：" + JSONObject.toJSONString(employeeInfo));
	}
	@Test
	public void selectByNewUserIdCache(){
		EmployeeInfo employeeInfo = iOrderShopImport.selectByNewUserIdFromCache(newUserId );
		System.out.println("结果是：" + JSONObject.toJSONString(employeeInfo));
	}
	
	@Test
	public void delCache(){
		Gcache gcache = gCacheConfig.gcache();
		String key = Constant.STAFF_INFO_STR_CACHE + newUserId;
		gcache.del(key);
	}

	@Autowired
	private GomeStoreFullClient gomeStoreFullClient;

	@Test
	public void getGomeStoreByStoreIdByAllStatus() {
		try {
			List<String> strings = Files.readLines(
					new File("D:\\Repository\\gomework\\meidian-service-order\\src\\test\\resources\\read2.properties"),
					Charset.defaultCharset());
			for (String string : strings) {
				GomeStoreFull allStatus = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus("A0GW");
				if (null != allStatus && allStatus.getPoolFlag() == 2) {
					System.err.println("加盟店的门店信息是：" + string);
				}

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Autowired private CouponUtils couponUtils;
	@Test
	public void getStaffInfoWithParam02(){
		//没有绑定关系
//		ResultEntity<StaffInfo<IcSmDqlStaff>> staffInfoWithParam = iOrderShopImport.getStaffInfoWithParam(100049585403l, null, null, null);
		List<CouponVo> var3 = Lists.newArrayList();
//		CouponVo couponVo = new CouponVo();
//		couponVo.setTicketId("券号1");
//		couponVo.setCouponType(3002L);
//		var3.add(couponVo);
//		CouponVo couponVo3 = new CouponVo();
//		couponVo3.setTicketId("券号2");
//		couponVo3.setCouponType(3002L);
//		var3.add(couponVo3);
//		CouponVo couponVo4 = new CouponVo();
//		couponVo4.setTicketId("券号1");
//		couponVo4.setCouponType(3005L);
//		var3.add(couponVo4);
//		CouponVo couponVo5 = new CouponVo();
//		couponVo5.setCouponId("PM23200034");
//		couponVo5.setCouponType(3005L);
//		var3.add(couponVo5);
//		CouponVo couponVo1 = new CouponVo();
//		couponVo1.setCouponId("券ID1");
//		couponVo1.setCouponType(3003L);
//		var3.add(couponVo1);
//		CouponVo couponVo2 = new CouponVo();
//		couponVo2.setCouponId("券ID2");
//		couponVo2.setCouponType(3003L);
//		var3.add(couponVo2);
//		CouponVo couponVo6 = new CouponVo();
//		couponVo6.setCouponId("1128072646");
//		couponVo6.setCouponType(3003l);
//		var3.add(couponVo6);
		CouponVo couponVo7 = new CouponVo();
		couponVo7.setTicketId("d0631042abc38dadad409f5b9f7d6913");
		couponVo7.setCouponType(3005L);
		var3.add(couponVo7);
//		Map<Integer, CouponGiveParamDTO> map = couponUtils.filterCouponVoList(var3);
//		for (Map.Entry<Integer, CouponGiveParamDTO> entry : map.entrySet()) {
//			System.err.println("结果是：" + entry.getKey() + "----" + JSON.toJSONString(entry.getValue()));
//		}

//		while(true){
//			ResultEntity<StaffInfo<IcSmDqlStaff>> staffInfoWithParam = iOrderShopImport.getStaffInfoWithParam(100051353723L, null,null, var3, null);
//			ResultEntity<StaffInfo<IcSmDqlStaff>> staffInfoWithParam = iOrderShopImport.getStaffInfoWithParam(100049064004L, null,null, var3, null);
			ResultEntity<StaffInfo<IcSmDqlStaff>> staffInfoWithParam = iOrderShopImport.getStaffInfoWithParam(100014604179L, null,null, var3, null);
			System.err.println("业绩还原结果是："+JSON.toJSONString(staffInfoWithParam));
//			String organizationByUserId = iOrderShopImport.findOrganizationByUserId(100051353723L);
//			System.err.println("销售组织：" + organizationByUserId);
//			try {
//				Thread.sleep(2000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}

	}

	@Autowired VshopInfoDescFacade vshopInfoDescFacade;
	@Autowired VshopFacade vshopFacade;

	@Test
	public void test03(){
		Map<String, Object> criteria1 = new HashMap<>();
		PageParam pageParam1 = new PageParam();
		pageParam1.setNumPerPage(1000);
		pageParam1.setPageNum(1);//页码
		criteria1.put("vshopIdentitys", 3);
		criteria1.put("newUseridLike", 100);
		List<VshopInfo> businessObj = vshopFacade.queryVshopInfoListByCriteria(pageParam1, criteria1).getBusinessObj();
		ArrayList<VshopInfoDesc> objects = Lists.newArrayList();
		for (VshopInfo vshopInfo : businessObj) {
			IcSmDqlStaff obj = (IcSmDqlStaff)icSmDqlStaffService.getStaffInfoByStaffID(vshopInfo.getUserId()).getBusinessObj();
			VshopInfoDesc desc = new VshopInfoDesc();
			desc.setUserId(vshopInfo.getUserId());
			desc.setStoreCode(null != obj ? obj.getStoreCode() : null);
			desc.setOrganization(null != obj ? obj.getOrganizationCode() : null);
			desc.setStaffCode(null != obj ? obj.getStaffCode() : null);
			desc.setRewardStatus(1);
			desc.setOnline(0);
			desc.setIdentityTag(0);
			objects.add(desc);
		}
		vshopInfoDescFacade.synVshopInfoDesc(objects);

	}




	@Test
	public void test02(){
		List<OrderShopSame> orderShopSameList = orderShopMapper.selectAll();
		ArrayList<VshopInfoDesc> objects = Lists.newArrayList();
		for (OrderShopSame orderShopSame : orderShopSameList) {
			VshopInfoDesc desc = new VshopInfoDesc();
			desc.setUserId(orderShopSame.getNewUserId());
			desc.setStoreCode(orderShopSame.getStoreId());
			desc.setOrganization(orderShopSame.getOrganizationCode());
			desc.setStaffCode(orderShopSame.getUserId());
			desc.setRewardStatus(1);
			desc.setOnline(0);
			desc.setIdentityTag(0);
			objects.add(desc);
		}
		vshopInfoDescFacade.synVshopInfoDesc(objects);

	}

	@Test
	public void getStaffInfoWithParam(){
		//自己是店主，是员工 在职状态 A00V----00067642  0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100032914141l, null);
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100051209401l, null);
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100051205001l, null);
		//自己是店主，是员工，但是离职状态 0 null
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100037435443l, null);
		//自己是店主，不是员工,上级是店主，是员工 返回上级A00V----00067642  0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100011897952l, null);
		//自己是店主，不是员工,上级是店主，不是员工 ,上上级是店主，是员工 返回上级A00V----00067642  0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100036365098l, null);
		//自己是店主，不是员工,上级是店主，不是员工 ,上上级是店主，是员工 返回上级A00V----00067642  0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100036365100l, null);
		//自己不是店主，不是员工(普通员工)，没有上级店主
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(73408894973l, null);
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100049280209l, null);
		//自己不是店主，不是员工(普通用户)，上级是店主，不是员工，上上上级是店主，是员工 A00V----00067642  0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(72010655313l, null);
		//自己不是店主，不是员工(普通用户)，上级是店主，是员工 A00V----00067642  0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(72772117906l, null);
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100051222003l, null);
		//自己是店主，不是员工，最上级是大锤(是店主，不是员工) 1001----null 0
		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100039974305l, null);
		//自己是店主，不是员工，上级是大锤(是店主，不是员工) 1001----null 0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100039973701l, null);
		//自己不是店主，不是员工，上级是大锤 1001----null 0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(1729898594l, null);
		//自己不是店主，不是员工，最上级是大锤 1001----null 0
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(64734985989658l, null);
		//自己是店主，不是员工，无上级 null  1
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(100040148201l, null);
		//自己不是店主，不是员工，上级离职状态 0 null
//		ResultEntity resultEntity = iOrderShopImport.getStaffInfoWithParam(64375847584l, null);
		StaffInfo staff = (StaffInfo) resultEntity.getBusinessObj();
		System.out.println("resultEntity:" + resultEntity);
		IcSmDqlStaff icSmDqlStaff = JSON.toJavaObject(JSONObject.parseObject(JSONObject.toJSONString(staff.getStaffInfo())), IcSmDqlStaff.class);
		if (null != staff.getStaffInfo()) {
			System.err.println(
					"结果是：" + resultEntity.getBusinessObj() + " 数据是：" + icSmDqlStaff.getStoreCode() + "----" + icSmDqlStaff
							.getStaffCode());

		}else{
			System.err.println("结果是：" + resultEntity.getBusinessObj() + " 数据是：" + staff.getStaffInfo());
		}

	}

	@Test
	public void findOrganizationByUserId(){
		String organizationByUserId = iOrderShopImport.findOrganizationByUserId(100051408403l);
//		String organizationByUserId = iOrderShopImport.findOrganizationByUserId(100039973701l);
//		String organizationByUserId = iOrderShopImport.findOrganizationByUserId(100051209401l);
		System.out.println("结果数据是：" + organizationByUserId);

	}

	@Test
	public void taskTest(){

		OrderBasedTask orderBasedTask = new OrderBasedTask();
		orderBasedTask.setUvQuota(400l);
		orderBasedTask.setShareQuota(1000l);
		orderBasedTask.setTaskId(1237l);
		orderBasedTask.setSkuId("123");
//        Integer integer = orderBasedTaskService.insertOne(orderBasedTask);
//        System.out.println(integer);
        List<OrderBasedTask> orderBasedTasks = new ArrayList<>();

		orderBasedTasks.add(orderBasedTask);
		OrderBasedTask orderBasedTask1 = new OrderBasedTask();
        orderBasedTask1.setUvQuota(500l);
        orderBasedTask1.setTaskId(1236l);
        orderBasedTask1.setSkuId("123");
        orderBasedTasks.add(orderBasedTask1);
        OrderBasedTask orderBasedTask2 = new OrderBasedTask();
        orderBasedTask2.setUvQuota(500l);
        orderBasedTask2.setTaskId(1245l);
        orderBasedTask2.setSkuId("123");
        orderBasedTasks.add(orderBasedTask2);
        orderBasedTaskService.insertOrUpdateBatchNum(orderBasedTasks);
//        List<BatchResult> batchResults = orderBasedTaskService.insertBatchNum(orderBasedTasks);
//        boolean insert = orderBasedTaskService.insert(orderBasedTask);
//		System.out.println(insert);
	}

	@Test
	public void orderTest() {
		HashMap<String, Object> hashMap = new HashMap<String, Object>();
		hashMap.put("startDate", "2018-08-07 00:00:00");
		hashMap.put("endDate", "2018-08-08 23:59:59");
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add(" 108275");
		 arrayList.add("524930");
		hashMap.put("mid",arrayList);
		hashMap.put("orderType", 2);
		// Object o=orderSvc.selectByDateRange(hashMap);

		List<OrderOccur> selectByDateRange = occurService.selectByDateRange(hashMap);
		System.out.println("=====" + selectByDateRange);
	}

	@Test
	public void orderOccurTest() throws Exception {
		/*
		 * OrderOccur orderOccur = new OrderOccur(); orderOccur.setOrderId(1l);
		 * orderOccur.setCommerceId(1l); occursvc.insertOccurOrder(orderOccur);
		 */
		/*String value = gCacheService.gcache().get("1vP6Y-sT568vAZb6iGv-Bu");
		System.out.println("-------" + value);
		HashMap<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("order_id", "11554760690");
		queryMap.put("commerce_id", "4861365323");
		System.out.println(effectService.selectByMap(queryMap));*/
		
		
		  OrderOccur orderOccur = new OrderOccur(); 
		  orderOccur.setOrderId(3333L);
		  orderOccur.setCommerceId(2222l); 
		  orderOccur.setDeliveryId("3444");
		  orderOccur.setMerchantName("测试小店");
		  occursvc.insertOccurOrder(orderOccur);
		 
	}

	@Test
	public void orderChannelTest() {
		/*
		 * OrderChannel channel = new OrderChannel(); channel.setKid("123213");
		 * channel.setOrderId(1111L); channel.setCommerceId(2222L);
		 * System.out.println(channelService.insert(channel));
		 */
//		Double a = 2858441017.34d;
//		Double b = 6964418384.23d;
//		Double c = 583205183.99d;
//		Double sum = a + b + c;
//		System.out.println("---------" + convertKid(null));
		/*
		 * System.out.println(a+"的百分比："+num.format(a/sum));
		 * System.out.println(b+"的百分比："+num.format(b/sum));
		 * System.out.println(c+"的百分比："+num.format(c/sum));
		 */
	}

	@Test
	public void orderRefundTest() {
	/*	OrderRefund refund = new OrderRefund();
		refund.setItemId("11111112");
		refund.setOrderId(5145454545L);
		refund.setCommerceId(3444444L);
		refund.setRefundId("12323");
		System.out.println(refundService.insert(refund));*/
	}

	private String convertKid(String kid) {
		if (kid.contains("_")) {
			try {
				kid = kid.split("_")[2];
			} catch (Exception e) {
			}
		}
		return kid;
	}

	@Test
	public void testSelectOnlyByDate() {
		HashMap<String, Object> object = new HashMap<String, Object>();
		//object.put("taskItems", "1,2");
		//object.put("taskQueueNum", "4");
		//object.put("startDate", "2018-12-01 00:00:00");
		//object.put("endDate", "2018-12-31 23:59:59");
		// 只要妥投

		//MshopInfo result = effectService.selectByDateRangeFromBsSchedule(object);
		object.put("mid", "758167");
		List<OrderEffect> orderEffects = effectService.selectByDateRange(object);
		System.out.println(orderEffects+"aaaaaa");
	}

	@Test
	public void testBsScheduleTask() {

		String startDate = DateUtils.getYesterdayTimeBySelect(DateUtils.DATE_START_TIME);
		String endDate = DateUtils.getYesterdayTimeBySelect(DateUtils.DATE_END_TIME);

		startDate = "2018-08-08 00:00:00";
		endDate = "2018-08-08 23:59:59";
		HashMap<String, Object> object = new HashMap<String, Object>();
		object.put("taskItems", "1,2");
		object.put("taskQueueNum", "4");
		object.put("startDate", startDate);
		object.put("endDate", endDate);
		// 只要妥投
		MshopInfo result = effectService.selectByDateRangeFromBsSchedule(object);
//		System.out.println("===" + JSON.toString(result));
	}

	@Autowired
	OrderOccurMapper orderMapper;

	@Test
	public void testItemId() {
		List<OrderOccur> list = orderMapper.selectItemIdByDateRange("9134162759", DateUtils.getCurrentStartTime(),
				DateUtils.getCurrentEndTime());
//		System.out.println("===" + JSON.toString(list));
	}

	@Test
	public void cacheListTest() {
		List list = new ArrayList();
		OrderOccur orderOccur = new OrderOccur();
		orderOccur.setOrderId(1123233l);
		orderOccur.setCommerceId(133333l);
		list.add(orderOccur);
		list.add(orderOccur);
		list.add(orderOccur);

		gCacheService.gcache().hset("meidian-service-order", "listTest", JSONUtils.toJSONString(list).getBytes());
		gCacheService.gcache().expire("meidian-service-order", 60 * 2);
		List<OrderOccur> orderOccurs = JSONObject
				.parseArray(gCacheService.gcache().hget("meidian-service-order", "listTest"), OrderOccur.class);
		System.out.println("===" + JSONUtils.toJSONString(orderOccurs));
	}

	@Test
	public void stidInfoTest() {
		List list = new ArrayList();
		list.add("111");
		list.add("112");
		list.add("113");
		Date date = DateUtils.getNowDate();
		List<StidInfo> result = orderSvc.selectStidInfoByDate(DateUtils.minusMonths(date, 4L), date, list);
		System.out.println("===" + JSONUtils.toJSONString(result));
	}

	@Test
	public void stidInfoTest2() {
		List list = new ArrayList();
		list.add("QDMD50001");
		list.add("QDMD105845");
		Date date = DateUtils.getNowDate();
		List<StidInfo> result = orderSvc.selectSkuNoByDate(DateUtils.minusMonths(date, 4L), date, list, null);
		System.out.println("===" + JSONUtils.toJSONString(result));
		list = new ArrayList();
		list.add("QDMD105845");
		result = orderSvc.selectSkuNoByDate(DateUtils.minusMonths(date, 4L), date, list, "100428664");
		System.out.println("$$==" + JSONUtils.toJSONString(result));
	}

	@Autowired
	MshopChannelService mshopChannelServer;

	@Test
	public void stidInfoTest3() {
		ResponseApiDto result = mshopChannelServer.getStidByMid(0L);
		String s = "";
		if (result.getCode().equals(0) && null != result.getDatas()) {
			s =  result.getDatas().toString();
		}
		System.out.println("$$==" + JSONUtils.toJSONString(s));
	}

	@Test
	public void stidInfoTest4() {
		List list = new ArrayList();
		list.add("713813");
		Date date = DateUtils.getNowDate();
		List<StidInfo> result = orderSvc.selectMidInfoByDate(DateUtils.minusMonths(date, 4L), date, list);
		System.out.println("$$==" + JSONUtils.toJSONString(result));
	}
	@Test
	public void stidInfoTest5() {
		List list = new ArrayList();
		list.add("QDMD165573");
		Date date = DateUtils.getNowDate();
		List<StidInfo> result = orderSvc.selectSkuNoByDate(DateUtils.minusMonths(date, 4L), date, list, "8003764145");
		System.out.println("$$==" + JSONUtils.toJSONString(result));
	}


	private String convertList(List<String> params) {
		String temp = "";
		for (int i = 0; i < params.size(); i++) {
			if (i != (params.size() - 1)) {
				temp += "'" + params.get(i) + "',";
			} else {
				temp += "'" + params.get(i) + "'";
				;
			}
		}
		return temp;
	}
	@Test
	public void detailTest() {
		List<OrderCategory> result = detailService.getCateByType(3,"cat10000008");
		System.out.println("$$==" + JSONUtils.toJSONString(result));
	}
	
	@Test
	public void detailTest2() {
		OrderDetailRequest orderDetailRequest  = new OrderDetailRequest();
		orderDetailRequest.setStartDate(DateUtils.formate("2018-01-26 00:00:00", "yyyy-MM-dd HH:mm:ss"));
		orderDetailRequest.setEndDate(DateUtils.formate("2019-12-27 00:00:00", "yyyy-MM-dd HH:mm:ss"));
		orderDetailRequest.setPageIndex(1);
		orderDetailRequest.setPageSize(10);
		//orderDetailRequest.setStaffId("10098488");
//		orderDetailRequest.setClassifyId("A1");
//		orderDetailRequest.setCategoryFirst("cat10000004");
		//orderDetailRequest.setSkuNo("100253545");
	//	orderDetailRequest.setDeliveryId("2771809902");
//		orderDetailRequest.setUserId("100036115415");
		//orderDetailRequest.setStaffType(1);
		orderDetailRequest.setOrderStatus(5);
		Map<Long,List<OrderDetailResponse>> result = detailService.queryOrderDetail(orderDetailRequest);
		System.out.println(result.get("list").size());
	}

	@Autowired
	private IProdDetailService iProdDetailService;

	@Test
	public void detailStaffTest() {

		ProductItemPage vo = iProdDetailService.getProductDetail("A0000154033", null);
		System.out.println(vo);

		/*//查询员工数据
		OrderDetailRequest orderDetailRequest  = new OrderDetailRequest();
		Date now = DateUtils.getNowDate();
		orderDetailRequest.setStartDate(DateUtils.minusHours(now, 24*31L));
		orderDetailRequest.setEndDate(now);
		orderDetailRequest.setPageIndex(0);
		orderDetailRequest.setPageSize(5);
		orderDetailRequest.setStaffType(1);
		Map<Long,List<OrderDetailResponse>> result= detailService.queryOrderDetail(orderDetailRequest);
		System.out.println(JSONUtils.toJSONString(result));*/
	}
	@Test
	public void detailNotStaffTest2() {
//		OrderDetailRequest orderDetailRequest  = new OrderDetailRequest();
//		Date now = DateUtils.getNowDate();
//		orderDetailRequest.setStartDate(DateUtils.minusHours(now, 24*31L));
//		orderDetailRequest.setEndDate(now);
//		orderDetailRequest.setPageIndex(0);
//		orderDetailRequest.setPageSize(5);
//		orderDetailRequest.setStaffType(4);
//		Map<Long,List<OrderDetailResponse>> result = detailService.queryOrderDetail(orderDetailRequest);
//		System.out.println(JSONUtils.toJSONString(result));
	}
	
	@Test
	public void orderCountTest() {
		OrderCountRequest request  = new OrderCountRequest();
		Date now = DateUtils.getNowDate();
		request.setStartDate(DateUtils.minusHours(now, 24*200L));
		request.setEndDate(now);
		request.setGroupType(4);
       // request.setProductId("9140000171");
        request.setOrderStatus(2);
    //    request.setSkuId("1130014523");
     //   request.setSkuNo("100428664");
		List<OrderCountResponse> result = countService.queryOrderCount(request);
		System.out.println(	request.getStartDate()+"--------"+JSONUtils.toJSONString(result));
	}
	
	//1-[{"groupId":null,"groupName":"合计","orderNum":62,"priceTotal":"27080.720000","buyNum":69,"elecBuyNum":9,"cargoBuyNum":2,"electricNum":9,"electricPrice":"26751.000000","cargoNum":2,"cargoPrice":"27.920000"}]

	//2-[{"groupId":null,"groupName":"合计","orderNum":203097,"priceTotal":"87026142.050000","buyNum":227331,"elecBuyNum":null,"cargoBuyNum":null,"electricNum":37578,"electricPrice":"84520497.370000","cargoNum":163480,"cargoPrice":"2049455.070000"}]
	//2-[{"groupId":null,"groupName":"合计","orderNum":203097,"priceTotal":"87026142.050000","buyNum":227331,"elecBuyNum":null,"cargoBuyNum":null,"electricNum":37578,"electricPrice":"84520497.370000","cargoNum":163480,"cargoPrice":"2049455.070000"}]
    //[{"groupId":"Z00001","groupName":"东北大区","orderNum":62,"priceTotal":"27080.720000","buyNum":69,"elecBuyNum":null,"cargoBuyNum":null,"electricNum":9,"electricPrice":"26751.000000","cargoNum":2,"cargoPrice":"27.920000"},
	//{"groupId":null,"groupName":"合计","orderNum":62,"priceTotal":"27080.72","buyNum":69,"elecBuyNum":null,"cargoBuyNum":null,"electricNum":9,"electricPrice":"26751.0","cargoNum":2,"cargoPrice":"27.92"}]

	@Test
	public void orderCountTest2() {   
//		OrderCountRequest request  = new OrderCountRequest();
//		Date now = DateUtils.getNowDate();
//		request.setStartDate(DateUtils.minusHours(now, 24*31L));
//		request.setEndDate(now);
//		request.setGroupType(7);
//		request.setStoreId("ACCI");
//		request.setStaffId("87907");
//		List<OrderCountResponse> result = countService.queryOrderCount(request);
//		System.out.println(JSONUtils.toJSONString(result));
		/*OrderEffect orderEffect = new OrderEffect();
		orderEffect.setOrderId(1111111111111L);
		orderEffect.setCommerceId(1111111111111L);orderEffect.setDeliveryId("1111111111111");
		boolean insertOrUpdate = effectService.insertOrUpdate(orderEffect);
		System.out.println(insertOrUpdate);
		errorLogUtil.insertLog(orderEffect, "插入妥投表失败");*/
	}
	@Test
	public void testSaveSiteId() throws Exception {
		/*File file = new File("C:\\development\\TestData\\ImportWare.txt");
		StringBuffer sb = new StringBuffer();
		BufferedReader input = null;
		try {
			input = new BufferedReader(new FileReader(file));
			String text;
			while ((text = input.readLine()) != null)
				sb.append(text);

		} catch (Exception ex) {
		}finally{
			if(input != null)
				input.close();
		}
		JSONObject jSONObject = JSONObject.parseObject(String.valueOf(sb));
		// logger.info("--------OMS队列消息: {}", jSONObject);
		OrderDto vo = JSON.toJavaObject(jSONObject, OrderDto.class);
		List<Delivery> deliveryList = vo.getDeliveryList();
		if (null != deliveryList && deliveryList.size() > 0) {
			for (Delivery deliveryVo : deliveryList) {
				// 解析商品对象
				List<GoodsDto> goodsList = deliveryVo.getGoodsList();
				if (null != goodsList && goodsList.size() > 0) {
					for (GoodsDto goodVo : goodsList) {
						// mid为空时,若kid未空,则不存库,否则存在kid,mid设为0
						if (StringUtils.isEmpty(goodVo.getMicroID())) {
							if (StringUtils.isEmpty(goodVo.getKid())) {
								continue;
							} else {
								goodVo.setMicroID("0");
							}
						}else {
							//mid不为空时 修复 mid 为 字符串 null 或者 undefined 的情况
							try {
								Long.parseLong(goodVo.getMicroID());
							} catch (Exception e) {
								goodVo.setMicroID("0");
							}
						}
						OrderFullMessage orderFullMessage = new OrderFullMessage();
						Integer status = deliveryVo.getStatus();
						if (status.equals(1)) {
							OrderOccur occur = new OrderOccur();
							convertOrder(vo, deliveryVo, goodVo, occur);
							occur.setAddressFirst(goodVo.getAddressFirst());
							occur.setAddressSecond(goodVo.getAddressSecond());
							occur.setAddressThird(goodVo.getAddressThird());
							occur.setAddressFourth(goodVo.getAddressFourth());
							occur.setBrandCode(goodVo.getBrandCode());
							occur.setChannelType(goodVo.getChannelType());
							occur.setMerchantName(goodVo.getMerchantName());
							boolean insertOccurOrder = occurService.insertOccurOrder(occur);
							if(insertOccurOrder) {
//								logger.info("--------插入发生单,{}", occur.toString());
								orderFullMessage.setInsertStatus(0);
//								orderFullMessageUtil.copyOrderToMessage(object.toString(), msgId, occur,orderFullMessage);
							}else {
								orderFullMessage.setInsertStatus(1);
//								orderFullMessageUtil.copyOrderToMessage(object.toString(), msgId, occur,orderFullMessage);
							}
						} else if(status.equals(2)) {
							OrderOccur occur = new OrderOccur();
							convertOrder(vo, deliveryVo, goodVo, occur);
							occur.setAddressFirst(goodVo.getAddressFirst());
							occur.setAddressSecond(goodVo.getAddressSecond());
							occur.setAddressThird(goodVo.getAddressThird());
							occur.setAddressFourth(goodVo.getAddressFourth());
							occur.setBrandCode(goodVo.getBrandCode());
							occur.setChannelType(goodVo.getChannelType());
							occur.setMerchantName(goodVo.getMerchantName());
							occur.setStatus(2);
							boolean updateOrderToCancel = occurService.updateOrderToCancel(occur);
							if(updateOrderToCancel) {
//								logger.info("--------update发生单success,{}", occur.toString());
								System.out.println(occur);
							}else {
//								logger.info("--------update发生单fail,{}", occur.toString());
								System.out.println(occur);
							}
						} else if (status.equals(5)) {
							OrderEffect effect = new OrderEffect();
							convertOrder(vo, deliveryVo, goodVo, effect);
							effect.setAddressFirst(goodVo.getAddressFirst());
							effect.setAddressSecond(goodVo.getAddressSecond());
							effect.setAddressThird(goodVo.getAddressThird());
							effect.setAddressFourth(goodVo.getAddressFourth());
							effect.setBrandCode(goodVo.getBrandCode());
							effect.setChannelType(goodVo.getChannelType());
							effect.setEffectTime(vo.getEffectTime());
							effectService.insertEffectOrder(effect);
//							logger.info("--------插入妥投单,{}", effect.toString());
						} else if (status.equals(6)) {
							OrderRefund refund = new OrderRefund();
							convertOrder(vo, deliveryVo, goodVo, refund);
							refund.setRefundId(goodVo.getAfterSalesOrderId().toString());
							refundService.insertRefundOrder(refund);
//							logger.info("--------插入退货单,{}", refund.toString());
						}else {
//							logger.info("------------------------"+msg.getMsgId()+"------------------------");
//							logger.info(vo.toString());
						}
					}
				}
			}
		}*/
		
	}
	
	
	public void convertOrder(OrderDto vo, Delivery deliveryVo, GoodsDto goodVo, Order order) throws Exception {
		order.setSiteId(vo.getSiteId());
		order.setStatus(deliveryVo.getStatus());
		order.setOrderId(Long.parseLong(vo.getOrderId()));
		order.setOrderTime(vo.getOrderDate());
		order.setCommerceId(Long.parseLong(goodVo.getOrderItemId()));
		order.setSkuId(goodVo.getSkuId());
		order.setSkuNo(goodVo.getSkuNo());
		order.setSkuName(goodVo.getSkuName());
		order.setUserId(vo.getUserId());
		order.setSellId(goodVo.getSellerId());
		order.setItemId(goodVo.getItemId());
		order.setKid(goodVo.getKid());
		order.setMid(goodVo.getMicroID());
		try {
			ResponseApiDto result = mshopChannelServer.getStidByMid(Long.parseLong(goodVo.getMicroID()));
			if (result.getCode().equals(0) && null != result.getDatas()) {
				order.setStid(result.getDatas().toString());
			}
		} catch (Exception e) {
//			logger.error("----mid查询stid异常 :{}", goodVo.getMicroID());
		}
		order.setCompanyCode(goodVo.getCompanyCode());
		order.setDeliveryId(deliveryVo.getDeliveryOrderId());
		order.setOrganizationId(goodVo.getMarketingOrganizationId());
		order.setMerchantId(null == goodVo.getMerchantId() ? "0" : goodVo.getMerchantId());
		BigDecimal unitPrice = null;
		if (null != goodVo.getPrice()) {
			unitPrice = new BigDecimal(goodVo.getPrice());
		}
		BigDecimal couponPrice = null;
		if (null != goodVo.getShopCouponPrice()) {
			couponPrice = new BigDecimal(goodVo.getShopCouponPrice());
		}
		Integer buyNum = goodVo.getBuyNum();
		order.setUnitPrice(unitPrice);
		order.setCouponPrice(couponPrice);
		order.setBuyNum(goodVo.getBuyNum());
		if (null != unitPrice && null != buyNum & null != couponPrice) {
			order.setPriceTotal(unitPrice.multiply(new BigDecimal(buyNum)).subtract(couponPrice));
		}
		order.setCategoryFirst(goodVo.getCategoryFirstId());
		order.setCategorySecond(goodVo.getCategorySecondId());
		order.setCategoryThird(goodVo.getCategoryThirdId());
		order.setCategoryFourth(goodVo.getCategoryFourthId());
		order.setSourceType(goodVo.getSourceType());
		order.setBusinessType(null != goodVo.getBusinessType() ? Integer.parseInt(goodVo.getBusinessType()) : null);
	}
	@Test
	public void testOfMessageSave() {
		OrderFullMessage orderFullMessage = new OrderFullMessage();
//		orderFullMessage.setMsgJson("1123");
//		orderFullMessage.setOrderId("1123");
//		orderFullMessage.setCommerceId("1123");
//		orderFullMessage.setDeliveryId("1123");
		orderFullMessage.setOrderStatus(0);
		orderFullMessage.setInsertStatus(1);
//		orderFullMessage.setCreateTime(new Date());
//		orderFullMessage.setUpdateTime(new Date());
//		boolean insert = orderFullMessageService.insert(orderFullMessage);
		EntityWrapper<OrderFullMessage> entityWrapper = new EntityWrapper<OrderFullMessage>();
		boolean update = orderFullMessageService.update(orderFullMessage, entityWrapper.eq("order_id", 1123).eq("commerce_id", 1123).eq("delivery_id", 1123));
		System.out.println(update);
		
	}
	
	@Test
	public void testOfMerge() {
		int[] arrays = new int[] {6,1,3,4,8,2,9,10,5,7};
		int[] mergeSort = new int[10];
	
		for (int i : mergeSort) {
			System.out.println(i);
		}
	}
	
	public int[] MergeSort(int[] array) {
	       if (array.length < 2) return array;
	       int mid = array.length / 2;
	       int[] left = Arrays.copyOfRange(array, 0, mid);
	       int[] right = Arrays.copyOfRange(array, mid, array.length);
	       return merge(MergeSort(left), MergeSort(right));
	   }
	   /**
	    * 归并排序——将两段排序好的数组结合成一个排序数组
	    *
	    * @param left
	    * @param right
	    * @return
	    */
	   public int[] merge(int[] left, int[] right) {
	       int[] result = new int[left.length + right.length];
	       for (int index = 0, i = 0, j = 0; index < result.length; index++) {
	           if (i >= left.length)
	               result[index] = right[j++];
	           else if (j >= right.length)
	               result[index] = left[i++];
	           else if (left[i] > right[j])
	               result[index] = right[j++];
	           else
	               result[index] = left[i++];
	       }
	       return result;
	   }
	/**
	 * 测试gcache
	 */
	@Test
	public void testOfGcache(){
		try {
			Gcache gcache = gCacheService.gcache();
			String keyoneValue = gcache.get("keyone");
			System.out.println("获取值1："+keyoneValue);
			Long key1 = gcache.del("keyone");
			System.out.println("第一次删除："+key1);
			long setex = gcache.setnxex("keyone", 500, "value");
			System.out.println("第一次设置值："+setex);
			Long setnxex = gcache.setnxex("keyone", 500, "value");
			System.out.println("第二次设置值："+setnxex);
			System.out.println("是否存在1:"+gcache.exists("keyone"));
			System.out.println("获取值2："+gcache.get("keyone"));
			Long key2 = gcache.del("keyone");
			System.out.println("第二次删除："+key2);
			System.out.println("是否存在2:"+gcache.exists("keyone"));
			System.out.println("获取值3："+gcache.get("keyone"));
//			Long setnxex = gcache.setnxex("key", 5, "value");
//			Thread.sleep(5000);
//			System.out.println("是否存在2:"+gcache.exists("key"));
//			System.out.println(gcache.get("key"));
//			long setex1 = gcache.setnxex("key", 1, "value");
//			System.out.println(setex1);
		}catch (Exception e){
			System.out.println(123);
		}

	}
	@Test
	public void testOfGcachePojo(){
		OrderOccur orderOccur = new OrderOccur();
		orderOccur.setOrderId(123L);
		orderOccur.setCommerceId(456L);
		orderOccur.setDeliveryId("6789");
		List<OrderOccur> orderOccurs = new ArrayList<>(1);
		orderOccurs.add(orderOccur);
		String s = JSONArray.toJSONString(orderOccurs);
		Gcache gcache = gCacheService.gcache();
		String userInfo = gcache.setex("userInfo", 500, s);
		System.out.println("存入redis值结果："+userInfo);
		String userInfo1 = gcache.get("userInfo");
		List<OrderOccur> list = JSONArray.parseArray(userInfo1, OrderOccur.class);
		for (OrderOccur thisOrderOccur:list
			 ) {
			System.out.println(orderOccur.getOrderId());
			System.out.println(orderOccur.getCommerceId());
		}
		System.out.println(userInfo1);
	}
	@Test
	public void testOfCacheMapList(){
		Gcache gcache = gCacheService.gcache();
		String map1 = gcache.get("map");
		System.out.println("map1"+map1);
		Map<String, List<String>> moneyMap = new HashMap<String, List<String>>();
		Map<String, List<String>> moneyMap1 = new HashMap<String, List<String>>();
		ArrayList<String> strings = new ArrayList<>(5);
		strings.add("1");
		strings.add("22");
		strings.add("333");
		strings.add("4444");
		strings.add("55555");
		moneyMap.put("money",strings);

		String s = JSONObject.toJSONString(moneyMap);
		System.out.println(s);
		moneyMap1 = JSONObject.parseObject(s,Map.class);
		List<String> money = moneyMap1.get("money");
		for (String thisStr:money
			 ) {
			System.out.println(thisStr);

		}
		String map = gcache.setex("map", 500, s);
		System.out.println(map);
	}
	@Test
	public void testOfCacheList(){
		String temp = null;
		String temp1 = "";
		ArrayList<String> strings = new ArrayList<>(3);
		strings.add("1");
		strings.add("22");
		System.out.println("null值判断："+org.apache.commons.lang.StringUtils.isEmpty(temp));
		System.out.println("空值判断："+org.apache.commons.lang.StringUtils.isEmpty(temp1));
		String s = JSONObject.toJSONString(strings);
		System.out.println("转json后："+s);
		ArrayList<String> otherList = JSONObject.parseObject(s,ArrayList.class);
		for (String string: otherList
			 ) {
			System.out.println(string);
		}
	}
	@Test
	public void testOfStringList(){
		ArrayList<String> strings = new ArrayList<>(2);
		strings.add("123");
		strings.add("234");
		String s = JSONArray.toJSONString(strings);
		List<String> strings1 = JSONArray.parseArray(s, String.class);
		for (String thistr : strings1
			 ) {
			System.out.println(thistr);
		}
	}
	@Test
	public void testOfBean(){
		OrderOccur orderOccur = new OrderOccur();
		orderOccur.setOrderId(123L);
		orderOccur.setCommerceId(321L);
		String s = JSONObject.toJSONString(orderOccur);
		OrderOccur orderOccur1 = JSONObject.parseObject(s, OrderOccur.class);
		System.out.println(orderOccur1.getOrderId());
		System.out.println(orderOccur1.getCommerceId());
	}

}
