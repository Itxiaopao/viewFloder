package com.gome.meidian;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.util.StopWatch;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ReferenceConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.utils.ReferenceConfigCache;
import com.alibaba.dubbo.rpc.service.GenericService;
import com.gome.meidian.entity.CouponVo;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.google.common.collect.Lists;

/**
 * 这里的注释内容，需要对类的使用做一个简单的说明。
 *
 * @author hushengdong
 * @create 2019-10-28 15:21:00
 */
public class LiveDubboTestHelper {

    @Test
    public void venusVshopDubboLive() {

        String applicationName = "venus-vshop";
        String ipPort = "10.125.139.217:30003";
        //接口版本，没有更改为null
        String version = "3.0.0";
        Class className = VshopFacade.class;
        String functionName = "queryVshopByuserId";
        String[] paramClassName = new String[] {"java.lang.String"};

        Object[] paramValue = new Object[] { "58921729563" };
        int a = 1;
        for (int i = 1; i <= 100; i++) {
            Map<String, Object> result = LiveDubboTestHelper
                    .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, version);
            if(null!=result){
                Map<String,Object> businessObj = (Map<String, Object>) result.get("businessObj");
                Integer vshopIdentity = (Integer) businessObj.get("vshopIdentity");
                if (3==vshopIdentity) {
                    System.err.println("结果是：" + (a++));
                }
            }
        }
    }
    @Test
    public void updateVshop() {

        String applicationName = "venus-vshop";
        String ipPort = "10.125.139.217:30003";
        //接口版本，没有更改为null
        String version = "3.0.0";
        Class className = VshopFacade.class;
        String functionName = "updateVshop";
        String[] paramClassName = new String[] {"com.gomeo2o.facade.vshop.entity.VshopInfo"};

        VshopInfo vshopInfo = new VshopInfo();
        vshopInfo.setVshopId(1122911L);
        vshopInfo.setVshopType(1);
        vshopInfo.setUserId(82896288550L);
        vshopInfo.setVshopIdentity(1);

        Object[] paramValue = new Object[] { vshopInfo };
        Map<String, Object> result = LiveDubboTestHelper
                    .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, version);
        System.err.println("结果是：" + result);
    }
    @Test
    public void changePianZong(){
        String applicationName = "meidian-service-user";
        String ipPort = "10.58.166.95:20880";
        //接口版本，没有更改为null
        String version = null;
        Class className = IUserShareBindingManager.class;
        String functionName = "changePianZong";
        String[] paramClassName = new String[] {"java.lang.Long","int"};

        Object[] paramValue = new Object[] { 82896288550L,1 };
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, version);
        System.err.println("结果是：" + result);


    }

    @Test
    public void orderLive() {

        String applicationName = "meidian-service-order";
//        String ipPort = "10.115.41.53:20880";
        String ipPort = "10.115.41.55:20880";
        //接口版本，没有更改为null
        Class className = IOrderShopService.class;
        String functionName = "getStaffInfoWithParam";
        String[] paramClassName = new String[] {"java.lang.Long","java.lang.Long","java.lang.Long","java.util.List","java.lang.String"};

        List<CouponVo> var3 = Lists.newArrayList();
//        CouponVo couponVo7 = new CouponVo();
//        couponVo7.setTicketId("d0631042abc38dadad409f5b9f7d6913");
//        couponVo7.setCouponType(3005L);
//        var3.add(couponVo7);

        Object[] paramValue = new Object[] { 58921729563L,738516,null, var3, null };
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("开始执行");
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, null);
        stopWatch.stop();
        System.err.println("结果是：" + result + "耗时：" + stopWatch.getLastTaskTimeMillis());
    }
    @Test
    public void orderTest() {

        String applicationName = "meidian-service-order";
        String ipPort = "10.115.4.177:20880";
        //接口版本，没有更改为null
        Class className = IOrderShopService.class;
        String functionName = "selectByNewUserIdFromCache";
        String[] paramClassName = new String[] {"long"};

        Object[] paramValue = new Object[] { 100051604302L };
        Map<String, Object> result = LiveDubboTestHelper
                .dubboLive(applicationName, className, functionName, paramClassName, paramValue, ipPort, null);
        System.err.println("结果是：" + result );
    }

    /**
     * 泛化调用 dubbo接口
     *
     * @param name               dubbo接口的应用名称 例如： venus-vshop
     * @param interfaceClassName 你要调用的接口的类 例如：VshopFacade.class
     * @param functionName       要调用的方法的名称 例如： updateVshop
     * @param paramClass         数组，入参的全路径名称 例如： com.gomeo2o.facade.vshop.entity.VshopInfo
     * @param paramValue         数组，入参值 例如： 具体的一个List
     * @param ip                 要调用的IP 例如： 10.125.140.106
     * @param port               端口 例如： 30003
     * @return 返回值
     */
    public static Map<String, Object> dubboLive(String applicationName, Class interfaceClassName, String functionName, String[] paramClass, Object[] paramValue, String ipPort,String version) {
        // dubbo 泛化调用
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(applicationName);
        // 连接注册中心配置
        RegistryConfig registryConfig = new RegistryConfig();
        registryConfig.setProtocol("zookeeper");

        ReferenceConfig<GenericService> reference = new ReferenceConfig<>();

        reference.setApplication(applicationConfig);
        // 直连
        reference.setUrl("dubbo://" + ipPort + "?scope=remote");
        reference.setRegistry(registryConfig);
        reference.setVersion(version);
        reference.setInterface(interfaceClassName);
        //true声明为泛化接口
        reference.setGeneric(true);
        ReferenceConfigCache cache = ReferenceConfigCache.getCache();
        GenericService genericService = cache.get(reference);

        // 泛化调用,接口方法名称+方法参数类型+方法参数值
        Map<String, Object> result = (Map<String, Object>) genericService.$invoke(functionName, paramClass, paramValue);
        System.err.println("结果是：" + result);
        return result;
    }

}
