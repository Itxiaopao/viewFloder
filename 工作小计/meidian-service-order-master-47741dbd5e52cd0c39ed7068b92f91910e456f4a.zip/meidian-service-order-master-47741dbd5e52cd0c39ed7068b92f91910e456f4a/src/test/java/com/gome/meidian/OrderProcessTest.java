package com.gome.meidian;

import com.gome.meidian.service.biz.MeidianCpaOrderBiz;
import com.gome.meidian.service.biz.ReceiveOrderCoreBiz;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.UUID;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class)
@EnableAutoConfiguration
@Slf4j
public class OrderProcessTest {

    @Autowired
    ReceiveOrderCoreBiz receiveOrderCoreBiz;
    @Autowired
    MeidianCpaOrderBiz meidianCpaOrderBiz;

    //已支付
    @Test
    public void payed() {
        String json = getFileContent("payed.txt");
        String msgId = UUID.randomUUID().toString();
        //receiveOrderCoreBiz.processCoreOrder(msgId, json);
        meidianCpaOrderBiz.processOrder(msgId, json);
    }

    // 配送单出库
    @Test
    public void outStock() {
        String json = getFileContent("OutStock.txt");
        String msgId = UUID.randomUUID().toString();
        //receiveOrderCoreBiz.processCoreOrder(msgId, json);
        meidianCpaOrderBiz.processOrder(msgId, json);
    }

    //拒收
    @Test
    public void revice() {
        String json = getFileContent("Revice.txt");
        String msgId = UUID.randomUUID().toString();
        //receiveOrderCoreBiz.processCoreOrder(msgId, json);
        meidianCpaOrderBiz.processOrder(msgId, json);
    }

    // 测试未支付状态的订单
    @Test
    public void testouge() {
        String json = getFileContent("WaitPay.txt");
        String msgId = UUID.randomUUID().toString();
        receiveOrderCoreBiz.processOrder(msgId, json);

    }

    // 测试拆单后的订单
    @Test
    public void WaitPay_OneSku() {
        String json = getFileContent("WaitPay_OneSku.txt");
        String msgId = UUID.randomUUID().toString();
        receiveOrderCoreBiz.processOrder(msgId, json);
    }

    @Test
    public void Payed_OneSku() {
        String json = getFileContent("Payed_OneSku.txt");
        String msgId = UUID.randomUUID().toString();
        receiveOrderCoreBiz.processOrder(msgId, json);
    }

    // 测试拆单后的订单
    @Test
    public void WaitPay_MoreSku() {
        String json = getFileContent("WaitPay_MoreSku.txt");
        String msgId = UUID.randomUUID().toString();
        receiveOrderCoreBiz.processOrder(msgId, json);
    }

    @Test
    public void Payed_MoreSku() {
        String json = getFileContent("Payed_MoreSku.txt");
        String msgId = UUID.randomUUID().toString();
        receiveOrderCoreBiz.processOrder(msgId, json);
    }


    private String getFileContent(String fileName) {
        String path = this.getClass().getClassLoader().getResource("").getPath().toString();
        String filePath = path.substring(1) + fileName;
        File file = new File(filePath);
        StringBuffer sb = new StringBuffer();
        BufferedReader input = null;
        try {
            input = new BufferedReader(new FileReader(file));
            String text;
            while ((text = input.readLine()) != null)
                sb.append(text);

        } catch (Exception ex) {
        } finally {
            if (input != null)
                try {
                    input.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
        System.out.println("编译后src路径：" + sb.toString());
        return sb.toString();
    }


}
