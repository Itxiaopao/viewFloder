package com.gome.meidian;

import cn.com.gome.rebate.calc.CouponsDto;
import cn.com.gome.rebate.calc.Delivery;
import cn.com.gome.rebate.calc.GoodsDto;
import cn.com.gome.rebate.calc.OrderDto;
import com.gome.meidian.dao.*;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.page.BasePageVo;
import com.gome.meidian.page.Pagination;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.service.biz.ReceiveOrderCoreBiz;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
@Slf4j
public class OrderMongodbTest {

	@Autowired
	private MeidianOrderDao meidianOrderDao;
	@Autowired
	private OrderBodyDao orderBodyDao;
	@Autowired
	private OrderDeliveryBodyDao orderDeliveryBodyDao;
	@Autowired
	private MeidianOrderMsgDao meidianOrderMsgDao;

//	@Test
	public void saveOrder() {
		for (int i = 0; i < 10000000; i++) {
			MogOrderInfo mogOrderInfo = new MogOrderInfo();
			mogOrderInfo.setOrderId(11483179654l);
			mogOrderInfo.setCommerceId(3776110114l);
			mogOrderInfo.setDeliveryId("2774863269");
			mogOrderInfo.setUserId(72086250255l);
			mogOrderInfo.setPhoneNo("18811735656");
			mogOrderInfo.setUserWeixin("微信1");//用户微信昵称
			mogOrderInfo.setKid("2iNYb3ZYT5ivRDtVUNMXAY");
			mogOrderInfo.setUserType(1);
			mogOrderInfo.setParentUserId(56097560522l);
			mogOrderInfo.setUserIdPZ(44068516714l);//片总id
			List<Long> list = new ArrayList<>();
			if(i%2 == 0){
				list.add(100000001l);
				list.add(200000001l);
				list.add(300000001l);
			}else{
				list.add(400000001l);
				list.add(500000001l);
				list.add(600000001l);
			}
			list.add(56097560522l);
			mogOrderInfo.setUserIdRelation(list);//链条关系
			mogOrderInfo.setSkuId("1123520095");
			mogOrderInfo.setSkuNo("100421829");
			mogOrderInfo.setSkuName("奇盛魔力擦QS-QJ20");
			mogOrderInfo.setItemId("9140000171");
			mogOrderInfo.setBuyNum(1);
			mogOrderInfo.setPriceTotal(104900l);
			mogOrderInfo.setUnitPrice(104900l);
			mogOrderInfo.setCouponPrice(0l);
			mogOrderInfo.setMerchantId("aa");
			mogOrderInfo.setBrandCode("bb");
			mogOrderInfo.setSiteId("qw");
			mogOrderInfo.setOrderStatus(1);//美店订单状态
			mogOrderInfo.setShowStatus(1);//展示状态
			mogOrderInfo.setAwardMoney(20l);
			mogOrderInfo.setCommMoney(30l);
			mogOrderInfo.setOrderTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
			mogOrderInfo.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
			mogOrderInfo.setUpdateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
			meidianOrderDao.saveOrderInfo(mogOrderInfo);
		}
	}
	
//	@Test
	public void delOrderInfoById() {
		meidianOrderDao.delOrderInfoById("5d023d831c24e41ed83de13a");
	}
	
//	@Test
	public void updateOrderData() {
		MogOrderInfo orderInfo = new MogOrderInfo();
		orderInfo.setId("5d04e7646d22f65704827296");
		orderInfo.setPhoneNo("18811735656");
		meidianOrderDao.updateOrderData(orderInfo);
	}
	
//	@Test
	public void queryOrderList() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		List<Long> userIdRelation = new ArrayList<>();
		userIdRelation.add(100049062015l);
		reqOrderVo.setUserIdRelation(userIdRelation);
//		reqOrderVo.setOrderId(22222l);
//		reqOrderVo.setId("5d04e7646d22f65704827296");
		ResultEntity<List<MogOrderInfo>> result = meidianOrderDao.queryOrderList(reqOrderVo);
		List<MogOrderInfo> list = result.getBusinessObj();
		System.out.println("查询总数:"+list.size());
	}
	
//	@Test
	public void queryPageOrderList() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		BasePageVo basePageVo = new BasePageVo();
		basePageVo.setPageNo(1);
		basePageVo.setPageSize(10);
		reqOrderVo.setBasePageVo(basePageVo);
		List<Long> userIdRelation = new ArrayList<>();
		userIdRelation.add(104l);
		reqOrderVo.setUserIdRelation(userIdRelation);
		ResultEntity<Pagination<MogOrderInfo>> result = meidianOrderDao.queryPageOrderList(reqOrderVo);
		Pagination<MogOrderInfo> page = result.getBusinessObj();
		System.out.println("查询总数:"+page.getTotalCount());
	}
	
//	@Test
	public void querySumOrderPrice() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		List<Long> userIdRelation = new ArrayList<>();
		userIdRelation.add(105l);
		reqOrderVo.setUserIdRelation(userIdRelation);
		ResultEntity<VitalOrderVo> result = meidianOrderDao.querySumOrderPrice(reqOrderVo);
		VitalOrderVo vitalOrder = result.getBusinessObj();
		System.out.println("查询总数:"+vitalOrder.getCountOrderNum());
	}
	
//	@Test
	public void queryPageGroupSumOrderPrice() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		BasePageVo basePageVo = new BasePageVo();
		basePageVo.setPageNo(1);
		basePageVo.setPageSize(10);
		reqOrderVo.setBasePageVo(basePageVo);
		reqOrderVo.setUserIdPZ(1l);
		reqOrderVo.setParentOutUserId(1l);
		ResultEntity<Pagination<VitalOrderVo>> result = meidianOrderDao.queryPageGroupSumOrderPrice(reqOrderVo);
		Pagination<VitalOrderVo> page = result.getBusinessObj();
		System.out.println("查询总数:"+page.getTotalCount());
	}
	
//	@Test
	public void queryPageOrderListNoPay() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		BasePageVo basePageVo = new BasePageVo();
		basePageVo.setPageNo(1);
		basePageVo.setPageSize(10);
		reqOrderVo.setBasePageVo(basePageVo);
		List<Long> userIdRelation = new ArrayList<>();
		userIdRelation.add(105l);
		reqOrderVo.setUserIdRelation(userIdRelation);
		ResultEntity<Pagination<VitalOrderPay>> result = meidianOrderDao.queryPageOrderNoPay(reqOrderVo);
		Pagination<VitalOrderPay> page = result.getBusinessObj();
		System.out.println("查询总数:"+page.getTotalCount());
	}
	
//	@Test
	public void queryPageOrderListPay() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		BasePageVo basePageVo = new BasePageVo();
		basePageVo.setPageNo(1);
		basePageVo.setPageSize(10);
		reqOrderVo.setBasePageVo(basePageVo);
		List<Long> userIdRelation = new ArrayList<>();
		userIdRelation.add(105l);
		reqOrderVo.setUserIdRelation(userIdRelation);
		ResultEntity<Pagination<VitalOrderPay>> result = meidianOrderDao.queryPageOrderPay(reqOrderVo);
		Pagination<VitalOrderPay> page = result.getBusinessObj();
		System.out.println("查询总数:"+page.getTotalCount());
	}
	
//	@Test
	public void saveMogOrderBody() {
		MogOrderBody mogOrderBody = new MogOrderBody();
		mogOrderBody.setMsgId("1");
		mogOrderBody.setOrderId(1l);
		mogOrderBody.setUserId(1l);
		mogOrderBody.setMsgBody("aa");
		mogOrderBody.setOrderTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
		mogOrderBody.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
		orderBodyDao.saveOrderBody(mogOrderBody);
	}
	
//	@Test
	public void saveOrderDeliveryBody() {
		MogDeliveryOrderBody mogDeliveryOrderBody = new MogDeliveryOrderBody();
		mogDeliveryOrderBody.setMsgId("1");
		mogDeliveryOrderBody.setOrderId(1l);
		mogDeliveryOrderBody.setDeliveryId("1");
		mogDeliveryOrderBody.setOrderStatus(1);
		mogDeliveryOrderBody.setUserId(1l);
		mogDeliveryOrderBody.setMsgBody("aa");
		mogDeliveryOrderBody.setOrderTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
		mogDeliveryOrderBody.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
		orderDeliveryBodyDao.saveOrderDeliveryBody(mogDeliveryOrderBody);
	}
	
//	@Test
	public void saveOrderMsg() {
		MogOrderMsgInfo mogOrderMsgInfo = new MogOrderMsgInfo();
		mogOrderMsgInfo.setMsgId("1");
		mogOrderMsgInfo.setMsgBody("aa");
		mogOrderMsgInfo.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
		meidianOrderMsgDao.saveOrderMsg(mogOrderMsgInfo);
	}
	
//	@Test
	public void queryTotalOrderPay() {
		ReqOrderVo reqOrderVo = new ReqOrderVo();
		List<Long> userIdRelation = new ArrayList<>();
		userIdRelation.add(100051184815l);
		reqOrderVo.setUserIdRelation(userIdRelation);
		List<Integer> showStatusList = new ArrayList<>();
		showStatusList.add(1);
		showStatusList.add(2);
		showStatusList.add(5);
		reqOrderVo.setShowStatusList(showStatusList);
		ResultEntity<Integer> resultEntity = meidianOrderDao.queryTotalOrderPay(reqOrderVo);
		Integer num = resultEntity.getBusinessObj();
		System.out.println(num);
	}

	@Autowired
	INewOrderService newOrderService;
	//待支付
	@Test
	public void handleOrder() throws Exception {
		log.info("当前时间{}",new Date());
		log.info("当前时间{}",System.currentTimeMillis());
		/*Date orderStartTime = org.apache.commons.lang3.time.DateUtils.parseDate("2019-09-20 00:00:00","yyyy-MM-dd HH:mm:ss");
		Date orderEndTime =  org.apache.commons.lang3.time.DateUtils.parseDate("2019-10-11 00:00:00","yyyy-MM-dd HH:mm:ss");
		//待支付
		List<Integer> orderStatus1 = new ArrayList<>();
		orderStatus1.add(14);
		ResultEntity<Boolean> flag1 = orderReportServiceImpl.mongoHistoryOrderSync(orderStartTime, orderEndTime, orderStatus1);
		System.out.println(flag1);*/
		//已支付
		/*List<Integer> orderStatus2 = new ArrayList<>();
		orderStatus2.add(1);
		ResultEntity<Boolean> flag2 = orderReportServiceImpl.mongoHistoryBackOrderSync(orderStartTime, orderEndTime, orderStatus2);
		//逆向
		List<Integer> orderStatus3 = new ArrayList<>();
		orderStatus3.add(20);
		ResultEntity<Boolean> flag3 = orderReportServiceImpl.mongoHistoryOrderSync(orderStartTime, orderEndTime, orderStatus3);
		List<Integer> orderStatus4 = new ArrayList<>();
		orderStatus4.add(2);
		orderStatus4.add(3);
		orderStatus4.add(6);
		ResultEntity<Boolean> flag4 = orderReportServiceImpl.mongoHistoryBackOrderSync(orderStartTime, orderEndTime, orderStatus4);
		//返利
		ResultEntity<Boolean> flag5 = orderReportServiceImpl.mongoHistoryRebateOrderSync(orderStartTime, orderEndTime);
		System.out.println("1");*/
	}

	@Autowired
	ReceiveOrderCoreBiz receiveOrderCoreBiz;

	StringBuilder sb = new StringBuilder();
	/**
	 * 场景一：分享人是片总 已测
	 */
	@Test
	public void test0() {
		OrderDto orderDto = new OrderDto();
		orderDto.setOrderId("19015101941");
		orderDto.setUserId("100051301203");
		List<Delivery> deliveries = new ArrayList<>();
		Delivery delivery = new Delivery();
		delivery.setStatus(1);
		delivery.setDeliveryOrderId("2570259570");
		List<GoodsDto> goodsDtos = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		goodsDto.setRetailId("100040132303");
		delivery.setGoodsList(goodsDtos);
		deliveries.add(delivery);
		orderDto.setDeliveryList(deliveries);
		MeidianUserInfoDTO meidianUserInfoDTO = receiveOrderCoreBiz.checkMeiDianOrder(Long.parseLong(orderDto.getUserId()), goodsDto,sb);
//		System.out.println(meidianUserInfoDTO);
	}

	/**
	 * 分享人是社会美店主 已测
	 */
	@Test
	public void test1() {
		OrderDto orderDto = new OrderDto();
		orderDto.setOrderId("19015101941");
		orderDto.setUserId("100051301203");
		List<Delivery> deliveries = new ArrayList<>();
		Delivery delivery = new Delivery();
		delivery.setStatus(1);
		delivery.setDeliveryOrderId("2570259570");
		List<GoodsDto> goodsDtos = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		delivery.setGoodsList(goodsDtos);
		goodsDto.setRetailId("75041522723");
		deliveries.add(delivery);
		orderDto.setDeliveryList(deliveries);
		MeidianUserInfoDTO meidianUserInfoDTO = receiveOrderCoreBiz.checkMeiDianOrder(Long.parseLong(orderDto.getUserId()), goodsDto,sb);
		System.out.println(meidianUserInfoDTO);
	}

	/*************************************
	 * 使用两张券（两种分别有多条转增记录） 未测
	 */
	@Test
	public void test2() {
		OrderDto orderDto = new OrderDto();
		orderDto.setOrderId("19015101941");
		orderDto.setUserId("100051301203");
		List<Delivery> deliveries = new ArrayList<>();
		Delivery delivery = new Delivery();
		delivery.setStatus(1);
		delivery.setDeliveryOrderId("2570259570");
		List<GoodsDto> goodsDtos = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		List<CouponsDto> couponsDtoList = new ArrayList<CouponsDto>();
		CouponsDto couponsDto = new CouponsDto();
		couponsDto.setCouponId("1128011373");
		couponsDto.setCouponType(3003L);
		couponsDtoList.add(couponsDto);
//		CouponsDto couponsDto1 = new CouponsDto();
//		couponsDto1.setCouponId("1128009553");
//		couponsDto1.setCouponType(3003L);
//		couponsDtoList.add(couponsDto1);
		goodsDto.setCouponsDtoList(couponsDtoList);
		goodsDto.setRetailId("12553");
		delivery.setGoodsList(goodsDtos);
		deliveries.add(delivery);
		orderDto.setDeliveryList(deliveries);
		MeidianUserInfoDTO meidianUserInfoDTO = receiveOrderCoreBiz.checkMeiDianOrder(Long.parseLong(orderDto.getUserId()), goodsDto,sb);
	}
	/*************************************
	 * 使用多种类型的券（含有转增历史） 已测
	 */
	@Test
	public void test3() {
		OrderDto orderDto = new OrderDto();
		orderDto.setOrderId("19015101941");
		orderDto.setUserId("100051301203");
		List<Delivery> deliveries = new ArrayList<>();
		Delivery delivery = new Delivery();
		delivery.setStatus(1);
		delivery.setDeliveryOrderId("2570259570");
		List<GoodsDto> goodsDtos = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		List<CouponsDto> couponsDtoList = new ArrayList<CouponsDto>();
		CouponsDto couponsDto = new CouponsDto();
		couponsDto.setTicketId("149cababb8a27c5f84f3fd6f69dfb74f");
		couponsDto.setCouponType(3001L);
		couponsDtoList.add(couponsDto);
		CouponsDto couponsDto1 = new CouponsDto();
		couponsDto1.setCouponId("1128011373");
		couponsDto1.setCouponType(3003L);
		couponsDtoList.add(couponsDto1);

		goodsDto.setCouponsDtoList(couponsDtoList);
		delivery.setGoodsList(goodsDtos);
		deliveries.add(delivery);
		orderDto.setDeliveryList(deliveries);
		MeidianUserInfoDTO meidianUserInfoDTO = receiveOrderCoreBiz.checkMeiDianOrder(Long.parseLong(orderDto.getUserId()), goodsDto,sb);
	}
	/*************************************
	 * 使用多种类型的券无转增历史  已测
	 */
	@Test
	public void test5() {
		OrderDto orderDto = new OrderDto();
		orderDto.setOrderId("19015101941");
		orderDto.setUserId("100051301203");
		List<Delivery> deliveries = new ArrayList<>();
		Delivery delivery = new Delivery();
		delivery.setStatus(1);
		delivery.setDeliveryOrderId("2570259570");
		List<GoodsDto> goodsDtos = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		List<CouponsDto> couponsDtoList = new ArrayList<CouponsDto>();
		CouponsDto couponsDto = new CouponsDto();
		couponsDto.setTicketId("149cababb8a27c5f84f3fd6f69dfb74f");
		couponsDto.setCouponType(3001L);
		couponsDtoList.add(couponsDto);
		CouponsDto couponsDto1 = new CouponsDto();
		couponsDto1.setTicketId("PM23200034");
		couponsDto1.setCouponType(3005L);
		couponsDtoList.add(couponsDto1);

		goodsDto.setCouponsDtoList(couponsDtoList);
		delivery.setGoodsList(goodsDtos);
		deliveries.add(delivery);
		orderDto.setDeliveryList(deliveries);
		MeidianUserInfoDTO meidianUserInfoDTO = receiveOrderCoreBiz.checkMeiDianOrder(Long.parseLong(orderDto.getUserId()), goodsDto,sb);
	}
	/*************************************
	 * 使用单种类型的券无转增历史  已测
	 */
	@Test
	public void test4() {
		OrderDto orderDto = new OrderDto();
		orderDto.setOrderId("19015101941");
		orderDto.setUserId("100051301203");
		List<Delivery> deliveries = new ArrayList<>();
		Delivery delivery = new Delivery();
		delivery.setStatus(1);
		delivery.setDeliveryOrderId("2570259570");
		List<GoodsDto> goodsDtos = new ArrayList<>();
		GoodsDto goodsDto = new GoodsDto();
		List<CouponsDto> couponsDtoList = new ArrayList<CouponsDto>();
		CouponsDto couponsDto = new CouponsDto();
		couponsDto.setTicketId("149cababb8a27c5f84f3fd6f69dfb74f");
		couponsDto.setCouponType(3001L);
		couponsDtoList.add(couponsDto);
		CouponsDto couponsDto1 = new CouponsDto();
		couponsDto1.setTicketId("YK23212115");
		couponsDto1.setCouponType(3001L);
		couponsDtoList.add(couponsDto1);

		goodsDto.setCouponsDtoList(couponsDtoList);
		delivery.setGoodsList(goodsDtos);
		deliveries.add(delivery);
		orderDto.setDeliveryList(deliveries);
		MeidianUserInfoDTO meidianUserInfoDTO = receiveOrderCoreBiz.checkMeiDianOrder(Long.parseLong(orderDto.getUserId()), goodsDto,sb);
	}
	@Test
	public void testCom() {
		MShopShareBindingDto mShopShareBindingDto = receiveOrderCoreBiz.checkOrderAndShare(73981587395L, 71596622827L);
		System.out.println(mShopShareBindingDto);
	}


}
