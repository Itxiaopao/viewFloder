package com.gome.meidian;

import java.util.List;

import com.gome.diamond.annotations.DiamondValue;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSON;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.dto.MeidianBangbangCalcTypeDto;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.service.IMeidianBangbangCalcTypeService;
import com.gome.meidian.service.biz.MeidianBangBangOrderCacheBiz;
import redis.Gcache;
import redis.gcache.KeysExecutor;

/**
 * @author limenghui
 * @create 2020-06-24 16:17
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class)
public class BangBangTest {

    @DiamondValue("${business.meidian.all.hammerStr}")
    private String allHammerStr;
    @DiamondValue("${business.meidian.default.hammer.mid}")
    private String defaultHammerMid;
    @DiamondValue("${business.meidian.default.hammer.userId}")
    private String defaultHammerUserId;
    @DiamondValue("${business.meidian.default.hammer.regionId}")
    private String defaultHammerRegionId;
    @DiamondValue("${business.meidian.default.hammer.regionName}")
    private String defaultHammerRegionName;
    @DiamondValue("${business.meidian.default.hammer.branchId}")
    private String defaultHammerBranchId;
    @DiamondValue("${business.meidian.default.hammer.branchName}")
    private String defaultHammerBranchName;
    @DiamondValue("${business.meidian.default.hammer.branchSecondId}")
    private String defaultHammerBranchSecondId;
    @DiamondValue("${business.meidian.default.hammer.branchSecondName}")
    private String defaultHammerBranchSecondName;
    @DiamondValue("${business.meidian.default.hammer.storeId}")
    private String defaultHammerStoreId;
    @DiamondValue("${business.meidian.default.hammer.storeName}")
    private String defaultHammerStoreName;
    @DiamondValue("${business.meidian.default.hammer.salesOrganization}")
    private String defaultHammerSalesOrganization;
    @DiamondValue("${business.meidian.race.activity.switch}")
    private Boolean activitySwitch;
    @DiamondValue("${business.meidian.race.activity.beginTime}")
    private String beginTime;
    @DiamondValue("${business.meidian.race.activity.endTime}")
    private String endTime;
    @DiamondValue("${business.meidian.race.activity.suspendTime}")
    private String suspendTime;
    @DiamondValue("${business.meidian.race.activityId}")
    private String activityId;
    @DiamondValue("${business.meidian.race.stage.money.condition}")
    private Long stageMoneyCondition;
    @DiamondValue("${business.meidian.race.stage.inviteUser.condition}")
    private Long stageInviteUserCondition;
    @DiamondValue("${business.meidian.cpa.orderTimeout}")
    private String orderTimeout;
    @DiamondValue("${business.meidian.cpa.restrictPrice}")
    private String restrictPrice;
    @DiamondValue("${business.meidian.cpa.rebatePrice}")
    private String rebatePrice;
    @DiamondValue("${query.db.switch}")
    private Boolean queryDbSwitch;
    @Test
    public void test5(){

    }


    @Autowired
    IMeidianBangbangCalcTypeService iMeidianBangbangCalcTypeService;
    @Autowired
    private MeidianBangBangOrderCacheBiz orderCacheBiz;
    @Autowired
    private Gcache gcache;

    @Test
    public void queryfirstOrder(){
        int i = iMeidianBangbangCalcTypeService.queryfirstOrder(100049064004L);
        System.err.println("结果是" + JSON.toJSONString(i));
    }
    @Test
    public void queryLoyalFans(){
        int i = iMeidianBangbangCalcTypeService.queryLoyalFans(100049064004L);
        System.err.println("结果是" + JSON.toJSONString(i));

    }

    @Test
    public void test() {
        for (int i = 0; i < 10; i++) {
            ResultEntity<List<MeidianBangbangCalcTypeDto>> listResultEntity = iMeidianBangbangCalcTypeService.queryList(100053969604L, null, 4, 0, 10);
            System.err.println("结果是：" + listResultEntity.getBusinessObj());
        }

    }

    @Test
    public void test2() {
        String redisKey = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_PROFIT_STR_PREFIX, 10086L, 1008611L, "12323");
        Boolean calc = orderCacheBiz.existCalcProfit(10086L, 1008611L, "12323");
        Boolean calc2 = orderCacheBiz.existCalcProfit(10086L, 1008611L, "12323");
        System.out.println(calc);
        System.out.println(calc2);
        String s = gcache.get(redisKey);
        Long ttl = gcache.ttl(redisKey);
        System.out.println(s);
        System.out.println(ttl);
        orderCacheBiz.delCalcProfit(10086L, 1008611L, "12323");
        String s2 = gcache.get(redisKey);
        System.out.println(s2);
    }

@Test
    public void test3() {
       gcache.scanCluster("crp_order_bangbang_calc_profit_str_prefix*",1024, new KeysExecutor() {
           @Override
           public void execute(List<String> keys) {
               for (String str: keys) {
                   gcache.del(str);
                   System.out.println("正在删除key"+keys);
               }
           }
       });
    System.out.println();
    }

}
