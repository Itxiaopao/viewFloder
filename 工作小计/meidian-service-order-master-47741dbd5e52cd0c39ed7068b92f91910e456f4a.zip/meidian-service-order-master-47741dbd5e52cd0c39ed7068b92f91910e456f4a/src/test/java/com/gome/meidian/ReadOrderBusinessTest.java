package com.gome.meidian;

import com.gome.meidian.config.GCacheConfig;
import com.gome.meidian.entity.OrderDetailRequest;
import com.gome.meidian.entity.OrderDetailResponse;
import com.gome.meidian.service.IOrderDetailService;
import com.gome.meidian.util.CouponUtils;
import com.gome.meidian.util.DateUtils;
import com.gome.pangu.promotionapply.client.coupongive.CouponGiveQueryService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;
import redis.clients.jedis.Tuple;

import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class ReadOrderBusinessTest {

	@Autowired
	IOrderDetailService detailService;

	@Autowired
	GCacheConfig gCacheConfig;
	
	@Test
	public void test() {
		OrderDetailRequest orderDetailRequest = new OrderDetailRequest();
		orderDetailRequest.setStartDate(DateUtils.formate("2018-01-26 00:00:00", "yyyy-MM-dd HH:mm:ss"));
		orderDetailRequest.setEndDate(DateUtils.formate("2019-12-27 00:00:00", "yyyy-MM-dd HH:mm:ss"));
		orderDetailRequest.setPageIndex(1);
		orderDetailRequest.setPageSize(10);
		// orderDetailRequest.setStaffId("10098488");
		// orderDetailRequest.setClassifyId("A1");
		// orderDetailRequest.setCategoryFirst("cat10000004");
		// orderDetailRequest.setSkuNo("100253545");
		// orderDetailRequest.setDeliveryId("2771809902");
		// orderDetailRequest.setUserId("100036115415");
		// orderDetailRequest.setStaffType(1);
		orderDetailRequest.setOrderStatus(5);
		Map<Long, List<OrderDetailResponse>> result = detailService.queryOrderDetail(orderDetailRequest);
		System.out.println(result.get("list").size());
	}
	
	
	String key="my_list";
	@Test
	public void testReidList()
	{
			gCacheConfig.gcache();
		///初始化集合
			gCacheConfig.gcache().del(key);
		    gCacheConfig.gcache().sadd(key,"0","1","2","3","4","5","6","7","8");
		    for(Integer i=9;i<100;i++)
		    {
		    	 gCacheConfig.gcache().sadd(key,i.toString());
		    }
	}
	private Object obj=new Object();
	private  void  popList()
	{
		Gcache g=	gCacheConfig.gcache();
		String val=g.spop(key);
		if(val==null||val=="")
		{
			System.out.println("红包已经完了！");
		}
		else
		{
			System.out.println("红包拿去成功。批次为:"+val);
		}
		
	//g.close();
	}
	
	
	String zkey="z_set";
	@Test
	public void TestZset()
	{
		Gcache g=	gCacheConfig.gcache();
		double score= new Date().getTime();
		for(int i=0;i<2;i++)
		zaddCache(g);
		//Set<String> sets=g.zrangeByLex(zkey, "0", "1");//获取所有的 订单   正序
		//Set<String> sets=g.zrange(zkey, 0, -1);//获取所有的 订单   正序
		//Set<String> sets=g.zrevrange(zkey, 0, -1);//获取所有的 订单   正序
		Set<Tuple>  sets=g.zrevrangeWithScores(zkey, 0, -1);
		Iterator<Tuple> iter = sets.iterator();
		while(iter.hasNext())
		{
			Tuple itemJsonStr = iter.next();
			System.out.println("获取 orderId："+itemJsonStr.getScore()+"-"+itemJsonStr.getElement());
		}
		/*for	(int i=0;i<sets.size();i++)
		{
			System.out.println("获取 orderId：");
		}*/
	}
	
	private Long zaddCache(Gcache g)
	{
		Long score=System.currentTimeMillis();
		String orderId=UUID.randomUUID().toString();
		System.out.println("存入成功 score："+score+",orderId:"+ orderId);
		return g.zadd(zkey, score, orderId);
	}
	
	
	
	String hkey="hashMap";
	@Test
	public void TesthashMap()
	{
//	  Gcache g=	gCacheConfig.gcache();
//	  g.hset(hkey, "mid_001", "1000");
//	  g.hset(hkey, "mid_002", "100011");
//	  g.hset(hkey, "mid_003", "1000111");
//	  g.hset(hkey, "mik_003", "1000222");
//	  g.hset(hkey, "mid_004", "1000115");
//
//	 String value= g.hget(hkey, "mid_003");
//		System.out.println("hash values is ："+value);
		System.out.println(Integer.MAX_VALUE);
	}
	
	public class MyThread  implements Runnable
	{

		@Override
		public void run() {
			popList();	
		}
	}
	@Autowired
	CouponUtils couponUtils;
	@Autowired
	CouponGiveQueryService couponGiveQueryService;
//	@Test
//	public void testCoupon(){
//		try {
//			CouponVo couponVoA = new CouponVo();
//			couponVoA.setCouponType(3002L);
//			couponVoA.setCouponId("1001674230");
//			CouponVo couponVoB = new CouponVo();
//			couponVoB.setCouponType(3003L);
//			couponVoB.setCouponId("1128011363");
//			List<CouponVo> couponVoList = new ArrayList<CouponVo>();
//			couponVoList.add(couponVoA);
//			couponVoList.add(couponVoB);
//			couponUtils.filterCouponVoList(couponVoList);
//			System.out.println();
//			System.out.println();
//			List<String> couponIdList = couponGiveParamDTO.getCouponIdList();
//			for (int i = 0 , j = couponIdList.size() ; i < j ; i++){
//				System.out.println(couponIdList.get(i));
//			}
//			/*//下单人userId
//			couponGiveParamDTO.setUserId(String.valueOf(100051465202L));
//			//一个type,对个券ID,返回多个券ID的集合
//			ResultDTO<List<CouponGiveResultDTO>> listResultDTO = couponGiveQueryService.queryCouponGiveInfo(couponGiveParamDTO);
//
//			if (null != listResultDTO && null != listResultDTO.getData() && CollectionUtils.isNotEmpty(listResultDTO.getData())) {
//				//最终转赠的店主用户ID
//				Long transferUserId = couponUtils.filterCouponGiveResultDTO(listResultDTO.getData());
//			}*/
//		}catch (Exception e){
//			e.printStackTrace();
//		}
//	}
}
