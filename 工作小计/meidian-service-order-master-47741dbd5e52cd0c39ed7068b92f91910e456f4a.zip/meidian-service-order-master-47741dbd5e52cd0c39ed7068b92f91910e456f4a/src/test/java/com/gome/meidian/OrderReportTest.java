package com.gome.meidian;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.dao.MeidianOrderDao;
import com.gome.meidian.dao.MogRaceUserInfoDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.service.biz.RaceBiz;
import com.gome.meidian.service.biz.ReceiveOrderCoreBiz;
import com.gome.meidian.service.impl.OrderShopServiceImpl;
import com.gome.meidian.service.impl.SaleRaceServiceImpl;
import com.gome.meidian.service.util.InviteUserRaceTask;
import com.gome.meidian.service.util.SaleRaceTask;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.util.DealWithSaleChannel;
import com.gome.meidian.vo.MogRaceUserInfo;
import com.gome.meidian.vo.ReqOrderVo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;

import java.math.BigDecimal;
import java.util.*;

/**
 * @author limenghui-ds
 * @create 2019-09-19 15:43
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = MeidianServiceOrderApplication.class)
@EnableAutoConfiguration
public class OrderReportTest {

    /**
     * 根据员工关系绑定表判断；电器员工店主/非电器员工店主/发展社会店主；外部美店主；
     * 100040132303-100049086401
     * 100051353722
     */
    @Autowired
    DealWithSaleChannel dealWithSaleChannel;

    @Test
    public void getMhsopEmployeeType() {
        ArrayList<Long> longs = new ArrayList<>();
        longs.add(100040132403L);
        longs.add(100049086401L);
//        longs.add(100049086402L);
        Integer integer = dealWithSaleChannel.checkSaleChannel(100051353722L, longs);
        System.out.println(integer);
    }

    @Autowired
    MeidianOrderDao meidianOrderDao;

    @Test
    public void testSumPriceTotal() {
        Calendar instance = Calendar.getInstance();
        instance.set(2019, 9, 1, 0, 0, 0);
        Date time = instance.getTime();
        instance.set(2019, 9, 2, 0, 0, 0);
        Date time1 = instance.getTime();
        ReqOrderVo reqOrderVo = new ReqOrderVo();
        reqOrderVo.setOrderStartTime(time);
        reqOrderVo.setOrderEndTime(time1);
        meidianOrderDao.querySumOrderPrice(reqOrderVo);
    }

    @Autowired
    ThreadPoolTaskExecutor threadPoolExecutor;
    @Autowired
    OrderShopServiceImpl orderShopService;
    @Autowired
    MogRaceUserInfoDao mogRaceUserInfoDao;

    @Test
    public void testThreadPool() {
        for (int i = 0; i < 100; i++) {
            MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
            mogRaceUserInfo.setActivityId("activityID");
            mogRaceUserInfo.setIntegral(new Double(i));
            mogRaceUserInfo.setInviteUserCount(50);
            mogRaceUserInfo.setSaleVolume(new Long(999999 + i));
            mogRaceUserInfo.setUserId(new Long(1231231 + i));
            mogRaceUserInfoDao.saveRecord(mogRaceUserInfo);
        }
    }

    @Test
    public void testQuery() {
        ResultEntity<MogRaceUserInfo> mogRaceUserInfoResultEntity = mogRaceUserInfoDao.queryByUserId(100049064004L);
        System.out.println(mogRaceUserInfoResultEntity.getBusinessObj());
    }

    @Test
    public void testQueryList() {
        ResultEntity<List<MogRaceUserInfo>> listResultEntity = mogRaceUserInfoDao.queryList(0, 10);
        System.out.println(listResultEntity.getBusinessObj());
    }

    @Autowired
    SaleRaceServiceImpl userRaceService;

    @Test
    public void testDubboService() {
        ResultEntity<Map<String, Object>> mapResultEntity = userRaceService.queryRaceTopN(100049055306L, 1, 10);
        Map<String, Object> businessObj = mapResultEntity.getBusinessObj();
        System.out.println(businessObj);
    }

    @Test
    public void testUpdate() {
        MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
        mogRaceUserInfo.setUserId(100049086401L);
        mogRaceUserInfo.setActivityId("activity01");
        BigDecimal bigDecimal = new BigDecimal(4.8);
        BigDecimal bigDecimal1 = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP);
        mogRaceUserInfo.setIntegral(bigDecimal1.doubleValue());
        mogRaceUserInfo.setSaleVolume(4091600L);
        mogRaceUserInfo.setVersion(32);
//        String s = JSONObject.toJSONString(mogRaceUserInfo);
//        System.out.println(s);
//        MogRaceUserInfo mogRaceUserInfo1 = JSONObject.parseObject(s, MogRaceUserInfo.class);
//        System.out.println(mogRaceUserInfo1);
        mogRaceUserInfoDao.updateUserRace(mogRaceUserInfo);
    }

    @Autowired
    Gcache gcache;

    @Test
    public void testRedisQueue() {
        for (int i = 0; i < 1000; i++) {
            MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
            mogRaceUserInfo.setActivityId("activityId01");
            mogRaceUserInfo.setUserId(new Long(i));
            gcache.rpush(Constant.SALE_RACE_DISTRIBUTED_LISTENER, JSONObject.toJSONString(mogRaceUserInfo));
        }
        try {
            Thread.sleep(3000L);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Autowired
    ThreadPoolTaskExecutor threadPoolTaskExecutor;


    @Autowired
    ReceiveOrderCoreBiz receiveOrderCoreBiz;

    @Autowired
    private SaleRaceServiceImpl saleRaceService;

    @Test
    public void testBeginTime() {
        ResultEntity<Map<String, Long>> mapResultEntity = saleRaceService.queryActivityCountdown();
        Map<String, Long> businessObj = mapResultEntity.getBusinessObj();
        System.out.println(businessObj);
    }

    @Autowired
    RaceBiz raceBiz;
    @Autowired
    InviteUserRaceTask inviteUserRaceTask;
    @Autowired
    SaleRaceTask saleRaceTask;

    @Test
    public void testRepeat() {
        Thread thread = new Thread() {
            @Override
            public void run() {
                MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
                mogRaceUserInfo.setActivityId("activityId01");
                mogRaceUserInfo.setUserId(100049064004L);
                mogRaceUserInfo.setSaleVolume(1000000L);
                saleRaceTask.run(mogRaceUserInfo);
            }
        };
        Thread thread1 = new Thread() {
            @Override
            public void run() {
                MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
                mogRaceUserInfo.setActivityId("activityId01");
                mogRaceUserInfo.setUserId(100049064004L);
                mogRaceUserInfo.setInviteUserCount(1);
                inviteUserRaceTask.run(mogRaceUserInfo);
            }
        };
        threadPoolTaskExecutor.submit(thread);
        threadPoolTaskExecutor.submit(thread1);
        try {
            Thread.sleep(3000L);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;

    @Test
    public void testJson() {
        Long moneyCondition = checkSaleRaceUtils.getMoneyCondition();
        System.out.println(moneyCondition);
    }

    @Test
    public void testSale() {
        int i = 80000 / 10000;
        System.out.println(i);
        int i1 = 80001 / 10000;
        System.out.println(i1);
        int i2 = 1 / 10000;
        System.out.println(i2);
        int i3 = 2 / 3;
        System.out.println(i3);
        int i4 = 5 / 3;
        System.out.println(i4);
    }

    @Test
    public void testInviteUser() {
        boolean b = checkSaleRaceUtils.checkActivityIsEffective();
        boolean b2 = checkSaleRaceUtils.checkIsActivityTime(new Date());
        boolean b1 = checkSaleRaceUtils.checkSuspendTime(new Date());
        String activityId = checkSaleRaceUtils.getActivityId();
        Date activityBeginTime = checkSaleRaceUtils.getActivityBeginTime();
        Long moneyCondition = checkSaleRaceUtils.getMoneyCondition();
        Long aLong = checkSaleRaceUtils.geInviteUserCountCondition();
        System.out.println(aLong);
    }

    @Test
    public void testDouble() {
        Integer saleIntegral = 4091400 / 1000000;
        Integer newInviteUserIntegral = (1 + 2) / 3;
        BigDecimal bigDecimal = new BigDecimal(saleIntegral * 0.7);
        BigDecimal bigDecimal2 = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP);
        BigDecimal bigDecimal1 = new BigDecimal(newInviteUserIntegral * 0.3);
        BigDecimal bigDecimal3 = bigDecimal1.setScale(1, BigDecimal.ROUND_HALF_UP);
        BigDecimal resultIntegral = bigDecimal2.add(bigDecimal3);
        Double aDouble = new Double(String.valueOf(resultIntegral));
        System.out.println(resultIntegral);
    }

}
