package com.gome.meidian;

import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.primitives.Ints;

public class BaseTest {
    @Test
    public void testDate(){
        Date date = new Date(1594884147628L);
        System.err.println("结果是" + JSON.toJSONString(DateFormatUtils.format(date, "yyyy-MM-dd HH:mm:ss")));

    }
    @Test
    public void testSort(){
        ArrayList<Integer> integers = Lists.newArrayList(1, 2, 3, 4);
        List<Integer> collect = integers.stream().sorted(new Comparator<Integer>() {
            @Override public int compare(Integer o1, Integer o2) {
                return o2.compareTo(o1);
            }
        }).collect(Collectors.toList());
        System.err.println("结果是" + JSON.toJSONString(collect));

    }
    @Test public void test04() {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime effectEndTime = LocalDateTime.now().minus(Period.ofDays(7));
        System.err.println("结果是：" + dateTimeFormatter.format(effectEndTime));

    }
    @Test public void test03() {
        List emptyList = Collections.EMPTY_LIST;
        System.err.println("结果是：" + JSON.toJSONString(emptyList));
    }
    @Test
    public void test02() {
        ArrayList<Map<String, String>> users = Lists.newArrayList(ImmutableMap.of("id", "1", "name", "lly"),
                ImmutableMap.of("id", "1", "name", "lmh"));
        Map<Integer, String> map = users.stream()
                .collect(Collectors.toMap(m -> Ints.tryParse(m.get("id")), m -> (m.get("name")), (a, b) -> b));
        System.out.println(map);
    }

    @Test
    public void test(){
        List<Integer> collect = Lists.newArrayList(9, 4, 3, 2, 5, 4, 3, 1, 5).parallelStream().filter(i -> i > 2)
                .collect(Collectors.toList());
        System.err.println("结果是：" + collect);

    }
}
