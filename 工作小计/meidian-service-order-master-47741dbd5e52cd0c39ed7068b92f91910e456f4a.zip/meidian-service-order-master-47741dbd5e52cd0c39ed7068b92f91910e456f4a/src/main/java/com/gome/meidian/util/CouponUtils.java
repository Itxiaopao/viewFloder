package com.gome.meidian.util;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.entity.CouponVo;
import com.gome.pangu.promotionapply.client.coupongive.dto.CouponGiveParamDTO;
import com.gome.pangu.promotionapply.client.coupongive.dto.CouponGiveResultDTO;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import static com.gome.meidian.enums.CouponTypeEnum.couponTypeMap;

/**
 * @author chenchen-ds6
 */
@Component("couponUtils")
@Slf4j
public class CouponUtils {

    public Map<Integer, CouponGiveParamDTO> filterCouponVoList(List<CouponVo> couponVoList){
        log.info("OrderShopServiceImpl.getStaffInfoWithParam.filterCouponVoList 券的参数信息 {} ", couponVoList);

        Map<Integer, CouponGiveParamDTO> map = new TreeMap<Integer, CouponGiveParamDTO>(new Comparator<Integer>() {
            @Override public int compare(Integer o1, Integer o2) {
                //对key的升序排序
                return o1 - o2;
            }
        });
        for (CouponVo couponVo : couponVoList) {
            //4.3.2.1
            Integer convertSortCouponType = couponTypeMap.get(couponVo.getCouponType()).getConvertSortCouponType();
            // 新建
            if (null == map.get(convertSortCouponType)) {
                List<String> ticketIdList = null;
                List<String> couponIdList = null;
                CouponGiveParamDTO couponGiveParamDTO = new CouponGiveParamDTO();
                if(StringUtils.isNotBlank(couponVo.getTicketId())) {
                    // 券号
                    ticketIdList = Lists.newArrayList();
                    ticketIdList.add(couponVo.getTicketId());
                }
                if(StringUtils.isNotBlank(couponVo.getCouponId())) {
                    // 券ID
                    couponIdList = Lists.newArrayList();
                    couponIdList.add(couponVo.getCouponId());
                }
                couponGiveParamDTO.setCouponIdList(couponIdList);
                couponGiveParamDTO.setTicketIdList(ticketIdList);
                couponGiveParamDTO.setCouponType(Long.valueOf(couponVo.getCouponType()));
                map.put(convertSortCouponType, couponGiveParamDTO);
            } else {
                // 更新
                CouponGiveParamDTO couponGiveParamDTO = map.get(convertSortCouponType);
                if(StringUtils.isNotBlank(couponVo.getCouponId())){
                    couponGiveParamDTO.getCouponIdList().add(couponVo.getCouponId());
                }
                if(StringUtils.isNotBlank(couponVo.getTicketId())) {
                    couponGiveParamDTO.getTicketIdList().add(couponVo.getTicketId());
                }
            }
        }
        log.info("OrderShopServiceImpl.getStaffInfoWithParam.filterCouponVoList 券的参数信息 {} ,按照神券>美券>红券>蓝券优先级排列的结果是：{}",
                couponVoList, JSON.toJSONString(map));
        return map;
    }


    /**
     * 相同券ID之间按照排序，取时间最大的
     * 对上面结果进行不同券之间的比较，取时间最小的，最早分享的
     */
    public Long filterCouponGiveResultDTO(List<CouponGiveResultDTO> data){
        Map<String, List<CouponVo>> map = Maps.newLinkedHashMap();
        for (CouponGiveResultDTO datum : data) {
            try {
                CouponVo couponVo = new CouponVo();
                if (null != datum.getCouponId()) {
                    if (null == map.get(datum.getCouponId())) {
                        List<CouponVo> list = Lists.newArrayList();
                        couponVo.setTransferTime(datum.getCreateDate());
                        couponVo.setTransferUserId(analysisRemark(datum.getRemark()));
                        list.add(couponVo);
                        map.put(datum.getCouponId(), list);
                    } else {
                        couponVo.setTransferTime(datum.getCreateDate());
                        couponVo.setTransferUserId(analysisRemark(datum.getRemark()));
                        map.get(datum.getCouponId()).add(couponVo);
                    }
                    //券号
                } else if (null != datum.getTicketId()) {
                    if (null == map.get(datum.getTicketId())) {
                        List<CouponVo> list = Lists.newArrayList();
                        couponVo.setTransferTime(datum.getCreateDate());
                        couponVo.setTransferUserId(analysisRemark(datum.getRemark()));
                        list.add(couponVo);
                        map.put(datum.getTicketId(), list);
                    } else {
                        couponVo.setTransferTime(datum.getCreateDate());
                        couponVo.setTransferUserId(analysisRemark(datum.getRemark()));
                        map.get(datum.getTicketId()).add(couponVo);
                    }
                }
            } catch (Exception e) {
                log.error("OrderShopServiceImpl.getStaffInfoWithParam.filterCouponGiveResultDTO 对券接口的调用结果根据 couponId/ticketId 进行分组，中间出现异常 {}", e);
            }
        }
        log.info("OrderShopServiceImpl.getStaffInfoWithParam 对券接口调用的整理结果是 {} ", map);

        //对每个券ID/券号-对应的集合按照赠送时间，时间最大
        List<CouponVo> result = Lists.newArrayList();
        if (MapUtils.isNotEmpty(map)) {
            for (Map.Entry<String, List<CouponVo>> entry : map.entrySet()) {
                //正序排列，取最大时间
                comparatorByTimeAsc(entry.getValue());
                //获取每个券ID/券号中的最后转赠时间
                result.add(entry.getValue().get(entry.getValue().size() - 1));
            }
        }
        if(CollectionUtils.isNotEmpty(result)){
            //对结果按照时间正序排序，最早分享的店主,在各个券ID/券号之间选择分享时间最早的,最小时间
            comparatorByTimeAsc(result);
            Long transferUserId = result.get(0).getTransferUserId();
            log.info("OrderShopServiceImpl.getStaffInfoWithParam.filterCouponGiveResultDTO 最后一次转增店主的用户ID是 {} ", transferUserId);
            return transferUserId;
        }
        return null;
    }

    public Long analysisRemark(String remark) {
        int i = remark.indexOf("[");
        int i1 = remark.indexOf("]");
        return Long.valueOf(remark.substring(i + 1, i1));
    }

    public void comparatorByTimeAsc(List<CouponVo> list){
        Collections.sort(list, new Comparator<CouponVo>() {
            //o1是后面的，o2是前面的,正序
            @Override public int compare(CouponVo o1, CouponVo o2) {
                if (o2.getTransferTime().getTime() > o1.getTransferTime().getTime()) {
                    return -1;
                }
                return 1;
            }
        });
    }
}
