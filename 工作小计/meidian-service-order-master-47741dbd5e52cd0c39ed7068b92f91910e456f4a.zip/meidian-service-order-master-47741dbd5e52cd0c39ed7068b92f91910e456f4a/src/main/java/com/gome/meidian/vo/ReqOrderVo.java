package com.gome.meidian.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gome.meidian.page.BasePageVo;

public class ReqOrderVo implements Serializable {
	
	private static final long serialVersionUID = -5770638870572843880L;
	
	private String id;//主键id
	private Long orderId;//订单id
	private Long commerceId;//子订单id
	private String deliveryId;//配送id
	private Long userId;//下单人id
	private String phoneNo;//手机号
	private String userWeixin;//用户微信昵称
	private Integer userType; //用户类型  0 普通用户  1 美店主
	private Long parentUserId;//下单人直属上级id
	private Long userIdPZ;//片总id
	private List<Long> userIdRelation;//下单人对应上级集合
	private String skuId;//skuId
	//自定义入参
	private List<Integer> orderStatusList;//美店订单状态  0:待支付 1:待发货 2:已取消 3:待收货 5:已收货 6:售后
	private List<Integer> showStatusList; //显示的订单状态
	private Long parentOutUserId;//父级要排除用户id
	private String orderIdUserWeixin;//订单号或微信昵称
	private Date orderStartTime;//订单开始时间
	private Date orderEndTime;//订单结束时间
	private Boolean awardFlag;//是否剔除不存在提奖金额的订单   true:是  false:否
	private Boolean splitNumFlag;//是否剔除不存在剩余拆单数的订单   true:是  false:否
	private BasePageVo basePageVo;//分页参数
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getCommerceId() {
		return commerceId;
	}
	public void setCommerceId(Long commerceId) {
		this.commerceId = commerceId;
	}
	public String getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getUserWeixin() {
		return userWeixin;
	}
	public void setUserWeixin(String userWeixin) {
		this.userWeixin = userWeixin;
	}
	public Integer getUserType() {
		return userType;
	}
	public void setUserType(Integer userType) {
		this.userType = userType;
	}
	public Long getParentUserId() {
		return parentUserId;
	}
	public void setParentUserId(Long parentUserId) {
		this.parentUserId = parentUserId;
	}
	public Long getUserIdPZ() {
		return userIdPZ;
	}
	public void setUserIdPZ(Long userIdPZ) {
		this.userIdPZ = userIdPZ;
	}
	public List<Long> getUserIdRelation() {
		return userIdRelation;
	}
	public void setUserIdRelation(List<Long> userIdRelation) {
		this.userIdRelation = userIdRelation;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public List<Integer> getOrderStatusList() {
		return orderStatusList;
	}
	public void setOrderStatusList(List<Integer> orderStatusList) {
		this.orderStatusList = orderStatusList;
	}
	public List<Integer> getShowStatusList() {
		return showStatusList;
	}
	public void setShowStatusList(List<Integer> showStatusList) {
		this.showStatusList = showStatusList;
	}
	public Long getParentOutUserId() {
		return parentOutUserId;
	}
	public void setParentOutUserId(Long parentOutUserId) {
		this.parentOutUserId = parentOutUserId;
	}
	public String getOrderIdUserWeixin() {
		return orderIdUserWeixin;
	}
	public void setOrderIdUserWeixin(String orderIdUserWeixin) {
		this.orderIdUserWeixin = orderIdUserWeixin;
	}
	public Date getOrderStartTime() {
		return orderStartTime;
	}
	public void setOrderStartTime(Date orderStartTime) {
		this.orderStartTime = orderStartTime;
	}
	public Date getOrderEndTime() {
		return orderEndTime;
	}
	public void setOrderEndTime(Date orderEndTime) {
		this.orderEndTime = orderEndTime;
	}
	public Boolean getSplitNumFlag() {
		return splitNumFlag;
	}
	public void setSplitNumFlag(Boolean splitNumFlag) {
		this.splitNumFlag = splitNumFlag;
	}
	public Boolean getAwardFlag() {
		return awardFlag;
	}
	public void setAwardFlag(Boolean awardFlag) {
		this.awardFlag = awardFlag;
	}
	public BasePageVo getBasePageVo() {
		return basePageVo;
	}
	public void setBasePageVo(BasePageVo basePageVo) {
		this.basePageVo = basePageVo;
	}
	
}
