package com.gome.meidian.enums;

/**
 * @author sunxueyan-ds
 * @Title: OrderTaskUtil
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/14 10:31
 */
public enum OrderTaskUtil {

    code1("count", "总部合计"),
    code2("fygmd", "非员工美店"),
    code3("A1", "电器"),
    code4("A2", "百货");

    private String code;
    private String name;

    private OrderTaskUtil(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
