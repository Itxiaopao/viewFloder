package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderChannel;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * 退货单表 Mapper 接口
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
public interface OrderChannelMapper extends BaseMapper<OrderChannel> {

    @Select("select * from order_channel")
    OrderChannel select1(@Param("id")Integer id);
}
