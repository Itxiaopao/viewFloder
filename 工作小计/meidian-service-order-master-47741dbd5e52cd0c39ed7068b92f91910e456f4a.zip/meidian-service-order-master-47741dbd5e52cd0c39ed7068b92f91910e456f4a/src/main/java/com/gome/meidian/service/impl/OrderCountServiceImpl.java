package com.gome.meidian.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.gome.meidian.mapper.readorder.OrderOccurReadMapper;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.entity.OrderCountRequest;
import com.gome.meidian.entity.OrderCountResponse;
import com.gome.meidian.service.IOrderCountService;

/**
 * @ClassName: OrderDetailServiceImpl
 * @Description: 订单明细实现类
 * @author likaile
 * @date 2018年10月31日 上午11:09:16
 */
@Service
public class OrderCountServiceImpl implements IOrderCountService {

    @Autowired
    OrderOccurReadMapper orderOccurMapper;

    @Override
    public List<OrderCountResponse> queryOrderCount(OrderCountRequest request) {
        Date startDate = request.getStartDate();
        Date endDate = request.getEndDate();
        if (null == startDate || null == endDate) {
            return null;
        }
        // 电器编码
        String electricType = "A1";
        // 百货编码
        String cargoType = "A2";
        // 搜索类型 0 总部 1 总部（员工） 2总部非员工 3大区 4一级分部 5二级分部 6门店且storeId值必传 7员工且staffId值必传
        Integer groupType = request.getGroupType();
        // 自联营类型
        Integer businessType = request.getBusinessType();
        // 商品编码
        String productId = request.getProductId();
        // skuId
        String skuId = request.getSkuId();
        // skuNo
        String skuNo = request.getSkuNo();

        Integer orderStatus = request.getOrderStatus();

        Boolean isElectric = false;
        //判断是否是电器

        List<OrderCountResponse> orderList = new ArrayList<OrderCountResponse>();
        List<OrderCountResponse> electricList = new ArrayList<OrderCountResponse>();
        List<OrderCountResponse> cargoList = new ArrayList<OrderCountResponse>();
        OrderCountResponse order = null;
        OrderCountResponse electric = null;
        OrderCountResponse cargo = null;
        // 显示所有订单
        if (groupType.equals(0)) {
            order = orderOccurMapper.queryOrderGMV(startDate, endDate, businessType, true, productId, skuId, skuNo, orderStatus);
            electric = orderOccurMapper.queryCateGMV(startDate, endDate, businessType, electricType, true, productId, skuId, skuNo, orderStatus);
            cargo = orderOccurMapper.queryCargoGMVBy(startDate, endDate, businessType, cargoType, true, productId, skuId, skuNo, orderStatus);
        } else if (groupType.equals(1)) {
            // 总部员工订单 显示所有员工订单
            order = orderOccurMapper.queryOrderGMV(startDate, endDate, businessType, null, productId, skuId, skuNo, orderStatus);
            electric = orderOccurMapper.queryCateGMV(startDate, endDate, businessType, electricType, null, productId, skuId, skuNo, orderStatus);
            cargo = orderOccurMapper.queryCargoGMVBy(startDate, endDate, businessType, cargoType, null, productId, skuId, skuNo, orderStatus);
        } else if (groupType.equals(2)) {
            // 所有非员工订单 合计
            order = orderOccurMapper.queryNotStaffOrderGMV(startDate, endDate, businessType, productId, skuId, skuNo, orderStatus);
            electric = orderOccurMapper.queryNotStaffCateGMV(startDate, endDate, businessType, electricType, productId, skuId, skuNo, orderStatus);
            cargo = orderOccurMapper.queryNotStaffCargoGMVBy(startDate, endDate, businessType, cargoType, productId, skuId, skuNo, orderStatus);
        } else if (groupType.equals(6)) {
            // 门店级别
            if (null == request.getStoreId()) {
                return null;
            }
            order = orderOccurMapper.queryOrderGMVByStore(startDate, endDate, businessType, request.getStoreId(), productId, skuId, skuNo, orderStatus);
            electric = orderOccurMapper.queryCateGMVByStore(startDate, endDate, businessType, electricType,
                    request.getStoreId(), productId, skuId, skuNo, orderStatus);
            cargo = orderOccurMapper.queryCargoGMVByStore(startDate, endDate, businessType, cargoType,
                    request.getStoreId(), productId, skuId, skuNo, orderStatus);
        } else if (groupType.equals(7)) {
            // 员工级别
            if (null == request.getStaffId()) {
                return null;
            }
            order = orderOccurMapper.queryOrderGMVByStaff(startDate, endDate, businessType, request.getStaffId(), productId, skuId, skuNo, orderStatus);
            electric = orderOccurMapper.queryCateGMVByStaff(startDate, endDate, businessType, electricType,
                    request.getStaffId(), productId, skuId, skuNo, orderStatus);
            cargo = orderOccurMapper.queryCargoGMVByStaff(startDate, endDate, businessType, cargoType,
                    request.getStaffId(), productId, skuId, skuNo, orderStatus);
        }
        if (null != order) {
            if (null != electric) {
                order.setElectricNum(electric.getElectricNum());
                order.setElectricPrice(electric.getElectricPrice());
                order.setElecBuyNum(electric.getElecBuyNum());
            } else {
                order.setElectricNum(0L);
                order.setElectricPrice("0.00");
                order.setElecBuyNum(0l);
            }
            if (null != cargo) {
                order.setCargoNum(cargo.getCargoNum());
                order.setCargoPrice(cargo.getCargoPrice());
                order.setCargoBuyNum(cargo.getCargoBuyNum());
            } else {
                order.setCargoNum(0L);
                order.setCargoPrice("0.00");
                order.setCargoBuyNum(0l);
            }
            orderList.add(order);
            return orderList;
        }
        if (groupType.equals(3)) {
            // 大区级别 分类
            orderList = orderOccurMapper.queryOrderGMVByRegion(startDate, endDate, businessType, productId, skuId, skuNo, orderStatus);
            electricList = orderOccurMapper.queryCateGMVByRegion(startDate, endDate, businessType, electricType, productId, skuId, skuNo, orderStatus);
            cargoList = orderOccurMapper.queryCargoGMVByRegion(startDate, endDate, businessType, cargoType, productId, skuId, skuNo, orderStatus);
        } else if (groupType.equals(4)) {
            // 一级分部级别
            orderList = orderOccurMapper.queryOrderGMVByBrand(startDate, endDate, businessType, productId, skuId, skuNo, orderStatus);
            electricList = orderOccurMapper.queryCateGMVByBrand(startDate, endDate, businessType, electricType, productId, skuId, skuNo, orderStatus);
            cargoList = orderOccurMapper.queryCargoGMVByBrand(startDate, endDate, businessType, cargoType, productId, skuId, skuNo, orderStatus);
        } else if (groupType.equals(5)) {
            // 二级分部级别
            orderList = orderOccurMapper.queryOrderGMVByBrandSecond(startDate, endDate, businessType, productId, skuId, skuNo, orderStatus);
            electricList = orderOccurMapper.queryCateGMVByBrandSecond(startDate, endDate, businessType, electricType, productId, skuId, skuNo, orderStatus);
            cargoList = orderOccurMapper.queryCargoGMVByBrandSecond(startDate, endDate, businessType, cargoType, productId, skuId, skuNo, orderStatus);
        }

        order = new OrderCountResponse();
        order.setGroupName("合计");
        Long orderNum = 0L;
        Double priceTotal = 0d;
        Long buyNum = 0L;
        Long electricNum = 0L;
        Double electricPrice = 0d;
        Long cargoNum = 0L;
        Double cargoPrice = 0d;
        Long elecProdNum = 0L;
        Long cargoProdNum = 0L;
        for (OrderCountResponse orderInfo : orderList) {
            orderNum = orderNum + orderInfo.getOrderNum();
            priceTotal = priceTotal + Double.parseDouble(orderInfo.getPriceTotal());
            buyNum = buyNum + orderInfo.getBuyNum();
            for (OrderCountResponse electricInfo : electricList) {
                if (orderInfo.getGroupId().equals(electricInfo.getGroupId())) {
                    orderInfo.setElectricNum(electricInfo.getElectricNum());
                    orderInfo.setElectricPrice(electricInfo.getElectricPrice());
                    orderInfo.setElecBuyNum(electricInfo.getElecBuyNum());
                    electricNum = electricNum + electricInfo.getElectricNum();
                    electricPrice = electricPrice + Double.parseDouble(electricInfo.getElectricPrice());
                    elecProdNum += electricInfo.getElecBuyNum();
                }
            }
            for (OrderCountResponse cargoInfo : cargoList) {
                if (orderInfo.getGroupId().equals(cargoInfo.getGroupId())) {
                    orderInfo.setCargoNum(cargoInfo.getCargoNum());
                    orderInfo.setCargoPrice(cargoInfo.getCargoPrice());
                    orderInfo.setCargoBuyNum(cargoInfo.getCargoBuyNum());
                    cargoNum = cargoNum + cargoInfo.getCargoNum();
                    cargoPrice = cargoPrice + Double.parseDouble(cargoInfo.getCargoPrice());
                    cargoProdNum += cargoInfo.getCargoBuyNum();
                }
            }
            if (null == orderInfo.getElectricNum()) {
                orderInfo.setElectricNum(0L);
            }
            if (null == orderInfo.getElectricPrice()) {
                orderInfo.setElectricPrice("0.00");
            }
            if (null == orderInfo.getCargoNum()) {
                orderInfo.setCargoNum(0L);
            }
            if (null == orderInfo.getCargoPrice()) {
                orderInfo.setCargoPrice("0.00");
            }
        }
        order.setOrderNum(orderNum);
        order.setPriceTotal(priceTotal.toString());
        order.setBuyNum(buyNum);
        order.setElectricNum(electricNum);
        order.setElecBuyNum(elecProdNum);
        order.setElectricPrice(electricPrice.toString());
        order.setCargoNum(cargoNum);
        order.setCargoBuyNum(cargoProdNum);
        order.setCargoPrice(cargoPrice.toString());
        orderList.add(order);
        return orderList;
    }

    ///判断是否电器
    private Boolean isElectric() {
        return false;
    }


    @Override
    public List<OrderCountResponse> queryOrderCountByOrderTime(OrderCountRequest request) {
        Date startDate = request.getStartDate();
        Date endDate = request.getEndDate();
        if (null == startDate || null == endDate) {
            return null;
        }
        // 电器编码
        String electricType = "A1";
        // 百货编码
        String cargoType = "A2";
        // 搜索类型 0 总部 1 总部（员工） 2总部非员工 3大区 4一级分部 5二级分部 6门店且storeId值必传 7员工且staffId值必传
        Integer groupType = request.getGroupType();
        // 自联营类型
        Integer businessType = request.getBusinessType();
        // 商品编码
        String productId = request.getProductId();
        // skuId
        String skuId = request.getSkuId();
        // skuNo
        String skuNo = request.getSkuNo();

        Integer orderStatus = request.getOrderStatus();

        Boolean isElectric = false;
        //判断是否是电器

        List<OrderCountResponse> orderList = new ArrayList<OrderCountResponse>();
        List<OrderCountResponse> electric = null;
        List<OrderCountResponse> cargo = null;
        // 显示所有订单
        if (groupType.equals(0)) {
            orderList = orderOccurMapper.queryOrderGMVByOrderTime(startDate, endDate, businessType, true, productId, skuId, skuNo, orderStatus);
            electric = orderOccurMapper.queryCateGMVByOrderTime(startDate, endDate, businessType, electricType, true, productId, skuId, skuNo, orderStatus);
            cargo = orderOccurMapper.queryCargoGMVByOrderTime(startDate, endDate, businessType, cargoType, true, productId, skuId, skuNo, orderStatus);
        }
            for(OrderCountResponse orderCountResponse : orderList){
                for(OrderCountResponse electrics : electric){
                    if(DateUtils.isSameDay(orderCountResponse.getOrderTime(), electrics.getOrderTime())){
                        orderCountResponse.setElectricNum(electrics.getElectricNum());
                        orderCountResponse.setElectricPrice(electrics.getElectricPrice());
                        orderCountResponse.setElecBuyNum(electrics.getElecBuyNum());
                    }
                }
                for (OrderCountResponse cargos : cargo){
                    if(DateUtils.isSameDay(orderCountResponse.getOrderTime(), cargos.getOrderTime())){
                        orderCountResponse.setCargoNum(cargos.getCargoNum());
                        orderCountResponse.setCargoPrice(cargos.getCargoPrice());
                        orderCountResponse.setCargoBuyNum(cargos.getCargoBuyNum());
                    }
                }
            }
        return orderList;
    }
}

