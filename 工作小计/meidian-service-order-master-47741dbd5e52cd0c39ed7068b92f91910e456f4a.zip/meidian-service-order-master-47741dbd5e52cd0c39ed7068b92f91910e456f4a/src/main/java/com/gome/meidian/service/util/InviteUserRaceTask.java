package com.gome.meidian.service.util;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.dao.MogRaceUserInfoDao;
import com.gome.meidian.service.biz.RaceBiz;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

/**
 * 拉新竞赛处理
 * @author chenchen-ds6
 */
@Slf4j
@Component
public class InviteUserRaceTask {
    @Autowired
    private RaceBiz raceBiz;
    @Autowired
    private Gcache gcache;
    public void run(MogRaceUserInfo mogRaceUserInfo) {
        log.info("线程处理拉新竞赛,处理入参:{}",mogRaceUserInfo);
        Long setnx = gcache.setnxex(Constant.SALE_RACE_DISTRIBUTED_LOCK + mogRaceUserInfo.getUserId(), 1,String.valueOf(System.currentTimeMillis()));
        if(setnx.equals(1L)){
            raceBiz.dealInviteUser(mogRaceUserInfo);
        }else{
            //并发处理
            log.info("并发处理邀请人计算时发送队列参数:{}",mogRaceUserInfo);
            String s = JSONObject.toJSONString(mogRaceUserInfo);
            gcache.rpush(Constant.SALE_RACE_DISTRIBUTED_LISTENER,s);
        }
    }
}
