package com.gome.meidian.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.norm.DataMigrator;
import com.gome.dragon.mds.client.dto.gcc.GomeRegioneOrBranchDTO;
import com.gome.dragon.mds.client.dto.gcc.GomeStoreFull;
import com.gome.dragon.mds.client.dto.gcc.GomeStoreFullOrBranchOrEmployeeDto;
import com.gome.dragon.mds.client.gcc.BranchQueryClient;
import com.gome.dragon.mds.client.gcc.GomeStoreFullClient;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.EmployeeInfo;
import com.gome.meidian.entity.IcSmDqlStaff;
import com.gome.meidian.entity.IcSmDqlStaffDataPagin;
import com.gome.meidian.entity.IcSmHlwlStaff;
import com.gome.meidian.entity.OrderShopSame;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.StaffInfo;
import com.gome.meidian.mapper.bigData.IcSmDqlStaffMapper;
import com.gome.meidian.mapper.bigData.IcSmHlwlStaffMapper;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.service.IcSmDqlStaffService;
import com.gome.meidian.service.biz.EmployeeBiz;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.dto.ChannelMshopRespDto;
import com.gomeo2o.facade.vshop.entity.VshopChannelInfo;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopChannelFacade;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

/**
 * @author sunxueyan-ds
 * @Title: IcSmDqlStaffServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/1/11 15:33
 */
@Slf4j
@Service
public class IcSmDqlStaffServiceImpl implements IcSmDqlStaffService {


    @Autowired
    private IcSmDqlStaffMapper icSmDqlStaffMapper;
    @Autowired
    private IcSmHlwlStaffMapper icSmHlwlStaffMapper;
    @Autowired
    private BranchQueryClient branchQueryClient;
    @Autowired
    private GomeStoreFullClient gomeStoreFullClient;
    @Autowired
    private VshopChannelFacade vshopChannelFacade;
    @Autowired
    private IOrderShopService iOrderShopService;
    @Autowired
    private IcSmDqlStaffDataForHttpServiceImpl icSmDqlStaffDataForHttpService;
    @Autowired
    private Gcache gcache;
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private IUserShareBindingManager userShareBindingManager;
    @Autowired
    private EmployeeBiz employeeBiz;

    @Value("${http.staffdata.url}")
    private String httpStaffUrl;

    /**
     * 根据员工ID查门店及分部（redis）+http
     *
     * @param staffId 员工id
     * @param type    1.员工di，2.一级分部id，3.二级分部id
     * @return
     */
    @SneakyLog("根据员工ID查门店及分部")
    public GomeStoreFullOrBranchOrEmployeeDto getShopInfo(String staffId, Integer type) {
        if (StringUtils.isEmpty(staffId)) {
            return null;
        }
        try {
            return gomeStoreFullClient.getNewGomeStoreOrBranchByEmployeeId(staffId, type);
        } catch (Exception e) {
            log.error("根据员工ID查门店及分部 发生异常,staffId:{},type:{},异常堆栈如下:", staffId, type, e);
            return null;
        }

    }

    /**
     * 查询全部大区或某个大区下的分部+http
     *
     * @return 一级分部编码匹配对应大区编码
     */
    @SneakyLog("查询全部大区或某个大区下的分部")
    private GomeRegioneOrBranchDTO getRegionInfo(String fDivisionCode, Map<String, GomeRegioneOrBranchDTO> regionRelation) {
        if (StringUtils.isEmpty(fDivisionCode) || regionRelation == null || regionRelation.isEmpty()) {
            return null;
        }
        return regionRelation.get(fDivisionCode);
    }

    @SneakyLog("查询获取大区及以及分部的映射关系")
    public Map<String, GomeRegioneOrBranchDTO> getRegionRelation() {
        Map<String, GomeRegioneOrBranchDTO> resultMap = new HashMap<>();
        try {
            List<GomeRegioneOrBranchDTO> regioneOrBranch = branchQueryClient.getRegioneOrBranch(null);
            if (CollectionUtils.isEmpty(regioneOrBranch)) {
                return resultMap;
            }
            for (GomeRegioneOrBranchDTO region : regioneOrBranch) {
                if (StringUtils.isEmpty(region.getRbid())) {
                    continue;
                }
                List<GomeRegioneOrBranchDTO> branch = branchQueryClient.getRegioneOrBranch(region.getRbid());
                if (CollectionUtils.isEmpty(branch)) {
                    continue;
                }
                for (GomeRegioneOrBranchDTO branchInfo : branch) {
                    resultMap.put(branchInfo.getRbid(), region);
                }
            }
            return resultMap;
        } catch (Exception e) {
            log.error("OrderChannelServiceImpl.getRegionRelation is failed!");
            return resultMap;
        }
    }

    /**
     * 查询美店名称接口
     *
     * @param
     * @return
     */
    public VshopChannelInfo vshopInfo(Long id) {
        if (id == null) {
            return null;
        }
        try {
            CommonResultEntity<ChannelMshopRespDto> ChannelMshopRespDto = vshopChannelFacade.getChannelMshopByParams(id, null);
            if (ChannelMshopRespDto.getBusinessObj() == null || ChannelMshopRespDto.getBusinessObj().getVshopChannelInfo() == null) {
                return null;
            }
            return ChannelMshopRespDto.getBusinessObj().getVshopChannelInfo();
        } catch (Exception e) {
            log.error("com.gome.meidian.service.impl.IcSmDqlStaffServiceImpl.vshopInfo 发生异常,id:{},异常堆栈如下:", id, e);
            return null;
        }
    }


    public Integer getTotalPageWithMid(Integer pageSize) {
        int totalCount = icSmDqlStaffMapper.getTotalCountWithMid();
        //总页数
        int totalPage = totalCount / pageSize;
        if (totalCount == 0 || totalCount % pageSize != 0) {
            totalPage++;
        }
        return totalPage;
    }


    /**
     * 处理员工数据
     * 1.分页查询
     * 2.封装
     * 3.保存到订单
     * 4.Http发送数据
     *
     * @return
     */
    @Override
    public ResultEntity staffDataHandle() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        Integer count = icSmDqlStaffMapper.getTotalCountWithMid();
        DataMigrator dataMigrator = new DataMigrator() {

            @Override
            public Integer doQueryTotalCount() {
                return count;
            }

            @Override
            public void executeBizMethod(Integer pageNo) {

                List<IcSmDqlStaff> icSmDqlStaffList = icSmDqlStaffMapper.selectPartWithMid((pageNo - 1) * DataMigrator.DEFAULT_EACH_THREAD_PAGE_NUM, DataMigrator.DEFAULT_EACH_THREAD_PAGE_NUM);
                if (CollectionUtils.isEmpty(icSmDqlStaffList)) {
                    return;
                }

                //处理缓存数据
                List<OrderShopSame> orderShopSameList = getStaffData(icSmDqlStaffList);
                orderShopSameList.parallelStream().forEach(item -> {
                    iOrderShopService.queryOrderCount(item);
                    saveGcache(item);
                });

                //向成都事业部发送消息
                List<List<IcSmDqlStaff>> partition = Lists.partition(icSmDqlStaffList, 2000);
                partition.forEach(item -> {
                    IcSmDqlStaffDataPagin<IcSmDqlStaff> data = new IcSmDqlStaffDataPagin<>();
                    data.setData(item);
                    data.setCurrentPage(pageNo);
                    data.setPageSize(DataMigrator.DEFAULT_EACH_THREAD_PAGE_NUM);
                    data.setTotalPage(count);
                    String s = JSONObject.toJSONString(data);
                    ResultEntity<String> result = icSmDqlStaffDataForHttpService.sendDataHttp(httpStaffUrl, s, headers);
                    log.info("处理员工数据 发送http请求,发送内容:{} result:{}", s, JSON.toJSON(result));
                });
            }
        };
        dataMigrator.start("定时处理员工数据");
        return new ResultEntity<>();
    }


    /**
     * 补全品牌编码存缓存
     *
     * @param os
     */
    private void saveGcache(OrderShopSame os) {
        if (os == null || os.getNewUserId() == null) {
            return;
        }
        try {
            EmployeeInfo employeeInfo = new EmployeeInfo();
            employeeInfo.setStaffCode(os.getUserId());
            employeeInfo.setNewUserId(os.getNewUserId());
            employeeInfo.setMid(os.getShopId());
            employeeInfo.setStaffName(os.getUserName());
            employeeInfo.setStaffPostName(os.getStaffPostName());
            List<Object> userBrandList = employeeBiz.getEmployeeBrandBySap(os.getUserId());
            if (CollectionUtils.isNotEmpty(userBrandList)) {
                List<String> brandList = new ArrayList<>(userBrandList.size());
                for (Object userBrand : userBrandList) {
                    brandList.add(String.valueOf(userBrand));
                }
                employeeInfo.setBrandIdList(brandList);
            }
            //查询联盟店
            GomeStoreFull gomeStoreByStoreIdByAllStatus = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus(os.getStoreId());
            if (null != gomeStoreByStoreIdByAllStatus) {
                employeeInfo.setPoolFlag(gomeStoreByStoreIdByAllStatus.getPoolFlag());
            }
            gcache.setex(Constant.STAFF_INFO_STR_CACHE + os.getNewUserId(), Constant.SECONDS_IN_GCACHE_ONEDAY, JSONObject.toJSONString(employeeInfo));
        } catch (Exception e) {
            log.error("IcSmDqlStaffServiceImpl.saveGcache 发生异常，入参：{} ,异常堆栈如下", JSON.toJSON(os), e);
        }
    }

    /**
     * 员工id获取员工信息
     *
     * @param staffId
     * @return
     */
    @Override
    public ResultEntity getStaffInfoByStaffID(Long staffId) {
        if (staffId == null) {
            return new ResultEntity<>(1, "员工Id为空");
        }
        try {
            boolean exists = gcache.hexists("staffInfo", staffId + "");
            if (exists) {//查询缓存
                String staffInfoString = gcache.hget("staffInfo", staffId + "");
                StaffInfo staffInfo = JSON.parseObject(staffInfoString, new TypeReference<StaffInfo>() {
                });
                return new ResultEntity<>(0, "员工信息查询成功!", staffInfo);
            }
            StaffInfo staffInfo = new StaffInfo();
            IcSmDqlStaff smDqlStaff = icSmDqlStaffMapper.selectByStaffId(staffId);
            if (null != smDqlStaff) {
                staffInfo.setStaffInfo(smDqlStaff);
                staffInfo.setType(new Byte("0"));
            } else {//线下员工信息不存在 查询线上员工信息
                IcSmHlwlStaff icSmHlwlStaff = icSmHlwlStaffMapper.selectByStaffId(staffId);
                if (null == icSmHlwlStaff) {
                    return new ResultEntity<>(1, "员工信息不存在", staffInfo);
                }
                staffInfo.setType(new Byte("1"));
                staffInfo.setStaffInfo(icSmHlwlStaff);
            }
            gcache.hset("staffInfo", staffId + "", JSONObject.toJSONString(staffInfo));
            return new ResultEntity<>(0, "员工信息查询成功!", staffInfo);
        } catch (Exception e) {
            log.error("IcSmDqlStaffServiceImpl.getStaffInfoByStaffID is failed! staffid:{}", staffId);
            return new ResultEntity<>(500, "系统内部异常!");
        }
    }

    /**
     * 员工数据补全大区及美店名称
     */
    public List<OrderShopSame> getStaffData(List<IcSmDqlStaff> list) {
        if (CollectionUtils.isEmpty(list)) {
            return new ArrayList<>();
        }
        List<OrderShopSame> order = new ArrayList<>(list.size());
        for (IcSmDqlStaff icSmDqlStaff : list) {
            OrderShopSame orderShop = new OrderShopSame();
            String storeCode = icSmDqlStaff.getStoreCode();
            if (!StringUtils.isEmpty(storeCode)) {
                GomeStoreFull gomeStoreByStoreIdByAllStatus = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus(storeCode);
                if (null != gomeStoreByStoreIdByAllStatus) {
                    if (null != gomeStoreByStoreIdByAllStatus.getRegioneName()) {//大区名称
                        orderShop.setRegionName(gomeStoreByStoreIdByAllStatus.getRegioneName());
                        icSmDqlStaff.setRegionName(gomeStoreByStoreIdByAllStatus.getRegioneName());
                    }
                    if (null != gomeStoreByStoreIdByAllStatus.getRegioneId()) {//大区编码
                        orderShop.setRegionId(gomeStoreByStoreIdByAllStatus.getRegioneId());
                        icSmDqlStaff.setRegionCode(gomeStoreByStoreIdByAllStatus.getRegioneId());
                    }
                    if (null != gomeStoreByStoreIdByAllStatus.getBranchId1()) {//一级分部
                        orderShop.setBranchId(gomeStoreByStoreIdByAllStatus.getBranchId1());
                        icSmDqlStaff.setfDivisionCode(gomeStoreByStoreIdByAllStatus.getBranchId1());
                    }
                    if (null != gomeStoreByStoreIdByAllStatus.getBranchName1()) {//一级分部名称
                        orderShop.setBranchName(gomeStoreByStoreIdByAllStatus.getBranchName1());
                        icSmDqlStaff.setfDivisionName(gomeStoreByStoreIdByAllStatus.getBranchName1());
                    }
                    if (null != gomeStoreByStoreIdByAllStatus.getBranchId2()) {//二级分部
                        orderShop.setBranchSecondId(gomeStoreByStoreIdByAllStatus.getBranchId2());
                        icSmDqlStaff.setsDivisionCode(gomeStoreByStoreIdByAllStatus.getBranchId2());
                    }
                    if (null != gomeStoreByStoreIdByAllStatus.getBranchName2()) {//二级分部名称
                        orderShop.setBranchSecondName(gomeStoreByStoreIdByAllStatus.getBranchName2());
                        icSmDqlStaff.setsDivisionName(gomeStoreByStoreIdByAllStatus.getBranchName2());
                    }
                    if (null != gomeStoreByStoreIdByAllStatus.getOrganizationId()) {//销售组织id
                        icSmDqlStaff.setOrganizationCode(gomeStoreByStoreIdByAllStatus.getOrganizationId());
                    }
                    /*if(null != gomeStoreByStoreIdByAllStatus.getBrand()){//品牌类型
                        icSmDqlStaff.setBrandCode(gomeStoreByStoreIdByAllStatus.getBrand());
                    }*/
                    if (null != gomeStoreByStoreIdByAllStatus.getStoreName()) {//门店地址
                        orderShop.setStoreName(gomeStoreByStoreIdByAllStatus.getStoreName());
                        icSmDqlStaff.setStoreName(gomeStoreByStoreIdByAllStatus.getStoreName());
                    }
                }
            }
            //一级分部区域查询
            //GomeStoreFullOrBranchOrEmployeeDto ShopInfo = getShopInfo(icSmDqlStaff.getStaffCode(), Integer.valueOf(icSmDqlStaff.getStatus()));
            //查询美店名称
            VshopChannelInfo MshopResp = vshopInfo(icSmDqlStaff.getMid());
            if (MshopResp != null) {
                //美店信息查询美店
                orderShop.setShopName(MshopResp.getName());
                icSmDqlStaff.setMidName(MshopResp.getName());
            }


            //大数据获取数据
            orderShop.setShopId(icSmDqlStaff.getMid());
            orderShop.setUserId(icSmDqlStaff.getStaffCode());
            orderShop.setNewUserId(icSmDqlStaff.getZxUid());
            orderShop.setUserName(icSmDqlStaff.getStaffName());
            orderShop.setStoreId(icSmDqlStaff.getStoreCode());
            orderShop.setStatus(icSmDqlStaff.getStatus());
            orderShop.setStaffPostName(icSmDqlStaff.getStaffPostName());
            orderShop.setOrganizationCode(icSmDqlStaff.getOrganizationCode());
            order.add(orderShop);
        }

        return order;
    }

    @Override
    public int deleteByPrimaryKey(Integer integer) {
        return 0;
    }

    @Override
    public int insert(IcSmDqlStaff icSmDqlStaff) {
        return 0;
    }

    @Override
    public int insertSelective(IcSmDqlStaff icSmDqlStaff) {
        return 0;
    }

    @Override
    public IcSmDqlStaff selectByPrimaryKey(Integer integer) {
        return null;
    }

    @Override
    public int updateByPrimaryKeySelective(IcSmDqlStaff icSmDqlStaff) {
        return 0;
    }

    @Override
    public int updateByPrimaryKey(IcSmDqlStaff icSmDqlStaff) {
        return 0;
    }

    /**
     * 同步数据：
     *
     * @param i 定时任务：取数据的间隔时间
     */
    @Override
    public void syncIcSmStaffToVshopInfo(int i) {
        log.info("IcSmDqlStaffServiceImpl.syncIcSmStaffToVshopInfo param hour {}", i);
        if (i == 0) {
            //全量同步
            bulkUpdateVshopInfoIdentity();
        } else {
            //增量同步
            incrementSyncToVshopInfoIdentity1(i);
        }
    }

    /**
     * 增量同步数据，增量幅度为hour
     *
     * @param minutes 分钟
     */
    private void incrementSyncToVshopInfoIdentity1(int minutes) {
        try {
            List<IcSmDqlStaff> staffList = icSmDqlStaffMapper.selectPartByCtime(minutes);
            log.info("增量升级片总,minutes:{}需要升级的员工数据:{}", minutes, JSON.toJSON(staffList));
            if (CollectionUtils.isNotEmpty(staffList)) {
                List<List<IcSmDqlStaff>> partition = Lists.partition(staffList, 100);
                for (List<IcSmDqlStaff> list : partition) {
                    for (IcSmDqlStaff info : list) {
                        userShareBindingManager.changePianZong(info.getZxUid(), info.getStatus());
                    }
                }
            }
        } catch (Exception e) {
            log.error("增量升级片总发生异常,minutes：{}.异常堆栈如下:", minutes, e);
        }
    }

    @Override
    public void bulkUpdateVshopInfoIdentity() {
        IcSmDqlStaffDataPagin<IcSmDqlStaff> icSmDqlStaffIcSmDqlStaffDataPagin = new IcSmDqlStaffDataPagin<>();
        icSmDqlStaffIcSmDqlStaffDataPagin.setPageSize(2000);
        Integer totalPage = getTotalPageWithMid(icSmDqlStaffIcSmDqlStaffDataPagin.getPageSize());
        log.info("IcSmDqlStaffServiceImpl. bulkUpdateVshopInfoIdentity totalPage is success,totalPage:{}", totalPage);
        List<IcSmDqlStaff> staffList = null;
        for (int i = 1; i <= totalPage; i++) {
            try {
                icSmDqlStaffIcSmDqlStaffDataPagin.setTotalPage(totalPage);
                staffList = icSmDqlStaffMapper.selectPartWithMid((i - 1) * icSmDqlStaffIcSmDqlStaffDataPagin.getPageSize(), icSmDqlStaffIcSmDqlStaffDataPagin.getPageSize());
                for (int j = 0; j < staffList.size(); j++) {
                    updateVshopInfoIdentity(staffList.get(j));
                }
                log.info("IcSmDqlStaffServiceImpl.staffDataHandle selectPart is success, pageNum, pageNum:{}, count:{}", i, staffList.size());
            } catch (Exception e) {
                log.error("IcSmDqlStaffServiceImpl.staffDataHandle selectPart is failed, pageNum:{}, pageSize:{}", i, icSmDqlStaffIcSmDqlStaffDataPagin.getPageSize());
                e.getMessage();
            }
        }
    }

    public void updateVshopInfoIdentity(IcSmDqlStaff icSmDqlStaff) {
        log.info("IcSmDqlStaffServiceImpl.updateVshopInfoIdentity param ZxUid {}", icSmDqlStaff.getZxUid().toString());
        try {
            CommonResultEntity<VshopInfo> result = vshopFacade.queryVshopByuserId(icSmDqlStaff.getZxUid().toString());
            if (result != null && result.getBusinessObj() != null) {
                VshopInfo entity = result.getBusinessObj();
                entity.setVshopIdentity(icSmDqlStaff.getStatus() == null || new Byte("0").equals(icSmDqlStaff.getStatus()) ? 1 : 3);
                entity.setVshopType(1);
                CommonResultEntity<String> rst = vshopFacade.updateVshop(entity);
                log.info("IcSmDqlStaffServiceImpl.updateVshopInfoIdentity CommonResultEntity {}", rst);
            }
        } catch (Exception e) {
            log.error("IcSmDqlStaffServiceImpl.updateVshopInfoIdentity param ZxUid {},is fail  ", icSmDqlStaff.getZxUid().toString(), e);
        }
    }


    ///根据分支名称修改
    private String getExchangeBranch(String branchId) {
        branchId = branchId.toUpperCase();
        String branchCode;
        switch (branchId) {
            case "TD00":
                branchCode = "JX00";
                break;
            case "YTOO":
                branchCode = "NJ00";
                break;
            case "YC00":
                branchCode = "NJ00";
                break;
            case "SX01":
                branchCode = "ZJ00";
                break;
            case "ZZ00":
                branchCode = "XM00";
                break;
            case "NM01":
                branchCode = "NM00";
                break;
            case "SDDZ":
                branchCode = "JN00";
                break;
            case "WZ00":
                branchCode = "NB00";
                break;
            case "TS00":
                branchCode = "TJ00";
                break;
            default:
                branchCode = branchId;
                break;
        }
        return branchCode;
    }


    ///根据分支名称修改
    private String getExchangeBranchName(String branchId, String branchName) {
        branchId = branchId.toUpperCase();
        String branchCode;
        switch (branchId) {
            case "TD00":
                branchCode = "江西分部";
                break;
            case "YTOO":
                branchCode = "南京分部";
                break;
            case "YC00":
                branchCode = "南京分部";
                break;
            case "SX01":
                branchCode = "浙江分部";
                break;
            case "ZZ00":
                branchCode = "厦门分部";
                break;
            case "NM01":
                branchCode = "内蒙分部";
                break;
            case "SDDZ":
                branchCode = "济南分部";
                break;
            case "WZ00":
                branchCode = "宁波分部";
                break;
            case "TS00":
                branchCode = "天津分部";
                break;
            default:
                branchCode = branchName;
                break;
        }
        return branchCode;
    }
}
