package com.gome.meidian.dao;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.vo.MogErrOrderBody;
import com.gome.meidian.vo.ReqOrderDeliveryBody;
import com.mongodb.DuplicateKeyException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Slf4j
@Repository
public class MogErrOrderBodyDao extends MongGenDao<MogErrOrderBody> {

    @Override
    protected Class getEntityClass() {
        return MogErrOrderBody.class;
    }

    /**
     * @param record 异常订单消息体记录
     * @return
     */
    public ResultEntity<Boolean> saveRecord(MogErrOrderBody record) {
        if (record == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        if (StringUtils.isBlank(record.getMsgId()) || record.getOrderId() == null || StringUtils.isBlank(record.getDeliveryId())) {
            return new ResultEntity<>(402, "msgId or orderId or deliveryId is null");
        }
        try {
            record.setCreateTime(new Date());
            this.save(record);
            return new ResultEntity<>(Boolean.TRUE);
        } catch (DuplicateKeyException e) {
            log.info("保存异常消息体因主键冲突插入失败,入参:{}", JSON.toJSON(record));
            return new ResultEntity<>(Boolean.FALSE);
        } catch (Exception e) {
            String format = String.format("保存异常消息体发生异常,入参:%s,异常堆栈如下:", JSON.toJSON(record));
            log.error(format, e);
            return new ResultEntity<>(Boolean.FALSE);
        }

    }

    /**
     * 删除 mogDeliveryOrderBody 通过id
     *
     * @param id
     * @return
     */
    public ResultEntity delRecord(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity<>(402, "id不能为空");
        }
        this.deleteById(id);
        return new ResultEntity<>(Boolean.TRUE);
    }

    /**
     * 多条件获取 mogDeliveryOrderBody 列表
     *
     * @param param
     * @return
     */
    public ResultEntity<List<MogErrOrderBody>> queryListByBiz(ReqOrderDeliveryBody param) {
        try {
            Query query = new Query();
            //封装条件查询数据
            query.addCriteria(this.queryParam(param));
            //订单时间倒序
            query.with(new Sort(Sort.Direction.DESC, "orderTime"));
            //查询订单列表
            List<MogErrOrderBody> list = this.findList(query);
            return new ResultEntity<>(list);
        } catch (Exception e) {
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    public ResultEntity<Boolean> updateRecord(MogErrOrderBody record) {
        if (record == null || record.getId() == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        //多条件嵌入
        Query query = Query.query(Criteria.where("_id").is(record.getId()));
        //封装更新数据
        Update update = this.updateParam(record);
        this.updateMulti(query, update);
        return new ResultEntity<>(Boolean.TRUE);
    }


    /**
     * 更新条件封装
     *
     * @param record
     * @return
     */
    private Update updateParam(MogErrOrderBody record) {
        Update update = new Update();
        String msgId = record.getMsgId();
        if (msgId != null) {
            update.set("msgId", msgId);
        }
        Long orderId = record.getOrderId();
        if (orderId != null) {
            update.set("orderId", orderId);
        }
        String deliveryId = record.getDeliveryId();
        if (deliveryId != null) {
            update.set("deliveryId", deliveryId);
        }
        Long userId = record.getUserId();
        if (userId != null) {
            update.set("userId", userId);
        }
        Integer orderStatus = record.getOrderStatus();
        if (orderStatus != null) {
            update.set("orderStatus", orderStatus);
        }
        String msgBody = record.getMsgBody();
        if (msgBody != null) {
            update.set("msgBody", msgBody);
        }
        Date orderTime = record.getOrderTime();
        if (orderTime != null) {
            update.set("orderTime", orderTime);
        }
        Date createTime = record.getCreateTime();
        if (createTime != null) {
            update.set("createTime", createTime);
        }
        return update;
    }

    /**
     * 筛选条件疯转
     *
     * @param param 入参
     * @return
     */
    private Criteria queryParam(ReqOrderDeliveryBody param) {
        Criteria criteria = new Criteria();
        //主键id
        String id = param.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //消息id
        String msgId = param.getMsgId();
        if (StringUtils.isNotBlank(msgId)) {
            criteria.and("msgId").is(msgId);
        }
        //订单号
        Long orderId = param.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //配送号
        String deliveryId = param.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            criteria.and("deliveryId").is(deliveryId);
        }
        //用户id
        Long userId = param.getUserId();
        if (userId != null) {
            criteria.and("userId").is(userId);
        }
        //订单状态
        List<Integer> orderStatusList = param.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = param.getOrderStartTime();
        Date orderEndTime = param.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        return criteria;
    }


}
