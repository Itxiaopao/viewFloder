package com.gome.meidian.enums;

/**
 * 用户身份枚举
 */
public enum UserIdentityType {

    custom(0, "用户"),
    shopkeeper(1, "店主"),
    shopowner(2, "店总"),
    topLeaderUser(3, "片总");

    private Integer status;

    private String desc;

    private UserIdentityType(Integer status, String desc) {
        this.status = status;
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public String getDesc() {
        return desc;
    }
}
