package com.gome.meidian.service.impl;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.OrderRebateParm;
import com.gome.meidian.enums.OrderFullStatus;
import com.gome.meidian.enums.OrderShowStatus;
import com.gome.meidian.service.IOrderRebateService;
import com.gome.meidian.service.biz.ReceiveOrderBiz;
import com.gome.meidian.util.CommUtils;
import com.gome.meidian.vo.MogOrderInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service("orderRebateService")
public class OrderRebateServiceImpl implements IOrderRebateService {

    @Autowired
    private RedisLockUtils redisLockUtils;
    @Autowired
    private ReceiveOrderBiz receiveOrderBiz;

    @Override
    @SneakyLog("B端订单返利逻辑处理")
    public boolean orderRebateSync(OrderRebateParm param) {
        String repeatKey = CommUtils.getRedisKey(Constant.ORDER_REBATE_REPEAT_INCR_PREFIX, param.getOrderId(), param.getDeliveryId(), param.getSkuId(), param.getOrderStatus());
        String lockKey = CommUtils.getRedisKey(Constant.PAY_ORDER_MUTEX_LOCK_PREFIX, param.getOrderId(), param.getDeliveryId(), param.getSkuId(), param.getOrderStatus());
        boolean resubmitLock = Boolean.FALSE;
        boolean mutexLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(repeatKey);
            if (!resubmitLock) {
                log.info("修改订单返利正在执行中,请勿重复提交");
                return Boolean.TRUE;
            }
            //支付订单互斥锁
            mutexLock = redisLockUtils.mutexLock(lockKey);
            MogOrderInfo mogOrderInfo = receiveOrderBiz.getOrderInfoByOrderIdDeliveryIdSkuId(param.getOrderId(), param.getDeliveryId(), param.getSkuId());
            if (mogOrderInfo != null) {
                mogOrderInfo.setAwardMoney(param.getRewardAmount());
                mogOrderInfo.setCommMoney(param.getRebateAmount());
                return receiveOrderBiz.updateOrderInfo(mogOrderInfo);
            }
            MogOrderInfo newOrderInfo = new MogOrderInfo();
            newOrderInfo.setOrderId(param.getOrderId());
            newOrderInfo.setSkuId(param.getSkuId());
            newOrderInfo.setDeliveryId(param.getDeliveryId());
            newOrderInfo.setOrderStatus(OrderFullStatus.Payed.getStatus());
            newOrderInfo.setShowStatus(OrderShowStatus.Payed.getStatus());
            newOrderInfo.setAwardMoney(param.getRewardAmount());
            newOrderInfo.setCommMoney(param.getRebateAmount());
            return receiveOrderBiz.addOrderInfo(newOrderInfo);
        } catch (Exception e) {
            log.error("保存返利记录发生异常,异常堆栈如下", e);
            return Boolean.FALSE;
        } finally {
            //删除锁
            redisLockUtils.unlock(mutexLock, lockKey);
            redisLockUtils.unlock(resubmitLock, repeatKey);
        }
    }

}
