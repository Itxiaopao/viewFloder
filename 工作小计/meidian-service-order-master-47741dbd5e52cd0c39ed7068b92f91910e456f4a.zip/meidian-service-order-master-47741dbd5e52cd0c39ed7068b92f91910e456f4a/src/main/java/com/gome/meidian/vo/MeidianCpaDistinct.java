package com.gome.meidian.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author helinhao
 * @create 2020/2/28 10:08
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MeidianCpaDistinct implements Serializable{

    private static final long serialVersionUID = -6413089898946749654L;

    private Long id;
    //用户id
    private Long userId;
    //是否新设备,0:不是，1:是
    private Integer isFirst;
    //首次激活时间
    private Date firstTime;
    //创建时间
    private Date insertTime;
    //更新时间
    private Date updateTime;
}
