package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderBodyError;
import com.gome.meidian.entity.OrderImportUvData;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface OrderImportUvDataMapper  extends BaseMapper<OrderImportUvData> {

//    int insert(OrderImportUvData record);

    int insertSelective(OrderImportUvData record);

    OrderImportUvData selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(OrderImportUvData record);

    int updateByPrimaryKey(OrderImportUvData record);


}