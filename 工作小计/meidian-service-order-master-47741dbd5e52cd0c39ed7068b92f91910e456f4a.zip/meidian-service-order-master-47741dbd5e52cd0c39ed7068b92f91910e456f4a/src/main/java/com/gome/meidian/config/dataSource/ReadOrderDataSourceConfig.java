package com.gome.meidian.config.dataSource;//package com.gome.meidian.config;

import com.baomidou.mybatisplus.spring.MybatisSqlSessionFactoryBean;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;


@Configuration
@MapperScan(basePackages = "com.gome.meidian.mapper.readorder*", sqlSessionTemplateRef = "readOrderSqlSessionTemplate")
public class ReadOrderDataSourceConfig {

    @Bean(name = "readOrderSource")
    @ConfigurationProperties(prefix = "spring.datasource.readorder")
    public DataSource readOrderSource(){ return DataSourceBuilder.create().build();
    }

    @Bean(name = "readOrderSqlSessionFactory")
    @ConfigurationProperties(prefix ="mybatis-plus4")
    public SqlSessionFactory readOrderSqlSessionFactory(@Qualifier("readOrderSource") DataSource dataSource) throws Exception{
        MybatisSqlSessionFactoryBean sqlSessionFactoryBean = new MybatisSqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(readOrderSource());
        return sqlSessionFactoryBean.getObject();
    }

    @Bean(name = "readOrderTransactionManager")
    public DataSourceTransactionManager readOrderTransactionManager(@Qualifier("readOrderSource") DataSource dataSource){
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean(name = "readOrderSqlSessionTemplate")
    public SqlSessionTemplate readOrderSqlSessionTemplate(@Qualifier("readOrderSqlSessionFactory")SqlSessionFactory sqlSessionFactory){
        return new SqlSessionTemplate(sqlSessionFactory);
    }
}
