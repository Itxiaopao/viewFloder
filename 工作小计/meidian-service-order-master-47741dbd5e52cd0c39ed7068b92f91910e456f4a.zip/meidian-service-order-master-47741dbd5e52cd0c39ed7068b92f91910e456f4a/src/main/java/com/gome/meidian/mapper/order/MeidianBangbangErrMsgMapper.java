package com.gome.meidian.mapper.order;


import com.gome.meidian.vo.MeidianBangbangErrMsg;

import java.util.List;
import java.util.Map;

public interface MeidianBangbangErrMsgMapper {

    int insert(MeidianBangbangErrMsg record);

    int update(MeidianBangbangErrMsg record);

    int delete(Long id);

    List<MeidianBangbangErrMsg> selectByBiz(Map<String, Object> map);

}