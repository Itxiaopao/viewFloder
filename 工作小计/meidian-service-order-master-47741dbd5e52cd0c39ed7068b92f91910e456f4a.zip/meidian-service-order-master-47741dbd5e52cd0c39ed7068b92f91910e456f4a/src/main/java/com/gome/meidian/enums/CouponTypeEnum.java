package com.gome.meidian.enums;

import com.google.common.collect.Maps;

import java.util.HashMap;

public enum CouponTypeEnum {

    GOD_COUPON(3005L, 1, "营销券/神券"),
    GOME_COUPON(3001L, 2, "美券"),
    RED_COUPON(3003L, 3, "红券"),
    BLUE_COUPON(3002L, 4, "蓝券");

    private Long couponType;
    private Integer convertSortCouponType; // 调用接口转换的券类型对应的编码
    private String message;

    CouponTypeEnum() {
    }

    CouponTypeEnum(Long couponType, Integer convertSortCouponType, String message) {
        this.couponType = couponType;
        this.convertSortCouponType = convertSortCouponType;
        this.message = message;
    }

    public static final HashMap<Long, CouponTypeEnum> couponTypeMap = Maps.newHashMap();
    public static final HashMap<Integer, CouponTypeEnum> couponSortTypeMap = Maps.newHashMap();
    static {
        for (CouponTypeEnum self : CouponTypeEnum.values()) {
            couponTypeMap.put(self.couponType, self);
            couponSortTypeMap.put(self.convertSortCouponType, self);
        }
    }

    public String getMessage() {
        return message;
    }

    public Long getCouponType() {
        return couponType;
    }

    public Integer getConvertSortCouponType() {
        return convertSortCouponType;
    }

}
