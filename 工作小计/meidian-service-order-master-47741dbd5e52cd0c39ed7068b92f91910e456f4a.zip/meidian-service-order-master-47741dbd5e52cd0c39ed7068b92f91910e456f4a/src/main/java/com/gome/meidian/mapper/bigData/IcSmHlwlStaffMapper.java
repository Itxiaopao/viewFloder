package com.gome.meidian.mapper.bigData;

import com.gome.meidian.entity.IcSmDqlStaff;
import com.gome.meidian.entity.IcSmHlwlStaff;
import com.gome.meidian.mapper.bigData.provider.IcSmHlwlStaffProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

/**
 * @author sunxueyan-ds
 * @Title: IcSmHlwlStaffMapper
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/2/14 14:09
 */
public interface IcSmHlwlStaffMapper {

    @SelectProvider(type=IcSmHlwlStaffProvider.class, method="selectByStaffId")
    IcSmHlwlStaff selectByStaffId(@Param(value = "staffId") Long staffId);
}
