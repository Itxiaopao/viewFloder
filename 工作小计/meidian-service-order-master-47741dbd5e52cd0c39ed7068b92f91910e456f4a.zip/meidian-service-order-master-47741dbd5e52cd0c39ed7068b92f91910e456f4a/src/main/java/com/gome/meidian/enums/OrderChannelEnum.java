package com.gome.meidian.enums;

public enum OrderChannelEnum {

    jinli(10, "金立"),
    meidian(13, "美店"),
    oneShopOnePage(16, "一店一页"),
    online(60, "线上商城");

    private Integer code;
    private String desc;

    public static OrderChannelEnum valueOf(Integer code) {
        for (OrderChannelEnum enu : OrderChannelEnum.values()) {
            if (enu.getCode().equals(code)) {
                return enu;
            }
        }
        return null;
    }


    private OrderChannelEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
