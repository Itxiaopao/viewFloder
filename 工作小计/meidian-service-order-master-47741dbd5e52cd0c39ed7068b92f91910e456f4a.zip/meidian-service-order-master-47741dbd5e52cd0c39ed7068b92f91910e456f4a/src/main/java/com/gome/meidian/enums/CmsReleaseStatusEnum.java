package com.gome.meidian.enums;

/**
 * CMS上下架状态
 */
public enum CmsReleaseStatusEnum {

    un(0, 0, "未上架"),
    on(1, 1, "上架"),
    off(2, 0, "下架");

    /**
     * cms状态
     */
    private Integer status;

    /**
     * 美店上下架映射 1:上架，其他:下架
     */
    private Integer code;

    /**
     * 描述
     */
    private String desc;

    private CmsReleaseStatusEnum(Integer status, Integer code, String desc) {
        this.status = status;
        this.code = code;
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
