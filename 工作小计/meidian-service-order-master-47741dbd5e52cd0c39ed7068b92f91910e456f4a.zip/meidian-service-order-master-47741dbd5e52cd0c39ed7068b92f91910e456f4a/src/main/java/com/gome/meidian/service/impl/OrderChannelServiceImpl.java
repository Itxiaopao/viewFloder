package com.gome.meidian.service.impl;

import com.gome.dragon.mds.client.dto.gcc.GomeBranchOne;
import com.gome.dragon.mds.client.dto.gcc.GomeRegioneOrBranchDTO;
import com.gome.dragon.mds.client.dto.gcc.GomeStoreFullOrBranchOrEmployeeDto;
import com.gome.dragon.mds.client.gcc.BranchQueryClient;
import com.gome.dragon.mds.client.gcc.GomeStoreFullClient;
import com.gome.meidian.entity.OrderChannel;
import com.gome.meidian.mapper.order.OrderChannelMapper;
import com.gome.meidian.service.IOrderChannelService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * <p>
 * 退货单表 服务实现类
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
@Service
public class OrderChannelServiceImpl extends ServiceImpl<OrderChannelMapper, OrderChannel> implements IOrderChannelService {

    @Autowired
    private OrderChannelMapper orderChannelMapper;


    public OrderChannel select1(Integer id){
        return orderChannelMapper.select1(id);
    }


}
