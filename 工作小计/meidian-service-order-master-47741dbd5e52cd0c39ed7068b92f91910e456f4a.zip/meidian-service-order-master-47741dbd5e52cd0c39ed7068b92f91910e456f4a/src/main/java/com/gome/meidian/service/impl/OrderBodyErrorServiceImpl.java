package com.gome.meidian.service.impl;

import com.gome.meidian.entity.OrderBodyError;
import com.gome.meidian.mapper.order.OrderBodyErrorMapper;
import com.gome.meidian.service.IOrderBodyErrorService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 消息实体错误表 服务实现类
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
@Service
public class OrderBodyErrorServiceImpl extends ServiceImpl<OrderBodyErrorMapper, OrderBodyError> implements IOrderBodyErrorService {

}
