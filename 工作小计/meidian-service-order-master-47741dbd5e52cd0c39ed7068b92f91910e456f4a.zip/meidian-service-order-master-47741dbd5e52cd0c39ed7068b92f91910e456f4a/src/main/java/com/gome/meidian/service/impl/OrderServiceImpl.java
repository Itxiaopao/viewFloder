package com.gome.meidian.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.config.GCacheConfig;
import com.gome.meidian.entity.OrderChannel;
import com.gome.meidian.entity.OrderEffect;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.entity.OrderRefund;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.StidInfo;
import com.gome.meidian.service.IOrderChannelService;
import com.gome.meidian.service.IOrderEffectService;
import com.gome.meidian.service.IOrderOccurService;
import com.gome.meidian.service.IOrderRefundService;
import com.gome.meidian.service.IOrderService;
import com.gome.meidian.service.util.OrderConstant;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.util.JSONUtils;

/**
 * <p>
 * 返回订单信息服务实现类
 * </p>
 *
 * @author chuwanxin
 * @since 2018-08-06
 */
@Service
public class OrderServiceImpl implements IOrderService {

	@Autowired
	IOrderEffectService orderEffectSvc;

	@Autowired
	IOrderOccurService orderOccurSvc;

	@Autowired
	IOrderRefundService orderRefundSvc;

	@Autowired
	IOrderChannelService orderChannelSvc;

	@Autowired
	GCacheConfig gCacheService;

	@Override
	public ResultEntity selectByDateRange(HashMap<String, Object> queryParams) {
		ResultEntity resultEntity = new ResultEntity();
		try {
			// 24小时制时间格式
			SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Object mid = queryParams.get("mid");
			Object startDate = queryParams.get("startDate");
			Object endDate = queryParams.get("endDate");
			Object orderType = queryParams.get("orderType");

			if (mid == null) {
				resultEntity.setCode(10001);
				resultEntity.setMessage("mid is null");
				return resultEntity;
			}
			ArrayList<String> midInner = (ArrayList<String>) mid;

			if (CollectionUtils.isEmpty(midInner)) {
				resultEntity.setCode(10001);
				resultEntity.setMessage("mid is invalid");
				return resultEntity;
			} else {
				String midStr = midInner.toString();
				queryParams.put("mid", midStr.substring(1, midStr.length() - 1));
			}

			if (startDate == null) {
				resultEntity.setCode(10002);
				resultEntity.setMessage("startDate is invalid");
				return resultEntity;
			}

			try {
				String startTime = sdformat.format(startDate);
				queryParams.put("startDate", startTime);
			} catch (Exception e) {
				resultEntity.setCode(10002);
				resultEntity.setMessage("startDate is invalid");
				return resultEntity;
			}

			if (endDate == null) {
				resultEntity.setCode(10003);
				resultEntity.setMessage("endDate is null");
				return resultEntity;
			}

			try {
				String endTime = sdformat.format(endDate);
				queryParams.put("endDate", endTime);
			} catch (Exception e) {
				resultEntity.setCode(10003);
				resultEntity.setMessage("endDate is invalid");
				return resultEntity;
			}

			if (orderType == null) {
				resultEntity.setCode(10004);
				resultEntity.setMessage("orderType is null");
				return resultEntity;
			}

			int orderTypeInner = (int) orderType;
			if (orderTypeInner <= 0) {
				resultEntity.setCode(10004);
				resultEntity.setMessage("orderType is invalid");
				return resultEntity;
			}
			resultEntity.setCode(10000);
			if (orderTypeInner == OrderConstant.ORDER_OCCUR) {
				List<OrderOccur> orderOccurs = orderOccurSvc.selectByDateRange(queryParams);
				System.out.println(orderOccurs.size());
				resultEntity.setBusinessObj(orderOccurs);
			} else if (orderTypeInner == OrderConstant.ORDER_EFFECT) {
				List<OrderEffect> orderEffects = orderEffectSvc.selectByDateRange(queryParams);
				resultEntity.setBusinessObj(orderEffects);
			} else if (orderTypeInner == OrderConstant.ORDER_REFUND) {
				List<OrderRefund> orderRefunds = orderRefundSvc.selectByDateRange(queryParams);
				resultEntity.setBusinessObj(orderRefunds);
			} else {
				resultEntity.setCode(10004);
				resultEntity.setMessage("orderType is invalid");
				return resultEntity;
			}
		} catch (Exception e) {
			resultEntity.setCode(10010);
			resultEntity.setMessage("parameter is invalid");
		}
		return resultEntity;
	}

	@Override
	public ResultEntity queryEffectWithStid(HashMap<String, Object> queryParams) {
		ResultEntity resultEntity = new ResultEntity();
		try {
			// 24小时制时间格式
			SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Object mid = queryParams.get("mid");
			Object startDate = queryParams.get("startDate");
			Object endDate = queryParams.get("endDate");
			Object orderType = queryParams.get("orderType");

			if (mid == null) {
				resultEntity.setCode(10001);
				resultEntity.setMessage("mid is null");
				return resultEntity;
			}
			ArrayList<String> midInner = (ArrayList<String>) mid;

			if (CollectionUtils.isEmpty(midInner)) {
				resultEntity.setCode(10001);
				resultEntity.setMessage("mid is invalid");
				return resultEntity;
			} else {
				String midStr = midInner.toString();
				queryParams.put("mid", midStr.substring(1, midStr.length() - 1));
			}

			if (startDate == null) {
				resultEntity.setCode(10002);
				resultEntity.setMessage("startDate is invalid");
				return resultEntity;
			}

			try {
				String startTime = sdformat.format(startDate);
				queryParams.put("startDate", startTime);
			} catch (Exception e) {
				resultEntity.setCode(10002);
				resultEntity.setMessage("startDate is invalid");
				return resultEntity;
			}

			if (endDate == null) {
				resultEntity.setCode(10003);
				resultEntity.setMessage("endDate is null");
				return resultEntity;
			}

			try {
				String endTime = sdformat.format(endDate);
				queryParams.put("endDate", endTime);
			} catch (Exception e) {
				resultEntity.setCode(10003);
				resultEntity.setMessage("endDate is invalid");
				return resultEntity;
			}

			if (orderType == null) {
				resultEntity.setCode(10004);
				resultEntity.setMessage("orderType is null");
				return resultEntity;
			}

			int orderTypeInner = (int) orderType;
			if (orderTypeInner <= 0) {
				resultEntity.setCode(10004);
				resultEntity.setMessage("orderType is invalid");
				return resultEntity;
			}
			resultEntity.setCode(10000);
			if (orderTypeInner == OrderConstant.ORDER_EFFECT) {
				List<OrderEffect> orderEffects = orderEffectSvc.selectByDateRange(queryParams);
				HashMap<String, Object> columnMap = new HashMap<String, Object>();
				for (OrderEffect orderEffect : orderEffects) {
					Long orderId = orderEffect.getOrderId();
					Long commerceId = orderEffect.getCommerceId();
					columnMap.clear();
					columnMap.put("order_id", orderId);
					columnMap.put("commerce_id", commerceId);
					List<OrderChannel> orderChannels = orderChannelSvc.selectByMap(columnMap);
					for (OrderChannel orderChannel : orderChannels) {
						String mdStid = orderChannel.getMdStid();
						if (StringUtils.isNotEmpty(mdStid)) {
							orderEffect.setStid(mdStid);
							break;
						}
					}
				}
				resultEntity.setBusinessObj(orderEffects);
			} else if (orderTypeInner == OrderConstant.ORDER_OCCUR) {
				List<OrderOccur> orderOccurs = orderOccurSvc.selectByDateRange(queryParams);
				HashMap<String, Object> columnMap = new HashMap<String, Object>();
				for (OrderOccur orderOccur : orderOccurs) {
					Long orderId = orderOccur.getOrderId();
					Long commerceId = orderOccur.getCommerceId();
					columnMap.clear();
					columnMap.put("order_id", orderId);
					columnMap.put("commerce_id", commerceId);
					List<OrderChannel> orderChannels = orderChannelSvc.selectByMap(columnMap);
					for (OrderChannel orderChannel : orderChannels) {
						String mdStid = orderChannel.getMdStid();
						if (StringUtils.isNotEmpty(mdStid)) {
							orderOccur.setStid(mdStid);
							break;
						}
					}
				}
				resultEntity.setBusinessObj(orderOccurs);
			} else {
				resultEntity.setCode(10004);
				resultEntity.setMessage("orderType is invalid");
				return resultEntity;
			}
		} catch (Exception e) {
			resultEntity.setCode(10010);
			resultEntity.setMessage("parameter is invalid");
		}
		return resultEntity;
	}

	@Override
	public ResultEntity selectItemIdByDate(List<String> itemIds, Integer dateType) {
		ResultEntity resultEntity = new ResultEntity();
		resultEntity.setCode(0);
		List<OrderOccur> all = new ArrayList();
		Date startDate = DateUtils.getNowDate();
		Date endDate = DateUtils.minusDays(startDate, 7L);
		for (String itemId : itemIds) {
			if (dateType.equals(2)) {
				// 15天
				endDate = DateUtils.minusDays(startDate, 15L);
			} else if (dateType.equals(3)) {
				// 30天
				endDate = DateUtils.minusDays(startDate, 30L);
			} else {
				// 默认7天
				dateType = 1;
			}
			all.addAll(getOccurList(itemId, startDate, endDate, dateType));
		}
		resultEntity.setBusinessObj(all);
		return resultEntity;
	}

	private List<OrderOccur> getOccurList(String itemId, Date startDate, Date endDate, Integer dateType) {
		String itemKey = "meidian-service-order_itemId_" + itemId;
		// 先从缓存取数据
		String byteList = gCacheService.gcache().hget(itemKey, dateType.toString());
		if (null == byteList) {
			// 缓存无数据 从数据库取
			List<OrderOccur> itemIdList = orderOccurSvc.selectItemIdByDateRange(itemId, startDate, endDate);
			// 存入缓存
			gCacheService.gcache().hset(itemKey, dateType.toString(), JSONUtils.toJSONString(itemIdList).getBytes());
			gCacheService.gcache().expire(itemKey, 60 * 2);
			return itemIdList;
		}
		return JSONObject.parseArray(byteList, OrderOccur.class);
	}

	@Override
	public List<StidInfo> selectStidInfoByDate(Date startDate, Date endDate, List<String> stids) {
		return orderOccurSvc.selectStidInfoByDate(startDate, endDate, stids);
	}

	@Override
	public List<StidInfo> selectMidInfoByDate(Date startDate, Date endDate, List<String> mids) {
		return orderOccurSvc.selectMidInfoByDate(startDate, endDate, mids);
	}

	@Override
	public List<StidInfo> selectSkuNoByDate(Date startDate, Date endDate, List<String> stids, String skuNo) {
		return orderOccurSvc.selectSkuNoByDate(startDate, endDate, stids, skuNo);
	}

	@Override
	public List<StidInfo> selectStidInfoByMid(Date startDate, Date endDate, String mid, String skuNo) {
		return orderOccurSvc.selectStidInfoByMid(startDate, endDate, mid, skuNo);
	}

}
