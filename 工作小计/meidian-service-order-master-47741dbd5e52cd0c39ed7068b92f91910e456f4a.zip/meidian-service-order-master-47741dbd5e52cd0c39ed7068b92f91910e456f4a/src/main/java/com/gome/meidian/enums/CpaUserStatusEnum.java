package com.gome.meidian.enums;

/**
 * cpa用户状态枚举
 */
public enum CpaUserStatusEnum {

    register(1, "已注册"),
    appFirstOrder(2,"app首单"),
    appFirstOrderCancel(3,"app首单取消")
    ;

    private Integer code;

    private String desc;

    public static boolean contains(Integer code) {
        for (CpaUserStatusEnum enu : CpaUserStatusEnum.values()) {
            if (enu.getCode().equals(code)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }


    private CpaUserStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
