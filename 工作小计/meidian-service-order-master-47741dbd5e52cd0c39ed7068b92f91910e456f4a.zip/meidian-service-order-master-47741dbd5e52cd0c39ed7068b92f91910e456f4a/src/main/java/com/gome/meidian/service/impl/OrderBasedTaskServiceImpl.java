package com.gome.meidian.service.impl;

import com.baomidou.mybatisplus.enums.SqlMethod;
import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.entity.OrderBasedTask;
import com.gome.meidian.mapper.order.OrderBasedTaskMapper;
import com.gome.meidian.service.OrderBasedTaskService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.binding.MapperMethod;
import org.apache.ibatis.executor.BatchResult;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author sunxueyan-ds
 * @Title: OrderBasedTaskServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/4 14:58
 */
@Slf4j
@Service
public class OrderBasedTaskServiceImpl extends ServiceImpl<OrderBasedTaskMapper, OrderBasedTask> implements OrderBasedTaskService {
    @Autowired
    OrderBasedTaskMapper orderBasedTaskMapper;

    public Integer insertOne(OrderBasedTask entity) {
        Integer recordNum = 0;
        if (null != entity && null != entity.getSkuId()) {
            recordNum = orderBasedTaskMapper.insert(entity);
        }
        return recordNum;
    }

    @Transactional(rollbackFor = Exception.class)
    public List<BatchResult> insertBatchNum(List<OrderBasedTask> entityList) {
        Integer recordNum = 0;
        if (null != entityList && entityList.size() > 0) {
            return insertBatchMethod(entityList, 30);
        }
        return null;
    }


    /**
     * 批量插入
     *
     * @param entityList
     * @param batchSize
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public List<BatchResult> insertBatchMethod(List<OrderBasedTask> entityList, int batchSize) {
        List<BatchResult> batchResults = new ArrayList<>();
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            String sqlStatement = sqlStatement(SqlMethod.INSERT_ONE);
            for (int i = 0; i < size; i++) {
                if (StringUtils.isNotEmpty(entityList.get(i).getSkuId()) && null != entityList.get(i).getTaskId()) {
                    entityList.get(i).setUpdateTime(new Date());
                    batchSqlSession.insert(sqlStatement, entityList.get(i));
                }
                if (i >= 1 && i % batchSize == 0) {
                    batchResults = batchSqlSession.flushStatements();
                }
            }
            batchResults = batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertBatch Method. Cause", e);
        }
        return batchResults;
    }

    @Transactional(rollbackFor = Exception.class)
    public List<BatchResult> updateBatchByIdNum(List<OrderBasedTask> entityList, int batchSize) {
        return updateBatchById(entityList, batchSize, true);
    }

    /**
     * 根据主键ID进行批量修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @param selective  是否滤掉空字段
     * @return boolean
     */
    private List<BatchResult> updateBatchById(List<OrderBasedTask> entityList, int batchSize, boolean selective) {
        List<BatchResult> batchResults = new ArrayList<>();
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            SqlMethod sqlMethod = selective ? SqlMethod.UPDATE_BY_ID : SqlMethod.UPDATE_ALL_COLUMN_BY_ID;
            String sqlStatement = sqlStatement(sqlMethod);
            for (int i = 0; i < size; i++) {
                MapperMethod.ParamMap<OrderBasedTask> param = new MapperMethod.ParamMap<>();
                param.put("et", entityList.get(i));
                batchSqlSession.update(sqlStatement, param);
                if (i >= 1 && i % batchSize == 0) {
                    batchResults = batchSqlSession.flushStatements();
                }
            }
            batchResults = batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute updateBatchById Method. Cause", e);
        }
        return batchResults;
    }



    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateBatchNum(List<OrderBasedTask> entityList) {
        for (OrderBasedTask entity : entityList) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && null != entity.getTaskId()) {
                EntityWrapper<OrderBasedTask> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("task_id", entity.getTaskId());
                OrderBasedTask orderBasedTask = selectOne(wrapper);
                if (null != orderBasedTask) {
                    if (null != entity.getUvQuota())
                        entity.setUvQuota(orderBasedTask.getUvQuota() == null ? entity.getUvQuota() : entity.getUvQuota() + orderBasedTask.getUvQuota());
                    if(null != entity.getSalesQuota())
                        entity.setSalesQuota(orderBasedTask.getSalesQuota() == null ? entity.getSalesQuota() : entity.getSalesQuota() + orderBasedTask.getSalesQuota());
                    if(null != entity.getShareQuota())
                        entity.setShareQuota(orderBasedTask.getShareQuota() == null ? entity.getShareQuota() : entity.getShareQuota() + orderBasedTask.getShareQuota());
                }
            }
        }
        return insertOrUpdateBatchMethod(entityList, 30);
    }


    /**
     * 批量插入修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @return boolean
     */
    private Map<String, Long> insertOrUpdateBatchMethod(List<OrderBasedTask> entityList, int batchSize) {
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        Long count = 0l;
        Map<String, Long> resultMap = new HashMap<>();
        resultMap.put("insertNum", 0l);
        resultMap.put("updateNum", 0l);
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            for (int i = 0; i < size; i++) {
                resultMap = insertOrUpdateReal(entityList.get(i), resultMap);
                if (i >= 1 && i % batchSize == 0) {
                    batchSqlSession.flushStatements();
                }
            }
            batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertOrUpdateBatch Method. Cause", e);
        }
        return resultMap;
    }


    /**
     * <p>
     * TableId 注解存在更新记录，否插入一条记录
     * </p>
     *
     * @param entity 实体对象
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateReal(OrderBasedTask entity, Map<String, Long> resultMap) {
//        Map<String, Long> resultMap = new HashMap<>();
        Boolean flag = false;
        Long updateNum = 0l;
        Long insertNum = 0l;
        if (null != entity) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && null != entity.getTaskId()) {
                /*
                 * 更新成功直接返回，失败执行插入逻辑
                 */
                EntityWrapper<OrderBasedTask> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("task_id", entity.getTaskId());
                flag = update(entity, wrapper);
                if (!flag) {
                    flag = insert(entity);
                    if (flag) {
                        insertNum = resultMap.get("insertNum");
                        insertNum++;
                        resultMap.put("insertNum", insertNum);
                    }
                } else {
                    updateNum = resultMap.get("updateNum");
                    updateNum++;
                    resultMap.put("updateNum", updateNum);
                }
                return resultMap;
//                return update(entity, wrapper) || insert(entity);
            }
        } else {
            throw new MybatisPlusException("Error:  Can not execute. Could not find @TableId.");
        }
//        }
        return resultMap;
    }
}
