package com.gome.meidian.service.impl;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.entity.OrderSalesEffect;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.SalesTaskParam;
import com.gome.meidian.page.BasePageVo;
import com.gome.meidian.page.Pagination;
import com.gome.meidian.service.IOrderSalesTaskService;
import com.gome.meidian.dao.MeidianOrderDao;
import com.gome.meidian.vo.ReqOrderVshopVo;
import com.gome.meidian.enums.SearchOrderStatusEnum;
import com.gome.meidian.vo.VitalOrderVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrderSalesTaskServiceImpl implements IOrderSalesTaskService {

    @Autowired
    private MeidianOrderDao meidianOrderDao;

    @Override
    @SneakyLog("获取店主销售效果总数")
    public ResultEntity<Integer> getMSalesEffectTotal(SalesTaskParam param) {
        if (param == null) {
            return new ResultEntity<>(402, "非空参数不能传递");
        }
        if (param.getStartTime() == null || param.getEndTime() == null) {
            return new ResultEntity<>(402, "任务起止时间不能为空");
        }
        try {
            ReqOrderVshopVo vo = new ReqOrderVshopVo();
            vo.setStartTime(param.getStartTime());
            vo.setEndTime(param.getEndTime());
            vo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(SearchOrderStatusEnum.normal.getCode()));
            ResultEntity<Integer> result = meidianOrderDao.queryCountVshopSellParam(vo);
            return new ResultEntity<>(result.getBusinessObj());
        } catch (Exception e) {
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("获取店主销售效果")
    public ResultEntity<List<OrderSalesEffect>> getMSalesEffect(SalesTaskParam param) {
        if (param == null) {
            return new ResultEntity<>(402, "非空参数不能传递");
        }
        if (param.getStartTime() == null || param.getEndTime() == null) {
            return new ResultEntity<>(402, "任务起止时间不能为空");
        }
        if (param.getPageNo() == null || param.getPageNo() <= 0) {
            param.setPageNo(1);
        }
        if (param.getPageSize() == null || param.getPageSize() <= 0) {
            param.setPageSize(100);
        }
        ReqOrderVshopVo reqOrderVshopVo = new ReqOrderVshopVo();
        BasePageVo basePageVo = new BasePageVo();
        basePageVo.setPageNo(param.getPageNo());
        basePageVo.setPageSize(param.getPageSize());
        reqOrderVshopVo.setBasePageVo(basePageVo);
        reqOrderVshopVo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(SearchOrderStatusEnum.normal.getCode()));
        reqOrderVshopVo.setStartTime(param.getStartTime());
        reqOrderVshopVo.setEndTime(param.getEndTime());
        ResultEntity<Pagination<VitalOrderVo>> result = meidianOrderDao.queryPageVshopSellParam(reqOrderVshopVo);
        List<VitalOrderVo> list = result.getBusinessObj().getList();
        List<OrderSalesEffect> orderSalesEffectList = new ArrayList<>(param.getPageSize());
        if (CollectionUtils.isEmpty(list)) {
            return new ResultEntity<>(orderSalesEffectList);
        }
        for (VitalOrderVo vo : list) {
            orderSalesEffectList.add(new OrderSalesEffect(vo.getId(), vo.getSumPriceTotal(), vo.getCountOrderNum()));
        }
        return new ResultEntity<>(orderSalesEffectList);
    }

}
