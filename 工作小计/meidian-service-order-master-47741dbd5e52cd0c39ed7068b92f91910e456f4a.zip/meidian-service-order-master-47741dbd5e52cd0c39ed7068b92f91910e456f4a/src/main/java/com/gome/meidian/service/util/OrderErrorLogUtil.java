package com.gome.meidian.service.util;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.entity.Order;
import com.gome.meidian.entity.OrderBodyError;
import com.gome.meidian.service.IOrderBodyErrorService;

@Component
public class OrderErrorLogUtil {
	@Autowired
	IOrderBodyErrorService orderBodyErrorSvc;

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void insertLog(Order orderOccur, String errMsg) {
		if(errMsg.contains("PRIMARY")) {
			return ;
		}
		// 错误日志表插入
		HashMap<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("order_id", orderOccur.getOrderId());
		queryMap.put("commerce_id", orderOccur.getCommerceId());
		List<OrderBodyError> orderBodyErrors = orderBodyErrorSvc.selectByMap(queryMap);
		OrderBodyError orderBodyError = new OrderBodyError();
		orderBodyError.setBodyMessage(JSONObject.toJSONString(orderOccur));
		orderBodyError.setMessage(errMsg);
		orderBodyError.setOrderType(orderOccur.getStatus());
		orderBodyError.setCommerceId(orderOccur.getCommerceId());
		orderBodyError.setOrderId(orderOccur.getOrderId());
		orderBodyError.setCreateTime(new Date());
		orderBodyError.setIsDel(1);
		if (CollectionUtils.isEmpty(orderBodyErrors)) {
			orderBodyError.setTryNum(0);
			orderBodyErrorSvc.insert(orderBodyError);
		} else {
			OrderBodyError orderBodyErrorUpd = orderBodyErrors.get(0);
			orderBodyError.setTryNum(orderBodyErrorUpd.getTryNum() + 1);
			orderBodyError.setId(orderBodyErrorUpd.getId());
			orderBodyErrorSvc.updateAllColumnById(orderBodyError);
		}
	}
}
