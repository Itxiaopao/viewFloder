package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderDataCount;
import com.gome.meidian.entity.OrderDetailTask;

import java.util.Date;
import java.util.List;

/**
 * @author sunxueyan-ds
 * @Title: OrderDetailTaskMapper
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/13 20:47
 */
public interface OrderDetailTaskMapper  extends BaseMapper<OrderDetailTask> {



    List<OrderDetailTask> getSkuTaskList(Byte status, Date startDate, Date endDate, Long taskId, String skuId);
}
