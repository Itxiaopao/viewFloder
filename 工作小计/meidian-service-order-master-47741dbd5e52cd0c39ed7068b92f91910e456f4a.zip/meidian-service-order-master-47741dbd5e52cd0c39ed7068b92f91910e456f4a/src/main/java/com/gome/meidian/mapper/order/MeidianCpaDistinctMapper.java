package com.gome.meidian.mapper.order;

import com.gome.meidian.vo.MeidianCpaDistinct;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Author helinhao
 * @create 2020/2/28 10:25
 */
public interface MeidianCpaDistinctMapper {

    int insert(MeidianCpaDistinct meidianCpaDistinct);

    int update(MeidianCpaDistinct meidianCpaDistinct);

    int delete(Long id);

    List<Long> selectUserIdListNonFirst();

    List<Long> selectUserIdListNonFirstByDate(@Param("startDate") String startDate, @Param("endDate")String endDate);
}
