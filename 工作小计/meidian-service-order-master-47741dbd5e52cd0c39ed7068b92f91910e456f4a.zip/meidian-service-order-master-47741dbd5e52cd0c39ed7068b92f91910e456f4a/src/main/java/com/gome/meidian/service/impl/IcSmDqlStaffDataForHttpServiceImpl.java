package com.gome.meidian.service.impl;

import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.service.IcSmDqlStaffDataService;
import com.gome.meidian.util.HttpClientUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: IcSmDqlStaffDataForHttpServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/1/11 17:42
 */
@Slf4j
@Service
public class IcSmDqlStaffDataForHttpServiceImpl implements IcSmDqlStaffDataService {

    //http发送数据
    @Override
    public ResultEntity<String> sendDataHttp(String s, String s1, Map<String, String> map) {
        try {
            String s2 = HttpClientUtils.httpClientPost2Str(s, s1, map);
            return new ResultEntity<>(0, "HTTP发送数据成功", s2);
        } catch (Exception e) {
            return new ResultEntity<>(1, "HTTP发送数据失败");
        }
    }
}
