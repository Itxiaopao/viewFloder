package com.gome.meidian.service.factory;

/**
 * 订单工厂
 */
public interface CrpOrderFactory {

    void processOrder(String msgId, String msgBody);

    default void exCallback(String msgId, String msgBody, Exception err) {

    }

}
