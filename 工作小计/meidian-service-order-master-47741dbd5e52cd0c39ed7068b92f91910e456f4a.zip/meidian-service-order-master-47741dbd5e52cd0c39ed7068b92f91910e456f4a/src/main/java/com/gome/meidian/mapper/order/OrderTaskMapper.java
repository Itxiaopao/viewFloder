package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderCountResponse;
import com.gome.meidian.entity.OrderDataCount;
import com.gome.meidian.entity.OrderDetailTask;
import com.gome.meidian.entity.OrderOccur;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * @author sunxueyan-ds
 * @Title: OrderTaskMapper
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/13 19:37
 */
public interface OrderTaskMapper extends BaseMapper<OrderOccur> {

    //基本查询条件
    static final String BASE_WHERE_SQLSTR=
//            "<if test='businessType != null'>" +
//                    " AND occur.business_type = #{businessType} " +
//                    "</if>" +
                    "<if test='productId != null'>" +
                    " AND occur.item_id = #{productId} " +
                    "</if>" +
                    "<if test='skuId != null'>" +
                    " AND occur.sku_id = #{skuId} " +
                    "</if>" +
                    "<if test='skuNo != null'>" +
                    " AND occur.sku_no = #{skuNo} " +
                    "</if>"+
                    "<if test='OrderStatus == 1 or OrderStatus == 2'>" +
                    " AND occur.order_status = #{OrderStatus}  " +
                    "</if> " +
                    "<if test='OrderStatus == 5 or OrderStatus == 6'>" +
                    " AND occur.status = #{OrderStatus}  " +
                    "</if> "
            ;

    //判断是发生单表  还是妥投单表 的数据
    static final String BASE_OCCUR_TABLE_SQLSTR=
            "<if test='OrderStatus==1 or OrderStatus==2 or OrderStatus==null'>" +
                    " order_occur occur "+
                    "</if>"+
                    "<if test='OrderStatus==5 or OrderStatus==6'>" +
                    " order_effect occur "+
                    "</if>"   ;


    @Select("<script> " +
            "SELECT  " +
            "IFNULL(count(1),0)  as order_num, " +
            "IFNULL(FORMAT((sum(price_total) / 100),2),0) as sales ," +
            "IFNULL(sum(buy_num),0) as sales_num, " +
            "DATE_FORMAT(occur.order_time,'%Y-%m-%d') as order_time " +
            ", occur.sku_id, shop.branch_id as branch_code,shop.branch_name,cate.classify_id as product_type " +
            "FROM " +
            "( "+
            BASE_OCCUR_TABLE_SQLSTR+
//            "<if test='flag != null'>" +
            " LEFT " +
//            "</if>" +
            "JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
            "LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
            "AND occur.category_second = cate.c2_id " +
            "AND occur.category_third = cate.c3_id " +
            "WHERE " +
//            "TO_DAYS(NOW()) - TO_DAYS(occur.order_time) <= 7" +
            "occur.order_time BETWEEN " +
            "str_to_date(#{startDate}, '%Y-%m-%d %H:%i:%s') AND str_to_date(#{endDate}, '%Y-%m-%d %H:%i:%s') " +
            BASE_WHERE_SQLSTR+ " group by TO_DAYS(occur.order_time), occur.sku_id " +
            "</script>")
    List<OrderDataCount> getOrderTaskData(@Param("startDate") String startDate, @Param("endDate") String endDate, @Param("productId") String productId, @Param("skuId") String skuId, @Param("skuNo") String skuNo, @Param("OrderStatus") Byte orderStatus);


}
