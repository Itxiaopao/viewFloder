package com.gome.meidian.vo;

import java.util.List;

import lombok.Data;

@Data
public class MeidianUserInfoDTO {
	/**
	 *  用户id
	 */
	private Long userId;
	/**
	 * 美店ID
	 */
	private Long mid;
	/**
	 * 上级美店ID(C购买的时候是他的直属上级（分享返），M购买的时候是他自己(自购省钱))
	 */
	private Long upUserId;
	/**
	 * 片总Id
	 */
	private Long pianUserId;
	/**
	 * 绑定关系链条
	 */
	private List<Long> shareChain;
	/**
	 * 微信昵称
	 */
	private String weiXinNickName;
	/**
	 * 手机号码
	 */
	private String phone;
	/**
	 * 用户类型 0 普通用户 1.店主2.店总3.片总
	 */
	private Integer identityType;
	/**
	 * 用户类型 1新客 2游客 4首单 5忠粉
	 */
	private Integer userType;

}
	