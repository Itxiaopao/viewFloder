package com.gome.meidian.enums;

/**
 * 开关枚举类
 */
public enum SwitchEnum {

    off("0", "关"),
    on("1", "开");

    private String code;

    private String desc;

    private SwitchEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
