package com.gome.meidian.mapper.order;

import java.util.List;
import java.util.Map;

import com.gome.meidian.vo.MeidianBangbangCalcType;

public interface MeidianBangbangCalcTypeMapper {

    MeidianBangbangCalcType selectOne(Map<String, Object> map);

    List<MeidianBangbangCalcType> selectList(Map<String, Object> map);

    int selectCount(Map<String, Object> map);

    int delete(Long id);

    int insert(MeidianBangbangCalcType record);

    int update(MeidianBangbangCalcType record);
}