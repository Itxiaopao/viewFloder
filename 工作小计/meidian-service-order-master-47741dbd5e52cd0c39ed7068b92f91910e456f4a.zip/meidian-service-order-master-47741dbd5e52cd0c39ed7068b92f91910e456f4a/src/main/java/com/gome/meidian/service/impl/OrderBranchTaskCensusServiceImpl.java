package com.gome.meidian.service.impl;

import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.toolkit.MapUtils;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.entity.*;
import com.gome.meidian.mapper.order.OrderBasedTaskMapper;
import com.gome.meidian.mapper.order.OrderBranchTaskCensusMapper;
import com.gome.meidian.mapper.order.OrderBranchTaskMapper;
import com.gome.meidian.mapper.order.OrderShopMapper;
import com.gome.meidian.service.OrderBranchTaskCensusService;
import com.gome.meidian.service.OrderBranchTaskService;
import com.gome.meidian.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author sunxueyan-ds
 * @Title: OrderBranchTaskCensusServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/4 21:15
 */
@Slf4j
@Service
public class OrderBranchTaskCensusServiceImpl extends ServiceImpl<OrderBranchTaskCensusMapper, OrderBranchTaskCensus> implements OrderBranchTaskCensusService {

    @Autowired
    OrderBranchTaskCensusMapper orderBranchTaskCensusMapper;
    @Autowired
    OrderBasedTaskMapper orderBasedTaskMapper;
    @Autowired
    OrderShopMapper orderShopMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Map<String, Long> insertOrUpdateBatchNum(List<OrderBranchTaskCensus> list) {

        return insertOrUpdateBatchMethod(list, 30);
    }

    public List<OrderBranchTaskCensus> getShareData(){
        List<OrderBranchTaskCensus> orderBranchTaskCensuses = new ArrayList<>();
        try {
            orderBranchTaskCensuses = orderBranchTaskCensusMapper.selectUnion();
            if(null != orderBranchTaskCensuses && orderBranchTaskCensuses.size() > 0){
                for(OrderBranchTaskCensus orderBranchTaskCensus : orderBranchTaskCensuses){
                    List<OrderBasedTask> orderBasedTasks = orderBasedTaskMapper.getOrderBasedTaskByRecordTime(orderBranchTaskCensus.getRecordTime(), orderBranchTaskCensus.getSkuId());
                    if(null != orderBasedTasks && orderBasedTasks.size() > 0){
                        orderBranchTaskCensus.setTaskId(orderBasedTasks.get(0).getTaskId());
                    }
                }
            }
        } catch (Exception e) {
            log.info("OrderBranchTaskCensusServiceImpl.getShareData is Failed!");
        }
        return orderBranchTaskCensuses;
    }

    @Override
    public List<orderTaskVo> getPartData(Date date, Date date1, Integer integer, Integer integer1) {
        try {
            List<orderTaskVo> partData = orderBranchTaskCensusMapper.getPartData(date, date1, (integer - 1) * integer1, integer1);
            return partData;
        } catch (Exception e) {
            log.error("OrderBranchTaskCensusServiceImpl.getPartData is error! startTime:{},endTime:{},pageNo:{},pageSize:{}", date, date1, integer, integer1);
        }
        return null;
    }

    @Override
    public List<orderTaskVo> getRegionDataBySkuId(Date date, Date date1, Integer integer, Integer integer1) {
        try {
            List<orderTaskVo> regionData = orderBranchTaskCensusMapper.getRegionDataBySkuId(date, date1, (integer - 1) * integer1, integer1);
            return regionData;
        } catch (Exception e) {
            log.error("OrderBranchTaskCensusServiceImpl.getRegionDataBySkuId is error! startTime:{},endTime:{},pageNo:{},pageSize:{}", date, date1, integer, integer1);
        }
        return null;
    }

    @Override
    public List<orderTaskVo> getRegionData(Date date, Date date1, Integer integer, Integer integer1) {
        try {
            List<orderTaskVo> regionData = orderBranchTaskCensusMapper.getRegionData(date, date1, (integer - 1) * integer1, integer1);
            return regionData;
        } catch (Exception e) {
            log.error("OrderBranchTaskCensusServiceImpl.getRegionData is error! startTime:{},endTime:{},pageNo:{},pageSize:{}", date, date1, integer, integer1);
        }
        return null;
    }

    @Override
    public List<orderTaskVo> getAllData(Date date, Date date1, Integer integer, Integer integer1) {
        try {
            List<orderTaskVo> allData = orderBranchTaskCensusMapper.getAllData(date, date1, (integer - 1) * integer1, integer1);
            return allData;
        } catch (Exception e) {
            log.error("OrderBranchTaskCensusServiceImpl.getAllData is error! startTime:{},endTime:{},pageNo:{},pageSize:{}", date, date1, integer, integer1);
        }
        return null;
    }


    /**
     * 补全数据
     */
    public Map<String, Long> getSalesDataAndInsertOrUpdate(){
        List<OrderBranchTaskCensus> orderBranchTaskCensuses = new ArrayList<>();
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DATE_FORMAT);
            Date yesterDayDate = simpleDateFormat.parse(DateUtils.getYesterdayTimeBySelect(""));
            Date todayDate = DateUtils.plusDays(yesterDayDate, 2l);
            orderBranchTaskCensuses = orderBranchTaskCensusMapper.getBranchSales(yesterDayDate, todayDate);
            if(null != orderBranchTaskCensuses && orderBranchTaskCensuses.size() > 0) {
                for (OrderBranchTaskCensus orderBranchTaskCensus : orderBranchTaskCensuses) {
                    List<OrderShopSame> orderShops = orderShopMapper.selectByBranchId(orderBranchTaskCensus.getBranchCode());
                    if (null != orderShops && orderShops.size() > 0) {
                        orderBranchTaskCensus.setBranchName(orderShops.get(0).getBranchName());
                        orderBranchTaskCensus.setRegionId(orderShops.get(0).getRegionId());
                        orderBranchTaskCensus.setRegionName(orderShops.get(0).getRegionName());
                        List<OrderBasedTask> orderBasedTasks = orderBasedTaskMapper.getOrderBasedTaskByRecordTime(orderBranchTaskCensus.getRecordTime(), orderBranchTaskCensus.getSkuId());
                        if(null != orderBasedTasks && orderBasedTasks.size() > 0){
                            orderBranchTaskCensus.setTaskId(orderBasedTasks.get(0).getTaskId());
                        }
                    }
                }
            }
        } catch (ParseException e) {
            log.info("OrderBranchTaskCensusServiceImpl.getBranchSales is Failed!");
            throw new RuntimeException();
        }

        Map<String, Long> map = insertOrUpdateBatchNum(orderBranchTaskCensuses);
        log.info("OrderBranchTaskCensusServiceImpl.getSalesDataAndInsertOrUpdate, result:{}", map);
        return map;
    }

    /**
     * 批量插入修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @return boolean
     */
    private Map<String, Long> insertOrUpdateBatchMethod(List<OrderBranchTaskCensus> entityList, int batchSize) {
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        Long count = 0l;
        Map<String, Long> resultMap = new HashMap<>();
        resultMap.put("insertNum", 0l);
        resultMap.put("updateNum", 0l);
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();

            for (int i = 0; i < size; i++) {
                entityList.get(i).setUpdateTime(new Date());
                resultMap = insertOrUpdateReal(entityList.get(i), resultMap);
                if (i >= 1 && i % batchSize == 0) {
                    batchSqlSession.flushStatements();
                }
            }
            batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertOrUpdateBatch Method. Cause", e);
        }
        return resultMap;
    }



    /**
     * <p>
     * TableId 注解存在更新记录，否插入一条记录
     * </p>
     *
     * @param entity 实体对象
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateReal(OrderBranchTaskCensus entity, Map<String, Long> resultMap) throws Exception {
//        Map<String, Long> resultMap = new HashMap<>();
        Boolean flag = false;
        Long updateNum = 0l;
        Long insertNum = 0l;
        if (null != entity) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && StringUtils.isNotEmpty(entity.getBranchCode()) && null != entity.getRecordTime()) {
                /*
                 * 更新成功直接返回，失败执行插入逻辑
                 */
                EntityWrapper<OrderBranchTaskCensus> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("branch_code", entity.getBranchCode());
                if(null != entity.getRecordTime()){
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DATE_FORMAT);
                    Date parse = simpleDateFormat.parse(simpleDateFormat.format(entity.getRecordTime()));
                    wrapper.eq("record_time", parse);
                }
                flag = update(entity, wrapper);
                if (!flag) {
                    flag = insert(entity);
                    if (flag) {
                        insertNum = resultMap.get("insertNum");
                        insertNum++;
                        resultMap.put("insertNum", insertNum);
                    }
                } else {
                    updateNum = resultMap.get("updateNum");
                    updateNum++;
                    resultMap.put("updateNum", updateNum);
                }
                return resultMap;
//                return update(entity, wrapper) || insert(entity);
            }
        } else {
            throw new MybatisPlusException("Error:  Can not execute. Could not find @TableId.");
        }
//        }
        return resultMap;
    }
}
