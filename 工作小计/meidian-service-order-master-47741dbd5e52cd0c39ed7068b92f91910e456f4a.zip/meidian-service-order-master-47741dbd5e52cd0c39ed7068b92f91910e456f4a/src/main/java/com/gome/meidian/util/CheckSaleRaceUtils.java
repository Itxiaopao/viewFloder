package com.gome.meidian.util;

import com.gome.diamond.annotations.DiamondValue;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author chenchen-ds6
 * 校验是否在活动开始时间内
 */
@Slf4j
@Component
public class CheckSaleRaceUtils {

    @DiamondValue("${business.meidian.race.activity.switch}")
    private Boolean activitySwitch;
    @DiamondValue("${business.meidian.race.activity.beginTime}")
    private String beginTime;
    @DiamondValue("${business.meidian.race.activity.endTime}")
    private String endTime;
    @DiamondValue("${business.meidian.race.activity.suspendTime}")
    private String suspendTime;
    @DiamondValue("${business.meidian.race.activityId}")
    private String activityId;
    @DiamondValue("${business.meidian.race.stage.money.condition}")
    private Long stageMoneyCondition;
    @DiamondValue("${business.meidian.race.stage.inviteUser.condition}")
    private Long stageInviteUserCondition;

    /**
     * 校验活动是否有效（diamond开关是否打开）
     *
     * @return
     */
    public boolean checkActivityIsEffective() {
        return activitySwitch;
    }

    /**
     * 检验入参时间是否在活动开始时间和结束时间期间内
     *
     * @param requestTime
     * @return
     */
    public boolean checkIsActivityTime(Date requestTime) {
        Date beginDate = DateUtils.transStrToDate(beginTime);
        Date endDate = DateUtils.transStrToDate(endTime);
        return requestTime.compareTo(beginDate) == 1 && endDate.compareTo(requestTime) == 1;
    }

    /**
     * 校验截止时间处理逆向单
     *
     * @param requestTime
     * @return
     */
    public boolean checkSuspendTime(Date requestTime) {
        Date suspendDate = DateUtils.transStrToDate(suspendTime);
        return suspendDate.compareTo(requestTime) == 1;
    }

    /**
     * 获取活动id
     *
     * @return
     */
    public String getActivityId() {
        return activityId;
    }

    /**
     * 获取活动开始时间
     *
     * @return
     */
    public Date getActivityBeginTime() {
        return DateUtils.transStrToDate(beginTime);
    }

    /**
     * 获取销售入榜条件
     *
     * @return
     */
    public Long getMoneyCondition() {
        return stageMoneyCondition;
    }

    /**
     * 获取拉新入榜条件
     *
     * @return
     */
    public Long geInviteUserCountCondition() {
        return stageInviteUserCondition;
    }

}
