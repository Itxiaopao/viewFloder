package com.gome.meidian.service.impl;

import com.gome.meidian.mapper.order.OrderFullMessageMapper;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.gome.meidian.entity.OrderFullMessage;
import com.gome.meidian.service.IOrderFullMessageService;
/**
 * @Desc 消息接口实现类
 * @author chenchen-ds6
 *
 */
@Service
public class OrderFullMessageServiceImpl extends ServiceImpl<OrderFullMessageMapper, OrderFullMessage> implements IOrderFullMessageService {

}
