package com.gome.meidian.convert;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import com.gome.meidian.dto.MeidianBangbangCalcTypeDto;
import com.gome.meidian.vo.MeidianBangbangCalcType;
import com.google.common.base.Converter;

/**
 * @author limenghui
 * @create 2020-06-19 17:32
 */
public class MeidianBangbangCalcTypeMapperToDtoConvert {

    public static final Converter<MeidianBangbangCalcType, MeidianBangbangCalcTypeDto> CONVERTER = new Converter<MeidianBangbangCalcType, MeidianBangbangCalcTypeDto>() {

        @Override
        protected MeidianBangbangCalcTypeDto doForward(MeidianBangbangCalcType mapper) {
            if (mapper == null) {
                return null;
            }

            MeidianBangbangCalcTypeDto dto = new MeidianBangbangCalcTypeDto();
            dto.setId(mapper.getId());
            dto.setUserId(mapper.getUserId());
            dto.setUpUserId(mapper.getUpUserId());
            dto.setCount(ObjectUtils.defaultIfNull(mapper.getCount(), 0));
            dto.setFirstOrderPrice(ObjectUtils.defaultIfNull(mapper.getFirstOrderPrice(), 0L));
            dto.setFirstOrderSalePrice(ObjectUtils.defaultIfNull(mapper.getFirstOrderSalePrice(), 0L));
            dto.setCumulateOrderPrice(ObjectUtils.defaultIfNull(mapper.getCumulateOrderPrice(), 0L));
            dto.setCumulateOrderSalePrice(ObjectUtils.defaultIfNull(mapper.getCumulateOrderSalePrice(), 0L));
            dto.setLastOrderPrice(ObjectUtils.defaultIfNull(mapper.getLastOrderPrice(), 0L));
            dto.setLastOrderSalePrice(ObjectUtils.defaultIfNull(mapper.getLastOrderSalePrice(), 0L));

            dto.setLastOrderPayDate(DateFormatUtils.format(mapper.getLastOrderPayDate(), "yyyy-MM-dd"));
            dto.setFirstOrderSubmittedDate(DateFormatUtils.format(mapper.getFirstOrderSubmittedDate(), "yyyy-MM-dd"));
            dto.setFirstOrderPayDate(DateFormatUtils.format(mapper.getFirstOrderPayDate(), "yyyy-MM-dd"));
            dto.setInsertTime(DateFormatUtils.format(mapper.getInsertTime(), "yyyy-MM-dd HH:mm:ss"));
            dto.setUpdateTime(DateFormatUtils.format(mapper.getUpdateTime(), "yyyy-MM-dd HH:mm:ss"));
            return dto;
        }

        @Override protected MeidianBangbangCalcType doBackward(MeidianBangbangCalcTypeDto o) {
            return null;
        }
    };
}
