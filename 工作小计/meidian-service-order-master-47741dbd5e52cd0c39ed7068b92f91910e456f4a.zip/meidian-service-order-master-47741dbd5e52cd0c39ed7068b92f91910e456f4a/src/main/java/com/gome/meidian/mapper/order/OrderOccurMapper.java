package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.entity.StidInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 发生单表 Mapper 接口
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
public interface OrderOccurMapper extends BaseMapper<OrderOccur> {
	
/*    //基本查询条件
	static final String BASE_WHERE_SQLSTR=	
			"<if test='businessType != null'>" +
			" AND occur.business_type = #{businessType} " +
			"</if>" +
			"<if test='productId != null'>" +
			" AND occur.item_id = #{productId} " +
			"</if>" +
			"<if test='skuId != null'>" +
			" AND occur.sku_id = #{skuId} " +
			"</if>" +
			"<if test='skuNo != null'>" +
			" AND occur.sku_no = #{skuNo} " +
			"</if>"+ 
			"<if test='OrderStatus == 1 or OrderStatus == 2'>" +
			" AND occur.order_status = #{OrderStatus}  " +
			"</if> " +  
			"<if test='OrderStatus == 5 or OrderStatus == 6'>" +
			" AND occur.status = #{OrderStatus}  " +
			"</if> " 
;

	 //判断是发生单表  还是妥投单表 的数据
	static final String BASE_OCCUR_TABLE_SQLSTR=
			"<if test='OrderStatus==1 or OrderStatus==2 or OrderStatus==null'>" +
		    	" order_occur occur "+
	       "</if>"+ 
			"<if test='OrderStatus==5 or OrderStatus==6'>" +
		     " order_effect occur "+
		    "</if>"   ;
	
	static final String BASE_QUERY_FIELDS_SQLSTR=
		        	"	occur.order_time," +
					"	occur.order_id," +
					"	occur.delivery_id," +
					"	occur.price_total/100 as price_total," +
					"	occur.buy_num," +
					"	occur.sku_name," +
					"	occur.user_id," +
					"	occur.sell_id," +
					"	occur.mid ," +
					"<if test='OrderStatus==null or OrderStatus==1 or OrderStatus==2'>" +
					"	occur.merchant_id," +
					"   occur.merchant_name," +
					"	occur.order_status as status," +
					"</if>"+
					"<if test='OrderStatus==5 or OrderStatus==6'>" +
					"	occur.status," +
					"</if>"+
					"	occur.address_first," +
					"	occur.address_second," +
					"	occur.address_third," +
					"	occur.address_fourth," +
					"	cate.c1_name AS category_first," +
					"	cate.c2_name AS category_second," +
					"	cate.c3_name AS category_third," +
					"	cate.classify_name," +
					"	occur.item_id," +
					"	shop.region_name," +
					"	shop.branch_name," +
					"	shop.branch_second_name," +
					"   shop.store_id," +
					"   occur.site_id," +
					"	shop.store_name," +
					"	occur.site_id," +
					"	shop.user_id as staff_id," +
					"	shop.user_name AS staff_name," +
					"	occur.sku_id," +
					"	occur.sku_no ";
	
	static final String DETAIL_WHERE_SQLSTR=
			   "    <if test='deliveryId != null'>" +
					" occur.delivery_id = #{deliveryId} AND " +
					"</if>" +
					"<if test='userId != null'>" +
					" occur.user_id = #{userId} AND " +
					"</if>" +
					"<if test='skuId != null'>" +
					" occur.sku_id = #{skuId} AND " +
					"</if>" +
					"<if test='itemId != null'>" +
					" occur.item_id = #{itemId} AND " +
					"</if>" +
					"<if test='skuNo != null'>" +
					" occur.sku_no = #{skuNo} AND " +
					"</if>" +
					"<if test='businessType != null'>" +
					" occur.business_type = #{businessType} AND " +
					"</if>" +
					"<if test='regionId != null'>" +
					" shop.region_id = #{regionId} AND " +
					"</if>" +
					"<if test='branchId != null'>" +
					" shop.branch_id = #{branchId} AND " +
					"</if>" +
					"<if test='branchSecondId != null'>" +
					" shop.branch_second_id = #{branchSecondId} AND " +
					"</if>" +
					"<if test='storeId != null'>" +
					" shop.store_id = #{storeId} AND " +
					"</if>" +
					"<if test='staffId != null'>" +
					" shop.user_id = #{staffId} AND " +
					"</if>" +
					"<if test='classifyId != null'>" +
					" cate.classify_id = #{classifyId} AND " +
					"</if>" +
					"<if test='categoryFirst != null'>" +
					" cate.c1_id = #{categoryFirst} AND " +
					"</if>" +
					"<if test='categorySecond != null'>" +
					" cate.c2_id = #{categorySecond} AND " +
					"</if>" +
					"<if test='categoryThird != null'>" +
					" cate.c3_id = #{categoryThird} AND " +
					"</if>" +
					"<if test='OrderStatus == 1 or OrderStatus == 2'>" +
					" occur.order_status = #{OrderStatus} AND " +
					"</if> " + 
					"<if test='OrderStatus == 5 or OrderStatus == 6'>" +
					" occur.status = #{OrderStatus} AND " +
					"</if> " + 
					 "1=1 ";*/
	
	@Select("select * from order_occur where mid in (${mid}) and (order_time between '${startDate}' and '${endDate}')")
	List<OrderOccur> selectByDateRange(HashMap<String, Object> queryParams);

	@Select("Select * FROM order_occur WHERE item_id = #{itemId} AND (order_time BETWEEN #{startDate} AND #{endDate})")
	List<OrderOccur> selectItemIdByDateRange(@Param("itemId") String itemId, @Param("startDate") Date startDate,
											 @Param("endDate") Date endDate);
	@Select("SELECT stid,"
			+ "sum(buy_num) AS buyNum,"
			+ "sum(price_total) AS orderGMV, "
			+ "count(stid) AS orderNum, "
			+ "sum(price_total) / count(stid) AS unitOrderPrice "
			+ "FROM order_occur"
			+ " WHERE stid IN (${stids}) AND (order_time BETWEEN #{startDate} AND #{endDate})"
			+ "GROUP BY stid ORDER BY orderGMV DESC")
	List<StidInfo> selectStidInfoByDate(@Param("startDate") Date startDate,
										@Param("endDate") Date endDate, @Param("stids")String stids);

	@Select("SELECT mid,"
			+ "sum(buy_num) AS buyNum,"
			+ "sum(price_total) AS orderGMV, "
			+ "count(mid) AS orderNum, "
			+ "sum(price_total) / count(mid) AS unitOrderPrice "
			+ "FROM order_occur"
			+ " WHERE mid IN (${mids}) AND (order_time BETWEEN #{startDate} AND #{endDate})"
			+ "GROUP BY mid ORDER BY orderGMV DESC")
	List<StidInfo> selectMidInfoByDate(@Param("startDate") Date startDate,
									   @Param("endDate") Date endDate, @Param("mids")String mids);

	@Select("<script>"
			+ "SELECT "
			+ "stid,sku_no,sku_name AS productName,business_type,"
			+ "category_first,category_second,category_third,category_fourth,"
			+ "sum(buy_num) AS buyNum,"
			+ "sum(price_total) AS orderGMV, "
			+ "count(sku_no) AS orderNum, "
			+ "sum(price_total) / count(stid) AS unitOrderPrice "
			+ "FROM order_occur"
			+ " WHERE stid IN (${stids}) "
			+ "<if test='skuNo!=null'>"
			+ "AND sku_no = #{skuNo}" 
			+ "</if>"
			+ "AND (order_time BETWEEN #{startDate} AND #{endDate})"
			+ "GROUP BY sku_no ORDER BY orderGMV DESC"
			+ "</script>")
	List<StidInfo> selectskuNoListByDate(@Param("startDate") Date startDate,
										 @Param("endDate") Date endDate, @Param("stids")String stids,  @Param("skuNo")String skuNo);

	@Select("<script>"
			+ "SELECT "
			+ "stid,sku_no,sku_name AS productName,"
			+ "category_first,category_second,category_third,category_fourth,"
			+ "sum(buy_num) AS buyNum,"
			+ "sum(price_total) AS orderGMV, "
			+ "count(sku_no) AS orderNum, "
			+ "sum(price_total) / count(stid) AS unitOrderPrice "
			+ "FROM order_occur"
			+ " WHERE stid = #{stid} "
			+ "<if test='skuNo!=null'>"
			+ "AND sku_no = #{skuNo}" 
			+ "</if>"
			+ "AND (order_time BETWEEN #{startDate} AND #{endDate})"
			+ "GROUP BY sku_no ORDER BY orderGMV DESC"
			+ "</script>")
	List<StidInfo> selectskuNoByDate(@Param("startDate") Date startDate,
									 @Param("endDate") Date endDate, @Param("stid")String stid,  @Param("skuNo")String skuNo);

	@Select("<script>"
			+ "SELECT "
			+ "stid,sku_no,sku_name AS productName,"
			+ "category_first,category_second,category_third,category_fourth,"
			+ "sum(buy_num) AS buyNum,"
			+ "sum(price_total) AS orderGMV, "
			+ "count(sku_no) AS orderNum, "
			+ "sum(price_total) / count(stid) AS unitOrderPrice "
			+ "FROM order_occur"
			+ " WHERE mid = #{mid} "
			+ "<if test='skuNo!=null'>"
			+ "AND sku_no = #{skuNo}" 
			+ "</if>"
			+ "AND (order_time BETWEEN #{startDate} AND #{endDate})"
			+ "GROUP BY sku_no ORDER BY orderGMV DESC"
			+ "</script>")
	List<StidInfo> selectStidInfoByMid(@Param("startDate") Date startDate,
                                       @Param("endDate") Date endDate, @Param("mid") String mid, @Param("skuNo") String skuNo);
/*	@Select("<script>" +
			"SELECT" +
			BASE_QUERY_FIELDS_SQLSTR+
			"   FROM" +
			"	(" +
			BASE_OCCUR_TABLE_SQLSTR+
			"		LEFT JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"	) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"occur.order_time BETWEEN #{startDate} AND #{endDate}  AND " +
			DETAIL_WHERE_SQLSTR+
			" ORDER BY occur.order_time ASC " +
			"<if test='pageIndex != null'>" +
			" LIMIT #{pageIndex},#{pageSize} " +
			"</if>" +
			"</script>")
	List<OrderDetailResponse> queryOrderDetail(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
                                               @Param("deliveryId") String deliveryId, @Param("userId") String userId,
                                               @Param("skuId") String skuId, @Param("itemId") String itemId,
                                               @Param("skuNo") String skuNo, @Param("businessType") Integer businessType,
                                               @Param("regionId") String regionId, @Param("branchId") String branchId,
                                               @Param("branchSecondId") String branchSecondId, @Param("storeId") String storeId,
                                               @Param("staffId") String staffId,
                                               @Param("classifyId") String classifyId, @Param("categoryFirst") String categoryFirst,
                                               @Param("categorySecond") String categorySecond, @Param("categoryThird") String categoryThird,
                                               @Param("pageIndex") Integer pageIndex, @Param("pageSize") Integer pageSize,@Param("OrderStatus") Integer orderStatus);
	@Select("<script>" +
			"SELECT COUNT(1)" +
			"   FROM" +
			"	(" +
			BASE_OCCUR_TABLE_SQLSTR+
			"		LEFT JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"	) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"occur.order_time BETWEEN #{startDate} AND #{endDate}  AND" +
			DETAIL_WHERE_SQLSTR+
			"ORDER BY occur.order_time ASC  " +
			"</script>")
	Long queryOrderDetailCount(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
            @Param("deliveryId") String deliveryId, @Param("userId") String userId,
            @Param("skuId") String skuId, @Param("itemId") String itemId,
            @Param("skuNo") String skuNo, @Param("businessType") Integer businessType,
            @Param("regionId") String regionId, @Param("branchId") String branchId,
            @Param("branchSecondId") String branchSecondId, @Param("storeId") String storeId,
            @Param("staffId") String staffId,
            @Param("classifyId") String classifyId, @Param("categoryFirst") String categoryFirst,
            @Param("categorySecond") String categorySecond, @Param("categoryThird") String categoryThird,
            @Param("OrderStatus") Integer orderStatus);
	
	
	@Select("<script>" +
			"SELECT" +
		    BASE_QUERY_FIELDS_SQLSTR+
			"   FROM"
			+ BASE_OCCUR_TABLE_SQLSTR+
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE" +
			"	occur.order_time BETWEEN #{startDate} AND #{endDate}  AND " +
			"   occur.mid IN ( " +
			"		SELECT " +
			"			DISTINCT occur.mid " +
			"		FROM " +
			 BASE_OCCUR_TABLE_SQLSTR+
			"		LEFT JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"		WHERE " +
			"			occur.order_time BETWEEN #{startDate} AND #{endDate}  " +
			"		AND shop.shop_id IS NULL " +
			"	) AND " +
			DETAIL_WHERE_SQLSTR+
			"ORDER BY occur.order_time ASC " +
			"<if test='pageIndex != null'>" +
			" LIMIT #{pageIndex},#{pageSize}" +
			"</if>" +
			"</script>")
	List<OrderDetailResponse> queryNotStaffDetail(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
                                                  @Param("deliveryId") String deliveryId, @Param("userId") String userId,
                                                  @Param("skuId") String skuId, @Param("itemId") String itemId,
                                                  @Param("skuNo") String skuNo, @Param("businessType") Integer businessType,
                                                  @Param("classifyId") String classifyId, @Param("categoryFirst") String categoryFirst,
                                                  @Param("categorySecond") String categorySecond, @Param("categoryThird") String categoryThird,
                                                  @Param("pageIndex") Integer pageIndex, @Param("pageSize") Integer pageSize,@Param("OrderStatus") Integer orderStatus);
	
	@Select("<script>" +
			"SELECT COUNT(1) " +
			"   FROM"
			+ 	BASE_OCCUR_TABLE_SQLSTR+
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE" +
			"	occur.order_time BETWEEN #{startDate} AND #{endDate}  AND " +
			"   occur.mid IN ( " +
			"		SELECT " +
			"			DISTINCT occur.mid " +
			"		FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"		LEFT JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"		WHERE " +
			"			occur.order_time BETWEEN #{startDate} AND #{endDate}  " +
			"		AND shop.shop_id IS NULL " +
			"	) AND " +
			DETAIL_WHERE_SQLSTR+
			"ORDER BY occur.order_time ASC " +
			"</script>")
	Long queryNotStaffDetailCount(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
            @Param("deliveryId") String deliveryId, @Param("userId") String userId,
            @Param("skuId") String skuId, @Param("itemId") String itemId,
            @Param("skuNo") String skuNo, @Param("businessType") Integer businessType,
            @Param("classifyId") String classifyId, @Param("categoryFirst") String categoryFirst,
            @Param("categorySecond") String categorySecond, @Param("categoryThird") String categoryThird,
           @Param("OrderStatus") Integer orderStatus);
	
	@Select("<script>" +
			"SELECT" +
			BASE_QUERY_FIELDS_SQLSTR+
			"   FROM" +
			"	(" +
			BASE_OCCUR_TABLE_SQLSTR+
			"		JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"	) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE" +
			"	occur.order_time BETWEEN #{startDate} AND #{endDate}  AND" +
			DETAIL_WHERE_SQLSTR+
			"ORDER BY occur.order_time ASC " +
			"<if test='pageIndex != null'>" +
			" LIMIT #{pageIndex},#{pageSize}" +
			"</if>" +
			"</script>")
	List<OrderDetailResponse> queryStaffDetail(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
                                               @Param("deliveryId") String deliveryId, @Param("userId") String userId,
                                               @Param("skuId") String skuId, @Param("itemId") String itemId,
                                               @Param("skuNo") String skuNo, @Param("businessType") Integer businessType,
                                               @Param("regionId") String regionId, @Param("branchId") String branchId,
                                               @Param("branchSecondId") String branchSecondId, @Param("storeId") String storeId,
                                               @Param("staffId") String staffId,
                                               @Param("classifyId") String classifyId, @Param("categoryFirst") String categoryFirst,
                                               @Param("categorySecond") String categorySecond, @Param("categoryThird") String categoryThird,
                                               @Param("pageIndex") Integer pageIndex, @Param("pageSize") Integer pageSize,@Param("OrderStatus") Integer orderStatus);

	@Select("<script>" +
			"SELECT COUNT(1) " +
			"   FROM" +
			"	(" +
			BASE_OCCUR_TABLE_SQLSTR+
			"		JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"	) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE" +
			"	occur.order_time BETWEEN #{startDate} AND #{endDate}  AND" +
			DETAIL_WHERE_SQLSTR+
			"ORDER BY occur.order_time ASC " +
			"</script>")
	Long queryStaffDetailCount(@Param("startDate") Date startDate, @Param("endDate") Date endDate,
            @Param("deliveryId") String deliveryId, @Param("userId") String userId,
            @Param("skuId") String skuId, @Param("itemId") String itemId,
            @Param("skuNo") String skuNo, @Param("businessType") Integer businessType,
            @Param("regionId") String regionId, @Param("branchId") String branchId,
            @Param("branchSecondId") String branchSecondId, @Param("storeId") String storeId,
            @Param("staffId") String staffId,
            @Param("classifyId") String classifyId, @Param("categoryFirst") String categoryFirst,
            @Param("categorySecond") String categorySecond, @Param("categoryThird") String categoryThird,
           @Param("OrderStatus") Integer orderStatus);
	
	
	@Select("<script> " +
			"SELECT  " +
			"region_id as group_id, region_name as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.region_id " +
			"</script>")
	List<OrderCountResponse> queryOrderGMVByRegion(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"region_id as group_id," +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price, " +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			"( "+
			BASE_OCCUR_TABLE_SQLSTR+
			" JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{classId} " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.region_id " +
			"</script>")
	List<OrderCountResponse> queryCateGMVByRegion(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("classId") String classId,
			@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"region_id as group_id," +
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price ," +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			"( "+ 
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{classId} " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.region_id " +
			"</script>")
	List<OrderCountResponse> queryCargoGMVByRegion(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("classId") String classId,
			@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"'合计' as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total ," +
			"IFNULL(sum(buy_num),0) as buy_num  " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"<if test='flag != null'>" +
			" LEFT " +
			"</if>" +
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			BASE_WHERE_SQLSTR+
			"</script>")
	OrderCountResponse queryOrderGMV(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType,
			@Param("flag") Boolean flag,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);


	@Select("<script> " +
			"SELECT  " +
			"'合计' as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(FORMAT((sum(price_total) / 100),2),0) as price_total ," +
			"IFNULL(sum(buy_num),0) as buy_num, " +
			"DATE_FORMAT(occur.order_time,'%Y-%m-%d') as order_time " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"<if test='flag != null'>" +
			" LEFT " +
			"</if>" +
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			BASE_WHERE_SQLSTR+ " group by TO_DAYS(occur.order_time)" +
			"</script>")
	List<OrderCountResponse> queryOrderGMVByOrderTime(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType,
									 @Param("flag") Boolean flag,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);


	@Select("<script> " +
			"SELECT  " +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price , " +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			"( "+ 
			BASE_OCCUR_TABLE_SQLSTR+
			"<if test='flag != null'>" +
			" LEFT " +   
			"</if>" +
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{classId} " +
			BASE_WHERE_SQLSTR+
			"</script>")
	OrderCountResponse queryCateGMV(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("classId") String classId, 
			@Param("flag") Boolean flag,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(FORMAT((sum(price_total) / 100),2),0) as electric_price , " +
			"IFNULL(sum(buy_num),0) as elec_buynum, " +
			"DATE_FORMAT(occur.order_time,'%Y-%m-%d') as order_time " +
			"FROM " +
			"( "+
			BASE_OCCUR_TABLE_SQLSTR+
			"<if test='flag != null'>" +
			" LEFT " +
			"</if>" +
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{classId} " +
			BASE_WHERE_SQLSTR+  " group by TO_DAYS(occur.order_time)" +
			"</script>")
	List<OrderCountResponse> queryCateGMVByOrderTime(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("classId") String classId,
			@Param("flag") Boolean flag,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price, " +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			"( "+
			BASE_OCCUR_TABLE_SQLSTR+
			"<if test='flag != null'>" +
			" LEFT " +
			"</if>" +
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{classId} " +
			BASE_WHERE_SQLSTR+
			"</script>")
	OrderCountResponse queryCargoGMVBy(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, 
			@Param("classId") String classId, @Param("flag") Boolean flag,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);


	@Select("<script> " +
			"SELECT  " +
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(FORMAT((sum(price_total) / 100),2),0) as cargo_price, " +
			"IFNULL(sum(buy_num),0) as cargo_buynum, " +
			"DATE_FORMAT(occur.order_time,'%Y-%m-%d') as order_time " +
			"FROM " +
			"( "+
			BASE_OCCUR_TABLE_SQLSTR+
			"<if test='flag != null'>" +
			" LEFT " +
			"</if>" +
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{classId} " +
			BASE_WHERE_SQLSTR+ " group by TO_DAYS(occur.order_time)" +
			"</script>")
	List<OrderCountResponse> queryCargoGMVByOrderTime(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType,
			@Param("classId") String classId, @Param("flag") Boolean flag,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);


	@Select("<script>" +
			"SELECT  " +
			"'合计' as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM (" +
			"	SELECT " +
			"		mid,price_total,buy_num" +
			"	FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"	WHERE " +
			"		order_time BETWEEN #{startDate} AND #{endDate} " +
			"	<if test='businessType != null'>" +
			" 	    AND business_type = #{businessType} " +
			"	</if>" +
			") a" +
			" LEFT OUTER JOIN ( " +
				"SELECT " +
				"	shop_id  " +
			"	FROM " +
			"		order_shop_same " +
			") b ON a.mid = b.shop_id " +
			"WHERE " +
			"	b.shop_id IS NULL " +
			"</script>")
	OrderCountResponse queryNotStaffOrderGMV1(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType);
	
	
	
	@Select("<script>" +
			"SELECT  " +
			"'合计' as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM "+
			BASE_OCCUR_TABLE_SQLSTR+
			"WHERE " +
			"(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  occur.mid not in (select shop_id from order_shop_same)  "+
			BASE_WHERE_SQLSTR+
			"</script>")
	OrderCountResponse queryNotStaffOrderGMV(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType,
			@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);
	
	@Select("<script>" +
			"SELECT  " +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price, " +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"	LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"	AND occur.category_second = cate.c2_id " +
			"	AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  occur.mid not in (select shop_id from order_shop_same)  "+
			BASE_WHERE_SQLSTR+
			"   AND  cate.classify_id = #{electricType} "+
			"</script>")
	OrderCountResponse queryNotStaffCateGMV(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("electricType") String electricType,
			@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);
	
	@Select("<script>" +
			"SELECT  " +
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price, " +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"	LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"	AND occur.category_second = cate.c2_id " +
			"	AND occur.category_third = cate.c3_id " +
			"WHERE " +
			"(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  occur.mid not in (select shop_id from order_shop_same)  "+
			BASE_WHERE_SQLSTR+
			"   AND  cate.classify_id = #{cargoType} "+
			"</script>")
	OrderCountResponse queryNotStaffCargoGMVBy(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("cargoType") String cargoType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);
	
	@Select("<script>" +
			"SELECT  " +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price " +
			"FROM (" +
			"	SELECT " +
			"		mid,price_total,buy_num" +
			"	FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"	LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"	AND occur.category_second = cate.c2_id " +
			"	AND occur.category_third = cate.c3_id " +
			"	WHERE " +
			"		occur.order_time BETWEEN #{startDate} AND #{endDate} " +
			"	 AND  classify_id = #{electricType}" +
			"	<if test='businessType != null'>" +
			" 	    AND occur.business_type = #{businessType} " +
			"	</if>" +
			") a" +
			" LEFT OUTER JOIN ( " +
				"SELECT " +
				"	shop_id  " +
			"	FROM " +
			"		order_shop_same " +
			") b ON a.mid = b.shop_id " +
			"WHERE " +
			"	b.shop_id IS NULL " +
			"</script>")
	OrderCountResponse queryNotStaffCateGMV1(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("electricType") String electricType);

	@Select("<script>" +
			"SELECT  " +
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price " +
			"FROM (" +
			"	SELECT " +
			"		mid,price_total,buy_num" +
			"	FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"	LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"	AND occur.category_second = cate.c2_id " +
			"	AND occur.category_third = cate.c3_id " +
			"	WHERE " +
			"		occur.order_time BETWEEN #{startDate} AND #{endDate} " +
			"	 AND  classify_id = #{cargoType}" +
			"	<if test='businessType != null'>" +
			" 	    AND occur.business_type = #{businessType} " +
			"	</if>" +
			") a" +
			" LEFT OUTER JOIN ( " +
				"SELECT " +
				"	shop_id  " +
			"	FROM " +
			"		order_shop_same " +
			") b ON a.mid = b.shop_id " +
			"WHERE " +
			"	b.shop_id IS NULL " +
			"</script>")
	OrderCountResponse queryNotStaffCargoGMVBy1(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("cargoType") String cargoType);

	@Select("<script> " +
			"SELECT  " +
			"branch_id as group_id, branch_name as group_name, " +
			"IFNULL(count(1),0) as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.branch_id " +
			"</script>")
	List<OrderCountResponse> queryOrderGMVByBrand(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"branch_id as group_id," +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price, " +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			"( "+ 
			BASE_OCCUR_TABLE_SQLSTR+
			" JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{electricType} " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.branch_id " +
			"</script>")
	List<OrderCountResponse> queryCateGMVByBrand(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("electricType") String electricType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"branch_id as group_id," +
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price, " +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			"( "+ 
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{cargoType} " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.branch_id " +
			"</script>")
	List<OrderCountResponse> queryCargoGMVByBrand(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("cargoType") String cargoType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"branch_second_id as group_id, branch_name as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.branch_second_id " +
			"</script>")
	List<OrderCountResponse> queryOrderGMVByBrandSecond(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"branch_second_id as group_id," +
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price, " +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			"("+ 
			BASE_OCCUR_TABLE_SQLSTR+
			" JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{electricType} " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.branch_second_id " +
			"</script>")
	List<OrderCountResponse> queryCateGMVByBrandSecond(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("electricType") String electricType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"branch_second_id as group_id," +
			"IFNULL(count(1),0) as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price, " +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			"( "+ 
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{cargoType} " +
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.branch_second_id " +
			"</script>")
	List<OrderCountResponse> queryCargoGMVByBrandSecond(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("cargoType") String cargoType
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"shop.store_id as group_id,"+
			"store_name as group_name, " +
			"IFNULL(count(1),0) as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			" AND shop.store_id = #{storeId} "+
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.store_id " +
			"</script>")
	OrderCountResponse queryOrderGMVByStore(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("storeId") String storeId
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			" shop.user_id as group_id,"+
			"user_name as group_name, " +
			"IFNULL(count(1),0)  as order_num, " +
			"IFNULL(sum(price_total) / 100,0) as price_total, " +
			"IFNULL(sum(buy_num),0) as buy_num " +
			"FROM " +
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND " +
			"	(occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			" AND shop.user_id = #{staffId} "+
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.user_id " +
			"</script>")
	OrderCountResponse queryOrderGMVByStaff(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("staffId") String staffId
			,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"shop.store_id ,"+
			"IFNULL(count(1),0)  as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price, " +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			"( "+ 
			BASE_OCCUR_TABLE_SQLSTR+
			" JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{electricType} " +
			"AND store_id = #{storeId} "+
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.store_id " +
			"</script>")
	OrderCountResponse queryCateGMVByStore(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("electricType") String electricType,
                                           @Param("storeId") String storeId,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			" shop.user_id ,"+
			"IFNULL(count(1),0) as electric_num, " +
			"IFNULL(sum(price_total) / 100,0) as electric_price ," +
			"IFNULL(sum(buy_num),0) as elec_buynum  " +
			"FROM " +
			"("+
			BASE_OCCUR_TABLE_SQLSTR+
			" JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{electricType} " +
			"AND shop.user_id = #{staffId} "+
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.user_id" +
			"</script>")
	OrderCountResponse queryCateGMVByStaff(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("electricType") String electricType,
                                           @Param("staffId") String staffId,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			"store_id ,"+
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price ," +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			"("+ 
			BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{cargoType} " +
			"AND store_id = #{storeId} "+
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.store_id " +
			"</script>")
	OrderCountResponse queryCargoGMVByStore(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("cargoType") String cargoType,
                                            @Param("storeId") String storeId,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	@Select("<script> " +
			"SELECT  " +
			" shop.user_id ,"+
			"IFNULL(count(1),0)  as cargo_num, " +
			"IFNULL(sum(price_total) / 100,0) as cargo_price ," +
			"IFNULL(sum(buy_num),0) as cargo_buynum  " +
			"FROM " +
			"("
			+BASE_OCCUR_TABLE_SQLSTR+
			"JOIN order_shop_same shop ON occur.mid = shop.shop_id ) " +
			"LEFT JOIN order_category cate ON occur.category_first = cate.c1_id " +
			"AND occur.category_second = cate.c2_id " +
			"AND occur.category_third = cate.c3_id " +
			"WHERE " +
			" shop.region_id IS NOT NULL " +
			"AND (occur.order_time BETWEEN #{startDate} AND #{endDate} ) " +
			"AND  classify_id = #{cargoType} " +
			"AND shop.user_id = #{staffId} "+
			BASE_WHERE_SQLSTR+
			"GROUP BY shop.user_id " +
			"</script>")
	OrderCountResponse queryCargoGMVByStaff(@Param("startDate") Date startDate, @Param("endDate") Date endDate, @Param("businessType") Integer businessType, @Param("cargoType") String cargoType,
                                            @Param("staffId") String staffId,@Param("productId") String productId,@Param("skuId") String skuId,@Param("skuNo") String skuNo,@Param("OrderStatus") Integer orderStatus);

	*//**
	 * 每次活动手动导出数据并合并
	 *//*
	@Select("<script> " +
			"SELECT  " +
			" SUM(price_total) / 100 as orderNum ,"+
			" count(*) as buyNum ,"+
			" mid as groupName"+
			" FROM " +
			" order_occur "+
			" WHERE " +
			" (order_time between '${startDate}' and '${endDate}')" +
			"AND mid in (${mid}) "+
			"GROUP BY mid " +
			"</script>")
	ArrayList<OrderCountResponse> queryGMVOfMid(HashMap<String, Object> queryParams);*/

	@Select({"<script>",
			"SELECT * FROM order_occur",
			"<where>",
			"<if test='id != null'> and id = #{id} </if>",
			"<if test='orderStatus != null'> and order_status = #{orderStatus} </if>",
			"<if test='orderId != null'> and order_id = #{orderId} </if>",
			"<if test='deliveryId != null'> and delivery_id = #{deliveryId} </if>",
			"<if test='skuId != null'> and sku_id = #{skuId} </if>",
			"</where>",
			" ORDER BY create_time,order_time ASC ",
			"<if test='pageIndex != null and pageSize != null'>  LIMIT #{pageIndex},#{pageSize}</if>",
			"</script>"})
	List<OrderOccur> selectPageByBiz(Map<String,Object> param);

	@Select({"<script>",
			"SELECT count(1) FROM order_occur",
			"<where>",
			"<if test='orderStatus != null'> and order_status = #{orderStatus} </if>",
			"</where>",
			"</script>"})
	Integer selectCountByBiz(Map<String,Object> param);

	@Select({"<script>",
			"SELECT * FROM order_occur",
			"<where>",
			"<if test='id != null'> and id > #{id} </if>",
			"<if test='orderStatus != null'> and order_status = #{orderStatus} </if>",
			"<if test='orderId != null'> and order_id = #{orderId} </if>",
			"<if test='deliveryId != null'> and delivery_id = #{deliveryId} </if>",
			"<if test='skuId != null'> and sku_id = #{skuId} </if>",
			"</where>",
			" ORDER BY id ASC ",
			"<if test='pageSize != null'>  LIMIT #{pageSize}</if>",
			"</script>"})
	List<OrderOccur> selectPageByAlgorithm(Map<String,Object> param);

	@Select({"<script>",
			"SELECT id FROM order_occur",
			"<where>",
			"<if test='orderStatus != null'> and order_status = #{orderStatus} </if>",
			"</where>",
			" ORDER BY id ASC  LIMIT 1",
			"</script>"})
	Long selectFirstId(Map<String,Object> param);

}
