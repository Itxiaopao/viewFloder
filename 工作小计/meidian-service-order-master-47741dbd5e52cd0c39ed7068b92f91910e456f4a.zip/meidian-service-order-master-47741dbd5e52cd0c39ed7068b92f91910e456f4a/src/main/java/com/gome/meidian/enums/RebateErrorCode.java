package com.gome.meidian.enums;

import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.Maps;

/**
 * 返利errorCode
 *
 * @author limenghui
 * @create 2020-02-10 22:09
 */
public enum RebateErrorCode {
    // @formatter:off
    E9100("传入参数异常，请检查传入参数"),
    E9101("没有查到业务预算"),
    E9102("预算扣减失败"),
    E9103("预算扣减系统处理异常"),
    E9104("该条数据正在被处理中"),
    E9105("该条数据已被处理"),
    E9106("该条数据已超过最大处理次数"),
    E9107("国美币发放失败"),
    E9108("程序处理异常"),
    E0000("成功"),

    ;

    // @formatter:on
    private String msg;

    private static final Map<String, RebateErrorCode> INDEX = Maps.newHashMap();
    static {
        for (RebateErrorCode code : RebateErrorCode.values()) {
            INDEX.put(code.name(), code);
        }

    }

    RebateErrorCode(String msg) {
        this.msg = msg;
    }

    public static Optional<RebateErrorCode> codeOf(String errCode){
        return Optional.ofNullable(INDEX.get(StringUtils.upperCase(errCode)));
    }

}
