package com.gome.meidian.dao;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.page.BasePageVo;
import com.gome.meidian.vo.MogOrderBody;
import com.gome.meidian.vo.ReqOrderBody;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@SuppressWarnings({"unchecked", "rawtypes"})
@Repository
public class OrderBodyDao extends MongGenDao<MogOrderBody> {

    @Override
    protected Class getEntityClass() {
        return MogOrderBody.class;
    }

    /**
     * 保存 mogOrderBody
     *
     * @param mogOrderBody
     */
    @SneakyLog
    public ResultEntity saveOrderBody(MogOrderBody mogOrderBody) {
        //参数过滤
        if (StringUtils.isBlank(mogOrderBody.getMsgId()) || mogOrderBody.getOrderId() == null) {
            return new ResultEntity(90001, "msgId,orderId is null");
        }
        //保存订单-初始化默认值
        this.save(mogOrderBody);
        return new ResultEntity();
    }

    /**
     * 删除 mogOrderBody 通过id
     *
     * @param id
     * @return
     */
    @SneakyLog
    public ResultEntity delOrderBodyById(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity(90002, "id is null");
        }
        this.deleteById(id);
        return new ResultEntity();
    }

    /**
     * 多条件获取 mogOrderBody 列表
     *
     * @param reqOrderBody
     * @return
     */
    @SneakyLog
    public ResultEntity<List<MogOrderBody>> queryOrderBodyList(ReqOrderBody reqOrderBody) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.orderBodyParamFile(reqOrderBody));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "orderTime"));
        //查询订单列表
        List<MogOrderBody> list = this.findList(query);
        return new ResultEntity(list);
    }

    //添加条件封装
    private Criteria orderBodyParamFile(ReqOrderBody reqOrderBody) {
        Criteria criteria = new Criteria();
        //主键id
        String id = reqOrderBody.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //消息id
        String msgId = reqOrderBody.getMsgId();
        if (StringUtils.isNotBlank(msgId)) {
            criteria.and("msgId").is(msgId);
        }
        //订单id
        Long orderId = reqOrderBody.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //用户id
        Long userId = reqOrderBody.getUserId();
        if (userId != null) {
            criteria.and("userId").is(userId);
        }
        //订单状态
        List<Integer> orderStatusList = reqOrderBody.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = reqOrderBody.getOrderStartTime();
        Date orderEndTime = reqOrderBody.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        return criteria;
    }

    /**
     * 分页获取订单数据
     *
     * @param reqOrderBody
     * @return
     */
    @SneakyLog
    public ResultEntity<List<MogOrderBody>> queryHistoryOrderBody(ReqOrderBody reqOrderBody) {
        //分页参数过滤
        BasePageVo page = reqOrderBody.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            return new ResultEntity(90002, "pageNo,pageSize is null");
        }
        //封装条件查询数据
        Criteria criteria = new Criteria();
        //订单状态
        List<Integer> orderStatusList = reqOrderBody.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = reqOrderBody.getOrderStartTime();
        Date orderEndTime = reqOrderBody.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gt(orderStartTime).lte(orderEndTime);
        }
        //查询数据
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(criteria),
                Aggregation.group("orderId").max("orderTime").as("orderTime").first("msgBody").as("msgBody"),
                Aggregation.sort(new Sort(Sort.Direction.DESC, "orderTime")),
                Aggregation.skip(page.getStartRow()),
                Aggregation.limit(page.getPageSize()));
        AggregationResults<MogOrderBody> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderBody", MogOrderBody.class);
        return new ResultEntity(aggResult.getMappedResults());
    }

    /**
     * 统计历史订单数据量
     *
     * @param reqOrderBody
     * @return
     */
    @SneakyLog
    public ResultEntity<Integer> countQueryHistoryOrderBody(ReqOrderBody reqOrderBody) {
        //封装条件查询数据
        Criteria criteria = new Criteria();
        //订单状态
        List<Integer> orderStatusList = reqOrderBody.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = reqOrderBody.getOrderStartTime();
        Date orderEndTime = reqOrderBody.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gt(orderStartTime).lte(orderEndTime);
        }
        //查询数据
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(criteria),
                Aggregation.group("orderId"));
        AggregationResults<MogOrderBody> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderBody", MogOrderBody.class);
        //响应信息
        return new ResultEntity(aggResultCount.getMappedResults().size());
    }

}
