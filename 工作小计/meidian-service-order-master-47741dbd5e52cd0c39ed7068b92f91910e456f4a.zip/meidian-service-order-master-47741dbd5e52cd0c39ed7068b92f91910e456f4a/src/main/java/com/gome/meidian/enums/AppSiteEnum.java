package com.gome.meidian.enums;

public enum AppSiteEnum {

    mobileEntityCardSite("国美实体卡-APP"),
    mobilePresellSite("手机客户端APP预售"),
    mobileGiftSite("手机客户端APP礼物"),
    mobileGroupOnSite("客户端团购站点"),
    mobileRushBuySite("客户端抢购站点"),
    mobileSite("手机客户端"),
    mobileVirtualCardSite("国美电子卡-APP"),
    mobileFightGroupSite("拼团站点APP"),
    mobileJixinSite("app极信"),
    mobileWarrantySite("APP延保补购站点"),
    mobileOperatorSite("移动app运营商站点"),
    ;


    private String desc;

    public static boolean contains(String name) {
        for (AppSiteEnum enu : AppSiteEnum.values()) {
            if (enu.name().equals(name)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }


    private AppSiteEnum(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
