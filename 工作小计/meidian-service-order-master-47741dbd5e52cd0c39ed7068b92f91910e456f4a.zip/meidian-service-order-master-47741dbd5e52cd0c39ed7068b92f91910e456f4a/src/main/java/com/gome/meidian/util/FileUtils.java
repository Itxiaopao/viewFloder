package com.gome.meidian.util;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Slf4j
public class FileUtils {
    private static ReadWriteLock lock = new ReentrantReadWriteLock();

    public static String readFileContent(String filePath) {
        String diamondUrl = null;
        File file = new File(filePath);
        if (file.exists()) {
            lock.readLock().lock();
            BufferedReader br = null;

            try {
                br = new BufferedReader(new FileReader(file));
                String line = null;

                while ((line = br.readLine()) != null) {
                    line = trimToEmpty(line);
                    if (!line.startsWith("#")) {
                        diamondUrl = trim(line);
                        break;
                    }
                }
            } catch (IOException var13) {
                log.error("[FileUtils.readFileContent] 加载.diamond.domain文件[{}]出错:{}", filePath, var13.getMessage());
            } finally {
                if (br != null) {
                    try {
                        br.close();
                    } catch (IOException var12) {
                    }
                }
                lock.readLock().unlock();
            }
        } else {
            log.error("[FileUtils.readFileContent] 配置文件{}不存在，请检查！", filePath);
        }

        return diamondUrl;
    }

    private static String trim(String str) {
        return str == null ? null : str.trim();
    }

    private static String trimToEmpty(String str) {
        return str == null ? "" : str.trim();
    }
}
