package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class OrderCategoryVo implements Serializable {

    private static final long serialVersionUID = 8849256448540762627L;
    private String c3Id;//三级品类
    private String c3Name;//三级品类名称
    private String c2Id;//二级品类
    private String c2Name;//二级品类名称
    private String c1Id;//一级品类
    private String c1Name;//一级品类名称
    private String classifyName;//订单分类名称
    private String classifyId;//订单分类编码
    private String businessCenter;//业务中心类
    private String businessCategroy;//业务品类

}
