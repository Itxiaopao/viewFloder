package com.gome.meidian.config.dataSource;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import com.baomidou.mybatisplus.plugins.PaginationInterceptor;
import com.baomidou.mybatisplus.spring.MybatisSqlSessionFactoryBean;


@Configuration
@MapperScan(basePackages = {"com.gome.meidian.mapper.order*"}, sqlSessionTemplateRef = "orderSqlSessionTemplate")
public class OrderDataSourceConfig {

	@Bean(name = "orderDataSource")
	@ConfigurationProperties(prefix = "spring.datasource.order")
	@Primary
	public DataSource orderDataSource(){ return DataSourceBuilder.create().build();
	}

	@Bean(name = "orderSqlSessionFactory")
	@ConfigurationProperties(prefix ="mybatis-plus")
	@Primary
	public SqlSessionFactory orderSqlSessionFactory(@Qualifier("orderDataSource") DataSource dataSource) throws Exception{
		MybatisSqlSessionFactoryBean sqlSessionFactoryBean = new MybatisSqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(orderDataSource());
		Resource[] resources = new PathMatchingResourcePatternResolver().getResources("classpath:mapper/order/*.xml");
		sqlSessionFactoryBean.setMapperLocations(resources);
		return sqlSessionFactoryBean.getObject();
	}

	@Bean(name = "orderTransactionManager")
	@Primary
	public DataSourceTransactionManager orderTransactionManager(@Qualifier("orderDataSource") DataSource dataSource){
		return new DataSourceTransactionManager(dataSource);
	}

	@Bean(name = "orderSqlSessionTemplate")
	@Primary
	public SqlSessionTemplate orderSqlSessionTemplate(@Qualifier("orderSqlSessionFactory")SqlSessionFactory sqlSessionFactory){
		return new SqlSessionTemplate(sqlSessionFactory);
	}

	/**
	 * mybatis-plus分页插件<br>
	 */
	@Bean
	public PaginationInterceptor paginationInterceptor() {
		PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
		paginationInterceptor.setLocalPage(true);// 开启 PageHelper 的支持
		return paginationInterceptor;
	}
}
