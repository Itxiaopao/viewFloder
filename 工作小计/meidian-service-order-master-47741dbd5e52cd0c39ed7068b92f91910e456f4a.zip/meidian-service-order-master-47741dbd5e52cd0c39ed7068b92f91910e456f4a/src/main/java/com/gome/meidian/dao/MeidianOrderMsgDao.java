package com.gome.meidian.dao;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.vo.MogOrderMsgInfo;
import com.gome.meidian.vo.ReqOrderMsg;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@SuppressWarnings({"unchecked", "rawtypes"})
@Repository
public class MeidianOrderMsgDao extends MongGenDao<MogOrderMsgInfo> {

    @Override
    protected Class getEntityClass() {
        return MogOrderMsgInfo.class;
    }

    @SneakyLog
    public ResultEntity saveOrderMsg(MogOrderMsgInfo mogOrderMsgInfo) {
        //参数过滤
        if (StringUtils.isBlank(mogOrderMsgInfo.getMsgId())) {
            return new ResultEntity(90001, "msgId is null");
        }
        //保存订单-初始化默认值
        this.save(mogOrderMsgInfo);
        //响应信息
        return new ResultEntity();
    }

    @SneakyLog
    public ResultEntity delOrderMsgById(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity(90002, "id is null");
        }
        this.deleteById(id);
        return new ResultEntity();
    }

    /**
     * 删除 mogOrderMsgInfo 通过时间范围
     *
     * @param time
     * @return
     */
    @SneakyLog
    public ResultEntity delOrderMsgByTime(Date time) {
        if (time == null) {
            return new ResultEntity(90002, "time is null");
        }
        //设定条件
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("createTime").lt(time);
        query.addCriteria(criteria);
        this.delete(query);
        return new ResultEntity();
    }

    /**
     * 多条件获取 mogOrderMsgInfo 列表
     *
     * @param reqOrderMsg
     * @return
     */
    @SneakyLog
    public ResultEntity<List<MogOrderMsgInfo>> queryOrderMsgList(ReqOrderMsg reqOrderMsg) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.orderMsgParamFile(reqOrderMsg));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "createTime"));
        //查询订单列表
        List<MogOrderMsgInfo> list = this.findList(query);
        return new ResultEntity(list);
    }

    //添加条件封装
    private Criteria orderMsgParamFile(ReqOrderMsg reqOrderMsg) {
        Criteria criteria = new Criteria();
        //主键id
        String id = reqOrderMsg.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //消息id
        String msgId = reqOrderMsg.getMsgId();
        if (StringUtils.isNotBlank(msgId)) {
            criteria.and("msgId").is(msgId);
        }
        //订单时间范围
        Date startTime = reqOrderMsg.getStartTime();
        Date endTime = reqOrderMsg.getEndTime();
        if (startTime != null && endTime != null) {
            criteria.and("createTime").gte(startTime).lte(endTime);
        }
        return criteria;
    }

}
