package com.gome.meidian.util;



import org.apache.poi.hssf.usermodel.HSSFWorkbook;


import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.gome.meidian.entity.OrderShop;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ReadExcelUtils {

    /**
     * 读取单个excel表
     *
     * @param path
     * @return
     * @throws IOException
     */
    public static List<HashMap<String, Object>> readExcel(String path) {
        //创建一个list 用来存储读取的内容
        List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

        File file = new File(path);
        Workbook workbook = null;
        try {
            if (path.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(file));
            } else {//xls
                POIFSFileSystem poifsFileSystem = new POIFSFileSystem(new FileInputStream(file));
                workbook = new HSSFWorkbook(poifsFileSystem);
            }
            //Excel的页签数量
            int sheet_size = workbook.getNumberOfSheets();
            for (int index = 0; index < sheet_size; index++) {
                LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
                //获取文件的指定工作表 默认的第一个
                Sheet sheet = workbook.getSheetAt(index);
                if (sheet.getLastRowNum() > 0) {
                    //获取表头
                    List<String> heardList = new ArrayList<String>();
                    int columns = sheet.getRow(0).getPhysicalNumberOfCells();//获取总列数
                    for (int k = 0; k < columns; k++) { 
                        sheet.getRow(0).getCell(k).setCellType(Cell.CELL_TYPE_STRING);
                        heardList.add(sheet.getRow(0).getCell(k).getStringCellValue());
                    }
                    //行数(表头的目录不需要，从1开始)
                    List<List<String>> recordList = new ArrayList<List<String>>();
                    System.out.println("第" + (index + 1) + "个行数" + sheet.getLastRowNum() + "--------");
                    System.out.println("第" + (index + 1) + "个列数" + columns + "--------");
                    for (int i = 1; i < sheet.getLastRowNum() + 1; i++) {
                        List<String> contentList = new ArrayList<String>();
                        //列数
                        for (int j = 0; j < columns; j++) {
                            //获取第i行，第j列的值
                            if (sheet.getRow(i).getCell(j) != null) {
                                sheet.getRow(i).getCell(j).setCellType(Cell.CELL_TYPE_STRING);
                                contentList.add(sheet.getRow(i).getCell(j).getStringCellValue());
                            } else {
                                contentList.add("");
                            }

                        }
                        recordList.add(contentList);
                    }
                    map.put("heardList", heardList);//表头内容
                    map.put("recordList", recordList);//记录内容
                    map.put("sheetName", sheet.getSheetName());
                    System.out.println("recordList" + recordList.size());
                    map.put("sheetNum", (index + 1));//sheet
                    list.add(map);
                }
            }
//        	workbook.colse();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    public static List<HashMap<String, Object>> readExcels(String path) {
        //创建一个list 用来存储读取的内容
        List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();

        File file = new File(path);
        Workbook workbook = null;
        try {
            if (path.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(file));
            } else {//xls
                POIFSFileSystem poifsFileSystem = new POIFSFileSystem(new FileInputStream(file));
                workbook = new HSSFWorkbook(poifsFileSystem);
            }
            //Excel的页签数量
            int sheet_size = workbook.getNumberOfSheets();
            LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
            //获取文件的指定工作表 默认的第一个
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet.getLastRowNum() > 0) {
                //获取表头
                List<String> heardList = new ArrayList<String>();
                int columns = sheet.getRow(0).getPhysicalNumberOfCells();//获取总列数
                for (int k = 0; k < columns; k++) {
                    sheet.getRow(0).getCell(k).setCellType(Cell.CELL_TYPE_STRING);
                    heardList.add(sheet.getRow(0).getCell(k).getStringCellValue());
                }
                //行数(表头的目录不需要，从1开始)
                List<List<String>> recordList = new ArrayList<List<String>>();
                System.out.println(sheet.getLastRowNum());
                for (int i = 1; i < sheet.getLastRowNum() + 1; i++) {
                    List<String> contentList = new ArrayList<String>();
                    //列数
                    if (sheet.getRow(i) != null) {
                        for (int j = 0; j < columns; j++) {
                            //获取第i行，第j列的值
                            if (sheet.getRow(i).getCell(j) != null) {
                                sheet.getRow(i).getCell(j).setCellType(Cell.CELL_TYPE_STRING);
                                contentList.add(sheet.getRow(i).getCell(j).getStringCellValue());
                            } else {
                                contentList.add("");
                            }

                        }

                    }
                    recordList.add(contentList);
                }
                map.put("heardList", heardList);//表头内容
                map.put("recordList", recordList);//记录内容
                map.put("sheetName", sheet.getSheetName());
                System.out.println("recordList" + recordList.size());
                map.put("sheetNum", (0 + 1));//sheet
                list.add(map);
            }
//        	workbook.colse();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    public static List<HashMap<String, Object>> isExcel(String path) {
        //创建一个list 用来存储读取的内容

        List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
        File file = new File(path);
        Workbook workbook = null;
        try {
            if (path.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(file));
            } else if (path.endsWith(".xls")) {//xls
                POIFSFileSystem poifsFileSystem = new POIFSFileSystem(new FileInputStream(file));
                workbook = new HSSFWorkbook(poifsFileSystem);
            } else {
                return null;
            }
            //Excel的页签数量
            int sheet_size = workbook.getNumberOfSheets();
            for (int index = 0; index < sheet_size; index++) {
                //获取文件的指定工作表 默认的第一个
                Sheet sheet = workbook.getSheetAt(index);
                if (sheet.getLastRowNum() > 0) {
                    LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
                    if (sheet.getRow(0) != null) {
                        int columns = sheet.getRow(0).getPhysicalNumberOfCells();//获取总列数
                        int b = isMergedRegion(sheet, 5, columns);
                        System.out.println("第" + (index + 1) + "个" + b + "--------");
                        if (b <= 1) {
                            map.put("isisExcelformat", true);
                        } else {
                            map.put("isisExcelformat", false);
                        }
                        list.add(map);
                    }
                }
            }
//        	workbook.colse();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return list;
    }

    /**
     * 读取多个excel表
     *
     * @param path
     * @return
     * @throws IOException
     */
    public static List<HashMap<String, Object>> readMoreExcel(String path) {
        // 此处路径指定到目录而不是单个文件
        File file = new File("E:/zhanhj/studysrc/jxl");
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files)
                // 如果还存在子目录则继续读取子目录下的Excel文件
                if (f.isDirectory()) {
                    File[] subfiles = f.listFiles();
                    for (File fi : subfiles) {
                        // 对文件进行过滤，只读取Excel文件，非Excel文件不读取，否则会出错
                        if (fi.getName().indexOf(".xls") > 0) {
                            readExcel(fi.getPath());//读取单个
                            //TODO 封装获取参数
                        }
                    }
                } else {
                    // 对文件进行过滤，只读取Excel文件，非Excel文件不读取，否则会出错
                    if (f.getName().indexOf(".xls") > 0) {
                        readExcel(f.getPath());//读取单个
                        //TODO 封装获取参数
                    }
                }
        }
        return null;
    }

    public static void main(String[] args) {

    }

    /**
     * 读取单个excel表
     *
     * @param path
     * @return
     * @throws IOException
     */
    public static List<OrderShop> readExcel2(String path) {
        //创建一个list 用来存储读取的内容
        List<OrderShop> recordList = new ArrayList<OrderShop>();
        List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
        File file = new File(path);
        Workbook workbook = null;
        try {
            if (path.endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(new FileInputStream(file));
            } else {//xls
                POIFSFileSystem poifsFileSystem = new POIFSFileSystem(new FileInputStream(file));
                workbook = new HSSFWorkbook(poifsFileSystem);
            }
            //Excel的页签数量
            int sheet_size = workbook.getNumberOfSheets();
            for (int index = 0; index < sheet_size; index++) {
                LinkedHashMap<String, Object> map = new LinkedHashMap<String, Object>();
                //获取文件的指定工作表 默认的第一个
                Sheet sheet = workbook.getSheetAt(index);
                if (sheet.getLastRowNum() > 0) {
                    //获取表头
                    List<String> heardList = new ArrayList<String>();
                    int columns = sheet.getRow(0).getPhysicalNumberOfCells();//获取总列数
                    for (int k = 0; k < columns; k++) {
                        sheet.getRow(0).getCell(k).setCellType(Cell.CELL_TYPE_STRING);
                        heardList.add(sheet.getRow(0).getCell(k).getStringCellValue());
                    }
                    //行数(表头的目录不需要，从1开始)
                    for (int i = 1; i < sheet.getLastRowNum(); i++) {
                        List<String> contentList = new ArrayList<String>();
                        //列数
//	        		for(int j=0; j<columns; j++){
                        //获取第i行，第j列的值
//	        			if(sheet.getRow(i).getCell(j) != null){
//	        				sheet.getRow(i).getCell(j).setCellType(Cell.CELL_TYPE_STRING);
//	        				contentList.add(sheet.getRow(i).getCell(j).getStringCellValue());
                        OrderShop ykDataSet = new OrderShop();
                        /*
                        ykDataSet.setNameCh(sheet.getRow(i).getCell(5).getStringCellValue());
                        ykDataSet.setNameEn("");
                        ykDataSet.setDescribe(sheet.getRow(i).getCell(9).getStringCellValue());
                        ykDataSet.setSign(sheet.getRow(i).getCell(31).getStringCellValue());
                        ykDataSet.setVersion("");
                        ykDataSet.setKeyword(sheet.getRow(i).getCell(10).getStringCellValue());
                        ykDataSet.setLanguages(sheet.getRow(i).getCell(16).getStringCellValue() == "中文" ? 1 : 0);
                        ykDataSet.setFkSubjectId(sheet.getRow(i).getCell(13).getStringCellValue());
                        ykDataSet.setResourceTypeId(sheet.getRow(i).getCell(14).getStringCellValue() == "01" ? 1 : 0);
                        ykDataSet.setDataAuthority(1);
                        ykDataSet.setRemarks("");
                        ykDataSet.setVersionInfo("");
                        ykDataSet.setFkScienceDataId(1);
                        ykDataSet.setCreateDate(new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").parse(sheet.getRow(i).getCell(1).getStringCellValue()));
                        ykDataSet.setSubmitDate(new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").parse(sheet.getRow(i).getCell(18).getStringCellValue()));
                        ykDataSet.setUpdateDate(new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").parse(sheet.getRow(i).getCell(2).getStringCellValue()));
                        ykDataSet.setAttachment("");
                        ykDataSet.setResourceLink(sheet.getRow(i).getCell(21).getStringCellValue());
                        ykDataSet.setSuffix(sheet.getRow(i).getCell(15).getStringCellValue());
                        ykDataSet.setGeographicRange("");
                        ykDataSet.setTimeRange("");
                        ykDataSet.setDataSize(sheet.getRow(i).getCell(23).getStringCellValue());
                        ykDataSet.setFileNum((Long.valueOf(sheet.getRow(i).getCell(24).getStringCellValue())));
                        ykDataSet.setSource(1);
                        ykDataSet.setIsSourceProject(1);
                        ykDataSet.setStatus(1);
                        ykDataSet.setFkUserId(1);
                        ykDataSet.setCreaterType(1);
                        ykDataSet.setDataQualityType(1);
                        ykDataSet.setEntityDataFlag(sheet.getRow(i).getCell(26).getStringCellValue() == "有实例数据" ? 1 : 0);
                        ykDataSet.setIsLicense(1);
                        ykDataSet.setDownloadNum(Long.valueOf(sheet.getRow(i).getCell(27).getStringCellValue()));
                        ykDataSet.setClickNum(Long.valueOf(sheet.getRow(i).getCell(26).getStringCellValue()));
                        ykDataSet.setQuoteDescride("");
                        ykDataSet.setDataCheckOpinion("");
                        ykDataSet.setDataCheckTime(new Date());
                        ykDataSet.setSubmitUserId(1);
                        ykDataSet.setDepartmentId(1);
                        ykDataSet.setLicenseNumber(0);
                        ykDataSet.setLicenseUrl("");
                        ykDataSet.setLicenseStatus(1);
                        ykDataSet.setLicenseCheckOpinion("");
                        ykDataSet.setProjectName("");
                        ykDataSet.setProjectNum("");
                        ykDataSet.setProjectSource("");
                        ykDataSet.setSaveDate(new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").parse(sheet.getRow(i).getCell(2).getStringCellValue()));
                        recordList.add(ykDataSet);
                        */
//	        			}else{
//	        				contentList.add("");
//	        			}

//	        		}
//	        		recordList.add(contentList);
                    }
//	        	map.put("heardList", heardList);//表头内容
//	        	map.put("recordList", recordList);//记录内容
//	        	map.put("sheetNum", (index+1));//sheet
//	        	list.add(map);
                }
            }
//        	workbook.close();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return recordList;
    }

    private static Integer isMergedRegion(Sheet sheet, int row, int column) {
        int sheetMergeCount = sheet.getNumMergedRegions();
        if (sheetMergeCount > 0) {
            int num = 0;
            for (int i = 0; i < sheetMergeCount; i++) {
                CellRangeAddress range = sheet.getMergedRegion(i);
                int firstColumn = range.getFirstColumn();
                int lastColumn = range.getLastColumn();
                int firstRow = range.getFirstRow();
                int lastRow = range.getLastRow();
                if (firstRow >= 0 && lastRow <= row + 1) {
                    if (firstColumn >= 0 && lastColumn <= column + 1) {
                        num += 1;
                    }
                }
            }
            return num;
        }

        return 0;
    }
}
