package com.gome.meidian.service.impl;

import com.gome.meidian.constant.Constant;
import com.gome.meidian.enums.CpaUserStatusEnum;
import com.gome.meidian.mapper.order.MeidianCpaDistinctMapper;
import com.gome.meidian.service.ICpaDistinctService;
import com.gome.meidian.service.IGrantRebateService;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.manager.IMeidianBindingRelationManager;
import com.gome.meidian.util.DateUtils;
import com.gomeo2o.common.exceptions.BizException;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Author helinhao
 * @create 2020/2/28 11:01
 */
@Slf4j
@Service("cpaDistinctServiceImpl")
public class CpaDistinctServiceImpl implements ICpaDistinctService {

    @Autowired
    MeidianCpaDistinctMapper meidianCpaDistinctMapper;
    @Autowired
    IMeidianBindingRelationManager meidianBindingRelationManager;
    @Autowired
    IGrantRebateService grantRebateService;

    private static String invokeFrom = Constant.SYSTEM_NAME;

    @Override
    public List<Long> selectUserIdListNonFirst(){
        return meidianCpaDistinctMapper.selectUserIdListNonFirst();
    }

    @Override
    public List<Long> selectUserIdListNonFirstByDate(String startDate,String endDate){
        return meidianCpaDistinctMapper.selectUserIdListNonFirstByDate(startDate,endDate);
    }

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void scheduledScanCpaDistinct(String[] date){
        //查询非首单设备的userId集合
        List<Long> userIdList = new ArrayList<>();
        if (date.length == 0){
            userIdList = this.selectUserIdListNonFirst();
        }else if (date.length == 2){
            String startDate = date[0];
            String endDate = date[1];
            try{
                SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                sdf.parse(startDate);
                sdf.parse(endDate);
            } catch (Exception e){
                log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 传入的时间参数有误，params={}",date);
                return;
            }
            userIdList = this.selectUserIdListNonFirstByDate(startDate,endDate);
        }else{
            log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 传入的时间参数有误，params={}",date);
            return;
        }

        for(Long userId : userIdList){
            //更新首单信息
            MapResults<Integer> mapResults = meidianBindingRelationManager.updateRelationStatus(userId, CpaUserStatusEnum.appFirstOrderCancel.getCode(), invokeFrom);
            if (mapResults == null || !mapResults.getSuccess() || mapResults.getBuessObj() == 0) {
                log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 更新meidian_binding_relation表异常,user_id={}",userId);
                throw new BizException("更新meidian_binding_relation状态异常");
            } else {
                Boolean flag = grantRebateService.updateFailureStatusByUserId(userId);
                if(!flag){
                    log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 更新meidian_cpa_distinct表异常,user_id={}",userId);
                    throw new BizException("更新meidian_grant_rebate failure_status状态异常");
                }
            }
        }

    }


    @Override
    public void scheduledScanCpaDistinct(String dateStr){

        //查询非首单设备的userId集合
        List<Long> userIdList = new ArrayList<>();

        if (StringUtils.isNotEmpty(dateStr)) {
            List<String> list = Splitter.on(",").omitEmptyStrings().splitToList(dateStr);

            if(list.size() != 2){
                log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 传入的时间参数有误，params={}",dateStr);
                return;
            }else{
                String startDate = list.get(0);
                String endDate = list.get(1);
                try{
                    SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    sdf.parse(startDate);
                    sdf.parse(endDate);
                } catch (Exception e){
                    log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 传入的时间参数有误，params={}",dateStr);
                    return;
                }
                userIdList = this.selectUserIdListNonFirstByDate(startDate,endDate);
            }
        }else{
            userIdList = this.selectUserIdListNonFirst();
        }

        for(Long userId : userIdList){
            //更新首单信息
            MapResults<Integer> mapResults = meidianBindingRelationManager.updateRelationStatus(userId, CpaUserStatusEnum.appFirstOrderCancel.getCode(), invokeFrom);
            if (mapResults == null || !mapResults.getSuccess() || mapResults.getBuessObj() == 0) {
                log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 更新meidian_binding_relation表异常,user_id={}",userId);
                throw new BizException("更新meidian_binding_relation状态异常");
            } else {
                Boolean flag = grantRebateService.updateFailureStatusByUserId(userId);
                if(!flag){
                    log.error("【CpaDistinctServiceImpl.scheduledScanCpaDistinct】 更新meidian_cpa_distinct表异常,user_id={}",userId);
                    throw new BizException("更新meidian_grant_rebate failure_status状态异常");
                }
            }
        }
    }
}
