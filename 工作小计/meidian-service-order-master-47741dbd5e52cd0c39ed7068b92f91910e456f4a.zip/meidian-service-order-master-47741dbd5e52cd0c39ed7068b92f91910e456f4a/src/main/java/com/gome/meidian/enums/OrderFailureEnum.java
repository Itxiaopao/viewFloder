package com.gome.meidian.enums;

/**
 * 订单失效原因枚举
 */
public enum OrderFailureEnum {

    restrictPrice(1, "不满足限价"),
    firstDevice(2, "不是首个设备"),
    ;

    public static String valueOf(Integer status) {
        for (OrderFailureEnum enu : OrderFailureEnum.values()) {
            if (enu.getStatus().equals(status)) {
                return enu.getName();
            }
        }
        return null;
    }

    private Integer status;

    private String name;

    private OrderFailureEnum(Integer status, String name) {
        this.status = status;
        this.name = name;
    }

    public Integer getStatus() {
        return status;
    }

    public String getName() {
        return name;
    }

}
