package com.gome.meidian.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gome.meidian.mapper.order.OrderOccurMapper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.gome.meidian.config.GCacheConfig;
import com.gome.meidian.entity.OrderChannel;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.entity.StidInfo;
import com.gome.meidian.service.IOrderBodyErrorService;
import com.gome.meidian.service.IOrderChannelService;
import com.gome.meidian.service.IOrderOccurService;
import com.gome.meidian.service.util.OrderErrorLogUtil;

/**
 * <p>
 * 发生单表 服务实现类
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
@Service
public class OrderOccurServiceImpl extends ServiceImpl<OrderOccurMapper, OrderOccur> implements IOrderOccurService {

	@Autowired
	IOrderChannelService channelService;

	@Autowired
	GCacheConfig gCacheService;

	@Autowired
	IOrderBodyErrorService orderBodyErrorSvc;

	@Autowired
	OrderErrorLogUtil errorLogUtil;

	@Autowired
	OrderOccurMapper orderMapper;
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Override
	@Transactional(rollbackFor = Throwable.class)
	public boolean insertOccurOrder(OrderOccur orderOccur) {
		// 如果表已有该记录 则不进行任何操作
		HashMap<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("order_id", orderOccur.getOrderId());
		queryMap.put("commerce_id", orderOccur.getCommerceId());
		queryMap.put("delivery_id", orderOccur.getDeliveryId());
		if (!CollectionUtils.isEmpty(this.selectByMap(queryMap))) {
			return true;
		}
		try {
			// 插入发生表
			/*
			 * // 渠道表查询 HashMap<String, Object> queryMap = new HashMap<String, Object>();
			 * queryMap.put("order_id", orderOccur.getOrderId());
			 * queryMap.put("commerce_id", orderOccur.getCommerceId()); List<OrderChannel>
			 * orderChannels = orderChannelSvc.selectByMap(queryMap);
			 * if(CollectionUtils.isEmpty(orderChannels)){
			 * if(StringUtils.isNotEmpty(orderOccur.getStid())){ OrderChannel orderChannel =
			 * new OrderChannel(); BeanUtils.copyProperties(orderOccur, orderChannel);
			 * orderChannelSvc.insert(orderChannel); } }
			 */

			if (null != orderOccur.getKid()) {
				if(orderOccur.getKid().startsWith("TUAN")) {
					orderOccur.setStatus(0);
				}
				String kid = convertKid(orderOccur.getKid());
				orderOccur.setKid(kid);
				Map<String, String> kMap = gCacheService.gcache().hgetAll(kid);
				if (null != kMap && kMap.size() > 0) {
					OrderChannel channel = new OrderChannel();
					BeanUtils.copyProperties(orderOccur, channel);
					channel.setMdKid(kid);
					channel.setMdMid(kMap.get("mid"));
					channel.setMdStid(kMap.get("stid"));
					channel.setMdUid(kMap.get("userId"));
					channel.setMdPgid(kMap.get("pgid"));
					channel.setMdChid(kMap.get("chid"));
					channel.setMdBack(kMap.get("back"));
					boolean channelInsert = channelService.insert(channel);
					if(!channelInsert) {
						logger.info("-------------插入渠道表失败orderChannel" + channel.toString());
						errorLogUtil.insertLog(orderOccur, "插入渠道表失败");
						return false;
					}
				}
			}
			boolean occurInsert = this.insert(orderOccur);
			if(!occurInsert) {
				logger.info("-------------插入发生表失败orderOccur" + orderOccur.toString());
				errorLogUtil.insertLog(orderOccur, "插入发生表失败");
			}
			return occurInsert;

		} catch (Exception e) {
			errorLogUtil.insertLog(orderOccur, e.getMessage());
			throw e;
		}
	}
	/**
	 * @Desc
	 * @param orderOccur
	 * @return
	 */
	@Override
	@Transactional(rollbackFor = Throwable.class)
	public boolean updateOrderToCancel(OrderOccur orderOccur) {
		try{
			HashMap<String, Object> queryMap = new HashMap<String, Object>();
			queryMap.put("order_id", orderOccur.getOrderId());
			queryMap.put("commerce_id", orderOccur.getCommerceId());
			queryMap.put("delivery_id", orderOccur.getDeliveryId());
			if (CollectionUtils.isEmpty(this.selectByMap(queryMap))) {
				logger.info("-------------发生表未查询到该条数据" + orderOccur.toString());
				if (null != orderOccur.getKid()) {
					if(orderOccur.getKid().startsWith("TUAN")) {
						orderOccur.setStatus(0);
					}
					String kid = convertKid(orderOccur.getKid());
					orderOccur.setKid(kid);
				}
				
				return this.insert(orderOccur);
			}
			EntityWrapper<OrderOccur> entityWrapper = new EntityWrapper<OrderOccur>();
			boolean updateOrderToCancel = this.update(orderOccur, entityWrapper.eq("order_id", orderOccur.getOrderId()).eq("commerce_id", orderOccur.getCommerceId()).eq("delivery_id", orderOccur.getDeliveryId()));
			if(updateOrderToCancel) {
				logger.info("-------------发生表中更新状态成功"+updateOrderToCancel + orderOccur.toString());
			}else {
				logger.info("-------------发生表中更新状态失败"+updateOrderToCancel + orderOccur.toString());
			}
			return updateOrderToCancel;
		}catch(Exception e){
			errorLogUtil.insertLog(orderOccur, e.getMessage());
			return false;
		}
	}
	/**
	 * @Title: convertKid
	 * @param kid
	 * @return
	 * @Description: 获取原生的kid
	 */
	private String convertKid(String kid) {
		if (kid.contains("_")) {
			try {
				kid = kid.split("_")[2];
			} catch (Exception e) {
			}
		}
		return kid;
	}

	@Override
	public List<OrderOccur> selectByDateRange(HashMap<String, Object> queryParams) {
		String object = queryParams.get("mid").toString();
		String[] splitStr = StringUtils.strip(object, "[]").split(",");
		String temp = convertList(splitStr);
		queryParams.put("mid", temp);
		List<OrderOccur> orderOccurs = orderMapper.selectByDateRange(queryParams);
		return orderOccurs;
	}
	private String convertList(String[] params) {
		String temp = "";
		int size = params.length;
		for (int i = 0 ; i < size ; i++) {
			if(i != size - 1) {
				temp += "'"+params[i].trim()+"',";
			}else {
				temp += "'"+params[i].trim()+"'";
			}
		}
		return temp;
	}
	@Override
	public List<OrderOccur> selectItemIdByDateRange(String itemId, Date startDate, Date endDate) {
		return orderMapper.selectItemIdByDateRange(itemId, startDate, endDate);
	}

	private String convertList(List<String> params) {
		String temp = "";
		for (int i = 0; i < params.size(); i++) {
			if (i != (params.size() - 1)) {
				temp += "'" + params.get(i) + "',";
			} else {
				temp += "'" + params.get(i) + "'";
			}
		}
		return temp;
	}

	@Override
	public List<StidInfo> selectStidInfoByDate(Date startDate, Date endDate, List<String> stids) {
		if (null == startDate || null == endDate || null == stids || stids.size() == 0) {
			return null;
		}
		return orderMapper.selectStidInfoByDate(startDate, endDate, convertList(stids));
	}

	@Override
	public List<StidInfo> selectMidInfoByDate(Date startDate, Date endDate, List<String> mids) {
		if (null == startDate || null == endDate || null == mids || mids.size() == 0) {
			return null;
		}
		return orderMapper.selectMidInfoByDate(startDate, endDate, convertList(mids));
	}

	@Override
	public List<StidInfo> selectSkuNoByDate(Date startDate, Date endDate, List<String> stids, String skuNo) {
		if (null == startDate || null == endDate || null == stids || stids.size() == 0) {
			return null;
		}
		if (stids.size() == 1) {
			return orderMapper.selectskuNoByDate(startDate, endDate, stids.get(0), skuNo);
		}
		return orderMapper.selectskuNoListByDate(startDate, endDate, convertList(stids), skuNo);
	}

	@Override
	public List<StidInfo> selectStidInfoByMid(Date startDate, Date endDate, String mid, String skuNo) {
		if (null == startDate || null == endDate || null == mid) {
			return null;
		}
		return orderMapper.selectStidInfoByMid(startDate, endDate, mid, skuNo);
	}
}
