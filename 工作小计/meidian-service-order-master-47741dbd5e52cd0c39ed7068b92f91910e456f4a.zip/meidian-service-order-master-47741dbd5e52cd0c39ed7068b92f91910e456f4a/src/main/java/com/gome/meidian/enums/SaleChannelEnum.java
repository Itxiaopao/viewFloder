package com.gome.meidian.enums;

/**
 * OMS订单状态
 */
public enum SaleChannelEnum {

    NOTEMPLOYEE(0, "非员工销售"),
    REPLACE(1, "代客下单"),
    FIRSTSTAIR(2, "一级销售"),
    SECONDSTAIR(3, "二级销售"),


    DIFFERENT_BREND(1, "不同品牌A卖B的情况");


    private Integer status;

    private String statusName;

    private SaleChannelEnum(Integer status, String statusName) {
        this.status = status;
        this.statusName = statusName;
    }

    public Integer getStatus() {
        return status;
    }

    public String getStatusName() {
        return statusName;
    }
}
