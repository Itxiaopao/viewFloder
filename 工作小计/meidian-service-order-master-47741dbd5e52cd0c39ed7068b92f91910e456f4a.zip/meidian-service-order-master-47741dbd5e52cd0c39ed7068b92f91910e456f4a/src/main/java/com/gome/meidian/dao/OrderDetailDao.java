package com.gome.meidian.dao;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.vo.MogOrderDetail;
import com.gome.meidian.vo.ReqOrderVo;
import com.mongodb.DuplicateKeyException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Slf4j
@Repository
public class OrderDetailDao extends MongGenDao<MogOrderDetail> {

    @Override
    protected Class getEntityClass() {
        return MogOrderDetail.class;
    }

    public ResultEntity<Boolean> saveRecord(MogOrderDetail record) {
        if (record == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        try {
            this.save(record);
            return new ResultEntity<>(Boolean.TRUE);
        } catch (DuplicateKeyException e) {
            log.info("保存订单详情因主键冲突插入失败,入参:{}", JSON.toJSON(record));
            return new ResultEntity<>(Boolean.FALSE);
        } catch (Exception e) {
            String format = String.format("保存订单详情发生异常,入参:%s,异常堆栈如下：", JSON.toJSON(record));
            log.error(format, e);
            return new ResultEntity<>(Boolean.FALSE);
        }

    }

    public ResultEntity<Boolean> delRecord(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity<>(402, "id不能为空");
        }
        this.deleteById(id);
        return new ResultEntity<>(Boolean.TRUE);
    }

    public ResultEntity<Boolean> updateRecord(MogOrderDetail record) {
        if (record == null || record.getId() == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        //多条件嵌入
        Query query = Query.query(Criteria.where("_id").is(record.getId()));
        //封装更新数据
        Update update = this.updateParam(record);
        this.updateMulti(query, update);
        return new ResultEntity<>(Boolean.TRUE);
    }

    public ResultEntity<List<MogOrderDetail>> queryListByBiz(ReqOrderVo param) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.queryParam(param));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "orderTime"));
        //查询订单列表
        List<MogOrderDetail> list = this.findList(query);
        return new ResultEntity<>(list);
    }

    /**
     * 更新条件封装
     *
     * @param record
     * @return
     */
    private Update updateParam(MogOrderDetail record) {
        Update update = new Update();
        Long orderId = record.getOrderId();
        if (orderId != null) {
            update.set("orderId", orderId);
        }
        Long commerceId = record.getCommerceId();
        if (commerceId != null) {
            update.set("commerceId", commerceId);
        }
        String deliveryId = record.getDeliveryId();
        if (deliveryId != null) {
            update.set("deliveryId", deliveryId);
        }
        String kid = record.getKid();
        if (kid != null) {
            update.set("kid", kid);
        }
        Long userId = record.getUserId();
        if (userId != null) {
            update.set("userId", userId);
        }
        Integer userType = record.getUserType();
        if (userType != null) {
            update.set("userType", userType);
        }
        Long parentUserId = record.getParentUserId();
        if (parentUserId != null) {
            update.set("parentUserId", parentUserId);
        }
        Long topLeaderUser = record.getTopLeaderUser();
        if (topLeaderUser != null) {
            update.set("topLeaderUser", topLeaderUser);
        }
        List<Long> userIdRelation = record.getUserIdRelation();
        if (CollectionUtils.isNotEmpty(userIdRelation)) {
            update.set("userIdRelation", userIdRelation);
        }
        String skuId = record.getSkuId();
        if (skuId != null) {
            update.set("skuId", skuId);
        }
        String skuNo = record.getSkuNo();
        if (skuNo != null) {
            update.set("skuNo", skuNo);
        }
        String skuName = record.getSkuName();
        if (skuName != null) {
            update.set("skuName", skuName);
        }
        String itemId = record.getItemId();
        if (itemId != null) {
            update.set("itemId", itemId);
        }
        Integer buyNum = record.getBuyNum();
        if (buyNum != null) {
            update.set("buyNum", buyNum);
        }
        Long priceTotal = record.getPriceTotal();
        if (priceTotal != null) {
            update.set("priceTotal", priceTotal);
        }
        Long unitPrice = record.getUnitPrice();
        if (unitPrice != null) {
            update.set("unitPrice", unitPrice);
        }
        String merchantId = record.getMerchantId();
        if (merchantId != null) {
            update.set("merchantId", merchantId);
        }
        String siteId = record.getSiteId();
        if (siteId != null) {
            update.set("siteId", siteId);
        }
        Integer orderStatus = record.getOrderStatus();
        if (orderStatus != null) {
            update.set("orderStatus", orderStatus);
        }
        Integer showStatus = record.getShowStatus();
        if (showStatus != null) {
            update.set("showStatus", showStatus);
        }
        Date orderCreateTime = record.getOrderCreateTime();
        if (orderCreateTime != null) {
            update.set("orderCreateTime", orderCreateTime);
        }
        Date orderTime = record.getOrderTime();
        if (orderTime != null) {
            update.set("orderTime", orderTime);
        }
        Long afterSalesOrderId = record.getAfterSalesOrderId();
        if (afterSalesOrderId != null) {
            update.set("afterSalesOrderId", afterSalesOrderId);
        }
        String categoryFirstId = record.getCategoryFirstId();
        if (categoryFirstId != null) {
            update.set("categoryFirstId", categoryFirstId);
        }
        String categoryFirstName = record.getCategoryFirstName();
        if (categoryFirstName != null) {
            update.set("categoryFirstName", categoryFirstName);
        }
        String categorySecondId = record.getCategorySecondId();
        if (categorySecondId != null) {
            update.set("categorySecondId", categorySecondId);
        }
        String categorySecondName = record.getCategorySecondName();
        if (categorySecondName != null) {
            update.set("categorySecondName", categorySecondName);
        }
        String categoryThirdId = record.getCategoryThirdId();
        if (categoryThirdId != null) {
            update.set("categoryThirdId", categoryThirdId);
        }
        String categoryThirdName = record.getCategoryThirdName();
        if (categoryThirdName != null) {
            update.set("categoryThirdName", categoryThirdName);
        }
        String categoryFourthId = record.getCategoryFourthId();
        if (categoryFourthId != null) {
            update.set("categoryFourthId", categoryFourthId);
        }
        String categoryFourthName = record.getCategoryFourthName();
        if (categoryFourthName != null) {
            update.set("categoryFourthName", categoryFourthName);
        }
        String marketingOrganizationId = record.getMarketingOrganizationId();
        if (marketingOrganizationId != null) {
            update.set("marketingOrganizationId", marketingOrganizationId);
        }
        String companyCode = record.getCompanyCode();
        if (companyCode != null) {
            update.set("companyCode", companyCode);
        }
        String orderItemId = record.getOrderItemId();
        if (orderItemId != null) {
            update.set("orderItemId", orderItemId);
        }
        String sellerId = record.getSellerId();
        if (sellerId != null) {
            update.set("sellerId", sellerId);
        }
        Integer sourceType = record.getSourceType();
        if (sourceType != null) {
            update.set("sourceType", sourceType);
        }
        String spuId = record.getSpuId();
        if (spuId != null) {
            update.set("spuId", spuId);
        }
        String isWarranty = record.getIsWarranty();
        if (isWarranty != null) {
            update.set("isWarranty", isWarranty);
        }
        String shopCode = record.getShopCode();
        if (shopCode != null) {
            update.set("shopCode", shopCode);
        }
        String addressFirst = record.getAddressFirst();
        if (addressFirst != null) {
            update.set("addressFirst", addressFirst);
        }
        String addressSecond = record.getAddressSecond();
        if (addressSecond != null) {
            update.set("addressSecond", addressSecond);
        }
        String addressThird = record.getAddressThird();
        if (addressThird != null) {
            update.set("addressThird", addressThird);
        }
        String addressFourth = record.getAddressFourth();
        if (addressFourth != null) {
            update.set("addressFourth", addressFourth);
        }
        Integer businessType = record.getBusinessType();
        if (businessType != null) {
            update.set("businessType", businessType);
        }
        String brandCode = record.getBrandCode();
        if (brandCode != null) {
            update.set("brandCode", brandCode);
        }
        String channelType = record.getChannelType();
        if (channelType != null) {
            update.set("channelType", channelType);
        }
        String merchantName = record.getMerchantName();
        if (merchantName != null) {
            update.set("merchantName", merchantName);
        }
        String regionId = record.getRegionId();
        if (regionId != null) {
            update.set("regionId", regionId);
        }
        String regionName = record.getRegionName();
        if (regionName != null) {
            update.set("regionName", regionName);
        }
        String brandId = record.getBrandId();
        if (brandId != null) {
            update.set("brandId", brandId);
        }
        String brandName = record.getBrandName();
        if (brandName != null) {
            update.set("brandName", brandName);
        }
        String brandSecondId = record.getBrandSecondId();
        if (brandSecondId != null) {
            update.set("brandSecondId", brandSecondId);
        }
        String brandSecondName = record.getBrandSecondName();
        if (brandSecondName != null) {
            update.set("brandSecondName", brandSecondName);
        }
        String storeId = record.getStoreId();
        if (storeId != null) {
            update.set("storeId", storeId);
        }
        String storeName = record.getStoreName();
        if (storeName != null) {
            update.set("storeName", storeName);
        }
        Integer isElectric = record.getIsElectric();
        if (isElectric != null) {
            update.set("isElectric", isElectric);
        }
        String purchaseType = record.getPurchaseType();
        if (purchaseType != null) {
            update.set("purchaseType", purchaseType);
        }
        String saleType = record.getSaleType();
        if (saleType != null) {
            update.set("saleType", saleType);
        }
        String saleChannel = record.getSaleChannel();
        if (saleChannel != null) {
            update.set("saleChannel", saleChannel);
        }
        Integer cmsEffective = record.getCmsEffective();
        if (cmsEffective != null) {
            update.set("cmsEffective", cmsEffective);
        }
        String businessCenter = record.getBusinessCenter();
        if (businessCenter != null) {
            update.set("businessCenter", businessCenter);
        }
        String businessCategroy = record.getBusinessCategroy();
        if (businessCategroy != null) {
            update.set("businessCategroy", businessCategroy);
        }
        Integer bSaleA = record.getBSaleA();
        if (bSaleA != null) {
            update.set("bSaleA", bSaleA);
        }
        Date createTime = record.getCreateTime();
        if (createTime != null) {
            update.set("createTime", createTime);
        }
        Date updateTime = record.getUpdateTime();
        if (updateTime != null) {
            update.set("updateTime", updateTime);
        }
        return update;
    }

    /**
     * 添加条件封装
     *
     * @param param 请求参数
     * @return
     */
    private Criteria queryParam(ReqOrderVo param) {
        Criteria criteria = new Criteria();
        //主键
        String id = param.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //订单号
        Long orderId = param.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //子订单号
        Long commerceId = param.getCommerceId();
        if (commerceId != null) {
            criteria.and("commerceId").is(commerceId);
        }
        //配送号
        String deliveryId = param.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            criteria.and("deliveryId").is(deliveryId);
        }
        //下单人id
        Long userId = param.getUserId();
        if (userId != null) {
            criteria.and("userId").is(userId);
        }
        //手机号
        String phoneNo = param.getPhoneNo();
        if (StringUtils.isNotBlank(phoneNo)) {
            criteria.and("phoneNo").is(phoneNo);
        }
        //用户类型  0 普通用户  1 美店主
        Integer userType = param.getUserType();
        if (userType != null) {
            criteria.and("userType").is(userType);
        }
        //下单人直属上级id
        Long parentUserId = param.getParentUserId();
        if (parentUserId != null) {
            criteria.and("parentUserId").is(parentUserId);
        }
        //片总id
        Long userIdPZ = param.getUserIdPZ();
        if (userIdPZ != null) {
            criteria.and("userIdPZ").is(userIdPZ);
        }
        //关系链
        List<Long> userIdRelation = param.getUserIdRelation();
        if (CollectionUtils.isNotEmpty(userIdRelation)) {
            criteria.and("userIdRelation").in(userIdRelation);
        }
        //skuId
        String skuId = param.getSkuId();
        if (StringUtils.isNotBlank(skuId)) {
            criteria.and("skuId").is(skuId);
        }
        //订单状态
        List<Integer> orderStatusList = param.getOrderStatusList();
        if (CollectionUtils.isNotEmpty(orderStatusList)) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //展示状态
        List<Integer> showStatusList = param.getShowStatusList();
        if (CollectionUtils.isNotEmpty(showStatusList)) {
            criteria.and("showStatus").in(showStatusList);
        }
        //订单时间范围
        Date orderStartTime = param.getOrderStartTime();
        Date orderEndTime = param.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        //是否剔除不存在提奖金额的订单  true:是  false:否
        Boolean awardFlag = param.getAwardFlag();
        if (awardFlag != null && awardFlag) {
            criteria.and("awardMoney").exists(true);
        }
        return criteria;
    }

}
