package com.gome.meidian.mapper.order;


import com.gome.meidian.vo.MeidianBangbangCalcProfit;

import java.util.List;
import java.util.Map;

public interface MeidianBangbangCalcProfitMapper {

    int delete(Long id);

    int insert(MeidianBangbangCalcProfit record);

    List<MeidianBangbangCalcProfit> selectByBiz(Map<String, Object> map);

    int update(MeidianBangbangCalcProfit record);
}