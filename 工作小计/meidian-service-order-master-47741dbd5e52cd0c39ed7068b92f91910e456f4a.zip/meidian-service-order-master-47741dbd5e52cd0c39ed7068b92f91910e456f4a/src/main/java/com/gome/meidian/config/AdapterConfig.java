package com.gome.meidian.config;

import com.gome.boot.adapter.config.aspect.CacheableAspect;
import com.gome.boot.adapter.config.aspect.RedisLockAspect;
import com.gome.boot.adapter.config.aspect.SneakyLogAspect;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gomeo2o.common.exceptions.BizException;
import com.gomeplus.bs.framework.dubbor.exceptions.BizExcepition;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import redis.Gcache;

import java.util.Arrays;

@Configuration
public class AdapterConfig {

    @Autowired
    private Gcache gcache;

    @Bean(name = "sneakyLogAspect")
    public SneakyLogAspect sneakyLogAspect() {
        return new SneakyLogAspect(Arrays.asList(BizException.class, com.gome.framework.exception.BizException.class, BizExcepition.class));
    }

    @Bean(name = "cacheableAspect")
    public CacheableAspect cacheableAspect() {
        return new CacheableAspect(gcache);
    }

    @Bean(name = "redisLockAspect")
    public RedisLockAspect redisLockAspect() {
        return new RedisLockAspect(gcache, BizException.class);
    }

    @Bean(name = "redisLockUtils")
    public RedisLockUtils redisLockUtils() {
        return new RedisLockUtils(gcache);
    }

}
