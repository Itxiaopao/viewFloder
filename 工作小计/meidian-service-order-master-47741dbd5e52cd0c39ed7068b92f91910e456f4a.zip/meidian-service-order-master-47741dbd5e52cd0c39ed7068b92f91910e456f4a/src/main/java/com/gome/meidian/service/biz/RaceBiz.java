package com.gome.meidian.service.biz;

import com.gome.meidian.dao.MogRaceUserInfoDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

import java.math.BigDecimal;

@Slf4j
@Component
public class RaceBiz {
    @Autowired
    private MogRaceUserInfoDao mogRaceUserInfoDao;
    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;

    /**
     * 处理销售Gmv
     */
    public void dealSaleOrder(MogRaceUserInfo mogRaceUserInfo){
        log.info("处理销售的参数:{}",mogRaceUserInfo);
        MogRaceUserInfo originalRanking = queryExistByUser(mogRaceUserInfo.getUserId());
        if(null == originalRanking){
            BigDecimal integral = new BigDecimal(mogRaceUserInfo.getSaleVolume() / 1000000);
            mogRaceUserInfo.setIntegral(integral.doubleValue());
            mogRaceUserInfo.setVersion(1);
            mogRaceUserInfo.setActivityId(checkSaleRaceUtils.getActivityId());
            mogRaceUserInfoDao.saveRecord(mogRaceUserInfo);
        }else{
            log.info("查询获得原始排名信息:{}",originalRanking);
            Long originalSaleVolume = ObjectUtils.defaultIfNull(originalRanking.getSaleVolume(),0L);
            Integer originalInviteUserCount = ObjectUtils.defaultIfNull(originalRanking.getInviteUserCount(),0);
            Long newSaleVolume = originalSaleVolume + mogRaceUserInfo.getSaleVolume();
            Double saleIntegral = new Double(newSaleVolume / 1000000);
            Double inviteIntegral = new Double(originalInviteUserCount / 3);
            BigDecimal bigDecimal = new BigDecimal(saleIntegral * 0.7 + inviteIntegral * 0.3);
            BigDecimal resultIntegral = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP);
            originalRanking.setIntegral(resultIntegral.doubleValue() <= 0 ? 0 : resultIntegral.doubleValue());
            originalRanking.setSaleVolume(newSaleVolume <= 0 ? 0 : newSaleVolume);
            log.info("处理之后的排名信息:{}",originalRanking);
            mogRaceUserInfoDao.updateUserRace(originalRanking);
        }
    }

    /**
     * 处理拉新
     * @param mogRaceUserInfo
     */
    public void dealInviteUser(MogRaceUserInfo mogRaceUserInfo){
        log.info("处理拉新的参数:{}",mogRaceUserInfo);
        MogRaceUserInfo originalRanking = queryExistByUser(mogRaceUserInfo.getUserId());
        if(null == originalRanking){
            BigDecimal integral = new BigDecimal(mogRaceUserInfo.getInviteUserCount() / 3);
            mogRaceUserInfo.setIntegral(integral.doubleValue());
            mogRaceUserInfo.setVersion(1);
            mogRaceUserInfo.setActivityId(checkSaleRaceUtils.getActivityId());
            mogRaceUserInfoDao.saveRecord(mogRaceUserInfo);
        }else{
            log.info("查询获得原始排名信息:{}",originalRanking);
            Integer originalInviteUserCount = ObjectUtils.defaultIfNull(originalRanking.getInviteUserCount(),0);
            Long originalSaleVolume = ObjectUtils.defaultIfNull(originalRanking.getSaleVolume(),0L);
            Double saleIntegral = new Double(originalSaleVolume / 1000000);
            Double newInviteUserIntegral = new Double((mogRaceUserInfo.getInviteUserCount() + originalInviteUserCount) / 3);
            BigDecimal bigDecimal = new BigDecimal(saleIntegral * 0.7 + newInviteUserIntegral * 0.3);
            BigDecimal resultIntegral = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP);
            originalRanking.setIntegral(resultIntegral.doubleValue());
            originalRanking.setInviteUserCount(originalInviteUserCount + mogRaceUserInfo.getInviteUserCount());
            log.info("处理之后的排名信息:{}",originalRanking);
            mogRaceUserInfoDao.updateUserRace(originalRanking);
        }
    }

    /**
     * 判断是否存在
     * @return
     */
    private MogRaceUserInfo queryExistByUser(Long userId) {
        ResultEntity<MogRaceUserInfo> mogRaceUserInfoResultEntity = mogRaceUserInfoDao.queryByUserId(userId);
        if (null == mogRaceUserInfoResultEntity || null == mogRaceUserInfoResultEntity.getBusinessObj()) {
            return null;
        }
        return mogRaceUserInfoResultEntity.getBusinessObj();
    }
}
