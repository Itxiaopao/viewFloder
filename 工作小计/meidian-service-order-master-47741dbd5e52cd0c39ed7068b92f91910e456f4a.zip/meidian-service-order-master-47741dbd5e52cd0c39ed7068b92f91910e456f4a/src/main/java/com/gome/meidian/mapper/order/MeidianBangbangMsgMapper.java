package com.gome.meidian.mapper.order;


import com.gome.meidian.vo.MeidianBangbangMsg;

public interface MeidianBangbangMsgMapper {

    int delete(Long id);

    int insert(MeidianBangbangMsg record);

    int update(MeidianBangbangMsg record);

    MeidianBangbangMsg selectByPrimaryKey(Long id);



}