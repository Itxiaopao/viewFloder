package com.gome.meidian.service.impl;

import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.gome.boot.adapter.config.aspect.annotation.Cacheable;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.dao.MeidianOrderDao;
import com.gome.meidian.entity.*;
import com.gome.meidian.enums.SearchOrderStatusEnum;
import com.gome.meidian.page.BasePageVo;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.util.CommUtils;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class NewOrderServiceImpl implements INewOrderService {

    /**
     * 订单biz
     */
    @Autowired
    private MeidianOrderDao meidianOrderDao;

    @Autowired
    private RedisLockUtils redisLockUtils;

    @Override
    @Cacheable(value = "获取我的GMV业绩", prefix = Constant.KEY_GRADES_STR_CACHE_PREFIX, suffix = {"#userId", "#dimension"}, seconds = 16)
    public ResultEntity<MyGradesVo> getMyGrades(Long userId, String dimension) {
        try {
            ReqOrderVo reqOrderVo = new ReqOrderVo();
            if ("1".equals(dimension)) {
                //今日
                reqOrderVo.setOrderStartTime(DateUtils.getCurrentDay());
                reqOrderVo.setOrderEndTime(DateUtils.getNextDay());
            } else if ("2".equals(dimension)) {
                //昨天
                reqOrderVo.setOrderStartTime(DateUtils.getYesterDay());
                reqOrderVo.setOrderEndTime(DateUtils.getCurrentDay());
            } else if ("3".equals(dimension)) {
                //本月
                reqOrderVo.setOrderStartTime(DateUtils.getCurrentMonth());
                reqOrderVo.setOrderEndTime(DateUtils.getNextMonth());
            }
            reqOrderVo.setUserIdRelation(Arrays.asList(userId));
            reqOrderVo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(SearchOrderStatusEnum.normal.getCode()));
            //订单数
            ResultEntity<Integer> orderNumResult = meidianOrderDao.queryTotalOrderPay(reqOrderVo);
            Long orderNum = orderNumResult.getBusinessObj() == null || orderNumResult.getBusinessObj() < 0 ? 0L : Long.valueOf(orderNumResult.getBusinessObj());
            //总价格
            ResultEntity<VitalOrderVo> sumResult = meidianOrderDao.querySumOrderPrice(reqOrderVo);
            Long sum = sumResult.getBusinessObj() == null || sumResult.getBusinessObj().getSumPriceTotal() == null || sumResult.getBusinessObj().getSumPriceTotal() < 0 ? 0L : sumResult.getBusinessObj().getSumPriceTotal();
            return new ResultEntity<>(new MyGradesVo(orderNum, sum));
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getMyGrades】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog(value = "获取订单列表", answer = false)
    public ResultEntity<Pagination<OrderInfo>> getOrderList(OrderListParam param) {
        if (param == null) {
            return new ResultEntity<>(402, "非空参数不能传递");
        }
        if (param.getUserId() == null) {
            return new ResultEntity<>(402, "美店主id不能为空");
        }

        if (param.getOrderStatus() != null && SearchOrderStatusEnum.notContains(param.getOrderStatus())) {
            return new ResultEntity<>(402, "未定义相应的订单状态");
        }

        if (param.getPageNo() == null) {
            param.setPageNo(1);
        }

        if (param.getPageSize() == null) {
            param.setPageSize(10);
        }

        if ("1".equals(param.getDateState())) {
            //昨日
            param.setStartDate(DateUtils.getYesterDay());
            param.setEndDate(DateUtils.getCurrentDay());
        } else if ("2".equals(param.getDateState())) {
            //今日
            param.setStartDate(DateUtils.getCurrentDay());
            param.setEndDate(DateUtils.getNextDay());
        } else if ("3".equals(param.getDateState())) {
            //本月
            param.setStartDate(DateUtils.getCurrentMonth());
            param.setEndDate(DateUtils.getNextMonth());
        }
        ReqOrderVo reqOrderVo = new ReqOrderVo();
        reqOrderVo.setUserIdPZ(param.getPid());
        if ("1".equals(param.getBizSource())) {
            //提奖订单
            reqOrderVo.setParentUserId(param.getUserId());
            reqOrderVo.setAwardFlag(Boolean.TRUE);
        } else {
            //业绩订单，销售订单根据美店主userid查询链条
            reqOrderVo.setUserIdRelation(Arrays.asList(param.getUserId()));
        }
        reqOrderVo.setOrderStartTime(param.getStartDate());
        reqOrderVo.setOrderEndTime(param.getEndDate());
        reqOrderVo.setOrderIdUserWeixin(param.getFilter());
        BasePageVo pageVo = new BasePageVo();
        pageVo.setPageNo(param.getPageNo());
        pageVo.setPageSize(param.getPageSize());
        reqOrderVo.setBasePageVo(pageVo);

        if (SearchOrderStatusEnum.normal.getCode().equals(param.getOrderStatus()) || SearchOrderStatusEnum.reverse.getCode().equals(param.getOrderStatus())) {
            //正反向订单状态隔离
            reqOrderVo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(param.getOrderStatus()));
        } else if (param.getOrderStatus() != null) {
            //精确订单搜索
            reqOrderVo.setShowStatusList(Arrays.asList(param.getOrderStatus()));
        }
        Pagination<OrderInfo> pagination = null;
        try {
            //mangodb 数据源
            ResultEntity<com.gome.meidian.page.Pagination<VitalOrderPay>> pageResult = meidianOrderDao.queryPageOrderNoPay(reqOrderVo);
            if (pageResult.getCode() == 0) {
                List<OrderInfo> list = new ArrayList<>();
                com.gome.meidian.page.Pagination<VitalOrderPay> pageInfo = pageResult.getBusinessObj();
                List<VitalOrderPay> vitalOrderPayList = pageInfo.getList();
                for (VitalOrderPay pay : vitalOrderPayList) {
                    Integer showStatus = pay.getMogOrderInfos().get(0).getShowStatus();
                    if (0 == showStatus) {
                        //待支付订单 以 orderId为维度
                        OrderInfo orderInfo = null;
                        Long orderAwardMoney = 0L;
                        Long orderCommMoney = 0L;
                        Long priceTotal = 0L;
                        List<SkuInfo> skuInfoList = new ArrayList<>();
                        for (MogOrderInfo mogOrderInfo : pay.getMogOrderInfos()) {
                            if (orderInfo == null) {
                                orderInfo = new OrderInfo();
                                orderInfo.setOrderId(mogOrderInfo.getOrderId());
                                orderInfo.setDeliveryId(mogOrderInfo.getDeliveryId());
                                orderInfo.setUserId(mogOrderInfo.getUserId());
                                orderInfo.setOrderTime(mogOrderInfo.getOrderTime());
                                orderInfo.setOrderStatus(mogOrderInfo.getOrderStatus());
                                orderInfo.setUserWeixin(mogOrderInfo.getUserWeixin());
                                orderInfo.setPhoneNo(mogOrderInfo.getPhoneNo());
                                orderInfo.setParentUserId(mogOrderInfo.getParentUserId());
                                orderInfo.setIsPickGoods(mogOrderInfo.getIsPickGoods());
                            }
                            SkuInfo skuInfo = new SkuInfo();
                            skuInfo.setCommerceId(mogOrderInfo.getCommerceId());
                            skuInfo.setItemId(mogOrderInfo.getItemId());
                            skuInfo.setSkuId(mogOrderInfo.getSkuId());
                            skuInfo.setSkuName(mogOrderInfo.getSkuName());
                            skuInfo.setUnitPrice(mogOrderInfo.getUnitPrice());
                            skuInfo.setBuyNum(mogOrderInfo.getBuyNum());
                            Long awardMoney = mogOrderInfo.getAwardMoney() == null ? 0L : mogOrderInfo.getAwardMoney();
                            Long commMoney = mogOrderInfo.getCommMoney() == null ? 0L : mogOrderInfo.getCommMoney();
                            skuInfo.setAwardMoney(awardMoney);
                            skuInfo.setCommMoney(commMoney);
                            //提奖
                            orderAwardMoney += awardMoney;
                            //佣金
                            orderCommMoney += commMoney;
                            //待支付状态实付金额
                            priceTotal += mogOrderInfo.getPriceTotal() == null ? 0L : mogOrderInfo.getPriceTotal();
                            skuInfoList.add(skuInfo);
                        }
                        orderInfo.setSkuInfoList(skuInfoList);
                        orderInfo.setPriceTotal(priceTotal);
                        orderInfo.setOrderAwardMoney(orderAwardMoney);
                        orderInfo.setOrderCommMoney(orderCommMoney);
                        list.add(orderInfo);
                    } else {
                        //拆单后以配送单号为维度
                        OrderInfo orderInfo = null;
                        Map<String, OrderInfo> map = new HashMap<>();
                        for (MogOrderInfo model : pay.getMogOrderInfos()) {
                            List<SkuInfo> skuInfoList = new ArrayList<>();
                            if (map.containsKey(model.getDeliveryId())) {
                                orderInfo = map.get(model.getDeliveryId());
                                SkuInfo skuInfo = new SkuInfo();
                                skuInfo.setCommerceId(model.getCommerceId());
                                skuInfo.setItemId(model.getItemId());
                                skuInfo.setSkuId(model.getSkuId());
                                skuInfo.setSkuName(model.getSkuName());
                                skuInfo.setUnitPrice(model.getUnitPrice());
                                skuInfo.setBuyNum(model.getBuyNum());

                                Long awardMoney = model.getAwardMoney() == null ? 0L : model.getAwardMoney();
                                Long commMoney = model.getCommMoney() == null ? 0L : model.getCommMoney();
                                skuInfo.setAwardMoney(awardMoney);
                                skuInfo.setCommMoney(commMoney);
                                orderInfo.setOrderCommMoney(orderInfo.getOrderCommMoney() + commMoney);
                                orderInfo.setOrderAwardMoney(orderInfo.getOrderAwardMoney() + awardMoney);
                                orderInfo.setPriceTotal(orderInfo.getPriceTotal() + (model.getPriceTotal() == null ? 0L : model.getPriceTotal()));

                                orderInfo.getSkuInfoList().add(skuInfo);
                                map.put(model.getDeliveryId(), orderInfo);
                            } else {
                                //订单信息
                                orderInfo = new OrderInfo();
                                orderInfo.setOrderId(model.getOrderId());
                                orderInfo.setDeliveryId(model.getDeliveryId());
                                orderInfo.setUserId(model.getUserId());
                                orderInfo.setOrderTime(model.getOrderTime());
                                orderInfo.setOrderStatus(model.getOrderStatus());
                                orderInfo.setUserWeixin(model.getUserWeixin());
                                orderInfo.setPhoneNo(model.getPhoneNo());
                                orderInfo.setParentUserId(model.getParentUserId());
                                orderInfo.setIsPickGoods(model.getIsPickGoods());

                                //商品信息
                                SkuInfo skuInfo = new SkuInfo();
                                skuInfo.setCommerceId(model.getCommerceId());
                                skuInfo.setItemId(model.getItemId());
                                skuInfo.setSkuId(model.getSkuId());
                                skuInfo.setSkuName(model.getSkuName());
                                skuInfo.setUnitPrice(model.getUnitPrice());
                                skuInfo.setBuyNum(model.getBuyNum());
                                Long awardMoney = model.getAwardMoney() == null ? 0L : model.getAwardMoney();
                                Long commMoney = model.getCommMoney() == null ? 0L : model.getCommMoney();
                                skuInfo.setAwardMoney(awardMoney);
                                skuInfo.setCommMoney(commMoney);
                                skuInfoList.add(skuInfo);
                                orderInfo.setSkuInfoList(skuInfoList);
                                //待支付状态实付金额
                                orderInfo.setPriceTotal(model.getPriceTotal() == null ? 0L : model.getPriceTotal());
                                //提奖
                                orderInfo.setOrderAwardMoney(awardMoney);
                                //佣金
                                orderInfo.setOrderCommMoney(commMoney);
                                map.put(model.getDeliveryId(), orderInfo);

                            }

                        }
                        for (String key : map.keySet()) {
                            list.add(map.get(key));
                        }
                    }
                }

                pagination = new Pagination<>(pageInfo.getPageNo(), pageInfo.getTotalCount(), pageInfo.getPageSize());
                pagination.setList(list);
            }
            return new ResultEntity<>(pagination);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getOrderList】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }

    }

    @Override
    @SneakyLog("获取业绩订单累计销售额")
    public ResultEntity<Long> getAccumSales(OrderListParam param) {
        if (param == null) {
            return new ResultEntity<>(402, "非空参数不能传递");
        }
        if (param.getUserId() == null) {
            return new ResultEntity<>(402, "美店主id不能为空");
        }
        if (param.getOrderStatus() != null && SearchOrderStatusEnum.notContains(param.getOrderStatus())) {
            return new ResultEntity<>(402, "未定义相应的订单状态");
        }

        if ("1".equals(param.getDateState())) {
            //昨日
            param.setStartDate(DateUtils.getYesterDay());
            param.setEndDate(DateUtils.getCurrentDay());
        } else if ("2".equals(param.getDateState())) {
            //今日
            param.setStartDate(DateUtils.getCurrentDay());
            param.setEndDate(DateUtils.getNextDay());
        } else if ("3".equals(param.getDateState())) {
            //本月
            param.setStartDate(DateUtils.getCurrentMonth());
            param.setEndDate(DateUtils.getNextMonth());
        }

        ReqOrderVo reqOrderVo = new ReqOrderVo();
        reqOrderVo.setUserIdPZ(param.getPid());
        if ("1".equals(param.getBizSource())) {
            //提奖订单
            reqOrderVo.setParentUserId(param.getUserId());
        } else {
            //业绩订单，销售订单根据美店主userid查询链条
            reqOrderVo.setUserIdRelation(Arrays.asList(param.getUserId()));
        }
        reqOrderVo.setOrderStartTime(param.getStartDate());
        reqOrderVo.setOrderEndTime(param.getEndDate());
        reqOrderVo.setOrderIdUserWeixin(param.getFilter());
        reqOrderVo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(SearchOrderStatusEnum.normal.getCode()));
        try {
            ResultEntity<VitalOrderVo> result = meidianOrderDao.querySumOrderPrice(reqOrderVo);
            VitalOrderVo businessObj = result.getBusinessObj();
            return new ResultEntity<>(businessObj.getSumPriceTotal() == null ? 0 : businessObj.getSumPriceTotal());
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getAccumSales】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog(value = "获取用户订单列表", answer = false)
    public ResultEntity<Pagination<OrderInfo>> getUserOrderList(Long userId, String dateType, Integer pageNo, Integer pageSize) {
        if (userId == null) {
            return new ResultEntity<>(402, "用户id不能为空");
        }
        if (pageNo == null) {
            pageNo = 1;
        }

        if (pageSize == null) {
            pageSize = 10;
        }
        ReqOrderVo reqOrderVo = new ReqOrderVo();
        if ("1".equals(dateType)) {
            //昨日
            reqOrderVo.setOrderStartTime(DateUtils.getYesterDay());
            reqOrderVo.setOrderEndTime(DateUtils.getCurrentDay());
        } else if ("2".equals(dateType)) {
            //今日
            reqOrderVo.setOrderStartTime(DateUtils.getCurrentDay());
            reqOrderVo.setOrderEndTime(DateUtils.getNextDay());
        } else if ("3".equals(dateType)) {
            //本月
            reqOrderVo.setOrderStartTime(DateUtils.getCurrentMonth());
            reqOrderVo.setOrderEndTime(DateUtils.getNextMonth());
        }

        reqOrderVo.setUserId(userId);
        //订单列表展示除了待支付状态的订单
        List<Integer> searchOrderStatusList = Arrays.asList(SearchOrderStatusEnum.payed.getCode(),
                SearchOrderStatusEnum.waitReceivDeliver.getCode(), SearchOrderStatusEnum.effect.getCode(),
                SearchOrderStatusEnum.cancel.getCode(), SearchOrderStatusEnum.afterSale.getCode());
        reqOrderVo.setShowStatusList(searchOrderStatusList);
        BasePageVo pageVo = new BasePageVo();
        pageVo.setPageNo(pageNo);
        pageVo.setPageSize(pageSize);
        reqOrderVo.setBasePageVo(pageVo);
        Pagination<OrderInfo> pagination = null;
        try {
            //mangodb 数据源
            ResultEntity<com.gome.meidian.page.Pagination<VitalOrderPay>> paginationResultEntity = meidianOrderDao.queryPageOrderNoPay(reqOrderVo);
            if (paginationResultEntity.getCode() == 0) {
                List<OrderInfo> list = new ArrayList<>();
                com.gome.meidian.page.Pagination<VitalOrderPay> pageInfo = paginationResultEntity.getBusinessObj();
                List<VitalOrderPay> vitalOrderPayList = pageInfo.getList();
                for (VitalOrderPay pay : vitalOrderPayList) {
                    //拆单后以配送单号为维度
                    OrderInfo orderInfo = null;
                    Map<String, OrderInfo> map = new HashMap<>();
                    for (MogOrderInfo model : pay.getMogOrderInfos()) {
                        List<SkuInfo> skuInfoList = new ArrayList<>();
                        if (map.containsKey(model.getDeliveryId())) {
                            orderInfo = map.get(model.getDeliveryId());
                            SkuInfo skuInfo = new SkuInfo();
                            skuInfo.setCommerceId(model.getCommerceId());
                            skuInfo.setItemId(model.getItemId());
                            skuInfo.setSkuId(model.getSkuId());
                            skuInfo.setSkuName(model.getSkuName());
                            skuInfo.setUnitPrice(model.getUnitPrice());
                            skuInfo.setBuyNum(model.getBuyNum());

                            Long awardMoney = model.getAwardMoney() == null ? 0L : model.getAwardMoney();
                            Long commMoney = model.getCommMoney() == null ? 0L : model.getCommMoney();
                            skuInfo.setAwardMoney(awardMoney);
                            skuInfo.setCommMoney(commMoney);
                            orderInfo.setOrderCommMoney(orderInfo.getOrderCommMoney() + commMoney);
                            orderInfo.setOrderAwardMoney(orderInfo.getOrderAwardMoney() + awardMoney);
                            orderInfo.setPriceTotal(orderInfo.getPriceTotal() + (model.getPriceTotal() == null ? 0L : model.getPriceTotal()));

                            orderInfo.getSkuInfoList().add(skuInfo);
                            map.put(model.getDeliveryId(), orderInfo);
                        } else {
                            //订单信息

                            orderInfo = new OrderInfo();
                            orderInfo.setOrderId(model.getOrderId());
                            orderInfo.setDeliveryId(model.getDeliveryId());
                            orderInfo.setUserId(model.getUserId());
                            orderInfo.setOrderTime(model.getOrderTime());
                            orderInfo.setOrderStatus(model.getOrderStatus());
                            orderInfo.setUserWeixin(model.getUserWeixin());
                            orderInfo.setPhoneNo(model.getPhoneNo());
                            orderInfo.setParentUserId(model.getParentUserId());

                            //商品信息
                            SkuInfo skuInfo = new SkuInfo();
                            skuInfo.setCommerceId(model.getCommerceId());
                            skuInfo.setItemId(model.getItemId());
                            skuInfo.setSkuId(model.getSkuId());
                            skuInfo.setSkuName(model.getSkuName());
                            skuInfo.setUnitPrice(model.getUnitPrice());
                            skuInfo.setBuyNum(model.getBuyNum());
                            Long awardMoney = model.getAwardMoney() == null ? 0L : model.getAwardMoney();
                            Long commMoney = model.getCommMoney() == null ? 0L : model.getCommMoney();
                            skuInfo.setAwardMoney(awardMoney);
                            skuInfo.setCommMoney(commMoney);
                            skuInfoList.add(skuInfo);
                            orderInfo.setSkuInfoList(skuInfoList);

                            //待支付状态实付金额
                            orderInfo.setPriceTotal(model.getPriceTotal() == null ? 0L : model.getPriceTotal());
                            //提奖
                            orderInfo.setOrderAwardMoney(awardMoney);
                            //佣金
                            orderInfo.setOrderCommMoney(commMoney);
                            map.put(model.getDeliveryId(), orderInfo);

                        }

                    }
                    for (String key : map.keySet()) {
                        list.add(map.get(key));
                    }

                }
                pagination = new Pagination<>(pageInfo.getPageNo(), pageInfo.getTotalCount(), pageInfo.getPageSize());
                pagination.setList(list);
            }
            return new ResultEntity<>(pagination);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getUserOrderList】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("获取用户的订单数量和销售总额")
    public ResultEntity<MyGradesVo> getUserAccumAmount(Long userId, String dateType) {
        if (userId == null) {
            return new ResultEntity<>(402, "用户id不能为空");
        }

        try {
            ReqOrderVo vo = new ReqOrderVo();
            if ("1".equals(dateType)) {
                //昨日
                vo.setOrderStartTime(DateUtils.getYesterDay());
                vo.setOrderEndTime(DateUtils.getCurrentDay());
            } else if ("2".equals(dateType)) {
                //今日
                vo.setOrderStartTime(DateUtils.getCurrentDay());
                vo.setOrderEndTime(DateUtils.getNextDay());
            } else if ("3".equals(dateType)) {
                //本月
                vo.setOrderStartTime(DateUtils.getCurrentMonth());
                vo.setOrderEndTime(DateUtils.getNextMonth());
            }
            vo.setUserId(userId);
            //统计展示正向单
            vo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(SearchOrderStatusEnum.normal.getCode()));
            //获取订单数量和销售总额
            ResultEntity<VitalOrderVo> resultEntity = meidianOrderDao.querySumOrderPrice(vo);
            VitalOrderVo businessObj = resultEntity.getBusinessObj();
            MyGradesVo result = new MyGradesVo();
            result.setOrderNums(businessObj.getCountOrderNum() == null ? 0 : businessObj.getCountOrderNum());
            result.setOrderGmv(businessObj.getSumPriceTotal() == null ? 0 : businessObj.getSumPriceTotal());
            return new ResultEntity<>(result);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getUserAccumAmount】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("根据片总userId获取累计提奖总额")
    public ResultEntity<Long> getAwardTotalMoney(Long pid, Integer state, Date startDate, Date endDate) {
        if (pid == null) {
            return new ResultEntity<>(402, "片总id不能为空");
        }
        if (900 != state && 901 != state) {
            return new ResultEntity<>(402, "未定义相应的订单状态");
        }
        ReqOrderVo vo = new ReqOrderVo();
        vo.setUserIdPZ(pid);
        vo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(state));
        vo.setOrderStartTime(startDate);
        vo.setOrderEndTime(endDate);
        try {
            ResultEntity<VitalOrderVo> resultEntity = meidianOrderDao.querySumOrderPrice(vo);
            VitalOrderVo businessObj = resultEntity.getBusinessObj();
            return new ResultEntity<>(businessObj.getSumAwardMoney() == null ? 0 : businessObj.getSumAwardMoney());
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getAwardTotalMoney】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("根据片总用户id获取片总提奖金额")
    public ResultEntity<AwardVo> getMyAward(Long pid, Integer state, Date startDate, Date endDate) {
        if (pid == null) {
            return new ResultEntity<>(402, "片总id不能为空");
        }
        if (900 != state && 901 != state) {
            return new ResultEntity<>(402, "未定义相应的订单状态");
        }
        ReqOrderVo vo = new ReqOrderVo();
        vo.setUserIdPZ(pid);
        vo.setParentUserId(pid);
        vo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(state));
        vo.setOrderStartTime(startDate);
        vo.setOrderEndTime(endDate);
        try {
            //获取片总直属
            ResultEntity<VitalOrderVo> resultEntity = meidianOrderDao.querySumOrderPrice(vo);
            VitalOrderVo businessObj = resultEntity.getBusinessObj();
            AwardVo result = new AwardVo();
            result.setUserId(pid);
            result.setAward(businessObj.getSumAwardMoney() == null ? 0 : businessObj.getSumAwardMoney());
            result.setSaleAmount(businessObj.getSumPriceTotal() == null ? 0 : businessObj.getSumPriceTotal());
            return new ResultEntity<>(result);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getMyAward】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("根据片总用户id获取美店主提奖总金额")
    public ResultEntity<Pagination<AwardVo>> getMasAward(Long pid, Integer state, Date startDate, Date endDate, Integer pageNo, Integer pageSize) {
        ReqOrderVo reqOrderVo = new ReqOrderVo();
        reqOrderVo.setUserIdPZ(pid);
        reqOrderVo.setParentOutUserId(pid);
        reqOrderVo.setShowStatusList(SearchOrderStatusEnum.bizIsolate(state));
        reqOrderVo.setOrderStartTime(startDate);
        reqOrderVo.setOrderEndTime(endDate);
        BasePageVo pageVo = new BasePageVo();
        pageVo.setPageNo(pageNo);
        pageVo.setPageSize(pageSize);
        reqOrderVo.setBasePageVo(pageVo);
        try {
            ResultEntity<com.gome.meidian.page.Pagination<VitalOrderVo>> resultEntity = meidianOrderDao.queryPageGroupSumOrderPrice(reqOrderVo);
            Pagination<AwardVo> pagination = null;
            if (resultEntity.getCode() == 0) {
                com.gome.meidian.page.Pagination<VitalOrderVo> pageInfo = resultEntity.getBusinessObj();
                List<AwardVo> list = new ArrayList<>();
                List<VitalOrderVo> mogOrderInfoList = pageInfo.getList();
                for (VitalOrderVo model : mogOrderInfoList) {
                    AwardVo awardVo = new AwardVo();
                    awardVo.setUserId(model.getId());
                    awardVo.setAward(model.getSumAwardMoney() == null ? 0 : model.getSumAwardMoney());
                    awardVo.setSaleAmount(model.getSumPriceTotal() == null ? 0 : model.getSumPriceTotal());
                    list.add(awardVo);
                }
                pagination = new Pagination<>(pageInfo.getPageNo(), pageInfo.getTotalCount(), pageInfo.getPageSize());
                pagination.setList(list);
            }
            return new ResultEntity<>(pagination);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.NewOrderServiceImpl.getMasAward】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }

    }

    @SneakyLog("获取订单基础信息")
    @Override
    public ResultEntity<OrderInfo> getOrderInfo(Long orderId) {
        if (orderId == null) {
            return new ResultEntity<>(400, "订单id不能为空");
        }
        ReqOrderVo reqOrderVo = new ReqOrderVo();
        reqOrderVo.setOrderId(orderId);
        try {
            ResultEntity<List<MogOrderInfo>> result = meidianOrderDao.queryOrderList(reqOrderVo);
            List<MogOrderInfo> businessObj = result.getBusinessObj();
            if (CollectionUtils.isNotEmpty(businessObj)) {
                MogOrderInfo mogOrderInfo = businessObj.get(0);
                OrderInfo orderInfo = new OrderInfo();
                orderInfo.setOrderId(mogOrderInfo.getOrderId());
                orderInfo.setUserId(mogOrderInfo.getUserId());
                orderInfo.setOrderTime(mogOrderInfo.getOrderTime());
                orderInfo.setOrderStatus(mogOrderInfo.getOrderStatus());
                orderInfo.setPriceTotal(mogOrderInfo.getPriceTotal());
                orderInfo.setUserWeixin(mogOrderInfo.getUserWeixin());
                orderInfo.setOrderAwardMoney(mogOrderInfo.getAwardMoney());
                orderInfo.setOrderCommMoney(mogOrderInfo.getCommMoney());
                orderInfo.setPhoneNo(mogOrderInfo.getPhoneNo());
                orderInfo.setUserIdRelation(mogOrderInfo.getUserIdRelation());
                return new ResultEntity<>(orderInfo);
            } else {
                return new ResultEntity<>(400, "查询不到该订单信息");
            }
        } catch (Exception e) {
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    @Override
    @SneakyLog("百货店主确认提货")
    public ResultEntity<Boolean> savePickGoods(String deliveryId, Long parentUserId, Integer isPickGoods) {
        if (StringUtils.isBlank(deliveryId)) {
            return new ResultEntity<>(400, "配送单id不允许为空");
        }
        if (parentUserId == null) {
            return new ResultEntity<>(400, "上级用户id不允许为空");
        }
        if (!Arrays.asList(NumberUtils.INTEGER_ZERO, NumberUtils.INTEGER_ONE).contains(isPickGoods)) {
            return new ResultEntity<>(400, "是否提货标识枚举越界");
        }
        //防重复提交
        String repeatKey = CommUtils.getRedisKey(Constant.ORDER_CONFIRM_PICK_GOODS_INCR_CACHE_PREFIX, deliveryId, parentUserId);
        boolean resubmitLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(repeatKey);
            if (!resubmitLock) {
                log.info("百货店主确认提货正在执行中,请勿重复提交");
                return new ResultEntity<>(403, "百货店主确认提货正在执行中,请勿重复提交");
            }
            return meidianOrderDao.savePickGoods(deliveryId, parentUserId, isPickGoods);
        } catch (Exception e) {
            log.error("百货店主确认提货,发生异常,入参 deliveryId:{},parentUserId:{},异常堆栈如下", deliveryId, parentUserId, e);
            return new ResultEntity<>(500, "系统内部异常");
        } finally {
            redisLockUtils.unlock(resubmitLock, repeatKey);
        }

    }

}
