package com.gome.meidian.enums;

public enum UserType {

    NewCustom(1, "新客"),
    Visitor(2, "游客"),
    FirstOrder(4, "首单"),
    Fans(5, "忠粉");

    private Integer type;

    private String name;

    private UserType(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public String getName() {
        return name;
    }

}
