package com.gome.meidian.util;

import org.apache.commons.lang3.ObjectUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author yuliang-ds1
 * @Date 2018/8/15 19:29
 * @Description
 */
public class DateUtils {

    //日期格式化格式
    public static final String  DATE_FORMAT="yyyy-MM-dd";
    //每天开始时间
    public static final String  DATE_START_TIME=" 00:00:00";
    //每天结束时间
    public static final String  DATE_END_TIME=" 23:59:59";

    /**
     * 获取当天开始时间
     * @return
     */
    public static Date getCurrentStartTime() {
        Calendar todayStart = Calendar.getInstance();
        todayStart.set(Calendar.HOUR, 0);
        todayStart.set(Calendar.MINUTE, 0);
        todayStart.set(Calendar.SECOND, 0);
        todayStart.set(Calendar.MILLISECOND, 0);
        return todayStart.getTime();
    }

    /**
     * 获取当天时间结束时间
     * @return
     */
    public static Date getCurrentEndTime() {
        Calendar todayEnd = Calendar.getInstance();
        todayEnd.set(Calendar.HOUR, 23);
        todayEnd.set(Calendar.MINUTE, 59);
        todayEnd.set(Calendar.SECOND, 59);
        todayEnd.set(Calendar.MILLISECOND, 999);
        return todayEnd.getTime();
    }


    /**
     * 获取昨天时间 根据传入变量取开始或结束
     * @param  append  DATE_START_TIME开始时间   DATE_END_TIME结束时间
     * @return
     */
    public static String getYesterdayTimeBySelect(String append){
        //当前时间
        Date dNow = new Date();
        Date dBefore = new Date();
        //得到日历
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(dNow);//把当前时间赋给日历
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        //设置为前一天
        dBefore = calendar.getTime();
        //得到前一天的时间
        SimpleDateFormat sdf=new SimpleDateFormat(DATE_FORMAT);
        //设置时间格式
        String defaultStartDate = sdf.format(dBefore);
        //格式化前一天
        StringBuilder sb=new StringBuilder(defaultStartDate);
        sb.append(append);
        return sb.toString();
    }

    /**
	 * @Fields DEFAULT_PATTERN:默认格式 yyyyMMddHHmmss
	 */
	@SuppressWarnings("unused")
	private final static String DEFAULT_PATTERN = "yyyyMMddHHmmssSSS";

	/**
	 * @Title: getNowDate
	 * @return
	 * @Description: 获取当前时间
	 */
	public static Date getNowDate() {
		return Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * @Title: getNowLocalDate
	 * @return
	 * @Description: 获取当前时间
	 */
	public static LocalDateTime getNowLocalDate() {
		return LocalDateTime.now();
	}

	/**
	 * @Title: convertDate
	 * @param localDateTime
	 * @return
	 * @Description: LocalDateTime 转换为 Date
	 */
	public static Date convert2Date(LocalDateTime localDateTime) {
		return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * @Title: convert2LocalDateTime
	 * @param date
	 * @return
	 * @Description: Date 转换为 LocalDateTime
	 */
	public static LocalDateTime convert2LocalDateTime(Date date) {
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}

	/**
	 * @Title: plusMintius
	 * @param date
	 * @param minutes
	 * @return
	 * @Description: 当前时间 新增分钟数
	 */
	public static Date plusMintius(Date date, Long minutes) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusMinutes(minutes));
	}

	/**
	 * @Title: plusHours
	 * @param date
	 * @param hours
	 * @return
	 * @Description: 新增小时
	 */
	public static Date plusHours(Date date, Long hours) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusHours(hours));
	}

	/**
	 * @Title: plusDays
	 * @param date
	 * @param days
	 * @return
	 * @Description: 新增天数
	 */
	public static Date plusDays(Date date, Long days) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusDays(days));
	}

	/**
	 * @Title: plusMonths
	 * @param date
	 * @param months
	 * @return
	 * @Description: 新增月份
	 */
	public static Date plusMonths(Date date, Long months) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(plusMonth(date, months));
	}

	public static LocalDateTime plusMonth(Date date, Long months) {
		return convert2LocalDateTime(date).plusMonths(months);
	}

	/**
	 * @Title: plusYear
	 * @param date
	 * @param years
	 * @return
	 * @Description: 新增年
	 */
	public static Date plusYear(Date date, Long years) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).plusYears(years));
	}

	/**
	 * @Title: minusMinutes
	 * @param date
	 * @param minutes
	 * @return
	 * @Description: 减去分钟数
	 */
	public static Date minusMinutes(Date date, Long minutes) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusMinutes(minutes));
	}

	/**
	 * @Title: minusHours
	 * @param date
	 * @param hours
	 * @return
	 * @Description: 减去小时
	 */
	public static Date minusHours(Date date, Long hours) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusHours(hours));
	}

	/**
	 * @Title: minusDays
	 * @param date
	 * @param days
	 * @return
	 * @Description: 减去天数
	 */
	public static Date minusDays(Date date, Long days) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusDays(days));
	}

	/**
	 * @Title: minusMonths
	 * @param date
	 * @param months
	 * @return
	 * @Description: 减去月份
	 */
	public static Date minusMonths(Date date, Long months) {
		if (null == date) {
			date = getNowDate();
		}
		return convert2Date(convert2LocalDateTime(date).minusMonths(months));
	}


	/**
	 * @Title: formate
	 * @param strDate
	 * @param pattern
	 * @return
	 * @Description: 解析字符串为时间类型
	 */
	public static Date formate(String strDate, String pattern) {
		return convert2Date(LocalDateTime.parse(strDate, DateTimeFormatter.ofPattern(pattern)));
	}

	/**
	 * @Title: checkDate
	 * @param startDate
	 * @param endDate
	 * @return
	 * @Description: 校验当前时间是否在 开始 和结束时间之间
	 */
	public static boolean checkDate(Date startDate, Date endDate) {
		return getNowLocalDate().isBefore(convert2LocalDateTime(endDate))
				&& getNowLocalDate().isAfter(convert2LocalDateTime(startDate));
	}
	/** 
	 * @Title: betweenNowWith 
	 * @param date
	 * @return
	 * @Description: 返回传入时间与当前时间的时间差 单位 秒 传入时间当前日期之后
	 */ 
	public static Long betweenNowWith(Date date) {
		return ChronoUnit.SECONDS.between(getNowLocalDate(), convert2LocalDateTime(date));
	}
	
	/** 
	 * @Title: betweenDate 
	 * @param date
	 * @return
	 * @Description: 返回传入时间与当前时间的时间差 单位 秒 传入时间当前日期之前
	 */ 
	public static Long betweenDate(Date date) {
		return ChronoUnit.SECONDS.between(convert2LocalDateTime(date),getNowLocalDate());
	}
	
	/**
	 * 获取当前时间戳
	 * @return
	 */
	public static long currentTimeSecs() {
		return System.currentTimeMillis();
	}
	
	/**
	 * 时间戳转date
	 * @param timestamp
	 * @return
	 */
	public static Date transDateForNum(long timestamp) {
		SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //设置格式
		String timeStr = sdf.format(timestamp);
		try {
			return sdf.parse(timeStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * date格式化
	 * @param timestamp
	 * @return
	 */
	public static String transStrForDate(Date date) {
		SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //设置格式
		return sdf.format(date);
	}

	/**
	 * 字符串转Date
	 * @param dateStr
	 * @return
	 */
	public static Date transStrToDate(String dateStr) {
		SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //设置格式
		Date date = null;
		try {
			date = sdf.parse(dateStr);
		}catch (Exception e){
			e.printStackTrace();
		}
		return date;
	}
	/**
	 * 获取昨天
	 * @return
	 */
	public static Date getYesterDay() {
		Calendar yesterDay=Calendar.getInstance();
		yesterDay.add(Calendar.DATE,-1);
		yesterDay.set(Calendar.HOUR_OF_DAY, 0);// 时
		yesterDay.set(Calendar.MINUTE, 0); // 分
		yesterDay.set(Calendar.SECOND, 0);// 秒
		yesterDay.set(Calendar.MILLISECOND, 0);// 秒
		return yesterDay.getTime();
	}

	/**
	 * 获取明天
	 * @return
	 */
	public static Date getNextDay() {
		Calendar yesterDay=Calendar.getInstance();
		yesterDay.add(Calendar.DATE,1);
		yesterDay.set(Calendar.HOUR_OF_DAY, 0);// 时
		yesterDay.set(Calendar.MINUTE, 0); // 分
		yesterDay.set(Calendar.SECOND, 0);// 秒
		yesterDay.set(Calendar.MILLISECOND, 0);// 秒
		return yesterDay.getTime();
	}

	/**
	 * 获取当月第一天
	 * @return
	 */
	public static Date getCurrentMonth() {
		Calendar sameMonth = Calendar.getInstance();
		sameMonth.add(Calendar.MONTH, 0);
		sameMonth.set(Calendar.DAY_OF_MONTH,1);
		sameMonth.set(Calendar.HOUR_OF_DAY, 0);// 时
		sameMonth.set(Calendar.MINUTE, 0); // 分
		sameMonth.set(Calendar.SECOND, 0);// 秒
		sameMonth.set(Calendar.MILLISECOND, 0);// 秒
		return sameMonth.getTime();
	}

	/**
	 * 获取下个月第一天
	 * @return
	 */
	public static Date getNextMonth() {
		Calendar nextMonth = Calendar.getInstance();
		nextMonth.add(Calendar.MONTH, 1);
		nextMonth.set(Calendar.DAY_OF_MONTH,1);
		nextMonth.set(Calendar.HOUR_OF_DAY, 0);// 时
		nextMonth.set(Calendar.MINUTE, 0); // 分
		nextMonth.set(Calendar.SECOND, 0);// 秒
		nextMonth.set(Calendar.MILLISECOND, 0);// 秒
		return nextMonth.getTime();
	}

	public static Date getCurrentDay() {
		Calendar todayStart = Calendar.getInstance();
		todayStart.set(Calendar.HOUR_OF_DAY, 0);// 时
		todayStart.set(Calendar.MINUTE, 0);
		todayStart.set(Calendar.SECOND, 0);
		todayStart.set(Calendar.MILLISECOND, 0);
		return todayStart.getTime();
	}
	
	//获取上月10号的日期
	public static Date getUpMonthTime() {
		Calendar month = Calendar.getInstance();
		month.add(Calendar.MONTH, -1);
		month.set(Calendar.DAY_OF_MONTH,10);
		month.set(Calendar.HOUR_OF_DAY, 0);// 时
		month.set(Calendar.MINUTE, 0); // 分
		month.set(Calendar.SECOND, 0);// 秒
		month.set(Calendar.MILLISECOND, 0);// 秒
		return month.getTime();
	}

	/**
	 * 获取指定时间
	 * @param date 指定的时间
	 * @param param 入参
	 * @return
	 */
	public static Date getSpecifiedDay(Date date, Map<Integer,Integer> param) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DATE, ObjectUtils.defaultIfNull(param.get(Calendar.DATE), 0));
		calendar.set(Calendar.HOUR_OF_DAY, ObjectUtils.defaultIfNull(param.get(Calendar.HOUR_OF_DAY), 0));// 时
		calendar.set(Calendar.MINUTE, ObjectUtils.defaultIfNull(param.get(Calendar.MINUTE), 0)); // 分
		calendar.set(Calendar.SECOND, ObjectUtils.defaultIfNull(param.get(Calendar.SECOND), 0));// 秒
		calendar.set(Calendar.MILLISECOND, ObjectUtils.defaultIfNull(param.get(Calendar.MILLISECOND), 0));// 秒
		return calendar.getTime();
	}

	/**
	 * 判断两个日期相隔多少天
	 * @param startDate 开始时间
	 * @param endDate 结束时间
	 * @return
	 */
	public static int daysApart(Date startDate, Date endDate) {
		if (startDate == endDate || convert2LocalDateTime(startDate).toLocalDate().equals(convert2LocalDateTime(endDate).toLocalDate())) {
			return 0;
		}
		Map<Integer,Integer> param = new HashMap<>();
		param.put(Calendar.DATE,1);
		Date current = getSpecifiedDay(startDate,param);
		int count = 1;
		while (current.getTime() < endDate.getTime()) {
			count++;
			current = plusDays(current, 1L);
		}
		return count;
	}
}
