package com.gome.meidian.enums;

/**
 * 美店订单显示状态
 */
public enum OrderShowStatus {

    Wait_Pay(0, "待支付"),
    Payed(1, "已支付"),
    Wait_Received(2, "待收货"),
    Canced(4, "已取消"),
    Effect(5, "订单妥投"),
    After_Sale(6, "售后");

    private Integer status;

    private String statusName;

    private OrderShowStatus(Integer status, String statusName) {
        this.status = status;
        this.statusName = statusName;
    }

    public Integer getStatus() {
        return status;
    }

    public String getStatusName() {
        return statusName;
    }
}
