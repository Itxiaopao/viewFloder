package com.gome.meidian.service.impl;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.gome.boot.adapter.config.aspect.annotation.Cacheable;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.dragon.mds.client.dto.gcc.GomeStoreFull;
import com.gome.dragon.mds.client.gcc.GomeStoreFullClient;
import com.gome.meidian.config.GCacheConfig;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.CouponVo;
import com.gome.meidian.entity.EmployeeInfo;
import com.gome.meidian.entity.IcSmDqlStaff;
import com.gome.meidian.entity.IcSmHlwlStaff;
import com.gome.meidian.entity.OrderShopSame;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.StaffInfo;
import com.gome.meidian.mapper.bigData.IcSmDqlStaffMapper;
import com.gome.meidian.mapper.bigData.IcSmHlwlStaffMapper;
import com.gome.meidian.mapper.order.OrderShopMapper;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.service.biz.DiamondBiz;
import com.gome.meidian.service.biz.EmployeeBiz;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import lombok.extern.slf4j.Slf4j;
import redis.Gcache;

/**
 * 订单收单
 *
 * @author zhangwei-ds19
 * 业务层
 */
@Slf4j
@Service("orderShopServiceImpl")
public class OrderShopServiceImpl implements IOrderShopService {

    public static final String STAFF_INFO_PREFIX = "getStaffInfoByUserId.staffInfo_";
    @Autowired
    private IcSmDqlStaffMapper icSmDqlStaffMapper;
    @Autowired
    private IcSmHlwlStaffMapper icSmHlwlStaffMapper;
    @Autowired
    private OrderShopMapper orderShopMapper;
    @Autowired
    private GCacheConfig gCacheConfig;
    @Autowired
    private GomeStoreFullClient gomeStoreFullClient;
    @Autowired
    private IUserShareBindingManager userShareBindingManager;
    @Autowired
    private EmployeeBiz employeeBiz;
    @Autowired
    private DiamondBiz diamondBiz;
    @Autowired
    private Gcache gcache;


    /**
     * 插入接口 （查询，修改接口） 返回：List<OrderShop>
     */
    @Override
    public int queryOrderCount(OrderShopSame orderShopSame) {
        try {
            if (NumberUtils.isNullOrZero(orderShopSame.getShopId())) {
                return 0;
            }
            int list = orderShopMapper.selectByDateRange(orderShopSame.getShopId());
            if (list > 0) {
                // 进行修改
                orderShopSame.setUtime(new Date());
                return orderShopMapper.updateOrder(orderShopSame);
            } else {
                // 进行添加
                return orderShopMapper.insertOrder(orderShopSame);
            }
        } catch (Exception ex) {
            log.error("插入或者保存用户数据异常", ex);
            return 0;
        }
    }


    /**
     * 员工id获取员工信息
     *
     * @param userId
     * @return
     */
    @Override
//    @Cacheable(value = "通过员工ID获取员工信息", prefix = STAFF_INFO_PREFIX, suffix = {"#userId"}, seconds = 3600)
    public ResultEntity<StaffInfo> getStaffInfoByUserId(Long userId) {
        if (userId == null) {
            return new ResultEntity(1, "员工Id为空", null);
        }

        String staffInfoString = gcache.get(STAFF_INFO_PREFIX + userId);
        StaffInfo staffInfo2 = JSON.parseObject(staffInfoString, new TypeReference<StaffInfo>() {
        });
        if (staffInfo2 != null) {
            return new ResultEntity<>(staffInfo2);
        }
        //数据库
        StaffInfo staffInfo = new StaffInfo();
        IcSmDqlStaff smDqlStaff = icSmDqlStaffMapper.selectByStaffId(userId);
        log.info("OrderShopServiceImpl.getStaffInfoByStaffID icSmDqlStaffMapper.selectByStaffId is suceess ! result is :{}", smDqlStaff);
        if (null != smDqlStaff) {
            String storeCode = smDqlStaff.getStoreCode();
            if (StringUtils.isNotBlank(storeCode)) {
                GomeStoreFull gomeStoreFull = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus(storeCode);
                if (null != gomeStoreFull) {
                    //大区名称
                    smDqlStaff.setRegionName(gomeStoreFull.getRegioneName());
                    //大区编码
                    smDqlStaff.setRegionCode(gomeStoreFull.getRegioneId());
                }
            }
            staffInfo.setStaffInfo(smDqlStaff);
            staffInfo.setType(new Byte("0"));
        } else {//线下员工信息不存在 查询线上员工信息
            IcSmHlwlStaff icSmHlwlStaff = icSmHlwlStaffMapper.selectByStaffId(userId);
            log.info("OrderShopServiceImpl.getStaffInfoByStaffID icSmHlwlStaffMapper.selectByStaffId is suceess ! result is :{}", icSmHlwlStaff);
            if (null == icSmHlwlStaff) {
                return new ResultEntity(1, "员工信息不存在", null);
            }
            staffInfo.setType(new Byte("1"));
            staffInfo.setStaffInfo(icSmHlwlStaff);
        }
        gcache.setex(STAFF_INFO_PREFIX + userId, 3600, JSONObject.toJSONString(staffInfo));
        return new ResultEntity(0, "员工信息查询成功! ", staffInfo);
    }

    /**
     * 通过参数获取员工信息
     * 0绑定 1不绑定
     *
     * @param userId    用户id
     * @param orderTime 订单时间
     * @return
     */
    @Override
    public ResultEntity<StaffInfo> getStaffInfoWithParam(Long userId, String orderTime) {
        return null;
    }

    @Override
    public ResultEntity<StaffInfo<IcSmDqlStaff>> getStaffInfoWithParam(Long userId, Long shareMid, Long shareUserId, List<CouponVo> couponVoList, String orderTime) {
        return null;
    }

    /**
     * 获取线下员工表的销售组织
     * 1.如果当前用户不是员工，那么没有销售组织，需要根据绑定关系，找到最上级是店主员工，并将其销售组织进行返回
     * 2.如果上级是大锤，返回大锤的销售组织
     * 3.如果上级为空，那么返回销售组织为空
     *
     * @param userId
     * @return 销售组织
     */
    @Override
    @Cacheable(value = "根据用户Id查找销售组织", prefix = "OrderShopServiceImpl.findOrganizationByUserId_", suffix = "#userId", seconds = 200)
    public String findOrganizationByUserId(Long userId) {
        if (null == userId) {
            return null;
        }
        IcSmDqlStaff icSmDqlStaff = icSmDqlStaffMapper.selectByStaffId(userId);
        log.info("根据用户id查询用户信息,数据库返回结果:{}", JSON.toJSON(icSmDqlStaff));
        //自己是员工，返回自己的销售组织
        if (null != icSmDqlStaff) {
            return icSmDqlStaff.getStatus() == 1 ? icSmDqlStaff.getOrganizationCode() : null;
        } else {
            //自己不是员工，找绑定关系
            MapResults<MShopShareBindingDto> currentBinding = userShareBindingManager.queryShareBindingByUserId(userId);
            log.info("OrderShopServiceImpl.findOrganizationByUserId 走数据库查找销售组织 param userId {},绑定关系数据是{} ", userId, JSON.toJSON(currentBinding));
            if (null == currentBinding || null == currentBinding.getBuessObj() || null == currentBinding.getBuessObj().getTopLeaderUserid()) {
                return null;
            }
            //有绑定关系，并且有片总ID
            Long topLeaderUserid = currentBinding.getBuessObj().getTopLeaderUserid();
            if (diamondBiz.getPianZongUserId().contains(topLeaderUserid)) {
                //如果是大锤，返回大锤的销售组织
                return diamondBiz.getDefaultHammer().getPianzong_oranid();
            }

            //片总不是大锤，返回自己的销售组织
            IcSmDqlStaff smDqlStaff2 = icSmDqlStaffMapper.selectByStaffId(topLeaderUserid);
            log.info("OrderShopServiceImpl.findOrganizationByUserId 走数据库查找销售组织 param userId {},绑定的片总ID {} 对应的员工信息 {}", userId, topLeaderUserid, JSON.toJSON(smDqlStaff2));
            if (null == smDqlStaff2) {
                return null;
            }
            //自己是员工，返回自己
            return smDqlStaff2.getStatus() == 1 ? smDqlStaff2.getOrganizationCode() : null;
        }
    }

    @Override
    @Cacheable(value="根据国美在线id获取员工信息",prefix = Constant.STAFF_INFO_STR_CACHE,suffix = {"#newUserId"},seconds =60 * 60 * 24 )
    public EmployeeInfo selectByNewUserId(long newUserId) {
        IcSmDqlStaff icSmDqlStaff = icSmDqlStaffMapper.selectByStaffId(newUserId);
        if (null == icSmDqlStaff) {
            return null;
        }
        EmployeeInfo employeeInfo = new EmployeeInfo();
        employeeInfo.setNewUserId(icSmDqlStaff.getZxUid());
        employeeInfo.setMid(icSmDqlStaff.getMid());
        employeeInfo.setStaffCode(icSmDqlStaff.getStaffCode());
        employeeInfo.setStaffName(icSmDqlStaff.getStaffName());
        employeeInfo.setStaffPostName(icSmDqlStaff.getStaffPostName());
        List<Object> userBrandList = employeeBiz.getEmployeeBrandBySap(employeeInfo.getStaffCode());
        if (CollectionUtils.isNotEmpty(userBrandList)) {
            List<String> brandList = userBrandList.stream().map(i -> String.valueOf(i)).collect(Collectors.toList());
            employeeInfo.setBrandIdList(brandList);
        }
        GomeStoreFull allStatus = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus(icSmDqlStaff.getStoreCode());
        if (null != allStatus) {
            //0-自营，1-联营，2-加盟
            employeeInfo.setPoolFlag(allStatus.getPoolFlag());
        }
        return employeeInfo;
    }

    /**
     * 从缓存中获取数据，并读取数据到缓存
     * @param userId
     * @return
     */
    @Override
    @SneakyLog("根据国美在线id 从缓存中获取员工信息")
    public EmployeeInfo selectByNewUserIdFromCache(long userId) {
        Gcache gcache = gCacheConfig.gcache();
        String key = Constant.STAFF_INFO_STR_CACHE + userId;
        String cache = gcache.get(key);
        return StringUtils.isNotEmpty(cache) ? JSONObject.parseObject(cache, EmployeeInfo.class) : null;
    }
}
