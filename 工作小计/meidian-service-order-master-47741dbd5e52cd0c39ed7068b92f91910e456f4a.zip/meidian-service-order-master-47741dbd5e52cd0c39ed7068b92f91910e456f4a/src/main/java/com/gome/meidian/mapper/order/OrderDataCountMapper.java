package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderBranchTaskCensus;
import com.gome.meidian.entity.OrderDataCount;

/**
 * @author sunxueyan-ds
 * @Title: OrderDataCountMapper
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/13 20:46
 */
public interface OrderDataCountMapper  extends BaseMapper<OrderDataCount> {
}
