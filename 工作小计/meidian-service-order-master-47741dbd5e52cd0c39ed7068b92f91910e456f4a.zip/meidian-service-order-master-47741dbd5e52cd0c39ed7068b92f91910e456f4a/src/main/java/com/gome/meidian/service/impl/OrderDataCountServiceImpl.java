package com.gome.meidian.service.impl;

import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.entity.OrderDataCount;
import com.gome.meidian.mapper.order.OrderDataCountMapper;
import com.gome.meidian.mapper.order.OrderTaskMapper;
import com.gome.meidian.service.OrderDataCountService;
import com.gome.meidian.service.util.BeanConvertUtils;
import com.gome.meidian.enums.OrderTaskUtil;
import org.apache.commons.lang3.time.DateUtils;
//import com.gome.meidian.util.DateUtils;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author sunxueyan-ds
 * @Title: OrderDataCountServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/13 20:43
 */
@Service
public class OrderDataCountServiceImpl extends ServiceImpl<OrderDataCountMapper, OrderDataCount> implements OrderDataCountService {

    @Autowired
    OrderDataCountMapper orderDataCountMapper;
    @Autowired
    OrderTaskMapper orderTaskMapper;

    @Override
    @Transactional
    public Map<String, Long> insertOrUpdateBatchNum(List<OrderDataCount> list) {
        return insertOrUpdateBatchMethod(list, 30);
    }


    @Transactional
    public void calculateOrderData() {

        List<OrderDataCount> orderDataCounts = new ArrayList<>();
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

            Date beforeDate = DateUtils.addDays(new Date(), -10);
            Date beforeDateOccur = DateUtils.addDays(new Date(), -5);
            String format = simpleDateFormat.format(beforeDate);
            Date tomorrowDate = DateUtils.addDays(new Date(), 1);
            String format1 = simpleDateFormat.format(tomorrowDate);
            List<OrderDataCount> orderTaskData = orderTaskMapper.getOrderTaskData(simpleDateFormat.format(beforeDateOccur), simpleDateFormat.format(tomorrowDate), null, null, null, null);//统计购买数据，购买数量、购买总额 全部
            List<OrderDataCount> payOrderTaskData = orderTaskMapper.getOrderTaskData(simpleDateFormat.format(beforeDateOccur), simpleDateFormat.format(tomorrowDate), null, null, null, new Byte("1"));//统计购买数据，购买数量、购买总额 已支付
            List<OrderDataCount> cancelOrderTaskData = orderTaskMapper.getOrderTaskData(simpleDateFormat.format(beforeDateOccur), simpleDateFormat.format(tomorrowDate), null, null, null, new Byte("2"));//统计购买数据，购买数量、购买总额 已取消
            List<OrderDataCount> effectOrderTaskData = orderTaskMapper.getOrderTaskData(simpleDateFormat.format(beforeDate), simpleDateFormat.format(tomorrowDate), null, null, null, new Byte("5"));//统计购买数据，购买数量、购买总额 已妥投

            orderDataCounts = mergeData(orderTaskData, payOrderTaskData, cancelOrderTaskData, effectOrderTaskData);

        } catch (Exception e) {
            throw new RuntimeException("Error:  Can not execute. Could not calculateOrderData.");
        }
        insertOrUpdateBatchNum(orderDataCounts);
    }


    /**
     * 合并list数据
     *
     * @param orderTaskData
     * @param payOrderTaskData
     * @param cancelOrderTaskData
     * @param effectOrderTaskData
     * @return
     */
    public List<OrderDataCount> mergeData(List<OrderDataCount> orderTaskData, List<OrderDataCount> payOrderTaskData, List<OrderDataCount> cancelOrderTaskData, List<OrderDataCount> effectOrderTaskData) {
        for (OrderDataCount orderDataCount : orderTaskData) {
            if (!StringUtils.isNotEmpty(orderDataCount.getBranchCode())) {//非美店员工
                orderDataCount.setBranchCode(OrderTaskUtil.code2.getCode());
                orderDataCount.setBranchName(OrderTaskUtil.code2.getName());
            }
            //存入支付单的数据
            for (OrderDataCount payData : payOrderTaskData) {
                if (StringUtils.isEmpty(payData.getBranchCode())) {//非美店员工
                    payData.setBranchCode(OrderTaskUtil.code2.getCode());
                    payData.setBranchName(OrderTaskUtil.code2.getName());
                }
                if (StringUtils.isNotEmpty(orderDataCount.getSkuId()) && null != orderDataCount.getOrderTime() && null != payData.getOrderTime() && StringUtils.isNotEmpty(payData.getSkuId())) {
                    if (orderDataCount.getSkuId().equals(payData.getSkuId()) && org.apache.commons.lang.time.DateUtils.isSameDay(orderDataCount.getOrderTime(), payData.getOrderTime()) && orderDataCount.getBranchCode().equals(payData.getBranchCode())) {
                        orderDataCount.setPaySales(payData.getSales() != null ? payData.getSales() : new BigDecimal("0"));
                        orderDataCount.setPaySalesNum(payData.getSalesNum() != null ? payData.getSalesNum() : 0l);
                        orderDataCount.setPayOrderNum(payData.getOrderNum() != null ? payData.getOrderNum() : 0l);
                    }
                }
            }
            //存入妥投单的数据
            for (OrderDataCount effectData : effectOrderTaskData) {
                if (StringUtils.isEmpty(effectData.getBranchCode())) {//非美店员工
                    effectData.setBranchCode(OrderTaskUtil.code2.getCode());
                    effectData.setBranchName(OrderTaskUtil.code2.getName());
                }
                if (StringUtils.isNotEmpty(orderDataCount.getSkuId()) && null != orderDataCount.getOrderTime() && null != effectData.getOrderTime() && StringUtils.isNotEmpty(effectData.getSkuId())) {
                    if (orderDataCount.getSkuId().equals(effectData.getSkuId()) && org.apache.commons.lang.time.DateUtils.isSameDay(orderDataCount.getOrderTime(), effectData.getOrderTime()) && orderDataCount.getBranchCode().equals(effectData.getBranchCode())) {
                        orderDataCount.setEffectSales(effectData.getSales() != null ? effectData.getSales() : new BigDecimal("0"));
                        orderDataCount.setEffectSalesNum(effectData.getSalesNum() != null ? effectData.getSalesNum() : 0l);
                        orderDataCount.setEffectOrderNum(effectData.getOrderNum() != null ? effectData.getOrderNum() : 0l);
                    }
                }
            }
            for (OrderDataCount cancelData : cancelOrderTaskData) {
                if (StringUtils.isEmpty(cancelData.getBranchCode())) {//非美店员工
                    cancelData.setBranchCode(OrderTaskUtil.code2.getCode());
                    cancelData.setBranchName(OrderTaskUtil.code2.getName());
                }
                if (StringUtils.isNotEmpty(orderDataCount.getSkuId()) && null != orderDataCount.getOrderTime() && null != cancelData.getOrderTime() && StringUtils.isNotEmpty(cancelData.getSkuId())) {
                    if (orderDataCount.getSkuId().equals(cancelData.getSkuId()) && org.apache.commons.lang.time.DateUtils.isSameDay(orderDataCount.getOrderTime(), cancelData.getOrderTime()) && orderDataCount.getBranchCode().equals(cancelData.getBranchCode())) {
                        orderDataCount.setCancelSales(cancelData.getSales() != null ? cancelData.getSales() : new BigDecimal("0"));
                        orderDataCount.setCancelSalesNum(cancelData.getSalesNum() != null ? cancelData.getSalesNum() : 0l);
                        orderDataCount.setCancelOrderNum(cancelData.getOrderNum() != null ? cancelData.getOrderNum() : 0l);
                    }
                }
            }
        }
        return orderTaskData;
    }

    /**
     * 批量插入修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @return boolean
     */
    private Map<String, Long> insertOrUpdateBatchMethod(List<OrderDataCount> entityList, int batchSize) {
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        Long count = 0l;
        Map<String, Long> resultMap = new HashMap<>();
        resultMap.put("insertNum", 0l);
        resultMap.put("updateNum", 0l);
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            for (int i = 0; i < size; i++) {
                entityList.get(i).setUpdateTime(new Date());
                resultMap = insertOrUpdateReal(entityList.get(i), resultMap);
                if (i >= 1 && i % batchSize == 0) {
                    batchSqlSession.flushStatements();
                }
            }
            batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertOrUpdateBatch Method. Cause", e);
        }
        return resultMap;
    }


    /**
     * <p>
     * TableId 注解存在更新记录，否插入一条记录
     * </p>
     *
     * @param entity 实体对象
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateReal(OrderDataCount entity, Map<String, Long> resultMap) {
//        Map<String, Long> resultMap = new HashMap<>();
        Boolean flag = false;
        Long updateNum = 0l;
        Long insertNum = 0l;
        if (null != entity) {
            if (StringUtils.isNotEmpty(entity.getBranchCode())) {
                /*
                 * 更新成功直接返回，失败执行插入逻辑
                 */
                EntityWrapper wrapper = new EntityWrapper();
                wrapper.eq("sku_id", null != entity.getSkuId() ? entity.getSkuId(): null);
                wrapper.eq("branch_code", entity.getBranchCode());
                wrapper.eq("order_time", null != entity.getOrderTime()? entity.getOrderTime() : null);
                OrderDataCount orderDataCount = selectOne(wrapper);
                if (null != orderDataCount) {
                    BeanConvertUtils.copyPropertiesIgnoreNull(entity, orderDataCount);
                    flag = updateById(orderDataCount);
                }
//                flag = update(entity, wrapper);
                if (!flag) {
                    flag = insert(entity);
                    if (flag) {
                        insertNum = resultMap.get("insertNum");
                        insertNum++;
                        resultMap.put("insertNum", insertNum);
                    }
                } else {
                    updateNum = resultMap.get("updateNum");
                    updateNum++;
                    resultMap.put("updateNum", updateNum);
                }
                return resultMap;
//                return update(entity, wrapper) || insert(entity);
            }
        } else {
            throw new MybatisPlusException("Error:  Can not execute. Could not find @TableId.");
        }
//        }
        return resultMap;
    }
}
