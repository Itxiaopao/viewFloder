package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderBasedTask;
import com.gome.meidian.entity.OrderBodyError;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

public interface OrderBasedTaskMapper extends BaseMapper<OrderBasedTask> {

//    int insert(OrderBasedTask record);

    int insertSelective(OrderBasedTask record);

    int updateByPrimaryKeySelective(OrderBasedTask record);

    int updateByPrimaryKey(OrderBasedTask record);

    @Select(" SELECT * from order_based_task b WHERE #{recordTime} BETWEEN b.start_time AND b.end_time AND b.sku_id = #{skuId}")
    List<OrderBasedTask> getOrderBasedTaskByRecordTime(@Param("recordTime")Date recordTime, @Param("skuId")String skuId);
}