package com.gome.meidian.mapper.order;


import com.gome.meidian.vo.MeidianBangbangOrder;

import java.util.Map;

public interface MeidianBangbangOrderMapper {

    int delete(Long id);

    int insert(MeidianBangbangOrder record);

    int update(MeidianBangbangOrder record);

    MeidianBangbangOrder selectOne(Map<String,Object> map);


}