package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.MidOrderInfo;
import com.gome.meidian.entity.OrderEffect;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

/**
 * <p>
 * 妥投单表 Mapper 接口
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
public interface OrderEffectMapper extends BaseMapper<OrderEffect> {


	@Select("select * from order_effect where mid in (${mid}) and (effect_time between '${startDate}' and '${endDate}')")
	List<OrderEffect> selectByDateRange(HashMap<String, Object> queryParams);


	@Select("select DISTINCT mid from order_effect where effect_time between '${startDate}' and '${endDate}' ")
	List<String> selectByOnlyDateRange(HashMap<String, Object> queryParams);

	@Select("select sum(1) as orderNum,sum(price_total) as orderGmv,mid from order_effect where mid = '${mid}' ")
    MidOrderInfo getMidOrderInfo(@Param(value = "mid") String mid);

	@Select("select sum(1) as orderNum,sum(price_total) as orderGmv,mid from order_effect where mid in (select o.mid from (select sum(price_total) as priceTotal,mid from order_effect GROUP BY mid) as o WHERE o.priceTotal BETWEEN ${beginOrderGmv} and ${endOrderGmv}) GROUP BY mid")
	List<MidOrderInfo> getInvertalOrderInfo(@Param(value = "beginOrderGmv") BigDecimal beginOrderGmv, @Param(value = "endOrderGmv") BigDecimal endOrderGmv);
}
