package com.gome.meidian.mapper.bigData;

import com.gome.meidian.entity.IcSmDqlStaff;
import com.gome.meidian.mapper.bigData.provider.IcSmDqlStaffProvider;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;

import java.util.List;

public interface IcSmDqlStaffMapper {

    @SelectProvider(type=IcSmDqlStaffProvider.class, method="selectPart")
    List<IcSmDqlStaff> selectPart(@Param(value = "pageNum") Integer pageNum, @Param(value = "pageSize") Integer pageSize);
    @SelectProvider(type=IcSmDqlStaffProvider.class, method="selectPartWithMid")
    List<IcSmDqlStaff> selectPartWithMid(@Param(value = "pageNum") Integer pageNum, @Param(value = "pageSize") Integer pageSize);

    @SelectProvider(type=IcSmDqlStaffProvider.class, method="getTotalCount")
    int getTotalCount();

    @SelectProvider(type=IcSmDqlStaffProvider.class, method="getTotalCountWithMid")
    int getTotalCountWithMid();

    int deleteByPrimaryKey(Integer id);

    int insert(IcSmDqlStaff record);

    int insertSelective(IcSmDqlStaff record);

    IcSmDqlStaff selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(IcSmDqlStaff record);

    int updateByPrimaryKey(IcSmDqlStaff record);

    @SelectProvider(type=IcSmDqlStaffProvider.class, method="selectByStaffId")
    IcSmDqlStaff selectByStaffId(@Param(value = "staffId") Long staffId);

    @SelectProvider(type=IcSmDqlStaffProvider.class, method="selectStaffInfoBymid")
    IcSmDqlStaff selectStaffInfoBymid(@Param(value = "mid") Long mid);

    @SelectProvider(type=IcSmDqlStaffProvider.class, method="selectPartByCtime")
    List<IcSmDqlStaff> selectPartByCtime(@Param(value = "minutes") int minutes);
}