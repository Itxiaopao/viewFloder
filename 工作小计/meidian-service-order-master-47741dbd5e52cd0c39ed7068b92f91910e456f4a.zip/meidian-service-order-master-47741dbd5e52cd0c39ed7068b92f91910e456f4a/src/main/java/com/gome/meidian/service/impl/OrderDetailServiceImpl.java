package com.gome.meidian.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gome.frontSe.interfaces.IProdDetailService;
import com.gome.meidian.config.GCacheConfig;
import com.gome.meidian.mapper.order.OrderCategoryMapper;
import com.gome.meidian.mapper.order.OrderShopMapper;
import com.gome.meidian.mapper.readorder.OrderOccurReadMapper;
import com.gome.meidian.enums.OrderStatus;
import com.gome.meidian.vo.OrgnizationVo;
import com.gome.stage.interfaces.whale.IProductInfoService;
import com.gome.stage.item.SkuItem;

import com.gome.stage.page.ProductItemPage;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.entity.OrderCategory;
import com.gome.meidian.entity.OrderDetailRequest;
import com.gome.meidian.entity.OrderDetailResponse;
import com.gome.meidian.service.IOrderDetailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.Gcache;

/**
 * @ClassName: OrderDetailServiceImpl
 * @Description: 订单明细实现类
 * @author likaile
 * @date 2018年10月31日 上午11:09:16
 */
@Slf4j
@Service
public class OrderDetailServiceImpl implements IOrderDetailService {
	@Autowired
	OrderCategoryMapper orderCategoryMapper;
	@Autowired
	OrderOccurReadMapper orderOccurMapper;
	@Autowired
	OrderShopMapper orderShopMapper;
	@Autowired 
	IProductInfoService iProductInfoService;
	@Autowired
	IProdDetailService iProdDetailService;
	@Autowired
	GCacheConfig gCacheConfig;

	private Logger logger = LoggerFactory.getLogger(getClass());
	@Override
	public List<OrderCategory> getCateByType(Integer type, String parentCode) {
		if (null == type || type.equals(0)) {
			return orderCategoryMapper.getCate();
		}
		if (type.equals(1)) {
			return orderCategoryMapper.getFirstCate(parentCode);
		}
		if (type.equals(2)) {
			return orderCategoryMapper.getSecondCate(parentCode);
		}
		if (type.equals(3)) {
			return orderCategoryMapper.getThirdCate(parentCode);
		}
		return null;
	}

	@Override
	public List<OrgnizationVo> getOrgnizationSelect(String type, String parentCode) {
		if (null == type || type.equals("0")) {
			return orderShopMapper.getFirstLevel();
		}
		if (type.equals("1")) {
			return orderShopMapper.getSecondLevel(parentCode);
		}
		if (type.equals("2")) {
			return orderShopMapper.getThirdLevel(parentCode);
		}
		return null;
	}

	@Override
	public Map queryOrderDetail(OrderDetailRequest request) {
		logger.info("请求报表详情入参："+request.toString());
		Map  map=new HashMap();
		if (null == request.getStartDate() || null == request.getEndDate()) {
			map= null;
		}
		if (null != request.getRegionId() || null != request.getBranchId() || null != request.getBranchSecondId()) {
			if (null != request.getStoreId() || null != request.getStaffId()) {
				// 大区或者分部查询条件 不可与 门店或员工 查询条件 并存
				map= null;
			}
		}
		// 校验自联营值 1 自营 4联营
		if (null != request.getBusinessType() && !request.getBusinessType().equals(1)
				&& !request.getBusinessType().equals(4)) {
			map= null;
		}
		List<OrderDetailResponse> list=null;
		Long total=0l;
		if (null != request.getStaffType()) {
			if (request.getStaffType().equals(1)) {
				// 查询员工数据
				list= orderOccurMapper.queryStaffDetail(request.getStartDate(), request.getEndDate(),
						request.getDeliveryId(), request.getUserId(), request.getSkuId(), request.getItemId(),
						request.getSkuNo(), request.getBusinessType(), request.getRegionId(), request.getBranchId(),
						request.getBranchSecondId(), request.getStoreId(), request.getStaffId(),
						request.getClassifyId(), request.getCategoryFirst(), request.getCategorySecond(),
						request.getCategoryThird(), request.getPageIndex(), request.getPageSize(),request.getOrderStatus());
				total= orderOccurMapper.queryStaffDetailCount(request.getStartDate(), request.getEndDate(),
						request.getDeliveryId(), request.getUserId(), request.getSkuId(), request.getItemId(),
						request.getSkuNo(), request.getBusinessType(), request.getRegionId(), request.getBranchId(),
						request.getBranchSecondId(), request.getStoreId(), request.getStaffId(),
						request.getClassifyId(), request.getCategoryFirst(), request.getCategorySecond(),
						request.getCategoryThird(), request.getOrderStatus());

			} else {
				// 查询非员工数据
				list= orderOccurMapper.queryNotStaffDetail(request.getStartDate(), request.getEndDate(),
						request.getDeliveryId(), request.getUserId(), request.getSkuId(), request.getItemId(),
						request.getSkuNo(), request.getBusinessType(), request.getClassifyId(),
						request.getCategoryFirst(), request.getCategorySecond(), request.getCategoryThird(),
						request.getPageIndex(), request.getPageSize(),request.getOrderStatus());
				
				total= orderOccurMapper.queryNotStaffDetailCount(request.getStartDate(), request.getEndDate(),
						request.getDeliveryId(), request.getUserId(), request.getSkuId(), request.getItemId(),
						request.getSkuNo(), request.getBusinessType(), 
						request.getClassifyId(), request.getCategoryFirst(), request.getCategorySecond(),
						request.getCategoryThird(), request.getOrderStatus());
			
			}
		}
		else	// 查询所有数据
		{
		total= orderOccurMapper.queryOrderDetailCount(request.getStartDate(), request.getEndDate(), request.getDeliveryId(),
					request.getUserId(), request.getSkuId(), request.getItemId(), request.getSkuNo(),
					request.getBusinessType(), request.getRegionId(), request.getBranchId(), request.getBranchSecondId(),
					request.getStoreId(), request.getStaffId(), request.getClassifyId(), request.getCategoryFirst(),
					request.getCategorySecond(), request.getCategoryThird(), request.getOrderStatus());
		list= orderOccurMapper.queryOrderDetail(request.getStartDate(), request.getEndDate(), request.getDeliveryId(),
				request.getUserId(), request.getSkuId(), request.getItemId(), request.getSkuNo(),
				request.getBusinessType(), request.getRegionId(), request.getBranchId(), request.getBranchSecondId(),
				request.getStoreId(), request.getStaffId(), request.getClassifyId(), request.getCategoryFirst(),
				request.getCategorySecond(), request.getCategoryThird(), request.getPageIndex(), request.getPageSize(),request.getOrderStatus());

		}
		Gcache gcache = gCacheConfig.gcache();
		for (OrderDetailResponse detailResponse : list){
			if(StringUtils.isNotEmpty(detailResponse.getItemId()) ){

				Boolean exists = gcache.exists("productId_" + detailResponse.getItemId());
				if(!exists){
					ProductItemPage vo = iProdDetailService.getProductDetail(detailResponse.getItemId(), null);
					if(null != vo && null != vo.getPrdInfo() && StringUtils.isNotEmpty(vo.getPrdInfo().getBrand())){
						detailResponse.setBrandName(vo.getPrdInfo().getBrand());
						//生成token
						//String token = UUID.randomUUID().toString();
						gcache.setnxex("productId_" + detailResponse.getItemId(), 60*60*240, vo.getPrdInfo().getBrand());
					}
				}else {
					String brandName = gcache.get("productId_" + detailResponse.getItemId());
					detailResponse.setBrandName(brandName);
				}
			}

            Byte status = detailResponse.getStatus();
            if(null != status){
                if(status.equals(OrderStatus.status1.getStatus()))
                    detailResponse.setStatusName(OrderStatus.status1.getStatusName());
                if(status.equals(OrderStatus.status2.getStatus()))
                    detailResponse.setStatusName(OrderStatus.status2.getStatusName());
                if(status.equals(OrderStatus.status5.getStatus()))
                    detailResponse.setStatusName(OrderStatus.status5.getStatusName());
                if(status.equals(OrderStatus.status6.getStatus()))
                    detailResponse.setStatusName(OrderStatus.status6.getStatusName());
            }
        }
		map.put("total", total);
		map.put("list", list);  
		System.out.println(total);
		return map;
	}
	
	
	
	
	//得到SKUInfo 信息
	private SkuItem getSkuItem(String skuId)
	{
		SkuItem skuItem=null;
		try {
		//ProductItem	 ProductItem=iProductInfoService.getProdDetailByProductId("");
		 skuItem= iProductInfoService.getSkuDetailBySkuId(skuId);
		
		}
		catch (Exception ex){
		   log.error("查询商品服务出现错误",ex);
		}
		return skuItem;
	}

}
