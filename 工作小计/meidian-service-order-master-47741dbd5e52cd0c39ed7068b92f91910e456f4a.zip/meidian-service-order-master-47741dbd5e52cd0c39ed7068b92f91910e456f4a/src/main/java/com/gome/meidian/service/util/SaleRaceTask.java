package com.gome.meidian.service.util;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.service.biz.RaceBiz;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

/**
 * 销售竞赛处理类
 * @author chenchen-ds6
 */
@Slf4j
@Component
public class SaleRaceTask{
    //1 准备一个新的dao
    //2 准备一个dao的对象
    //3 销售禁赛的分支
    //4 拉新竞赛的分支
    //5 计算积分
    @Autowired
    private RaceBiz raceBiz;
    @Autowired
    private Gcache gcache;

    public void run(MogRaceUserInfo mogRaceUserInfo) {
        log.info("线程处理销售竞赛,处理入参:{}",mogRaceUserInfo);
        Long setnx = gcache.setnxex(Constant.SALE_RACE_DISTRIBUTED_LOCK + mogRaceUserInfo.getUserId(),1, String.valueOf(System.currentTimeMillis()));
        if(setnx.equals(1L)){
            raceBiz.dealSaleOrder(mogRaceUserInfo);
        }else{
            //并发处理
            log.info("并发处理订单Gmv计算时发送队列参数:{}",mogRaceUserInfo);
            String s = JSONObject.toJSONString(mogRaceUserInfo);
            gcache.rpush(Constant.SALE_RACE_DISTRIBUTED_LISTENER,s);
        }
    }
}
