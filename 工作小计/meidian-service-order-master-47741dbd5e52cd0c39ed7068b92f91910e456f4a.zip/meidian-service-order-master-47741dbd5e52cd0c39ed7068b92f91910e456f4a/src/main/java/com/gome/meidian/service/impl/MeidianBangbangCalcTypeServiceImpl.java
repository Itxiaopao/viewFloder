package com.gome.meidian.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.gome.diamond.annotations.DiamondValue;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.convert.MeidianBangbangCalcTypeMapperToDtoConvert;
import com.gome.meidian.dto.MeidianBangbangCalcTypeDto;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.mapper.order.MeidianBangbangCalcTypeMapper;
import com.gome.meidian.service.IMeidianBangbangCalcTypeService;
import com.gome.meidian.service.biz.MeidianBangBangOrderCacheBiz;
import com.gome.meidian.vo.MeidianBangbangCalcType;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

/**
 * @author limenghui
 * @create 2020-06-19 11:58
 */
@Slf4j
@Service("meidianBangbangCalcTypeServiceImpl")
public class MeidianBangbangCalcTypeServiceImpl implements IMeidianBangbangCalcTypeService {
    @Autowired
    MeidianBangbangCalcTypeMapper meidianBangbangCalcTypeMapper;
    @Autowired
    MeidianBangBangOrderCacheBiz meidianBangBangOrderCacheBiz;
    @DiamondValue("${query.db.switch}")
    private Boolean queryDbSwitch;


    @Override
    @SneakyLog("查找首单数量")
    public int queryfirstOrder(Long upUserId) {
        try {
            Long firstCount = meidianBangBangOrderCacheBiz.getSubordinateCount(upUserId, Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER);
            if (!NumberUtils.isNullOrZero(firstCount)) {
                return firstCount.intValue();
            }
            if (queryDbSwitch) {
                Map<String, Object> param = new HashMap<>(1);
                param.put("upUserId", upUserId);
                return meidianBangbangCalcTypeMapper.selectCount(param);
            }
        } catch (Exception e) {
            log.error(" 查找首单数量 发生异常 入参 {} ", upUserId, e);
        }
        return 0;
    }

    @Override
    @SneakyLog("查找忠粉数量")
    public int queryLoyalFans(Long upUserId) {
        try {
            Long loyalFans = meidianBangBangOrderCacheBiz.getSubordinateCount(upUserId, Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS);
            if (!NumberUtils.isNullOrZero(loyalFans)) {
                return loyalFans.intValue();
            }
            if (queryDbSwitch) {
                Map<String, Object> param = new HashMap<>(2);
                param.put("upUserId", upUserId);
                param.put("count", 3);
                return meidianBangbangCalcTypeMapper.selectCount(param);
            }
        } catch (Exception e) {
            log.error(" 查找忠粉数量 发生异常 入参 {} ", upUserId, e);
        }
        return 0;
    }


    @Override
    @SneakyLog("查找忠粉/首单 列表")
    public ResultEntity<List<MeidianBangbangCalcTypeDto>> queryList(@NonNull Long upUserId, Set<String> userIds, int type, int pageIndex, int pageSize) {
        if (type != Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER && type != Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS) {
            return new ResultEntity();
        }

        try {
            Set<String> filterUserIds = null;
            if (CollectionUtils.isNotEmpty(userIds)) {
                Set<String> userIdsFromCache = meidianBangBangOrderCacheBiz.getSubordinate(upUserId, type);
                List<String> joinUserIds = userIdsFromCache.parallelStream().filter(s -> userIds.contains(s)).collect(Collectors.toList());
                List<String> strings = joinUserIds.subList(Math.max(0, pageIndex - 1), Math.min(pageSize, joinUserIds.size()));
                filterUserIds = Sets.newLinkedHashSet(strings);
            } else {
                filterUserIds = meidianBangBangOrderCacheBiz.getSubordinatePage(upUserId, type, pageIndex, pageSize);
            }
            //缓存
            List<MeidianBangbangCalcType> list = meidianBangBangOrderCacheBiz.multiGetCalcType(upUserId, filterUserIds);
            if (CollectionUtils.isNotEmpty(list) && list.size() == filterUserIds.size()) {
                return new ResultEntity<>(Lists.newArrayList(MeidianBangbangCalcTypeMapperToDtoConvert.CONVERTER.convertAll(list)));
            }
            if (queryDbSwitch) {
                Map<String, Object> param = new HashMap<>(6);
                if (type == Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS) {
                    param.put("upUserId", upUserId);
                    param.put("userIds", userIds);
                    param.put("count", 3);
                    param.put("pageIndex", pageIndex);
                    param.put("pageSize", pageSize);
                    param.put("sort", "lastOrderPayDate");
                } else {
                    param.put("upUserId", upUserId);
                    param.put("userIds", userIds);
                    param.put("pageIndex", pageIndex);
                    param.put("pageSize", pageSize);
                    param.put("sort", "firstOrderPayDate");
                }
                List<MeidianBangbangCalcType> calcTypeList = meidianBangbangCalcTypeMapper.selectList(param);
                return new ResultEntity<>(Lists.newArrayList(MeidianBangbangCalcTypeMapperToDtoConvert.CONVERTER.convertAll(calcTypeList)));
            }
        } catch (Exception e) {
            log.error(" 查找忠粉/首单列表 发生异常 upUserId {},userIds {} ,type {} , pageIndex {} ", upUserId, userIds, type, pageIndex, e);
        }
        return new ResultEntity<>();
    }
}
