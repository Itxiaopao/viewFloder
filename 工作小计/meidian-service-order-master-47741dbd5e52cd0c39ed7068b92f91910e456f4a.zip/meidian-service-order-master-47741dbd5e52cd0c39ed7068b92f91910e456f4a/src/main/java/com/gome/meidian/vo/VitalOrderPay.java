package com.gome.meidian.vo;

import java.io.Serializable;
import java.util.List;

public class VitalOrderPay implements Serializable {
	
	private static final long serialVersionUID = 4625375148406545584L;
	
	private Long id;//对应orderId/deliveryId
	private List<String> skuIds;
	private List<MogOrderInfo> mogOrderInfos;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public List<String> getSkuIds() {
		return skuIds;
	}
	public void setSkuIds(List<String> skuIds) {
		this.skuIds = skuIds;
	}
	public List<MogOrderInfo> getMogOrderInfos() {
		return mogOrderInfos;
	}
	public void setMogOrderInfos(List<MogOrderInfo> mogOrderInfos) {
		this.mogOrderInfos = mogOrderInfos;
	}
	
}
