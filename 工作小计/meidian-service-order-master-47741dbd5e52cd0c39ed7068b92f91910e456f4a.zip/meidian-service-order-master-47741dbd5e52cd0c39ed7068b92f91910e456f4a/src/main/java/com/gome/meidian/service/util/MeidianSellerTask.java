package com.gome.meidian.service.util;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.OrderEffect;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.entity.OrderRefund;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeplus.bs.interfaces.mshop.task.service.TaskOrderResource;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskOrderVo;

import redis.Gcache;

/**
 * @author chenchen-ds6
 * @Desc 美店主销售任务
 */
@Component
public class MeidianSellerTask {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
    @Autowired
    private TaskOrderResource taskOrderResource;
    @Resource(name = "gcache")
	private Gcache gcache;
    
    private final String MIDTASKRELATION="mid_task_relation:";//店主和拉新任务的数据
    
    /**
     * 处理发生订单数据
     * @param orderOccur
     */
    public void pushMeidianSellerEffectOrders(OrderOccur orderOccur){
    	try{
	    	Integer orderStatus = orderOccur.getStatus();
	    	if(orderStatus.equals(Constant.TASK_ORDER_PLACE)){//发生单
	    		//缓存mid对应拉新有效信息
	    		VshopInvitationRelation vshopInvitationRelation = this.getCacheMidTask(orderOccur.getMid());
	    		if(vshopInvitationRelation!=null){
	    			long activityTime = vshopInvitationRelation.getActiveTime().getTime();
	    			long orderTime = orderOccur.getOrderTime().getTime();
	    			if(orderTime<=activityTime){
	    				TaskOrderVo taskOrderVo = new TaskOrderVo();
	    				taskOrderVo.setOrderId(orderOccur.getOrderId());
	    				taskOrderVo.setCommerceId(orderOccur.getCommerceId());
	    				taskOrderVo.setDeliveryId(orderOccur.getDeliveryId());
	    				taskOrderVo.setOrderMid(orderOccur.getMid());
	    				taskOrderVo.setOrderUserId(Long.parseLong(orderOccur.getUserId()));
	    				taskOrderVo.setOrderTime(orderOccur.getOrderTime().getTime());
	    				taskOrderVo.setOrderPrice(orderOccur.getPriceTotal().longValue());
	    				taskOrderVo.setDeliverTime(orderOccur.getOrderTime().getTime());
	    				taskOrderVo.setOrderStatus(Constant.TASK_ORDER_PLACE);
	    				taskOrderVo.setSkuNo(orderOccur.getSkuNo());
	    				taskOrderResource.insertMshopTaskOrder(taskOrderVo);
	    				logger.info("订单推送完成,订单号:{},子订单号:{},配送号:{},订单mid:{}",orderOccur.getOrderId(),orderOccur.getCommerceId(),orderOccur.getDeliveryId(),orderOccur.getMid());
	    			}
	    		}
	    	}else if(orderStatus.equals(Constant.TASK_ORDER_OVER)){//取消单
	    		//缓存mid对应拉新有效信息
	    		VshopInvitationRelation vshopInvitationRelation = this.getCacheMidTask(orderOccur.getMid());
	    		if(vshopInvitationRelation!=null){
	    			TaskOrderVo taskOrderVo = new TaskOrderVo();
	    			taskOrderVo.setOrderId(orderOccur.getOrderId());
	    			taskOrderVo.setCommerceId(orderOccur.getCommerceId());
	    			taskOrderVo.setDeliveryId(orderOccur.getDeliveryId());
	    			taskOrderVo.setOrderMid(orderOccur.getMid());
	    			taskOrderVo.setOrderUserId(Long.parseLong(orderOccur.getUserId()));
	    			taskOrderVo.setOrderTime(orderOccur.getOrderTime().getTime());
	    			taskOrderVo.setOrderPrice(orderOccur.getPriceTotal().longValue());
	    			taskOrderVo.setDeliverTime(orderOccur.getOrderTime().getTime());
	    			taskOrderVo.setOrderStatus(Constant.TASK_ORDER_OVER);
	    			taskOrderVo.setSkuNo(orderOccur.getSkuNo());
	    			taskOrderResource.insertMshopTaskOrder(taskOrderVo);
	    		}
	    	}
    	}catch(Exception e){
    		logger.info("订单推送失败,异常信息:{}",e.getMessage());
    	}
    }
    
    /**
     * 处理妥投单数据
     * @param order
     */
    public void pushMeidianSellerEffectOrders(OrderEffect orderEffect){
    	try{
	        TaskOrderVo taskOrderVo = new TaskOrderVo();
	        taskOrderVo.setOrderId(orderEffect.getOrderId());
	        taskOrderVo.setCommerceId(orderEffect.getCommerceId());
	        taskOrderVo.setDeliveryId(orderEffect.getDeliveryId());
	        taskOrderVo.setOrderMid(orderEffect.getMid());
	        taskOrderVo.setOrderUserId(Long.parseLong(orderEffect.getUserId()));
	        taskOrderVo.setOrderTime(orderEffect.getOrderTime().getTime());
	        taskOrderVo.setOrderPrice(orderEffect.getPriceTotal().longValue());
	        taskOrderVo.setDeliverTime(orderEffect.getEffectTime().getTime());
	        taskOrderVo.setOrderStatus(Constant.TASK_ORDER_DELIVE);
	        taskOrderVo.setSkuNo(orderEffect.getSkuNo());
	        taskOrderResource.insertMshopTaskOrder(taskOrderVo);
    	}catch(Exception e){
    		logger.info("订单推送失败,异常信息:{}",e.getMessage());
    	}
    }
    
    /**
     * 处理逆向单数据
     * @param refund
     */
    public void pushMeidianSellerEffectOrders(OrderRefund orderRefund){
    	try{
	        TaskOrderVo taskOrderVo = new TaskOrderVo();
	        taskOrderVo.setOrderId(orderRefund.getOrderId());
	        taskOrderVo.setCommerceId(orderRefund.getCommerceId());
	        taskOrderVo.setDeliveryId(orderRefund.getDeliveryId());
	        taskOrderVo.setOrderMid(orderRefund.getMid());
	        taskOrderVo.setOrderUserId(Long.parseLong(orderRefund.getUserId()));
	        taskOrderVo.setOrderTime(orderRefund.getOrderTime().getTime());
	        taskOrderVo.setOrderPrice(orderRefund.getPriceTotal().longValue());
	        taskOrderVo.setDeliverTime(orderRefund.getOrderTime().getTime());
	        taskOrderVo.setOrderStatus(Constant.TASK_ORDER_CHARGE);
	        taskOrderVo.setSkuNo(orderRefund.getSkuNo());
	        taskOrderResource.insertMshopTaskOrder(taskOrderVo);
    	}catch(Exception e){
    		logger.info("订单推送失败,异常信息:{}",e.getMessage());
    	}
    }
    
    //缓存获取店主和拉新任务关系
    private VshopInvitationRelation getCacheMidTask(String mid){
    	String midTask = MIDTASKRELATION + mid;
		String gacheTSCK = gcache.get(midTask);
		if(gacheTSCK!=null&&!gacheTSCK.equals("")){
			VshopInvitationRelation vshopInvitationRelation = JSON.parseObject(gacheTSCK,VshopInvitationRelation.class);
			if(vshopInvitationRelation!=null){
				return vshopInvitationRelation;
			}
		}
		return null;
    }
    
}
