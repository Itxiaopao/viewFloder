package com.gome.meidian.page;

import java.io.Serializable;

public class BasePageVo implements Serializable {

	private static final long serialVersionUID = -1927582180563760495L;
	
	private Integer pageNo = 1;
	private Integer startRow = 0;
    private Integer pageSize = 10;

	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		if (pageNo < 1) {
			this.pageNo = 1;
		} else {
			this.pageNo = pageNo;
		}
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getStartRow() {
		this.startRow = (pageNo-1)*this.pageSize;
		return startRow;
	}
    
}
