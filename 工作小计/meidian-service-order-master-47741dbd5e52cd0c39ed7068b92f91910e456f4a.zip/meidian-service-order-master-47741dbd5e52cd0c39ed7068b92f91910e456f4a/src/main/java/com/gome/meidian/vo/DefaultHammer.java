package com.gome.meidian.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * diamond里的默认大锤信息
 *
 * @author hushengdong
 * @date 2019/11/12
 */
@Setter
@Getter
@ToString
public class DefaultHammer {

    private String pianzong_userid;
    private String pianzong_mid;
    private String pianzong_stid;
    private String pianzong_oranid;
    private String sledge_hammer_userId;
    private String sledge_hammer_mid;
    private String sledge_hammer_regionId;
    private String sledge_hammer_regionName;
    private String sledge_hammer_branchId;
    private String sledge_hammer_branchName;
    private String sledge_hammer_branchSecondId;
    private String sledge_hammer_branchSecondName;
    private String sledge_hammer_storeName;

}
