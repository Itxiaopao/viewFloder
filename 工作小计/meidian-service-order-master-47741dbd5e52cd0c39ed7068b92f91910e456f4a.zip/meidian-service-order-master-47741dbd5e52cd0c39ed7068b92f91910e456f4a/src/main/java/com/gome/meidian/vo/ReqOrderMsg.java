package com.gome.meidian.vo;

import java.io.Serializable;
import java.util.Date;

import com.gome.meidian.page.BasePageVo;

public class ReqOrderMsg implements Serializable {
	
	private static final long serialVersionUID = -7244933009693781003L;
	
	private String id;//主键id
	private String msgId;//消息id
	//自定义入参
	private Date startTime;//开始时间
	private Date endTime;//结束时间
	private BasePageVo basePageVo;//分页参数
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public BasePageVo getBasePageVo() {
		return basePageVo;
	}
	public void setBasePageVo(BasePageVo basePageVo) {
		this.basePageVo = basePageVo;
	}
	
}
