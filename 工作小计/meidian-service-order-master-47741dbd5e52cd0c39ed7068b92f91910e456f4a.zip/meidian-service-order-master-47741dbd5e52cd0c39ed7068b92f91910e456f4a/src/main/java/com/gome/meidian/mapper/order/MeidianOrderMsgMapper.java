package com.gome.meidian.mapper.order;

import com.gome.meidian.vo.MeidianOrderMsg;

import java.util.List;
import java.util.Map;

public interface MeidianOrderMsgMapper {

    int insert(MeidianOrderMsg record);

    int update(MeidianOrderMsg record);

    int delete(Long id);

    List<MeidianOrderMsg> selectListByBiz(Map<String,Object> map);

    MeidianOrderMsg selectOneByBiz(Map<String,Object> map);



}