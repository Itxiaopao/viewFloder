package com.gome.meidian.service.biz;

import cn.com.gome.rebate.calc.Delivery;
import cn.com.gome.rebate.calc.GoodsDto;
import cn.com.gome.rebate.calc.OrderDto;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.diamond.annotations.DiamondValue;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.enums.*;
import com.gome.meidian.mapper.order.MeidianCpaOrderMapper;
import com.gome.meidian.mapper.order.MeidianGrantRebateMapper;
import com.gome.meidian.mapper.order.MeidianOrderMsgMapper;
import com.gome.meidian.service.factory.OmsOrderFactory;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MeidianBindingRelationDto;
import com.gome.meidian.user.manager.IMeidianBindingRelationManager;
import com.gome.meidian.util.CommUtils;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.vo.MeidianCpaOrder;
import com.gome.meidian.vo.MeidianGrantRebate;
import com.gome.meidian.vo.MeidianOrderMsg;
import com.gomeo2o.common.exceptions.BizException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component("meidianCpaOrderBiz")
public class MeidianCpaOrderBiz implements OmsOrderFactory {

    @Autowired
    private RedisLockUtils redisLockUtils;

    @Autowired
    private MeidianCpaOrderMapper meidianCpaOrderMapper;

    @Autowired
    private MeidianGrantRebateMapper meidianGrantRebateMapper;

    @Autowired
    private MeidianOrderMsgMapper meidianOrderMsgMapper;

    @Autowired
    private IMeidianBindingRelationManager meidianBindingRelationManager;

    private static String invokeFrom = "meidian-service-order";

    @DiamondValue("${business.meidian.cpa.orderTimeout}")
    private String orderTimeout;
    @DiamondValue("${business.meidian.cpa.restrictPrice}")
    private String restrictPrice;
    @DiamondValue("${business.meidian.cpa.rebatePrice}")
    private String rebatePrice;

    /**
     * 美店CPA订单核心入口
     *
     * @param msgId   消息id
     * @param msgBody 消息体
     */
    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void processOrder(String msgId, String msgBody) {
        StringBuilder logContent = new StringBuilder(256);
        try {
            OrderDto orderDto = JSONObject.parseObject(msgBody, OrderDto.class);
            if (orderDto == null || StringUtils.isEmpty(orderDto.getUserId()) || CollectionUtils.isEmpty(orderDto.getDeliveryList())) {
                logContent.append("美店CPA订单消费失败,原因:必要参数为空,msgId:").append(msgId).append(",msgBody:").append(JSON.toJSON(orderDto));
                return;
            }
            List<Delivery> deliveryList = orderDto.getDeliveryList();
            Integer status = deliveryList.get(0).getStatus();
            //不消费订单级别的消息
            if (OrderFullStatus.getWaitPayOperateStatus().contains(status)) {
                logContent.append("美店CPA订单消费失败,原因:不接收待支付消息,msgId:").append(msgId).append(",orderId:").append(orderDto.getOrderId());
                return;
            }
            logContent.append("开始处理美店CPA订单,msgId:").append(msgId).append(",userId:").append(orderDto.getUserId()).append(",orderId:").append(orderDto.getOrderId());
            //配送单级别消息处理
            for (int i = 0; i < deliveryList.size(); i++) {
                boolean isCollect = Boolean.FALSE;
                Delivery delivery = deliveryList.get(i);
                Integer orderStatus = delivery.getStatus();
                logContent.append(",deliveryId:").append(delivery.getDeliveryOrderId()).append(",orderStatus:").append(orderStatus).append(OrderFullStatus.valueOf(orderStatus));
                String lockKey = CommUtils.getRedisKey(Constant.CPA_ORDER_MUTEX_LOCK_PREFIX, orderDto.getOrderId(), delivery.getDeliveryOrderId(), orderStatus);
                boolean mutexLock = Boolean.FALSE;
                try {
                    mutexLock = redisLockUtils.mutexLock(lockKey);
                    Long deliveryPrice = this.getDeliveryPrice(delivery.getGoodsList());
                    if (OrderFullStatus.Payed.getStatus().equals(orderStatus)) {
                        ResultEntity<Boolean> result = this.dealPayStatus(orderDto, delivery, deliveryPrice, i);
                        if (HttpStatus.SC_PARTIAL_CONTENT == result.getCode()) {
                            //部分创建
                            logContent.append(result.getMessage());
                        } else if (HttpStatus.SC_PRECONDITION_FAILED == result.getCode()) {
                            //不满足前提条件的
                            logContent.append(",美店CPA订单消费失败,原因:").append(result.getMessage());
                        }
                        isCollect = result.isSuccess() || HttpStatus.SC_PARTIAL_CONTENT == result.getCode();
                    } else {
                        Map<String, Object> map = new HashMap<>();
                        map.put("orderId", orderDto.getOrderId());
                        map.put("deliveryId", delivery.getDeliveryOrderId());
                        MeidianCpaOrder meidianCpaOrder = meidianCpaOrderMapper.selectOneByBiz(map);
                        if (meidianCpaOrder == null) {
                            logContent.append(",美店CPA订单消费失败,原因:没有支付订单");
                            continue;
                        }
                        //库里订单状态
                        Integer oldOrderStatus = meidianCpaOrder.getStatus();
                        if (OrderFullStatus.Payed.getStatus().equals(oldOrderStatus) && OrderFullStatus.Canced.getStatus().equals(orderStatus)) {
                            //原 已支付 → 现 取消单
                            this.dealReverseStatus(orderDto, meidianCpaOrder, orderStatus, deliveryPrice);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Payed.getStatus().equals(oldOrderStatus) && OrderFullStatus.Order_OutStock.getStatus().equals(orderStatus)) {
                            //原 已支付 → 现 配送单出库
                            meidianCpaOrder.setStatus(orderStatus);
                            meidianCpaOrderMapper.update(meidianCpaOrder);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Order_OutStock.getStatus().equals(oldOrderStatus) && OrderFullStatus.Effect.getStatus().equals(orderStatus)) {
                            //原 配送单出库 → 现妥投
                            meidianCpaOrder.setStatus(orderStatus);
                            this.dealEffectStatus(orderDto, meidianCpaOrder, deliveryPrice);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Order_OutStock.getStatus().equals(oldOrderStatus) && OrderFullStatus.Resfuesd_Revice.getStatus().equals(orderStatus)) {
                            //原 配送单出库 → 现已拒收
                            this.dealReverseStatus(orderDto, meidianCpaOrder, orderStatus, deliveryPrice);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Effect.getStatus().equals(oldOrderStatus) && OrderFullStatus.Back_Apply.getStatus().equals(orderStatus)) {
                            //原 妥投 → 现退货申请
                            this.dealReverseStatus(orderDto, meidianCpaOrder, orderStatus, deliveryPrice);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Effect.getStatus().equals(oldOrderStatus) && OrderFullStatus.Exchange_Apply.getStatus().equals(orderStatus)) {
                            //原 妥投 → 现换货申请
                            this.dealReverseStatus(orderDto, meidianCpaOrder, orderStatus, deliveryPrice);
                            isCollect = Boolean.TRUE;
                        }
                    }
                    //收集配送单消息
                    if (isCollect) {
                        MeidianOrderMsg msg = new MeidianOrderMsg();
                        msg.setOrderId(orderDto.getOrderId());
                        msg.setDeliveryId(delivery.getDeliveryOrderId());
                        msg.setStatus(delivery.getStatus());
                        msg.setMsgId(msgId);
                        msg.setMsgBody(msgBody);
                        msg.setInsertTime(orderDto.getOrderDate());
                        meidianOrderMsgMapper.insert(msg);
                        logContent.append(",消息处理成功");
                    }
                } finally {
                    //删除锁
                    redisLockUtils.unlock(mutexLock, lockKey);
                }

            }
        } catch (Exception e) {
            log.error(logContent.append(",CPA订单消费发生异常,异常堆栈如下:").toString(), e);
            throw e;
        } finally {
            log.info(logContent.toString());
        }
    }

    /**
     * 处理支付状态
     *
     * @param orderDto      订单
     * @param delivery      配送单
     * @param deliveryPrice 配送单实付金额
     * @param index         下标
     * @return
     */
    public ResultEntity<Boolean> dealPayStatus(OrderDto orderDto, Delivery delivery, Long deliveryPrice, int index) {
        //1.根据userId查询CPA链路关系
        MapResults<MeidianBindingRelationDto> userResult = meidianBindingRelationManager.getRelationByUserId(Long.parseLong(orderDto.getUserId()), invokeFrom);
        if (userResult == null || !userResult.getSuccess()) {
            return new ResultEntity<>(HttpStatus.SC_INTERNAL_SERVER_ERROR, "用户服务异常,接口返回值:" + JSON.toJSON(userResult));
        }
        MeidianBindingRelationDto userDto = userResult.getBuessObj();
        //2.非CPA用户不参与收单
        if (userDto == null) {
            return new ResultEntity<>(HttpStatus.SC_PRECONDITION_FAILED, "没有找到该用户的链路关系");
        }
        //3.没有参与活动的用户不收单
        if (StringUtils.isEmpty(userDto.getActivityId())) {
            return new ResultEntity<>(HttpStatus.SC_PRECONDITION_FAILED, "该用户不是在活动期间注册");
        }
        //4.判断用户注册是否超过配置的天数
        if (orderDto.getOrderSubmitDate().after(DateUtils.plusDays(userDto.getInsertTime(), Long.parseLong(orderTimeout)))) {
            return new ResultEntity<>(HttpStatus.SC_PRECONDITION_FAILED, "下单时间超过活动时间");
        }
        //5.该用户已成下过首单
        Map<String, Object> map2 = new HashMap<>();
        map2.put("userId", orderDto.getUserId());
        MeidianGrantRebate meidianGrantRebate = meidianGrantRebateMapper.selectOneByBiz(map2);
        if (meidianGrantRebate != null && !orderDto.getOrderId().equals(meidianGrantRebate.getOrderId())) {
            return new ResultEntity<>(HttpStatus.SC_PRECONDITION_FAILED, "用户已经下过首单");
        }
        //6.判断首单是否在非APP站点下过单
        Map<String, Object> map = new HashMap<>();
        map.put("userId", orderDto.getUserId());
        List<MeidianCpaOrder> deliveryIdList = meidianCpaOrderMapper.selectListByBiz(map);
        if (CollectionUtils.isNotEmpty(deliveryIdList) && !deliveryIdList.get(0).getOrderId().equals(orderDto.getOrderId())) {
            return new ResultEntity<>(HttpStatus.SC_PRECONDITION_FAILED, "该用户已在非APP站点下过首单");
        }
        //7.判断该配送单是否被记录
        map.clear();
        map.put("orderId", orderDto.getOrderId());
        List<String> deliveryIdList2 = meidianCpaOrderMapper.selectDeliveryIdListByBiz(map);
        if (CollectionUtils.isNotEmpty(deliveryIdList2) && deliveryIdList2.contains(delivery.getDeliveryOrderId())) {
            return new ResultEntity<>(HttpStatus.SC_PRECONDITION_FAILED, "该配送单已被记录");
        }
        //8.创建订单记录
        meidianCpaOrderMapper.insert(this.buildMeidianCpaOrder(orderDto, delivery, deliveryPrice));
        if (index == orderDto.getDeliveryList().size() - 1) {
            //9.判断是否APP站点下单
            if (!AppSiteEnum.contains(orderDto.getSiteId())) {
                if (CpaUserStatusEnum.register.getCode().equals(userDto.getStatus())) {
                    this.updateRelationStatus(Long.parseLong(orderDto.getUserId()), CpaUserStatusEnum.appFirstOrderCancel.getCode());
                }
                return new ResultEntity<>(HttpStatus.SC_PARTIAL_CONTENT, "非APP站点订单不创建返利计划");
            }
            //10.判断是否满足限价
            if (orderDto.getOrderPrice() < this.decimalMultiply(restrictPrice, "100")) {
                if (CpaUserStatusEnum.register.getCode().equals(userDto.getStatus())) {
                    this.updateRelationStatus(Long.parseLong(orderDto.getUserId()), CpaUserStatusEnum.appFirstOrderCancel.getCode());
                }
                return new ResultEntity<>(HttpStatus.SC_PARTIAL_CONTENT, "订单实付总额福满足限价不创建返利计划");
            }
            //11.判断是否已经创建过返利计划
            if (meidianGrantRebate != null) {
                return new ResultEntity<>(HttpStatus.SC_PARTIAL_CONTENT, "已创建过返利计划,无需再次创建");
            }
            //12.创建返利计划
            MeidianGrantRebate vo = new MeidianGrantRebate();
            vo.setPuserId(userDto.getPuserId());
            vo.setUserId(userDto.getUserId());
            vo.setOrderId(orderDto.getOrderId());
            vo.setOrderPrice(orderDto.getOrderPrice());
            vo.setOrderInitPrice(orderDto.getOrderPrice());
            vo.setOrderTime(orderDto.getOrderSubmitDate());
            vo.setRebatePrice(this.decimalMultiply(rebatePrice, "100"));
            vo.setRebateStatus("0");
            vo.setIsDelete(1);
            vo.setBindingTime(userDto.getInsertTime());
            meidianGrantRebateMapper.insert(vo);
            //13.更新首单信息
            if (CpaUserStatusEnum.register.getCode().equals(userDto.getStatus())) {
                this.updateRelationStatus(Long.parseLong(orderDto.getUserId()), CpaUserStatusEnum.appFirstOrder.getCode());
            }
        }
        return new ResultEntity<>(Boolean.TRUE);
    }

    /**
     * 处理逆向状态订单
     *
     * @param orderDto        订单消息体
     * @param meidianCpaOrder 数据库里面的订单信息
     * @param deliveryPrice   配送单金额
     */
    public void dealReverseStatus(OrderDto orderDto, MeidianCpaOrder meidianCpaOrder, Integer orderStatus, Long deliveryPrice) {
        //1.计算配送单级别的剩余金额
        Long surplusPrice = meidianCpaOrder.getPrice() - deliveryPrice;
        //2.判断,当订单取消或全部逆向后才改变订单状态
        meidianCpaOrder.setStatus(OrderFullStatus.Canced.getStatus().equals(orderStatus) || NumberUtils.LONG_ZERO.equals(surplusPrice) ? orderStatus : OrderFullStatus.Effect.getStatus());
        meidianCpaOrder.setPrice(surplusPrice);
        meidianCpaOrderMapper.update(meidianCpaOrder);
        if (!AppSiteEnum.contains(meidianCpaOrder.getSite())) {
            //非app站点订单，没有订单返利信息
            return;
        }
        //3.获取订单返利信息
        Map<String, Object> map2 = new HashMap<>();
        map2.put("userId", orderDto.getUserId());
        map2.put("orderId", orderDto.getOrderId());
        MeidianGrantRebate meidianGrantRebate = meidianGrantRebateMapper.selectOneByBiz(map2);
        if (meidianGrantRebate == null) {
            //返利信息为空，不记录逆向
            return;
        }
        if (!"0".equals(meidianGrantRebate.getRebateStatus())) {
            //返利已经发放，不记录逆向
            return;
        }
        //4.计算订单级别的剩余金额
        long surplusOrderPrice = meidianGrantRebate.getOrderPrice() - deliveryPrice;
        meidianGrantRebate.setOrderPrice(surplusOrderPrice);
        //5.返利有效并且剩余钱数或者剩余钱数为0时 逻辑删除，并且修改首单状态
        if (meidianGrantRebate.getIsDelete().equals(1) && (surplusOrderPrice < this.decimalMultiply(restrictPrice, "100") || surplusOrderPrice <= 0)) {
            meidianGrantRebate.setIsDelete(0);
            meidianGrantRebate.setFailureStatus(OrderFailureEnum.restrictPrice.getStatus());
            this.updateRelationStatus(Long.parseLong(orderDto.getUserId()), CpaUserStatusEnum.appFirstOrderCancel.getCode());
        }
        meidianGrantRebate.setUpdateTime(new Date());
        //6.更新返利表
        meidianGrantRebateMapper.update(meidianGrantRebate);

    }

    /**
     * 处理妥投状态
     *
     * @param orderDto        订单体
     * @param meidianCpaOrder 订单消息体
     * @param deliveryPrice   配送单实付金额
     */
    public void dealEffectStatus(OrderDto orderDto, MeidianCpaOrder meidianCpaOrder, Long deliveryPrice) {
        Map<String, Object> map2 = new HashMap<>();
        map2.put("userId", orderDto.getUserId());
        map2.put("orderId", orderDto.getOrderId());
        MeidianGrantRebate meidianGrantRebate = meidianGrantRebateMapper.selectOneByBiz(map2);
        //如果返利表不为空，并且妥投时间不为空
        if (meidianGrantRebate != null && meidianGrantRebate.getEffectTime() == null) {
            map2.put("status", OrderFullStatus.Effect.getStatus());
            Long sumPrice = meidianCpaOrderMapper.selectSumPriceByBiz(map2);
            if (meidianGrantRebate.getOrderPrice() - sumPrice - deliveryPrice <= 0) {
                meidianGrantRebate.setEffectTime(orderDto.getOrderDate());
                meidianGrantRebateMapper.update(meidianGrantRebate);
            }
        }
        meidianCpaOrderMapper.update(meidianCpaOrder);
    }

    /**
     * 构建CPA订单数据结构
     *
     * @param orderDto      订单
     * @param delivery      配送单
     * @param deliveryPrice 配送单总价
     * @return
     */
    private MeidianCpaOrder buildMeidianCpaOrder(OrderDto orderDto, Delivery delivery, Long deliveryPrice) {
        MeidianCpaOrder meidianCpaOrder = new MeidianCpaOrder();
        meidianCpaOrder.setUserId(Long.parseLong(orderDto.getUserId()));
        meidianCpaOrder.setOrderId(orderDto.getOrderId());
        meidianCpaOrder.setDeliveryId(delivery.getDeliveryOrderId());
        meidianCpaOrder.setStatus(delivery.getStatus());
        meidianCpaOrder.setPrice(deliveryPrice);
        meidianCpaOrder.setInitPrice(deliveryPrice);
        meidianCpaOrder.setSite(orderDto.getSiteId());
        meidianCpaOrder.setOrderTime(orderDto.getOrderSubmitDate());
        return meidianCpaOrder;
    }

    /**
     * 两个字符串相乘
     *
     * @param var1 乘数
     * @param var2 被乘数
     * @return
     */
    private Long decimalMultiply(String var1, String var2) {
        return new BigDecimal(var1).multiply(new BigDecimal(var2)).longValue();
    }

    /**
     * 获取配送单金额
     *
     * @param goodsList 商品集合
     * @return
     */
    private long getDeliveryPrice(List<GoodsDto> goodsList) {
        long deliveryPrice = 0L;
        if (CollectionUtils.isEmpty(goodsList)) {
            return deliveryPrice;
        }
        for (GoodsDto goodsDto : goodsList) {
            deliveryPrice += goodsDto.getPrice() * goodsDto.getBuyNum() - goodsDto.getShopCouponPrice();
        }
        return deliveryPrice;
    }

    /**
     * 更新用户状态
     *
     * @param userId 用户id
     * @param status 状态
     *               此方法需要事务同步，故不成功会抛出异常
     */
    public void updateRelationStatus(Long userId, Integer status) throws BizException {
        MapResults<Integer> mapResults = meidianBindingRelationManager.updateRelationStatus(userId, status, invokeFrom);
        if (mapResults == null || !mapResults.getSuccess() || mapResults.getBuessObj() == 0) {
            throw new BizException("更新用户状态异常,接口返回值:" + JSON.toJSON(mapResults));
        }
    }

}
