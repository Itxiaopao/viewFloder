package com.gome.meidian.vo;

import java.io.Serializable;

public class VitalOrderVo implements Serializable {
	
	private static final long serialVersionUID = -1055001458012850147L;
	
	private Long id;//分组parentUserId
	private Long countOrderNum;//订单总数
	private Long sumPriceTotal;//订单实付总额  单位:分
	private Long sumAwardMoney;//提奖总额 单位:分
	private Long sumCommMoney;//佣金总额 单位:分
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCountOrderNum() {
		return countOrderNum;
	}
	public void setCountOrderNum(Long countOrderNum) {
		this.countOrderNum = countOrderNum;
	}
	public Long getSumPriceTotal() {
		return sumPriceTotal;
	}
	public void setSumPriceTotal(Long sumPriceTotal) {
		this.sumPriceTotal = sumPriceTotal;
	}
	public Long getSumAwardMoney() {
		return sumAwardMoney;
	}
	public void setSumAwardMoney(Long sumAwardMoney) {
		this.sumAwardMoney = sumAwardMoney;
	}
	public Long getSumCommMoney() {
		return sumCommMoney;
	}
	public void setSumCommMoney(Long sumCommMoney) {
		this.sumCommMoney = sumCommMoney;
	}
	
}
