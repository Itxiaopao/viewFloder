package com.gome.meidian.service.util;

import com.gome.meidian.enums.OrderFullStatus;
import com.gome.meidian.enums.OrderShowStatus;

/**
 * 美店订单状态工具类
 */
public class OrderStatusUtil {

    /**
     * 订单中心订单状态转美店显示状态
     *
     * @param status 订单中心状态
     * @return
     */
    public static Integer getShowStatus(Integer status) {
        if (status == null) {
            return null;
        }
        if (OrderFullStatus.Wait_Pay_Order.getStatus().equals(status) || OrderFullStatus.Wait_Pay_Deposit.getStatus().equals(status)) {
            return OrderShowStatus.Wait_Pay.getStatus();
        } else if (OrderFullStatus.Effect.getStatus().equals(status)) {
            return OrderShowStatus.Effect.getStatus();
        } else if (OrderFullStatus.Canced.getStatus().equals(status)) {
            return OrderShowStatus.Canced.getStatus();
        } else if (OrderFullStatus.Payed.getStatus().equals(status)) {
            return OrderShowStatus.Payed.getStatus();
        } else if (OrderFullStatus.Order_OutStock.getStatus().equals(status)) {
            return OrderShowStatus.Wait_Received.getStatus();
        } else {
            return OrderShowStatus.After_Sale.getStatus();
        }
    }
}
