package com.gome.meidian.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class MeidianBangbangCalcProfit implements Serializable {

    private static final long serialVersionUID = -3309576131214014340L;

    private Long id;//主键id
    private Long upUserId;//上级用户id
    private Long userId;//下单用户id
    private String orderId;//订单id
    private Date insertTime;//创建时间

}