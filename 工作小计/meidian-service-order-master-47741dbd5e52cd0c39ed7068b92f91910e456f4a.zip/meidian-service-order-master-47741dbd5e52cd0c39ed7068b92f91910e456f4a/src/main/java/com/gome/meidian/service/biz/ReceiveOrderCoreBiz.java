package com.gome.meidian.service.biz;

import cn.com.gome.rebate.calc.CouponsDto;
import cn.com.gome.rebate.calc.Delivery;
import cn.com.gome.rebate.calc.GoodsDto;
import cn.com.gome.rebate.calc.OrderDto;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.gome.framework.base.ResultDTO;
import com.gome.meidian.dao.MogErrOrderBodyDao;
import com.gome.meidian.entity.CouponVo;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.enums.OrderFullStatus;
import com.gome.meidian.enums.OrderShowStatus;
import com.gome.meidian.service.factory.OmsOrderFactory;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.util.CouponUtils;
import com.gome.meidian.vo.MeidianUserInfoDTO;
import com.gome.meidian.vo.MogErrOrderBody;
import com.gome.meidian.vo.MogOrderInfo;
import com.gome.pangu.promotionapply.client.coupongive.CouponGiveQueryService;
import com.gome.pangu.promotionapply.client.coupongive.dto.CouponGiveParamDTO;
import com.gome.pangu.promotionapply.client.coupongive.dto.CouponGiveResultDTO;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Slf4j
@Component
public class ReceiveOrderCoreBiz implements OmsOrderFactory {

    @Autowired
    private MogErrOrderBodyDao mogErrOrderBodyDao;
    @Autowired
    private ReceiveOrderBiz receiveOrderBiz;
    @Autowired
    private MedianUserBiz medianUserBiz;
    @Autowired
    private ReceiveOrderBodyBiz receiveOrderBodyBiz;
    @Autowired
    private CouponUtils couponUtils;
    @Autowired
    private CouponGiveQueryService couponGiveQueryService;
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private IUserShareBindingManager userShareBindingManager;
    @Autowired
    private RaceAsynConsumeOrder raceAsynConsumeOrder;
    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;

    /**
     * 订单消息处理入口
     *
     * @param msgId  消息id
     * @param object 消息体
     */
    public void processOrder(String msgId, String object) {
        StringBuilder logContent = new StringBuilder(256);
        try {
            OrderDto orderDto = JSONObject.parseObject(object, OrderDto.class);
            if (orderDto == null || StringUtils.isEmpty(orderDto.getUserId()) || CollectionUtils.isEmpty(orderDto.getDeliveryList())) {
                logContent.append("美店订单消费失败,原因:必要参数为空,msgId:").append(msgId).append(",msgBody:").append(JSON.toJSON(orderDto));
                return;
            }
            //解析订单状态
            List<Delivery> deliveryList = orderDto.getDeliveryList();
            Integer status = deliveryList.get(0).getStatus();
            //订单级别的消息体
            if (OrderFullStatus.getWaitPayOperateStatus().contains(status)) {
                MeidianUserInfoDTO userInfo = medianUserBiz.getUserInfo(Long.valueOf(orderDto.getUserId()));
                if (userInfo == null) {
                    logContent.append("美店待支付订单消费失败,原因:沒有查到用戶,msgId:").append(msgId).append(",userId:").append(orderDto.getUserId()).append(",orderId:").append(orderDto.getOrderId());
                    return;
                }
                //记录订单级别消息
                for (Delivery delivery : deliveryList) {
                    receiveOrderBodyBiz.saveOrderBody(msgId, object, orderDto, delivery);
                    logContent.append("美店待支付订单消费成功,msgId:").append(msgId).append(",userId:").append(orderDto.getUserId()).append(",orderId:").append(orderDto.getOrderId())
                            .append(",orderStatus:").append(delivery.getStatus()).append(OrderFullStatus.valueOf(delivery.getStatus()));
                }
                return;
            }
            logContent.append("开始分析拆单后订单,msgId:").append(msgId).append(",userId:").append(orderDto.getUserId()).append(",orderId:").append(orderDto.getOrderId());
            //配送单级别的消息体
            for (int i = 0; i < deliveryList.size(); i++) {
                //是否收集配送单消息体
                boolean isCollect = Boolean.FALSE;
                Delivery delivery = deliveryList.get(i);
                Integer orderStatus = delivery.getStatus();
                List<GoodsDto> goodsList = delivery.getGoodsList();
                logContent.append(",deliveryId:").append(delivery.getDeliveryOrderId()).append(",orderStatus:").append(orderStatus).append(OrderFullStatus.valueOf(orderStatus));
                for (GoodsDto goodsDto : goodsList) {
                    logContent.append(",skuId:").append(goodsDto.getSkuId());
                    //已支付订单状态
                    if (OrderFullStatus.Payed.getStatus().equals(orderStatus)) {
                        //1.判断是否美店订单
                        MeidianUserInfoDTO userInfo = checkMeiDianOrder(Long.valueOf(orderDto.getUserId()), goodsDto, logContent);
                        if (userInfo == null) {
                            logContent.append(",消费失败,原因:非美店订单不受理此SKU");
                            continue;
                        }
                        logContent.append("商品级用户关系:").append(userInfo.getShareChain());
                        //2.模型转换
                        MogOrderInfo orderOccur = receiveOrderBiz.buildMogOrderInfo(orderDto, delivery, goodsDto);
                        receiveOrderBiz.addOrderInfo(orderOccur, userInfo);
                        //3.更新下单人 首单忠粉
                        if (i == deliveryList.size() - 1) {
                            ResultEntity result = medianUserBiz.updateUserType(userInfo);
                            logContent.append(",更新用户身份:").append(JSON.toJSONString(result, new SimplePropertyPreFilter(ResultEntity.class, "code", "message")));
                        }
                        //处理竞赛
                        checkSaleRace(orderOccur, userInfo, 1);
                        isCollect = Boolean.TRUE;
                    } else {
                        //判断是否有已支付订单
                        MogOrderInfo mogOrderInfo = receiveOrderBiz.getOrderInfoById(Long.valueOf(orderDto.getOrderId()), goodsDto.getSkuId(), delivery.getDeliveryOrderId());
                        if (mogOrderInfo == null) {
                            logContent.append(",美店订单消费失败,原因:没有已支付订单");
                            continue;
                        }
                        //库里订单状态
                        Integer oldOrderStatus = mogOrderInfo.getOrderStatus();
                        mogOrderInfo.setOrderStatus(orderStatus);
                        if (OrderFullStatus.Payed.getStatus().equals(oldOrderStatus) && OrderFullStatus.Canced.getStatus().equals(orderStatus)) {
                            //原 已支付 → 现 取消单
                            mogOrderInfo.setShowStatus(OrderShowStatus.Canced.getStatus());
                            receiveOrderBiz.updateOrderInfo(mogOrderInfo);
                            isCollect = Boolean.TRUE;
                            checkSaleRace(mogOrderInfo, null, 2);
                        } else if (OrderFullStatus.Payed.getStatus().equals(oldOrderStatus) && OrderFullStatus.Order_OutStock.getStatus().equals(orderStatus)) {
                            //原 已支付 → 现 配送单出库
                            mogOrderInfo.setShowStatus(OrderShowStatus.Wait_Received.getStatus()); //待收货
                            receiveOrderBiz.updateOrderInfo(mogOrderInfo);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Order_OutStock.getStatus().equals(oldOrderStatus) && OrderFullStatus.Effect.getStatus().equals(orderStatus)) {
                            //原 配送单出库 → 现妥投
                            mogOrderInfo.setShowStatus(OrderShowStatus.Effect.getStatus());
                            receiveOrderBiz.updateOrderInfo(mogOrderInfo);
                            isCollect = Boolean.TRUE;
                        } else if (OrderFullStatus.Order_OutStock.getStatus().equals(oldOrderStatus) && OrderFullStatus.Resfuesd_Revice.getStatus().equals(orderStatus)) {
                            //原 配送单出库 → 现已拒收
                            mogOrderInfo.setShowStatus(OrderShowStatus.After_Sale.getStatus()); //设置为售后
                            receiveOrderBiz.updateOrderInfo(mogOrderInfo);
                            isCollect = Boolean.TRUE;
                            checkSaleRace(mogOrderInfo, null, 2);
                        } else if (OrderFullStatus.Effect.getStatus().equals(oldOrderStatus) && OrderFullStatus.Back_Apply.getStatus().equals(orderStatus)) {
                            //原 妥投 → 现退货申请
                            mogOrderInfo.setShowStatus(OrderShowStatus.After_Sale.getStatus()); //已支付状态
                            receiveOrderBiz.updateOrderInfo(mogOrderInfo);
                            isCollect = Boolean.TRUE;
                            checkSaleRace(mogOrderInfo, null, 2);
                        } else if (OrderFullStatus.Effect.getStatus().equals(oldOrderStatus) && OrderFullStatus.Exchange_Apply.getStatus().equals(orderStatus)) {
                            //原 妥投 → 现换货申请
                            mogOrderInfo.setShowStatus(OrderShowStatus.After_Sale.getStatus()); //换货售后状态
                            receiveOrderBiz.updateOrderInfo(mogOrderInfo);
                            isCollect = Boolean.TRUE;
                        }
                    }
                }
                //收集配送单消息
                if (isCollect) {
                    receiveOrderBodyBiz.saveDeliveryOrderBody(msgId, object, orderDto, delivery);
                }
                logContent.append(",消费成功,是否美店订单:").append(isCollect);
            }
        } catch (Exception e) {
            log.error(logContent.append(",订单消费发生异常,异常堆栈如下:").toString(), e);
            throw e;
        } finally {
            log.info(logContent.toString());
        }

    }

    /**
     * 检验是否是美店订单
     *
     * @param orderUserId 下单人
     * @param goodsDto
     * @return
     */
    public MeidianUserInfoDTO checkMeiDianOrder(Long orderUserId, GoodsDto goodsDto, StringBuilder logContent) {
        Long shareUserId = StringUtils.isNumeric(goodsDto.getRetailId()) ? Long.parseLong(goodsDto.getRetailId()) : null;
        MeidianUserInfoDTO userinfo = new MeidianUserInfoDTO();
        userinfo.setUserId(orderUserId);
        HashMap<Long, VshopInfo> longVshopInfoHashMap = checkUserTypeFromVshop(orderUserId, shareUserId);
        if (longVshopInfoHashMap.containsKey(orderUserId)) {
            VshopInfo vshopInfo = longVshopInfoHashMap.get(orderUserId);
            userinfo.setIdentityType(vshopInfo.getVshopIdentity());
        } else {
            userinfo.setIdentityType(0);
        }
        //取分享
        if (shareUserId != null && longVshopInfoHashMap.containsKey(shareUserId)) {
            logContent.append(",根据分享人判断");
            VshopInfo vshopInfo = longVshopInfoHashMap.get(shareUserId);
            userinfo = dealWithUserInfo(vshopInfo, shareUserId, userinfo);
            return userinfo;
        }
        if (null != goodsDto.getCouponsDtoList()) {
            logContent.append(",根据券转增记录判断");
            List<CouponsDto> couponsDtoList = goodsDto.getCouponsDtoList();
            if (couponsDtoList.size() == 0) {
                return null;
            }
            List<CouponVo> couponVos = dealWithGoodsCoupons(couponsDtoList);
            Map<Integer, CouponGiveParamDTO> integerCouponGiveParamDTOMap = couponUtils.filterCouponVoList(couponVos);
            Iterator<Integer> iterator = integerCouponGiveParamDTOMap.keySet().iterator();
            while (iterator.hasNext()) {
                Integer next = iterator.next();
                CouponGiveParamDTO couponGiveParamDTO = integerCouponGiveParamDTOMap.get(next);
                //下单人userId
                couponGiveParamDTO.setUserId(String.valueOf(orderUserId));
                //一个type,对个券ID,返回多个券ID的集合
                ResultDTO<List<CouponGiveResultDTO>> listResultDTO = couponGiveQueryService.queryCouponGiveInfo(couponGiveParamDTO);
                logContent.append("券类型:").append(next).append(",促销组接口返回:").append(JSON.toJSON(listResultDTO));
                if (null != listResultDTO && CollectionUtils.isNotEmpty(listResultDTO.getData())) {
                    //最终转赠的店主用户ID
                    Long transferUserId = couponUtils.filterCouponGiveResultDTO(listResultDTO.getData());
                    CommonResultEntity<VshopInfo> vshopRtnEntity = vshopFacade.queryVshopByuserId(String.valueOf(transferUserId));
                    if (null != vshopRtnEntity && vshopRtnEntity.getBusinessObj() != null) {
                        VshopInfo vshopInfo = vshopRtnEntity.getBusinessObj();
                        userinfo = dealWithUserInfo(vshopInfo, vshopInfo.getUserId(), userinfo);
                        return userinfo;
                    }
                }
            }

        }
        if (userinfo.getUpUserId() == null || userinfo.getPianUserId() == null || userinfo.getIdentityType() == null || userinfo.getShareChain() == null) {
            logContent.append(",根据下单人用户关系判断");
            MeidianUserInfoDTO bindingRtn = medianUserBiz.getUserInfo(orderUserId);
            return bindingRtn;
        }
        return userinfo;

    }

    /**
     * 处理购买者和分享用户的身份关系
     *
     * @param orderUserId
     * @param shareUserId 可为空
     * @return
     */
    public HashMap<Long, VshopInfo> checkUserTypeFromVshop(Long orderUserId, Long shareUserId) {
        HashSet<Long> userIds = new HashSet<Long>(2);
        HashMap<Long, VshopInfo> rtnHashMap = new HashMap<Long, VshopInfo>(2);
        userIds.add(orderUserId);
        if (null != shareUserId) {
            userIds.add(shareUserId);
        }
        CommonResultEntity<List<VshopInfo>> listCommonResultEntity = vshopFacade.batchQueryVshopByUserIds(userIds);
        if (null != listCommonResultEntity) {
            List<VshopInfo> vshopInfos = listCommonResultEntity.getBusinessObj();
            if (null != vshopInfos && vshopInfos.size() > 0) {
                for (VshopInfo vshopInfo : vshopInfos) {
                    rtnHashMap.put(vshopInfo.getUserId(), vshopInfo);
                }
            }
        }
        return rtnHashMap;
    }

    /**
     * 转换券对象
     *
     * @param couponsDtoList 订单入参券list
     * @return 返回指定类型的list
     */
    public List<CouponVo> dealWithGoodsCoupons(List<CouponsDto> couponsDtoList) {
        List<CouponVo> couponVos = new ArrayList<CouponVo>(couponsDtoList.size());
        for (CouponsDto thisCoupon : couponsDtoList) {
            CouponVo couponVo = new CouponVo();
            couponVo.setTicketId(thisCoupon.getTicketId());
            couponVo.setCouponType(thisCoupon.getCouponType());
            couponVo.setCouponId(thisCoupon.getCouponId());
            couponVos.add(couponVo);
        }
        return couponVos;
    }

    /**
     * 抽象出拼装返回userInfo的参数
     *
     * @param vshopInfo   美店主对象信息
     * @param shareUserId 分享人的userId
     * @param userInfo    返回的userInfo
     * @return
     */
    public MeidianUserInfoDTO dealWithUserInfo(VshopInfo vshopInfo, Long shareUserId, MeidianUserInfoDTO userInfo) {
        if (vshopInfo.getVshopIdentity().equals(3)) {
            //没有userType
            userInfo.setUpUserId(vshopInfo.getUserId());
            userInfo.setPianUserId(vshopInfo.getUserId());
            ArrayList<Long> shareChain = new ArrayList<>();
            shareChain.add(vshopInfo.getUserId());
            userInfo.setShareChain(shareChain);
        } else {
            MeidianUserInfoDTO bindingRtn = medianUserBiz.getUserInfo(shareUserId);
            userInfo.setUpUserId(bindingRtn.getUpUserId());
            userInfo.setPianUserId(bindingRtn.getPianUserId());
            userInfo.setUpUserId(bindingRtn.getUpUserId());
            userInfo.setShareChain(bindingRtn.getShareChain());
        }
        MShopShareBindingDto mShopShareBindingDto = checkOrderAndShare(userInfo.getUserId(), shareUserId);
        if (null != mShopShareBindingDto) {
            userInfo.setUserType(mShopShareBindingDto.getType());
        }
        return userInfo;
    }

    /**
     * 校验下单人与分享人（全转增人）的关系
     *
     * @param orderUserId
     * @param shareUserId
     */
    public MShopShareBindingDto checkOrderAndShare(Long orderUserId, Long shareUserId) {
        HashMap<String, Object> requestMap = new HashMap<>();
        requestMap.put("userId", orderUserId);
        requestMap.put("upUserId", shareUserId);
        List<MShopShareBindingDto> mShopShareBindingDtos = userShareBindingManager.queryListByParam(requestMap);
        if (null != mShopShareBindingDtos && mShopShareBindingDtos.size() > 0) {
            return mShopShareBindingDtos.get(0);
        }
        return null;
    }

    /**
     * 保存异常消息体
     *
     * @param msgBody 消息体
     */
    public void exCallback(String msgId, String msgBody) {
        try {
            OrderDto orderDto = JSONObject.parseObject(msgBody, OrderDto.class);
            List<Delivery> deliveryList = orderDto.getDeliveryList();
            if (CollectionUtils.isEmpty(deliveryList)) {
                return;
            }
            for (Delivery delivery : deliveryList) {
                MogErrOrderBody record = new MogErrOrderBody();
                record.setMsgId(msgId);
                record.setOrderId(Long.parseLong(orderDto.getOrderId()));
                record.setDeliveryId(delivery.getDeliveryOrderId());
                record.setOrderStatus(delivery.getStatus());
                record.setUserId(Long.parseLong(orderDto.getUserId()));
                record.setMsgBody(msgBody);
                record.setOrderTime(orderDto.getOrderDate());
                mogErrOrderBodyDao.saveRecord(record);
            }
        } catch (Exception e) {
            String format = String.format("保存异常订单消息体发生异常,入参:%s,异常堆栈如下", JSON.toJSONString(msgBody, new SimplePropertyPreFilter(MessageExt.class, "msgId", "body")));
            log.error(format, e);
        }
    }

    /**
     * 校验并处理销售竞赛
     *
     * @param orderOccur 订单用户对象
     * @param userInfo   用户对象
     * @param type       1 表示正向  2 表示逆向
     */
    private void checkSaleRace(MogOrderInfo orderOccur, MeidianUserInfoDTO userInfo, int type) {
        try {
            if (!checkSaleRaceUtils.checkActivityIsEffective()) {
                return;
            }
            raceAsynConsumeOrder.dealWithSaleRace(orderOccur, userInfo, type);
        } catch (Exception e) {
            log.info("消费订单处理销售竞赛异常", e);
        }
    }
}
