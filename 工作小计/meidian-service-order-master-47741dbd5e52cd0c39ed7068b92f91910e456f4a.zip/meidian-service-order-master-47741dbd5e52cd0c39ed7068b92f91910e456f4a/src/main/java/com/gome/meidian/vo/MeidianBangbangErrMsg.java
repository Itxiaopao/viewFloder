package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class MeidianBangbangErrMsg implements Serializable {

    private static final long serialVersionUID = -3913015854191678339L;

    private Long id;//主键id
    private String profileId;//购买人id
    private String orderId;//订单id
    private String shippingGroupId;//配送单id
    private String gomeState;//订单状态
    private String msgId;//消息id
    private String msgBody;//消息体
    private String errMsg;//错误信息
    private Date insertTime;//创建时间

}