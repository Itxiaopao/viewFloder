package com.gome.meidian.service.biz;

import com.gome.meidian.constant.Constant;
import com.gome.meidian.enums.EmployeeTypeEnum;
import com.gome.meidian.service.util.SaleRaceTask;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MeidianUserInfoDTO;
import com.gome.meidian.vo.MogOrderInfo;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import redis.Gcache;

import java.util.Date;

@Slf4j
@Component
public class RaceAsynConsumeOrder {
    @Autowired
    private ReceiveOrderBiz receiveOrderBiz;
    @Autowired
    private SaleRaceTask saleRaceTask;
    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;
    @Autowired
    private Gcache gcache;
    @Autowired
    private EmployeeBiz employeeBiz;

    /**
     *
     * @param orderOccur
     * @param userInfo
     * @param type  1:正向  2:逆向
     */
    @Async
    public void dealWithSaleRace(MogOrderInfo orderOccur, MeidianUserInfoDTO userInfo, int type){
        if(checkRepeatConosumeSaleMessage(orderOccur)){
            log.info("校验已处理过该订单");
//            log.info("测试暂不处理");
            return;
        }
        firstOrPutRepeat(orderOccur);
        Date orderCreationTime = orderOccur.getOrderTime();
        //添加订单创建时间为空的处理
        if(!checkSaleRaceUtils.checkIsActivityTime(orderCreationTime)){
            return;
        }
        MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
        Long upOrLeaderUserId = checkUserIdentity(orderOccur);
        log.info("店主竞赛消费订单,积分用户为:{},orderId:{},deliveryId:{},skuId:{}",upOrLeaderUserId,orderOccur.getOrderId(),orderOccur.getDeliveryId(),orderOccur.getSkuId());
        if(type == 1){
            //正向
            log.info("获取订单创建时间:{}",orderCreationTime);
            mogRaceUserInfo.setUserId(upOrLeaderUserId);
            mogRaceUserInfo.setSaleVolume(orderOccur.getPriceTotal());
        }else{
            if(!checkSaleRaceUtils.checkSuspendTime(orderOccur.getOrderTime())){
                return;
            }
            //逆向
            mogRaceUserInfo.setUserId(upOrLeaderUserId);
            long priceTotal = orderOccur.getPriceTotal();
            mogRaceUserInfo.setSaleVolume(priceTotal * -1);
        }
        saleRaceTask.run(mogRaceUserInfo);
    }

    /**
     * 校验身份处理
     * @param orderOccur
     */
    public Long checkUserIdentity(MogOrderInfo orderOccur){
        String employeeType = employeeBiz.getEmployeeType(orderOccur.getParentUserId());
        if(null != employeeType && EmployeeTypeEnum.hlwl.name().equals(employeeType)){
            return orderOccur.getParentUserId();
        }
        return orderOccur.getUserIdPZ();
    }
    /**
     * 避免处理同一个订单缓存处理
     * @param mogOrderInfo
     */
    public void firstOrPutRepeat(MogOrderInfo mogOrderInfo){
        log.info("正向支付的时候存缓存，避免重复消费orderId:{},deliveryId:{},skuId:{},orderStatus:{}",mogOrderInfo.getOrderId(),mogOrderInfo.getDeliveryId(),mogOrderInfo.getSkuId(),mogOrderInfo.getOrderStatus());
        String priventKey = Constant.SALE_RACE_PREVENT_REPEAT_ORDER + mogOrderInfo.getOrderId() + "_" + mogOrderInfo.getDeliveryId() + "_" + mogOrderInfo.getSkuId() + "_" + mogOrderInfo.getOrderStatus();
        gcache.set(priventKey,String.valueOf(System.currentTimeMillis()));
        gcache.expire(priventKey,Constant.SECONDS_IN_GCACHE_ONEMONTH);
    }
    /**
     * 正向单的时候需要处理缓存避免重复消费
     * @param mogOrderInfo
     * @return
     */
    public boolean checkRepeatConosumeSaleMessage(MogOrderInfo mogOrderInfo){
        String priventKey = Constant.SALE_RACE_PREVENT_REPEAT_ORDER + mogOrderInfo.getOrderId() + "_" + mogOrderInfo.getDeliveryId() + "_" + mogOrderInfo.getSkuId() + "_" + mogOrderInfo.getOrderStatus();
        String s = gcache.get(priventKey);
        if(StringUtils.isBlank(s)){
            log.info("校验缓存里面的这单不是重复处理orderId:{},deliveryId:{},skuId:{},orderStatus:{}",mogOrderInfo.getOrderId(),mogOrderInfo.getDeliveryId(),mogOrderInfo.getSkuId(),mogOrderInfo.getOrderStatus());
            return false;
        }
        return true;
    }

}
