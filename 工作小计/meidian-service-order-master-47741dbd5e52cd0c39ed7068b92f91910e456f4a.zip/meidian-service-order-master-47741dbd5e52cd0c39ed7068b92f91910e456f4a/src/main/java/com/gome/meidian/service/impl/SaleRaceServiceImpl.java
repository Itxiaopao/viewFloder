package com.gome.meidian.service.impl;

import com.gome.meidian.dao.MogRaceUserInfoDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.UserRaceVo;
import com.gome.meidian.service.ISaleRaceService;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

/**
 * 销售竞赛
 * @author chenchen-ds6
 */
@Slf4j
@Service
public class SaleRaceServiceImpl implements ISaleRaceService {
    @Autowired
    private MogRaceUserInfoDao mogRaceUserInfoDao;
    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;
    @Override
    public ResultEntity<Map<String,Object>> queryRaceTopN(Long userId, int pageNum, int pageSize){
        if(pageNum <= 0){
            pageNum = 1;
        }
        if(pageSize <= 0){
            pageSize = 10;
        }
        ResultEntity<Map<String, Object>> mapResultEntity = new ResultEntity<>();
        HashMap<String, Object> rtnHashMap = new HashMap<>(2);
        ArrayList<UserRaceVo> userRaceVos = new ArrayList<>(10);
        ResultEntity<MogRaceUserInfo> mogRaceUserInfoResultEntity = mogRaceUserInfoDao.queryByUserId(userId);
        if(mogRaceUserInfoResultEntity != null && mogRaceUserInfoResultEntity.getBusinessObj() != null){
            MogRaceUserInfo self = mogRaceUserInfoResultEntity.getBusinessObj();
            Long saleVolume = self.getSaleVolume() == null ? 0 : self.getSaleVolume() / 100;
            UserRaceVo userRaceVo = new UserRaceVo();
            BeanUtils.copyProperties(self,userRaceVo);
            //换算单位
            userRaceVo.setSaleVolume(saleVolume);
            userRaceVo.setRanking(queryRaceSelf(userId));
            rtnHashMap.put("self",userRaceVo);
        }else{
            //库里面没有数据
            UserRaceVo userRaceVo = new UserRaceVo();
            userRaceVo.setUserId(userId);
            rtnHashMap.put("self",userRaceVo);
        }
        ResultEntity<List<MogRaceUserInfo>> listResultEntity = mogRaceUserInfoDao.queryList(pageNum, pageSize);
        List<MogRaceUserInfo> businessObj = listResultEntity.getBusinessObj();
        if(null != businessObj) {
            for (int i = 0, j = businessObj.size();i < j; i++) {
                MogRaceUserInfo mogRaceUserInfo = businessObj.get(i);
                Long saleVolume = mogRaceUserInfo.getSaleVolume() / 100;
                UserRaceVo userRaceVo = new UserRaceVo();
                BeanUtils.copyProperties(mogRaceUserInfo, userRaceVo);
                userRaceVo.setRanking((pageNum - 1) * pageSize + i + 1);
                //换算单位
                userRaceVo.setSaleVolume(saleVolume);
                userRaceVos.add(userRaceVo);
                rtnHashMap.put("ranking", userRaceVos);
            }
        }
        mapResultEntity.setBusinessObj(rtnHashMap);
        return mapResultEntity;
    }

    /**
     * 获取距离活动开始时间的毫秒数
     * @return
     */
    @Override
    public ResultEntity<Map<String, Long>> queryActivityCountdown() {
        ResultEntity<Map<String, Long>> mapResultEntity = new ResultEntity<>();
        HashMap<String, Long> rtnHashMap = new HashMap<>(1);
        Date activityBeginTime = checkSaleRaceUtils.getActivityBeginTime();
        long beginTime = activityBeginTime.getTime();
        long currentTimeMillis = System.currentTimeMillis();
        if(beginTime > currentTimeMillis){
            rtnHashMap.put("timeMillis",beginTime-currentTimeMillis);
        }else{
            rtnHashMap.put("timeMillis",0L);
        }
        mapResultEntity.setBusinessObj(rtnHashMap);
        return mapResultEntity;
    }

    /**
     * 查询自己的排名
     * @param userId
     * @return
     */
    public  Integer queryRaceSelf(Long userId){
        log.info("查询当前userId:{}的排名",userId);
        ResultEntity<List<MogRaceUserInfo>> listResultEntity = mogRaceUserInfoDao.queryList(0, 100);
        Integer rtnCode = 0;
        if(null != listResultEntity && listResultEntity.getBusinessObj() != null){
            List<MogRaceUserInfo> businessObj = listResultEntity.getBusinessObj();
            if(null == businessObj){
                rtnCode = 0;
            }
            for(int i = 0 , j = businessObj.size() ; i < j ; i++){
                MogRaceUserInfo mogRaceUserInfo = businessObj.get(i);
                if(mogRaceUserInfo.getUserId().equals(userId)){
                    rtnCode = i+1;
                }
            }
        }
        return rtnCode;
    }
}
