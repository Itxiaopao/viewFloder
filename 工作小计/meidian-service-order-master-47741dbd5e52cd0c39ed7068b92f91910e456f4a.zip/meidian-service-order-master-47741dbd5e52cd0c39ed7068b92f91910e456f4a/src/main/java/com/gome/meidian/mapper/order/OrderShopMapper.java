package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderShopSame;
import com.gome.meidian.vo.OrgnizationVo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;
import java.util.Map;

/**
 *订单收单  mapper
 * @author zhangwei-ds19
 *
 */
public interface OrderShopMapper extends  BaseMapper<OrderShopSame> {

	@Select("select count(*) from order_shop_same where shop_id = #{parentCode}")
	int selectByDateRange(long parentCode);

	@Update("<script>"
			+ "update order_shop_same "
			+ "<set>"
			+ "<if test='shopName != null'>"
			+ "shop_name=#{shopName},"
			+ "</if>"
			+ "<if test='userId != null'>"
			+ "user_id=#{userId},"
			+ "</if>"
			+ "<if test='newUserId != null'>"
			+ "new_user_id=#{newUserId},"
			+ "</if>"
			+ "<if test='userName != null'>"
			+ "user_name=#{userName},"
			+ "</if>"
			+ "<if test='regionId != null'>"
			+ "region_id=#{regionId},"
			+ "</if>"
			+ "<if test='regionName != null'>"
			+ "region_name=#{regionName},"
			+ "</if>"
			+ "<if test='branchId != null'>"
			+ "branch_id=#{branchId},"
			+ "</if>"
			+ "<if test='branchName != null'>"
			+ "branch_name=#{branchName},"
			+ "</if>"
			+ "<if test='branchSecondId != null'>"
			+ "branch_second_id=#{branchSecondId},"
			+ "</if>"
			+ "<if test='branchSecondName != null'>"
			+ "branch_second_name=#{branchSecondName},"
			+ "</if>"
			+ "<if test='storeId != null'>"
			+ "store_id=#{storeId},"
			+ "</if>"
			+ "<if test='storeName != null'>"
			+ "store_name=#{storeName},"
			+ "</if>"
			+ "<if test='staffPostName != null'>"
			+ 	"staff_post_name=#{staffPostName},"
			+ "</if>"
			+ "<if test='status != null'>"
			+ "status=#{status},"
			+ "</if>"
			+ "<if test='organizationCode != null'>"
			+ "organization_code=#{organizationCode},"
			+ "</if>"
			+ " utime = now() "
			+ "</set>"
			+ " where shop_id = #{shopId}"
			+ "</script>")
	int updateOrder(OrderShopSame orderShopSame);

	@Insert({"INSERT INTO order_shop_same "
			+ "(shop_id,shop_name,user_id, new_user_id,user_name,region_id,region_name,branch_id,branch_name,branch_second_id,branch_second_name,"
			+ "store_id,store_name,staff_post_name,status,organization_code,utime, ctime)"
			+ "values (#{shopId},#{shopName},#{userId},#{newUserId},#{userName},#{regionId},#{regionName},#{branchId},"
			+ "#{branchName},#{branchSecondId},#{branchSecondName},#{storeId},#{storeName},#{staffPostName},#{status},"
			+ "#{organizationCode},now(),now())"})
	int insertOrder(OrderShopSame orderShopSame);

	@Select("select region_id as code,region_name as name from order_shop_same GROUP BY region_id")
	List<OrgnizationVo> getFirstLevel();

	@Select("select branch_id as code,branch_name as name,branch_id as parentCode from order_shop_same where region_id = #{parentCode} GROUP BY branch_id")
	List<OrgnizationVo> getSecondLevel(String parentCode);

	@Select("select branch_second_id as code,branch_second_name as name,branch_second_id as parentCode from order_shop_same where branch_id = #{parentCode} GROUP BY branch_second_id")
	List<OrgnizationVo> getThirdLevel(String parentCode);

	@Select("select * from order_shop_same where new_user_id = #{newUserId}")
	List<OrderShopSame> selectByNewUserId(long newUserId);

	@Select("select * from order_shop_same")
	List<OrderShopSame> selectAll();

	@Select("select * from order_shop_same limit #{offSet},#{pageSize}")
	List<OrderShopSame> selectAllLimit(Map<String, Object> map);

	@Select("select count(*) from order_shop_same ")
	int selectAllCount();



	@Select("select * from order_shop_same where branch_id = #{branchId}")
	List<OrderShopSame> selectByBranchId(@Param("branchId")String branchId);


	@Select("SELECT * from order_shop_same WHERE branch_id <> \"\" GROUP BY branch_id")
	List<OrderShopMapper> selectAllByBranchId();

	@Select({"<script>",
			"SELECT",
			"shop_id,shop_name,user_id,new_user_id,user_name,",
			"region_id,region_name,branch_id,branch_name,branch_second_id,",
			"branch_second_name,store_id,store_name,status,ctime,utime,staff_post_name",
			"FROM order_shop_same",
			"<where>",
			"<if test='shopId != null'> and shop_id = #{shopId} </if>",
			"<if test='newUserId != null'> and new_user_id = #{newUserId} </if>",
			"</where>",
			"</script>"})
	List<OrderShopSame> selectByBiz(@Param("shopId") Long shopId, @Param("newUserId") Long newUserId);
}
