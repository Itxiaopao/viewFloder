package com.gome.meidian.service.biz;

import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.config.aspect.annotation.Cacheable;
import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.constant.Constant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;


/**
 * 员工业务类
 */
@Slf4j
@Component
public class EmployeeBiz {

    @Autowired
    private RestTemplate restTemplate;

    /**
     * 员工品牌http地址
     */
    @Value("${http.employeeBrand.url}")
    private String employeeBrandUrl;

    /**
     * 员工身份http地址
     */
    @Value("${http.employeeType.url}")
    private String employeeTypeUrl;

    /**
     * 根据员工SAP编码获取员工品牌
     *
     * @param sap 员工sap编码，服务降级，默认为null
     * @return
     */
    @SneakyLog("根据员工SAP编码获取员工品牌")
    public List<Object> getEmployeeBrandBySap(String sap) {
        String param = String.format("{\"GM_FUNC\":\"GETTRADEMARK\",\"GM_ID\":\"TRADEMARK\",\"GM_PARAM\":{\"USERKEY\": \"%s\"}}", sap);
        HttpEntity<String> entity = new HttpEntity<>(param, null);
        try {
            JSONObject jsonObject = restTemplate.postForObject(employeeBrandUrl, entity, JSONObject.class);
            JSONObject restPostRsp = jsonObject.getJSONObject("REST_POST_RSP");
            if (restPostRsp == null) {
                return null;
            }
            JSONObject gmResponse = JSONObject.parseObject(restPostRsp.getString("GM_RESPONSE"));
            if (!"0".equals(gmResponse.getString("msg_code"))) {
                log.error("调用DHR接口失败，接口返回值:{}", restPostRsp.getString("GM_RESPONSE"));
                return null;
            }
            return gmResponse.getJSONArray("data");
        } catch (Exception e) {
            String format = String.format("调用DHR接口发生异常,入参:%s,异常堆栈如下", sap);
            log.error(format, e);
            return null;
        }
    }

    @Cacheable(value = "获取员工类型", prefix = Constant.EMPLOYEE_TYPE_HASH_CACHE_PREFIX, suffix = "#userId", seconds = Constant.SECONDS_IN_GCACHE_ONEHOUR * 2)
    public String getEmployeeType(Long userId) {
        try {
            JSONObject result = restTemplate.getForObject(employeeTypeUrl, JSONObject.class, userId);
            if (result.getIntValue("code") != 200) {
                log.info("调用无线接口成功,但反回结果不是200，入参:userId:{},详情如下:{}", userId, result.getString("msg"));
                return null;
            }
            return result.getJSONObject("data").getString("type");
        } catch (Exception e) {
            log.error("调用无线接口失败，服务异常，异常堆栈如下", e);
            return null;
        }
    }

}
