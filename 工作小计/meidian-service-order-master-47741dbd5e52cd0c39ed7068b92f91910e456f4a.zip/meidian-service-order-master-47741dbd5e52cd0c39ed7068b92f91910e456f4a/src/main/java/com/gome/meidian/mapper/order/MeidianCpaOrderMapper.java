package com.gome.meidian.mapper.order;

import com.gome.meidian.vo.MeidianCpaOrder;

import java.util.List;
import java.util.Map;

public interface MeidianCpaOrderMapper {

    int insert(MeidianCpaOrder record);

    int update(MeidianCpaOrder record);

    int delete(Long id);

    List<MeidianCpaOrder> selectListByBiz(Map<String, Object> map);

    List<String> selectDeliveryIdListByBiz(Map<String, Object> map);

    Long selectSumPriceByBiz(Map<String, Object> map);

    MeidianCpaOrder selectOneByBiz(Map<String, Object> map);
}