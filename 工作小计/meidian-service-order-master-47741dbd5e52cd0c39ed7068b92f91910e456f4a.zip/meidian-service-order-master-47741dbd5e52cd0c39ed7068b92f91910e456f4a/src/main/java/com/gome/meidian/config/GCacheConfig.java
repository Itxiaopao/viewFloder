package com.gome.meidian.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.Gcache;
import redis.GcacheClient;

@Configuration
public class GCacheConfig {
	
	@Value("${gCache.address}")
	private String zk;
	@Value("${gCache.business}")
	private String business;


	@Bean(name = "gcache", destroyMethod = "close")
    public Gcache gcache(){
        Gcache gcache = new GcacheClient(zk, business);
        return gcache;
    }

	public boolean setString(String key, String field, String value) throws Exception {
		try {
			gcache().hset(key, field, value);
			return true;
		} catch (Exception e) {
			throw e;
		}
	}
	public String getString(String key,String field) throws Exception {
		try {
			return gcache().hget(key,field);
		} catch (Exception e) {
			throw e;
		}
	}

	public boolean hexists(String key, String field) throws Exception{
		try {
			return gcache().hexists(key, field);
		}catch (Exception e){
			throw e;
		}
	}

}