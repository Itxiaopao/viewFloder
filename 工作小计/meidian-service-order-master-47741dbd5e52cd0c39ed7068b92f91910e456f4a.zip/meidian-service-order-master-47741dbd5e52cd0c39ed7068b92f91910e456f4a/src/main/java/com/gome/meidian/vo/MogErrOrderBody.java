package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class MogErrOrderBody implements Serializable {

    private static final long serialVersionUID = -2031109535941292757L;

    private String id;
    //消息id
    private String msgId;
    //订单id
    private Long orderId;
    //物流编码
    private String deliveryId;
    //订单状态
    private Integer orderStatus;
    //用户id
    private Long userId;
    //消息内容
    private String msgBody;
    //订单时间
    private Date orderTime;
    //创建时间
    private Date createTime;
}
