package com.gome.meidian.util;


import lombok.extern.slf4j.Slf4j;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

@Slf4j
public class HttpClientUtils {


	// 连接超时时间  单位毫秒
	private static int CON_TIMEOUT = 1000;
	// 读超时时间  单位毫秒
	private static int READ_TIMEOUT = 5000;


	/**
	 * http get
	 * @param requestUrl
	 * @return
	 */
	public static String doGet(String requestUrl){
		String httpRes=null;
		//创建默认的httpClient实例
		CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			//用get方法发送http请求
			HttpGet get = new HttpGet(requestUrl);
			CloseableHttpResponse httpResponse = null;
			//发送get请求
			httpResponse = httpClient.execute(get);
			try{
				//response实体
				HttpEntity entity = httpResponse.getEntity();
				if (null != entity){
					httpRes = EntityUtils.toString(entity, "UTF-8");
				}
			}
			finally{
				httpResponse.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally{
			try{
				httpClient.close();
			} catch (IOException e){
				e.printStackTrace();
			}
		}
		return httpRes;
	}

	/**
	 * http post
	 * @param requestUrl
	 * @param jsonParams
	 * @param headers
	 * @return
	 */
	public static String doPost(String requestUrl, String jsonParams, Map<String, String> headers) {
		return  httpClientPost2Str(requestUrl,jsonParams, headers);
	}

	public static String httpClientPost2Str(String url,String jsonParams, Map<String, String> headers) {
		if (jsonParams == null) return "";

		String responseContent = "";
		HttpClient httpclient = new DefaultHttpClient();

		httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, CON_TIMEOUT);
		httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, READ_TIMEOUT);

		try {
			HttpPost httppost = new HttpPost(url);

			if(null != headers){
				Set<String> keys = headers.keySet();
				for(String key: keys){
					httppost.addHeader(key, headers.get(key));
				}

			}

			httppost.setEntity(new StringEntity(jsonParams, HTTP.UTF_8));
			HttpResponse response = httpclient.execute(httppost);

			HttpEntity entity = response.getEntity();
			if (entity == null) {
				return null;
			}
			Header header = entity.getContentType();
			if (header == null) {
				return null;
			}
			try {
				responseContent = EntityUtils.toString(entity, "UTF-8");
			} catch (IOException ex) {
				throw ex;
			} catch (RuntimeException ex) {
				throw ex;
			} finally {
				try {
					if(null != httppost){
						httppost.abort();
					}
				} catch (Exception ignore) {
					log.error("HttpClientUtils.httpClientPost2Str,exception:{}", ignore);
					return null;
				}
			}

		} catch (Exception e) {
			log.error("HttpClientUtils.httpClientPost2Str,exception:{}", e);
			return null;
		} finally {
			httpclient.getConnectionManager().shutdown();
		}
		return responseContent;
	}
}
