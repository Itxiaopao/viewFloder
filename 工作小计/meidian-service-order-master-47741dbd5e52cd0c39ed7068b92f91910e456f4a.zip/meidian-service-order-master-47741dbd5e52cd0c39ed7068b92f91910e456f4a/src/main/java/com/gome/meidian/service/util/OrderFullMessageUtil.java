package com.gome.meidian.service.util;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gome.meidian.entity.Order;
import com.gome.meidian.entity.OrderFullMessage;
import com.gome.meidian.service.IOrderFullMessageService;
/**
 * @Desc 消息處理工具類
 * @author chenchen-ds6
 *
 */
@Component
public class OrderFullMessageUtil {
	@Autowired
	IOrderFullMessageService orderFullMessageService;
	@Autowired
	OrderErrorLogUtil orderErrorUtil;
	public void copyOrderToMessage(String msgJson,String msgId,Order order,OrderFullMessage orderFullMessage) {
		try {
			orderFullMessage.setMsgJson(msgJson);
			orderFullMessage.setOrderId(order.getOrderId());
			orderFullMessage.setCommerceId(order.getCommerceId());
			orderFullMessage.setDeliveryId(order.getDeliveryId());
			orderFullMessage.setDesc1(msgId);
			orderFullMessage.setDesc2(order.getDeliveryId());
			orderFullMessage.setCreateTime(order.getOrderTime());
			orderFullMessage.setOrderStatus(order.getStatus());
			orderFullMessage.setUpdateTime(new Date());
			orderFullMessageService.insert(orderFullMessage);
		}catch(Exception e) {
			orderErrorUtil.insertLog(order, "插入消息表失敗");
			e.printStackTrace();
		}
	}
}
