package com.gome.meidian.service.impl;

import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.entity.OrderDataCount;
import com.gome.meidian.entity.OrderDetailTask;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.TaskResponse;
import com.gome.meidian.mapper.order.OrderDataCountMapper;
import com.gome.meidian.mapper.order.OrderDetailTaskMapper;
import com.gome.meidian.service.OrderDetailTaskService;
import com.gome.meidian.service.util.BeanConvertUtils;
import com.gome.meidian.enums.OrderTaskUtil;
import com.gome.meidian.util.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author sunxueyan-ds
 * @Title: OrderDetailTaskServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/13 20:42
 */
@Slf4j
@Service
public class OrderDetailTaskServiceImpl extends ServiceImpl<OrderDetailTaskMapper, OrderDetailTask> implements OrderDetailTaskService {


    @Autowired
    OrderDetailTaskMapper orderDetailTaskMapper;
    @Autowired
    OrderDataCountMapper orderDataCountMapper;


    /**
     * 任务状态	1 未开始	2进行中	3已结束
     * 任务日期	2019.3.1	2019.3.15
     * 任务ID
     * skuid/productid
     * 销量/销售
     */

    @Override
    @Transactional
    public ResultEntity importOrderTask(List<OrderDetailTask> list) {
        ResultEntity resultEntity = new ResultEntity(1, null, null);
        Long id = null;
//        Iterator<OrderDetailTask> iterator = list.iterator();
//        while (iterator.hasNext()) {
        for (int i = 0; i < list.size(); i++) {
//            OrderDetailTask orderDetailTask = iterator.next();
            if (list.get(i).getBranchCode().equals("count")) {
                if (isExists(list.get(i))) {//总部任务存在重复的
                    resultEntity.setMessage("总部合计任务重复！");
                    return resultEntity;
                } else {
                    if (insert(list.get(i))) {//总部合计任务插入成功
                        if (null != list.get(i).getId()) {
                            id = list.get(i).getId();
                            list.remove(list.get(i));
                        } else {
                            resultEntity.setMessage("总部合计任务插入失败！");
                        }
                    } else {
                        resultEntity.setMessage("总部合计任务插入失败！");
                    }
                }
            }
        }
        if (null != id) {
            for (OrderDetailTask orderDetailTask : list) {
                orderDetailTask.setParentId(id);
            }
            Map<String, Long> map = insertOrUpdateBatchNum(list);
            map.put("insertNum", map.get("insertNum") + 1);
            resultEntity.setCode(0);
            resultEntity.setMessage("");
            resultEntity.setBusinessObj(map);
        }
        return resultEntity;
    }

    /**
     * suk任务通报的实现
     *
     * @param status    任务状态1 未开始	2进行中	3已结束
     * @param startDate 任务日期	2019.3.1
     * @param endDate   任务日期	2019.3.15
     * @param taskId    任务ID
     * @param skuId     skuId
     * @return
     */
    @Override
    public ResultEntity getSkuTaskList(Byte status, Date startDate, Date endDate, Long taskId, String skuId, Integer pageNum, Integer pageSize, Integer type) {
        ResultEntity resultEntity = new ResultEntity(1, "查询失败", null);
        try {
            //1.获取任务列表
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DATE_FORMAT);
            Date yesterDayDate = simpleDateFormat.parse(DateUtils.getYesterdayTimeBySelect(""));
            startDate = (startDate == null ? DateUtils.plusDays(yesterDayDate, 1l) : startDate);//当天
            endDate = (endDate == null ? DateUtils.plusDays(yesterDayDate, 2l) : endDate);//明天
            List<OrderDetailTask> skuTasKListCondition = getSkuTasKListCondition(yesterDayDate, status, startDate, endDate, taskId, skuId, pageNum, pageSize, type);
            //2.根据任务列表获取对应的订单数据
            List<TaskResponse> skuTaskResult = getSkuTaskResult(skuTasKListCondition, startDate, endDate, type);
            resultEntity.setCode(0);
            resultEntity.setMessage("查询成功");
            resultEntity.setBusinessObj(skuTaskResult);
        } catch (Exception e) {
            log.error("Error: Cannot execute getSkuTaskList Method.");
            throw new RuntimeException("Error: Cannot execute getSkuTaskList Method.  Cause", e);
        }
        return resultEntity;
    }

    /**
     * 条件查询任务
     * @param orderDetailTask
     * @return
     */
    @Override
    public ResultEntity getTaskDetail(OrderDetailTask orderDetailTask, Integer pageNum, Integer pageSize) {
        ResultEntity resultEntity = new ResultEntity();
        try {
            if(null == orderDetailTask || null == orderDetailTask.getStartTime() || null == orderDetailTask.getEndTime()){
                resultEntity.setCode(0);
                resultEntity.setMessage("查询参数不可为空！");
            }
            if(null == pageNum){
                pageNum = 0;
            }
            if(null == pageSize){
                pageSize = 0;
            }
//            List<OrderDetailTask> orderDetailTasks = orderDetailTaskMapper.selectList(new EntityWrapper<OrderDetailTask>().setSqlSelect(" * ")
//                    .ge("start_time", orderDetailTask.getStartTime())
//                    .le("end_time", orderDetailTask.getEndTime())
//                    .addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getProductAbbreviation()), "product_abbreviation={0}", orderDetailTask.getProductAbbreviation())
//                    .addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getSkuId()), "sku_id={0}", orderDetailTask.getSkuId())
//                    .addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getBranchCode()), "branch_code={0}", orderDetailTask.getBranchCode())
//                    .addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getBranchName()), "branch_name={0}", orderDetailTask.getBranchName())
//                    .addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getTaskName()), "task_name={0}", orderDetailTask.getTaskName())
//                    .addFilterIfNeed(null != orderDetailTask.getId(), "id={0}", orderDetailTask.getId())
//                    .addFilterIfNeed(null != orderDetailTask.getParentId(), "parent_id={0}", orderDetailTask.getParentId())
//                    .addFilterIfNeed(null != orderDetailTask.getTaskType(), "task_type={0}", orderDetailTask.getTaskType())
//                    .orderBy("create_time", false));
//                    .last("LIMIT " + pageNum + "," + pageSize));
            EntityWrapper entityWrapper = new EntityWrapper<OrderDetailTask>();
            entityWrapper.ge("start_time", orderDetailTask.getStartTime());
            entityWrapper.le("end_time", orderDetailTask.getEndTime());
            entityWrapper.addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getProductAbbreviation()), "product_abbreviation={0}", orderDetailTask.getProductAbbreviation());
            entityWrapper.addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getSkuId()), "sku_id={0}", orderDetailTask.getSkuId());
            entityWrapper.addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getBranchCode()), "branch_code={0}", orderDetailTask.getBranchCode());
            entityWrapper.addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getBranchName()), "branch_name={0}", orderDetailTask.getBranchName());
            entityWrapper.addFilterIfNeed(StringUtils.isNotEmpty(orderDetailTask.getTaskName()), "task_name={0}", orderDetailTask.getTaskName());
            entityWrapper.addFilterIfNeed(null != orderDetailTask.getId(), "id={0}", orderDetailTask.getId());
            entityWrapper.addFilterIfNeed(null != orderDetailTask.getParentId(), "parent_id={0}", orderDetailTask.getParentId());
            entityWrapper.addFilterIfNeed(null != orderDetailTask.getTaskType(), "task_type={0}", orderDetailTask.getTaskType());
            entityWrapper.orderBy("create_time", false);
            Page<OrderDetailTask> page = new Page<OrderDetailTask>(pageNum, pageSize);
            Page result = selectPage(page, entityWrapper);
            Integer count = selectCount(entityWrapper);
            result.setTotal(count);
            resultEntity.setCode(0);
            resultEntity.setMessage("查询成功");
            resultEntity.setBusinessObj(result);
        }catch (Exception e){
            log.error("Error: Cannor execute getTaskDetail Method. orderDetailTask:{}", orderDetailTask);
            throw new RuntimeException("Error: Cannor execute getTaskDetail Method.  Cause", e);
        }
        return resultEntity;
    }


    /**
     * 根据sku任务获取订单数据组装并返回
     *
     * @param skuTasKListCondition
     * @return
     */
    public List<TaskResponse> getSkuTaskResult(List<OrderDetailTask> skuTasKListCondition, Date startDate, Date endDate, Integer type) {
        List<TaskResponse> taskResponses = new ArrayList<>();
        for (OrderDetailTask orderDetailTask : skuTasKListCondition) {
            TaskResponse taskResponse = new TaskResponse();//赋值任务量
            taskResponse.setSalesTask(orderDetailTask.getSales());
            taskResponse.setSalesNumTask(orderDetailTask.getSalesNum());
            taskResponse.setOrderNumTask(orderDetailTask.getOrderNum());
            taskResponse.setCargoSalesNumTask(orderDetailTask.getCargoSalesNum());
            taskResponse.setCargoSalesTask(orderDetailTask.getCargoSales());
            taskResponse.setElectricSalesNumTask(orderDetailTask.getElectricSalesNum());
            taskResponse.setElectricSalesTask(orderDetailTask.getElectricSales());

            taskResponse.setTaskName(orderDetailTask.getTaskName());
            taskResponse.setBranchCode(orderDetailTask.getBranchCode());
            taskResponse.setBranchName(orderDetailTask.getBranchName());
            taskResponse.setTaskType(orderDetailTask.getTaskType());
            if (StringUtils.isNotEmpty(orderDetailTask.getProductAbbreviation())) {
                taskResponse.setProductAbbreviation(orderDetailTask.getProductAbbreviation());
            }
            if (StringUtils.isNotEmpty(orderDetailTask.getSkuId())) {
                taskResponse.setSkuId(orderDetailTask.getSkuId());
            }

            if (type == 1) {//sku任务
                taskResponse = getSkuOrderDataByTask(taskResponse, orderDetailTask, startDate, endDate);
                taskResponses.add(taskResponse);
            } else {//分部任务
                TaskResponse orderDataByTask = getOrderDataByTask(taskResponse, orderDetailTask, startDate, endDate);
                taskResponses.add(taskResponse);
            }
        }
        taskResponses = calculateData(taskResponses);
        return taskResponses;
    }


    public List<TaskResponse> calculateData(List<TaskResponse> responses) {
        TaskResponse response = new TaskResponse();

        for (TaskResponse taskResponse : responses) {
            if (!taskResponse.getBranchCode().equals("count")) {
                if (StringUtils.isNotEmpty(taskResponse.getSkuId())) {//sku任务
                    response.setSalesNum(taskResponse.getSalesNum() + response.getSalesNum());
                    response.setSalesNumNow(taskResponse.getSalesNumNow() + response.getSalesNum());
                    response.setSales(taskResponse.getSales().add(response.getSales()));
                    response.setSalesNow(taskResponse.getSalesNow().add(response.getSalesNow()));
                } else {
                    response.setOrderNum(taskResponse.getOrderNum() + response.getOrderNum());
                    response.setOrderNumNow(taskResponse.getOrderNumNow() + response.getOrderNumNow());
                    response.setElectricSalesNum(taskResponse.getElectricSalesNum() + response.getElectricSalesNum());
                    response.setElectricSalesNumNow(taskResponse.getElectricSalesNumNow() + response.getElectricSalesNumNow());
                    response.setCargoSalesNum(taskResponse.getCargoSalesNum() + response.getCargoSalesNum());
                    response.setCargoSalesNumNow(taskResponse.getCancelOrderNumNow() + response.getCargoSalesNumNow());
                    response.setElectricSales(taskResponse.getElectricSales().add(response.getElectricSales()));
                    response.setElectricSalesNow(taskResponse.getElectricSalesNow().add(response.getElectricSalesNow()));
                    response.setCargoSales(taskResponse.getCargoSales().add(response.getCargoSales()));
                    response.setCargoSalesNow(taskResponse.getCargoSalesNow().add(response.getCargoSalesNow()));
                    response.setSales(taskResponse.getSales().add(response.getSales()));
                    response.setSalesNow(taskResponse.getSalesNow().add(response.getSalesNow()));
                }
            }
        }
        for (TaskResponse taskResponse : responses) {
            if (taskResponse.getBranchCode().equals("count")) {
                response.setSalesTask(taskResponse.getSalesTask());
                response.setSalesNumTask(taskResponse.getSalesNumTask());
                response.setOrderNumTask(taskResponse.getOrderNumTask());
                response.setCargoSalesNumTask(taskResponse.getCargoSalesNumTask());
                response.setCargoSalesTask(taskResponse.getCargoSalesTask());
                response.setElectricSalesNumTask(taskResponse.getElectricSalesNumTask());
                response.setElectricSalesTask(taskResponse.getElectricSalesTask());

                BeanConvertUtils.copyPropertiesIgnoreNull(response, taskResponse);
            }
        }
        return responses;
    }

    /**
     * 获取非sku任务的数据
     *
     * @param taskResponse
     * @param orderDetailTask
     * @param startDate
     * @param endDate
     * @return
     */
    public TaskResponse getOrderDataByTask(TaskResponse taskResponse, OrderDetailTask orderDetailTask, Date startDate, Date endDate) {
        try {
            List<OrderDataCount> orderCounts = orderDataCountMapper.selectList(new EntityWrapper<OrderDataCount>().setSqlSelect("SUM(sales_num) salesNum",
                    "SUM(sales) sales", "SUM(pay_sales) paySales", "SUM(pay_sales_num) paySalesNum",
                    "SUM(cancel_sales) cancelSales", "SUM(cancel_sales_num) cancelSalesNum", "SUM(effect_sales) effectSales",
                    "SUM(order_num) orderNum", "SUM(effect_sales_num) effectSalesNum", "SUM(effect_order_num) effectOrderNum",
                    "SUM(pay_order_num) payOrderNum", "SUM(cancel_order_num) cancelOrderNum")
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getBranchCode()), "branch_code = {0}", orderDetailTask.getBranchCode())
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getSkuId()), "sku_id = {0}", orderDetailTask.getSkuId())
                    .between("order_time", orderDetailTask.getStartTime() != null ? orderDetailTask.getStartTime() : startDate, orderDetailTask.getEndTime() != null ? orderDetailTask.getEndTime() : endDate)
                    .groupBy("branch_code").groupBy("product_type").orderBy("sales_num", false));
            for (OrderDataCount orderDataCount : orderCounts) {
                if (StringUtils.isNotEmpty(orderDataCount.getProductType()) && orderDataCount.getProductType().equals(OrderTaskUtil.code3.getCode())) {//电器
                    taskResponse.setElectricSales(orderDataCount.getSales());
                    taskResponse.setEffectSalesNum(orderDataCount.getSalesNum());
                } else if (StringUtils.isNotEmpty(orderDataCount.getProductType()) && orderDataCount.getProductType().equals(OrderTaskUtil.code4.getCode())) {//电器
                    taskResponse.setCargoSales(orderDataCount.getSales());
                    taskResponse.setCargoSalesNum(orderDataCount.getSalesNum());
                }
                if(StringUtils.isNotEmpty(orderDataCount.getProductType())){
                    taskResponse.setSales(taskResponse.getElectricSales().add(taskResponse.getCargoSales()));
                    taskResponse.setSalesNum(taskResponse.getElectricSalesNum() + taskResponse.getCargoSalesNum());
                }else {
                    taskResponse.setSales(orderDataCount.getSales());
                    taskResponse.setSalesNum(orderDataCount.getSalesNum());
                }
            }
            List<OrderDataCount> orderDataCounts = orderDataCountMapper.selectList(new EntityWrapper<OrderDataCount>().setSqlSelect("SUM(sales_num) salesNum",
                    "SUM(sales) sales", "SUM(pay_sales) paySales", "SUM(pay_sales_num) paySalesNum",
                    "SUM(cancel_sales) cancelSales", "SUM(cancel_sales_num) cancelSalesNum", "SUM(effect_sales) effectSales",
                    "SUM(order_num) orderNum", "SUM(effect_sales_num) effectSalesNum", "SUM(effect_order_num) effectOrderNum",
                    "SUM(pay_order_num) payOrderNum", "SUM(cancel_order_num) cancelOrderNum")
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getBranchCode()), "branch_code = {0}", orderDetailTask.getBranchCode())
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getSkuId()), "sku_id = {0}", orderDetailTask.getSkuId())
                    .between("order_time", orderDetailTask.getStartTime() != null ? orderDetailTask.getStartTime() : startDate, orderDetailTask.getEndTime() != null ? orderDetailTask.getEndTime() : endDate)
                    .between("order_time", startDate, endDate)
                    .groupBy("branch_code").groupBy("product_type").orderBy("sales_num", false));
            for (OrderDataCount dataCount : orderDataCounts) {
                if (StringUtils.isNotEmpty(dataCount.getProductType()) && dataCount.getProductType().equals(OrderTaskUtil.code3.getCode())) {//电器

                    taskResponse.setElectricSalesNow(dataCount.getSales());
                    taskResponse.setEffectSalesNumNow(dataCount.getSalesNum());
                } else if (StringUtils.isNotEmpty(dataCount.getProductType()) && dataCount.getProductType().equals(OrderTaskUtil.code4.getCode())) {//电器
                    taskResponse.setCargoSalesNow(dataCount.getSales());
                    taskResponse.setCargoSalesNumNow(dataCount.getSalesNum());
                }
                if(StringUtils.isNotEmpty(dataCount.getProductType())){
                    taskResponse.setSales(taskResponse.getElectricSalesNow().add(taskResponse.getCargoSalesNow()));
                    taskResponse.setSalesNumNow(taskResponse.getElectricSalesNumNow() + taskResponse.getCargoSalesNumNow());
                }else {
                    taskResponse.setSales(dataCount.getSales());
                    taskResponse.setSalesNum(dataCount.getSalesNum());
                }
            }
        } catch (Exception e) {
            log.error("Error: Cannor execute getOrderDataByTask Method. taskResponse:{}", taskResponse);
            throw new RuntimeException("Error: Cannor execute getOrderDataByTask Method.  Cause", e);
        }
        return taskResponse;
    }

    /**
     * 获取sku任务的数据
     *
     * @param taskResponse    返回结果
     * @param orderDetailTask 任务
     * @param startDate       今天
     * @param endDate         明天
     * @return
     */
    public TaskResponse getSkuOrderDataByTask(TaskResponse taskResponse, OrderDetailTask orderDetailTask, Date startDate, Date endDate) {
        try {
            List<OrderDataCount> orderDataCounts = orderDataCountMapper.selectList(new EntityWrapper<OrderDataCount>().setSqlSelect("SUM(sales_num) salesNum",
                    "SUM(sales) sales", "SUM(pay_sales) paySales", "SUM(pay_sales_num) paySalesNum",
                    "SUM(cancel_sales) cancelSales", "SUM(cancel_sales_num) cancelSalesNum", "SUM(effect_sales) effectSales",
                    "SUM(order_num) orderNum", "SUM(effect_sales_num) effectSalesNum", "SUM(effect_order_num) effectOrderNum",
                    "SUM(pay_order_num) payOrderNum", "SUM(cancel_order_num) cancelOrderNum")
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getBranchCode()), "branch_code = {0}", orderDetailTask.getBranchCode())
//                .eq("branch_code", orderDetailTask.getBranchCode())
//                .eq("sku_id", orderDetailTask.getSkuId())
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getSkuId()), "sku_id = {0}", orderDetailTask.getSkuId())
                    .between("order_time", orderDetailTask.getStartTime() != null ? orderDetailTask.getStartTime() : startDate, orderDetailTask.getEndTime() != null ? orderDetailTask.getEndTime() : endDate)
                    .groupBy("sku_id").orderBy("sales_num", false));
            if (null != orderDataCounts && orderDataCounts.size() > 0) {//赋值完成量

                taskResponse.setSales(orderDataCounts.get(0).getSales());
                taskResponse.setSalesNum(orderDataCounts.get(0).getSalesNum());

                taskResponse.setOrderNum(orderDataCounts.get(0).getOrderNum());
                taskResponse.setPayOrderNum(orderDataCounts.get(0).getPayOrderNum());
                taskResponse.setPaySales(orderDataCounts.get(0).getPaySales());
                taskResponse.setPaySalesNum(orderDataCounts.get(0).getPaySalesNum());
                taskResponse.setCancelOrderNum(orderDataCounts.get(0).getCancelOrderNum());
                taskResponse.setCancelSales(orderDataCounts.get(0).getCancelSales());
                taskResponse.setCancelSalesNum(orderDataCounts.get(0).getCancelSalesNum());
                taskResponse.setEffectOrderNum(orderDataCounts.get(0).getEffectOrderNum());
                taskResponse.setEffectSales(orderDataCounts.get(0).getEffectSales());
                taskResponse.setEffectSalesNum(orderDataCounts.get(0).getEffectSalesNum());
            }
            List<OrderDataCount> dataCounts = orderDataCountMapper.selectList(new EntityWrapper<OrderDataCount>().setSqlSelect("SUM(sales_num) salesNum",
                    "SUM(sales) sales", "SUM(pay_sales) paySales", "SUM(pay_sales_num) paySalesNum",
                    "SUM(cancel_sales) cancelSales", "SUM(cancel_sales_num) cancelSalesNum", "SUM(effect_sales) effectSales",
                    "SUM(order_num) orderNum", "SUM(effect_sales_num) effectSalesNum", "SUM(effect_order_num) effectOrderNum",
                    "SUM(pay_order_num) payOrderNum", "SUM(cancel_order_num) cancelOrderNum")
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getBranchCode()), "branch_code = {0}", orderDetailTask.getBranchCode())
//                .eq("branch_code", orderDetailTask.getBranchCode())
//                .eq("sku_id", orderDetailTask.getSkuId())
                    .addFilterIfNeed(!org.springframework.util.StringUtils.isEmpty(orderDetailTask.getSkuId()), "sku_id = {0}", orderDetailTask.getSkuId())
                    .between("order_time", orderDetailTask.getStartTime() != null ? orderDetailTask.getStartTime() : startDate, orderDetailTask.getEndTime() != null ? orderDetailTask.getEndTime() : endDate)
                    .between("order_time", startDate, endDate)
                    .groupBy("sku_id").orderBy("sales_num", false));
            if (null != dataCounts && dataCounts.size() > 0) {//赋值当前完成量
                taskResponse.setSalesNow(dataCounts.get(0).getSales());
                taskResponse.setSalesNumNow(dataCounts.get(0).getSalesNum());
                taskResponse.setOrderNumNow(dataCounts.get(0).getOrderNum());
                taskResponse.setPayOrderNumNow(dataCounts.get(0).getPayOrderNum());
                taskResponse.setPaySalesNow(dataCounts.get(0).getPaySales());
                taskResponse.setPaySalesNumNow(dataCounts.get(0).getPaySalesNum());
                taskResponse.setCancelOrderNumNow(dataCounts.get(0).getCancelOrderNum());
                taskResponse.setCancelSalesNow(dataCounts.get(0).getCancelSales());
                taskResponse.setCancelSalesNumNow(dataCounts.get(0).getCancelSalesNum());
                taskResponse.setEffectOrderNumNow(dataCounts.get(0).getEffectOrderNum());
                taskResponse.setEffectSalesNow(dataCounts.get(0).getEffectSales());
                taskResponse.setEffectSalesNumNow(dataCounts.get(0).getEffectSalesNum());
            }
        } catch (Exception e) {
            log.error("Error: Cannor execute getSkuOrderDataByTask Method. taskResponse:{}", taskResponse);
            throw new RuntimeException("Error: Cannot execute getSkuOrderDataByTask Method. Cause", e);
        }
        return taskResponse;
    }


    /**
     * 条件获取sku任务列表
     *
     * @param yesterDayDate
     * @param status
     * @param startDate
     * @param endDate
     * @param taskId
     * @param skuId
     * @return
     */
    public List<OrderDetailTask> getSkuTasKListCondition(Date yesterDayDate, Byte status, Date startDate, Date endDate, Long taskId, String skuId, Integer pageNum, Integer pageSize, Integer type) {
        List<OrderDetailTask> orderDetailTasks = new ArrayList<>();
        try {
            EntityWrapper<OrderDetailTask> wrapper = new EntityWrapper();
            if (status != null) {
                if (status.equals(new Byte("1"))) {//未开始
                    wrapper.gt("start_time", DateUtils.plusDays(yesterDayDate, 1l));//开始时间大于当天
                } else if (status.equals(new Byte("2"))) {//2进行中
                    wrapper.le("start_time", DateUtils.plusDays(yesterDayDate, 1l));//开始时间小于等于当天
                    wrapper.gt("end_time", DateUtils.plusDays(yesterDayDate, 1l));//结束时间大于当天
                } else if (status.equals(new Byte("3"))) {//3已结束
                    wrapper.lt("end_time", DateUtils.plusDays(yesterDayDate, 1l));//结束时间小于当天
                }
            }
            wrapper.ge("start_time", startDate);//大于等于任务开始日期
            wrapper.le("end_time", endDate);//小于等于任务结束日期
            if (null != taskId) {
                wrapper.eq("id", taskId);//任务id
            }
            if (StringUtils.isNotEmpty(skuId)) {
                wrapper.eq("sku_id", skuId);
            }
            if (type == 1) {
                wrapper.and("sku_id is not " + null);
            } else {
                wrapper.and("sku_id is " + null);
            }
            wrapper.orderBy("create_time", false);
//            if (null == pageNum) {
//                pageNum = 0;
//            }
//            if (null == pageSize) {
//                pageSize = 20;
//            }
//            wrapper.last("LIMIT " + pageNum + "," + pageSize);

            orderDetailTasks = selectList(wrapper);
        } catch (Exception e) {
            throw new RuntimeException("Error: Cannot execute getSkuTasKList Method. Cause", e);
        }
        return orderDetailTasks;
    }


    @Override
    @Transactional
    public Map<String, Long> insertOrUpdateBatchNum(List<OrderDetailTask> list) {
        return insertOrUpdateBatchMethod(list, 30);
    }

    /**
     * 批量插入修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @return boolean
     */
    private Map<String, Long> insertOrUpdateBatchMethod(List<OrderDetailTask> entityList, int batchSize) {
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        Long count = 0l;
        Map<String, Long> resultMap = new HashMap<>();
        resultMap.put("insertNum", 0l);
        resultMap.put("repeatNum", 0l);
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            for (int i = 0; i < size; i++) {
                resultMap = insertOrUpdateReal(entityList.get(i), resultMap);
                if (i >= 1 && i % batchSize == 0) {
                    batchSqlSession.flushStatements();
                }
            }
            batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertOrUpdateBatch Method. Cause", e);
        }
        return resultMap;
    }


    /**
     * <p>
     * TableId 注解存在更新记录，否插入一条记录
     * </p>
     *
     * @param entity 实体对象
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateReal(OrderDetailTask entity, Map<String, Long> resultMap) {
//        Map<String, Long> resultMap = new HashMap<>();
        Long repeatNum = 0l;
        Long insertNum = 0l;
        if (null != entity) {
            if (StringUtils.isNotEmpty(entity.getTaskName()) && null != entity.getTaskType() && entity.getStartTime() != null && entity.getEndTime() != null && StringUtils.isNotEmpty(entity.getBranchCode())) {
                /*
                 * 重复不导入，否则执行插入逻辑
                 */
                if (isExists(entity)) {
                    repeatNum = resultMap.get("repeatNum");
                    repeatNum++;
                    resultMap.put("repeatNum", repeatNum);
                    return resultMap;
                }
                if (insert(entity)) {
                    insertNum = resultMap.get("insertNum");
                    insertNum++;
                    resultMap.put("insertNum", insertNum);
                }
            }
        } else {
            throw new MybatisPlusException("Error:  Can not execute. Could not find @TableId.");
        }
        return resultMap;
    }


    /**
     * 判断导入的订单任务数据是否存在
     *
     * @param entity
     * @return
     */
    public Boolean isExists(OrderDetailTask entity) {
        OrderDetailTask orderDetailTask = null;
        try {
            EntityWrapper wrapper = new EntityWrapper();
            if (StringUtils.isNotEmpty(entity.getSkuId())) {
                wrapper.eq("sku_id", entity.getSkuId());
            }
            wrapper.eq("branch_code", entity.getBranchCode());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DateUtils.DATE_FORMAT);
            wrapper.eq("start_time", simpleDateFormat.format(entity.getStartTime()));
            wrapper.eq("end_time", simpleDateFormat.format(entity.getEndTime()));
            wrapper.eq("task_type", entity.getTaskType());
            wrapper.eq("task_name", entity.getTaskName());
            orderDetailTask = selectOne(wrapper);
        } catch (Exception e) {
            throw new RuntimeException("Error: Cannot execute isExists Method.  Cause", e);
        }
        if (null != orderDetailTask) {
            return Boolean.TRUE;
        } else {
            return Boolean.FALSE;
        }
    }
}
