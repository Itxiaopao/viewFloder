package com.gome.meidian.base;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import com.mongodb.WriteResult;

public abstract class MongGenDao<T> {

    protected abstract Class<T> getEntityClass();

    @Autowired
    protected MongoTemplate mongoTemplate;
    
    //保存
    protected void save(T t) {
        this.mongoTemplate.save(t);
    }

    //通过条件查询单个实体
    protected T findOne(Query query) {
        return this.mongoTemplate.findOne(query, this.getEntityClass());
    }

    //主键获取实体
    protected T findById(String id) {
        Query query = new Query();
        Criteria criteria = Criteria.where("_id").is(id);
        query.addCriteria(criteria);
        return this.mongoTemplate.findOne(query, this.getEntityClass());
    }

    //根据条件查询集合
    protected List<T> findList(Query query) {
        return this.mongoTemplate.find(query, this.getEntityClass());
    }

    //查询集合全部
    protected List<T> findAll() {
        return mongoTemplate.findAll(this.getEntityClass());
    }

    //条件进行分页查询
    protected List<T> findPage(Query query, int start, int size) {
        query.skip(start);
        query.limit(size);
        List<T> lists = this.mongoTemplate.find(query, this.getEntityClass());
        return lists;
    }

    //条件进行分页查询with排序
    protected List<T> findPageBySort(Query query, Pageable pageable) {
        query.skip((pageable.getPageNumber() - 1) * pageable.getPageSize());
        query.limit(pageable.getPageSize());
        query.with(pageable.getSort());
        List<T> lists = this.mongoTemplate.find(query, this.getEntityClass());
        return lists;
    }

    //条件查询库中符合记录的总数
    protected Long count(Query query) {
        return this.mongoTemplate.count(query, this.getEntityClass());
    }

    //删除对象
    protected void delete(T t) {
        this.mongoTemplate.remove(t);
    }

    //根据条件删除document
    protected void delete(Query query) {
        this.mongoTemplate.remove(query, this.getEntityClass());
    }

    //根据Id删除用户
    protected void deleteById(String id) {
        Criteria criteria = Criteria.where("_id").is(id);
        if (null != criteria) {
            Query query = new Query(criteria);
            if (null != query && this.findOne(query) != null) {
                mongoTemplate.remove(query, this.getEntityClass());
            }
        }
    }

    //更新满足条件的第一个记录
    protected void updateFirst(Query query, Update update) {
        this.mongoTemplate.updateFirst(query, update, this.getEntityClass());
    }

    //根据条件 更新
    protected WriteResult update(Query query, Update update) {
        if (update == null) {
            return null;
        }
        return mongoTemplate.updateMulti(query, update, this.getEntityClass());
    }

    //更新满足条件的所有记录
    protected void updateMulti(Query query, Update update) {
        this.mongoTemplate.updateMulti(query, update, this.getEntityClass());
    }

    //更新满足条件的所有记录
    protected void upsert(Query query, Update update) {
        this.mongoTemplate.upsert(query, update, this.getEntityClass());
    }

    //查找更新,如果没有找到符合的记录,则将更新的记录插入库中
    protected void updateInser(Query query, Update update) {
        this.mongoTemplate.upsert(query, update, this.getEntityClass());
    }

}
