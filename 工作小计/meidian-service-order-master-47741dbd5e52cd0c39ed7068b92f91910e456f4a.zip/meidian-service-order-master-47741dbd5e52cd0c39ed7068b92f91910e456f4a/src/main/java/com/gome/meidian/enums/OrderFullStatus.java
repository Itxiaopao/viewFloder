package com.gome.meidian.enums;

import java.util.Arrays;
import java.util.List;

/**
 * OMS订单状态
 */
public enum OrderFullStatus {

    Payed(1, "已支付"),
    Canced(2, "已取消"),
    Resfuesd_Revice(3, "已拒收"),
    Effect(5, "订单妥投"),
    Back_Apply(6, "退货申请"),
    Back_Successed(7, "退货入库"),
    Back_Failed(8, "退货失败"),
    Exchange_Apply(9, "换货申请"),
    Exchange_Successed(10, "换货成功"),
    Exchange_Failed(11, "换货失败"),
    Effect_Backed(12, "妥投+7后退货"),
    Exchange_Refused(13, "换货被拒收"),
    Wait_Pay_Order(14, "订单待支付"),
    Wait_Pay_Deposit(15, "订单待支付定金"),
    Wait_Pay_Tail(16, "订单待支付尾款"),
    Order_OutStock(17, "配送单出库"),
    Wait_Pay_Canced(20, "待支付取消");

    public static String valueOf(Integer status) {
        for (OrderFullStatus enu : OrderFullStatus.values()) {
            if (enu.getStatus().equals(status)) {
                return enu.getName();
            }
        }
        return "未约定订单状态";
    }

    /**
     * 获取待支付操作状态
     *
     * @return
     */
    public static List<Integer> getWaitPayOperateStatus() {
        return Arrays.asList(OrderFullStatus.Wait_Pay_Order.getStatus(),
                OrderFullStatus.Wait_Pay_Deposit.getStatus(),
                OrderFullStatus.Wait_Pay_Tail.getStatus(),
                OrderFullStatus.Wait_Pay_Canced.getStatus());
    }

    /**
     * 处理手机报表订单状态
     *
     * @return
     */
    public static List<Integer> reportBizStatus() {
        return Arrays.asList(OrderFullStatus.Wait_Pay_Order.getStatus(),
                OrderFullStatus.Payed.getStatus(),
                OrderFullStatus.Effect.getStatus());
    }

    private Integer status;

    private String name;

    private OrderFullStatus(Integer status, String name) {
        this.status = status;
        this.name = name;
    }

    public Integer getStatus() {
        return status;
    }

    public String getName() {
        return name;
    }
}
