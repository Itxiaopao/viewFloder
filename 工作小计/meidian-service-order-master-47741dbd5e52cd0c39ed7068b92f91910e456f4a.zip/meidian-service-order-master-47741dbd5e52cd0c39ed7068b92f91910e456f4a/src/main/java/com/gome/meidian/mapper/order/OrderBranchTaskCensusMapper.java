package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderBodyError;
import com.gome.meidian.entity.OrderBranchTaskCensus;
import com.gome.meidian.entity.OrderImportUvData;
import com.gome.meidian.entity.orderTaskVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

@Mapper
public interface OrderBranchTaskCensusMapper extends BaseMapper<OrderBranchTaskCensus> {

//    int insert(OrderBranchTaskCensus record);

    int insertSelective(OrderBranchTaskCensus record);

    OrderBranchTaskCensus selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(OrderBranchTaskCensus record);

    int updateByPrimaryKey(OrderBranchTaskCensus record);

    @Select("select i.record_time,i.sku_id,o.branch_id as branchCode, sum(share_quantity) as share_quantity,sum(uv_quantity) as uv_quantity from order_import_uv_data i,order_shop_same o where i.mid = o.shop_id GROUP BY o.branch_id,i.sku_id,i.record_time")
    List<OrderBranchTaskCensus> selectUnion();

    @Select("<script>" +
            "select o.sku_id,o.order_time as record_time,sum(buy_num) as sales_quantity,sum(price_total) as sales_money,s.branch_id as branch_code " +
            "from order_occur o,order_shop_same s " +
            "where " +
            "o.order_time BETWEEN #{startDate} and #{endDate} " +
            " and s.branch_id != '' " +
            "GROUP BY s.branch_id,o.sku_id " +
            "ORDER BY sales_money desc" +
            "</script>")
    List<OrderBranchTaskCensus> getBranchSales(@Param("startDate")Date startDate, @Param("endDate")Date endDate);


    @Select("SELECT * from order_branch_task_census where region_id is NULL")
    List<OrderBranchTaskCensus> getListDataByRegionIdIsNull();

    @Select("SELECT\n" +
            "\tb.task_id,\n" +
            "\tb.sku_id,\n" +
            "\tb.start_time,\n" +
            "\tb.end_time,\n" +
            "\tb.product_abbreviation,\n" +
            "\tb.share_quota,\n" +
            "\tb.uv_quota,\n" +
            "\tb.sales_quota,\n" +
            "\tsum( share_quantity )  as share_quantity,\n" +
            "\tsum( uv_quantity ) as uv_quantity,\n" +
            "\tsum( sales_quantity ) as sales_quantity,\n" +
            "\t(\n" +
            "CASE\n" +
            "\t\n" +
            "\tWHEN b.task_id = o.task_id \n" +
            "\tAND o.record_time >= #{startTime} \n" +
            "\tAND o.record_time < #{endTime} THEN\n" +
            "\tsum( share_quantity ) ELSE 0 \n" +
            "END \n" +
            "\t) share_quota_now,\n" +
            "\t(\n" +
            "CASE\n" +
            "\t\n" +
            "\tWHEN b.task_id = o.task_id \n" +
            "\tAND o.record_time >= #{startTime} \n" +
            "\tAND o.record_time < #{endTime} THEN\n" +
            "\tsum( uv_quantity ) ELSE 0 \n" +
            "END \n" +
            "\t) uv_quota_now,\n" +
            "\t(\n" +
            "CASE\n" +
            "\t\n" +
            "\tWHEN b.task_id = o.task_id \n" +
            "\tAND o.record_time >= #{startTime} \n" +
            "\tAND o.record_time < #{endTime} THEN\n" +
            "\tsum( sales_quantity ) ELSE 0 \n" +
            "END \n" +
            "\t) sales_quota_now \n" +
            "FROM\n" +
            "\torder_based_task b\n" +
            "\tLEFT JOIN order_branch_task_census o ON b.task_id = o.task_id \n" +
            "GROUP BY\n" +
            "\tb.sku_id,\n" +
            "\tb.task_id,\n" +
            "\to.record_time\n" + "ORDER BY o.sales_quantity DESC" +
            " LIMIT #{pageNo},#{pageSize}")
    List<orderTaskVo> getAllData(@Param("startTime")Date startTime, @Param("endTime")Date endTime,@Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);

    @Select("SELECT b.task_id,\n" +
            "\tb.region_id,\n" +
            "\tb.region_name,\n" +
            "\tt.share_quota,\n" +
            "\tt.uv_quota,\n" +
            "\tt.sales_quota,\n" +
            "\tsum(uv_quantity) as uv_quantity,sum(share_quantity) as share_quantity,sum(sales_quantity) as sales_quantity,\n" +
            "(CASE\n" +
            "\tWHEN b.task_id = t.task_id AND b.record_time >= #{startTime} AND b.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( uv_quantity ) ELSE 0 \n" +
            "END) uv_quota_now,\n" +
            "(CASE\n" +
            "\tWHEN b.task_id = t.task_id AND b.record_time >= #{startTime} AND b.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( share_quantity ) ELSE 0 \n" +
            "END) share_quota_now,\n" +
            "(CASE\n" +
            "\tWHEN b.task_id = t.task_id AND b.record_time >= #{startTime} AND b.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( sales_quantity ) ELSE 0 \n" +
            "END) sales_quota_now\n" +
            "from order_branch_task_census b left join order_branch_task t on b.task_id = t.task_id GROUP BY b.task_id,b.region_id ORDER BY b.sales_quantity DESC" +
            " LIMIT #{pageNo},#{pageSize}")
    List<orderTaskVo> getRegionData(@Param("startTime")Date startTime, @Param("endTime")Date endTime,@Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);

    @Select(" SELECT b.task_id,\n" +
            "\tb.sku_id,\n" +
            "\tb.region_id,\n" +
            "\tb.region_name,\n" +
            "\tt.share_quota,\n" +
            "\tt.uv_quota,\n" +
            "\tt.sales_quota,\n" +
            "\tsum(uv_quantity) as uv_quantity,sum(share_quantity) as share_quantity,sum(sales_quantity) as sales_quantity,\n" +
            "(case\n" +
            "\tWHEN b.task_id = t.task_id AND b.record_time >= #{startTime} AND b.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( uv_quantity ) ELSE 0 \n" +
            "END) uv_quota_now,\n" +
            "(case\n" +
            "\tWHEN b.task_id = t.task_id AND b.record_time >= #{startTime} AND b.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( share_quantity ) ELSE 0 \n" +
            "END) share_quota_now,\n" +
            "(case\n" +
            "\tWHEN b.task_id = t.task_id AND b.record_time >= #{startTime} AND b.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( sales_quantity ) ELSE 0 \n" +
            "END) sales_quota_now\n" +
            "from order_branch_task_census b left join order_branch_task t on b.task_id = t.task_id GROUP BY b.sku_id,b.task_id,b.region_id ORDER BY b.sales_quantity DESC" +
            " LIMIT #{pageNo},#{pageSize}")
    List<orderTaskVo> getRegionDataBySkuId(@Param("startTime")Date startTime, @Param("endTime")Date endTime,@Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);

    @Select("SELECT b.*,o.share_quota,o.uv_quota,o.sales_quota from  (SELECT c.task_id,c.region_id,c.region_name,c.branch_code,c.branch_name,\n" +
            "\tsum(uv_quantity) as uv_quantity,sum(share_quantity) as share_quantity,sum(sales_quantity) as \tsales_quantity,\n" +
            "(case\n" +
            "\tWHEN c.branch_code = t.branch_code AND c.record_time >= #{startTime} AND c.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( sales_quantity ) ELSE 0 \n" +
            "END) sales_quota_now,\n" +
            "(case\n" +
            "\tWHEN c.branch_code = t.branch_code AND c.record_time >= #{startTime} AND c.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( uv_quantity ) ELSE 0 \n" +
            "END) uv_quota_now,\n" +
            "(case\n" +
            "\tWHEN c.branch_code = t.branch_code AND c.record_time >= #{startTime} AND c.record_time < #{endTime}\n" +
            "\tTHEN\n" +
            "\tsum( share_quantity ) ELSE 0 \n" +
            "END) share_quota_now\n" +
            "from order_branch_task_census c left join  order_branch_task t on c.branch_code = t.branch_code\n" +
            "GROUP BY c.task_id ) as b, order_branch_task as o WHERE b.task_id = o.task_id\n" +
            "ORDER BY b.sales_quantity DESC" +
            " LIMIT #{pageNo},#{pageSize}")
    List<orderTaskVo> getPartData(@Param("startTime")Date startTime, @Param("endTime")Date endTime,@Param("pageNo")Integer pageNo, @Param("pageSize")Integer pageSize);
}

