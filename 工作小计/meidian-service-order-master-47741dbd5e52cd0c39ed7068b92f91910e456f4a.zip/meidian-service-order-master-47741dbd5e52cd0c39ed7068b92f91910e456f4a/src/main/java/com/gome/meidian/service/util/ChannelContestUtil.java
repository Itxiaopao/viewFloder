package com.gome.meidian.service.util;

import com.gome.meidian.entity.Order;
import com.gomeplus.bs.interfaces.channel.api.MshopChannelActivityDataService;
import com.gomeplus.bs.interfaces.channel.entity.MshopActivityData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @Desc 渠道竞赛
 */
@Component
public class ChannelContestUtil {
    @Autowired
    private MshopChannelActivityDataService mshopChannelActivityDataService;

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private OrderErrorLogUtil orderErrorLogUtil;

    public void sendOrderTOChannelContest(Order order) {
        try {
            Long mid = Long.parseLong(order.getMid());
            if (null == mid || mid.equals(0)) {
                return;
            }
            MshopActivityData mshopActivityData = new MshopActivityData();
            mshopActivityData.setMid(mid);
            mshopActivityData.setSalePerformance(order.getPriceTotal());
            mshopActivityData.setRealPerformance(order.getPriceTotal());
            mshopActivityData.setOrderNum(1L);
            Integer status = order.getStatus();
            System.out.println(status.equals(0) || status.equals(1) ? 1 : 2);
            mshopChannelActivityDataService.updateRecordOrder(mshopActivityData, status.equals(0) || status.equals(1) ? 1 : 2, order.getOrderTime());
        } catch (Exception e) {
            logger.info("-----------渠道竞赛订单统计：{}" + "订单号：" + order.getOrderId() + "，子订单号：" + order.getCommerceId() + ",配送单号：" + order.getDeliveryId() + "，错误信息：" + e.getMessage());
            orderErrorLogUtil.insertLog(order,"渠道竞赛发送订单失败");
        }
    }
}

