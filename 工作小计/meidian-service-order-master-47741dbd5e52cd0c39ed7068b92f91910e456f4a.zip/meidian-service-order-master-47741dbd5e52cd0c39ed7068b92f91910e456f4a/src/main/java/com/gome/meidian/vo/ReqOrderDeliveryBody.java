package com.gome.meidian.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gome.meidian.page.BasePageVo;

public class ReqOrderDeliveryBody implements Serializable {
	
	private static final long serialVersionUID = -6842752319804301105L;
	
	private String id;//主键id
	private String msgId;//消息i
	private Long orderId;//订单id
	private String deliveryId;//物流编码
	private Long userId;//用户id
	//自定义入参
	private List<Integer> orderStatusList;//美店订单状态
	private Date orderStartTime;//订单开始时间
	private Date orderEndTime;//订单结束时间
	private BasePageVo basePageVo;//分页参数
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMsgId() {
		return msgId;
	}
	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public List<Integer> getOrderStatusList() {
		return orderStatusList;
	}
	public void setOrderStatusList(List<Integer> orderStatusList) {
		this.orderStatusList = orderStatusList;
	}
	public Date getOrderStartTime() {
		return orderStartTime;
	}
	public void setOrderStartTime(Date orderStartTime) {
		this.orderStartTime = orderStartTime;
	}
	public Date getOrderEndTime() {
		return orderEndTime;
	}
	public void setOrderEndTime(Date orderEndTime) {
		this.orderEndTime = orderEndTime;
	}
	public BasePageVo getBasePageVo() {
		return basePageVo;
	}
	public void setBasePageVo(BasePageVo basePageVo) {
		this.basePageVo = basePageVo;
	}
  	
}
