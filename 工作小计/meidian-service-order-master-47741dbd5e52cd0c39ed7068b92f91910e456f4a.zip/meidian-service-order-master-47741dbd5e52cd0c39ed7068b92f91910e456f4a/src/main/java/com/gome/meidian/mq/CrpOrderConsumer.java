package com.gome.meidian.mq;

import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeOrderlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerOrderly;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.boot.adapter.utils.SerializeUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.service.factory.CrpOrderFactory;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import redis.Gcache;

import javax.annotation.PostConstruct;
import java.util.Map;

@Slf4j
@Component
public class CrpOrderConsumer {

    @Value("${mq.address}")
    private String namesrvAddr;
    @Value("${mq.crpOrder.topic}")
    private String topic;
    @Value("${mq.crpOrder.group}")
    private String group;
    @Value("${mq.crpOrder.instanceName}")
    private String instanceName;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private Gcache gcache;

    @PostConstruct
    @SneakyThrows(MQClientException.class)
    public void init() {
        Map<String, CrpOrderFactory> beanMap = applicationContext.getBeansOfType(CrpOrderFactory.class);
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(group);
        consumer.setNamesrvAddr(namesrvAddr);
        consumer.setInstanceName(instanceName);
        consumer.subscribe(topic, "*");
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET);
        consumer.setMessageModel(MessageModel.CLUSTERING);
        consumer.registerMessageListener((MessageListenerOrderly) (msgs, context) -> {
            MessageExt msg = msgs.get(0);
            String msgId = msg.getMsgId();
            Object object = SerializeUtils.unserialize(msgId, msg.getBody());
            if (object == null) {
                return ConsumeOrderlyStatus.SUCCESS;
            }
            String msgBody = object.toString();
            for (String beanName : beanMap.keySet()) {
                CrpOrderFactory crpOrderFactory = beanMap.get(beanName);
                try {
                    crpOrderFactory.processOrder(msgId, msgBody);
                } catch (DuplicateKeyException e) {
                    log.error("{},发生唯一键冲突异常,msgId:{},事务已回滚,进入下一进程...", beanName, msg.getMsgId());
                } catch (Exception e) {
                    log.error("{},解析异常,失败msgId:{},异常堆栈如下:", beanName, msg.getMsgId(), e);
                    if (gcache.increx(Constant.CRP_ORDER_RETRY_COUNT_INCR_PREFIX + msgId, Constant.SECONDS_IN_GCACHE_ONEDAY) >= 3) {
                        //三次重试记录异常信息
                        crpOrderFactory.exCallback(msgId, msgBody, e);
                        return ConsumeOrderlyStatus.SUCCESS;
                    }
                    return ConsumeOrderlyStatus.SUSPEND_CURRENT_QUEUE_A_MOMENT;
                }
            }
            return ConsumeOrderlyStatus.SUCCESS;
        });
        consumer.start();
        log.info("CrpOrderConsumer Started... MQAddress:{} ,group:{}, topic:{}", namesrvAddr, group, topic);
    }

}