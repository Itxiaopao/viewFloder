package com.gome.meidian.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class MeidianBangbangMsg implements Serializable {

    private static final long serialVersionUID = 7444889435143737592L;

    private Long id;//主键id
    private String profileId;//购买人id
    private String orderId;//订单id
    private String shippingGroupId;//配送单id
    private String gomeState;//订单状态
    private String msgId;//消息id
    private Date insertTime;//创建时间
    private String msgBody;//消息体

}