package com.gome.meidian.service.biz;

import cn.com.gome.rebate.calc.Delivery;
import cn.com.gome.rebate.calc.OrderDto;
import com.gome.boot.adapter.utils.SerializeUtils;
import com.gome.meidian.dao.MeidianOrderMsgDao;
import com.gome.meidian.dao.OrderBodyDao;
import com.gome.meidian.dao.OrderDeliveryBodyDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.enums.OrderFullStatus;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
@Slf4j
public class ReceiveOrderBodyBiz {

	@Autowired
	OrderBodyDao orderBodyDao;
	@Autowired
	MeidianOrderMsgDao meidianOrderMsgDao;
	@Autowired
	OrderDeliveryBodyDao orderDeliveryBodyDao;
	
	//保存订单消息
	public void saveOrderMsg(String msgId, byte[] body) {
		try {
			MogOrderMsgInfo mogOrderMsgInfo = new MogOrderMsgInfo();
			mogOrderMsgInfo.setMsgId(msgId);
			mogOrderMsgInfo.setMsgBody(SerializeUtils.unserialize(body).toString());
			//mogOrderMsgInfo.setMsgBody(new String(body, "UTF-8"));
			mogOrderMsgInfo.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
			meidianOrderMsgDao.saveOrderMsg(mogOrderMsgInfo);
		} catch (Exception ex) {
			log.error("ReceiveOrderBodyImpl - saveOrderMsg 保存基本消息体 出现错误，错误原因:", ex);
		}
	}
	
	//是否存在待支付订单
	public MogOrderBody getOrderBody(Long orderId) {
		ReqOrderBody reqOrderBody = new ReqOrderBody();
		reqOrderBody.setOrderId(orderId);
		reqOrderBody.setOrderStatusList(Arrays.asList(OrderFullStatus.Wait_Pay_Order.getStatus()));
		ResultEntity<List<MogOrderBody>> result = orderBodyDao.queryOrderBodyList(reqOrderBody);
		return result == null || CollectionUtils.isEmpty(result.getBusinessObj()) ? null : result.getBusinessObj().get(0);
	}
	
	// 保存待支付订单
	public void saveOrderBody(String msgId, String body, OrderDto vo, Delivery dto) {
		ReqOrderBody reqOrderBody = new ReqOrderBody();
		reqOrderBody.setOrderId(Long.valueOf(vo.getOrderId()));
		reqOrderBody.setOrderStatusList(Arrays.asList(dto.getStatus()));
		try {
			ResultEntity<List<MogOrderBody>> orderBodyResult = orderBodyDao.queryOrderBodyList(reqOrderBody);
			if (orderBodyResult == null || CollectionUtils.isEmpty(orderBodyResult.getBusinessObj())) {
				MogOrderBody orderBody = new MogOrderBody();
				orderBody.setMsgBody(body);
				orderBody.setMsgId(msgId);
				orderBody.setOrderId(Long.valueOf(vo.getOrderId()));
				orderBody.setOrderTime(vo.getOrderDate());
				orderBody.setOrderStatus(dto.getStatus());
				orderBody.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
				orderBody.setUserId(Long.valueOf(vo.getUserId()));
				orderBodyDao.saveOrderBody(orderBody);
				log.info("保存待支付的订单，订单msgId为{},订单编码为{}", msgId, orderBody.getOrderId());
			}
		} catch (Exception ex) {
			log.error("ReceiveOrderBodyImpl - saveOrderBody 出现错误，错误原因:", ex);
		}
	}
	
	// 保存配送单
	public void saveDeliveryOrderBody(String msgId, String body, OrderDto vo, Delivery dto) {
		ReqOrderDeliveryBody reqOrderBody = new ReqOrderDeliveryBody();
		reqOrderBody.setOrderId(Long.valueOf(vo.getOrderId()));
		reqOrderBody.setDeliveryId(dto.getDeliveryOrderId());
		reqOrderBody.setOrderStatusList(Arrays.asList(dto.getStatus()));
		try {
			ResultEntity<List<MogDeliveryOrderBody>> orderBodyResult = orderDeliveryBodyDao.queryOrderDeliveryBodyList(reqOrderBody);
			if (orderBodyResult == null || CollectionUtils.isEmpty(orderBodyResult.getBusinessObj())) {
				MogDeliveryOrderBody orderBody = new MogDeliveryOrderBody();
				orderBody.setMsgBody(body);
				orderBody.setMsgId(msgId);
				orderBody.setOrderStatus(dto.getStatus());
				orderBody.setDeliveryId(dto.getDeliveryOrderId());
				orderBody.setOrderId(Long.valueOf(vo.getOrderId()));
				orderBody.setOrderTime(vo.getOrderDate());
				orderBody.setUserId(Long.valueOf(vo.getUserId()));
				orderBody.setCreateTime(DateUtils.transDateForNum(DateUtils.currentTimeSecs()));
				orderDeliveryBodyDao.saveOrderDeliveryBody(orderBody);
				// 先判断是否存在
				log.info("保存配送单消息，订单msgId为{},订单编码为{},物流单号:{}", orderBody.getMsgId(), orderBody.getOrderId(), orderBody.getDeliveryId());
			}
		} catch (Exception ex) {
			log.error("ReceiveOrderBodyImpl - saveDeliveryOrderBody 出现错误，错误原因:", ex);
		}
	}
}
