package com.gome.meidian.mq;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import com.alibaba.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import com.alibaba.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.enums.EmployeeTypeEnum;
import com.gome.meidian.service.biz.EmployeeBiz;
import com.gome.meidian.service.util.InviteUserRaceTask;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MogRaceUserInfo;
import com.gome.memberCore.lang.MapResult;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import redis.Gcache;

import javax.annotation.PostConstruct;
import java.text.SimpleDateFormat;
import java.util.*;

@Slf4j
@Component
public class ConsumerInviteUser {
    @Value("${mq.address}")
    private String namesrvAddr;
    @Value("${mq.inviteuser.topic}")
    private String topic;
    @Value("${mq.inviteuser.group}")
    private String group;
    @Value("${mq.inviteuser.instanceName}")
    private String instanceName;
    @Value("${mq.inviteuser.tag}")
    private String tag;
    @Autowired
    private InviteUserRaceTask inviteUserRaceTask;
    @Autowired
    private IUserInfoFacade iUserInfoFacade;
    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private Gcache gcache;
    //调用会员组公共参数  invokeFrom
    public static final String INVOKE_FROM = "gomeShop";
    @Autowired
    private EmployeeBiz employeeBiz;

    @PostConstruct
    @SneakyThrows(MQClientException.class)
    public void init() {
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(group);
        consumer.setNamesrvAddr(namesrvAddr);
        consumer.setInstanceName(instanceName);
        consumer.subscribe(topic, tag);
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET);
        consumer.setMessageModel(MessageModel.CLUSTERING);
        consumer.registerMessageListener(new MessageListenerConcurrently() {
            @Override
            public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
                MessageExt msg = msgs.get(0);
                try {
                    String msgId = msg.getMsgId();
                    String body = new String(msg.getBody());
                    log.info("收到拉新消息:{},messageBody:{}",msgId,body);
                    dealWithInviteUserRace(body);
                } catch (Exception e) {
                    log.error("解析异常,失败msgId:{},失败原因:{}", msg.getMsgId(), e);
                    return ConsumeConcurrentlyStatus.RECONSUME_LATER;
                }
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
        });
        consumer.start();
        log.info("InviteUserConsumer Started... MQAddress:{} ,group:{}, topic:{}", namesrvAddr, group, topic);
    }

    /**
     * 异步处理邀请人数
     * @param messageBody
     * @throws Exception
     */
    @Async
    public void dealWithInviteUserRace(String messageBody) throws Exception{
        if(!checkSaleRaceUtils.checkActivityIsEffective()){
            log.info("活动开关未开");
            return;
        }
        if(!checkSaleRaceUtils.checkIsActivityTime(new Date())){
            return;
        }
        JSONObject jsonObject = JSONObject.parseObject(messageBody);
        String puserId = jsonObject.getString("puserId");
        String userId = jsonObject.getString("userId");
        Date registerTime = queryRegisterTime(userId);
        if(null == registerTime){
            return;
        }
        if(!checkSaleRaceUtils.checkIsActivityTime(registerTime)){
            log.info("注册时间不在活动期间内");
            return;
        }
        if(!checkInviteUser(puserId) && null == checkInviteUserIdentity(Long.parseLong(puserId))){
            log.info("校验邀请人不是员工美店主,也不是互联网员工");
            return;
        }
        if(checkRepeatConsumerInviteMessage(puserId,userId)){
            log.info("已处理过该邀请者和拉新用户");
//            log.info("测试场景暂不处理");
            return;
        }
        MogRaceUserInfo mogRaceUserInfo = new MogRaceUserInfo();
        mogRaceUserInfo.setUserId(Long.parseLong(puserId));
        mogRaceUserInfo.setActivityId(checkSaleRaceUtils.getActivityId());
        mogRaceUserInfo.setInviteUserCount(1);
        inviteUserRaceTask.run(mogRaceUserInfo);
        firstOrRepeatPut(puserId,userId);
    }

    /**
     * 获取指定用户的注册时间
     * @param userId
     * @return
     */
    private Date queryRegisterTime(String userId) throws Exception{
        Map<String, Object> param = new HashMap<>();
        param.put("companyName", "gomeOnLine");
        MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(userId, INVOKE_FROM, param);
        if(null != userResult && userResult.isSuccess()) {
            UnifyUserInfoExt info = userResult.getBuessObj();
            if(null != info && StringUtils.isNotBlank(info.getRegisterDateSting())) {
                Date registerTime = new SimpleDateFormat("yyyyMMdd HH:mm:ss").parse(info.getRegisterDateSting());
                log.info("userId:{}的注册时间为:{}",userId,registerTime);
                return registerTime;
            }
        }
        return null;
    }

    /**
     * 校验邀请人是否是员工美店主
     * @param userId
     * @return
     */
    public boolean checkInviteUser(String userId){
        CommonResultEntity<VshopInfo> vshopInfoCommonResultEntity = vshopFacade.queryVshopByuserId(userId);
        if(null != vshopInfoCommonResultEntity && null != vshopInfoCommonResultEntity.getBusinessObj()){
            VshopInfo vshopInfo = vshopInfoCommonResultEntity.getBusinessObj();
            log.info("校验邀请人查询美店主信息userId:{},identity:{}",vshopInfo.getUserId(),vshopInfo.getVshopIdentity());
            if(null != vshopInfo.getVshopIdentity() && vshopInfo.getVshopIdentity().equals(3)){
                return true;
            }
        }
        return false;
    }

    /**
     * 往缓存set里面放数据(过期时间为7天)
     * @param puserId
     * @param userId
     */
    public void firstOrRepeatPut(String puserId,String userId){
        log.info("处理完加入缓存，避免重复处理拉新数据");
        Set<String> smembers = gcache.smembers(Constant.SALE_RACE_PREVENT_REPEAT_INVITE_USER + puserId);
        gcache.sadd(Constant.SALE_RACE_PREVENT_REPEAT_INVITE_USER + puserId, userId);
        if(smembers.size() == 0){
            gcache.expire(Constant.SALE_RACE_PREVENT_REPEAT_INVITE_USER + puserId,Constant.SECONDS_IN_GCACHE_ONEWEEK);
//            gcache.expire(Constant.SALE_RACE_PREVENT_REPEAT_INVITE_USER + puserId,60);
        }
    }
    /**
     * 校验是否是重复消费
     * @param puserId
     * @param userId
     * @return
     */
    public boolean checkRepeatConsumerInviteMessage(String puserId,String userId){
        Boolean sismember = gcache.sismember(Constant.SALE_RACE_PREVENT_REPEAT_INVITE_USER + puserId, userId);
        log.info("判断是否是重复处理相同的拉新,puserId:{},userId:{},sismember:{}",puserId,userId,sismember);
        return sismember;
    }
    /**
     * 校验邀请人身份处理(是互联网身份的时候进行处理)
     * @param inviteUserId
     */
    public Long checkInviteUserIdentity(Long inviteUserId){
        String employeeType = employeeBiz.getEmployeeType(inviteUserId);
        if(EmployeeTypeEnum.hlwl.name().equals(employeeType)){
            log.info("消费拉新用户,此userId为hlwl:{},employeeType:{}",inviteUserId,employeeType);
            return inviteUserId;
        }
        return null;
    }
}
