package com.gome.meidian.service.factory;

/**
 * 订单工厂
 */
public interface OmsOrderFactory {

    void processOrder(String msgId, String msgBody);

    default void exCallback(String msgId, String msgBody){

    }

}
