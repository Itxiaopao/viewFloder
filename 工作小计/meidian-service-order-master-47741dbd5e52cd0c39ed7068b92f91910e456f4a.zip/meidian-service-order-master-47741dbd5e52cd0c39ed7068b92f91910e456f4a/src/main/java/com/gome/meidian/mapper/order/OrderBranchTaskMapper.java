package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderBodyError;
import com.gome.meidian.entity.OrderBranchTask;

public interface OrderBranchTaskMapper extends BaseMapper<OrderBranchTask> {

//    int insert(OrderBranchTask record);

    int insertSelective(OrderBranchTask record);


    int updateByPrimaryKeySelective(OrderBranchTask record);

    int updateByPrimaryKey(OrderBranchTask record);
}