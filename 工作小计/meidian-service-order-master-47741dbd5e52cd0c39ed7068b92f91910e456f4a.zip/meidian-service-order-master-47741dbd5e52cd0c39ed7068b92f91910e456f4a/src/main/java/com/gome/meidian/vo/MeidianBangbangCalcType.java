package com.gome.meidian.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class MeidianBangbangCalcType implements Serializable {

    private static final long serialVersionUID = 4812649076220980040L;

    private Long id;//主键id
    private Long userId;//用户id
    private Long upUserId;//上级用户id
    private Integer count;//累计订单数量
    private Long firstOrderPrice;//首单实付金额
    private Long firstOrderSalePrice;//首单销售金额
    private Date firstOrderSubmittedDate;//首单提交时间
    private Date firstOrderPayDate;//首单支付时间
    private Long cumulateOrderPrice;//累计实付金额
    private Long cumulateOrderSalePrice;//累计销售金额
    private Long lastOrderPrice;//最近一次实付金额
    private Long lastOrderSalePrice;//最近一次销售金额
    private Date lastOrderSubmittedDate;//最近一次提交订单时间
    private Date lastOrderPayDate;//最近一次支付时间
    private Date insertTime;//创建时间
    private Date updateTime;//更新时间

}