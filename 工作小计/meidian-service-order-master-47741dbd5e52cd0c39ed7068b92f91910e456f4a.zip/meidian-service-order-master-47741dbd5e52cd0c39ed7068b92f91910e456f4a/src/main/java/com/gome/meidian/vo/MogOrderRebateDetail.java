package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class MogOrderRebateDetail implements Serializable {

    private static final long serialVersionUID = 7059351813361123749L;
    private String id;//主键id
    private Long orderId;//订单id
    private String deliveryId;//配送单id
    private String skuId;//skuId
    private Long commMoney;//佣金
    private Integer status;//订单状态
    private Date orderTime;//订单时间
    private Date createTime;//创建时间
}
