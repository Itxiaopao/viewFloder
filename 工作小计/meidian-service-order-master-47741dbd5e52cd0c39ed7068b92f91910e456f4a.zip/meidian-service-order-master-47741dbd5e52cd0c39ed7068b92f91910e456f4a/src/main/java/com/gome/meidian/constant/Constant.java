package com.gome.meidian.constant;

public class Constant {

    public static final String SYSTEM_NAME = "meidian-service-order";

    //订单状态
    public static final int TASK_ORDER_PLACE = 1;//发生单
    public static final int TASK_ORDER_OVER = 2;//取消单
    public static final int TASK_ORDER_DELIVE = 5;//妥投单
    public static final int TASK_ORDER_CHARGE = 6;//逆向单

    /**
     * redis过期时间 1分
     */
    public static final int SECONDS_IN_GCACHE_ONEMINUTE = 60;

    /**
     * redis过期时间 1小时
     */
    public static final int SECONDS_IN_GCACHE_ONEHOUR = SECONDS_IN_GCACHE_ONEMINUTE * 60;

    /**
     * redis过期时间 半天
     */
    public static final int SECONDS_IN_GCACHE_HALFDAY = 12 * SECONDS_IN_GCACHE_ONEHOUR;

    /**
     * redis过期时间 1天
     */
    public static final int SECONDS_IN_GCACHE_ONEDAY = 24 * SECONDS_IN_GCACHE_ONEHOUR;

    /**
     * redis过期时间 1周
     */
    public static final int SECONDS_IN_GCACHE_ONEWEEK = 7 * SECONDS_IN_GCACHE_ONEDAY;
    /**
     * redis 过期时间 1个月
     */
    public static final int SECONDS_IN_GCACHE_ONEMONTH = 31 * SECONDS_IN_GCACHE_ONEDAY;

    /**
     * redis 过期时间 3个月
     */
    public static final int SECONDS_IN_GCACHE_THIRDMONTH = 91 * SECONDS_IN_GCACHE_ONEDAY;

    /**
     * 单线程默认处理条数
     */
    public static final int EACH_THREAD_PAGE_NUM = 10000;

    /**
     * diamond 组名
     */
    public static final String DIAMOND_GROUP_NAME = "ms_service_order";

    /**
     * diamond 手机报表开关dataId
     */
    public static final String DIAMOND_DATA_ID_MS_REPORT_SWITCH = "ms_report_switch";

    /**
     * diamond CMS上下架开关dataId
     */
    public static final String DIAMOND_DATA_ID_MS_CMS_SWITCH = "ms_cms_switch";

    /**
     * diamond OMS订单时间开关dataId
     */
    public static final String DIAMOND_DATA_ID_MS_OMS_SWITCH = "ms_oms_switch";

    /**
     * 默认日期格式
     */
    public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    /**
     * 精确到毫秒日期格式
     */
    public static final String EXACT_MS_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss:SSS";

    /**
     * redis 美店主用户链条防重复提交
     */
    public static final String KEY_USER_RELATION_REPEAT_INCR_PREFIX = "key_user_relation_repeat_incr_prefix";

    /**
     * redis 美店主GMV业绩缓存String缓存前缀
     */
    public static final String KEY_GRADES_STR_CACHE_PREFIX = "key_grades_str_cache_prefix";

    /**
     * 逆向单缓存
     */
    public static final String REVERSE_ORDER_PK_SET_CACHE_PREFIX = "reverse_order_pk_set_cache_prefix";

    /**
     * 正向单缓存key
     */
    public static final String NORMAL_ORDER_PK_SET_CACHE_PREFIX = "normal_order_pk_set_cache_prefix";

    /**
     * 等待补偿的返利金额
     */
    public static final String WAIT_COMPENSATE_REBATE_PK_SET_CACHE_PREFIX = "wait_compensate_rebate_pk_set_cache_prefix";

    /**
     * 等待补偿的重试锁
     */
    public static final String WAIT_RETRY_REBATE_PK_INCR_CACHE_PREFIX = "wait_retry_rebate_pk_incr_cache_prefix";

    /**
     * 美店订单大区分部信息hash缓存前缀
     */
    public static final String ORDER_SHOP_SAME_HASH_CACHE_PREFIX = "order_shop_same_hash_cache_prefix";

    /**
     * 美店大区hash缓存前缀
     */
    public static final String ORDER_CATEGORY_HASH_CACHE_PREFIX = "order_category_hash_cache_prefix";

    /**
     * CMS上下架hash缓存前缀
     */
    public static final String CMS_EFFECTIVE_HASH_CACHE_PREFIX = "cms_effective_hash_cache_prefix";

    /**
     * 判断是否B 卖A hash缓存前缀
     */
    public static final String IS_BSALEA_HASH_CACHE_PREFIX = "is_bsalea_hash_cache_prefix";

    /**
     * 员工类型hash缓存前缀
     */
    public static final String EMPLOYEE_TYPE_HASH_CACHE_PREFIX = "employee_type_hash_cache_prefix";

    /**
     * OMS查询美店订单创建时间hash缓存前缀
     */
    public static final String OMS_ORDER_CREATE_TIME_HASH_CACHE_PREFIX = "oms_order_create_time_hash_cache_prefix";

    /**
     * OMS找不到订单创建时间的set缓存前缀
     */
    public static final String OMS_NOT_FOUND_ORDER_CREATE_TIME_SET_CACHE_PREFIX = "oms_not_found_order_create_time_set_cache_prefix";

    /**
     * 支付订单互斥锁
     */
    public static final String PAY_ORDER_MUTEX_LOCK_PREFIX = "pay_order_mutex_lock_prefix";


    /**
     * 订单返利防重复提交前缀
     */
    public static final String ORDER_REBATE_REPEAT_INCR_PREFIX = "order_rebate_repeat_incr_prefix";

    /**
     * 员工信息String缓存
     */
    public static final String STAFF_INFO_STR_CACHE =  "shopkeepers_rebate_";

    /**
     * 销售竞赛排名分布式锁
     */
    public static final String SALE_RACE_DISTRIBUTED_LOCK = "order_sale_race_";

    /**
     * 销售排名redis消费监听key
     */
    public static final String SALE_RACE_DISTRIBUTED_LISTENER= "order_sale_race_queue_listener";

    /**
     * 销售竞赛避免重复消费拉新用户
     */
    public static final String SALE_RACE_PREVENT_REPEAT_INVITE_USER= "order_sale_race_prevent_invite_";

    /**
     * 销售竞赛避免重复消费订单处理销售竞赛
     */
    public static final String SALE_RACE_PREVENT_REPEAT_ORDER= "order_sale_";

    /**
     * 订单确认提货防重复提交前缀
     */
    public static final String ORDER_CONFIRM_PICK_GOODS_INCR_CACHE_PREFIX= "order_confirm_pick_goods_incr_cache_prefix";

    /**
     * 支付订单互斥锁
     */
    public static final String CPA_ORDER_MUTEX_LOCK_PREFIX = "cpa_order_mutex_lock_prefix";
    /**
     * 小美帮帮-CPA订单返利防重复提交前缀
     */
    public static final String CPA_ORDER_REBATE_REPEAT_INCR_PREFIX = "cpa_order_rebate_repeat_incr_prefix";

    /**
     * oms消息重试次数前缀
     */
    public static final String OMS_ORDER_RETRY_COUNT_INCR_PREFIX = "oms_order_retry_count_incr_prefix_";

    /**
     * 提成消息重试次数前缀
     */
    public static final String CRP_ORDER_RETRY_COUNT_INCR_PREFIX = "crp_order_retry_count_incr_prefix_";

    /**
     * 提成消息体 美店帮帮计算用户类型String缓存
     */
    public static final String CRP_ORDER_BANGBANG_CALC_TYPE_STR_PREFIX = "crp_order_bangbang_calc_type_str_prefix";

    /**
     * 提成消息体 美店帮帮计算用户类型zset缓存
     */
    public static final String CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX = "crp_order_bangbang_calc_type_zset_prefix";

    /**
     * 提成消息体 美店帮帮是否计算过该订单String前缀
     */
    public static final String CRP_ORDER_BANGBANG_CALC_PROFIT_STR_PREFIX = "crp_order_bangbang_calc_profit_str_prefix";

    /**
     * 提成消息体 美店帮帮是否存储过该订单String前缀
     */
    public static final String CRP_ORDER_BANGBANG_USER_ORDER_STR_PREFIX = "crp_order_bangbang_user_order_str_prefix";

    /**
     * 提成消息体 美店帮帮计算用户类型 首单
     */
    public static final Integer CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER = 4;
    /**
     * 提成消息体 美店帮帮计算用户类型 忠粉
     */
    public static final Integer CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS = 5;

}
