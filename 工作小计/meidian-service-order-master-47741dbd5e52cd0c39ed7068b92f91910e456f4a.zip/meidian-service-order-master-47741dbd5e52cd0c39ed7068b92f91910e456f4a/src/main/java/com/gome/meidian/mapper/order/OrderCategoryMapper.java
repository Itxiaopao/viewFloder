package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderCategory;
import com.gome.meidian.vo.OrderCategoryVo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author likaile
 * @since 2018-10-31
 */
public interface OrderCategoryMapper extends BaseMapper<OrderCategory> {
	@Select("select classify_id as code ,classify_name as name from order_category GROUP BY classify_id")
	List<OrderCategory> getCate();

	@Select("select c1_id as code ,c1_name as name ,classify_id as parentCode from order_category where classify_id = #{parentCode} GROUP BY c1_id")
	List<OrderCategory> getFirstCate(String parentCode);

	@Select("select c2_id as code ,c2_name as name ,c1_id as parentCode from order_category where c1_id = #{parentCode} GROUP BY c2_id")
	List<OrderCategory> getSecondCate(String parentCode);

	@Select("select c3_id as code ,c3_name as name ,c2_id as parentCode from order_category  where c2_id = #{parentCode} GROUP BY c3_id")
	List<OrderCategory> getThirdCate(String parentCode);


	@Select({"<script>",
			"SELECT oc.c3_id, oc.c3_name, oc.c2_id, oc.c2_name, oc.c1_id, oc.c1_name, oc.classify_name, oc.classify_id, ocbc.business_categroy, ocbc.business_center ",
			"FROM order_category oc",
			"LEFT JOIN order_category_biz_center ocbc on ocbc.c3_id = oc.c3_id",
			"WHERE oc.c3_id = #{c3Id}",
			"</script>"})
	OrderCategoryVo selectByBiz(@Param("c3Id") String c3Id);
}
