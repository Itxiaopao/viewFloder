package com.gome.meidian.dao;

import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.page.BasePageVo;
import com.gome.meidian.page.Pagination;
import com.gome.meidian.vo.*;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
@Repository
public class MeidianOrderDao extends MongGenDao<MogOrderInfo> {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Override
    protected Class getEntityClass() {
        return MogOrderInfo.class;
    }

    /**
     * 保存订单信息
     *
     * @param mogOrderInfo
     */
    public ResultEntity saveOrderInfo(MogOrderInfo mogOrderInfo) {
        //参数过滤
        if (mogOrderInfo.getOrderId() == null || mogOrderInfo.getCommerceId() == null || StringUtils.isBlank(mogOrderInfo.getDeliveryId()) || StringUtils.isBlank(mogOrderInfo.getSkuId())) {
            return new ResultEntity(90001, "orderId,commerceId,deliveryId,skuId,orderStatus is null");
        }
        //保存订单-初始化默认值
        this.save(mogOrderInfo);
        //响应信息
        return new ResultEntity();
    }

    /**
     * 删除订单信息通过id
     *
     * @param id
     * @return
     */
    public ResultEntity delOrderInfoById(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity(90002, "id is null");
        }
        this.deleteById(id);
        return new ResultEntity();
    }

    /**
     * 主键更新内容,不存在属性新增
     *
     * @param mogOrderInfo
     * @return
     */
    public ResultEntity updateOrderData(MogOrderInfo mogOrderInfo) {
        if (StringUtils.isBlank(mogOrderInfo.getId())) {
            return new ResultEntity(90002, "id is null");
        }
        //多条件嵌入
        Query query = Query.query(Criteria.where("_id").is(mogOrderInfo.getId()));
        //封装更新数据
        Update update = this.orderParamUpdate(mogOrderInfo);
        this.updateMulti(query, update);
        return new ResultEntity();
    }

    /**
     * 保存百货店主提货
     *
     * @param deliveryId   配送单id
     * @param parentUserId 上级id
     * @param isPickGoods  是否提货
     * @return
     */
    public ResultEntity<Boolean> savePickGoods(String deliveryId, Long parentUserId, Integer isPickGoods) {
        if (StringUtils.isBlank(deliveryId) || parentUserId == null && isPickGoods == null) {
            return new ResultEntity(90002, "更新参数不可为null");
        }
        Query query = Query.query(Criteria.where("deliveryId").is(deliveryId).and("parentUserId").is(parentUserId));
        Update update = new Update();
        update.set("isPickGoods", isPickGoods);
        this.updateMulti(query, update);
        return new ResultEntity(Boolean.TRUE);
    }


    /**
     * 多条件获取订单列表
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<List<MogOrderInfo>> queryOrderList(ReqOrderVo reqOrderVo) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.orderParamFile(reqOrderVo));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "orderTime"));
        //查询订单列表
        List<MogOrderInfo> list = this.findList(query);
        return new ResultEntity(list);
    }

    /**
     * 分页多条件获取订单列表
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<Pagination<MogOrderInfo>> queryPageOrderList(ReqOrderVo reqOrderVo) {
        //分页参数过滤
        BasePageVo page = reqOrderVo.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            return new ResultEntity(90002, "pageNo,pageSize is null");
        }
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.orderParamFile(reqOrderVo));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "orderTime"));
        //查询订单列表
        List<MogOrderInfo> list = this.findPage(query, page.getStartRow(), page.getPageSize());
        //查询订单条数
        long count = this.count(query);
        //封装分页信息
        Pagination<MogOrderInfo> pagination = new Pagination(page.getPageNo(), page.getPageSize(), (int) count);
        pagination.setList(list);
        return new ResultEntity(pagination);
    }


    /**
     * 根据条件获取符合条件的总数
     *
     * @param reqOrderVo 请求参数
     * @return
     */
    public ResultEntity<Long> queryCountByBiz(ReqOrderVo reqOrderVo) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.orderParamFile(reqOrderVo));
        //查询订单条数
        long count = this.count(query);
        return new ResultEntity<>(count);
    }

    /**
     * 多条件统计订单总数/订单实付总额/提奖总额 /佣金总额
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<VitalOrderVo> querySumOrderPrice(ReqOrderVo reqOrderVo) {
        //条件查询并销售额求和
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFile(reqOrderVo)),
                Aggregation.group("id").count().as("countOrderNum").sum("priceTotal").as("sumPriceTotal").sum("awardMoney").as("sumAwardMoney").sum("commMoney").as("sumCommMoney"));
        AggregationResults<VitalOrderVo> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderInfo", VitalOrderVo.class);
        List<VitalOrderVo> vitalOrderVos = aggResult.getMappedResults();
        VitalOrderVo vitalOrderVo = CollectionUtils.isNotEmpty(vitalOrderVos) ? vitalOrderVos.get(0) : new VitalOrderVo();
        return new ResultEntity(vitalOrderVo);
    }

    /**
     * 分页统计订单总数/订单实付总额/提奖总额 /佣金总额(父级用户分组)(父级不为片总)
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<Pagination<VitalOrderVo>> queryPageGroupSumOrderPrice(ReqOrderVo reqOrderVo) {
        //分页参数过滤
        BasePageVo page = reqOrderVo.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            return new ResultEntity(90002, "pageNo,pageSize is null");
        }
        //条件查询并销售额求和
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("parentUserId").count().as("countOrderNum").sum("priceTotal").as("sumPriceTotal").sum("awardMoney").as("sumAwardMoney").sum("commMoney").as("sumCommMoney"),
                Aggregation.sort(new Sort(Sort.Direction.DESC, "sumAwardMoney")),
                Aggregation.skip(page.getStartRow()),
                Aggregation.limit(page.getPageSize()));
        AggregationResults<VitalOrderVo> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderInfo", VitalOrderVo.class);
        //获取总数
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("parentUserId"));
        AggregationResults<VitalOrderVo> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderInfo", VitalOrderVo.class);
        //封装分页信息
        Pagination<VitalOrderVo> pagination = new Pagination(page.getPageNo(), page.getPageSize(), aggResultCount.getMappedResults().size());
        pagination.setList(aggResult.getMappedResults());
        return new ResultEntity(pagination);
    }

    /**
     * 未支付-分页订单号对应集合-分组orderId
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<Pagination<VitalOrderPay>> queryPageOrderNoPay(ReqOrderVo reqOrderVo) {
        //分页参数过滤
        BasePageVo page = reqOrderVo.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            return new ResultEntity(90002, "pageNo,pageSize is null");
        }
        //条件查询并销售额求和
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("orderId").addToSet("skuId").as("skuIds").max("orderTime").as("orderTime"),
                Aggregation.sort(new Sort(Sort.Direction.DESC, "orderTime")),
                Aggregation.skip(page.getStartRow()),
                Aggregation.limit(page.getPageSize()));
        AggregationResults<VitalOrderPay> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderInfo", VitalOrderPay.class);
        List<VitalOrderPay> vitalOrderNoPays = aggResult.getMappedResults();
        for (VitalOrderPay vitalOrderNoPay : vitalOrderNoPays) {
            Long orderId = vitalOrderNoPay.getId();
            //封装对象
            List<MogOrderInfo> list = new ArrayList<>();
            List<String> skuIds = vitalOrderNoPay.getSkuIds();
            for (String skuId : skuIds) {
                Query query = new Query();
                Criteria criteria = this.orderParamFileParentUserId(reqOrderVo, 1);
                criteria.and("orderId").is(orderId);
                criteria.and("skuId").is(skuId);
                //封装条件查询数据
                query.addCriteria(criteria);
                //查询订单列表
                List<MogOrderInfo> mogOrderInfos = this.findList(query);
                for (MogOrderInfo mogOrderInfo : mogOrderInfos) {
                    list.add(mogOrderInfo);
                }
            }
            vitalOrderNoPay.setMogOrderInfos(list);
        }
        //获取总数
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("orderId"));
        AggregationResults<VitalOrderPay> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderInfo", VitalOrderPay.class);
        //封装分页信息
        Pagination<VitalOrderPay> pagination = new Pagination(page.getPageNo(), page.getPageSize(), aggResultCount.getMappedResults().size());
        pagination.setList(vitalOrderNoPays);
        return new ResultEntity(pagination);
    }

    /**
     * 已支付-分页订单号对应集合-分组deliveryId
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<Pagination<VitalOrderPay>> queryPageOrderPay(ReqOrderVo reqOrderVo) {
        //分页参数过滤
        BasePageVo page = reqOrderVo.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            return new ResultEntity(90002, "pageNo,pageSize is null");
        }
        //条件查询并销售额求和
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("deliveryId").addToSet("skuId").as("skuIds").max("orderTime").as("orderTime"),
                Aggregation.sort(new Sort(Sort.Direction.DESC, "orderTime")),
                Aggregation.skip(page.getStartRow()),
                Aggregation.limit(page.getPageSize()));
        AggregationResults<VitalOrderPay> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderInfo", VitalOrderPay.class);
        List<VitalOrderPay> vitalOrderPays = aggResult.getMappedResults();
        for (VitalOrderPay vitalOrderPay : vitalOrderPays) {
            Long deliveryId = vitalOrderPay.getId();
            //封装对象
            List<MogOrderInfo> list = new ArrayList<>();
            List<String> skuIds = vitalOrderPay.getSkuIds();
            for (String skuId : skuIds) {
                Query query = new Query();
                Criteria criteria = this.orderParamFileParentUserId(reqOrderVo, 2);
                criteria.and("deliveryId").is(deliveryId);
                criteria.and("skuId").is(skuId);
                //封装条件查询数据
                query.addCriteria(criteria);
                //查询订单列表
                List<MogOrderInfo> mogOrderInfos = this.findList(query);
                for (MogOrderInfo mogOrderInfo : mogOrderInfos) {
                    list.add(mogOrderInfo);
                }
            }
            vitalOrderPay.setMogOrderInfos(list);
        }
        //获取总数
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("deliveryId"));
        AggregationResults<VitalOrderPay> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderInfo", VitalOrderPay.class);
        //封装分页信息
        Pagination<VitalOrderPay> pagination = new Pagination(page.getPageNo(), page.getPageSize(), aggResultCount.getMappedResults().size());
        pagination.setList(vitalOrderPays);
        return new ResultEntity(pagination);
    }

    /**
     * 已支付根据配送单分组并统计
     *
     * @param reqOrderVo
     * @return
     */
    public ResultEntity<Integer> queryTotalOrderPay(ReqOrderVo reqOrderVo) {
        //获取总数
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(this.orderParamFileParentUserId(reqOrderVo, 0)),
                Aggregation.group("deliveryId"));
        AggregationResults<VitalOrderPay> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderInfo", VitalOrderPay.class);
        List<VitalOrderPay> mappedResults = aggResultCount.getMappedResults();
        int orderNum = CollectionUtils.isNotEmpty(mappedResults) ? mappedResults.size() : 0;
        return new ResultEntity(orderNum);
    }

    /**
     * 统计用户总数
     *
     * @param reqOrderVshopVo
     * @return
     */
    public ResultEntity<Integer> queryCountVshopSellParam(ReqOrderVshopVo reqOrderVshopVo) {
        //获取总数
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(this.orderVshopParamFile(reqOrderVshopVo)),
                Aggregation.group("parentUserId"));
        AggregationResults<VitalOrderVo> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderInfo", VitalOrderVo.class);
        List<VitalOrderVo> mappedResults = aggResultCount.getMappedResults();
        int parentUsreNum = CollectionUtils.isNotEmpty(mappedResults) ? mappedResults.size() : 0;
        return new ResultEntity(parentUsreNum);
    }

    /**
     * 分页统计用户订单量和销售额
     *
     * @param reqOrderVshopVo
     * @return
     */
    public ResultEntity<Pagination<VitalOrderVo>> queryPageVshopSellParam(ReqOrderVshopVo reqOrderVshopVo) {
        //分页参数过滤
        BasePageVo page = reqOrderVshopVo.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            page = new BasePageVo();
        }
        //条件查询并销售额求和
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(this.orderVshopParamFile(reqOrderVshopVo)),
                Aggregation.group("parentUserId").count().as("countOrderNum").sum("priceTotal").as("sumPriceTotal").sum("awardMoney").as("sumAwardMoney").sum("commMoney").as("sumCommMoney"),
                Aggregation.sort(new Sort(Sort.Direction.DESC, "sumPriceTotal")),
                Aggregation.skip(page.getStartRow()),
                Aggregation.limit(page.getPageSize()));
        AggregationResults<VitalOrderVo> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderInfo", VitalOrderVo.class);
        //获取总数
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(this.orderVshopParamFile(reqOrderVshopVo)),
                Aggregation.group("parentUserId"));
        AggregationResults<VitalOrderVo> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogOrderInfo", VitalOrderVo.class);
        //封装分页信息
        Pagination<VitalOrderVo> pagination = new Pagination(page.getPageNo(), page.getPageSize(), aggResultCount.getMappedResults().size());
        pagination.setList(aggResult.getMappedResults());
        return new ResultEntity(pagination);
    }

    //添加条件封装(父级不为片总)
    private Criteria orderParamFileParentUserId(ReqOrderVo reqOrderVo, Integer fileType) {
        if (fileType.equals(1)) {//过滤orderId skuId
            reqOrderVo.setOrderId(null);
            reqOrderVo.setSkuId(null);
        }
        if (fileType.equals(2)) {//过滤deliveryId skuId
            reqOrderVo.setDeliveryId(null);
            reqOrderVo.setSkuId(null);
        }
        Criteria criteria = new Criteria();
        //主键
        String id = reqOrderVo.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //订单号
        Long orderId = reqOrderVo.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //子订单号
        Long commerceId = reqOrderVo.getCommerceId();
        if (commerceId != null) {
            criteria.and("commerceId").is(commerceId);
        }
        //配送号
        String deliveryId = reqOrderVo.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            criteria.and("deliveryId").is(deliveryId);
        }
        //下单人id
        Long userId = reqOrderVo.getUserId();
        if (userId != null) {
            criteria.and("userId").is(userId);
        }
        //手机号
        String phoneNo = reqOrderVo.getPhoneNo();
        if (StringUtils.isNotBlank(phoneNo)) {
            criteria.and("phoneNo").is(phoneNo);
        }
        //用户微信昵称
        String userWeixin = reqOrderVo.getUserWeixin();
        if (StringUtils.isNotBlank(userWeixin)) {
            criteria.and("userWeixin").is(userWeixin);
        }
        //用户类型  0 普通用户  1 美店主
        Integer userType = reqOrderVo.getUserType();
        if (userType != null) {
            criteria.and("userType").is(userType);
        }
        //父级id
        Long parentUserId = reqOrderVo.getParentUserId();
        if (parentUserId != null) {
            criteria.and("parentUserId").is(parentUserId);
            reqOrderVo.setParentOutUserId(null);
        }
        //父级要排除用户id
        Long parentOutUserId = reqOrderVo.getParentOutUserId();
        if (parentOutUserId != null) {
            criteria.and("parentUserId").ne(parentOutUserId);
        }
        //片总id
        Long userIdPZ = reqOrderVo.getUserIdPZ();
        if (userIdPZ != null) {
            criteria.and("userIdPZ").is(userIdPZ);
        }
        //关系链
        List<Long> userIdRelation = reqOrderVo.getUserIdRelation();
        if (userIdRelation != null && userIdRelation.size() > 0) {
            criteria.and("userIdRelation").in(userIdRelation);
        }
        //skuId
        String skuId = reqOrderVo.getSkuId();
        if (StringUtils.isNotBlank(skuId)) {
            criteria.and("skuId").is(skuId);
        }
        //订单状态
        List<Integer> orderStatusList = reqOrderVo.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //展示状态
        List<Integer> showStatusList = reqOrderVo.getShowStatusList();
        if (showStatusList != null) {
            criteria.and("showStatus").in(showStatusList);
        }
        //订单号或微信昵称
        String orderIdUserWeixin = reqOrderVo.getOrderIdUserWeixin();
        if (StringUtils.isNotBlank(orderIdUserWeixin)) {
            if (StringUtils.isNumeric(orderIdUserWeixin)) {
                criteria.orOperator(Criteria.where("orderId").is(Long.valueOf(orderIdUserWeixin)), Criteria.where("userWeixin").is(orderIdUserWeixin));
            } else {
                criteria.and("userWeixin").is(orderIdUserWeixin);
            }
        }
        //订单时间范围
        Date orderStartTime = reqOrderVo.getOrderStartTime();
        Date orderEndTime = reqOrderVo.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        //是否剔除不存在提奖金额的订单  true:是  false:否
        Boolean awardFlag = reqOrderVo.getAwardFlag();
        if (awardFlag != null && awardFlag) {
            criteria.and("awardMoney").exists(true).ne(0);
        }
        //是否剔除不存在剩余拆单数的订单   true:是  false:否
        Boolean splitNumFlag = reqOrderVo.getSplitNumFlag();
        if (splitNumFlag != null && splitNumFlag) {
            criteria.and("skuSplitNum").exists(true);
        }
        return criteria;
    }

    //添加条件封装
    private Criteria orderParamFile(ReqOrderVo reqOrderVo) {
        Criteria criteria = new Criteria();
        //主键
        String id = reqOrderVo.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //订单号
        Long orderId = reqOrderVo.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //子订单号
        Long commerceId = reqOrderVo.getCommerceId();
        if (commerceId != null) {
            criteria.and("commerceId").is(commerceId);
        }
        //配送号
        String deliveryId = reqOrderVo.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            criteria.and("deliveryId").is(deliveryId);
        }
        //下单人id
        Long userId = reqOrderVo.getUserId();
        if (userId != null) {
            criteria.and("userId").is(userId);
        }
        //手机号
        String phoneNo = reqOrderVo.getPhoneNo();
        if (StringUtils.isNotBlank(phoneNo)) {
            criteria.and("phoneNo").is(phoneNo);
        }
        //用户微信昵称
        String userWeixin = reqOrderVo.getUserWeixin();
        if (StringUtils.isNotBlank(userWeixin)) {
            criteria.and("userWeixin").is(userWeixin);
        }
        //用户类型  0 普通用户  1 美店主
        Integer userType = reqOrderVo.getUserType();
        if (userType != null) {
            criteria.and("userType").is(userType);
        }
        //下单人直属上级id
        Long parentUserId = reqOrderVo.getParentUserId();
        if (parentUserId != null) {
            criteria.and("parentUserId").is(parentUserId);
        }
        //片总id
        Long userIdPZ = reqOrderVo.getUserIdPZ();
        if (userIdPZ != null) {
            criteria.and("userIdPZ").is(userIdPZ);
        }
        //关系链
        List<Long> userIdRelation = reqOrderVo.getUserIdRelation();
        if (userIdRelation != null && userIdRelation.size() > 0) {
            criteria.and("userIdRelation").in(userIdRelation);
        }
        //skuId
        String skuId = reqOrderVo.getSkuId();
        if (StringUtils.isNotBlank(skuId)) {
            criteria.and("skuId").is(skuId);
        }
        //订单状态
        List<Integer> orderStatusList = reqOrderVo.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //展示状态
        List<Integer> showStatusList = reqOrderVo.getShowStatusList();
        if (showStatusList != null) {
            criteria.and("showStatus").in(showStatusList);
        }
        //订单号或微信昵称
        String orderIdUserWeixin = reqOrderVo.getOrderIdUserWeixin();
        if (StringUtils.isNotBlank(orderIdUserWeixin)) {
            if (StringUtils.isNumeric(orderIdUserWeixin)) {
                criteria.orOperator(Criteria.where("orderId").is(Long.valueOf(orderIdUserWeixin)), Criteria.where("userWeixin").is(orderIdUserWeixin));
            } else {
                criteria.and("userWeixin").is(orderIdUserWeixin);
            }
        }
        //订单时间范围
        Date orderStartTime = reqOrderVo.getOrderStartTime();
        Date orderEndTime = reqOrderVo.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        //是否剔除不存在提奖金额的订单  true:是  false:否
        Boolean awardFlag = reqOrderVo.getAwardFlag();
        if (awardFlag != null && awardFlag) {
            criteria.and("awardMoney").exists(true);
        }
        //是否剔除不存在剩余拆单数的订单   true:是  false:否
        Boolean splitNumFlag = reqOrderVo.getSplitNumFlag();
        if (splitNumFlag != null && splitNumFlag) {
            criteria.and("skuSplitNum").exists(true);
        }
        return criteria;
    }

    //更新条件封装
    private Update orderParamUpdate(MogOrderInfo orderInfo) {
        Update update = new Update();
        Long orderId = orderInfo.getOrderId();
        if (orderId != null) {
            update.set("orderId", orderId);
        }
        Long commerceId = orderInfo.getCommerceId();
        if (commerceId != null) {
            update.set("commerceId", commerceId);
        }
        String deliveryId = orderInfo.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            update.set("deliveryId", deliveryId);
        }
        Long userId = orderInfo.getUserId();
        if (userId != null) {
            update.set("userId", userId);
        }
        String phoneNo = orderInfo.getPhoneNo();
        if (StringUtils.isNotBlank(phoneNo)) {
            update.set("phoneNo", phoneNo);
        }
        String userWeixin = orderInfo.getUserWeixin();
        if (StringUtils.isNotBlank(userWeixin)) {
            update.set("userWeixin", userWeixin);
        }
        String kid = orderInfo.getKid();
        if (StringUtils.isNotBlank(kid)) {
            update.set("kid", kid);
        }
        Integer userType = orderInfo.getUserType();
        if (userType != null) {
            update.set("userType", userType);
        }
        Long parentUserId = orderInfo.getParentUserId();
        if (parentUserId != null) {
            update.set("parentUserId", parentUserId);
        }
        Long userIdPZ = orderInfo.getUserIdPZ();
        if (userIdPZ != null) {
            update.set("userIdPZ", userIdPZ);
        }
        List<Long> userIdRelation = orderInfo.getUserIdRelation();
        if (userIdRelation != null && userIdRelation.size() > 0) {
            update.set("userIdRelation", userIdRelation);
        }
        String skuId = orderInfo.getSkuId();
        if (StringUtils.isNotBlank(skuId)) {
            update.set("skuId", skuId);
        }
        String skuNo = orderInfo.getSkuNo();
        if (StringUtils.isNotBlank(skuNo)) {
            update.set("skuNo", skuNo);
        }
        String skuName = orderInfo.getSkuName();
        if (StringUtils.isNotBlank(skuName)) {
            update.set("skuName", skuName);
        }
        String itemId = orderInfo.getItemId();
        if (StringUtils.isNotBlank(itemId)) {
            update.set("itemId", itemId);
        }
        Integer buyNum = orderInfo.getBuyNum();
        if (buyNum != null) {
            update.set("buyNum", buyNum);
        }
        Integer skuSplitNum = orderInfo.getSkuSplitNum();
        if (skuSplitNum != null) {
            update.set("skuSplitNum", skuSplitNum);
        }
        Long priceTotal = orderInfo.getPriceTotal();
        if (priceTotal != null) {
            update.set("priceTotal", priceTotal);
        }
        Long unitPrice = orderInfo.getUnitPrice();
        if (unitPrice != null) {
            update.set("unitPrice", unitPrice);
        }
        Long couponPrice = orderInfo.getCouponPrice();
        if (couponPrice != null) {
            update.set("couponPrice", couponPrice);
        }
        String merchantId = orderInfo.getMerchantId();
        if (StringUtils.isNotBlank(merchantId)) {
            update.set("merchantId", merchantId);
        }
        String brandCode = orderInfo.getBrandCode();
        if (StringUtils.isNotBlank(brandCode)) {
            update.set("brandCode", brandCode);
        }
        String siteId = orderInfo.getSiteId();
        if (StringUtils.isNotBlank(siteId)) {
            update.set("siteId", siteId);
        }
        Integer orderStatus = orderInfo.getOrderStatus();
        if (orderStatus != null) {
            update.set("orderStatus", orderStatus);
        }
        Integer showStatus = orderInfo.getShowStatus();
        if (showStatus != null) {
            update.set("showStatus", showStatus);
        }
        Long awardMoney = orderInfo.getAwardMoney();
        if (awardMoney != null) {
            update.set("awardMoney", awardMoney);
        }
        Long commMoney = orderInfo.getCommMoney();
        if (commMoney != null) {
            update.set("commMoney", commMoney);
        }
        Integer isPickGoods = orderInfo.getIsPickGoods();
        if (isPickGoods != null) {
            update.set("isPickGoods", isPickGoods);
        }
        Date orderTime = orderInfo.getOrderTime();
        if (orderTime != null) {
            update.set("orderTime", orderTime);
        }
        Date createTime = orderInfo.getCreateTime();
        if (createTime != null) {
            update.set("createTime", createTime);
        }
        Date updateTime = orderInfo.getUpdateTime();
        if (updateTime != null) {
            update.set("updateTime", updateTime);
        }
        return update;
    }

    //店主订单封装
    private Criteria orderVshopParamFile(ReqOrderVshopVo reqOrderVshopVo) {
        Criteria criteria = new Criteria();
        //订单状态
        List<Integer> orderStatusList = reqOrderVshopVo.getOrderStatusList();
        if (CollectionUtils.isNotEmpty(orderStatusList)) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //展示状态
        List<Integer> showStatusList = reqOrderVshopVo.getShowStatusList();
        if (CollectionUtils.isNotEmpty(showStatusList)) {
            criteria.and("showStatus").in(showStatusList);
        }
        //订单时间范围
        Date startTime = reqOrderVshopVo.getStartTime();
        Date endTime = reqOrderVshopVo.getEndTime();
        if (startTime != null && endTime != null) {
            criteria.and("orderTime").gte(startTime).lte(endTime);
        }
        return criteria;
    }

}
