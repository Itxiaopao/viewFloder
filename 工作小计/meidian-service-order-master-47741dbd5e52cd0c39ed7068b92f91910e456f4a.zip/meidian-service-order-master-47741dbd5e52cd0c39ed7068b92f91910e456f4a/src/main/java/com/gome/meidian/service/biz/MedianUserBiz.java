package com.gome.meidian.service.biz;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.enums.UserIdentityType;
import com.gome.meidian.enums.UserType;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopOrderUserInfoDto;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.manager.IMShopShareRecordManager;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.meidian.vo.MeidianUserInfoDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class MedianUserBiz {

    @Autowired
    IMShopShareRecordManager shopShareRecordManager;

    @Autowired
    IUserShareBindingManager userShareBindingManager;

    /**
     * 慎重修改，修改须与李家奇、陈晨讨论
     * 获取下单关系链
     *
     * @param userId 用户id
     * @return
     */
    @SneakyLog("获取美店用户下单关系链")
    public MeidianUserInfoDTO getUserInfo(Long userId) {
        try {
            MapResults<MshopOrderUserInfoDto> result = userShareBindingManager.queryMshopOrderDtoByUserId(userId);
            if (result == null || result.getBuessObj() == null) {
                return null;
            }
            MshopOrderUserInfoDto dto = result.getBuessObj();
            MeidianUserInfoDTO userInfo = new MeidianUserInfoDTO();
            userInfo.setUpUserId(dto.getPUserId());
            userInfo.setUserId(dto.getUserId());
            userInfo.setPianUserId(dto.getPianUserId());
            userInfo.setMid(dto.getMid());
            userInfo.setUserType(dto.getUserType());
            userInfo.setIdentityType(dto.getUserIdentity());
            if (StringUtils.isNotBlank(dto.getShareChain())) {
                String[] split = dto.getShareChain().split("-");
                List<Long> list = new ArrayList<>(split.length);
                for (String id : split) {
                    list.add(Long.valueOf(id));
                }
                userInfo.setShareChain(list);
            }
            return userInfo;
        } catch (Exception e) {
            log.info("调用美店用户关系异常，异常堆栈如下", e);
            throw new RuntimeException("调用美店用户关系异常");
        }

    }

    /**
     * 更新用户身份
     *
     * @param  userInfo 用户信息
     */
    public ResultEntity updateUserType(MeidianUserInfoDTO userInfo) {
        if (userInfo == null || !UserIdentityType.custom.getStatus().equals(userInfo.getIdentityType())) {
            return new ResultEntity(400, "该用户身份不需要更新用户类型");
        }
        if (userInfo.getUserType() == null || UserType.Visitor.getType().equals(userInfo.getUserType()) || UserType.Fans.getType().equals(userInfo.getUserType())) {
            return new ResultEntity(400, "无需更新用户类型");
        }
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        mshopShareRecordDto.setUserId(userInfo.getUserId());
        mshopShareRecordDto.setType(userInfo.getUserType());
        try {
            MapResults mapResults = shopShareRecordManager.updateUserRecord(mshopShareRecordDto);
            if (mapResults == null) {
                return new ResultEntity(500, "用户服务空值异常");
            }
            return new ResultEntity(mapResults.getCode(), mapResults.getMessage());
        } catch (Exception ex) {
            return new ResultEntity(500, "用户服务异常" + userInfo.getUserId());
        }
    }

}
