package com.gome.meidian.service.biz;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.meidian.dto.DeliveryDto;
import com.gome.meidian.dto.GoodsDto;
import com.gome.meidian.dto.OrderDto;
import com.gome.meidian.enums.GomeStateEnum;
import com.gome.meidian.mapper.order.MeidianBangbangCalcProfitMapper;
import com.gome.meidian.mapper.order.MeidianBangbangCalcTypeMapper;
import com.gome.meidian.mapper.order.MeidianBangbangErrMsgMapper;
import com.gome.meidian.mapper.order.MeidianBangbangMsgMapper;
import com.gome.meidian.mapper.order.MeidianBangbangOrderMapper;
import com.gome.meidian.service.factory.CrpOrderFactory;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.meidian.vo.MeidianBangbangCalcProfit;
import com.gome.meidian.vo.MeidianBangbangCalcType;
import com.gome.meidian.vo.MeidianBangbangErrMsg;
import com.gome.meidian.vo.MeidianBangbangMsg;
import com.gome.meidian.vo.MeidianBangbangOrder;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class MeidianBangBangOrderBiz implements CrpOrderFactory {

    @Autowired
    private MeidianBangBangOrderCacheBiz orderCacheBiz;

    @Autowired
    private MeidianBangbangOrderMapper orderMapper;

    @Autowired
    private MeidianBangbangMsgMapper msgMapper;

    @Autowired
    private MeidianBangbangErrMsgMapper errMsgMapper;

    @Autowired
    private MeidianBangbangCalcTypeMapper calcTypeMapper;

    @Autowired
    private MeidianBangbangCalcProfitMapper calcProfitMapper;

    @Autowired
    private IUserShareBindingManager userShareBindingManager;

    @Autowired
    private VshopFacade vshopFacade;

    @Resource(name = "threadPoolExecutor")
    private Executor executor;

    @Override
    @Transactional(rollbackFor = Throwable.class)
    public void processOrder(String msgId, String msgBody) {
        StringBuilder logContent = new StringBuilder(256);
        logContent.append("提成订单计算小美帮帮用户类型开始,msgId:").append(msgId);
        OrderDto orderDto = JSONObject.parseObject(msgBody, OrderDto.class);
        if (orderDto == null || StringUtils.isBlank(orderDto.getProfileId()) || StringUtils.isBlank(orderDto.getOrderId()) || CollectionUtils.isEmpty(orderDto.getDeliveryList())) {
            log.info("消费失败,失败原因:必要参数为空,msgId {} 消息体如下: {} ", msgId,msgBody);
            return;
        }
        String orderId = orderDto.getOrderId();
        String userId = orderDto.getProfileId();
        long longTypeUserId = Long.parseLong(userId);
        Set<Long> upUserIdSet = new HashSet<>();
        try {
            Date now = new Date();
            logContent.append(",orderId:").append(orderDto.getOrderId()).append(",userId:").append(userId);
            List<DeliveryDto> deliveryList = orderDto.getDeliveryList();
            for (DeliveryDto deliveryDto : deliveryList) {
                String gomeState = deliveryDto.getGomeState();
                logContent.append(",配送单id:").append(deliveryDto.getShippingGroupId()).append("订单状态:").append(gomeState);
                if (GomeStateEnum.pay.getCode().equals(gomeState)) {

                    List<GoodsDto> goodsList = deliveryDto.getGoodsList();
                    Long orderPrice = NumberUtils.yuanToFen(orderDto.getOrderPrice());
                    Long orderSalePrice = NumberUtils.yuanToFen(orderDto.getOrderSalePrice());
                    Date submittedDate = orderDto.getSubmittedDate();
                    Date payDate = orderDto.getPayDate();
                    boolean isCollect = Boolean.FALSE;
                    if (CollectionUtils.isEmpty(goodsList)) {
                        log.info("消费失败,失败原因:sku为空,msgId {} 消息体如下: {}",msgId,msgBody);
                        return;
                    }
                    //获取分享人和自购的用户集合
                    Set<String> userIdSet = goodsList.stream().map(item -> StringUtils.isEmpty(item.getRetailId()) ? userId : item.getRetailId()).collect(Collectors.toSet());
                    for (String item : userIdSet) {
                        Long upUserId = getUpUserId(userId, item, logContent);
                        if (upUserId == null) {
                            logContent.append(",upUserId:").append(item).append("上级用户id为空");
                            continue;
                        }
                        if (orderCacheBiz.existCalcProfit(upUserId, longTypeUserId, orderId)) {
                            logContent.append(",此订单已经计算过");
                            continue;
                        }
                        upUserIdSet.add(upUserId);
                        Map<String, Object> map = new HashMap<>();
                        map.put("userId", userId);
                        map.put("upUserId", upUserId);
                        MeidianBangbangCalcType model = calcTypeMapper.selectOne(map);
                        if (model == null) {
                            MeidianBangbangCalcType record = new MeidianBangbangCalcType();
                            record.setUserId(longTypeUserId);
                            record.setUpUserId(upUserId);
                            record.setCount(1);
                            record.setFirstOrderPrice(orderPrice);
                            record.setFirstOrderSalePrice(orderSalePrice);
                            record.setFirstOrderSubmittedDate(submittedDate);
                            record.setFirstOrderPayDate(payDate);
                            record.setCumulateOrderPrice(orderPrice);
                            record.setCumulateOrderSalePrice(orderSalePrice);
                            record.setLastOrderPrice(orderPrice);
                            record.setLastOrderSalePrice(orderSalePrice);
                            record.setLastOrderSubmittedDate(submittedDate);
                            record.setLastOrderPayDate(payDate);
                            record.setInsertTime(now);
                            record.setUpdateTime(now);
                            calcTypeMapper.insert(record);
                            logContent.append("新增首单用户类型,计算结果").append(JSON.toJSON(record));
                        } else {
                            model.setCount(model.getCount() + 1);
                            model.setCumulateOrderPrice(model.getCumulateOrderPrice() + orderPrice);
                            model.setCumulateOrderSalePrice(model.getCumulateOrderSalePrice() + orderSalePrice);
                            model.setLastOrderPrice(orderPrice);
                            model.setLastOrderSalePrice(orderSalePrice);
                            model.setLastOrderSubmittedDate(submittedDate);
                            model.setLastOrderPayDate(payDate);
                            model.setUpdateTime(now);
                            calcTypeMapper.update(model);
                            logContent.append("累计用户类型,计算结果").append(JSON.toJSON(model));
                        }
                        MeidianBangbangCalcProfit calcProfit = new MeidianBangbangCalcProfit();
                        calcProfit.setUpUserId(upUserId);
                        calcProfit.setUserId(longTypeUserId);
                        calcProfit.setOrderId(orderId);
                        calcProfit.setInsertTime(now);
                        calcProfitMapper.insert(calcProfit);
                        orderCacheBiz.delCalcProfit(upUserId, longTypeUserId, orderId);
                        orderCacheBiz.resetCalcType(upUserId, longTypeUserId);
                        isCollect = Boolean.TRUE;
                    }
                    if (isCollect && !orderCacheBiz.existOrder(orderId, userId)) {
                        MeidianBangbangOrder order = new MeidianBangbangOrder();
                        order.setOrderId(orderDto.getOrderId());
                        order.setReturnOrderId(orderDto.getReturnOrderId());
                        order.setProfileId(orderDto.getProfileId());
                        order.setOrderPrice(orderPrice);
                        order.setOrderSalePrice(orderSalePrice);
                        order.setSubmittedDate(submittedDate);
                        order.setPayDate(payDate);
                        order.setOrderType(orderDto.getOrderType());
                        order.setInsertTime(now);
                        orderMapper.insert(order);
                        orderCacheBiz.delOrder(orderId, userId);
                    }
                }
                if (orderCacheBiz.existOrder(orderId, userId)) {
                    MeidianBangbangMsg msg = new MeidianBangbangMsg();
                    msg.setProfileId(userId);
                    msg.setOrderId(orderId);
                    msg.setShippingGroupId(deliveryDto.getShippingGroupId());
                    msg.setGomeState(deliveryDto.getGomeState());
                    msg.setMsgId(msgId);
                    msg.setInsertTime(now);
                    msg.setMsgBody(msgBody);
                    msgMapper.insert(msg);
                }
            }
            log.info(logContent.append(",消费成功").toString());
        } catch (DuplicateKeyException e) {
            log.info(logContent.append(",此订单已受理,mySQL发生主键冲突异常,事务回滚,异常如下:{}").toString(), e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error(logContent.append(",小美帮帮计算用户类型发生异常,异常堆栈如下:").toString(), e);
            executor.execute(() -> {
                upUserIdSet.forEach(upUserId -> {
                    orderCacheBiz.delCalcProfit(upUserId, longTypeUserId, orderId);
                    orderCacheBiz.refreshCalcType(upUserId, longTypeUserId);
                });
                orderCacheBiz.delOrder(orderId, userId);
            });
            throw e;
        }
    }

    @Override
    public void exCallback(String msgId, String msgBody, Exception err) {
        try {
            OrderDto orderDto = JSONObject.parseObject(msgBody, OrderDto.class);
            List<DeliveryDto> deliveryList = orderDto.getDeliveryList();
            if (CollectionUtils.isEmpty(deliveryList)) {
                return;
            }
            for (DeliveryDto delivery : deliveryList) {
                Map<String, Object> map = new HashMap<>();
                map.put("orderId", orderDto.getOrderId());
                map.put("shippingGroupId", delivery.getShippingGroupId());
                map.put("gomeState", delivery.getGomeState());
                List<MeidianBangbangErrMsg> errMsgList = errMsgMapper.selectByBiz(map);
                if (CollectionUtils.isNotEmpty(errMsgList)) {
                    return;
                }
                MeidianBangbangErrMsg record = new MeidianBangbangErrMsg();
                record.setProfileId(orderDto.getProfileId());
                record.setOrderId(orderDto.getOrderId());
                record.setShippingGroupId(delivery.getShippingGroupId());
                record.setGomeState(delivery.getGomeState());
                record.setMsgId(msgId);
                record.setMsgBody(msgBody);
                record.setErrMsg(err.getMessage());
                record.setInsertTime(new Date());
                errMsgMapper.insert(record);
            }
        } catch (Exception e) {
            log.error("保存异常订单消息体发生异常,msgId:{},msgBody:{},err:{},异常堆栈如下", msgId, msgBody, err.getMessage(), e);
        }
    }

    /**
     * 获取上级用户id
     *
     * @param userId      购买人
     * @param shareUserId 上级id
     * @param logContent  日志
     * @return
     */
    private Long getUpUserId(String userId, String shareUserId, StringBuilder logContent) {
        long longTypeShareUserId = Long.parseLong(shareUserId);
        boolean flag = userId.equals(shareUserId);
        if (flag) {
            //自购
            MapResults<MShopShareBindingDto> userResult = userShareBindingManager.queryShareBindingByUserId(longTypeShareUserId, Collections.singletonList(1));
            //返回值费校验
            if (userResult == null || userResult.getBuessObj() == null) {
                logContent.append(",userId:").append(shareUserId).append("查不到该用户链路关系,不记录此订单,用户服务返回值:").append(JSON.toJSON(userResult));
                return null;
            }
            return userResult.getBuessObj().getUpUserId();
        }
        //分享
        CommonResultEntity<VshopInfo> vshopResult = vshopFacade.queryVshopByuserId(shareUserId);
        if (vshopResult == null || vshopResult.getBusinessObj() == null) {
            logContent.append(",userId:").append(shareUserId).append("该用户不是推手,不记录此关系产生的订单,店主服务返回值:").append(JSON.toJSON(vshopResult));
            return null;
        }
        return longTypeShareUserId;

    }
}
