package com.gome.meidian.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class MogRaceUserInfo implements Serializable {
    private static final long serialVersionUID = 4557825443648186576L;
    private Long userId;
    /**
     * 积分
     */
    private Double integral;
    /**
     * 销售额
     */
    private Long saleVolume;
    /**
     * 邀请人数
     */
    private Integer inviteUserCount;
    /**
     * 活动id
     */
    private String activityId;
    /**
     * 版本
     */
    private Integer version;
    private Date insertTime;
    private Date updateTime;
}
