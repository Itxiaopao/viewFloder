package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderFullMessage;

/**
 * @Desc 消息处理mapper
 * @author chenchen-ds6
 *
 */
public interface OrderFullMessageMapper extends BaseMapper<OrderFullMessage>{

}
