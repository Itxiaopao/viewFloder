package com.gome.meidian.enums;

/**
 * @author sunxueyan-ds
 * @Title: OrderStatus
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/2/26 15:13
 */
public enum OrderStatus {

    status1(new Byte("1"), "已支付"),
    status2(new Byte("2"), "已取消"),
    status5(new Byte("5"), "已妥投"),
    status6(new Byte("6"), "已退货");

    private Byte status;

    private String statusName;

    private OrderStatus(Byte status, String statusName) {
        this.status = status;
        this.statusName = statusName;
    }

    public Byte getStatus() {
        return status;
    }

    public String getStatusName() {
        return statusName;
    }
}
