package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class MeidianOrderMsg implements Serializable {

    private static final long serialVersionUID = -1377544819071854841L;

    private Long id;
    //订单id
    private String orderId;
    //配送单id
    private String deliveryId;
    //订单状态
    private Integer status;
    //消息id
    private String msgId;
    //消息体
    private String msgBody;
    //创建时间
    private Date insertTime;

}