package com.gome.meidian.service.impl;

import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.entity.OrderBasedTask;
import com.gome.meidian.entity.OrderImportUvData;
import com.gome.meidian.mapper.order.OrderImportUvDataMapper;
import com.gome.meidian.service.OrderImportUvDataService;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: OrderImportUvDataServiceImpl
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/3/4 20:13
 */
@Slf4j
@Service
public class OrderImportUvDataServiceImpl extends ServiceImpl<OrderImportUvDataMapper, OrderImportUvData> implements OrderImportUvDataService {

    @Autowired
    OrderImportUvDataMapper orderImportUvDataMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public Map<String, Long> insertOrUpdateBatchNum(List<OrderImportUvData> list) {
        for (OrderImportUvData entity : list) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && null != entity.getMid() && null != entity.getRecordTime()) {
                EntityWrapper<OrderImportUvData> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("mid", entity.getMid());
                wrapper.eq("record_time", entity.getRecordTime());
                OrderImportUvData orderImportUvData = selectOne(wrapper);
                if (null != orderImportUvData) {
                    if (null != entity.getUvQuantity())
                        entity.setUvQuantity(orderImportUvData.getUvQuantity() == null ? entity.getUvQuantity() : entity.getUvQuantity() + orderImportUvData.getUvQuantity());
                    if(null != entity.getShareQuantity())
                        entity.setShareQuantity(orderImportUvData.getShareQuantity() == null ? entity.getShareQuantity() : entity.getShareQuantity() + orderImportUvData.getShareQuantity());
                }
            }
        }
        return insertOrUpdateBatchMethod(list, 30);
    }


    /**
     * 批量插入修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @return boolean
     */
    private Map<String, Long> insertOrUpdateBatchMethod(List<OrderImportUvData> entityList, int batchSize) {
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        Long count = 0l;
        Map<String, Long> resultMap = new HashMap<>();
        resultMap.put("insertNum", 0l);
        resultMap.put("updateNum", 0l);
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            for (int i = 0; i < size; i++) {
                entityList.get(i).setUpdateTime(new Date());
                resultMap = insertOrUpdateReal(entityList.get(i), resultMap);
                if (i >= 1 && i % batchSize == 0) {
                    batchSqlSession.flushStatements();
                }
            }
            batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertOrUpdateBatch Method. Cause", e);
        }
        return resultMap;
    }


    /**
     * <p>
     * TableId 注解存在更新记录，否插入一条记录
     * </p>
     *
     * @param entity 实体对象
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateReal(OrderImportUvData entity, Map<String, Long> resultMap) {
//        Map<String, Long> resultMap = new HashMap<>();
        Boolean flag = false;
        Long updateNum = 0l;
        Long insertNum = 0l;
        if (null != entity) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && null != entity.getMid() && null != entity.getRecordTime()) {
                /*
                 * 更新成功直接返回，失败执行插入逻辑
                 */
                EntityWrapper<OrderImportUvData> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("mid", entity.getMid());
                wrapper.eq("record_time", entity.getRecordTime());
                flag = update(entity, wrapper);
                if (!flag) {
                    flag = insert(entity);
                    if (flag) {
                        insertNum = resultMap.get("insertNum");
                        insertNum++;
                        resultMap.put("insertNum", insertNum);
                    }
                } else {
                    updateNum = resultMap.get("updateNum");
                    updateNum++;
                    resultMap.put("updateNum", updateNum);
                }
                return resultMap;
//                return update(entity, wrapper) || insert(entity);
            }
        } else {
            throw new MybatisPlusException("Error:  Can not execute. Could not find @TableId.");
        }
//        }
        return resultMap;
    }
}
