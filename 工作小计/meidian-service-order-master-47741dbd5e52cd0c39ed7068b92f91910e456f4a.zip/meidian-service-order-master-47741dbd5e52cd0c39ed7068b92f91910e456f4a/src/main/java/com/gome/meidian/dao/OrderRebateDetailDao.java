package com.gome.meidian.dao;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.vo.MogOrderRebateDetail;
import com.gome.meidian.vo.ReqOrderVo;
import com.mongodb.DuplicateKeyException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Slf4j
@Repository
public class OrderRebateDetailDao extends MongGenDao<MogOrderRebateDetail> {

    @Override
    protected Class getEntityClass() {
        return MogOrderRebateDetail.class;
    }

    public ResultEntity<Boolean> saveRecord(MogOrderRebateDetail record) {
        if (record == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        record.setCreateTime(new Date());
        try {
            this.save(record);
            return new ResultEntity<>(Boolean.TRUE);
        } catch (DuplicateKeyException e) {
            log.info("保存订单返利信息因主键冲突插入失败,入参:{}", JSON.toJSON(record));
            return new ResultEntity<>(Boolean.FALSE);
        } catch (Exception e) {
            String format = String.format("保存订单返利信息发生异常,入参:%s,异常堆栈如下：", JSON.toJSON(record));
            log.error(format, e);
            return new ResultEntity<>(Boolean.FALSE);
        }
    }

    public ResultEntity<Boolean> delRecord(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity<>(402, "id不能为空");
        }
        this.deleteById(id);
        return new ResultEntity<>(Boolean.TRUE);
    }

    public ResultEntity<Boolean> updateRecord(MogOrderRebateDetail record) {
        if (record == null || record.getId() == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        //多条件嵌入
        Query query = Query.query(Criteria.where("_id").is(record.getId()));
        //封装更新数据
        Update update = this.updateParam(record);
        this.updateMulti(query, update);
        return new ResultEntity<>(Boolean.TRUE);
    }

    public ResultEntity<List<MogOrderRebateDetail>> queryListByBiz(ReqOrderVo param) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.queryParam(param));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "orderTime"));
        //查询订单列表
        List<MogOrderRebateDetail> list = this.findList(query);
        return new ResultEntity<>(list);
    }

    public ResultEntity<Long> getCommMoneyByBiz(ReqOrderVo reqOrderVo) {
        //条件查询并销售额求和
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(this.queryParam(reqOrderVo)),
                Aggregation.group("deliveryId").sum("commMoney").as("commMoney"));
        AggregationResults<MogOrderRebateDetail> aggResult = this.mongoTemplate.aggregate(aggregation, "mogOrderRebateDetail", MogOrderRebateDetail.class);
        Long commMoney = aggResult.getUniqueMappedResult() == null ? null : aggResult.getUniqueMappedResult().getCommMoney();
        return new ResultEntity<>(commMoney);
    }

    /**
     * 更新条件封装
     *
     * @param record
     * @return
     */
    private Update updateParam(MogOrderRebateDetail record) {
        Update update = new Update();
        Long orderId = record.getOrderId();
        if (orderId != null) {
            update.set("orderId", orderId);
        }
        String deliveryId = record.getDeliveryId();
        if (deliveryId != null) {
            update.set("deliveryId", deliveryId);
        }
        String skuId = record.getSkuId();
        if (skuId != null) {
            update.set("skuId", skuId);
        }
        Long commMoney = record.getCommMoney();
        if (commMoney != null) {
            update.set("commMoney", commMoney);
        }
        Integer status = record.getStatus();
        if (status != null) {
            update.set("status", status);
        }
        Date orderTime = record.getOrderTime();
        if (orderTime != null) {
            update.set("orderTime", orderTime);
        }
        return update;
    }

    /**
     * 添加条件封装
     *
     * @param param 请求参数
     * @return
     */
    private Criteria queryParam(ReqOrderVo param) {
        Criteria criteria = new Criteria();
        //主键
        String id = param.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //订单号
        Long orderId = param.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //配送号
        String deliveryId = param.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            criteria.and("deliveryId").is(deliveryId);
        }
        //skuId
        String skuId = param.getSkuId();
        if (StringUtils.isNotBlank(skuId)) {
            criteria.and("skuId").is(skuId);
        }
        //订单状态
        List<Integer> orderStatusList = param.getOrderStatusList();
        if (CollectionUtils.isNotEmpty(orderStatusList)) {
            criteria.and("status").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = param.getOrderStartTime();
        Date orderEndTime = param.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        return criteria;
    }

}
