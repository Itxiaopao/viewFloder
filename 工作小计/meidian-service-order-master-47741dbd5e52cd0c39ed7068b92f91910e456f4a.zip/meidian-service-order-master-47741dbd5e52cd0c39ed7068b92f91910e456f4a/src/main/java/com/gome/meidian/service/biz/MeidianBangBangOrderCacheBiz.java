package com.gome.meidian.service.biz;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.config.aspect.annotation.CacheEvict;
import com.gome.boot.adapter.config.aspect.annotation.Cacheable;
import com.gome.boot.adapter.utils.CommUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.mapper.order.MeidianBangbangCalcProfitMapper;
import com.gome.meidian.mapper.order.MeidianBangbangCalcTypeMapper;
import com.gome.meidian.mapper.order.MeidianBangbangOrderMapper;
import com.gome.meidian.vo.MeidianBangbangCalcProfit;
import com.gome.meidian.vo.MeidianBangbangCalcType;
import redis.Gcache;

@Service
public class MeidianBangBangOrderCacheBiz {

    @Autowired
    private Gcache gcache;

    @Autowired
    private MeidianBangbangOrderMapper orderMapper;

    @Autowired
    private MeidianBangbangCalcProfitMapper calcProfitMapper;

    @Autowired
    private MeidianBangbangCalcTypeMapper meidianBangbangCalcTypeMapper;

    /**
     * 设置 计算用户类型缓存
     *
     * @param model 计算用户类型实体
     */
    public void setCalcType(MeidianBangbangCalcType model) {
        if (model == null) {
            return;
        }
        String dbKey = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_STR_PREFIX, model.getUpUserId(), model.getUserId());
        gcache.set(dbKey, JSON.toJSONBytes(model));
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER, model.getUpUserId());
        Date firstOrderPayDate = model.getFirstOrderPayDate();
        gcache.zadd(key, firstOrderPayDate == null ? System.currentTimeMillis() : firstOrderPayDate.getTime(), String.valueOf(model.getUserId()));
        if (model.getCount() > 3) {
            String redisKey = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS, model.getUpUserId());
            Date lastOrderPayDate = model.getLastOrderPayDate();
            gcache.zadd(redisKey, lastOrderPayDate == null ? System.currentTimeMillis() : lastOrderPayDate.getTime(), String.valueOf(model.getUserId()));
        }
    }

    /**
     * 重新设置缓存(查库)
     *
     * @param upUserId 上级用户id
     * @param userId   用户id
     */
    public void resetCalcType(Long upUserId, Long userId) {
        Map<String, Object> map = new HashMap<>();
        map.put("userId", userId);
        map.put("upUserId", upUserId);
        MeidianBangbangCalcType meidianBangbangCalcType = meidianBangbangCalcTypeMapper.selectOne(map);
        this.setCalcType(meidianBangbangCalcType);
    }

    /**
     * 删除缓存
     *
     * @param upUserId 上级用户id
     * @param userId   用户id
     */
    public void removeCalcType(Long upUserId, Long userId) {
        String dbKey = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_STR_PREFIX, upUserId, userId);
        gcache.del(dbKey);
        String firstOrderKey = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER, upUserId);
        String s = String.valueOf(userId);
        gcache.zrem(firstOrderKey, s);
        String loyalOrderKey = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS, upUserId);
        gcache.zrem(loyalOrderKey, s);
    }

    /**
     * 删除缓存-查db-设置缓存
     *
     * @param upUserId 上级用户id
     * @param userId   用户id
     */
    public void refreshCalcType(Long upUserId, Long userId) {
        this.removeCalcType(upUserId, userId);
        this.resetCalcType(upUserId, userId);
    }

    /**
     * 获取计算用户类型
     *
     * @param upUserId 上级用户id
     * @param userId   用户id
     * @return
     */
    public MeidianBangbangCalcType getCalcType(Long upUserId, Long userId) {
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_STR_PREFIX, upUserId, userId);
        String val = gcache.get(key);
        if (StringUtils.isEmpty(val)) {
            return null;
        }
        return JSONObject.parseObject(val, MeidianBangbangCalcType.class);
    }

    public List<MeidianBangbangCalcType> multiGetCalcType(Long upUserId, Set<String> userIdSet) {
        if (upUserId == null) {
            return new ArrayList<>();
        }
        if (CollectionUtils.isEmpty(userIdSet)) {
            return new ArrayList<>();
        }
        String[] keys = new String[userIdSet.size()];
        int i = 0;
        for (String key : userIdSet) {
            keys[i] = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_STR_PREFIX, upUserId, key);
            i++;
        }
        Map<String, String> map = gcache.multiGet(keys);
        if (com.gome.boot.adapter.utils.CollectionUtils.isEmpty(map)) {
            return new ArrayList<>();
        }
        List<MeidianBangbangCalcType> list = new ArrayList<>(map.size());
        for (String key : keys) {
            String val = map.get(key);
            if (StringUtils.isNotEmpty(val)) {
                list.add(JSONObject.parseObject(val, MeidianBangbangCalcType.class));
            }
        }
        return list;
    }

    /**
     * 获取下级用户首单忠粉数量
     *
     * @param userId 用户
     * @param type   类型 Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER 首单,Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS 忠粉
     * @return
     */
    public Long getSubordinateCount(Long userId, Integer type) {
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, type, userId);
        return gcache.zcard(key);
    }

    /**
     * @param userId    用户
     * @param type      类型 Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER 首单,Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS 忠粉
     * @param startTime 筛选开始时间
     * @param endTime   筛选结束时间
     * @return
     */
    public Long getSubordinateCountByScore(Long userId, Integer type, Double startTime, Double endTime) {
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, type, userId);
        return gcache.zcount(key, startTime, endTime);
    }

    /**
     * 时间段获取列表
     *
     * @param userId    用户id
     * @param type      类型 Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER 首单,Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS 忠粉
     * @param startTime 筛选开始时间
     * @param endTime   筛选结束时间
     * @return
     */
    public Set<String> getSubordinateListByScore(Long userId, Integer type, Double startTime, Double endTime) {
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, type, userId);
        return gcache.zrangeByScore(key, startTime, endTime);
    }

    /**
     * 分页获取列表
     *
     * @param userId    用户id
     * @param type      类型 Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER 首单,Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS 忠粉
     * @param pageIndex 开始下标
     * @param pageSize  页面大小
     * @return
     */
    public Set<String> getSubordinatePage(Long userId, Integer type, Integer pageIndex, Integer pageSize) {
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, type, userId);
        return gcache.zrevrangeByScore(key, "+inf", "-inf", pageIndex, pageSize);
    }

    /**
     * 获取所有的member
     *
     * @param userId 用户id
     * @param type   类型 Constant.CRP_ORDER_BANGBANG_CALC_TYPE_FIRST_ORDER 首单,Constant.CRP_ORDER_BANGBANG_CALC_TYPE_LOYAL_FANS 忠粉
     * @return
     */
    public Set<String> getSubordinate(Long userId, Integer type) {
        String key = CommUtils.getRedisKey(Constant.CRP_ORDER_BANGBANG_CALC_TYPE_ZSET_PREFIX, type, userId);
        return gcache.zrangeByScore(key, "+inf", "-inf");
    }


    @Cacheable(value = "是否存在小美帮帮订单计算记录", prefix = Constant.CRP_ORDER_BANGBANG_CALC_PROFIT_STR_PREFIX, seconds = Constant.SECONDS_IN_GCACHE_THIRDMONTH)
    public Boolean existCalcProfit(Long upUserId, Long userId, String orderId) {
        Map<String, Object> map = new HashMap<>(3);
        map.put("upUserId", upUserId);
        map.put("userId", userId);
        map.put("orderId", orderId);
        List<MeidianBangbangCalcProfit> list = calcProfitMapper.selectByBiz(map);
        return CollectionUtils.isNotEmpty(list);
    }

    @CacheEvict(value = "删除小美帮帮订单计算记录", prefix = Constant.CRP_ORDER_BANGBANG_CALC_PROFIT_STR_PREFIX)
    public void delCalcProfit(Long upUserId, Long userId, String orderId) {
    }

    @Cacheable(value = "是否存在过该订单", prefix = Constant.CRP_ORDER_BANGBANG_USER_ORDER_STR_PREFIX, seconds = Constant.SECONDS_IN_GCACHE_THIRDMONTH)
    public Boolean existOrder(String orderId, String profileId) {
        Map<String, Object> map = new HashMap<>();
        map.put("orderId", orderId);
        map.put("profileId", profileId);
        return orderMapper.selectOne(map) != null;
    }

    @CacheEvict(value = "删除记录过该订单", prefix = Constant.CRP_ORDER_BANGBANG_USER_ORDER_STR_PREFIX)
    public void delOrder(String orderId, String profileId) {
    }
}
