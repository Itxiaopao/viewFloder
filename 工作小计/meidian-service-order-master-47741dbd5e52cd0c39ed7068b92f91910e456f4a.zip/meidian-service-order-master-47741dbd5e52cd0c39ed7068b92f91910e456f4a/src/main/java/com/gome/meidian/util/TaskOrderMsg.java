package com.gome.meidian.util;

import com.gome.meidian.dao.MeidianOrderMsgDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

@Component
@EnableScheduling
public class TaskOrderMsg {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private MeidianOrderMsgDao meidianOrderMsgDao;
	
	//每月定时清除消息记录
	@SuppressWarnings("unused")
//	@Scheduled(cron="0 0 0 1 * ?")
	public void cleanOrderMsg(){
		try{
			RestTemplate restTemplate = new RestTemplate();
			Date upMonthTime = DateUtils.getUpMonthTime();
			meidianOrderMsgDao.delOrderMsgByTime(upMonthTime);
		}catch(Exception e){
			logger.info("定时删除订单记录异常");
		}
	}
	
}
