package com.gome.meidian.mq;

import com.alibaba.rocketmq.client.consumer.DefaultMQPushConsumer;
import com.alibaba.rocketmq.client.consumer.listener.*;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.common.consumer.ConsumeFromWhere;
import com.alibaba.rocketmq.common.message.MessageExt;
import com.alibaba.rocketmq.common.protocol.heartbeat.MessageModel;
import com.gome.boot.adapter.utils.SerializeUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.service.factory.OmsOrderFactory;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import redis.Gcache;

import javax.annotation.PostConstruct;
import java.util.Map;

@Slf4j
//@Component
public class OmsOrderConsumer {

    @Value("${mq.address}")
    private String namesrvAddr;
    @Value("${mq.omsOrder.topic}")
    private String topic;
    @Value("${mq.omsOrder.group}")
    private String group;
    @Value("${mq.omsOrder.instanceName}")
    private String instanceName;

    @Autowired
    private ApplicationContext applicationContext;

    @Autowired
    private Gcache gcache;

    @PostConstruct
    @SneakyThrows(MQClientException.class)
    public void init() {
        Map<String, OmsOrderFactory> beanMap = applicationContext.getBeansOfType(OmsOrderFactory.class);
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(group);
        consumer.setNamesrvAddr(namesrvAddr);
        consumer.setInstanceName(instanceName);
        consumer.subscribe(topic, "*");
        consumer.setConsumeFromWhere(ConsumeFromWhere.CONSUME_FROM_LAST_OFFSET);
        consumer.setMessageModel(MessageModel.CLUSTERING);
        consumer.registerMessageListener((MessageListenerOrderly) (msgs, context) -> {
            MessageExt msg = msgs.get(0);
            String msgId = msg.getMsgId();
            Object object = SerializeUtils.unserialize(msgId, msg.getBody());
            if (object == null) {
                return ConsumeOrderlyStatus.SUCCESS;
            }
            String msgBody = object.toString();
            for (String beanName : beanMap.keySet()) {
                OmsOrderFactory omsOrderFactory = beanMap.get(beanName);
                try {
                    omsOrderFactory.processOrder(msgId, msgBody);
                } catch (Exception e) {
                    omsOrderFactory.exCallback(msgId, msgBody);
                    log.error("{},解析异常,失败msgId:{},失败原因:{}", beanName, msg.getMsgId(), e.getMessage());
                    return gcache.increx(Constant.OMS_ORDER_RETRY_COUNT_INCR_PREFIX + msgId, Constant.SECONDS_IN_GCACHE_ONEDAY) >= 3 ?
                            ConsumeOrderlyStatus.SUCCESS : ConsumeOrderlyStatus.SUSPEND_CURRENT_QUEUE_A_MOMENT;
                }
            }
            return ConsumeOrderlyStatus.SUCCESS;
        });
        consumer.start();
        log.info("OmsOrderConsumer Started... MQAddress:{} ,group:{}, topic:{}", namesrvAddr, group, topic);
    }

}