package com.gome.meidian.service.biz;

import cn.com.gome.rebate.calc.Delivery;
import cn.com.gome.rebate.calc.GoodsDto;
import cn.com.gome.rebate.calc.OrderDto;
import com.alibaba.fastjson.JSON;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.dao.MeidianOrderDao;
import com.gome.meidian.entity.OrderFullMessage;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.service.IOrderFullMessageService;
import com.gome.meidian.service.impl.NewOrderServiceImpl;
import com.gome.meidian.service.util.OrderStatusUtil;
import com.gome.meidian.util.CommUtils;
import com.gome.meidian.vo.MeidianUserInfoDTO;
import com.gome.meidian.vo.MogOrderInfo;
import com.gome.meidian.vo.ReqOrderVo;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import com.gome.userBase.model.weChat.GomeShopBasicInfoModel;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
@Slf4j
public class ReceiveOrderBiz {

    @Autowired
    IOrderFullMessageService orderFullMessageService;
    @Autowired
    MeidianOrderDao medianOrderDAO;
    @Autowired
    NewOrderServiceImpl newOrderService;
    @Autowired
    private IGomeShopWeChatFacade gomeShopWeChatFacade;
    @Autowired
    private ReceiveOrderBodyBiz receiveOrderBodyBiz;
    @Autowired
    private ReceiveOrderBiz receiveOrderBiz;
    @Autowired
    private Gcache gcache;
    @Autowired
    private RedisLockUtils redisLockUtils;

    final long addtime = 0;

    /**
     * 根据订单号，skuId,配送单id获取对象
     *
     * @param orderId    订单号
     * @param skuId      skuId
     * @param deliveryId 配送单id
     * @return
     */
    public MogOrderInfo getOrderInfoById(Long orderId, String skuId, String deliveryId) {
        ReqOrderVo req = new ReqOrderVo();
        req.setOrderId(orderId);
        req.setDeliveryId(deliveryId);
        req.setSkuId(skuId);
        ResultEntity<List<MogOrderInfo>> result = medianOrderDAO.queryOrderList(req);
        if (result.getCode() == 0 && CollectionUtils.isNotEmpty(result.getBusinessObj())) {
            return result.getBusinessObj().get(0);
        }
        return null;
    }

    //根据订单，SKUId与状态查询
    public MogOrderInfo getOrderInfoBySkuId(Long orderId, String skuId, Integer status) {
        MogOrderInfo info = null;
        ReqOrderVo req = new ReqOrderVo();
        req.setOrderId(orderId);
        req.setSkuId(skuId);
        List<Integer> statusList = new ArrayList<>();
        statusList.add(status);
        req.setShowStatusList(statusList);
        ResultEntity<List<MogOrderInfo>> result = medianOrderDAO.queryOrderList(req);
        if (result.getCode() == 0) {
            if (result.getBusinessObj() != null && result.getBusinessObj().size() > 0) {
                info = result.getBusinessObj().get(0);
            }
        }
        return info;
    }

    // 修改或者新增订单记录
    public boolean updateOrderInfo(MogOrderInfo orderInfo) {
        if (orderInfo == null) {
            //空参数不可以保存
            return Boolean.FALSE;
        }
        orderInfo.setUpdateTime(new Date());
        try {
            ResultEntity<?> result = medianOrderDAO.updateOrderData(orderInfo);
            return result.getCode() == 0;
        } catch (Exception e) {
            String format = String.format("更新mongo异常,入参:%s,异常堆栈如下", JSON.toJSON(orderInfo));
            log.error(format, e);
            return Boolean.FALSE;
        }
    }

    /**
     * 修改或者新增订单记录
     *
     * @param orderInfo
     * @param userInfo
     * @return
     */
    public boolean addOrderInfo(MogOrderInfo orderInfo, MeidianUserInfoDTO userInfo) {
        if (orderInfo == null) {
            //空值不允许插入
            return Boolean.FALSE;
        }
        orderInfo.setUserId(userInfo.getUserId());
        orderInfo.setParentUserId(userInfo.getUpUserId());
        orderInfo.setUserIdPZ(userInfo.getPianUserId());
        orderInfo.setUserType(userInfo.getIdentityType()); //下单用户身份
        orderInfo.setUserIdRelation(userInfo.getShareChain());
        try {
            UserResult<List<GomeShopBasicInfoModel>> userResult = gomeShopWeChatFacade.batchQueryUserBasicInfo(Lists.newArrayList(String.valueOf(userInfo.getUserId())), "gomeShop");
            if (userResult.isSuccess() && CollectionUtils.isNotEmpty(userResult.getBuessObj())) {
                GomeShopBasicInfoModel userModel = userResult.getBuessObj().get(0);
                orderInfo.setPhoneNo(userModel.getMobile());
                orderInfo.setUserWeixin(userModel.getWeixinNickName());
            }
        } catch (Exception e) {
            String format = String.format("com.gome.meidian.service.biz.ReceiveOrderBiz.addOrderInfo 调用会员接口发生异常 userId: %s,异常堆栈如下", userInfo.getUserId());
            log.error(format, e);
        }
        String lockKey = CommUtils.getRedisKey(Constant.PAY_ORDER_MUTEX_LOCK_PREFIX, orderInfo.getOrderId(), orderInfo.getDeliveryId(), orderInfo.getSkuId(), orderInfo.getOrderStatus());
        boolean mutexLock = Boolean.FALSE;
        try {
            mutexLock = redisLockUtils.mutexLock(lockKey);
            MogOrderInfo mogOrderInfo = receiveOrderBiz.getOrderInfoById(orderInfo.getOrderId(), orderInfo.getSkuId(), orderInfo.getDeliveryId());
            ResultEntity result;
            if (mogOrderInfo == null) {
                result = medianOrderDAO.saveOrderInfo(orderInfo);
            } else {
                orderInfo.setId(mogOrderInfo.getId());
                result = medianOrderDAO.updateOrderData(orderInfo);
            }
            return result.getCode() == 0;
        } catch (Exception e) {
            String format = String.format("com.gome.meidian.service.biz.ReceiveOrderBiz.addOrderInfo 保存订单记录失败 保存记录：%s,异常堆栈如下", JSON.toJSON(orderInfo));
            log.error(format, e);
            return Boolean.FALSE;
        } finally {
            redisLockUtils.unlock(mutexLock, lockKey);
        }
    }

    //添加订单
    public boolean addOrderInfo(MogOrderInfo orderInfo) {
        boolean res = false;
        try {
            ResultEntity<?> result = medianOrderDAO.saveOrderInfo(orderInfo);
            if (result.getCode() == 0) {
                res = true;
            }
        } catch (Exception ex) {
            log.error("ReceiveOrderServiceImpl -addOrderInfo 插入数据失败,失败数据为:{},失败原因{}", orderInfo.getOrderId(),
                    ex.getMessage());
        }
        return res;
    }

    // 保存订单实体
    public void saveOrderBody(String msgJson, String msgId, MogOrderInfo order) {
        try {
            // 先判断 避免重复
            OrderFullMessage orderFullMessage = new OrderFullMessage();
            orderFullMessage.setMsgJson(msgJson);
            orderFullMessage.setOrderId(Long.valueOf(order.getOrderId()));
            orderFullMessage.setCommerceId(order.getCommerceId());
            orderFullMessage.setDeliveryId(order.getDeliveryId());
            orderFullMessage.setDesc1(msgId);
            orderFullMessage.setDesc2(order.getDeliveryId());
            orderFullMessage.setCreateTime(order.getOrderTime());
            orderFullMessage.setOrderStatus(order.getOrderStatus());
            orderFullMessage.setUpdateTime(new Date());
            orderFullMessageService.insert(orderFullMessage);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            // orderErrorUtil.insertLog(order, "插入消息表失敗");
        }
    }

    //对象转化
    public MogOrderInfo buildMogOrderInfo(OrderDto vo, Delivery delivery, GoodsDto goodsDto) {
        MogOrderInfo order = new MogOrderInfo();
        order.setOrderId(Long.parseLong(vo.getOrderId()));
        order.setCommerceId(Long.parseLong(goodsDto.getOrderItemId()));
        order.setDeliveryId(delivery.getDeliveryOrderId());
        order.setKid(goodsDto.getKid());
        order.setSkuId(goodsDto.getSkuId());
        order.setSkuNo(goodsDto.getSkuNo());
        order.setSkuName(goodsDto.getSkuName());
        order.setItemId(goodsDto.getItemId());
        order.setBuyNum(goodsDto.getBuyNum());
        order.setPriceTotal(goodsDto.getPrice() * (goodsDto.getBuyNum()) - (goodsDto.getShopCouponPrice()));
        order.setUnitPrice(goodsDto.getPrice());
        Long retailId = StringUtils.isNumeric(goodsDto.getRetailId()) ? Long.valueOf(goodsDto.getRetailId()) : null;
        order.setRetailId(retailId);
        order.setCouponsDtoList(goodsDto.getCouponsDtoList());
        order.setMerchantId(ObjectUtils.defaultIfNull(goodsDto.getMerchantId(), "0"));
        order.setSiteId(vo.getSiteId());
        order.setOrderStatus(delivery.getStatus());
        order.setShowStatus(OrderStatusUtil.getShowStatus(delivery.getStatus()));
        order.setOrderTime(vo.getOrderSubmitDate());
        Date now = new Date();
        order.setCreateTime(now);
        order.setUpdateTime(now);
        return order;
    }

    //根据订单号和skuId和剩余拆单量获取实例
    public List<MogOrderInfo> getOrderInfoByOrderIdSkuId(Long orderId, String skuId, Boolean flag) {
        List<MogOrderInfo> infos = null;
        ReqOrderVo req = new ReqOrderVo();
        req.setOrderId(orderId);
        req.setSkuId(skuId);
        req.setSplitNumFlag(flag);
        ResultEntity<List<MogOrderInfo>> result = medianOrderDAO.queryOrderList(req);
        if (result.getCode() == 0) {
            if (result.getBusinessObj() != null && result.getBusinessObj().size() > 0) {
                infos = result.getBusinessObj();
            }
        }
        return infos;
    }

    //订单商品配送单获取数据
    public MogOrderInfo getOrderInfoByOrderIdDeliveryIdSkuId(Long orderId, String deliveryId, String skuId) {
        ReqOrderVo req = new ReqOrderVo();
        req.setOrderId(orderId);
        req.setDeliveryId(deliveryId);
        req.setSkuId(skuId);
        ResultEntity<List<MogOrderInfo>> result = medianOrderDAO.queryOrderList(req);
        if (result.getCode() == 0 && CollectionUtils.isNotEmpty(result.getBusinessObj())) {
            return result.getBusinessObj().get(0);
        }
        return null;
    }

    //获取订单列表
    public List<MogOrderInfo> getOrderInfoByOrderId(Long orderId) {
        List<MogOrderInfo> infos = null;
        ReqOrderVo req = new ReqOrderVo();
        req.setOrderId(orderId);
        ResultEntity<List<MogOrderInfo>> result = medianOrderDAO.queryOrderList(req);
        if (result.getCode() == 0) {
            if (result.getBusinessObj() != null && result.getBusinessObj().size() > 0) {
                infos = result.getBusinessObj();
            }
        }
        return infos;
    }

}
