package com.gome.meidian.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.gome.meidian.entity.MidOrderInfo;
import com.gome.meidian.mapper.order.OrderEffectMapper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.gome.meidian.entity.MshopInfo;
import com.gome.meidian.entity.OrderEffect;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.service.IOrderBodyErrorService;
import com.gome.meidian.service.IOrderChannelService;
import com.gome.meidian.service.IOrderEffectService;
import com.gome.meidian.service.IOrderOccurService;
import com.gome.meidian.service.util.OrderErrorLogUtil;

/**
 * <p>
 * 妥投单表 服务实现类
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
@Service
public class OrderEffectServiceImpl extends ServiceImpl<OrderEffectMapper, OrderEffect> implements IOrderEffectService {

	private Logger logger = LoggerFactory.getLogger(getClass());


	@Autowired
	IOrderChannelService orderChannelSvc;

	@Autowired
	IOrderOccurService orderOccurSvc;

	@Autowired
	IOrderBodyErrorService orderBodyErrorSvc;
	
	@Autowired
	OrderErrorLogUtil errorLogUtil;
	
	@Autowired
	OrderEffectMapper orderMapper;

	@Override
	@Transactional(rollbackFor = Throwable.class)
	public boolean insertEffectOrder(OrderEffect orderEffect) {
		HashMap<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("order_id", orderEffect.getOrderId());
		queryMap.put("commerce_id", orderEffect.getCommerceId());
		queryMap.put("delivery_id", orderEffect.getDeliveryId());
		if(!CollectionUtils.isEmpty(this.selectByMap(queryMap))){
			return true;
		}
		try {
			// 插入妥投表
			boolean orderEffectInsert = this.insert(orderEffect);
			if(!orderEffectInsert) {
				logger.info("-------------插入妥投表失败orderEffect"+orderEffect.toString());
				errorLogUtil.insertLog(orderEffect, "插入妥投表失败");
			}
			// 发生表插入
			List<OrderOccur> orderOccurs = orderOccurSvc.selectByMap(queryMap);
			if (CollectionUtils.isEmpty(orderOccurs)) {
				OrderOccur orderOccur = new OrderOccur();
				BeanUtils.copyProperties(orderEffect, orderOccur);
				orderOccur.setOrderType(0);
				boolean orderOccurInsert = orderOccurSvc.insert(orderOccur);
				if(!orderOccurInsert) {
					logger.info("-------------插入发生表(妥投之后的插发生表,发生时发生表未插入)orderOccur"+orderOccur.toString());
					errorLogUtil.insertLog(orderOccur, "妥投之后插入发生表失败");
				}
			}			
			return orderEffectInsert;
/*			// 渠道表查询
			List<OrderChannel> orderChannels = orderChannelSvc.selectByMap(queryMap);
			if (CollectionUtils.isEmpty(orderChannels)) {
				OrderChannel orderChannel = new OrderChannel();
				BeanUtils.copyProperties(orderEffect, orderChannel);
				orderChannelSvc.insert(orderChannel);
			}*/
		} catch (Exception e) {
			errorLogUtil.insertLog(orderEffect, e.getMessage());
			throw e;
		}
	}

	@Override
	public List<OrderEffect> selectByDateRange(HashMap<String, Object> queryParams) {
		String object = queryParams.get("mid").toString();
		String[] splitStr = StringUtils.strip(object, "[]").split(",");
		String temp = convertList(splitStr);
		queryParams.put("mid", temp);
		List<OrderEffect> orderEffects = orderMapper.selectByDateRange(queryParams);		
		return orderEffects;
	}

	private String convertList(String[] params) {
		String temp = "";
		int size = params.length;
		for (int i = 0 ; i < size ; i++) {
			if(i != size - 1) {
				temp += "'"+params[i].trim()+"',";
			}else {
				temp += "'"+params[i].trim()+"'";
			}
		}
		return temp;
	}
	/**
	 * 查询增量订单mid
	 * @param queryParams
	 * @return
	 */
	@Override
	public MshopInfo selectByDateRangeFromBsSchedule(HashMap<String, Object> queryParams) {
		MshopInfo resultEntity = new MshopInfo();
		try {
			//24小时制时间格式
			SimpleDateFormat sdformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Object taskItems = queryParams.get("taskItems");
			Object taskQueueNum = queryParams.get("taskQueueNum");
			Object startDate = queryParams.get("startDate");
			Object endDate = queryParams.get("endDate");

			if(taskItems == null){
				return resultEntity;
			}
			String taskItemsString=(String)taskItems;
			//分片键
			String[] taskItemsArray=taskItemsString.split(",");
			List<String> taskItemList= Arrays.asList(taskItemsArray);
			if(taskQueueNum == null){
				return resultEntity;
			}

			String taskQueueNumString=(String)taskQueueNum;
			//分片键大小
			Integer taskQueueNumInteger=new Integer(taskQueueNumString);

			if(startDate == null){
				return resultEntity;
			}

			queryParams.put("startDate", startDate);


			if(endDate == null){
				return resultEntity;
			}

			queryParams.put("endDate", endDate);

			//妥投
			List<String> midStringArray = orderMapper.selectByOnlyDateRange(queryParams);
			Set<Long>  midLongSet=new HashSet<Long>();
			List<Long> midLongArray=new ArrayList<Long>();
			for (String mid:midStringArray) {
				if(null!=mid&&!"null".equals(mid)){
					Long midLong=0l;
					try{
					 	midLong=new Long(mid);
					}catch(Exception e){
						logger.info("bs-schedule:selectByDateRangeFromBsSchedule mid:{}",mid);
					}
					Long mod=midLong%taskQueueNumInteger;
					if(taskItemList.contains(mod.toString())){
						midLongSet.add(midLong);
					}
				}
			}
			if(midLongSet.size()>0){
				midLongArray.addAll(midLongSet);
			}
			resultEntity.setMidList(midLongArray);
			/*if(midLongArray.size()>0){
				logger.info("bs-schedule:selectByDateRangeFromBsSchedule result:{}", JSON.toJSONString(resultEntity));
			}else{
				logger.info("bs-schedule:selectByDateRangeFromBsSchedule result is null");
			}*/

		} catch (Exception e) {
			logger.info("bs-schedule:selectByDateRangeFromBsSchedule result:{}", JSON.toJSONString(resultEntity));

		}

		return resultEntity;
	}

	@Override
	public MidOrderInfo getMidOrderInfo(String s) {
		MidOrderInfo midOrderInfo = new MidOrderInfo();
		try {
			if(StringUtils.isNotEmpty(s)){
				midOrderInfo = orderMapper.getMidOrderInfo(s);
			}
		} catch (Exception e) {
			logger.info("OrderEffectServiceImpl.getMidOrderInfo is failed! mid is :{}", s);
		}
		return midOrderInfo;
	}

	@Override
	public List<MidOrderInfo> getInvertalOrderInfo(BigDecimal beginOrderGmv, BigDecimal endOrderGmv) {
		List<MidOrderInfo> result = new ArrayList<>();
		try {
			if(null != beginOrderGmv && null != endOrderGmv){
				result = orderMapper.getInvertalOrderInfo(beginOrderGmv, endOrderGmv);
			}
		} catch (Exception e) {
			logger.info("OrderEffectServiceImpl.getInvertalOrderInfo is failed! beginOrderGmv is :{}, endOrderGmv is :{}", beginOrderGmv, endOrderGmv);
		}
		return result;
	}
}
