package com.gome.meidian.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gome.meidian.page.BasePageVo;

public class ReqUserRelationVo implements Serializable {
	
	private static final long serialVersionUID = -2201652093057326111L;
	
	private String id;//主键id
	private Long userId;//用户id
	private Integer userType; //用户类型  0 普通用户  1 美店主
	private List<Long> userIdRelation;//用户对应上级集合
	//自定义入参
	private Long outUserId;//剔除用户id
	private Date startTime;//开始时间
	private Date endTime;//结束时间
	private BasePageVo basePageVo;//分页参数
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Integer getUserType() {
		return userType;
	}
	public void setUserType(Integer userType) {
		this.userType = userType;
	}
	public List<Long> getUserIdRelation() {
		return userIdRelation;
	}
	public void setUserIdRelation(List<Long> userIdRelation) {
		this.userIdRelation = userIdRelation;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public BasePageVo getBasePageVo() {
		return basePageVo;
	}
	public void setBasePageVo(BasePageVo basePageVo) {
		this.basePageVo = basePageVo;
	}
	public Long getOutUserId() {
		return outUserId;
	}
	public void setOutUserId(Long outUserId) {
		this.outUserId = outUserId;
	}
	
}
