package com.gome.meidian.vo;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class MeidianBangbangOrder implements Serializable {

    private static final long serialVersionUID = 6516499500882544377L;

    private Long id;//主键id
    private String orderId;//订单id
    private String returnOrderId;//退货订单号
    private String profileId;//购买人id
    private Long orderPrice;//订单实付金额
    private Long orderSalePrice;//订单销售金额
    private Date submittedDate;//订单提交时间
    private Date payDate;//订单支付时间
    private String orderType;//订单类型,0正常单；1预售单；2SMI；3货到付款；4；全额定金发货
    private Date insertTime;//创建时间
    private Date updateTime;//更新时间

}