package com.gome.meidian.vo;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MeidianCpaOrder implements Serializable {

    private static final long serialVersionUID = -4406930235538915623L;

    private Long id;
    //用户id
    private Long userId;
    //订单id
    private String orderId;
    //配送单id
    private String deliveryId;
    //订单状态
    private Integer status;
    //配送单实付总额
    private Long price;
    //配送单实付初始总额
    private Long initPrice;
    //站点
    private String site;
    //订单创建时间
    private Date orderTime;
    //创建时间
    private Date insertTime;
    //更新时间
    private Date updateTime;

}