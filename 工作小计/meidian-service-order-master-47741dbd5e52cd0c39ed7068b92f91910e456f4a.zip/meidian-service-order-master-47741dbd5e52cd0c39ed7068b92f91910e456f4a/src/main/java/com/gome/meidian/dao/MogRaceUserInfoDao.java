package com.gome.meidian.dao;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Slf4j
@Repository
@SuppressWarnings({"rawtypes"})
public class MogRaceUserInfoDao extends MongGenDao<MogRaceUserInfo> {
    @Override
    protected Class<MogRaceUserInfo> getEntityClass() {
        return MogRaceUserInfo.class;
    }

    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;

    @SneakyLog
    public ResultEntity<Boolean> saveRecord(MogRaceUserInfo mogRaceUserInfo) {
        if (mogRaceUserInfo == null) {
            return new ResultEntity<>(402, "空参数不能执行");
        }
        if (mogRaceUserInfo.getUserId() == null) {
            return new ResultEntity<>(90001, "userId, is null");
        }
        mogRaceUserInfo.setInsertTime(new Date());
        mogRaceUserInfo.setUpdateTime(new Date());
        this.save(mogRaceUserInfo);
        return new ResultEntity<>();
    }

    /**
     * 查询列表
     *
     * @param
     * @return
     */
    @SneakyLog
    public ResultEntity<List<MogRaceUserInfo>> queryList(int skipNum, int pageSize) {
        //多条件嵌入
        Query query = new Query();
        //订单时间倒序
        Criteria criteria = new Criteria();
        criteria.and("saleVolume").gte(checkSaleRaceUtils.getMoneyCondition());
        criteria.and("inviteUserCount").gte(checkSaleRaceUtils.geInviteUserCountCondition());
        query.addCriteria(criteria);
        query.with(new Sort(Sort.Direction.DESC, "integral"));
        query.with(new Sort(Sort.Direction.DESC, "saleVolume"));
        query.with(new Sort(Sort.Direction.DESC, "inviteUserCount"));
        query.with(new Sort(Sort.Direction.ASC, "insertTime"));
        query.skip((skipNum - 1) * pageSize);
        query.limit(pageSize);
        //查询订单列表
        List<MogRaceUserInfo> list = this.findList(query);
        return new ResultEntity<>(list);
    }

    /**
     * 根据userId查询
     *
     * @param userId
     * @return
     */
    @SneakyLog
    public ResultEntity<MogRaceUserInfo> queryByUserId(Long userId) {
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("userId").is(userId);
        query.addCriteria(criteria);
        MogRaceUserInfo one = this.findOne(query);
        return new ResultEntity<>(one);
    }

    /**
     * 更新记录
     *
     * @param mogRaceUserInfo
     * @return
     */
    @SneakyLog
    public ResultEntity updateUserRace(MogRaceUserInfo mogRaceUserInfo) {
        if (null == mogRaceUserInfo || null == mogRaceUserInfo.getUserId() || null == mogRaceUserInfo.getVersion()) {
            return new ResultEntity(90001, "requestParam or userId or version is null");
        }
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("userId").is(mogRaceUserInfo.getUserId());
        criteria.and("version").is(mogRaceUserInfo.getVersion());
        query.addCriteria(criteria);
        Update update = new Update();
        update.set("integral", mogRaceUserInfo.getIntegral());
        update.set("saleVolume", mogRaceUserInfo.getSaleVolume());
        update.set("inviteUserCount", mogRaceUserInfo.getInviteUserCount());
        update.set("activityId", mogRaceUserInfo.getActivityId());
        update.set("version", mogRaceUserInfo.getVersion() + 1);
        update.set("updateTime", new Date());
        this.updateMulti(query, update);
        return new ResultEntity();
    }
}
