package com.gome.meidian.service.impl;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.function.Supplier;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.boot.adapter.utils.RedisLockUtils;
import com.gome.diamond.annotations.DiamondValue;
import org.apache.commons.lang3.StringUtils;
import org.mortbay.util.ajax.JSON;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import cn.com.gome.rebate.dubbo.service.man.IDubboRebateBusinessBudgetService;
import cn.com.gome.rebate.model.persist.rebatedetail.RebateBudgetExpendReq;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.entity.GrantRebateParam;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.mapper.order.MeidianGrantRebateMapper;
import com.gome.meidian.service.IGrantRebateService;
import com.gome.meidian.util.CommUtils;
import com.gome.meidian.util.DateUtils;
import com.gome.meidian.vo.MeidianGrantRebate;
import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;

/**
 * 预估收益实现类
 *
 * @Author helinhao
 * @create 2020/2/7 17:32
 */
@Slf4j
@Service("grantRebateService")
public class GrantRebateServiceImpl implements IGrantRebateService {
    @Autowired
    MeidianGrantRebateMapper meidianGrantRebateMapper;
    @Autowired
    private RedisLockUtils redisLockUtils;
    @Autowired
    private IDubboRebateBusinessBudgetService rebateBusinessBudgetService;
    @Autowired
    private ApplicationContext context;

    private Map<Long, String> errorMap = new ConcurrentHashMap<>();

    @DiamondValue("${business.meidian.cpa.businessCode}")
    private String businessCode;
    @DiamondValue("${business.meidian.cpa.pageSize}")
    private String pageSize;
    @DiamondValue("${business.meidian.cpa.partitionSize}")
    private String partitionSize;

    /**
     * 报表累计预估收益查询
     *
     * @param puserId  接受返利的用户id
     * @param dateType 日期类型，0昨天 1今天 2近七日 3近一月
     * @return ResultEntity<Integer>
     */
    @Override
    @SneakyLog("小美帮帮-报表累计预估收益查询接口")
    public ResultEntity<Integer> predictionIncome(Long puserId, Integer dateType) {
        if (puserId == null) {
            return new ResultEntity<>(400, "用户id不能为空");
        }
        if (0 != dateType && 1 != dateType && 2 != dateType && 3 != dateType) {
            log.info("----------查询用户 {} 的预计收益，日期类型错误dateType={}", puserId, dateType);
            return new ResultEntity<>(400, "未定义的日期状态");
        }
        int income = 0;
        Date endDate = DateUtils.getCurrentEndTime();
        Date startDate = DateUtils.getCurrentStartTime();
        if (dateType.equals(1)) {
            // 昨天
            startDate = DateUtils.minusDays(startDate, 1L);
        } else if (dateType.equals(0)) {
            // 今天
            startDate = DateUtils.minusDays(startDate, 0L);
        } else if (dateType.equals(2)) {
            // 近7天
            startDate = DateUtils.minusDays(startDate, 7L);
        } else if (dateType.equals(3)) {
            // 近30天
            startDate = DateUtils.minusDays(startDate, 30L);
        }
        try {
            income = meidianGrantRebateMapper.selectPredictionIncome(DateUtils.transStrForDate(startDate), DateUtils.transStrForDate(endDate), puserId);
            log.info("----------查询用户 {} 在{}到{}的预计收益为{}", puserId, startDate, endDate, income);
            return new ResultEntity<>(Integer.valueOf(income));
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.GrantRebateServiceImpl.predictionIncome】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    /**
     * 报表累计预估收益查询
     *
     * @param puserId   接受返利的用户id
     * @param startDate 开始时间
     * @param endDate   截止时间
     * @return 预估收益
     */
    @Override
    @SneakyLog("小美帮帮-报表累计预估收益查询接口")
    public ResultEntity<Integer> predictionIncomeByDate(Long puserId, String startDate, String endDate) {
        if (puserId == null) {
            log.info("----------查询用户预计收益，用户ID为空----------");
            return new ResultEntity<>(400, "用户id不能为空");
        }
        if (StringUtils.isBlank(startDate) || StringUtils.isBlank(endDate)) {
            log.info("----------查询用户 {} 的预计收益，日期为空，startDate={},endDate={}", puserId, startDate, endDate);
            return new ResultEntity<>(400, "日期不可为空 ");
        }
        Integer income = 0;
        try {
            income = meidianGrantRebateMapper.selectPredictionIncome(startDate, endDate, puserId);
            return new ResultEntity<>(Integer.valueOf(income));
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.GrantRebateServiceImpl.predictionIncomeByDate】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    /**
     * 根据下单人的userId查询预估收益
     *
     * @param userIdList 下单人的userId
     * @return 预估收益
     */
    @Override
    @SneakyLog("小美帮帮-根据下单人的userId查询预估收益接口")
    public ResultEntity<Map<Long, Double>> predictionIncomeByUserIdList(List<Long> userIdList) {

        if (CollectionUtils.isEmpty(userIdList)) {
            return new ResultEntity<>(400, "用户id集合不能为空");
        }
        Map<Long, Double> resultMap = new HashMap<>();
        try {
            List<Map<String, Object>> mapList = meidianGrantRebateMapper.selectPredictionIncomeByUserIdList(userIdList);
            //遍历结果集转换为map
            for (Map<String, Object> map : mapList) {
                Long key = Long.valueOf(String.valueOf(map.get("userId")));
                Long v = (Long) map.get("rebatePrice");
                double value = BigDecimal.valueOf(v).divide(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP).doubleValue();
                resultMap.put(key, value);
            }
            return new ResultEntity<>(resultMap);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.GrantRebateServiceImpl.predictionIncomeByUserIdList】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    /**
     * 根据获取返利的 puserIdList查询每个puserId对应的预估收益
     *
     * @param puserIdList 下单人的userId
     * @return 预估收益
     */
    @Override
    @SneakyLog("小美帮帮-根据获取返利的puserIdList查询每个puserId对应的预估收益")
    public ResultEntity<Map<Long, Double>> predictionIncomeByPuserIdList(List<Long> puserIdList) {
        if (CollectionUtils.isEmpty(puserIdList)) {
            return new ResultEntity<>(400, "用户id集合不能为空");
        }
        Map<Long, Double> resultMap = new HashMap<>();
        try {
            List<Map<String, Object>> mapList = meidianGrantRebateMapper.predictionIncomeByPuserIdList(puserIdList);
            //遍历结果集转换为map
            for (Map<String, Object> map : mapList) {
                Long key = Long.valueOf(String.valueOf(map.get("puserId")));
                BigDecimal v = (BigDecimal) map.get("rebatePrice");
                double value = v.divide(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP).doubleValue();
                resultMap.put(key, value);
            }
            return new ResultEntity<>(resultMap);
        } catch (Exception e) {
            log.error("【com.gome.meidian.service.impl.GrantRebateServiceImpl.predictionIncomeByPuserIdList】,发生异常，异常堆栈如下：", e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    /**
     * 查询每天的预计收益
     *
     * @param startTime
     * @param endTime
     * @param puserId
     * @return
     */
    @Override
    public ResultEntity<List<Map<String, Object>>> selectPredictionIncomeWithEveryday(String startTime, String endTime, Long puserId) {
        if (StringUtils.isEmpty(startTime) || StringUtils.isEmpty(endTime) || null == puserId) {
            return new ResultEntity<>(400, "入参都不能为空");
        }

        try {
            List<Map<String, Object>> dataList = meidianGrantRebateMapper.selectPredictionIncomeWithEveryday(startTime, endTime, puserId);

            for (Map<String, Object> data : dataList) {
                BigDecimal value = (BigDecimal) data.get("val");
                double v = value.divide(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP).doubleValue();
                data.put("val", v);
            }

            log.info("IGrantRebateService.selectPredictionIncomeWithEveryday 开始时间 {}，结束时间 {}，puserId {},最终数据是 {}",
                    startTime, endTime, puserId, dataList);
            return new ResultEntity<>(dataList);
        } catch (Exception e) {
            log.error("IGrantRebateService.selectPredictionIncomeWithEveryday 开始时间 {}，结束时间 {}，puserId {}",
                    startTime, endTime, puserId, e);
            return new ResultEntity<>(500, "系统内部异常");
        }
    }

    /**
     * 订单返利回执接口，修改返利发放状态
     *
     * @param param
     * @return
     */
    @SneakyLog("小美帮帮-订单返利回执接口")
    @Override
    public Boolean grantRebateSync(GrantRebateParam param) {
        if (Objects.isNull(param)) {
            log.info("【IGrantRebateService.grantRebateSync】传入参数对象为空");
            return Boolean.FALSE;
        }
        //CPA返利防重复提交锁
        String repeatKey = CommUtils.getRedisKey(Constant.CPA_ORDER_REBATE_REPEAT_INCR_PREFIX, param.getId(), param.getUserId());
        boolean resubmitLock = Boolean.FALSE;
        try {
            resubmitLock = redisLockUtils.resubmitLock(repeatKey);
            if (!resubmitLock) {
                log.info("【IGrantRebateService.grantRebateSync】修改订单返利状态正在执行中,请勿重复提交");
                return Boolean.TRUE;
            }
            Map<String, Object> map = new HashMap<>();
            map.put("id", param.getId());
            MeidianGrantRebate m = meidianGrantRebateMapper.selectOneByBiz(map);
            if (m != null) {
                //修改员工返利表中的返利状态
                MeidianGrantRebate mgr = new MeidianGrantRebate();
                mgr.setId(param.getId());
                mgr.setRebateStatus(param.getRebateStatus());
                mgr.setBusinessCode(param.getBusinessCode());
                mgr.setRebateTime(DateUtils.getNowDate());
                int i = meidianGrantRebateMapper.update(mgr);
                if (i == 1) {
                    return Boolean.TRUE;
                } else {
                    log.info("【IGrantRebateService.grantRebateSync】更新返利表meidian_grant_rebate表中主键为{}的数据，更新失败", param.getId());
                    return Boolean.FALSE;
                }
            } else {
                log.info("【IGrantRebateService.grantRebateSync】返利表meidian_grant_rebate表中无主键为{}的数据", param.getId());
                return Boolean.FALSE;
            }
        } catch (Exception e) {
            log.error("【IGrantRebateService.grantRebateSync】保存返利发放状态发生异常,异常堆栈如下", e);
            return Boolean.FALSE;
        } finally {
            //删除锁
            redisLockUtils.unlock(resubmitLock, repeatKey);
        }
    }

    @Override
    public Boolean updateFailureStatusByUserId(Long userId) {
        if (Objects.isNull(userId)) {
            log.info("【IGrantRebateService.updateFailureStatusByUserId】传入参数对象为空");
            return Boolean.FALSE;
        }
        Map<String, Object> map = new HashMap<>();
        map.put("userId", userId);
        MeidianGrantRebate m = meidianGrantRebateMapper.selectOneByBiz(map);
        if (m != null) {
            //修改员工返利表中的返利状态
            MeidianGrantRebate mgr = new MeidianGrantRebate();
            mgr.setId(m.getId());
            mgr.setIsDelete(0);
            mgr.setFailureStatus(2);
            int i = meidianGrantRebateMapper.update(mgr);
            if (i == 1) {
                return Boolean.TRUE;
            } else {
                log.info("【IGrantRebateService.updateFailureStatusByUserId】更新返利表meidian_grant_rebate表中主键为{}的数据，更新失败", m.getId());
                return Boolean.FALSE;
            }
        } else {
            log.info("【IGrantRebateService.updateFailureStatusByUserId】返利表meidian_grant_rebate表中主键为{}的数据不存在", userId);
            return Boolean.FALSE;
        }

    }

    @Override
    public void scheduledScanGrantRebate(String rebateCode) {
        errorMap.clear();
        List<String> rebateCodeList = Lists.newArrayList();
        if (StringUtils.isNotEmpty(rebateCode)) {
            List<String> strings = Splitter.on(",").omitEmptyStrings().splitToList(rebateCode);
            rebateCodeList.addAll(strings);
        } else {
            rebateCodeList.add("0");
        }
        log.info("IGrantRebateService.scheduledScanGrantRebate 入参是 {},查询的返利状态是 {} ", rebateCode, rebateCodeList);
        int PAGE_SIZE = StringUtils.isNotEmpty(pageSize) ? Integer.parseInt(pageSize) : 0;
        int PARTITION_SIZE = StringUtils.isNotEmpty(partitionSize) ? Integer.parseInt(partitionSize) : 0;
        log.info("IGrantRebateService.scheduledScanGrantRebate 分页查询信息 pageSize {}, 每个线程处理数量 {}  ", PARTITION_SIZE, PARTITION_SIZE);

        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime effectEndTime = LocalDateTime.now().minus(Period.ofDays(7));
        Map<String, Object> param = new HashMap<>();
        param.put("isDelete", 1);
        param.put("rebateStatus", rebateCodeList);
        param.put("effectEndTime", dateTimeFormatter.format(effectEndTime));
        int totalCount = meidianGrantRebateMapper.selectRebateUserCount(param);

        Integer totalPage = getTotalPage(PAGE_SIZE, totalCount);
        CountDownLatch countDownLatch;
        List<MeidianGrantRebate> meidianGrantRebates = Collections.EMPTY_LIST;

        for (int i = 1; i <= totalPage; i++) {
            param.put("pageIndex", (i - 1) * PAGE_SIZE);
            param.put("pageSize", PAGE_SIZE);
            meidianGrantRebates = meidianGrantRebateMapper.selectRebateUserList(param);

            List<List<MeidianGrantRebate>> partition = Lists.partition(meidianGrantRebates, PARTITION_SIZE);
            countDownLatch = new CountDownLatch(partition.size());
            for (List<MeidianGrantRebate> grantRebates : partition) {
                // 开启多线程
                GrantRebateServiceImpl grantRebateServiceProxy = (GrantRebateServiceImpl) context.getBean("grantRebateService");
                grantRebateServiceProxy.executeRebate(grantRebates, businessCode, countDownLatch);
            }

            try {
                countDownLatch.await();
            } catch (InterruptedException e) {
                log.error("IGrantRebateService.scheduledScanGrantRebate countDownLatch.await() 出现异常 ", e);
            } finally {
                log.info("IGrantRebateService.scheduledScanGrantRebate 第 {} 页 发放返利结束 ", i);
            }
        }
        if (com.gome.boot.adapter.utils.CollectionUtils.isNotEmpty(errorMap)) {
            log.info("IGrantRebateService.scheduledScanGrantRebate 接口调用完成, 程序异常导致发放失败的用户信息是 {} ", errorMap);
        }
    }

    @Async
    public void executeRebate(List<MeidianGrantRebate> meidianGrantRebates, String businessCode, CountDownLatch countDownLatch) {
        try {
            for (MeidianGrantRebate rebate : meidianGrantRebates) {
                RebateBudgetExpendReq rebateBudgetExpendReq = new RebateBudgetExpendReq();
                rebateBudgetExpendReq.setUserId(rebate.getPuserId());
                rebateBudgetExpendReq.setBusinessNo(String.valueOf(rebate.getId()));
                rebateBudgetExpendReq.setAmount(rebate.getRebatePrice());
                rebateBudgetExpendReq.setBusinessCode(businessCode);

                String errorCode;
                try {
                    errorCode = Optional
                            .ofNullable(rebateBusinessBudgetService.expendBusinessBudget(rebateBudgetExpendReq))
                            .map(i -> i.getErrorCode()).orElseThrow((Supplier<Throwable>) () -> new RuntimeException(
                                    "IGrantRebateService.scheduledScanGrantRebate.expendBusinessBudget 调用返利接口 返回值为null"));
                } catch (Throwable throwable) {
                    log.error("IGrantRebateService.scheduledScanGrantRebate.expendBusinessBudget 调用返利接口 入参{} 发放返利出现异常 ", JSON.toString(rebateBudgetExpendReq), throwable);
                    errorMap.put(rebate.getUserId(), "返利接口调用失败");
                    continue;
                }
                //返利正常返回数值
                GrantRebateParam param = new GrantRebateParam();
                param.setUserId(rebate.getUserId());
                param.setId(rebate.getId());
                param.setRebateStatus(errorCode);
                param.setBusinessCode(businessCode);
                //更新返利的结果状态
                Boolean aBoolean = grantRebateSync(param);
                if (!aBoolean) {
                    errorMap.put(rebate.getUserId(), "更新返利状态失败");
                }

            }
        } catch (Exception e) {
            log.error("IGrantRebateService.scheduledScanGrantRebate  线程 {} 执行 executeRebate 方法，出现异常", Thread.currentThread().getName(), e);
        } finally {
            countDownLatch.countDown();
        }
    }


    public Integer getTotalPage(int pageSize, int totalCount) {
        //总页数
        int totalPage = totalCount / pageSize;
        if (totalCount == 0 || totalCount % pageSize != 0) {
            totalPage++;
        }
        return totalPage;
    }

}
