package com.gome.meidian.service.impl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import com.gome.meidian.mapper.order.OrderRefundMapper;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.gome.meidian.entity.OrderEffect;
import com.gome.meidian.entity.OrderOccur;
import com.gome.meidian.entity.OrderRefund;
import com.gome.meidian.service.IOrderBodyErrorService;
import com.gome.meidian.service.IOrderChannelService;
import com.gome.meidian.service.IOrderEffectService;
import com.gome.meidian.service.IOrderOccurService;
import com.gome.meidian.service.IOrderRefundService;
import com.gome.meidian.service.util.OrderErrorLogUtil;

/**
 * <p>
 * 退货单表 服务实现类
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
@Service
public class OrderRefundServiceImpl extends ServiceImpl<OrderRefundMapper, OrderRefund> implements IOrderRefundService {
	@Autowired
	IOrderChannelService orderChannelSvc;

	@Autowired
	IOrderOccurService orderOccurSvc;

	@Autowired
	IOrderBodyErrorService orderBodyErrorSvc;
	
	@Autowired
	IOrderEffectService orderEffectSvc;
	
	@Autowired
	OrderErrorLogUtil errorLogUtil;
	
	@Autowired
	OrderRefundMapper orderMapper;
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Override
	@Transactional(rollbackFor=Throwable.class)
	public Integer insertRefundOrder(OrderRefund orderRefund) {
		//如果退货表已有该记录 则不进行任何操作
		Integer returnCode = 0;
		HashMap<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("order_id", orderRefund.getOrderId());
		queryMap.put("commerce_id", orderRefund.getCommerceId());
		queryMap.put("delivery_id", orderRefund.getDeliveryId());
		queryMap.put("refund_id", orderRefund.getRefundId());
		if(!CollectionUtils.isEmpty(this.selectByMap(queryMap))){
			return returnCode;
		}
		try {
			// 插入退货表
			boolean insertOrUpdate = this.insert(orderRefund);
			if(!insertOrUpdate) {
				logger.info("-------------插入退货表失败orderRefund"+orderRefund.toString());
				errorLogUtil.insertLog(orderRefund, "插入退货表失败");
			}
			queryMap.remove("refund_id");
			// 发生表插入
			List<OrderOccur> orderOccurs = orderOccurSvc.selectByMap(queryMap);
			if (CollectionUtils.isEmpty(orderOccurs)) {
				OrderOccur orderOccur = new OrderOccur();				
				BeanUtils.copyProperties(orderRefund, orderOccur);
				orderOccur.setOrderType(0);
				boolean orderOccurInsert = orderOccurSvc.insert(orderOccur);
				if(!orderOccurInsert) {
					logger.info("-------------退货之后插入发生表失败(发生时未插入到发生表)orderRefund"+orderOccur.toString());
					errorLogUtil.insertLog(orderOccur, "插入发生表失败");
				}
			}
			
			// 妥投表插入
			List<OrderEffect> orderEffects = orderEffectSvc.selectByMap(queryMap);
			if (CollectionUtils.isEmpty(orderEffects)) {
				OrderEffect orderEffect = new OrderEffect();				
				BeanUtils.copyProperties(orderRefund, orderEffect);
				orderEffect.setOrderType(0);
				boolean orderEffectInsert = orderEffectSvc.insert(orderEffect);
				if(!orderEffectInsert) {
					logger.info("-------------退货之后插入妥投表失败(妥投时未插入到妥投表)orderEffect"+orderEffect.toString());
					errorLogUtil.insertLog(orderEffect, "插入妥投表失败");
				}
			}else{
				OrderEffect orderEffect = orderEffects.get(0);
				if(orderEffect.getOrderType().intValue() != 0){
					int effectBuyNum = orderEffect.getBuyNum().intValue();
					BigDecimal effectPriceTotal = orderEffect.getPriceTotal();
					
					Integer buyNum = orderRefund.getBuyNum();				
					BigDecimal priceTotal = orderRefund.getPriceTotal();
					
					int diffBuyNum = effectBuyNum - buyNum;
					if(diffBuyNum < 0){
						diffBuyNum = 0;
					}
					
					BigDecimal subtract = effectPriceTotal.subtract(priceTotal);				
					if(subtract.longValue() < 0){
						subtract = new BigDecimal("0");
					}
					orderEffect.setBuyNum(diffBuyNum);
					orderEffect.setPriceTotal(subtract);
					boolean updateAllColumnById = orderEffectSvc.updateAllColumnById(orderEffect);
					if(!updateAllColumnById) {
						logger.info("-------------退货之后更新妥投表失败orderEffect"+orderEffect.toString());
						errorLogUtil.insertLog(orderEffect, "更新妥投表失败");
					}
				}			
			}
			
			
/*			// 渠道表查询
			List<OrderChannel> orderChannels = orderChannelSvc.selectByMap(queryMap);
			if (CollectionUtils.isEmpty(orderChannels)) {
				OrderChannel orderChannel = new OrderChannel();
				BeanUtils.copyProperties(orderRefund, orderChannel);
				orderChannelSvc.insert(orderChannel);
			}*/
			returnCode = 1;
		} catch (Exception e) {
			errorLogUtil.insertLog(orderRefund, e.getMessage());
			throw e;
		}
		return returnCode;
	}
	
	@Override
	public List<OrderRefund> selectByDateRange(HashMap<String, Object> queryParams) {
		String object = queryParams.get("mid").toString();
		String[] splitStr = StringUtils.strip(object, "[]").split(",");
		String temp = convertList(splitStr);
		queryParams.put("mid", temp);
		List<OrderRefund> orderOccurs = orderMapper.selectByDateRange(queryParams);		
		return orderOccurs;
	}
	private String convertList(String[] params) {
		String temp = "";
		int size = params.length;
		for (int i = 0 ; i < size ; i++) {
			if(i != size - 1) {
				temp += "'"+params[i].trim()+"',";
			}else {
				temp += "'"+params[i].trim()+"'";
			}
		}
		return temp;
	}
}
