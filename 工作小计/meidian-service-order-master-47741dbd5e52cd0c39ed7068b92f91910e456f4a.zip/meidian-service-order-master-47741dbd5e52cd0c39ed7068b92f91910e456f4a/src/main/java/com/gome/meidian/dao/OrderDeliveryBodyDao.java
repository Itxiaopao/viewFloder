package com.gome.meidian.dao;

import com.gome.boot.adapter.config.aspect.annotation.SneakyLog;
import com.gome.meidian.base.MongGenDao;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.page.BasePageVo;
import com.gome.meidian.vo.MogDeliveryOrderBody;
import com.gome.meidian.vo.ReqOrderDeliveryBody;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@SuppressWarnings({"unchecked", "rawtypes", "deprecation"})
@Repository
public class OrderDeliveryBodyDao extends MongGenDao<MogDeliveryOrderBody> {

    @Override
    protected Class getEntityClass() {
        return MogDeliveryOrderBody.class;
    }

    /**
     * 保存 mogDeliveryOrderBody
     *
     * @param mogDeliveryOrderBody
     */
    @SneakyLog
    public ResultEntity saveOrderDeliveryBody(MogDeliveryOrderBody mogDeliveryOrderBody) {
        //参数过滤
        if (StringUtils.isBlank(mogDeliveryOrderBody.getMsgId()) || mogDeliveryOrderBody.getOrderId() == null || StringUtils.isBlank(mogDeliveryOrderBody.getDeliveryId())) {
            return new ResultEntity(90001, "msgId,orderId,deliveryId is null");
        }
        //保存订单-初始化默认值
        this.save(mogDeliveryOrderBody);
        return new ResultEntity();
    }

    /**
     * 删除 mogDeliveryOrderBody 通过id
     *
     * @param id
     * @return
     */
    @SneakyLog
    public ResultEntity delOrderDeliveryBodyById(String id) {
        if (StringUtils.isBlank(id)) {
            return new ResultEntity(90002, "id is null");
        }
        this.deleteById(id);
        return new ResultEntity();
    }

    /**
     * 多条件获取 mogDeliveryOrderBody 列表
     *
     * @param reqOrderDeliveryBody
     * @return
     */
    @SneakyLog
    public ResultEntity<List<MogDeliveryOrderBody>> queryOrderDeliveryBodyList(ReqOrderDeliveryBody reqOrderDeliveryBody) {
        //多条件嵌入
        Query query = new Query();
        //封装条件查询数据
        query.addCriteria(this.orderDeliveryBodyParamFile(reqOrderDeliveryBody));
        //订单时间倒序
        query.with(new Sort(Sort.Direction.DESC, "orderTime"));
        //查询订单列表
        List<MogDeliveryOrderBody> list = this.findList(query);
        return new ResultEntity(list);
    }

    //添加条件封装
    private Criteria orderDeliveryBodyParamFile(ReqOrderDeliveryBody reqOrderDeliveryBody) {
        Criteria criteria = new Criteria();
        //主键id
        String id = reqOrderDeliveryBody.getId();
        if (StringUtils.isNotBlank(id)) {
            criteria.and("_id").is(id);
        }
        //消息id
        String msgId = reqOrderDeliveryBody.getMsgId();
        if (StringUtils.isNotBlank(msgId)) {
            criteria.and("msgId").is(msgId);
        }
        //订单号
        Long orderId = reqOrderDeliveryBody.getOrderId();
        if (orderId != null) {
            criteria.and("orderId").is(orderId);
        }
        //配送号
        String deliveryId = reqOrderDeliveryBody.getDeliveryId();
        if (StringUtils.isNotBlank(deliveryId)) {
            criteria.and("deliveryId").is(deliveryId);
        }
        //用户id
        Long userId = reqOrderDeliveryBody.getUserId();
        if (userId != null) {
            criteria.and("userId").is(userId);
        }
        //订单状态
        List<Integer> orderStatusList = reqOrderDeliveryBody.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = reqOrderDeliveryBody.getOrderStartTime();
        Date orderEndTime = reqOrderDeliveryBody.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gte(orderStartTime).lt(orderEndTime);
        }
        return criteria;
    }

    /**
     * 分页获取订单数据
     *
     * @param reqOrderDeliveryBody
     * @return
     */
    @SneakyLog
    public ResultEntity<List<MogDeliveryOrderBody>> queryHistoryDeliveryOrderBody(ReqOrderDeliveryBody reqOrderDeliveryBody) {
        //分页参数过滤
        BasePageVo page = reqOrderDeliveryBody.getBasePageVo();
        if (page == null || page.getPageNo() == null || page.getPageSize() == null) {
            return new ResultEntity(90002, "pageNo,pageSize is null");
        }
        //封装条件查询数据
        Criteria criteria = new Criteria();
        //订单状态
        List<Integer> orderStatusList = reqOrderDeliveryBody.getOrderStatusList();
        if (CollectionUtils.isNotEmpty(orderStatusList)) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = reqOrderDeliveryBody.getOrderStartTime();
        Date orderEndTime = reqOrderDeliveryBody.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gt(orderStartTime).lte(orderEndTime);
        }
        //查询数据
        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(criteria),
                Aggregation.group("orderId", "deliveryId").max("orderTime").as("orderTime").first("msgBody").as("msgBody"),
                Aggregation.sort(new Sort(Sort.Direction.DESC, "orderTime")),
                Aggregation.skip(page.getStartRow()),
                Aggregation.limit(page.getPageSize()));
        AggregationResults<MogDeliveryOrderBody> aggResult = this.mongoTemplate.aggregate(aggregation, "mogDeliveryOrderBody", MogDeliveryOrderBody.class);
        return new ResultEntity(aggResult.getMappedResults());
    }

    /**
     * 统计历史订单数据量
     *
     * @param reqOrderDeliveryBody
     * @return
     */
    @SneakyLog
    public ResultEntity<Integer> countQueryHistoryDeliveryOrderBody(ReqOrderDeliveryBody reqOrderDeliveryBody) {
        //封装条件查询数据
        Criteria criteria = new Criteria();
        //订单状态
        List<Integer> orderStatusList = reqOrderDeliveryBody.getOrderStatusList();
        if (orderStatusList != null && orderStatusList.size() > 0) {
            criteria.and("orderStatus").in(orderStatusList);
        }
        //订单时间范围
        Date orderStartTime = reqOrderDeliveryBody.getOrderStartTime();
        Date orderEndTime = reqOrderDeliveryBody.getOrderEndTime();
        if (orderStartTime != null && orderEndTime != null) {
            criteria.and("orderTime").gt(orderStartTime).lte(orderEndTime);
        }
        //查询数据
        Aggregation aggregationCount = Aggregation.newAggregation(
                Aggregation.match(criteria),
                Aggregation.group("orderId"));
        AggregationResults<MogDeliveryOrderBody> aggResultCount = this.mongoTemplate.aggregate(aggregationCount, "mogDeliveryOrderBody", MogDeliveryOrderBody.class);
        //响应信息
        return new ResultEntity(aggResultCount.getMappedResults().size());
    }

}
