package com.gome.meidian.service.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * Excel工具类
 * @author zhangwei-ds19
 *
 */
public class ReadExcel {
		
		 //main方法测试
	    public static void main(String[] args) throws Exception {
	        //importdata();
	        outputdate();
	    }
		
      //outputdata：读取excel表中的数据,读取的模板为刚才生成的excel表格
        public static void outputdate() throws Exception{
            
            //用FileInputStream读入需要读取的文件
            String filepath = "E:\\美店测试数据.xlsx";
            File empinf = new File(filepath);
            FileInputStream fis = new FileInputStream(empinf);
            //判断读取的文件的格式
            boolean is03Excel = filepath.matches("^.+\\.(?i)(xls)$");
            //读取工作簿
            Workbook workbook = is03Excel?new HSSFWorkbook(fis):new XSSFWorkbook(fis);
            //读取工作表
            Sheet sheet = workbook.getSheetAt(0);
            //读取表格中的内容
            for(int i = 1;i < sheet.getPhysicalNumberOfRows();i++){
                //获取对应的行
                Row row = sheet.getRow(i);
                //取对应行中每一列的数据
                for(int j = 1;j < row.getPhysicalNumberOfCells();i++){
                    //取该行中的列
                    Cell cell = row.getCell(j);
                    //把对应的值取出来
                    String cellvalue = cell.getStringCellValue();
                    System.out.print(cellvalue);
                }
//                System.out.println();
            }
            
           //在控制台输出结果
          //  fis.close();
        }    
        
}
