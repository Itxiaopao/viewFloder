package com.gome.meidian.util;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.enums.UserIdentityType;
import org.apache.commons.lang3.ObjectUtils;

import java.util.List;
import java.util.Map;

public class CommUtils {

    /**
     * 获取缓存key
     *
     * @param params
     * @return
     */
    public static <T> String getRedisKey(T... params) {
        return spliceKey("_", params);
    }

    /**
     * 拼接key
     *
     * @param params 入参
     * @return
     */
    public static <T> String spliceKey(String splice, T... params) {
        if (params == null || params.length == 0) {
            return null;
        }
        StringBuilder sb = new StringBuilder(params.length * 32);
        for (Object param : params) {
            sb.append(param).append(splice);
        }
        return sb.toString().substring(0, sb.length() - 1);
    }


    /**
     * 获取最大页数
     *
     * @param total
     * @param pageSize
     * @return
     */
    public static int getTotalPageNum(int total, Integer pageSize) {
        int eachPageSize = ObjectUtils.defaultIfNull(pageSize, Constant.EACH_THREAD_PAGE_NUM);
        return (total + eachPageSize - 1) / eachPageSize;
    }

    /**
     * 日志格式拼接
     *
     * @param answer     是否输出响应
     * @param logContent 文件头
     * @param className  文件名
     * @param methodName 方法名
     * @param args       参数
     * @param useTime    耗时
     * @param object     响应
     * @return
     */
    public static String logFormat(boolean answer, String logContent, String className, String methodName, Object[] args, long useTime, Object object) {
        return answer ?
                String.format("%s 【URI:%s#%s】【参数:%s】【耗时:%s ms】 【响应:%s】", logContent, className, methodName, JSON.toJSON(args), useTime, JSON.toJSON(object))
                : String.format("%s 【URI:%s#%s】【参数:%s】【耗时:%s ms】", logContent, className, methodName, JSON.toJSON(args), useTime);
    }

    /**
     * 获取用户身份
     *
     * @param userId         下单用户id
     * @param userIdRelation 关系链条
     * @return
     */
    public static Integer getUserIdentity(Long userId, List<Long> userIdRelation) {
        if (userId.equals(userIdRelation.get(0))) {
            //片总
            return UserIdentityType.topLeaderUser.getStatus();
        } else if (userId.equals(userIdRelation.get(userIdRelation.size() - 1))) {
            //店主
            return UserIdentityType.shopkeeper.getStatus();
        } else {
            //用户
            return UserIdentityType.custom.getStatus();
        }
    }

    /**
     * 判断map是否为空
     *
     * @param m
     * @return
     */
    public static boolean isEmpty(Map m) {
        return m == null || m.isEmpty();
    }
}
