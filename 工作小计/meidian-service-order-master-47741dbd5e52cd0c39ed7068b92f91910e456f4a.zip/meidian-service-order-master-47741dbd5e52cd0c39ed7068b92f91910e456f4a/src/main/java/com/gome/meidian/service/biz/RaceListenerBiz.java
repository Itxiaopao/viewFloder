package com.gome.meidian.service.biz;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.boot.adapter.utils.NumberUtils;
import com.gome.meidian.constant.Constant;
import com.gome.meidian.util.CheckSaleRaceUtils;
import com.gome.meidian.vo.MogRaceUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.Gcache;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.Executor;

/**
 * 监听redis消息队列
 *
 * @author chenchen-ds6
 */
@Slf4j
@Component
public class RaceListenerBiz {
    @Autowired
    private Gcache gcache;
    @Autowired
    private RaceBiz raceBiz;
    @Autowired
    private CheckSaleRaceUtils checkSaleRaceUtils;
    @Resource(name = "threadPoolExecutor")
    private Executor executor;

    @PostConstruct
    public void init() {
        executor.execute(new Thread(this::listener));
        log.info("店主竞赛监听初始化成功...");
    }

    /**
     * 监听处理逻辑
     */
    public void listener() {
        while (true) {
            try {
                if (!checkSaleRaceUtils.checkActivityIsEffective()) {
                    log.info("店主竞赛销售活动开关关闭,不在从队列里面取值");
                    return;
                }
                List<String> blpop = gcache.blpop(2000, Constant.SALE_RACE_DISTRIBUTED_LISTENER);
                if (CollectionUtils.isEmpty(blpop)) {
                    continue;
                }
                for (int i = 0, j = blpop.size(); i < j; i++) {
                    if (i == 0) {
                        continue;
                    }
                    MogRaceUserInfo mogRaceUserInfo = JSONObject.parseObject(blpop.get(i), MogRaceUserInfo.class);
                    log.info("监听到需要处理店主竞赛内容:{}", JSON.toJSON(mogRaceUserInfo));
                    Long setnx = gcache.setnxex(Constant.SALE_RACE_DISTRIBUTED_LOCK + mogRaceUserInfo.getUserId(), 1, String.valueOf(System.currentTimeMillis()));
                    if (setnx.equals(0L)) {
                        //延时两秒再入队
                        Thread.sleep(2000L);
                        gcache.rpush(Constant.SALE_RACE_DISTRIBUTED_LISTENER, blpop.get(i));
                        continue;
                    }
                    if (NumberUtils.isNullOrZero(mogRaceUserInfo.getInviteUserCount())) {
                        //处理销售gmv
                        raceBiz.dealSaleOrder(mogRaceUserInfo);
                    } else {
                        //处理拉新人数
                        raceBiz.dealInviteUser(mogRaceUserInfo);
                    }
                }
            } catch (Exception e) {
                log.error("店主竞赛监听发生异常,异常堆栈如下:", e);
            }
        }
    }
}
