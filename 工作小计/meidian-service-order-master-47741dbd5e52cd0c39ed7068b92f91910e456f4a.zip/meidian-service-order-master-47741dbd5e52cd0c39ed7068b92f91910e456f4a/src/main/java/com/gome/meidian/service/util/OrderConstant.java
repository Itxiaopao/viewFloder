package com.gome.meidian.service.util;

public interface OrderConstant {
	int ORDER_OCCUR = 1;
	int ORDER_EFFECT = 2;
	int ORDER_REFUND = 3;
}
