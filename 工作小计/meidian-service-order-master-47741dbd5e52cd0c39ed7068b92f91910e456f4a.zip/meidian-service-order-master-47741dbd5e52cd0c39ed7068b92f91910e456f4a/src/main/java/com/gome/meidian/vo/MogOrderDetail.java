package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
public class MogOrderDetail implements Serializable {

    private static final long serialVersionUID = 314756552854718602L;
    private String id;//主键id
    private Long orderId;//订单id
    private Long commerceId;//子订单id
    private String deliveryId;//配送id
    private String kid;//团id
    private Long userId;//下单人id
    private Integer userType; //用户类型 0:普通用户,1:美店主,3:片总
    private Long parentUserId;//下单人直属上级id
    private Long topLeaderUser;//下单人片总id
    private List<Long> userIdRelation;//下单人对应上级集合
    private String skuId;//skuId
    private String skuNo;//skuNo
    private String skuName;//skuName
    private String itemId;//商品id
    private Integer buyNum;//购买数量
    private Long priceTotal;//订单实付总价(单价*数量-优惠券价格) 单位:分
    private Long unitPrice;//单价 单位:分
    private String merchantId;//商家id
    private String siteId;//下单渠道
    private Integer orderStatus;//美店OMS订单状态
    private Integer showStatus; //美店显示订单状态
    private Date orderCreateTime;//订单创建时间
    private Date orderTime;//订单时间
    private Long afterSalesOrderId;//售后单ID
    private String categoryFirstId;//一级品类
    private String categoryFirstName;//一级品类名称
    private String categorySecondId;//二级品类
    private String categorySecondName;//二级品类名称
    private String categoryThirdId;//三级品类
    private String categoryThirdName;//三级品类名称
    private String categoryFourthId;//四级品类
    private String categoryFourthName;//四级品类名称
    private String marketingOrganizationId;//销售组织Id
    private String companyCode;//公司代码
    private String orderItemId;//订单商品行id
    private String sellerId;//卖家id
    private Integer sourceType;//来源1:平台,2:商家,3:线下
    private String spuId;
    private String isWarranty;//是否延保
    private String shopCode;//销售门店编码
    private String addressFirst;//一级地址
    private String addressSecond;//二级地址
    private String addressThird;//三级地址
    private String addressFourth;//四级地址
    private Integer businessType;//1:在线自营,2:海外购自营,3:海外购联营,4:其它联营
    private String brandCode;//品牌编码
    private String channelType;//渠道来源
    private String merchantName;//商户名称
    private String regionId;//大区id
    private String regionName;//大区名称
    private String brandId;//一级分部
    private String brandName;//一级分部名称
    private String brandSecondId;//二级分部
    private String brandSecondName;//二级分部名称
    private String storeId;//业绩还原门店编码
    private String storeName;//业绩还原门店名称
    private Integer isElectric;//是否电器 1:电器,0:非电器
    private String purchaseType;//采购方式
    private String saleType;//销售方式 员工美店,非员工美店
    private String saleChannel;//销售途径(直接购买/绑定关系购买/二级邀请网络购买）
    private Integer cmsEffective;//cms是否上下架(1:上架,0:下架)
    private String businessCenter;//业务中心类
    private String businessCategroy;//业务品类
    private Integer bSaleA;//1:是B卖A  0：非B卖A
    private Integer upUserRole; //1.电器员工店主,2.非电器员工店主,3.发展社会店主,4.外部美店主
    private Date createTime;//创建时间
    private Date updateTime;//更新时间

}
