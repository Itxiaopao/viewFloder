package com.gome.meidian.mapper.bigData.provider;

import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: IcSmDqlStaffProvider
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/1/11 15:27
 */
public class IcSmDqlStaffProvider{

    public String selectPart(Map<String, Integer> map){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select ids.mx_uid  \n"+ 
        		",ids.zx_uid\n" + 
        		",ids.mid\n" + 
        		",ids.staff_name\n" + 
        		",ids.staff_code\n" + 
        		",ids.staff_post\n" + 
        		",ids.is_appoint\n" + 
        		",ids.staff_post_name\n" + 
        		",ids.f_division_code\n" + 
        		",ids.f_division_name\n" + 
        		",ids.s_division_code\n" + 
        		",ids.s_division_name\n" + 
        		",ids.store_code\n" + 
        		",ids.store_name\n" + 
        		",ids.staff_level\n" + 
        		",ids.staff_category\n" + 
        		",ids.staff_category_brand\n" + 
        		",ids.introduction\n" + 
        		",ids.isstore\n" + 
        		",ids.organization_code\n" + 
        		",ids.brand_code\n" + 
        		",ids.status\n" + 
        		",ids.header_status from ic_sm_dql_staff as ids ");
        stringBuilder.append("limit " + map.get("pageNum") + "," + map.get("pageSize"));
        return stringBuilder.toString();
    }
	public String selectPartWithMid(Map<String, Integer> map){
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("select ids.mx_uid  \n"+
				",ids.zx_uid\n" +
				",ids.mid\n" +
				",ids.staff_name\n" +
				",ids.staff_code\n" +
				",ids.staff_post\n" +
				",ids.is_appoint\n" +
				",ids.staff_post_name\n" +
				",ids.f_division_code\n" +
				",ids.f_division_name\n" +
				",ids.s_division_code\n" +
				",ids.s_division_name\n" +
				",ids.store_code\n" +
				",ids.store_name\n" +
				",ids.staff_level\n" +
				",ids.staff_category\n" +
				",ids.staff_category_brand\n" +
				",ids.introduction\n" +
				",ids.isstore\n" +
				",ids.organization_code\n" +
				",ids.brand_code\n" +
				",ids.status\n" +
				",ids.header_status from ic_sm_dql_staff as ids ");
		stringBuilder.append("where ids.mid!=0 ORDER BY ids.utime DESC  limit " + map.get("pageNum") + "," + map.get("pageSize"));
		return stringBuilder.toString();
	}

    public String selectPartByCtime(Map<String, Integer> map){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select ids.mx_uid  \n"+
        		",ids.zx_uid\n" +
        		",ids.mid\n" +
        		",ids.staff_name\n" +
        		",ids.staff_code\n" +
        		",ids.staff_post\n" +
        		",ids.is_appoint\n" +
        		",ids.staff_post_name\n" +
        		",ids.f_division_code\n" +
        		",ids.f_division_name\n" +
        		",ids.s_division_code\n" +
        		",ids.s_division_name\n" +
        		",ids.store_code\n" +
        		",ids.store_name\n" +
        		",ids.staff_level\n" +
        		",ids.staff_category\n" +
        		",ids.staff_category_brand\n" +
        		",ids.introduction\n" +
        		",ids.isstore\n" +
        		",ids.organization_code\n" +
        		",ids.brand_code\n" +
        		",ids.status\n" +
        		",ids.header_status from ic_sm_dql_staff as ids ");
        stringBuilder.append("where utime BETWEEN DATE_SUB(NOW(), interval "+map.get("minutes")+" MINUTE) and NOW()");
        return stringBuilder.toString();
    }

    public String selectByStaffId(Map<String, Integer> map){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select ids.mx_uid  \n"+
        		",ids.zx_uid\n" +
        		",ids.mid\n" +
        		",ids.staff_name\n" +
        		",ids.staff_code\n" +
        		",ids.staff_post\n" +
        		",ids.is_appoint\n" +
        		",ids.staff_post_name\n" +
        		",ids.f_division_code\n" +
        		",ids.f_division_name\n" +
        		",ids.s_division_code\n" +
        		",ids.s_division_name\n" +
        		",ids.store_code\n" +
        		",ids.store_name\n" +
        		",ids.staff_level\n" +
        		",ids.staff_category\n" +
        		",ids.staff_category_brand\n" +
        		",ids.introduction\n" +
        		",ids.isstore\n" +
        		",ids.organization_code\n" +
        		",ids.brand_code\n" +
        		",ids.status\n" +
        		",ids.header_status from ic_sm_dql_staff as ids ");
        stringBuilder.append("where zx_uid = " + map.get("staffId"));
        return stringBuilder.toString();
    }

    public String selectStaffInfoBymid(Map<String, Integer> map){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select ids.mx_uid  \n"+
        		",ids.zx_uid\n" +
        		",ids.mid\n" +
        		",ids.staff_name\n" +
        		",ids.staff_code\n" +
        		",ids.staff_post\n" +
        		",ids.is_appoint\n" +
        		",ids.staff_post_name\n" +
        		",ids.f_division_code\n" +
        		",ids.f_division_name\n" +
        		",ids.s_division_code\n" +
        		",ids.s_division_name\n" +
        		",ids.store_code\n" +
        		",ids.store_name\n" +
        		",ids.staff_level\n" +
        		",ids.staff_category\n" +
        		",ids.staff_category_brand\n" +
        		",ids.introduction\n" +
        		",ids.isstore\n" +
        		",ids.organization_code\n" +
        		",ids.brand_code\n" +
        		",ids.status\n" +
        		",ids.header_status from ic_sm_dql_staff as ids ");
        stringBuilder.append("where mid = " + map.get("mid"));
        return stringBuilder.toString();
    }


    public String getTotalCount(){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select count(*) from ic_sm_dql_staff as ids ");
        return stringBuilder.toString();
    }

	public String getTotalCountWithMid(){
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("select count(*) from ic_sm_dql_staff where mid!=0 ");
		return stringBuilder.toString();
	}
}
