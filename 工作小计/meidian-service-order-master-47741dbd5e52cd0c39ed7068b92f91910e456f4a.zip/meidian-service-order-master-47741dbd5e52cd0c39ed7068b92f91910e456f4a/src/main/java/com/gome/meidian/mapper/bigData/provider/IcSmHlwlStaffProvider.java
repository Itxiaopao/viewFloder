package com.gome.meidian.mapper.bigData.provider;

import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: IcSmHlwlStaffProvider
 * @ProjectName meidian-service-order
 * @Description: TODO
 * @date 2019/2/14 14:10
 */
public class IcSmHlwlStaffProvider {

    public String selectByStaffId(Map<String, Integer> map) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("select ids.mx_uid  \n" +
                ",ids.zx_uid\n" +
                ",ids.mid\n" +
                ",ids.staff_name\n" +
                ",ids.staff_code\n" +
                ",ids.staff_phone\n" +
                ",ids.staff_post_code\n" +
                ",ids.staff_post_name\n" +
                ",ids.staff_dept_code\n" +
                ",ids.staff_dept_name\n" +
                ",ids.staff_company_code\n" +
                ",ids.staff_company_name\n" +
                ",ids.status\n" +
                ",ids.ctime\n" +
                ",ids.utime\n" +
                " from ic_sm_hlwl_staff as ids ");
        stringBuilder.append("where zx_uid = " + map.get("staffId"));
        return stringBuilder.toString();
    }
}
