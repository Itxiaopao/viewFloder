package com.gome.meidian.enums;

public enum GomeStateEnum {

    pay("CO", "配送单已生效"),
    deliver("DL", "配送单已妥投"),
    cancel("CL", "订单已取消"),
    rejection("RT", "配送单拒收入库"),
    back("RCO", "退货审核完成");

    private GomeStateEnum(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    private String code;

    private String desc;

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
