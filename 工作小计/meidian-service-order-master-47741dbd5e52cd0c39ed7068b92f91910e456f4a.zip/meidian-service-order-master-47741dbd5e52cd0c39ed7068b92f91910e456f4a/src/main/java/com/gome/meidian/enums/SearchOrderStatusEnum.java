package com.gome.meidian.enums;


import java.util.Arrays;
import java.util.List;

/**
 * 搜索订单状态聚合
 */
public enum SearchOrderStatusEnum {

    //订单状态 null:全部,0:待支付 1:已支付 2:待收货 4:已取消 5:订单妥投 6:售后，900:正向单，901逆向单
    waitPay(0, "待支付"),
    payed(1, "已支付"),
    waitReceivDeliver(2, "待收货"),
    cancel(4, "已取消"),
    effect(5, "订单妥投"),
    afterSale(6, "售后"),
    normal(900, "正向单"),
    reverse(901, "逆向单");

    /**
     * 根据正反向编码，分离订单状态
     *
     * @param code 状态码
     * @return
     */
    public static List<Integer> bizIsolate(Integer code) {
        if (SearchOrderStatusEnum.normal.getCode().equals(code)) {
            return Arrays.asList(SearchOrderStatusEnum.payed.getCode(), SearchOrderStatusEnum.waitReceivDeliver.getCode(), SearchOrderStatusEnum.effect.getCode());
        } else if (SearchOrderStatusEnum.reverse.getCode().equals(code)) {
            return Arrays.asList(SearchOrderStatusEnum.cancel.getCode(), SearchOrderStatusEnum.afterSale.getCode());
        }
        return null;
    }

    public static Integer valueOf(Integer code) {
        for (SearchOrderStatusEnum enu : SearchOrderStatusEnum.values()) {
            if (enu.getCode().equals(code)) {
                return enu.getCode();
            }
        }
        return -1;
    }

    public static boolean contains(Integer code) {
        for (SearchOrderStatusEnum enu : SearchOrderStatusEnum.values()) {
            if (enu.getCode().equals(code)) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    public static boolean notContains(Integer code) {
        return !contains(code);
    }


    private Integer code;

    private String name;

    private SearchOrderStatusEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

}
