package com.gome.meidian.vo;

import java.util.List;

public class OrderDeliveryVo {

	private Long totalGMV;
	
	private Long userId;
	
	private boolean isAdd;
	
	private Long orderId;
	
	private String deliveryId;

	public Long getTotalGMV() {
		return totalGMV;
	}

	public void setTotalGMV(Long totalGMV) {
		this.totalGMV = totalGMV;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}


	public boolean getIsAdd() {
		return isAdd;
	}

	public void setAdd(boolean isAdd) {
		this.isAdd = isAdd;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	
	
}
