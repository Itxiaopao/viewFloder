package com.gome.meidian.vo;

import com.gome.meidian.page.BasePageVo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class ReqOrderVshopVo implements Serializable {
	
	private static final long serialVersionUID = -4453828151288858957L;

	//自定义入参
	private List<Integer> orderStatusList;//美店订单状态  0:待支付 1:待发货 2:已取消 3:待收货 5:已收货 6:售后
	private List<Integer> showStatusList; //显示的订单状态
	private Date startTime;//订单开始时间
	private Date endTime;//订单结束时间
	private BasePageVo basePageVo;//分页参数

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	public List<Integer> getOrderStatusList() {
		return orderStatusList;
	}

	public void setOrderStatusList(List<Integer> orderStatusList) {
		this.orderStatusList = orderStatusList;
	}

	public List<Integer> getShowStatusList() {
		return showStatusList;
	}

	public void setShowStatusList(List<Integer> showStatusList) {
		this.showStatusList = showStatusList;
	}

	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public BasePageVo getBasePageVo() {
		return basePageVo;
	}
	public void setBasePageVo(BasePageVo basePageVo) {
		this.basePageVo = basePageVo;
	}
	
}
