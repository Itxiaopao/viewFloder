package com.gome.meidian.service.biz;

import com.gome.diamond.annotations.DiamondValue;
import com.gome.meidian.vo.DefaultHammer;
import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Set;

@Slf4j
@Component
public class DiamondBiz {

    @DiamondValue("${business.meidian.all.hammerStr}")
    private String allHammerStr;
    @DiamondValue("${business.meidian.default.hammer.mid}")
    private String defaultHammerMid;
    @DiamondValue("${business.meidian.default.hammer.userId}")
    private String defaultHammerUserId;
    @DiamondValue("${business.meidian.default.hammer.regionId}")
    private String defaultHammerRegionId;
    @DiamondValue("${business.meidian.default.hammer.regionName}")
    private String defaultHammerRegionName;
    @DiamondValue("${business.meidian.default.hammer.branchId}")
    private String defaultHammerBranchId;
    @DiamondValue("${business.meidian.default.hammer.branchName}")
    private String defaultHammerBranchName;
    @DiamondValue("${business.meidian.default.hammer.branchSecondId}")
    private String defaultHammerBranchSecondId;
    @DiamondValue("${business.meidian.default.hammer.branchSecondName}")
    private String defaultHammerBranchSecondName;
    @DiamondValue("${business.meidian.default.hammer.storeId}")
    private String defaultHammerStoreId;
    @DiamondValue("${business.meidian.default.hammer.storeName}")
    private String defaultHammerStoreName;
    @DiamondValue("${business.meidian.default.hammer.salesOrganization}")
    private String defaultHammerSalesOrganization;

    /**
     * 大锤默认信息
     *
     * @return
     */
    public DefaultHammer getDefaultHammer() {
        DefaultHammer defaultHammer = new DefaultHammer();
        defaultHammer.setPianzong_mid(defaultHammerMid);
        defaultHammer.setPianzong_oranid(defaultHammerSalesOrganization);
        defaultHammer.setPianzong_stid(defaultHammerStoreId);
        defaultHammer.setPianzong_userid(allHammerStr);
        defaultHammer.setSledge_hammer_branchId(defaultHammerBranchId);
        defaultHammer.setSledge_hammer_branchName(defaultHammerBranchName);
        defaultHammer.setSledge_hammer_branchSecondId(defaultHammerBranchSecondId);
        defaultHammer.setSledge_hammer_branchSecondName(defaultHammerBranchSecondName);
        defaultHammer.setSledge_hammer_mid(defaultHammerMid);
        defaultHammer.setSledge_hammer_regionId(defaultHammerRegionId);
        defaultHammer.setSledge_hammer_regionName(defaultHammerRegionName);
        defaultHammer.setSledge_hammer_storeName(defaultHammerStoreName);
        defaultHammer.setSledge_hammer_userId(defaultHammerUserId);
        return defaultHammer;
    }

    /**
     * 获取片总用户id Set
     *
     * @return
     */
    public Set<Long> getPianZongUserId() {
        Set<Long> set = Sets.newHashSet();
        for (String s : allHammerStr.split(",")) {
            set.add(Long.valueOf(s));
        }
        return set;
    }

}
