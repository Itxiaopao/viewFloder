package com.gome.meidian.mapper.order;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.gome.meidian.entity.OrderRefund;
import org.apache.ibatis.annotations.Select;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * 退货单表 Mapper 接口
 * </p>
 *
 * @author likaile
 * @since 2018-07-30
 */
public interface OrderRefundMapper extends BaseMapper<OrderRefund> {

	@Select("select * from order_refund where mid in (${mid}) and (order_time between '${startDate}' and '${endDate}')")
	List<OrderRefund> selectByDateRange(HashMap<String, Object> queryParams);

	@Select({"<script>",
			"SELECT * FROM order_refund",
			"<where>",
			"<if test='id != null'> and id = #{id} </if>",
			"<if test='orderId != null'> and order_id = #{orderId} </if>",
			"<if test='deliveryId != null'> and delivery_id = #{deliveryId} </if>",
			"<if test='skuId != null'> and sku_id = #{skuId} </if>",
			"<if test='status != status'> and status = #{status} </if>",
			"</where>",
			" ORDER BY create_time,order_time ASC ",
			"<if test='pageIndex != null and pageSize != null'>  LIMIT #{pageIndex},#{pageSize}</if>",
			"</script>"})
	List<OrderRefund> selectPageByBiz(Map<String,Object> param);

	@Select({"<script>",
			"SELECT count(1) FROM order_refund",
			"<where>",
			"<if test='status != null'> and status = #{status} </if>",
			"</where>",
			"</script>"})
	Integer selectCountByBiz(Map<String,Object> param);
}
