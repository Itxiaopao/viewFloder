package com.gome.meidian.mapper.order;


import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.gome.meidian.vo.MeidianGrantRebate;

public interface MeidianGrantRebateMapper {

    int insert(MeidianGrantRebate record);

    int update(MeidianGrantRebate record);

    int delete(Long id);

    List<MeidianGrantRebate> selectListByBiz(Map<String, Object> map);

    MeidianGrantRebate selectOneByBiz(Map<String, Object> map);

    int selectPredictionIncome(@Param("startDate") String startDate, @Param("endDate")String endDate, @Param("puserId")Long puserId);

    List<Map<String,Object>> selectPredictionIncomeWithEveryday(@Param("startDate") String startDate, @Param("endDate")String endDate, @Param("puserId")Long puserId);

    List<Map<String,Object>> selectPredictionIncomeByUserIdList(@Param("userIdList")List<Long> userIdList);

    List<Map<String,Object>> predictionIncomeByPuserIdList(@Param("puserIdList")List<Long> puserIdList);

    int selectRebateUserCount(Map<String, Object> map);

    List<MeidianGrantRebate> selectRebateUserList(Map<String, Object> map);


}