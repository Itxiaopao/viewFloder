package com.gome.meidian.util;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.enums.SaleChannelEnum;
import com.gome.meidian.service.biz.DiamondBiz;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 处理 非员工销售/代客下单/一级销售/二级邀请网络购买
 */
@Slf4j
@Component
public class DealWithSaleChannel {

    @Autowired
    private DiamondBiz diamondBiz;

    /**
     * 获取订单的销售途径
     *
     * @param userId
     * @param shareChain
     * @return
     */
    public Integer checkSaleChannel(Long userId, List<Long> shareChain) {
        if (CollectionUtils.isEmpty(shareChain) || null == userId) {
            log.error("处理销售途径，入参关系链为空userId:{},shareChain:{}", userId, JSON.toJSON(shareChain));
            return null;
        }
        if (diamondBiz.getPianZongUserId().contains(shareChain.get(0))) {
            return SaleChannelEnum.NOTEMPLOYEE.getStatus();
        } else if (userId.equals(shareChain.get(0))) {
            return SaleChannelEnum.REPLACE.getStatus();
        } else if (checkFirstStair(userId, shareChain)) {
            return SaleChannelEnum.FIRSTSTAIR.getStatus();
        } else {
            return SaleChannelEnum.SECONDSTAIR.getStatus();
        }
    }

    /**
     * 检查是否是一级销售
     *
     * @param userId
     * @param shareChain
     * @return
     */
    public Boolean checkFirstStair(Long userId, List<Long> shareChain) {
        int size = shareChain.size();
        if (size == 1) {
            return true;
        }
        if (userId.equals(shareChain.get(size - 1))) {
            //说明当前userId的身份是美店主
            if (size == 2) {
                return true;
            }
        }
        return false;
    }
}
