package com.gome.meidian.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
public class MeidianGrantRebate implements Serializable {

    private static final long serialVersionUID = 6976395516157893536L;

    private Long id;
    //接受返利的用户id
    private Long puserId;
    //提供返利的用户id
    private Long userId;
    //订单id
    private String orderId;
    //订单实付总额
    private Long orderPrice;
    //订单实付初始总额
    private Long orderInitPrice;
    //订单创建时间
    private Date orderTime;
    //妥投时间
    private Date effectTime;
    //返利金额
    private Long rebatePrice;
    //返利状态
    private String rebateStatus;
    //发放返利时间
    private Date rebateTime;
    //返利预算号
    private String businessCode;
    //是否有效
    private Integer isDelete;
    //失效原因
    private Integer failureStatus;
    //用户绑定时间
    private Date bindingTime;
    //新增时间
    private Date insertTime;
    //更新时间
    private Date updateTime;

}