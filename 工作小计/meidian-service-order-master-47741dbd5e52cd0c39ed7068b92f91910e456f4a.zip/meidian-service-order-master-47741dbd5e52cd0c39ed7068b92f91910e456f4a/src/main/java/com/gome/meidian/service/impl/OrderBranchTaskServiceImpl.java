package com.gome.meidian.service.impl;

import java.util.*;

import org.apache.ibatis.binding.MapperMethod;
import org.apache.ibatis.executor.BatchResult;
import org.apache.ibatis.session.SqlSession;
import org.mortbay.log.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.baomidou.mybatisplus.enums.SqlMethod;
import com.baomidou.mybatisplus.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.entity.OrderBranchTask;
import com.gome.meidian.mapper.order.OrderBranchTaskMapper;
import com.gome.meidian.service.OrderBranchTaskService;

/**
 * 分部任务导入接口实现类
 *
 * @author zhangwei-ds19
 * OrderBranchTaskServiceImpl
 */
@Service
public class OrderBranchTaskServiceImpl extends ServiceImpl<OrderBranchTaskMapper, OrderBranchTask> implements OrderBranchTaskService {

    @Autowired
    OrderBranchTaskMapper orderBranchTaskMapper;

    @Override
    public Integer insertOne(OrderBranchTask entity) {
        Integer recordNum = 0;
        if (null != entity && null != entity.getSkuId()) {
            orderBranchTaskMapper.insert(entity);
        }
        return recordNum;
    }


    @Override
    public List<BatchResult> insertBatchNum(List<OrderBranchTask> entityList) {
        Integer recordNum = 0;
        if (null != entityList && entityList.size() > 0) {
            return insertBatchMethod(entityList, 30);
        }

        return null;
    }

    /**
     * 批量插入
     *
     * @param entityList
     * @param batchSize
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public List<BatchResult> insertBatchMethod(List<OrderBranchTask> entityList, int batchSize) {
        List<BatchResult> batchResults = new ArrayList<>();
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            String sqlStatement = sqlStatement(SqlMethod.INSERT_ONE);
            for (int i = 0; i < size; i++) {
                if (StringUtils.isNotEmpty(entityList.get(i).getSkuId()) && null != entityList.get(i).getTaskId()) {
                    batchSqlSession.insert(sqlStatement, entityList.get(i));
                }
                if (i >= 1 && i % batchSize == 0) {
                    batchResults = batchSqlSession.flushStatements();
                }
            }
            batchResults = batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertBatch Method. Cause", e);
        }
        return batchResults;
    }

    @Override
    public List<BatchResult> updateBatchByIdNum(List<OrderBranchTask> entityList, int batchSize) {

        return updateBatchById(entityList, batchSize, true);
    }

    /**
     * 根据主键ID进行批量修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @param selective  是否滤掉空字段
     * @return boolean
     */
    private List<BatchResult> updateBatchById(List<OrderBranchTask> entityList, int batchSize, boolean selective) {
        List<BatchResult> batchResults = new ArrayList<>();
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            SqlMethod sqlMethod = selective ? SqlMethod.UPDATE_BY_ID : SqlMethod.UPDATE_ALL_COLUMN_BY_ID;
            String sqlStatement = sqlStatement(sqlMethod);
            for (int i = 0; i < size; i++) {
                MapperMethod.ParamMap<OrderBranchTask> param = new MapperMethod.ParamMap<>();
                param.put("et", entityList.get(i));
                batchSqlSession.update(sqlStatement, param);
                if (i >= 1 && i % batchSize == 0) {
                    batchResults = batchSqlSession.flushStatements();
                }
            }
            batchResults = batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute updateBatchById Method. Cause", e);
        }
        return batchResults;
    }


    @Override
    public Map<String, Long> insertOrUpdateBatchNum(List<OrderBranchTask> entityList) {
        for (OrderBranchTask entity : entityList) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && null != entity.getTaskId() && StringUtils.isNotEmpty(entity.getBranchCode())) {
                EntityWrapper<OrderBranchTask> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("task_id", entity.getTaskId());
                wrapper.eq("branch_code", entity.getBranchCode());
                OrderBranchTask orderBasedTask = selectOne(wrapper);
                if (null != orderBasedTask) {
                    if (null != entity.getUvQuota())
                        entity.setUvQuota(orderBasedTask.getUvQuota() == null ? entity.getUvQuota() : entity.getUvQuota() + orderBasedTask.getUvQuota());
//                    else
//                        entity.setUvQuota(orderBasedTask.getUvQuota());
                    if (null != entity.getSalesQuota())
                        entity.setSalesQuota(orderBasedTask.getSalesQuota() == null ? entity.getSalesQuota() : entity.getSalesQuota() + orderBasedTask.getSalesQuota());
//                    else
//                        entity.setSalesQuota(orderBasedTask.getSalesQuota());
                    if (null != entity.getShareQuota())
                        entity.setShareQuota(orderBasedTask.getShareQuota() == null ? entity.getShareQuota() : entity.getShareQuota() + orderBasedTask.getShareQuota());
//                    else
//                        entity.setShareQuota(orderBasedTask.getShareQuota());
                }
            }
        }
        return insertOrUpdateBatchMethod(entityList, 30);
    }


    /**
     * 批量插入修改
     *
     * @param entityList 实体对象列表
     * @param batchSize  批量刷新个数
     * @return boolean
     */
    private Map<String, Long> insertOrUpdateBatchMethod(List<OrderBranchTask> entityList, int batchSize) {
        if (CollectionUtils.isEmpty(entityList)) {
            throw new IllegalArgumentException("Error: entityList must not be empty");
        }
        Long count = 0l;
        Map<String, Long> resultMap = new HashMap<>();
        resultMap.put("insertNum", 0l);
        resultMap.put("updateNum", 0l);
        try (SqlSession batchSqlSession = sqlSessionBatch()) {
            int size = entityList.size();
            for (int i = 0; i < size; i++) {
                entityList.get(i).setUpdateTime(new Date());
                resultMap = insertOrUpdateReal(entityList.get(i), resultMap);
                if (i >= 1 && i % batchSize == 0) {
                    batchSqlSession.flushStatements();
                }
            }
            batchSqlSession.flushStatements();
        } catch (Throwable e) {
            throw new MybatisPlusException("Error: Cannot execute insertOrUpdateBatch Method. Cause", e);
        }
        return resultMap;
    }


    /**
     * <p>
     * TableId 注解存在更新记录，否插入一条记录
     * </p>
     *
     * @param entity 实体对象
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String, Long> insertOrUpdateReal(OrderBranchTask entity, Map<String, Long> resultMap) {
//        Map<String, Long> resultMap = new HashMap<>();
        Boolean flag = false;
        Long updateNum = 0l;
        Long insertNum = 0l;
        if (null != entity) {
            if (StringUtils.isNotEmpty(entity.getSkuId()) && null != entity.getTaskId() && StringUtils.isNotEmpty(entity.getBranchCode())) {
                /*
                 * 更新成功直接返回，失败执行插入逻辑
                 */
                EntityWrapper<OrderBranchTask> wrapper = new EntityWrapper<>();
                wrapper.eq("sku_id", entity.getSkuId());
                wrapper.eq("task_id", entity.getTaskId());
                wrapper.eq("branch_code", entity.getBranchCode());
                flag = update(entity, wrapper);
                if (!flag) {
                    flag = insert(entity);
                    if (flag) {
                        insertNum = resultMap.get("insertNum");
                        insertNum++;
                        resultMap.put("insertNum", insertNum);
                    }
                } else {
                    updateNum = resultMap.get("updateNum");
                    updateNum++;
                    resultMap.put("updateNum", updateNum);
                }
                return resultMap;
//                return update(entity, wrapper) || insert(entity);
            }
        } else {
            throw new MybatisPlusException("Error:  Can not execute. Could not find @TableId.");
        }
//        }
        return resultMap;
    }


}
