package com.gome.meidian.vo;

import cn.com.gome.rebate.calc.CouponsDto;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Setter
@Getter
@ToString
public class MogOrderInfo implements Serializable {

    private static final long serialVersionUID = -8081495615970707823L;
    /**
     * 主键id
     */
    private String id;
    /**
     * 订单id
     */
    private Long orderId;
    /**
     * 子订单id
     */
    private Long commerceId;
    /**
     * 配送id
     */
    private String deliveryId;
    /**
     * 下单人id
     */
    private Long userId;
    /**
     * 手机号
     */
    private String phoneNo;
    /**
     * 用户微信昵称
     */
    private String userWeixin;
    /**
     * 团id
     */
    private String kid;
    /**
     * 用户类型  0 普通用户  1 美店主
     */
    private Integer userType;
    /**
     * 下单人直属上级id
     */
    private Long parentUserId;
    /**
     * 片总id
     */
    private Long userIdPZ;
    /**
     * 下单人对应上级集合
     */
    private List<Long> userIdRelation;
    /**
     * skuId
     */
    private String skuId;
    /**
     * skuNo
     */
    private String skuNo;
    /**
     * skuName
     */
    private String skuName;
    /**
     * product Id
     */
    private String itemId;
    /**
     * 购买数量
     */
    private Integer buyNum;
    /**
     * sku剩余拆分数量  默认sku购买数量  全部拆分为0
     */
    private Integer skuSplitNum;
    /**
     * 订单实付总价(单价*数量-优惠券价格) 单位:分
     */
    private Long priceTotal;
    /**
     * 单价 单位:分
     */
    private Long unitPrice;
    /**
     * 优惠券价格 单位:分
     */
    private Long couponPrice;
    /**
     * 分享人
     */
    private Long retailId;
    /**
     * 优化劵信息
     */
    List<CouponsDto> couponsDtoList;
    /**
     * 商户代码
     */
    private String merchantId;
    /**
     * 品牌编码
     */
    private String brandCode;
    /**
     * 站点id
     */
    private String siteId;
    /**
     * 美店订单状态  0:待支付 1:待发货 2:已取消 3:待收货 5:已收货 6:售后
     */
    private Integer orderStatus;
    /**
     * 显示的订单状态
     */
    private Integer showStatus;
    /**
     * 提奖金额  单位:分
     */
    private Long awardMoney;
    /**
     * 佣金金额 单位:分
     */
    private Long commMoney;
    /**
     * 百货店主提货标识 null or 0:未提货,1:已提货
     */
    private Integer isPickGoods;
    /**
     * 订单时间
     */
    private Date orderTime;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新时间
     */
    private Date updateTime;
}
