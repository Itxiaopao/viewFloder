package com.gome.meidian.managerTest;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.GroupOrderApplication;
import com.gome.meidian.grouporder.utils.BindInfoUpdateThread;
import com.gome.meidian.grouporder.utils.RedisKeyUtils;
import com.gome.meidian.grouporder.utils.ThreadPoolManager;
import com.gome.meidian.grouporder.vo.wechatLogin.WeChatOpenIdAndUserIdVO;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.UserRelation;
import com.gome.meidian.user.manager.IUserRelationManager;
import com.gome.memberCore.lang.model.GomeSNSUser;
import com.gome.memberCore.utils.utils.JsonSerializeUtil;
import com.gome.userCenter.common.constants.LoginConstants;
import com.gome.userCenter.facade.login.ISNSLoginFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UserInfo;
import com.gome.userCenter.model.UserLoginResult;
import com.gome.userCenter.model.enu.CompanyNameEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import redis.Gcache;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/7 17:38
 * @Description
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = GroupOrderApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableAutoConfiguration
public class WeChatSNSLogin {


    @Autowired
    ISNSLoginFacade snsLoginFacade;

    //添加SCN老用户
    @Test
    public void addWechatUser() {
        //dubbo注入
        String  unionID="4301d5ac-5c6c-45fa-82dc-3e8a";
        String  snsUserName="小美1000";
        RequestParams requestParams = new RequestParams("gomeShopWeChat", "10.57.29.216", "52232", null, null, null);
        // 第一个参数管家可以传“gomegjWap”或者“gomegjMobile”
        HashMap<String, Object> paramsMap = new HashMap<String, Object>();
        paramsMap.put(LoginConstants.SNS_UNION_ID_KEY, unionID); // 微信的unionID 必传参数
        paramsMap.put(LoginConstants.SNS_REGISTER_SOURCE_KEY, "wechat"); // 微信来源，固定传“wechat”
        GomeSNSUser gomeSNSUser = new GomeSNSUser(null, "wechat", unionID, snsUserName); // 第二个参数固定传“wechat” 昵称必传
        // 参数描述：第三方用户对象、请求参数、特殊参数
        paramsMap.put(LoginConstants.SNSUSER_REGISTER, false);
        paramsMap.put(LoginConstants.COMPANYNAME, CompanyNameEnum.gomeOnLine.name());// 登录时固定传递该字符串“gomeOnLine”
        UserLoginResult<UserInfo> result = snsLoginFacade.doSNSLogin(gomeSNSUser, requestParams, paramsMap);
        int code = result.getCode();// 登录成功失败代码
        String message = result.getMessage();// 登录成功失败信息
        System.out.println("********" + JsonSerializeUtil.serialize(result));


    }



    @Test
    public void addWechatUser2() {
        String  unionID="0f8293ee-cc0d-4d99-9bb4-fb3c";
        RequestParams requestParams = new RequestParams("gomegjWap", "10.57.29.216", "52232", null, null, null);// 第一个参数管家可以传“gomegjWap”或者“gomegjMobile”
        HashMap<String, Object> paramsMap = new HashMap<String, Object>();
        paramsMap.put(LoginConstants.SNS_UNION_ID_KEY, unionID); // 微信的unionID 必传参数
        paramsMap.put(LoginConstants.SNS_REGISTER_SOURCE_KEY, "wechat"); // 微信来源，固定传“wechat”
        GomeSNSUser gomeSNSUser = new GomeSNSUser(null, "wechat", unionID, "小美1000"); // 第二个参数固定传“wechat” 昵称必传
        // 参数描述：第三方用户对象、请求参数、特殊参数

        paramsMap.put(LoginConstants.COMPANYNAME, CompanyNameEnum.gomeOnLine.name());// 登录时固定传递该字符串“gomeOnLine”
        UserLoginResult<UserInfo> result = snsLoginFacade.doSNSLogin(gomeSNSUser, requestParams, paramsMap);
        int code = result.getCode();// 登录成功失败代码
        String message = result.getMessage();// 登录成功失败信息
        System.out.println("********" + JsonSerializeUtil.serialize(result));


    }



    @Test
    public  void doPostURLTOSaveRelation(){

        //openid 是 字符串 微信openid
        //unionid 是 字符串 微信unionid
        //user_id 是 字符串 本系统用户id
        //user_name 是 字符串 本系统用户昵称
        //dyn_user_id 是 字符串 本系统用户id
        //dyn_user_confirm 否 字符串 scn 没有可以不填
        // platForm 是 字符串 微信平台标识 Service1314 对应国美家生活 Serviceplus 国美美店


        String  openId="11111111";
        String  unionid="222222222222";
        String  user_id="1225555544";
        String  user_name="xiaoyu";
        String  dyn_user_id="1225555544";
        String  dyn_user_confirm=null;
        String  platForm="";




    }


    @Resource(name = "userCenter")
    private Gcache userCenter;

    @Autowired
    private IUserRelationManager iUserRelationManager;



    /**
     * 重新跑openId 时间
     */
    @Test
    public  void   updateOpenIdInfo(){
        Boolean flag=false;
        String  userId="100049397501";
        String  openId="oJ5y11BoPMEEEkr3tOjdi3Xd-bEM";
        String  key = BindInfoUpdateThread.USER_OPENID_ID_SET + ":" + RedisKeyUtils.getHKey(openId);
        String  relationStr=userCenter.hget(key,openId);

        try {
            List<UserRelation> list = null;
            if(org.apache.commons.lang3.StringUtils.isNotBlank(relationStr)) {
                list = JSONObject.parseArray(relationStr, UserRelation.class);
            }
            List<UserRelation>  newList=new ArrayList<>();
            for (UserRelation userRelation:list) {
                SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date1=format.parse("2018-12-14 00:00:00");//str表示yyyy年MM月dd HH:mm:ss格式字符串
                userRelation.setCtime(date1);
                userRelation.setUtime(date1);
                newList.add(userRelation);
                //iUserRelationManager.updateUserRelation(userRelation);
            }

            //MapResults<List<UserRelation>> results = iUserRelationManager.findByUserId(userId);
            if(list != null && list.size() > 0) {
                userCenter.hset(key, userId, JSONObject.toJSONString(newList));
            }
        }catch(Exception e) {
            e.printStackTrace();

        }

        if(null!=userId&&null!=openId) {

            if(StringUtils.isNotBlank(relationStr)){
                List<UserRelation> userRelations = JSONObject.parseArray(relationStr, UserRelation.class);
                if(null!=userRelations&&userRelations.size()>0){

                    for (UserRelation userRelation:userRelations) {
                        String  dbOpenId=userRelation.getOpenId();
                        String  dbUserId=userRelation.getUserId();
                        if(openId.equals(dbOpenId)){
                            Date uptime=userRelation.getUtime();
                            long  time1=uptime.getTime();
                            long  time2=new Date().getTime();
                            long days=getDistanceDays(time2,time1);
                            if(days>1&&dbUserId.equals(userId)){
                                //唯一需要变更绑定关系
                                flag=true;
                                break;
                            }
                        }
                    }
                }
            }
        }

        System.out.println("flag========================== :"+flag);


    }


    public static long getDistanceDays(long time1, long time2) {
        long days=0;
        long diff ;
        if(time1<time2) {
            diff = time2 - time1;
        } else {
            diff = time1 - time2;
        }
        days = diff / (1000 * 60 * 60 * 24);
        return days;
    }

}



