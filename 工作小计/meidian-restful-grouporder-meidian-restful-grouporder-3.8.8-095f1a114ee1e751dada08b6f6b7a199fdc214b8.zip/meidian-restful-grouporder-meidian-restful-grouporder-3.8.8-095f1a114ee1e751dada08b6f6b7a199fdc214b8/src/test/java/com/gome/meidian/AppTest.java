package com.gome.meidian;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.gomeplus.bs.interfaces.gorder.vo.ProductsVo;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest {
	public static void main(String[] args) {
		List<String> list = new ArrayList<>();
		for(int a = 1; a <= 1801; a++){
			list.add("aaaa" + a);
		}
		System.out.println(list);
		int listSize = list.size();
		int selectCount = listSize%30 == 0 ? listSize/30 :listSize/30 + 1;

		List<String> paramList = null;
		for(int a = 1; a <= selectCount; a ++){
			if(selectCount == 1){
				paramList = list;
			}else{
				if(a != selectCount){
					paramList = list.subList(30 * (a - 1), 30 * a);
				}else{
					paramList = list.subList(30 * (a - 1), listSize);
				}
			}
			System.out.println("第"+a+"轮循环：" + paramList);
		}
		
		
		
	}



}
