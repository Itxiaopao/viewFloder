package com.gome.meidian.managerTest;

import com.gome.meidian.BaseTestClass;
import com.gome.meidian.grouporder.vo.mshopUserVo.CommonVariableVo;
import com.gome.userCenter.facade.login.IQuickLoginFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gome.userCenter.model.UserLoginResult;
import org.jboss.util.Heap;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Stack;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * @author sunxueyan-ds
 * @Title: TestSunXueYan
 * @ProjectName meidian-restful-grouporder
 * @Description: TODO
 * @date 2018/12/7 14:52
 */

public class TestSunXueYan extends BaseTestClass {

    @Autowired
    private IQuickLoginFacade iQuickLoginFacade;

    @Test
    public void quickLogin() {
        String mobile = "15032155953";
        String invokeFrom = CommonVariableVo.invokeFrom;
        RequestParams requestParams = new RequestParams();
        requestParams.setClientIp("114.113.63.7");
        requestParams.setRemotePort("65427");
        requestParams.setInvokeChannel(CommonVariableVo.invokeFrom);
        Map<String, Object> map = new HashMap<>();
        map.put("companyName", CommonVariableVo.companyName);
        map.put("businessName", CommonVariableVo.BusinessName_quick);
        map.put("templateId", CommonVariableVo.BusinessId_quick);
        map.put("msgCode", "168026");

        UserLoginResult<UnifyUserInfoExt> unifyUserInfoExtUserLoginResult = iQuickLoginFacade.quickLogin(mobile, invokeFrom, requestParams, map);
        System.out.println(unifyUserInfoExtUserLoginResult);
    }

    private static <T extends Comparable<? super T>> void mergeSort(T[] arr,
                                                                    T[] tmpArray, int left, int right) {
        if (left < right) {
            int center = (left + right) / 2;
            mergeSort(arr, tmpArray, left, center);
            mergeSort(arr, tmpArray, center + 1, right);
            merge(arr, tmpArray, left, center + 1, right);
        }
    }


    private static <T extends Comparable<? super T>> void merge(T[] arr,
                                                                T[] tmpArray, int leftPos, int rightPos, int rightEnd) {
        int leftEnd = rightPos - 1;
        int numElements = rightEnd - leftPos + 1;
        int tmpPos = leftPos;// 只使用tmpArray中某一部分区域
        while (leftPos <= leftEnd && rightPos <= rightEnd) {
            if (arr[leftPos].compareTo(arr[rightPos]) <= 0)
                tmpArray[tmpPos++] = arr[leftPos++];
            else
                tmpArray[tmpPos++] = arr[rightPos++];
        }

        while (leftPos <= leftEnd)
            tmpArray[tmpPos++] = arr[leftPos++];// copy rest of left half
        while (rightPos <= rightEnd)
            tmpArray[tmpPos++] = arr[rightPos++];// copy rest of right half

        // copy tmpArray back
        for (int i = 0; i < numElements; i++, rightEnd--)
            arr[rightEnd] = tmpArray[rightEnd];//只拷贝当前 merge 的部分数组

        /**
         * 复制了整个数组中的所有元素
         for(int i = 0; i < tmpArray.length; i++)
         arr[i] = tmpArray[i];
         */
    }

    public static <T extends Comparable<? super T>> void mergeSort(T[] arr) {
//        T[] tmpArray = (T[]) new Comparable[arr.length];
//        mergeSort(arr, tmpArray, 0, arr.length - 1);
        int[] x = {24, 13, 26, 1, 2, 27, 38, 15};

        sort(x, 0, arr.length - 1);
    }


    public static int[] sort(int[] a,int low,int high){
        int mid = (low+high)/2;
        if(low<high){
            sort(a,low,mid);
            sort(a,mid+1,high);
            //左右归并
            merge(a,low,mid,high);
        }
        return a;
    }

    public static void merge(int[] a, int low, int mid, int high) {
        int[] temp = new int[high-low+1];
        int i= low;
        int j = mid+1;
        int k=0;
        // 把较小的数先移到新数组中
        while(i<=mid && j<=high){
            if(a[i]<a[j]){
                temp[k++] = a[i++];
            }else{
                temp[k++] = a[j++];
            }
        }
        // 把左边剩余的数移入数组
        while(i<=mid){
            temp[k++] = a[i++];
        }
        // 把右边边剩余的数移入数组
        while(j<=high){
            temp[k++] = a[j++];
        }
        // 把新数组中的数覆盖nums数组
        for(int x=0;x<temp.length;x++){
            a[x+low] = temp[x];
        }
    }

    public static void mergeSort(int[] list){
        if(list.length > 1){
            int[] firstHalf = new int[list.length/2];
            System.arraycopy(list, 0, firstHalf, 0, list.length/2);
            mergeSort(firstHalf);

            int secondHalfLength = list.length - list.length/2;
            int[] secondHalf = new int[secondHalfLength];
            System.arraycopy(list, list.length/2, secondHalf, 0, secondHalfLength);
            mergeSort(secondHalf);

            merge(firstHalf, secondHalf, list);
        }
    }

    public static void merge(int[] list1, int[] list2, int[] temp){
        int current1 = 0;
        int current2 = 0;
        int current3 = 0;

        while (current1 < list1.length && current2 < list2.length){
            if(list1[current1] < list2[current2]){
                temp[current3++] = list1[current1++];
            }else {
                temp[current3++] = list2[current2++];
            }
        }
        while (current1 < list1.length){
            temp[current3++] = list1[current1++];
        }
        while (current2 < list2.length){
            temp[current3++] = list2[current2++];
        }
    }


    public static void main(String[] args) {
        int a = 120000000;
        System.out.println(a>>10);
        System.out.println(a>>8);
        System.out.println((a>>>10) ^ (a >>> 8));
//        Heap heap = new Heap();
//
//        Queue queue = new LinkedBlockingDeque();
//        Stack stack = new Stack();
//
//        Integer[] arr = {24, 13, 26, 1, 2, 27, 38, 15};
//        int[] a = {24, 13, 26, 1, 2, 27, 38, 15};
////        mergeSort(arr);
//        mergeSort(a);
////        for (Integer i : arr)
////            System.out.print(i + " ");
//        for (int i : a)
//            System.out.print(i + " ");

//        Map<String, Integer> map = new TreeMap<>();
//        String text = "Good morning. Have a good class. Have a good visit. Have fun!";
//        String[] words = text.split("[ \n\r\t.,;:!?(){}]");
//        System.out.println(words);
//        for(int i = 0; i < words.length; i ++){
//            String key = words[i].toLowerCase();
//            if(key.length() > 0){
//                if(!map.containsKey(key)){
//                    map.put(key, 1);
//                } else {
//                    int value = map.get(key);
//                    value++;
//                    map.put(key, value);
//                }
//            }
//        }
//
//        Set<Entry<String, Integer>> entries = map.entrySet();
//        for(Entry<String, Integer> entry : entries){
//            System.out.println(entry.getKey() + "\t" + entry.getValue());
//        }
    }
}
