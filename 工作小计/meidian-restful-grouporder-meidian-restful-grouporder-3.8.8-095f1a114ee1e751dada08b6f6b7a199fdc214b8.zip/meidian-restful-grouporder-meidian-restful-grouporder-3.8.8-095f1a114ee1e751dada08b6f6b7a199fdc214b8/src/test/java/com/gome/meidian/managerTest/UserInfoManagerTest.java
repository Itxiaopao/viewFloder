package com.gome.meidian.managerTest;

import com.gome.meidian.grouporder.utils.AesUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.BaseTestClass;
import com.gome.meidian.grouporder.manager.mshopUserManager.UserBasicInfoManager;
import com.gome.meidian.grouporder.vo.UserInfoDto;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;


public class UserInfoManagerTest extends BaseTestClass {
	@Autowired
	private UserBasicInfoManager userInfoManager;
	String invokeFrom = "gomeShop";

	@Test
	public void getUserBasicInfo() {
		String userId = "100040422116";
		UserInfoDto uDto = userInfoManager.getUserBasicInfo(userId);
		System.out.println(JSON.toJSONString(uDto));
	}
//	@Test
//	public void dealWithImage() throws IOException {
//		OutputStream out = null;
//		try {
//			out = new FileOutputStream("E://sz/photo.png");
//			String str = "";
//			byte[] b = AesUtils.base64Decode(str);
//			for (int i = 0; i < b.length; ++i) {
//				if (b[i] < 0) {// 调整异常数据
//					b[i] += 256;
//				}
//			}
//			out.write(b);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}catch(Exception ce){
//			ce.printStackTrace();
//		}finally {
//			out.flush();
//			out.close();
//		}
//	}
}
