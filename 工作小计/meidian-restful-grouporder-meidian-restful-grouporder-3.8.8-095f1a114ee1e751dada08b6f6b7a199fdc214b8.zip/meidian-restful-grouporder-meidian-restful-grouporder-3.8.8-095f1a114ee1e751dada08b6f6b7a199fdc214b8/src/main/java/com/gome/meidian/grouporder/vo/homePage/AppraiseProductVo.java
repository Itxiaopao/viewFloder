package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class AppraiseProductVo implements Serializable{

	private static final long serialVersionUID = -849391636899025216L;

	@NotBlank(message = "{param.error}")
	private String productId;
	@NotBlank(message = "{param.error}")
	private String productName;
	@NotBlank(message = "{param.error}")
	private String appraiseContent;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getAppraiseContent() {
		return appraiseContent;
	}
	public void setAppraiseContent(String appraiseContent) {
		this.appraiseContent = appraiseContent;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

	
}
