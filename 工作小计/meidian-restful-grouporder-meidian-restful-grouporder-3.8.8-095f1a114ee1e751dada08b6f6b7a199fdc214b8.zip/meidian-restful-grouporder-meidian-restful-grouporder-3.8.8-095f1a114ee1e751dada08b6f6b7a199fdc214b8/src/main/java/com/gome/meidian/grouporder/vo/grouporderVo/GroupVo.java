package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.product.ProductInfo;

/**
 * 团详情页
 * @author shichangjian
 *
 */
public class GroupVo implements Serializable{

	private static final long serialVersionUID = -5381326520544983245L;

	private Group group;			// 团信息
	private ProductInfo productInfo;// 商品信息
	private Activity activity;		// 活动信息
	private int status;				// 用户对团的操作情况
	
	public Group getGroup() {
		return group;
	}
	public void setGroup(Group group) {
		this.group = group;
	}
	public ProductInfo getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(ProductInfo productInfo) {
		this.productInfo = productInfo;
	}
	public Activity getActivity() {
		return activity;
	}
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
	
	
	
	
}
