package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 槽位
 * @author shichangjian
 *
 */
public class Slot implements Serializable{

	private static final long serialVersionUID = 1964314225540482294L;

	private String name;		//活动页标题名
	private String image;
	private String is_effective;
	private String end_time;
	private String table_name;
	private String link_name;	//活动页副标题名
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getIs_effective() {
		return is_effective;
	}
	public void setIs_effective(String is_effective) {
		this.is_effective = is_effective;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	public String getTable_name() {
		return table_name;
	}
	public void setTable_name(String table_name) {
		this.table_name = table_name;
	}
	public String getLink_name() {
		return link_name;
	}
	public void setLink_name(String link_name) {
		this.link_name = link_name;
	}
	
	
}
