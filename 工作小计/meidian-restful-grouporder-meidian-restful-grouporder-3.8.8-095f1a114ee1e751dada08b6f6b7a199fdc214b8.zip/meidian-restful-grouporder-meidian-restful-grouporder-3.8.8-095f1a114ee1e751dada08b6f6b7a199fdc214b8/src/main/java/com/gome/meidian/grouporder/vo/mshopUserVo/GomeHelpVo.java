package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;

/**
 * 小美萌店
 *
 * @author limenghui
 * @create 2020-02-07 18:53
 */
@Builder
@Data
public class GomeHelpVo implements Serializable {

    private static final long serialVersionUID = -9000124553157045806L;

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 上级用户id
     */
    private Long puserId;

    /**
     * 头像
     */
    private String image;

    /**
     * 用户昵称
     */
    private String nickName;

    /**
     * 预计收益
     */
    private Double awardPrice;

    /**
     * 首单人数
     */
    private Integer firstOrdernNum;

    /**
     * 更新用户状态时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateStatusTime;

    private String status;

    @Override public String toString() {
        return "GomeHelpVo{" + "userId=" + userId + ", puserId=" + puserId + ", image='" + image + '\'' + ", nickName='"
                + nickName + '\'' + ", awardPrice=" + awardPrice + ", updateStatusTime=" + updateStatusTime
                + ", status='" + status + '\'' + '}';
    }
}

