package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class CollectionProductVo implements Serializable{

	private static final long serialVersionUID = 4020844582861091051L;
	@NotBlank(message = "{param.error}")
	private String productId;

	@NotBlank(message = "{param.error}")
	private String skuId;
	
	@NotBlank(message = "{param.error}")
	private String skuNo;

	@NotBlank(message = "{param.error}")
	private String activityId;

	private String groupId;
	
	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getSkuNo() {
		return skuNo;
	}

	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	
	
}
