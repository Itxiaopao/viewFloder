package com.gome.meidian.grouporder.utils;


public class ChannelUtils {

	/**
	 * 来源渠道兼容校验,cms使用
	 * @param cookiehannel
	 * @param channel
	 * @return
	 */
	public static int getCmsChannel(String cookiehannel, String channel){
		int cmsChannel = GroupOrderConstants.MEIDIAN_CMS_WAP;
		if(null != cookiehannel && !cookiehannel.equals("") && null != channel && !channel.equals("")){
			cmsChannel = check(cookiehannel, cmsChannel);
		}else if(null != cookiehannel && !cookiehannel.equals("")){
			cmsChannel = check(cookiehannel, cmsChannel);
		}else if(null != channel && !channel.equals("")){
			cmsChannel = check(channel, cmsChannel);
		}
		
		return cmsChannel;
	}
	
	public static int check(String channel, int cmsChannel){
		if(channel.equalsIgnoreCase(GroupOrderConstants.CHANNEL_WAP)){
			
		}else if(channel.equalsIgnoreCase(GroupOrderConstants.CHANNEL_MINI)){
			cmsChannel = GroupOrderConstants.MEIDIAN_CMS_MINI;
		}else if(channel.equalsIgnoreCase(GroupOrderConstants.CHANNEL_ANDROID_APP)){
			cmsChannel = GroupOrderConstants.MEIDIAN_CMS_ANDROID_APP;
		}else if(channel.equalsIgnoreCase(GroupOrderConstants.CHANNEL_IOS_APP)){
			cmsChannel = GroupOrderConstants.MEIDIAN_CMS_IOS_APP;
		}
		
		return cmsChannel;
	}
	
	/**
	 * 门店编码兼容校验
	 * @param cookieStoreCode
	 * @param storeCode
	 * @param defaultStoreCode
	 * @return
	 */
	public static String getStoreCode(String cookieStoreCode, String storeCode, String defaultStoreCode){
		String stoCode = defaultStoreCode;
		
		if(null != cookieStoreCode && !cookieStoreCode.equalsIgnoreCase("") && null != storeCode && !storeCode.equals("")){
			stoCode = cookieStoreCode;
		}else if(null != cookieStoreCode && !cookieStoreCode.equalsIgnoreCase("")) 
			stoCode = cookieStoreCode;
		else if(null != storeCode && !storeCode.equals(""))
			stoCode = storeCode;
		
		return stoCode;
	}
	
	/**
	 * 站点处理
	 * @param cookieChannel
	 * @param channel
	 * @return
	 */
	public static String site(String cookieChannel, String channel){
		String site = GroupOrderConstants.meidian_wap_site;
		if(null != cookieChannel && !cookieChannel.equals("")){
			if(cookieChannel.equals(GroupOrderConstants.CHANNEL_WAP)){
				
			}else if(cookieChannel.equals(GroupOrderConstants.CHANNEL_MINI)){
				site = GroupOrderConstants.meidian_mini_site;
			}else if(cookieChannel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP)){
				site = GroupOrderConstants.meidian_app_site;
			}else if(cookieChannel.equals(GroupOrderConstants.CHANNEL_IOS_APP)){
				site = GroupOrderConstants.meidian_app_site;
			}
		}else if(null != channel && !channel.equals("")){
			if(channel.equals(GroupOrderConstants.CHANNEL_WAP)){
				
			}else if(channel.equals(GroupOrderConstants.CHANNEL_MINI)){
				site = GroupOrderConstants.meidian_mini_site;
			}else if(channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP)){
				site = GroupOrderConstants.meidian_app_site;
			}else if(channel.equals(GroupOrderConstants.CHANNEL_IOS_APP)){
				site = GroupOrderConstants.meidian_app_site;
			}
		}
		
		return site;
	}
}
