package com.gome.meidian.grouporder.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.config.PageCodeConfig;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.buyRebate;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupProduct;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.shareRebate;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReqVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupReq;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupTotal;
import com.gome.meidian.grouporder.vo.meidiancms.Model;
import com.gome.meidian.grouporder.vo.product.HomeCouponProductRes;
import com.gome.meidian.grouporder.vo.product.MeidianPrice;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebate;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateReq;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;
import com.gome.meidian.grouporder.vo.rebate.ShareRebateResponse;
import com.gome.meidian.grouporder.vo.rebate.ShareRebateVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.sso.model.UserInfoCache;
import com.gome.stage.interfaces.item.IProductInfoService;
import com.gome.stage.item.GoodsInfo;

import redis.Gcache;

@RestController
@Validated
@RequestMapping("/v1/homeProducts")
public class HomeProductsController {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private HomeProductsManager homeProductsManager;
	@Autowired
	private GroupOrderManager groupOrderManager;

	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	@Value("${gome.defaultStoreCode}")
	private String defaultStoreCode; // 默认门店，西坝河
	@Resource(name = "gcache")
	private Gcache gcache;
	@Resource(name = "gcachezz")
	private Gcache gcachezz;
	@Autowired
	private PageCodeConfig pageCodeConfig;
	@Autowired
	private AuthencationUtils authencationUtils;
	
	@Autowired
	private IProductInfoService productInfoService;
	
	/**
	 * 首页组团列表
	 * 
	 * @param productIdActivityIds
	 * @param areaCode
	 * @param storeCode
	 * @param ukey
	 * @param typeName
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/groupInfo", method = RequestMethod.POST)
	public ResponseJson groupInfo(
			@RequestBody GroupInfoReqVo groupInfoReqVo,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> resMap = new HashMap<String, Object>();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
		
		List<ProductGroupInfoVo> productGroupInfoVos = homeProductsManager
					.groupInfo(groupInfoReqVo.getGroupInfoReqs(), MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode"));
		
		resMap.put("productGroupInfoVos", productGroupInfoVos);

		response.setData(resMap);
		return response;
	}

	/**
	 * 首页基础商品列表
	 * 
	 * @param productIds
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getProducts", method = RequestMethod.POST)
	public ResponseJson getProducts(
			@RequestBody @Validated({ groupProduct.class }) GroupReq groupReq,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;

		Map<String, Object> productsMap = new HashMap<String, Object>();

		List<HomeCouponProductRes> homeCouponProducts = homeProductsManager.getHomeProductCoupons(groupReq.getProductCouponReqs(), MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
		
		productsMap.put("products", homeCouponProducts);

		response.setData(productsMap);
		return response;
	}

	/**
	 * 购买返利-单独调
	 * 
	 * @param productId
	 * @param areaCode
	 * @param skuNo
	 * @param price 单位：元
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getRebate")
	public ResponseJson rebate(
			@RequestParam(value = "skuNo", required = false) String skuNo,
			@RequestParam(value = "skuId", required = false) String skuId,
			@RequestParam(value = "areaCode", required = false) String areaCode)
			throws MeidianException {

		ResponseJson response = new ResponseJson();
		Map<String, Object> map = new HashMap<String, Object>();

//		map.put("buyRebate", homeProductsManager.getBuyRebate(productId, skuNo, areaCode, price));
//
//		response.setData(map);
		
		//加盟店逻辑begin
		String mOrg = MeidianEnvironment.getKey("priceReqStoreCode");
		areaCode = MeidianEnvironment.getKey("priceReqAreaCode");
		//加盟店逻辑end;
		
		if (StringUtils.isEmpty(areaCode)) {
			areaCode = defaultAreaCode;
		}

		map.put("buyRebate", homeProductsManager.getgetBuyRebateOneInfo(skuNo, skuId, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, mOrg, GroupOrderConstants.PRICE_POLICYID));

		response.setData(map);
		return response;
	
	}


	/**
	 * 获取商品的已团件数
	 * 
	 * @param groupId
	 * @param pageNum
	 * @param pageSize
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getTotalBuyNumber")
	public ResponseJson getTotalBuyNumber(
			@RequestParam(value = "productIds") List<String> productIds)
			throws MeidianException {
		ResponseJson response = new ResponseJson();

		List<ProductGroupTotal> productGroupTotals = new ArrayList<ProductGroupTotal>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		if (null == productIds || productIds.size() == 0) {
			resMap.put("productGroupTotals", productGroupTotals);
			response.setData(resMap);
			return response;
		}
		productGroupTotals = groupOrderManager.getProductBuyNum(productIds);
		resMap.put("productGroupTotals", productGroupTotals);
		
		response.setData(resMap);
		return response;

	}

	/**
	 * 佣金-批量（分享返-列表）
	 * 
	 * @param productId
	 * @param skuId
	 * @param orgCode
	 * @param price 单位：分
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getPrdRebate", method = RequestMethod.POST)
	public ResponseJson getPrdRebate(
			@RequestBody @Validated({ shareRebate.class }) ShareRebateVo shareRebateVo,
			@RequestParam("organizationId") String organizationId,
			@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "Channel", required = false) String Channel,
			@RequestParam(value = "channel", required = false) String channel
			) throws MeidianException {
		
		
//		long start = System.currentTimeMillis();
		
		//判断渠道来源
		int chan = ChannelUtils.getCmsChannel(Channel, channel);
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> buyRebateMap = new HashMap<String, Object>();
//		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
//		String userId = null;
//		if (userInfo != null && StringUtils.isNotBlank(userInfo.getId())) {
//			userId = userInfo.getId();
//		}
		
		String userId = authencationUtils.authenticationLogin(scn);
			//判断是否为app端的请求3,4 可进行返利查询
		if(userId == null){
			if(chan != 3 && chan != 4){
				buyRebateMap.put("shareRebates", null);
				response.setData(buyRebateMap);
				return response;
			}
		}


		
		
		List<ShareRebateResponse> shareRebateResponses = null;
		
		// 佣金开关
		String onOff = gcache.get("shareRebateOnOff");
		if(null == onOff){
			shareRebateResponses = homeProductsManager.shareRebate(shareRebateVo.getShareRebates(), organizationId , userId);
		}else{
			buyRebateMap.put("shareRebates", null);
			
			response.setData(buyRebateMap);
			return response;
		}
		buyRebateMap.put("shareRebates", shareRebateResponses);
		
		response.setData(buyRebateMap);
		
		
		
		
		
		
		
		
		
//		long end = System.currentTimeMillis();
//		long sum = end - start;
//		logger.info("/getPrdRebate sum time ==>{}",sum);
//		if(sum > 1000 && sum < 2000){
//			logger.info("/getPrdRebate sum time 1==>{}",sum);
//		}else if(sum > 2000 && sum < 3000){
//			logger.info("/getPrdRebate sum time 2==>{}",sum);
//		}else if(sum > 3000 && sum < 4000){
//			logger.info("/getPrdRebate sum time 3==>{}",sum);
//		}else if(sum > 4000 && sum < 5000){
//			logger.info("/getPrdRebate sum time 4==>{}",sum);
//		}else if(sum > 5000){
//			logger.info("/getPrdRebate sum time 5==>{}",sum);
//		}
		
		
		
		
		
		
		
		
		
		
		return response;
	}
	
	/**
	 * 佣金（分享返-详情页）
	 * 
	 * @param productId
	 * @param skuId
	 * @param orgCode
	 * @param price 单位：分
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getShareRebate", method = RequestMethod.GET)
	public ResponseJson getShareRebate(
			@NotBlank(message = "{param.error}") @RequestParam("productId") String productId,
			@RequestParam("skuNo") String skuNo,
			@RequestParam("skuId") String skuId,
			@NotNull(message = "{param.error}") @RequestParam("price") Long price,
			@RequestParam("shopId") String shopId,
			@RequestParam("organizationId") String organizationId,
			@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "Channel", required = false) String Channel,
			@RequestParam(value = "channel", required = false) String channel
			) throws MeidianException {
		int chan = ChannelUtils.getCmsChannel(Channel, channel);
		ResponseJson response = new ResponseJson();
		Map<String, Object> buyRebateMap = new HashMap<String, Object>();
//		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
//		String userId = null;
//		if (userInfo != null && StringUtils.isNotBlank(userInfo.getId())) {
//			userId = userInfo.getId();
//			buyRebateMap.put("shareRebate", homeProductsManager.shareRebateOneself(productId, skuNo, skuId, price, shopId, organizationId , userId));
//		} 
//		
//		else {
//			buyRebateMap.put("shareRebate","0");
//		}
		
		String userId = authencationUtils.authenticationLogin(scn);
		//判断是否为app端的请求3,4 可进行返利查询
		if(userId == null){
			if(chan != 3 && chan != 4){
				buyRebateMap.put("shareRebate","0");
				response.setData(buyRebateMap);
				return response;
			}
		}
		
		buyRebateMap.put("shareRebate", homeProductsManager.shareRebateOneself(productId, skuNo, skuId, price, shopId, organizationId , userId));
		response.setData(buyRebateMap);
		return response;
	}

	/**
	 * 美店价格
	 * 
	 * @param productId
	 * @param skuId
	 * @param orgCode
	 * @param price
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getMeidianPrice", method = RequestMethod.GET)
	public ResponseJson getMeidianPrice(
			@NotBlank(message = "{param.error}") @RequestParam("productId") String productId,
			@NotBlank(message = "{param.error}") @RequestParam("skuId") String skuId,
			@RequestParam(value = "areaCode", required = false) String areaCode
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "SCN", required = false) String SCN,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils
			) throws MeidianException {
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
		ResponseJson response = new ResponseJson();
		MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productId, skuId, MeidianEnvironment.getKey("priceReqAreaCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL, MeidianEnvironment.getKey("priceReqStoreCode"),
				GroupOrderConstants.PRICE_POLICYID);

		response.setData(meidianPrice);
		return response;
	}

	/**
	 * 首页超级返商品列表信息
	 * @param buyRebates
	 * @param areaCode
	 * @param storeCode
	 * @param ukey
	 * @param typeName
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getProductBuyRebates", method = RequestMethod.POST)
	public ResponseJson getProductBuyRebates(
			@RequestBody @Validated({ buyRebate.class }) ProductBuyRebateReq productBuyRebateReq,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		String Channel = MeidianEnvironment.getChannel();
		if(null != Channel && !Channel.equals("")){
			if(Channel.equals(GroupOrderConstants.CHANNEL_IOS_APP) 
					|| Channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP))
				return response;
		}
		
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		List<ProductBuyRebate> proRebates = productBuyRebateReq.getProductBuyRebates();
		if(null == proRebates || proRebates.size() == 0){
			resMap.put("productBuyRebateVos", null);
			response.setData(resMap);
			return response;
		}

		List<ProductBuyRebateVo> productBuyRebateVos = homeProductsManager.getProductBuyRebates(proRebates, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
		resMap.put("productBuyRebateVos", productBuyRebateVos);
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 提供给楼上cms后台使用，实时数据，不支持高并发
	 * @param productIds
	 * @param areaCode
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getProductsCms")
	public ResponseJson getProductsCms(
			@RequestParam(value = "skuIds") List<String> skuIds,
			@RequestParam(value = "imageSize") String imageSize
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		resMap.put("products", homeProductsManager.products(skuIds, imageSize));
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 提供给运维判断服务是否健康
	 * @return
	 */
	@RequestMapping(value = "/checkProjcet", method = RequestMethod.GET)
	public ResponseJson checkProjcet(){
		ResponseJson response = new ResponseJson();
		String hostAddress = null;
		String hostAd = null;
		List<String> addrs = new ArrayList<String>(); 
		try {
			//获取的是本服务器的IP地址 
           InetAddress address = InetAddress.getLocalHost();
           hostAddress = address.getHostAddress();
           
           //获取的是该网站的ip地址，比如我们所有的请求都通过nginx的，所以这里获取到的其实是nginx服务器的IP地
           InetAddress ad = InetAddress.getByName("d.m.gome.com.cn"); 
           hostAd = ad.getHostAddress();
           //根据主机名返回其可能的所有InetAddress对象
           InetAddress[] addresses = InetAddress.getAllByName("d.m.gome.com.cn"); 
           
           for(InetAddress addr : addresses){
        	   addrs.add(addr.toString());
//        	   System.out.println(addr);//www.baidu.com/14.215.177.38 
           } 
		
		} catch (UnknownHostException e) { 
			e.printStackTrace();
		}
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("hostIP: ", hostAddress);
		map.put("nginxIP: ", hostAd);
		map.put("allNginxIP: ", addrs);
		response.setData(map);
		return response;
	}

	/**
	 * 获取CMS配置首页功能Icon信息
	 * @return
	 */
	@RequestMapping(value = "/getCmsIconInfo", method = RequestMethod.GET)
	public ResponseJson getCmsIconInfo(@NotBlank(message = "{param.error}") @RequestParam("code") String code){
		ResponseJson response = new ResponseJson();
		
		response.setData(homeProductsManager.getHomePageSetInfoByCode(code));
		return response;
	}
	
	/**
	 * 用户参与同一个团的次数
	 * @param mutiCollectionId
	 * @param groupId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/userSameGroupRestrict", method = RequestMethod.GET)
	public ResponseJson userSameGroupRestrict(
			@NotNull(message = "{param.error}") @RequestParam("mutiCollectionId") Long mutiCollectionId,
			@RequestParam("groupId") Long groupId,
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == scn || scn.equalsIgnoreCase("")) {
			resMap.put("login", 0);			
			response.setData(resMap);
			return response;
		}
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		Long userId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		}else {
			resMap.put("login", 0);			
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		Boolean userRestrict = homeProductsManager.userSameGroupRestrict(userId, mutiCollectionId, groupId);
		resMap.put("userRestrict", userRestrict);
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 商详页图片楼层(来源渠道cookie里面没有就取url，url没有取默认)
	 * @param storeCode
	 * @param channel
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/productDetailsFloor", method = RequestMethod.GET)
	public ResponseJson productDetailsFloor(
			@CookieValue(value = "StoreCode", required = false) String StoreCode,
			@CookieValue(value = "Channel", required = false) String Channel,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@RequestParam(value = "channel", required = false) String channel
			)throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
		int chan = ChannelUtils.getCmsChannel(Channel, channel);
		
		Model model = homeProductsManager.getProductDetailsFloor(stoCode, pageCodeConfig.getProductDetailsPageCode(), chan);
		
		response.setData(model);
		return response;
	}

	

}
