package com.gome.meidian.grouporder.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import redis.Gcache;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

@Component
@ConfigurationProperties(prefix = "gome")
public class PropertiesConfig {
	
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	private String defaultStoreCode;// 默认门店，西坝河
	private String account; 		// 默认账号（操作删除接口）
	private String businessHours; 	// 默认营业时间
	private String promotionSite; 	// 促销站点
	
	// 素材分享logo使用
	Map<String, String> materialBrandLogo = new HashMap<String, String>(){
		{
			put("yongledianqi", "https://gfs15.gomein.net.cn/T1IUACBsZT1RCvBVdK.png");
		    put("sanxingdianqi", "https://gfs16.gomein.net.cn/T1VmLCB_JT1RCvBVdK.png");
		    put("heitianedianqi", "https://gfs14.gomein.net.cn/T15UKCBvbv1RCvBVdK.png");
		    put("guomeidianqi", "https://gfs16.gomein.net.cn/T1VmLCB_JT1RCvBVdK.png");
		    put("fengxingdianqi", "https://gfs15.gomein.net.cn/T1cUCCBTCv1RCvBVdK.png");
		    put("dazhongdianqi", "https://gfs14.gomein.net.cn/T1ucbCBmhv1RCvBVdK.png");
		    put("beifangdianqi", "https://gfs16.gomein.net.cn/T1VmLCB_JT1RCvBVdK.png");
		}
	};
	
	// 门店logo使用
	Map<String, String> storeBrandLogo = new HashMap<String, String>(){
		{
			put("yongledianqi", "https://cmsimg.meixincdn.com/images/2018/05/RGQLdo2MIJSPyl9TcrbFYiwjDzBnxH.png");
		    put("sanxingdianqi", "https://cmsimg.meixincdn.com/images/2018/05/vUYBPd413k7wZgy8mzifcA2HRXjTLV.png");
		    put("heitianedianqi", "https://cmsimg.meixincdn.com/images/2018/05/l9YNsmaVcdS54kUCAKWD6gGq0FuO3y.png");
		    put("guomeidianqi", "https://cmsimg.meixincdn.com/images/2018/05/zkesa64dpixmWJ23Mjr7hvqTUL8fPY.png");
		    put("fengxingdianqi", "https://cmsimg.meixincdn.com/images/2018/05/0blQWJtICYhaiF1RAPqmBXUwSorczM.png");
		    put("dazhongdianqi", "https://cmsimg.meixincdn.com/images/2018/05/zZwOKvion2VDYtScfET7UMLs4r83GP.png");
		    put("beifangdianqi", "https://cmsimg.meixincdn.com/images/2018/05/ZbPLmqiCxwDsM1VpH0nWS4Xou59erc.png");
		}
	};
	
	@Resource(name = "gcache")
    private Gcache gcache;
	@Resource(name = "gcacheNew")
    private Gcache gcacheNew;
    @Resource(name = "userCenter")
    private Gcache userCenter;
	    
    
	public String getDefaultAreaCode() {
		return defaultAreaCode;
	}
	public void setDefaultAreaCode(String defaultAreaCode) {
		this.defaultAreaCode = defaultAreaCode;
	}
	public String getDefaultStoreCode() {
		return defaultStoreCode;
	}
	public void setDefaultStoreCode(String defaultStoreCode) {
		this.defaultStoreCode = defaultStoreCode;
	}
	public Gcache getGcache() {
		return gcache;
	}
	public void setGcache(Gcache gcache) {
		this.gcache = gcache;
	}
	public Gcache getUserCenter() {
		return userCenter;
	}
	public void setUserCenter(Gcache userCenter) {
		this.userCenter = userCenter;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getBusinessHours() {
		return businessHours;
	}
	public void setBusinessHours(String businessHours) {
		this.businessHours = businessHours;
	}
	public Map<String, String> getMaterialBrandLogo() {
		return materialBrandLogo;
	}
	public void setMaterialBrandLogo(Map<String, String> materialBrandLogo) {
		this.materialBrandLogo = materialBrandLogo;
	}
	public Map<String, String> getStoreBrandLogo() {
		return storeBrandLogo;
	}
	public void setStoreBrandLogo(Map<String, String> storeBrandLogo) {
		this.storeBrandLogo = storeBrandLogo;
	}
	public String getPromotionSite() {
		return promotionSite;
	}
	public void setPromotionSite(String promotionSite) {
		this.promotionSite = promotionSite;
	}
	public Gcache getGcacheNew() {
		return gcacheNew;
	}
	public void setGcacheNew(Gcache gcacheNew) {
		this.gcacheNew = gcacheNew;
	}
	
	
}
