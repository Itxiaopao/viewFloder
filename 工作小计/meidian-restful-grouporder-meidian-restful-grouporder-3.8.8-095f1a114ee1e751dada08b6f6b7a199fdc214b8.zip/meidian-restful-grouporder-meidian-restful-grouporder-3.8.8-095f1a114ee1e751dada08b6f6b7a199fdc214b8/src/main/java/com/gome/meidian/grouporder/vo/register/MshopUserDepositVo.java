package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class MshopUserDepositVo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@NotNull(message = "{base.deposit.userId.notNull}")
	private Long userId;//当前用户userId
	@NotBlank(message = "{base.deposit.uniqueId.notBlank}")
	private String uniqueId;//当前用户uniqueId
	@NotBlank(message = "{base.deposit.image.notBlank}")
	private String image;//当前用户头像
	@NotBlank(message = "{base.deposit.nickName.notBlank}")
	private String nickName;//当前用户昵称
	@NotNull(message = "{base.deposit.inviteUserId.notNull}")
	private Long inviteUserId;//邀请人的userId
	private String channelSource;//渠道来源
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public Long getInviteUserId() {
		return inviteUserId;
	}
	public void setInviteUserId(Long inviteUserId) {
		this.inviteUserId = inviteUserId;
	}
	public String getChannelSource() {
		return channelSource;
	}
	public void setChannelSource(String channelSource) {
		this.channelSource = channelSource;
	}
	
	@Override
	public String toString() {
		return "MshopUserDepositVo [userId=" + userId + ", uniqueId=" + uniqueId + ", image=" + image + ", nickName="
				+ nickName + ", inviteUserId=" + inviteUserId + ", channelSource=" + channelSource + "]";
	}
	
}
