package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;
/**
 * 购买者信息
 * @author lishouxu-ds
 *
 */
public class UserInfoVo implements Serializable{
	private static final long serialVersionUID = -6282992309757987708L;
	private String purchaserId;//购买者id
    private String nickName;//昵称
    private String facePicUrl;//头像地址
	public String getPurchaserId() {
		return purchaserId;
	}
	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getFacePicUrl() {
		return facePicUrl;
	}
	public void setFacePicUrl(String facePicUrl) {
		this.facePicUrl = facePicUrl;
	}
    
}
