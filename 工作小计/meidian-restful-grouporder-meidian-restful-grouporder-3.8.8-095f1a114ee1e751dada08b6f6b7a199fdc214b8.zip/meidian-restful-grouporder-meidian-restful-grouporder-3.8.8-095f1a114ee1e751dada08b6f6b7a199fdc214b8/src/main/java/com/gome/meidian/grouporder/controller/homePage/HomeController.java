package com.gome.meidian.grouporder.controller.homePage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.aop.MDLoginAnnotation;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.homePageManager.HomePageManager;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.LogUtils;
import com.gome.meidian.grouporder.utils.thread.ThreadPoolUtils;
import com.gome.meidian.grouporder.vo.meidiancms.Model;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;


@RestController
@Validated
@RequestMapping("/home")
public class HomeController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private HomePageManager homePageManager;
	@Autowired
	private StoreManager storeManager;
	@Autowired
	private ThreadPoolUtils threadPoolUtils;
	
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认三级区域，朝阳，全国价
	@Value("${gome.defaultStoreCode}")
	private String defaultStoreCode; // 默认门店，西坝河

	@MDLoginAnnotation
	@MDStorePriceAnnotation
	@RequestMapping(value = "/v2/homePage", method = RequestMethod.GET)
	public ResponseJson homePage(
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@RequestParam(value = "channel", required = false) String channel,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);
		int chan = ChannelUtils.getCmsChannel(MeidianEnvironment.getChannel(), channel);
		
		// 1.处理楼层
		String areaCo = MeidianEnvironment.getKey("priceReqAreaCode");
		Integer ppi = MeidianEnvironment.getPPI();
		String userId = MeidianEnvironment.getUserId();
		// 主线程MDC传参给子线程
        Map<String, String> context = MDC.getCopyOfContextMap();
		// 获取线程池
		ExecutorService pool = threadPoolUtils.getCustomThreadPoolExecutor();
		Callable<Model> task = () -> {
			// 将父线程的MDC内容传给子线程
	        MDC.setContextMap(context);
	        MeidianEnvironment.putTraceId(MeidianEnvironment.getTraceId() + "_" + Thread.currentThread().getName());
			Model model = homePageManager.getHome(stoCode, areaCo, chan, 
					ua, ppi, userId == null ? null : Long.parseLong(userId));
			MeidianEnvironment.clear();
            return model;
        };
        // 开始执行子线程
        Future<Model> futureModel = pool.submit(task);
        // 主线程继续执行，此处不等待子线程。
        
        //2.处理门店
        Store storeInfo = null;
        if(null != MeidianEnvironment.getChannel() && MeidianEnvironment.getChannel().equals(GroupOrderConstants.CHANNEL_WAP)){
        	
        	String st = MeidianEnvironment.getKey("priceReqStoreCode");
        	String lon = MeidianEnvironment.getLongitude();
        	String la = MeidianEnvironment.getLaitude();
        	Callable<Store> store = () -> {
        		// 将父线程的MDC内容传给子线程
        		MDC.setContextMap(context);
        		MeidianEnvironment.putTraceId(MeidianEnvironment.getTraceId() + "_" + Thread.currentThread().getName());
        		Store sto = storeManager.getStoreInfo(st, 0, lon, la);
        		MeidianEnvironment.clear();
        		return sto;
        	};
        	// 开始执行子线程
        	Future<Store> futureStore = pool.submit(store);
        	// 主线程继续执行，此处不等待子线程。
        	
        	try {
				storeInfo = futureStore.get(1000 * 2, TimeUnit.MILLISECONDS);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			} catch (TimeoutException e) {
				e.printStackTrace();
				// 处理超时的线程,立即中断此线程。
				LogUtils.logError(HomeController.class, "getStoreInfo timeout");
				futureStore.cancel(true);
			}
        }
        
        Model model = null;
		try {
			//主线程其他工作完毕,等待子线程的结束, 调用future.get()系列的方法即可。
			model = futureModel.get(1000 * 5, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			e.printStackTrace();
		} catch (TimeoutException e) {
			e.printStackTrace();
			// 处理超时的线程,立即中断此线程。
			LogUtils.logError(HomeController.class, "getHome timeout");
			futureModel.cancel(true);
		}
		
		if(null != model){
			model.setStore(storeInfo);
		}
		
		response.setData(model);
		return response;
	}
    
    
}
