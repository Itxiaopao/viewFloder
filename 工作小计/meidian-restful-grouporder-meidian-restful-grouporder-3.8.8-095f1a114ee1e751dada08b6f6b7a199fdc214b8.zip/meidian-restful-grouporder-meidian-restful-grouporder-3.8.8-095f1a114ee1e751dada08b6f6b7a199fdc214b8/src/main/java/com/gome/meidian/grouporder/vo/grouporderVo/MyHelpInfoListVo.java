package com.gome.meidian.grouporder.vo.grouporderVo;


import java.io.Serializable;
import java.util.List;

/**
 * 我的助力信息VO
 * @author shigaopeng-ds
 */
public class MyHelpInfoListVo implements Serializable {

    private static final long serialVersionUID = -5290610523647386248L;
    private List<MyHelpInfoVo> myHelpList;  // 我的助力列表信息

    public List<MyHelpInfoVo> getMyHelpList() {
        return myHelpList;
    }

    public void setMyHelpList(List<MyHelpInfoVo> myHelpList) {
        this.myHelpList = myHelpList;
    }
}