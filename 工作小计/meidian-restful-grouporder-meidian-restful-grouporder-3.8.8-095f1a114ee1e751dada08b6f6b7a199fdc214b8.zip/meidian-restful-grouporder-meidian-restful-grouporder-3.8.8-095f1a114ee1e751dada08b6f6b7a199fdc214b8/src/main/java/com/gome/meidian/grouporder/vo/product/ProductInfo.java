package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;
import java.util.Date;

/**
 * 组团列表商品信息
 * @author shichangjian
 *
 */
public class ProductInfo implements Serializable{

	private static final long serialVersionUID = -497171702970616945L;


	private String productId; 		// 商品productID
	private String skuId;			// 商品默认skuId
	private String skuNo;			// 商品默认skuNo
	private String name; 			// 商品名称
	private String shopId;			// 店铺id
	private String productImage; 	// 商品图
	private Integer productTag; 	// 自联营标示  1自营 2联营;
	private String price;			// 销售价
	private Integer productStatus;	// 商品状态  1上架  -1 下架
	private String meidianPrice;	// 美店定价
	private String priceKey;		// 下单带着，区分美店价


	private Integer helpMinTotalNum;// 助力最低总人数
	private Integer helpMinNewNum;// 助力最低新用户人数
	private String attendFixMoney; //参与者每人固定国美币（元）
	private String initialFixMoney; //开团者返利国美币（元）
	private Integer helpAllow; //是否允许助力 0:不允许,1:允许 （默认0）
	private String priceType;  //价格类型
	public ProductInfo() {
		super();
	}
	public ProductInfo(String productId, String skuId, String skuNo, 
			String name, String shopId, String productImage,
			Integer productTag, String price, Integer productStatus, 
			String meidianPrice, String priceKey) {
		super();
		this.productId = productId;
		this.skuId = skuId;
		this.skuNo = skuNo;
		this.name = name;
		this.shopId = shopId;
		this.productImage = productImage;
		this.productTag = productTag;
		this.price = price;
		this.productStatus = productStatus;
		this.meidianPrice = meidianPrice;
		this.priceKey = priceKey;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Integer getProductTag() {
		return productTag;
	}
	public void setProductTag(Integer productTag) {
		this.productTag = productTag;
	}
	public Integer getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(Integer productStatus) {
		this.productStatus = productStatus;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getMeidianPrice() {
		return meidianPrice;
	}
	public void setMeidianPrice(String meidianPrice) {
		this.meidianPrice = meidianPrice;
	}

	public String getPriceKey() {
		return priceKey;
	}
	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}

	public String getSkuNo() {
		return skuNo;
	}

	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public Integer getHelpMinTotalNum() {
		return helpMinTotalNum;
	}
	public void setHelpMinTotalNum(Integer helpMinTotalNum) {
		this.helpMinTotalNum = helpMinTotalNum;
	}
	public Integer getHelpMinNewNum() {
		return helpMinNewNum;
	}
	public void setHelpMinNewNum(Integer helpMinNewNum) {
		this.helpMinNewNum = helpMinNewNum;
	}
	public String getAttendFixMoney() {
		return attendFixMoney;
	}
	public void setAttendFixMoney(String attendFixMoney) {
		this.attendFixMoney = attendFixMoney;
	}
	public String getInitialFixMoney() {
		return initialFixMoney;
	}
	public void setInitialFixMoney(String initialFixMoney) {
		this.initialFixMoney = initialFixMoney;
	}
	public Integer getHelpAllow() {
		return helpAllow;
	}
	public void setHelpAllow(Integer helpAllow) {
		this.helpAllow = helpAllow;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

}
