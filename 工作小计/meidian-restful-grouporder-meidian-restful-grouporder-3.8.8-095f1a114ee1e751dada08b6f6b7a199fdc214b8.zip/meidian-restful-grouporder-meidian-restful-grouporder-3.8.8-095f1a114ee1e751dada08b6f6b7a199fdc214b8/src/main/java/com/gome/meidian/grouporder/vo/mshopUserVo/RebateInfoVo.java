package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;
import java.util.Date;

import cn.com.gome.rebate.model.buyer.RebateUserDetailDto;
/**
 * 收益信息列表实体
 * @author lishouxu-ds
 *
 */
public class RebateInfoVo implements Serializable {
	private static final long serialVersionUID = -7785223137118618145L;
	private UserInfoVo purchaser;//购买者信息
	private SkuInfoVo skuInfo;//sku商品信息
	private UserInfoVo invitee;//被邀请者信息
	private ShopInfoVo shopInfo;//店铺信息
    private String purchaseTimeStr;	//格式化下单时间	
    private String invalidTimeStr;	//格式化失效时间
	private String rebateTimeStr;//格式化返利到账时间
	
	private String purchaserId;//购买者id
	private int rebateType;//返利类型
	private Long amount;//返利金额 分
	private int invalidReasonType;//失效原因类型(1:订单取消,2:退货入库,3:换货拒收)
	private int businessType;//业务类型(1:国美+订单,2:国美在线订单,3:邀请好友,4:邀请商家,5:广告,6:游戏,7:电影
	private String skuId;
	private String shopId;//店铺id
	private String inviteeId;//被邀请者id
	private String title;//标题
	private String adOriginal;//广告来源
	private Integer level;//	所在分享级别，默认0
	private String microId;//美店id
	private Long id;//主键id
	private Integer flag;//是否有返利详情页标识，是否有返利链条标识（1、代表有返利链条 0、代表无返利链条）
	

	public String getPurchaseTimeStr() {
		return purchaseTimeStr;
	}
	public void setPurchaseTimeStr(String purchaseTimeStr) {
		this.purchaseTimeStr = purchaseTimeStr;
	}
	public String getInvalidTimeStr() {
		return invalidTimeStr;
	}
	public void setInvalidTimeStr(String invalidTimeStr) {
		this.invalidTimeStr = invalidTimeStr;
	}
	public String getRebateTimeStr() {
		return rebateTimeStr;
	}
	public void setRebateTimeStr(String rebateTimeStr) {
		this.rebateTimeStr = rebateTimeStr;
	}
	public UserInfoVo getPurchaser() {
		return purchaser;
	}
	public void setPurchaser(UserInfoVo purchaser) {
		this.purchaser = purchaser;
	}
	public SkuInfoVo getSkuInfo() {
		return skuInfo;
	}
	public void setSkuInfo(SkuInfoVo skuInfo) {
		this.skuInfo = skuInfo;
	}
	public UserInfoVo getInvitee() {
		return invitee;
	}
	public void setInvitee(UserInfoVo invitee) {
		this.invitee = invitee;
	}
	public ShopInfoVo getShopInfo() {
		return shopInfo;
	}
	public void setShopInfo(ShopInfoVo shopInfo) {
		this.shopInfo = shopInfo;
	}
	public String getPurchaserId() {
		return purchaserId;
	}
	public void setPurchaserId(String purchaserId) {
		this.purchaserId = purchaserId;
	}
	public int getRebateType() {
		return rebateType;
	}
	public void setRebateType(int rebateType) {
		this.rebateType = rebateType;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public int getInvalidReasonType() {
		return invalidReasonType;
	}
	public void setInvalidReasonType(int invalidReasonType) {
		this.invalidReasonType = invalidReasonType;
	}
	public int getBusinessType() {
		return businessType;
	}
	public void setBusinessType(int businessType) {
		this.businessType = businessType;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getInviteeId() {
		return inviteeId;
	}
	public void setInviteeId(String inviteeId) {
		this.inviteeId = inviteeId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAdOriginal() {
		return adOriginal;
	}
	public void setAdOriginal(String adOriginal) {
		this.adOriginal = adOriginal;
	}
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public String getMicroId() {
		return microId;
	}
	public void setMicroId(String microId) {
		this.microId = microId;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	
	

}
