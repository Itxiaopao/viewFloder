package com.gome.meidian.grouporder.vo.collectFlow;

import java.io.Serializable;
import java.util.Date;

public class FlowCoupon implements Serializable{

	private static final long serialVersionUID = -8406896727800006328L;

	private String flowActivityId;	// 集客活动id
	private String flowName;		// 集客名称
	private Date stateTime;			// 集客劵领取时间
	private byte groupStatus;		// 是否参与集客团0：没，1：有
	private String phone;			// 被集客者手机号
	
	public FlowCoupon() {
		super();
	}
	public FlowCoupon(String flowActivityId, String flowName, Date stateTime, 
						byte groupStatus, String phone) {
		super();
		this.flowActivityId = flowActivityId;
		this.flowName = flowName;
		this.stateTime = stateTime;
		this.groupStatus = groupStatus;
		this.phone = phone;
	}
	public String getFlowActivityId() {
		return flowActivityId;
	}
	public void setFlowActivityId(String flowActivityId) {
		this.flowActivityId = flowActivityId;
	}
	public String getFlowName() {
		return flowName;
	}
	public void setFlowName(String flowName) {
		this.flowName = flowName;
	}
	public Date getStateTime() {
		return stateTime;
	}
	public void setStateTime(Date stateTime) {
		this.stateTime = stateTime;
	}
	public byte getGroupStatus() {
		return groupStatus;
	}
	public void setGroupStatus(byte groupStatus) {
		this.groupStatus = groupStatus;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
	
}
