package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.Map;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.grouporder.manager.mshopUserManager.GuestManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

import redis.Gcache;

@RestController
@Validated
@RequestMapping("/channel")
public class ChannelController {
	
	@Autowired
	private GuestManager guestManager;
	@Resource(name = "gcache")
    private Gcache gcache;
	/**
	 * 完整信息
	 * 
	 * @param scn
	 * @CookieValue(value = "SCN", required = false)
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/myMshopOwner")
	public Object myMshopOwner(@CookieValue(value = "SCN", required = false) String scn) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "ChannelController:" + "myMshopOwner:" + currentUser ;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.myChannelMshopOwner(currentUser);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		
		return responseJson;
	}

	/**
	 * 渠道 分页
	 * @CookieValue(value = "SCN", required = false)
	 * @param scn
	 * @return
	 */
	@GetMapping(value = "/myPerformances")
	public Object myPerformances(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("pageNo") int pageNo) {
		String currentUser = guestManager.getUserIdByScn(scn);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		responseJson = guestManager.myChannelPerformances(currentUser, pageNo);
		return responseJson;
	}


}
