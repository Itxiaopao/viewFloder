package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import lombok.Data;

/**
 * @author limenghui
 * @create 2019-12-10 11:52
 */
@Data
public class IcSmDqlStaffVo implements Serializable {
    private static final long serialVersionUID = -3152492265776869630L;
    /**
     * 用户ID
     */
    @NotNull(message = "userId非空")
    private Long userId;
    /**
     * 0离职，1在职，2直接换绑
     */
    @NotNull(message = "status非空")
    private Integer status;
    /**
     * 门店编码
     */
    private String storeCode;
    /**
     * 员工编码
     */
    private String staffCode;
    /**
     * 销售组织
     */
    private String orgCode;
    /**
     * 美店ID
     */
    private Long mid;
    /**
     * 员工姓名
     */
    private String staffName;
    /**
     * 岗位编码
     */
    private String staffPost;
    /**
     * 岗位名称
     */
    private String staffPostName;
    /**
     * 门店名称
     */
    private String storeName;
    /**
     * 品牌编码
     */
    private String  brandCode;

}
