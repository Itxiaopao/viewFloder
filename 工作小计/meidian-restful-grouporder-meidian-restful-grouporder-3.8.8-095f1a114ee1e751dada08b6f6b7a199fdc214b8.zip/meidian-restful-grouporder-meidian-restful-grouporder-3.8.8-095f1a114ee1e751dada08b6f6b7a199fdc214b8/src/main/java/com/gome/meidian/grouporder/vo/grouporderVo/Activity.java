package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

/**
 * 活动信息
 * @author shichangjian
 *
 */
public class Activity implements Serializable{

	private static final long serialVersionUID = -93868214875632454L;

	private Long activityId;				// 活动id
	private int maxDiscountNeedPeopleNum;	// 最大折扣需要的人数
	private Double rebateAmount;			// 折扣返，元
	private Integer buyNumber; 				// 限购件数
	private Float maxDiscount; 				// 最大折扣
	
	
	
	public Activity() {
		super();
	}

	public Activity(Long activityId, int maxDiscountNeedPeopleNum, Double rebateAmount, 
			Integer buyNumber) {
		super();
		this.activityId = activityId;
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
		this.rebateAmount = rebateAmount;
		this.buyNumber = buyNumber;
	}

	public Long getActivityId() {
		return activityId;
	}

	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public Integer getBuyNumber() {
		return buyNumber;
	}

	public void setBuyNumber(Integer buyNumber) {
		this.buyNumber = buyNumber;
	}

	public int getMaxDiscountNeedPeopleNum() {
		return maxDiscountNeedPeopleNum;
	}

	public void setMaxDiscountNeedPeopleNum(int maxDiscountNeedPeopleNum) {
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
	}

	public Double getRebateAmount() {
		return rebateAmount;
	}

	public void setRebateAmount(Double rebateAmount) {
		this.rebateAmount = rebateAmount;
	}

	public Float getMaxDiscount() {
		return maxDiscount;
	}

	public void setMaxDiscount(Float maxDiscount) {
		this.maxDiscount = maxDiscount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
