package com.gome.meidian.grouporder.vo.carveUp.carveUpDetail;

import java.util.List;

import com.gome.meidian.grouporder.vo.Coupon;
import com.gomeplus.bs.interfaces.gorder.vo.carve.CarveRankAwardVo;

public class CarveUpDetailRankVo extends CarveUpDetailBaseVo {

	private static final long serialVersionUID = -4758254157743221988L;

//	private Double rankBondTotalNum; //排名奖励劵面值总和（元）
	private Double leaderMoney;//团长独享金额（根据瓜分比例和总额计算结果）
//	private List<Coupon> rankCoupon;  //排名团券信息
	private List<CarveRankAwardVo> carveRankAwardList;//排名团奖励配置
	private Integer rankingNum;//榜单排名数（已有多少个团进入排行）
	private Boolean activitiIsLimit;//当前活动是否达到人数上限,true上限
	private Integer rankActivityMinPeopleNum; //活动最少参与人数
	private Integer activityAttendNum;//当前活动参与人数
	private Integer rankActivityMaxPeopleNum; //排名团活动最多参与人数
	
//	public Double getRankBondTotalNum() {
//		return rankBondTotalNum;
//	}
//	public void setRankBondTotalNum(Double rankBondTotalNum) {
//		this.rankBondTotalNum = rankBondTotalNum;
//	}
	public Double getLeaderMoney() {
		return leaderMoney;
	}
	public void setLeaderMoney(Double leaderMoney) {
		this.leaderMoney = leaderMoney;
	}
//	public List<Coupon> getRankCoupon() {
//		return rankCoupon;
//	}
//	public void setRankCoupon(List<Coupon> rankCoupon) {
//		this.rankCoupon = rankCoupon;
//	}
	public List<CarveRankAwardVo> getCarveRankAwardList() {
		return carveRankAwardList;
	}
	public void setCarveRankAwardList(List<CarveRankAwardVo> carveRankAwardList) {
		this.carveRankAwardList = carveRankAwardList;
	}
	public Boolean getActivitiIsLimit() {
		return activitiIsLimit;
	}
	public void setActivitiIsLimit(Boolean activitiIsLimit) {
		this.activitiIsLimit = activitiIsLimit;
	}
	public Integer getRankingNum() {
		return rankingNum;
	}
	public void setRankingNum(Integer rankingNum) {
		this.rankingNum = rankingNum;
	}
	public Integer getRankActivityMinPeopleNum() {
		return rankActivityMinPeopleNum;
	}
	public void setRankActivityMinPeopleNum(Integer rankActivityMinPeopleNum) {
		this.rankActivityMinPeopleNum = rankActivityMinPeopleNum;
	}
	public Integer getActivityAttendNum() {
		return activityAttendNum;
	}
	public void setActivityAttendNum(Integer activityAttendNum) {
		this.activityAttendNum = activityAttendNum;
	}
	public Integer getRankActivityMaxPeopleNum() {
		return rankActivityMaxPeopleNum;
	}
	public void setRankActivityMaxPeopleNum(Integer rankActivityMaxPeopleNum) {
		this.rankActivityMaxPeopleNum = rankActivityMaxPeopleNum;
	}
	
}
