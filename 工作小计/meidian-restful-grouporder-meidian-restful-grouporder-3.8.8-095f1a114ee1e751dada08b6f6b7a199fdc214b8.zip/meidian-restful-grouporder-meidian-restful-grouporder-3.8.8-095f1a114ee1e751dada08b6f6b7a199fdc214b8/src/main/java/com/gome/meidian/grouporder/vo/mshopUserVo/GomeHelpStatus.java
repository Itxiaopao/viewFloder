package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.util.Map;
import java.util.Optional;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * @author limenghui
 * @create 2020-02-07 19:33
 */
@Getter
@NoArgsConstructor
@AllArgsConstructor
public enum GomeHelpStatus {
    REGISTER(1, "已注册"), APPFIRST(2, "app首单"), CANCEL(3, "失效");
    private int code;
    private String message;

    private static final Map<Integer, GomeHelpStatus> INDEX = Maps.newHashMap();

    static {
        for (GomeHelpStatus status : GomeHelpStatus.values()) {
            INDEX.put(status.getCode(), status);
        }
    }

    public static Optional<GomeHelpStatus> codeOf(int code) {
        return Optional.ofNullable(INDEX.get(code));
    }

}
