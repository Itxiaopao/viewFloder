package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.product.ProductInfo;

public class HomeProductActivity implements Serializable{

	private static final long serialVersionUID = 2846445190609938202L;

	private ProductInfo productInfo;			// 商品信息
	private HomePageActivity homePageActivity;	// 活动信息
	
	public ProductInfo getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(ProductInfo productInfo) {
		this.productInfo = productInfo;
	}
	public HomePageActivity getHomePageActivity() {
		return homePageActivity;
	}
	public void setHomePageActivity(HomePageActivity homePageActivity) {
		this.homePageActivity = homePageActivity;
	}
	
	
	
}
