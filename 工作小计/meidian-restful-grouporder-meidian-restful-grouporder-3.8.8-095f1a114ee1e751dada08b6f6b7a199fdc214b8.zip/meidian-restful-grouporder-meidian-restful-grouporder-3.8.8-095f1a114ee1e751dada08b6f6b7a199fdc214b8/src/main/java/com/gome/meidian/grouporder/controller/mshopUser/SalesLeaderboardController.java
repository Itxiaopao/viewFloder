package com.gome.meidian.grouporder.controller.mshopUser;

import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.SalesLeaderboardManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.sso.model.UserInfoCache;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * @author limenghui-ds
 * @create 2019-11-27 10:59
 * 销售排行榜
 */
@RestController
@Validated
@RequestMapping("/sales")
public class SalesLeaderboardController {
    @Autowired
    private GroupOrderManager groupOrderManager;
    @Autowired
    private SalesLeaderboardManager salesLeaderboardManager;


    /**
     * 销售排行榜列表
     * @param scn
     * @param pageNo
     * @return
     */
    @GetMapping(value = "/salesLeaderboardList")
    public Object salesLeaderboardList(@CookieValue(value = "SCN", required = false) String scn,
            @NotNull(message = "{param.error}") @RequestParam("pageNo") int pageNo) throws ServiceException {
        // 验证是否登陆，未登陆强制登陆
        String currentUser = getCurrentUserBySCN(scn);
        ResponseJson<Map<String, Object>> responseJson = salesLeaderboardManager.salesLeaderboardList(currentUser,pageNo);
        return responseJson;
    }

    /**
     * 活动开始时间
     * @param scn
     * @return
     */
    @GetMapping(value = "/getActivityStartTime")
    public Object getActivityStartTime(@CookieValue(value = "SCN", required = false) String scn) throws ServiceException {
        // 验证是否登陆，未登陆强制登陆
        String currentUser = getCurrentUserBySCN(scn);
        return salesLeaderboardManager.getActivityStartTime(currentUser);
    }

    private String getCurrentUserBySCN(String scn) throws ServiceException {
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        String currentUser = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            currentUser = userInfo.getId();
        } else {
            throw new ServiceException("group.operation.notLoggin");
        }
        return currentUser;

    }


}
