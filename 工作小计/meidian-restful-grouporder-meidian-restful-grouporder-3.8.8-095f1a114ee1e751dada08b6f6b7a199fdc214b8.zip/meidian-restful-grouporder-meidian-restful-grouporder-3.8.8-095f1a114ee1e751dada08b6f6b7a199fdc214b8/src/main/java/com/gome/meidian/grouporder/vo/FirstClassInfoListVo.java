package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FirstClassInfoListVo implements Serializable {

	private static final long serialVersionUID = -2630704040363641615L;
	private List<FirstClassInfoVo> firstClassifications = new ArrayList<>(); //一级分类列表列表
	
	
	public FirstClassInfoListVo() {
		super();
	}
	public FirstClassInfoListVo(List<FirstClassInfoVo> firstClassifications) {
		super();
		this.firstClassifications = firstClassifications;
	}
	public List<FirstClassInfoVo> getFirstClassifications() {
		return firstClassifications;
	}
	public void setFirstClassifications(List<FirstClassInfoVo> firstClassifications) {
		this.firstClassifications = firstClassifications;
	}
	
	
}
