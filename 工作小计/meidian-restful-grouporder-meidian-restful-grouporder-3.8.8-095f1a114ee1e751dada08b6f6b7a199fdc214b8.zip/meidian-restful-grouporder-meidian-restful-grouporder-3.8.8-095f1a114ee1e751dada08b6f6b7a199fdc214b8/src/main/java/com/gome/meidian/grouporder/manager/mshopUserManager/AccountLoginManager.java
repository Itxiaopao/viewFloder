package com.gome.meidian.grouporder.manager.mshopUserManager;

import com.alibaba.dubbo.config.annotation.Reference;
import com.gome.architect.risk.dto.RequestV2;
import com.gome.loom.model.TpModel;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.common.MeidianMemberService;
import com.gome.meidian.grouporder.common.MeidianRiskService;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.LoginRecordThread;
import com.gome.meidian.grouporder.utils.ThreadPoolManager;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.AccountLoginVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.CommonVariableVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.QuickLoginVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.meidian.user.manager.IUserRelationManager;
import com.gome.meidian.user.manager.IUserRoleManager;
import com.gome.memberCore.lang.MapResult;
import com.gome.userCenter.facade.login.IUserLoginFacade;
import com.gome.userCenter.facade.userservice.othergroup.ICSCUserFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UserInfo;
import com.gome.userCenter.model.UserLoginResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: AccountLoginManager
 * @ProjectName meidian-restful-grouporder
 * @Description: TODO
 * @date 2018/11/29 11:46
 */
@Slf4j
@Service
public class AccountLoginManager {

    @Autowired
    private IUserLoginFacade iUserLoginFacade;
    @Autowired
    private ICSCUserFacade icscUserFacade;
    @Autowired
    private MeidianRiskService meidianRiskService;
    @Autowired
    private MeidianMemberService meidianMemberService;

    @Resource(name = "userCenter")
    private Gcache userCenter;

    @Resource(name = "venusVshop")
    private Gcache venusVshopGcache;

    @Autowired
    private IUserInfoManager iUserInfoManager;

    @Autowired
    private IUserRoleManager iUserRoleManager;
    @Autowired
    private WechatLoginManager wechatLoginManager;


    @Value("${cookie.path}")
    private String path;

    @Value("${cookie.domain}")
    private String domain;

    @Value("${cookie.time}")
    private int time;



    /**
     * WAP站账号密码登录
     *
     * @param accountLoginVo
     * @param requestParams  初始化信息
     * @param map            扩展字段
     * @return
     */
    public ResponseJson doLogin(AccountLoginVo accountLoginVo, RequestParams requestParams, Map<String, Object> map, RequestV2 requestV2, HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResponseJson responseJson = new ResponseJson();
//        riskLogin(requestV2, request);
        String SCN= null;
        String id= null;
        UserLoginResult<UserInfo> userInfoUserLoginResult=null;
        try {
             userInfoUserLoginResult = iUserLoginFacade.doLogin(accountLoginVo.getLogin(), accountLoginVo.getPassword(), requestParams, map);
        }catch(Exception e){
            log.info("AccountLoginManager-iUserLoginFacade-doLogin:{} error:{}",userInfoUserLoginResult,e.getMessage());

        }
        if (userInfoUserLoginResult != null && userInfoUserLoginResult.isSuccess()) {
            Map<String, Object> resultMap = new HashMap<>();
            if (userInfoUserLoginResult.getBuessObj() != null) {
                resultMap.put("userInfo", userInfoUserLoginResult.getBuessObj());
                id = userInfoUserLoginResult.getBuessObj().getId();
            }
            if(null != userInfoUserLoginResult.getExtraInfoMap() && userInfoUserLoginResult.getExtraInfoMap().size()>0){
                SCN= (String)userInfoUserLoginResult.getExtraInfoMap().get("SCN");
                try {
                    SCN=URLEncoder.encode(SCN,"UTF-8");
                } catch (UnsupportedEncodingException e) {
                    log.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",SCN,e);
                }
            }
            resultMap.put("isMobileActived", userInfoUserLoginResult.getExtraInfoMap().get("isMobileActived"));
            resultMap.put("identifyLevel", userInfoUserLoginResult.getExtraInfoMap().get("identifyLevel"));
            resultMap.put("SCN", SCN);
            
            AuthencationVo userInfo = wechatLoginManager.getAutencationVo(id);
            resultMap.put("userDetails", userInfo);
            //写COOKIE
            if(StringUtils.isNotBlank(SCN)){
                CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
                CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID, id,path,domain,time);
            }
            //添加用户记录
            if(null != userInfoUserLoginResult.getBuessObj().getId()){
                LoginRecordThread thread= new LoginRecordThread(userInfoUserLoginResult.getBuessObj().getId(), accountLoginVo.getCreateType(),"2", userCenter, venusVshopGcache, iUserInfoManager, iUserRoleManager);
                ThreadPoolManager.newInstance().addExecuteTask(thread);
            }

            responseJson.setData(resultMap);
            responseJson.setCode(0);
            responseJson.setMsg(userInfoUserLoginResult.getMessage());
        } else if (userInfoUserLoginResult != null && !userInfoUserLoginResult.isSuccess()) {
            responseJson.setCode(1);
            responseJson.setMsg(userInfoUserLoginResult.getMessage());
            Map<String, Object> resultMap = new HashMap<>();
            if (userInfoUserLoginResult.getBuessObj() != null)
                resultMap.put("userInfo", userInfoUserLoginResult.getBuessObj());
            if(null != userInfoUserLoginResult.getExtraInfoMap() && userInfoUserLoginResult.getExtraInfoMap().size()>0){
                SCN= (String)userInfoUserLoginResult.getExtraInfoMap().get("SCN");
                if(null!=SCN){
                    try {
                        SCN=URLEncoder.encode(SCN,"UTF-8");
                    } catch (UnsupportedEncodingException e) {
                        log.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",SCN,e);
                    }
                }
            }
            resultMap.put("isMobileActived", userInfoUserLoginResult.getExtraInfoMap().get("isMobileActived"));
            resultMap.put("identifyLevel", userInfoUserLoginResult.getExtraInfoMap().get("identifyLevel"));
            resultMap.put("SCN", SCN);
            if(StringUtils.isNotEmpty(SCN)){
                //添加用户记录
                if(null != userInfoUserLoginResult.getBuessObj().getId()){
                    LoginRecordThread thread= new LoginRecordThread(userInfoUserLoginResult.getBuessObj().getId(), accountLoginVo.getCreateType(),"2", userCenter, venusVshopGcache, iUserInfoManager, iUserRoleManager);
                    ThreadPoolManager.newInstance().addExecuteTask(thread);
                }
            }
            //写COOKIE
            if(StringUtils.isNotBlank(SCN)){
                CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
                CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID, id,path,domain,time);
            }
            responseJson.setData(resultMap);
        } else {
            responseJson.setCode(-1);
            responseJson.setMsg("账号登录请求失败!");
        }
        return responseJson;
    }

    /**
     * 修改手机号
     *
     * @param accountLoginVo
     * @return
     */
    public ResponseJson mobileActivated(AccountLoginVo accountLoginVo) throws Exception{
        ResponseJson responseJsons = new ResponseJson();
        MapResult<Integer> integerMapResult = null;
        if ("Y".equals(accountLoginVo.getIsMobileActivated())) {//激活手机号
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("companyName", CommonVariableVo.companyName);
            integerMapResult = icscUserFacade.updateMobileAndIsActivated(accountLoginVo.getUserId(), accountLoginVo.getNewMobile(), accountLoginVo.getIsMobileActivated(), CommonVariableVo.invokeFrom, paramMap);
        } else if ("N".equals(accountLoginVo.getIsMobileActivated())) {//释放手机
            Map<String, Object> paramMap = new HashMap<>();
            paramMap.put("companyName", CommonVariableVo.companyName);
            integerMapResult = icscUserFacade.updateMobileAndIsActivated(accountLoginVo.getUserId(), null, accountLoginVo.getIsMobileActivated(), CommonVariableVo.invokeFrom, paramMap);
        }
        if (integerMapResult.isSuccess()) {
            responseJsons.setCode(0);
            responseJsons.setMsg("手机号激活成功！");
        } else {
            responseJsons.setCode(integerMapResult.getCode());
            responseJsons.setMsg(integerMapResult.getMessage());
        }
        return responseJsons;
    }


    /**
     *  风控
     * @param requestV2
     * @param request
     */
    public void riskLogin(RequestV2 requestV2, HttpServletRequest request) throws MeidianException {
        meidianRiskService.predict(requestV2, request);
    }


    /**
     *  滑块验证
     * @param token
     */
    public ResponseJson sliderVal(String token) throws Exception{
        return meidianRiskService.sliderVal(token);
    }

    /**
     *  发送短信验证码
     * @param phone
     */
    public boolean sendSms(String phone, HttpServletRequest request) throws MeidianException{
        //短信风控
        RequestV2 requestV2 = new RequestV2();
        requestV2.setBizNo(CommonVariableVo.sms_bind_bizNo);//美店短信防刷风控 完善手机号
        requestV2.setUserId(phone);
        requestV2.setPhone(phone);
        meidianRiskService.predict(requestV2,request);
        TpModel tpModel = new TpModel(CommonVariableVo.BusinessName_perfect, CommonVariableVo.BusinessId_perfect);
        tpModel.setPhone(phone);
        return meidianMemberService.sendSms(tpModel);
    }
    /**
     *  校验短信验证码
     * @param accountLoginVo
     */
    public boolean checkCode(AccountLoginVo accountLoginVo) throws MeidianException{
        return meidianMemberService.checkVcode(CommonVariableVo.BusinessName_perfect, accountLoginVo.getPhone(), accountLoginVo.getCode(), Boolean.TRUE);
    }

    /**
     * 短信防刷
     * @param accountLoginVo
     * @param request
     * @throws MeidianException
     */
    public void smsPredict(AccountLoginVo accountLoginVo, HttpServletRequest request) throws MeidianException{
        //短信风控
        RequestV2 requestV2 = new RequestV2();
        requestV2.setBizNo(CommonVariableVo.sms_login_bizNo);//美店短信防刷风控
        requestV2.setUserId(accountLoginVo.getUserId());
        requestV2.setPhone(accountLoginVo.getPhone());
        meidianRiskService.predict(requestV2,request);
    }
}
