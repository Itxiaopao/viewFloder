package com.gome.meidian.grouporder.vo.carveUp.myCarveUpList;

import java.io.Serializable;
import java.util.Date;

/**
 * 瓜分团信息
 */
public class CarveUpGroupVo implements Serializable {

	private static final long serialVersionUID = 1385728423172398128L;

	private Long carveGroupId; //团id
	private Long carveId; //瓜分活动id
	private Long userId; //瓜分团成员userID
	private Long headerUserId; //瓜分团长userId
	private Long startTime; //开始时间
	private Long endTime; //结束时间
//	private Integer status; //瓜分团状态： 0：初始值；1：已开始；2：已结束
	private Integer currentMemberNum; //当前成员人数
	private Integer isSucess; //是否达标 0 未达标  1 已达标（判断条件--新人数达到标准且总人数达到标准）
	private Integer carveGroupType; //瓜分团类型：1：基础团，2：排名团--奖励定额，3：排名团--奖励瓜分
	private Integer oldUserNum; //老用户参与团人数
	private Integer newUserNum; //新用户参与团人数
	private Integer carveBaseNum; //达标人数',--团
	private Integer carveMinNewNum; //最低新用户人数
	private Integer carveOrderStatus;//瓜分团订单当前状态 1：进行中，2：已完成，3：已结束
	private Long surplusTime;//团结束还有多长时间 单位 秒
	private String activityImageUrl; //活动图标
	public Long getCarveGroupId() {
		return carveGroupId;
	}
	public void setCarveGroupId(Long carveGroupId) {
		this.carveGroupId = carveGroupId;
	}
	public Long getCarveId() {
		return carveId;
	}
	public void setCarveId(Long carveId) {
		this.carveId = carveId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}
	public Long getEndTime() {
		return endTime;
	}
	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}
//	public Integer getStatus() {
//		return status;
//	}
//	public void setStatus(Integer status) {
//		this.status = status;
//	}
	public Integer getCurrentMemberNum() {
		return currentMemberNum;
	}
	public void setCurrentMemberNum(Integer currentMemberNum) {
		this.currentMemberNum = currentMemberNum;
	}
	public Integer getIsSucess() {
		return isSucess;
	}
	public void setIsSucess(Integer isSucess) {
		this.isSucess = isSucess;
	}
	public Integer getCarveGroupType() {
		return carveGroupType;
	}
	public void setCarveGroupType(Integer carveGroupType) {
		this.carveGroupType = carveGroupType;
	}
	public Integer getOldUserNum() {
		return oldUserNum;
	}
	public void setOldUserNum(Integer oldUserNum) {
		this.oldUserNum = oldUserNum;
	}
	public Integer getNewUserNum() {
		return newUserNum;
	}
	public void setNewUserNum(Integer newUserNum) {
		this.newUserNum = newUserNum;
	}
	public Integer getCarveBaseNum() {
		return carveBaseNum;
	}
	public void setCarveBaseNum(Integer carveBaseNum) {
		this.carveBaseNum = carveBaseNum;
	}

	public Integer getCarveOrderStatus() {
		return carveOrderStatus;
	}

	public void setCarveOrderStatus(Integer carveOrderStatus) {
		this.carveOrderStatus = carveOrderStatus;
	}
	public Long getSurplusTime() {
		return surplusTime;
	}
	public void setSurplusTime(Long surplusTime) {
		this.surplusTime = surplusTime;
	}
	public Long getHeaderUserId() {
		return headerUserId;
	}
	public void setHeaderUserId(Long headerUserId) {
		this.headerUserId = headerUserId;
	}
	public Integer getCarveMinNewNum() {
		return carveMinNewNum;
	}
	public void setCarveMinNewNum(Integer carveMinNewNum) {
		this.carveMinNewNum = carveMinNewNum;
	}
	public String getActivityImageUrl() {
		return activityImageUrl;
	}
	public void setActivityImageUrl(String activityImageUrl) {
		this.activityImageUrl = activityImageUrl;
	}
}
