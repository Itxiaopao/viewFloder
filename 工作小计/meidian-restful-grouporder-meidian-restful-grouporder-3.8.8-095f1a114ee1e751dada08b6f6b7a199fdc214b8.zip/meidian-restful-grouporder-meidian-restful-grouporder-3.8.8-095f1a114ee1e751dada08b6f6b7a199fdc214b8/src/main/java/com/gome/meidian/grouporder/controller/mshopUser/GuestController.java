package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.mshopUserManager.GuestManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.rec.footprint.entity.PageEntity;
import com.gome.rec.footprint.entity.UserFootprintEntity;
import com.gome.rec.footprint.service.FootprintService;

import redis.Gcache;

/**
 * 客户管理
 * @author libinbin-ds
 *
 */
@RestController
@Validated
@RequestMapping("/guest")
public class GuestController {

	@Autowired
	private FootprintService footprintService; // 查询用户浏览记录
	@Autowired
	private GuestManager guestManager;
    @Resource(name = "gcache")
    private Gcache gcache;

	
	/**
	 * 搜索用户手机号, 微信昵称
	 * 
	 * @param scn
	 * @param phone
	 * @param wechartNick
	 * @param pageNo
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/searchByPhoneAndWeNick")
	public Object searchByPhoneAndWeNick(@CookieValue(value = "SCN", required = false) String scn, 
			String phone,
			String wechartNick, 
			@NotNull(message = "{param.error}") @RequestParam("type") int type) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "GuestController:" + "searchByPh-Wn:" + currentUser + "-" + phone + "-" + wechartNick + "-" + type;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.searchByPhoneAndWeNick(currentUser, phone, wechartNick, type);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}

	/**
	 * 用户下新,老,首单,忠实,用户数量
	 * 
	 * @param userId
	 * @param scn
	 * @CookieValue(value = "SCN", required = false)
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/myGuestTypeCount")
	public Object myGuestTypeCount(@CookieValue(value = "SCN", required = false) String scn) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "GuestController:" + "myGuestTypeCount:" + currentUser;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.myGuestTypeCount(currentUser);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}

	/**
	 * 用户列表, 通过type分页
	 * 
	 * @param userId
	 * @param phone
	 * @param nickName
	 * @param type
	 *            1：新客 2：游客 4：首单 5：忠粉
	 * @param pageNo
	 * @return
	 */
	@GetMapping(value = "/myGuestListByType")
	public Object myGuestListByType(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("type") int type,
			@NotNull(message = "{param.error}") @RequestParam("pageNo") int pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		responseJson = guestManager.myGuestListByType(currentUser, type, pageNo);
		return responseJson;
	}
	
	/**
	 * 我的客户组合几口
	 * 
	 * @param scn
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/myGuestInit")
	public Object myGuestInit(@CookieValue(value = "SCN", required = false) String scn, 
			@NotNull(message = "{param.error}") @RequestParam("type") int type
			) {
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "GuestController:" + "myGuestInit:" + currentUser + "-"+type ;
		String resultJson = gcache.get(key);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.myGuestInit(currentUser, type);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	
	

	/**
	 * 根据userId 当前用户的信息
	 * 
	 * @param scn
	 * @param searchUserId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/getMshopOwner")
	public Object getMshopOwner(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("searchUserId") Long searchUserId) {
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "GuestController:" + "getMshopOwner:" + currentUser + "-" + searchUserId;
		String resultJson = gcache.get(key);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.getMshopOwner(currentUser, searchUserId);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	

	/**
	 * 查询scn用户足迹 分页
	 * 
	 * @param scn
	 * @param pageNo
	 * @return
	 */
	@GetMapping(value = "/myFootPoint")
	public Object myFootPoint(@CookieValue(value = "SCN", required = false) String scn, String pageNo) {
		String currentUser = guestManager.getUserIdByScn(scn);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		responseJson = guestManager.myFootPoint(currentUser, pageNo);
		return responseJson;
	}

	/**
	 * 查询用户足迹 分页
	 * 
	 * @param searchUserId
	 * @param pageNo
	 * @return
	 */
	@GetMapping(value = "/userFootPoint")
	public Object userFootPoint(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("searchUserId") String searchUserId, String pageNo) {
		String currentUser = guestManager.getUserIdByScn(scn);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		responseJson = guestManager.userFootPoint(currentUser, searchUserId, pageNo);
		return responseJson;
	}


	/**
	 * 他人我的足迹组合接口
	 * 
	 * @param scn
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/userFootPointInit")
	public Object userFootPointInit(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("searchUserId") String searchUserId) {
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "GuestController:" + "userFootPointInit:" + currentUser + "-" + searchUserId;
		String resultJson = gcache.get(key);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.userFootPointInit(currentUser, searchUserId);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	
	/**
	 * 
	 * @param searchUserId
	 * @return
	 */
	@GetMapping(value = "/test/foot1")
	public Object userFootPointInit1(
			@NotNull(message = "{param.error}") @RequestParam("searchUserId") String searchUserId) {
		PageEntity<List<UserFootprintEntity>> page = footprintService.getUserFootprintsByPage(searchUserId, null, null,
				"1", "10", "MEIDIAN");
		return page;
	}

	/**
	 * 
	 * @param searchUserId
	 * @return
	 */
	@GetMapping(value = "/test/foot2")
	public Object userFootPointInit2(
			@NotNull(message = "{param.error}") @RequestParam("searchUserId") String searchUserId) {
		PageEntity<List<UserFootprintEntity>> page = footprintService.getRankedVisitors(searchUserId, guestManager.uidListTest(), 1, 10);
		return page;
	}

	/**
	 * 获取用户微信昵称
	 * @param userId
	 * @return
	 * @throws ServiceException
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/getWeiXinNickName")
	public  Object getWeiXinNickName(@CookieValue(value = "SCN", required = false) String scn)throws ServiceException{
		String currentUser = guestManager.getUserIdByScn(scn);
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String key ="GuestController:" + "getWeiXinNickName:" + currentUser;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.getWeiXinNickName(currentUser);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	
}
