package com.gome.meidian.grouporder.vo.carveUp.carveUpActivity;

import java.util.List;

import com.gome.meidian.grouporder.vo.Coupon;

/**
 * 排名团活动基础信息
 */
public class CarveUpRankActivityInfoVo extends CarveUpBaseActivityInfoVo {

	private static final long serialVersionUID = -6721843595631605179L;
//	private Integer rankGroupRewardNum; //排名团奖励团数
//	private List<Coupon> rankCoupon;  //排名团券信息
//	private Integer rankMaxPeopleNum; //排名团最多参与人数
//	private Double rankFixMoney; //排名团额外每人固定国美币
//	private Double rankTotalMoney; //排名团额外总国美币
	private Double rankBondTotalNum; //排名奖励劵面值总和（元）
	private Double leaderMoney;//团长独享金额（根据瓜分比例和总额计算结果）
	private Double totalCarveMoney;//共同瓜分金额(元、小数最多2位)
//	public List<Coupon> getRankCoupon() {
//		return rankCoupon;
//	}
//	public void setRankCoupon(List<Coupon> rankCoupon) {
//		this.rankCoupon = rankCoupon;
//	}
//	public Double getRankFixMoney() {
//		return rankFixMoney;
//	}
//	public void setRankFixMoney(Double rankFixMoney) {
//		this.rankFixMoney = rankFixMoney;
//	}
//	public Double getRankTotalMoney() {
//		return rankTotalMoney;
//	}
//	public void setRankTotalMoney(Double rankTotalMoney) {
//		this.rankTotalMoney = rankTotalMoney;
//	}
	public Double getRankBondTotalNum() {
		return rankBondTotalNum;
	}
	public void setRankBondTotalNum(Double rankBondTotalNum) {
		this.rankBondTotalNum = rankBondTotalNum;
	}
	public Double getLeaderMoney() {
		return leaderMoney;
	}
	public void setLeaderMoney(Double leaderMoney) {
		this.leaderMoney = leaderMoney;
	}
	public Double getTotalCarveMoney() {
		return totalCarveMoney;
	}
	public void setTotalCarveMoney(Double totalCarveMoney) {
		this.totalCarveMoney = totalCarveMoney;
	}

//	public Integer getRankMaxPeopleNum() {
//		return rankMaxPeopleNum;
//	}
//
//	public void setRankMaxPeopleNum(Integer rankMaxPeopleNum) {
//		this.rankMaxPeopleNum = rankMaxPeopleNum;
//	}

//	public Integer getRankGroupRewardNum() {
//		return rankGroupRewardNum;
//	}
//
//	public void setRankGroupRewardNum(Integer rankGroupRewardNum) {
//		this.rankGroupRewardNum = rankGroupRewardNum;
//	}
}
