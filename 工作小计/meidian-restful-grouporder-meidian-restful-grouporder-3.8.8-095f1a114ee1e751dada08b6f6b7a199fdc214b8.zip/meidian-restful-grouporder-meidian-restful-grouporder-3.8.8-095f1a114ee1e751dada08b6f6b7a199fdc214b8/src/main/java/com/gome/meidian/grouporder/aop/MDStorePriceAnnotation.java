package com.gome.meidian.grouporder.aop;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.ElementType;

/**
 * 门店价注解
 * @author Administrator
 *
 */
@Documented 
@Retention(RetentionPolicy.RUNTIME) // RetentionPolicy.RUNTIME：注解不仅被保存到class文件中，jvm加载class文件之后，仍然存在
@Target(ElementType.METHOD)// 　@Target说明了Annotation所修饰的对象范围,METHOD:用于描述方法
public @interface MDStorePriceAnnotation {

}
