package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

public class SkuEnergyAllowanceVo implements Serializable {

	private static final long serialVersionUID = 8303022489691690564L;
	/**
     * 状态 1有效，0无效
     */
    private Integer energyState;
    /**
     * 能效级别
     */
    private Integer energyLevel;
    /**
     * 补贴标准
     */
    private Double energyStandard;
    /**
     * 补贴限额
     */
    private Double energyLimitMoney;
    /**
     * 报备价
     */
    private Double recordPrice;
	public Integer getEnergyState() {
		return energyState;
	}
	public void setEnergyState(Integer energyState) {
		this.energyState = energyState;
	}
	public Integer getEnergyLevel() {
		return energyLevel;
	}
	public void setEnergyLevel(Integer energyLevel) {
		this.energyLevel = energyLevel;
	}
	public Double getEnergyStandard() {
		return energyStandard;
	}
	public void setEnergyStandard(Double energyStandard) {
		this.energyStandard = energyStandard;
	}
	public Double getEnergyLimitMoney() {
		return energyLimitMoney;
	}
	public void setEnergyLimitMoney(Double energyLimitMoney) {
		this.energyLimitMoney = energyLimitMoney;
	}
	public Double getRecordPrice() {
		return recordPrice;
	}
	public void setRecordPrice(Double recordPrice) {
		this.recordPrice = recordPrice;
	}
    
    
}
