package com.gome.meidian.grouporder.vo.wechatLogin;

import java.io.Serializable;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/6 16:19
 * @Description
 */
public class WeChatLoginResultVO implements Serializable {


    private  String  success;//成功为true，失败false失败原因看code字段

    private  String  memberCode;//会员code  6001是新用户

    private  String  userType;//loginBind or registerBind isBindMobile

    private  String message;

    private  String  userId;//用户ID

    private  String  scn;//登录用户信息

    private  String  sNSUserName;//微信昵称

    private  String  headImageUrl;//微信头像

    private  String nickName;

    private  Boolean updateBind; //是否跳出变更绑定确认按钮

    private  Long updateBindOpenId; //绑定openId

    private String storeNo;		//门店编码stId
    private String staffNo;     //员工编号
    private String gomeNickName;	//国美用户昵称
    private Long shopId;//店主id


    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMemberCode() {
        return memberCode;
    }

    public void setMemberCode(String memberCode) {
        this.memberCode = memberCode;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getScn() {
        return scn;
    }

    public void setScn(String scn) {
        this.scn = scn;
    }

    public String getsNSUserName() {
        return sNSUserName;
    }

    public void setsNSUserName(String sNSUserName) {
        this.sNSUserName = sNSUserName;
    }

    public String getHeadImageUrl() {
        return headImageUrl;
    }

    public void setHeadImageUrl(String headImageUrl) {
        this.headImageUrl = headImageUrl;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }


    public Boolean getUpdateBind() {
        return updateBind;
    }

    public void setUpdateBind(Boolean updateBind) {
        this.updateBind = updateBind;
    }


    public Long getUpdateBindOpenId() {
        return updateBindOpenId;
    }

    public void setUpdateBindOpenId(Long updateBindOpenId) {
        this.updateBindOpenId = updateBindOpenId;
    }


    public String getStoreNo() {
        return storeNo;
    }

    public void setStoreNo(String storeNo) {
        this.storeNo = storeNo;
    }

    public String getGomeNickName() {
        return gomeNickName;
    }

    public void setGomeNickName(String gomeNickName) {
        this.gomeNickName = gomeNickName;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public String getStaffNo() {
        return staffNo;
    }

    public void setStaffNo(String staffNo) {
        this.staffNo = staffNo;
    }

    @Override
    public String toString() {
        return "WeChatLoginResultVO{" +
                "success='" + success + '\'' +
                ", memberCode='" + memberCode + '\'' +
                ", userType='" + userType + '\'' +
                ", message='" + message + '\'' +
                ", userId='" + userId + '\'' +
                ", scn='" + scn + '\'' +
                ", sNSUserName='" + sNSUserName + '\'' +
                ", headImageUrl='" + headImageUrl + '\'' +
                ", nickName='" + nickName + '\'' +
                ", updateBind=" + updateBind +
                ", updateBindOpenId=" + updateBindOpenId +
                ", storeNo='" + storeNo + '\'' +
                ", gomeNickName='" + gomeNickName + '\'' +
                ", shopId=" + shopId +
                '}';
    }
}
