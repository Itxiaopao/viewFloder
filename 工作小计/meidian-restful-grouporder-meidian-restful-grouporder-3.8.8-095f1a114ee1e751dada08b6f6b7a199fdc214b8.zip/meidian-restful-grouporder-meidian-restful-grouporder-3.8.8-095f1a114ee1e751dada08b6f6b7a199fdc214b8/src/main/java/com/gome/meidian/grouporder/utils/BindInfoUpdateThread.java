package com.gome.meidian.grouporder.utils;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.vo.wechatLogin.WeChatOpenIdAndUserIdVO;
import com.gome.meidian.user.entity.UserRelation;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.meidian.user.manager.IUserRelationManager;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.Gcache;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/4 10:20
 * @Description
 */
public class BindInfoUpdateThread extends Thread {

    private Logger logger = LoggerFactory.getLogger(getClass());

    private  Long id;

    private  String userId;

    private  String openId;

    private  String unionId;

    private boolean addOrSave;

    private Gcache userCenter;

    private IUserRelationManager iUserRelationManager;

    private  WeChatOpenIdAndUserIdVO  weChatOpenIdAndUserIdVO;

    private  HttpClientUtil   httpClientUtil;

    private  String   bindUserUrl;


    public static final String USER_OPENID_ID_SET="user.center.userRelation.manager";


    public BindInfoUpdateThread(boolean addOrSave, Long id, String userId, String openId, String unionId, Gcache userCenter, IUserRelationManager iUserRelationManager, WeChatOpenIdAndUserIdVO weChatOpenIdAndUserIdVO,HttpClientUtil httpClientUtil,String bindUserUrl){
            this.addOrSave=addOrSave;
            this.id=id;
            this.userId=userId;
            this.openId=openId;
            this.unionId=unionId;
            this.userCenter=userCenter;
            this.iUserRelationManager=iUserRelationManager;
            this.weChatOpenIdAndUserIdVO=weChatOpenIdAndUserIdVO;
            this.httpClientUtil=httpClientUtil;
            this.bindUserUrl=bindUserUrl;
    }

    @Override
    public void run() {
        //保存openId和userId关系或更新用户关系到美店用户中心
        logger.info("BindInfoUpdateThread-toDo-id:{} userId-{}  openId-{}  unionId-{}",id,userId,openId,unionId);
        UserRelation  userRelation=new UserRelation();
        userRelation.setId(this.id);
        userRelation.setUserId(userId);
        userRelation.setOpenId(openId);
        userRelation.setUnionId(unionId);
        if(addOrSave){
            iUserRelationManager.addUserRelation(userRelation);
        }else{
            iUserRelationManager.updateUserRelation(userRelation);
        }

        //保存用户关系到无线DB
        if(null!=weChatOpenIdAndUserIdVO){
            Map map=new HashMap<>();
            try {
                 String  request=com.alibaba.fastjson.JSON.toJSONString(weChatOpenIdAndUserIdVO);
                 map.put("body",request);
                 String  reponse=httpClientUtil.doFromPost(bindUserUrl,map);
            } catch (Exception e) {
                logger.info("http://wx.wireless.api/bind/user-error map:{}",map);
                e.printStackTrace();
            }
        }
    }
}
