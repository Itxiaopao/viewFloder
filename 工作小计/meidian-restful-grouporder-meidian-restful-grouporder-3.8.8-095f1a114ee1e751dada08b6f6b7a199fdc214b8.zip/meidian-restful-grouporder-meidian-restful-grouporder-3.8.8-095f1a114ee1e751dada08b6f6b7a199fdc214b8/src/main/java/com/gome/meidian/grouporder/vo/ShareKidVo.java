package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.goodsProductVerify;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupOrderVerify;


/**
 * 换取kid
 * @author shichangjian
 *
 */
public class ShareKidVo implements Serializable {

	private static final long serialVersionUID = -7256940255530948718L;

	@NotNull(message = "{param.error}", groups = {groupOrderVerify.class})
	private int callform; 		// 分享来源
	@NotNull(message = "{param.error}")
	private int channel; 		// 分享渠道
	private String url; 		// url
	private String shareKey;	// 唯一分享key
	private String skuId; 		// 商品SKUId
	private String itemId; 		// 商品itemID
	private int flow; 			// 推广
	private String distSaleId;	// 分销ID 如果推广模式是分销那么这个ID必须得有
	private String merchantId;	// 商家ID
	@NotBlank(message = "{param.error}", groups = {groupOrderVerify.class})
	private String userId; 		// 用户ID
	
	private String mid; 		// 个人店主id（线上虚拟的）
	private String stid; 		// 渠道美店id
	private String pgid;		// 落地id（从哪个页面进来的，上一个页面的标识）
	private String chid;		// 合作方id
	private String back;		// 自定义参数（为后期业务扩展使用）
	
	public int getCallform() {
		return callform;
	}

	public void setCallform(int callform) {
		this.callform = callform;
	}

	public int getChannel() {
		return channel;
	}

	public void setChannel(int channel) {
		this.channel = channel;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getShareKey() {
		return shareKey;
	}

	public void setShareKey(String shareKey) {
		this.shareKey = shareKey;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public int getFlow() {
		return flow;
	}

	public void setFlow(int flow) {
		this.flow = flow;
	}

	public String getDistSaleId() {
		return distSaleId;
	}

	public void setDistSaleId(String distSaleId) {
		this.distSaleId = distSaleId;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getStid() {
		return stid;
	}

	public void setStid(String stid) {
		this.stid = stid;
	}

	public String getPgid() {
		return pgid;
	}

	public void setPgid(String pgid) {
		this.pgid = pgid;
	}

	public String getChid() {
		return chid;
	}

	public void setChid(String chid) {
		this.chid = chid;
	}

	public String getBack() {
		return back;
	}

	public void setBack(String back) {
		this.back = back;
	}

}
