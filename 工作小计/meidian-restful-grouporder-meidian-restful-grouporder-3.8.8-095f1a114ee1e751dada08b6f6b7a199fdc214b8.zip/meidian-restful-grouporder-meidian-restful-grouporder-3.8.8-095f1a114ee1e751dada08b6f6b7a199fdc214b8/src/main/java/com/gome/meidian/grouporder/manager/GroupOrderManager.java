package com.gome.meidian.grouporder.manager;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.gome.meidian.grouporder.vo.grouporderVo.*;
import com.gome.meidian.user.manager.IUserGomeInfoManager;
import com.gomeplus.bs.interfaces.gorder.vo.*;

import org.apache.http.client.methods.HttpGet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.coo8.promotion.business.interfaces.interfaces.IProPromtionInterfaceManager;
import com.coo8.promotion.model.ProPresent;
import com.coo8.promotion.model.ProProduct;
import com.coo8.promotion.model.interfaces.PromotionProductShowPageInterfaceBean;
import com.gome.architect.risk.dto.ExtKeyEnum;
import com.gome.architect.risk.dto.RequestV2;
import com.gome.architect.risk.dto.ResponseV2;
import com.gome.architect.risk.dto.ResultV2;
import com.gome.architect.risk.service.IRiskService;
import com.gome.bg.interfaces.coupons.bean.GomeFetchCouponsResult;
import com.gome.bg.interfaces.coupons.bean.GomePackageFetchCouponParam;
import com.gome.bg.interfaces.coupons.service.GomeFetchCouponsInnoService;
import com.gome.bg.interfaces.coupons.service.GomeFetchCouponsService;
import com.gome.bg.interfaces.fusecoupon.bean.FuseCouponParam;
import com.gome.bg.interfaces.fusecoupon.bean.FuseCouponResult;
import com.gome.bg.interfaces.fusecoupon.bean.FuseCouponResultData;
import com.gome.bg.interfaces.fusecoupon.service.GomeFetchFuseCouponInnoService;
import com.gome.bg.interfaces.fusecoupon.service.GomeFetchFuseCouponService;
import com.gome.coupon.interfaces.dubbo.ICouponAndBatchManager;
import com.gome.coupon.interfaces.dubbo.IPromotionAndCouponManager;
import com.gome.coupon.model.cartBean.AreaInfo;
import com.gome.coupon.model.cartBean.CouponBatchResult;
import com.gome.coupon.model.cartBean.QueryShopCouponParam;
import com.gome.coupon.model.cartBean.ResultDO;
import com.gome.feitian.atp.client.AtpAreaQueryClient;
import com.gome.framework.base.ResultDTO;
import com.gome.frontSe.comm.FSImgBase;
import com.gome.frontSe.interfaces.IProdDetailService;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.controller.GroupOrderController;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.CouponEncryptionUtil;
import com.gome.meidian.grouporder.utils.CouponEnum;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.LogUtils;
import com.gome.meidian.grouporder.utils.MD5Util;
import com.gome.meidian.grouporder.vo.ActivityPageShare;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.BannerImage;
import com.gome.meidian.grouporder.vo.BannerProductIdVo;
import com.gome.meidian.grouporder.vo.CurrentStepsVo;
import com.gome.meidian.grouporder.utils.PageInfoVo;
import com.gome.meidian.grouporder.utils.Sha1Util;
import com.gome.meidian.grouporder.utils.TypeConversionUtils;
import com.gome.meidian.grouporder.vo.FirstClassInfoListVo;
import com.gome.meidian.grouporder.vo.FirstClassInfoVo;
import com.gome.meidian.grouporder.vo.GmsidValidResultVo;
import com.gome.meidian.grouporder.vo.GroupInfomationVo;
import com.gome.meidian.grouporder.vo.GroupOrderDetails;
import com.gome.meidian.grouporder.vo.GroupOrderInfoVo;
import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.MyGroupOrderInfoVo;
import com.gome.meidian.grouporder.vo.PriceConditionVo;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.ProductDetailPageVo;
import com.gome.meidian.grouporder.vo.ProductDetailVo;
import com.gome.meidian.grouporder.vo.ProductIdActivityId;
import com.gome.meidian.grouporder.vo.ProductIdActivityIdVo;
import com.gome.meidian.grouporder.vo.ProductInfoVo;
import com.gome.meidian.grouporder.vo.ProductListVo;
import com.gome.meidian.grouporder.vo.ProductParamInfo;
import com.gome.meidian.grouporder.vo.ProductVo;
import com.gome.meidian.grouporder.vo.ShareKidVo;
import com.gome.meidian.grouporder.vo.SkuAttrVo;
import com.gome.meidian.grouporder.vo.StepsConfig;
import com.gome.meidian.grouporder.vo.StepsVo;
import com.gome.meidian.grouporder.vo.coupon.Condition;
import com.gome.meidian.grouporder.vo.coupon.CouponMiddleOne;
import com.gome.meidian.grouporder.vo.coupon.Gift;
import com.gome.meidian.grouporder.vo.coupon.Promotion;
import com.gome.meidian.grouporder.vo.coupon.TransitionCoupon;
import com.gome.meidian.grouporder.vo.grouporderVo.EnergySavingSubsidiesVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupActivityInfo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupSkuVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupTotal;
import com.gome.meidian.grouporder.vo.grouporderVo.Sku;
import com.gome.meidian.grouporder.vo.grouporderVo.SkuEnergyAllowanceVo;
import com.gome.meidian.grouporder.vo.product.MeidianPrice;
import com.gome.meidian.grouporder.vo.product.ProductRequestParam;
import com.gome.meidian.grouporder.vo.product.ProductSkuStatus;
import com.gome.meidian.grouporder.vo.product.SkuStatus;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.meidian.grouporder.vo.product.AppreciationServeType;
import com.gome.meidian.grouporder.vo.product.AppreciationServe;
import com.gome.meidian.restfulcommon.reponse.StatusCode;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.mobile.common.utils.math.BigDecimalUtils;
import com.gome.oms.commerce.model.order.OrderInfo;
import com.gome.oms.searchorders.service.order.OrderQueryService;
import com.gome.pangu.bluecoupon.dubbo.model.BlueCouponBaseResult;
import com.gome.pangu.bluecoupon.dubbo.service.BlueCouponQueryService;
import com.gome.pangu.bluecoupon.dubbo.service.FpBlueCouponQueryService;
import com.gome.pangu.promotiondata.client.CouponPromotionClient;
import com.gome.pangu.promotiondata.client.EnergySavingSubsidiesClient;
import com.gome.pangu.promotiondata.client.GomePromotionForDetailClient;
import com.gome.pangu.promotiondata.client.dto.couponProm.CouponPromListParamDTO;
import com.gome.pangu.promotiondata.client.dto.detailpromotion.GiftDTO;
import com.gome.pangu.promotiondata.client.dto.detailpromotion.GomePromotionConditionDTO;
import com.gome.pangu.promotiondata.client.dto.detailpromotion.GomePromotionForDetailDTO;
import com.gome.pangu.promotiondata.client.dto.detailpromotion.GomePromotionForDetailResultDTO;
import com.gome.pangu.promotiondata.client.dto.energysavingsubsidies.EnergySavingSubsidiesParamDTO;
import com.gome.pangu.promotiondata.client.dto.energysavingsubsidies.EnergySavingSubsidiesResultDTO;
import com.gome.pangu.promotiondata.client.dto.energysavingsubsidies.PromotionScopeDTO;
import com.gome.pangu.redcoupon.dubbo.model.ChangeUserIdParam;
import com.gome.pangu.redcoupon.dubbo.model.RedCouponBaseResult;
import com.gome.pangu.redcoupon.dubbo.service.RedCouponQueryService;
import com.gome.pangu.redcoupon.dubbo.service.RedCouponService;
import com.gome.promotion.gome.warranty.client.IGomeIncrementServiceClient;
import com.gome.promotion.gome.warranty.client.dto.IncrementBaseGroupDTO;
import com.gome.promotion.gome.warranty.client.dto.IncrementShowGroupDTO;
import com.gome.promotion.gome.warranty.client.dto.IncrementSkuInfoDTO;
import com.gome.promotion.gome.warranty.client.param.QueryIncrementServiceDetailParam;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gome.promotion.handle.client.service.QueryGomePromService;
import com.gome.rpc.base.RequestDTO;
import com.gome.rpc.base.ResponseDTO;
import com.gome.sso.model.UserInfoCache;
import com.gome.stage.bean.BombDTO;
import com.gome.stage.bean.price.GomeUnifiedPrice;
import com.gome.stage.bean.vo.CommodityVo;
import com.gome.stage.bean.vo.ProductShopInfo;
import com.gome.stage.interfaces.item.IGomeRebateService;
import com.gome.stage.interfaces.item.IGomeVipPriceService;
import com.gome.stage.interfaces.item.IProductInfoService;
import com.gome.stage.interfaces.item.ISkuEnergyAllowanceService;
import com.gome.stage.item.GomeBombMultipleSkuService;
import com.gome.stage.item.GomeVipPriceItem;
import com.gome.stage.item.GoodsInfoFull;
import com.gome.stage.item.RebatePercent;
import com.gome.stage.item.SkuEnergyAllowance;
import com.gome.stage.item.SkuItem;
import com.gome.stage.page.ProductItemPage;
import com.gome.stage.service.IAccessGoodsService;
import com.gome.tapho.bean.spec.PrdSpecBean;
import com.gome.tapho.interfaces.spec.IProdSpecService;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppHelpGroupResource;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gome.pangu.promotiondata.client.dto.couponProm.CouponPromListResultDTO;

import cn.com.gome.rebate.dubbo.service.app.IDubboBuyersService;
import cn.com.gome.rebate.model.url.UrlReqDto;
import cn.com.gome.rebate.model.url.UrlResDto;
import cn.com.gome.user.service.QueryUserInfoFacade;
import redis.Gcache;

/**
 * @author shichangjian
 *
 */
@Service
public class GroupOrderManager {

    private Logger logger = LoggerFactory.getLogger(getClass());
    private final static String user_id = "user.center.userInfo.manager";
    private final static String warrantyChannel = "13";                    // 延保渠道
    private final static byte USER_ALREADY_LOGIN = 1;    // 用户已登录
    private final static byte USER_NOT_LOGIN = 0;        // 用户未登录
    private final static String SKU_CATEGORY_MID = "MDXQ0001";        // 商品分类mid
    private final static String SKU_ATTRIBUTE_MID = "MDXQ0002";        // 商品属性mid

    // 返利成功返回
    private final static String REBATE_SUCCESS = "E0000";
    @Autowired
    private GorderInfoForAppNewResource gorderInfoForAppNewResource;
    @Autowired
    private IProductInfoService productInfoService;
    @Autowired
    private IProdSpecService prodSpecService;
    @Autowired
    private IDubboBuyersService iDubboBuyersService;
    @Autowired
    private IAccessGoodsService accessGoodsService;
    @Autowired
    private HttpClientUtil httpClientUtil;
    @Autowired
    private GomeFetchFuseCouponInnoService gomeFetchFuseCouponInnoService;
    @Autowired
    private IGomeRebateService iGomeRebateService;
    @Autowired
    private AuthencationUtils authencationUtils;
    @Autowired
    private QueryGomePromService queryGomePromService;
    @Autowired
    private IProPromtionInterfaceManager proPromInterfaceManager;
    @Autowired
    private GomeBombMultipleSkuService gomeBombMultipleSkuService;
    @Autowired
    private CouponPromotionClient couponPromotionClient;
    @Resource(name = "gcache")
    private Gcache gcache;
    @Resource(name = "gcachezz")
    private Gcache gcachezz;
    @Resource(name = "userCenter")
    private Gcache userCenter;

	@Autowired
	private IProdDetailService prodDetailService;
//	@Autowired
//	private GomeFetchCouponsService gomeFetchCouponsService;
	@Autowired
	private AtpAreaQueryClient atpAreaQueryClient;
	@Autowired
	private ICouponAndBatchManager iCouponAndBatchManager;
	@Autowired
	private IPromotionAndCouponManager iPromotionAndCouponManager;
	@Autowired
	private IRiskService iriskService;
	@Autowired
	private OrderQueryService orderQueryService;
	@Autowired
	private IGomeVipPriceService iGomeVipPriceService;
	@Autowired
	private HomeProductsManager homeProductsManager;
	@Autowired
	private ISkuEnergyAllowanceService iSkuEnergyAllowanceService;
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	@Autowired
	private IGomeIncrementServiceClient iGomeIncrementServiceClient;
	@Autowired
	private EnergySavingSubsidiesClient energySavingSubsidiesClient;
	@Autowired
	private VshopFacade vshopFacade;
	@Autowired
	private StoreManager storeManager;
	@Autowired
	private RedCouponService redCouponService;
	@Autowired
	private FpBlueCouponQueryService fpBlueCouponQueryService;
	@Autowired
	private BlueCouponQueryService blueCouponQueryService;
	@Autowired
	private RedCouponQueryService redCouponQueryService;
	@Autowired
	private IUserShareBindingManager iUserShareBindingManager;
	@Autowired
	private GorderInfoForAppHelpGroupResource gorderInfoForAppHelpResource;
	@Autowired
	private IUserGomeInfoManager iUserGomeInfoManager;
	@Autowired
	private GomePromotionForDetailClient gomePromotionForDetailClient;
	@Autowired
	private PropertiesConfig propertiesConfig;
	@Autowired
	private PriceManager priceManager;
	@Autowired
	private GomeFetchCouponsInnoService gomeFetchCouponsInnoService;
	
	
	@Value("${gome.order.getOrder}")
	private String getOrderURL;
	@Value("${gome.order.shipList}")
	private String getShipListURL;
	@Value("${gome.order.areaList}")
	private String areaList;
	@Value("${gome.order.orderUrl}")
	private String orderUrl;
	@Value("${gome.order.orderRefer}")
	private String orderRefer;
	@Value("${gome.order.returnUrl}")
	private String returnUrl;
	@Value("${cms.productIdsUrl}")
	private String productIdsUrl; // http://shark-cms.pre.video.api/v1/slot/store/getStoreSlot?unique_key=A017entitystorecontent661217
	@Value("${cms.slotUrl}")
	private String slotUrl;
	@Value("${cms.activityPageShare}")
	private String activityPageShare;
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认三级区域，朝阳，全国价
	@Value("${gome.product.appraiseUrl}")
	private String appraiseUrl;
	@Value("${gome.gmsidValid.url}")
	private String gmsidValidUrl;
	@Value("${gome.gmsidValid.appId}")
	private String appId;
	@Value("${meidian.image.userImage}")
	private String userImage;			// 用户头像分辨率
	@Value("${meidian.image.agreement}")
	private String agreement;			// http协议
	@Value("${gome.loginUrl}")
	private String loginUrl;
	@Value("${spring.profiles.active}")
	private String currentEnv;
	@Resource(name = "venusVshop")
	private Gcache venusVshopGcache;
	
	/**
	 * 热门爆款/精选商品列表
	 * 
	 * @param type
	 *            查询类型：热门爆款-1 精选-2
	 * @param areaCode
	 *            区域码
	 * @param pageNum
	 *            页码
	 * @param pageSize
	 *            条数
	 * @return
	 */
	public Map<String, Object> getRecommendProductList(Integer type, String areaCode, Integer pageNum, Integer pageSize,
			HttpServletRequest request) {
//		String urlType = this.getCurrentUrlType(request.getRequestURL().toString());

        Map<String, Object> resultMap = new HashMap<>();
        CommonResultEntity<RecommendProductVo> resultVo = gorderInfoForAppNewResource.getRecommendProductList(type,
                areaCode, pageNum, pageSize);

        resultMap = resultMapConvert(resultMap, resultVo);
        ProductListVo listVo = new ProductListVo();
        Long totalNum = 0L;
        Map<String, Object> data = new HashMap<>();
        if (resultVo.getBusinessObj() != null) {
            RecommendProductVo tVo = resultVo.getBusinessObj();
            if (tVo != null) {
                List<ProductManagementVo> tList = tVo.getProductInfo();
                if (tList != null && tList.size() > 0) {
                    List<ProductVo> resultList = tList.stream().map(a -> copyProduct(a))
                            .collect(Collectors.toList());
                    listVo = new ProductListVo(resultList);
                    totalNum = tVo.getTotalNum();
                }

            }
        }

        data.put("results", listVo);
        PageInfoVo page = new PageInfoVo();
        page.setCurrPageNo(pageNum);
        page.setPageSize(pageSize);
        page.setTotalCount(totalNum);

        data.put("page", page);

        resultMap.put("data", data);

        return resultMap;
    }

    /**
     * 获取一级分类列表
     *
     * @return
     */
    public Map<String, Object> getFirstClassificationList() {
        Map<String, Object> resultMap = new HashMap<>();
        CommonResultEntity<FirstClassificationVo> resultVo = gorderInfoForAppNewResource.getFirstClassificationList();

        resultMap = resultMapConvert(resultMap, resultVo);
        FirstClassInfoListVo listVo = new FirstClassInfoListVo();

        if (resultVo.getBusinessObj() != null) {
            FirstClassificationVo tVo = resultVo.getBusinessObj();
            if (tVo != null) {
                List<FirstClassificationManagementVo> tList = tVo.getFirstClassificationList();
                if (tList != null && tList.size() > 0) {
                    List<FirstClassInfoVo> resultList = tList.stream()
                            .map(a -> new FirstClassInfoVo(a.getFirstClassificationId(), a.getName(), a.getAlias(),
                                    a.getSortNum()))
                            .collect(Collectors.toList());
                    listVo = new FirstClassInfoListVo(resultList);

                }
            }
        }
        resultMap.put("data", listVo);
        return resultMap;
    }

    /**
     * 根据一级分类获取商品列表
     *
     * @param firstClassificationId 一级分类ID
     * @param areaCode              区域码
     * @param pageSize              条数
     * @param pageNum               页码
     * @return
     */
    public Map<String, Object> getProductsByFirstClassification(String firstClassificationId, String areaCode,
                                                                Integer pageSize, Integer pageNum, HttpServletRequest request) {

//		String urlType = this.getCurrentUrlType(request.getRequestURL().toString());

        Map<String, Object> resultMap = new HashMap<>();
        CommonResultEntity<FirstClassificationProductsVo> resultVo = gorderInfoForAppNewResource
                .getProductsByFirstClassification(firstClassificationId, areaCode, pageNum, pageSize);

        resultMap = resultMapConvert(resultMap, resultVo);

        ProductListVo listVo = new ProductListVo();
        Long totalNum = 0L;
        Map<String, Object> data = new HashMap<>();
        if (resultVo.getBusinessObj() != null) {
            FirstClassificationProductsVo tVo = resultVo.getBusinessObj();
            if (tVo != null) {
                List<ProductManagementVo> tList = tVo.getProductInfo();
                if (tList != null && tList.size() > 0) {
                    List<ProductVo> resultList = tList.stream().map(a -> copyProduct(a))
                            .collect(Collectors.toList());
                    listVo = new ProductListVo(resultList);
                    totalNum = tVo.getTotalNum();
                }

            }
        }

        data.put("results", listVo);
        PageInfoVo page = new PageInfoVo();
        page.setCurrPageNo(pageNum);
        page.setPageSize(pageSize);
        page.setTotalCount(totalNum);
        data.put("page", page);

        resultMap.put("data", data);

        return resultMap;
    }

//	/**
//	 * 获取商品列表
//	 *
//	 * @param productIdActivityIds
//	 * @param areaCode
//	 * @param organizationId
//	 * @param request
//	 * @return
//	 */
//	public List<GrouppOrderProductsVo> getProductsByIds(ProductsRequestVo productsRequestVo,
//			HttpServletRequest request) {
//
//		String areaCode = productsRequestVo.getAreaCode();
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
//		String organizationId = productsRequestVo.getOrganizationId();
//		List<ProductIdActivityId> productIdActivityIds = productsRequestVo.getProductIdActivityIds();
//		String storeCode = productsRequestVo.getStoreCode();
//		String ukey = productsRequestVo.getUkey();
//		String typeName = productsRequestVo.getTypeName();
//
//		List<ProductsVo> productIds = new ArrayList<ProductsVo>();
//
//		int index = 0;
//		Map<String, String> indexMap = new LinkedHashMap<String, String>();
//		List<ProductVo> resultList = new ArrayList<ProductVo>();
//		if (productIdActivityIds != null && productIdActivityIds.size() > 0) {
//			for (ProductIdActivityId productIdActivityId : productIdActivityIds) {
//				// 记录活动页ukey下标
//				index++;
//				if (StringUtils.isNotBlank(productIdActivityId.getUkey())) {
//					indexMap.put(String.valueOf(index - 1), productIdActivityId.getUkey());
//					continue;
//				}
//				ProductsVo productsVo = new ProductsVo();
//				if (StringUtils.isNotBlank(productIdActivityId.getActivityId()))
//					productsVo.setActivityId(Long.valueOf(productIdActivityId.getActivityId()));
//				productsVo.setProductId(productIdActivityId.getProductId());
//				productIds.add(productsVo);
//			}
//
////			String urlType = this.getCurrentUrlType(request.getRequestURL().toString());
//
//			// 拉取缓存数据
////			List<ProductManagementVo> productManagementVos = JSONObject.parseArray(
////					gcache.hget("meidian-restful-grouporder",
////							storeCode + "_" + ukey + "_" + ChineseUtils.toHanyuPinyin(typeName)),
////					ProductManagementVo.class);
//
//			List<ProductManagementVo> productManagementVos = JSONObject.parseArray(
//					gcache.get(storeCode + "_" + ukey + "_" + ChineseUtils.toHanyuPinyin(typeName)),
//					ProductManagementVo.class);
//
//			if (null != productManagementVos && productManagementVos.size() > 0) {
//				logger.info("getProductsByIds cache ==> {} ",
//						storeCode + "_" + ukey + "_" + ChineseUtils.toHanyuPinyin(typeName));
//				for (ProductManagementVo productManagementVo : productManagementVos) {
//					// 过滤下架商品
//					if (null != productManagementVo && null != productManagementVo.getProductStatus()
//							&& productManagementVo.getProductStatus() == 1) {
//
//						ProductVo productVo = copyProduct(productManagementVo);
//						resultList.add(productVo);
//					}
//				}
//
//			} else {
//				int listSize = productIds.size();
//				int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
//
//				List<ProductsVo> paramList = new ArrayList<>();
//				List<ProductManagementVo> productManagements = new ArrayList<ProductManagementVo>();
//				for (int a = 1; a <= selectCount; a++) {
//					paramList.clear();
//					if (selectCount == 1) {
//						paramList = productIds;
//					} else {
//						if (a != selectCount) {
//							paramList.addAll(productIds.subList(30 * (a - 1), 30 * a));
//						} else {
//							paramList.addAll(productIds.subList(30 * (a - 1), listSize));
//						}
//					}
//
//					CommonResultEntity<ProductInfoListVo> resultVo = GorderInfoForAppNewResource
//							.getProductInfoByIds(paramList, areaCode);
//					logger.debug("getProductsByIds resultVo ==> {} ", resultVo);
//					logger.info("getProductsByIds areaCode ==> {} ", areaCode);
//					if (resultVo.getBusinessObj() != null) {
//						ProductInfoListVo tVo = resultVo.getBusinessObj();
//						if (tVo != null) {
//							List<ProductManagementVo> tList = tVo.getProductInfo();
//							productManagements.addAll(tList);
//							if (tList != null && tList.size() > 0) {
//								for (ProductManagementVo productManagementVo : tList) {
//									if (null != productManagementVo && null != productManagementVo.getProductStatus()
//											&& productManagementVo.getProductStatus() == 1) {
//
//										ProductVo productVo = copyProduct(productManagementVo);
//										resultList.add(productVo);
//									}
//								}
//							}
//						}
//					}
//				}
//				// 添加到缓存
////				if (null != productManagements && productManagements.size() > 0) {
////					gcache.hset("meidian-restful-grouporder",
////							storeCode + "_" + ukey + "_" + ChineseUtils.toHanyuPinyin(typeName),
////							JSONUtils.toJSONString(productManagements).getBytes());
////				}
//				gcache.setex(storeCode + "_" + ukey + "_" + ChineseUtils.toHanyuPinyin(typeName), 5 * 60, JSONObject.toJSONString(productManagements).getBytes());
//
//			}
//
//		}
//
//		// 获取凑单商品列表，爆品商品列表，活动页，超级返
//		List<GrouppOrderProductsVo> grouppOrderProductsVos = new ArrayList<GrouppOrderProductsVo>();
//		// 超级返入参
////		List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
//
//		for (ProductVo productVo : resultList) {
//			GrouppOrderProductsVo grouppOrderProductsVo = new GrouppOrderProductsVo();
//			ProductParamInfo productParamInfo = new ProductParamInfo();
//
//			// 赋值
//			BeanUtils.copyProperties(productVo, productParamInfo);
//
//			// 佣金
//			RebatePercent rebatePercent = this.getPrdRebate(productParamInfo.getProductId(),
//					productParamInfo.getSkuId(), organizationId, productParamInfo.getPrice());
//			productParamInfo.setBrokerage(rebatePercent.getShareRebate());
//
//			// 优惠券信息
//			if (null == productVo.getActivityId()) {
//				Coupon coupon = new Coupon();
//				productIdActivityIds.stream().forEach(f -> {
//					if (f.getProductId().equalsIgnoreCase(productVo.getProductId())) {
//						// 注意区分f.getCouponType()是cms的，美劵和pop劵调用的接口不一样，couponType是返给前端用的
//						// f.getCouponType()为1:美劵，2：pop劵
//						// couponType; //类型 3001:美券 3002:蓝券 3003:红券 0：店铺劵(pop)
//						// 2：pop-平台劵(pop)
//						if (f.getCouponType() != null
//								&& f.getCouponType().equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
//							// 根据劵批次id查询pop劵信息
//							CouponBatchResult couponBatchResult = getPopCoupon(f.getCoupon_id());
//							if (null != couponBatchResult) {
//								coupon.setCoupon_id(f.getCoupon_id());// pop劵批次号
//								coupon.setCoupon_num(couponBatchResult.getDenomination()); // 面额
//								coupon.setDescription(couponBatchResult.getDescription());
//								coupon.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
//								coupon.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券,
//																									// 2:平台券
//								coupon.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
//							}
//						} else {
//							// 根据劵规则id查询美，红，蓝 ，劵信息
//							CouponRuleInfo couponData = this.getCoupon(f.getCoupon_id());
//							if (null != couponData) {
//								coupon.setCoupon_id(f.getCoupon_id());
//								coupon.setPlan_id(f.getPlan_id());
//								coupon.setCoupon_num(couponData.getAmount());
//								coupon.setDescription(couponData.getDescription());
//								coupon.setFullAmount(couponData.getLimitAmount());
//								coupon.setCouponType(couponData.getType());
//							}
//						}
//
//
//
//
//
//
//
//						// 超级返入参
////						if (null != f.getSkuId() && !f.getSkuId().equalsIgnoreCase("")) {
////							CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
////							// 返利key，自定义，作为返回多个值的区分,以productId,skuNo作为key
////							commonGoodsReqDto.setKey(f.getProductId());
////							// 商品productId
////							commonGoodsReqDto.setItemId(f.getProductId());
////							// skuNo
////							commonGoodsReqDto.setSkuId(f.getSkuId());
////							// 商户id
////							commonGoodsReqDto.setMerchantId(productVo.getShopId() == null || productVo.getShopId().equalsIgnoreCase("") ? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE : productVo.getShopId());
////							commonGoodsReqDtos.add(commonGoodsReqDto);
////						}
//
//
//
//
//
//
//
//
//
//
//
//
//					}
//				});
//				productParamInfo.setCoupon(coupon);
//
//				// 劵后价
//				Double couponNum = coupon.getCoupon_num();
//				if (null != couponNum) {
//					productParamInfo.setCouponPrice(DoubleUtils.sub(productParamInfo.getPrice(), couponNum));
//				}
//
//				// 爆品，超级返已售件数
//			}
//
//			grouppOrderProductsVo.setProductParamInfo(productParamInfo);
//			grouppOrderProductsVos.add(grouppOrderProductsVo);
//		}
//
//		// map遍历,set活动页信息,放入正确的下标，活动页排序
//		for (Map.Entry<String, String> entry : indexMap.entrySet()) {
//			GrouppOrderProductsVo grouppOrderProductsVo = new GrouppOrderProductsVo();
//			// 获取首页中的活动页
//			// 拉取缓存
////			ActivityPage activityPage = JSONObject.parseObject(
////					gcache.hget("meidian-restful-grouporder", entry.getValue() + "_" + areaCode), ActivityPage.class);
//			ActivityPage activityPage = JSONObject.parseObject(
//					gcache.get(entry.getValue() + "_" + areaCode), ActivityPage.class);
//
//			if (null == activityPage) {
//				activityPage = this.getActivityPage(entry.getValue(), areaCode, organizationId, request);
//				// 添加到缓存
////				gcache.hset("meidian-restful-grouporder", entry.getValue() + "_" + areaCode,
////						JSONUtils.toJSONString(activityPage).getBytes());
//				gcache.setex(entry.getValue() + "_" + areaCode, 3 * 60, JSONUtils.toJSONString(activityPage).getBytes());
//			}
//
//			// set 副标题名
//			if (activityPage.getSlot() != null) {
//				for (ProductIdActivityId productIdActivityId : productIdActivityIds) {
//					String uk = productIdActivityId.getUkey();
//					if (StringUtils.isNotBlank(uk) && uk.equalsIgnoreCase(entry.getValue())) {
//						activityPage.getSlot().setLink_name(productIdActivityId.getLink_name());
//					}
//				}
//			}
//
//			grouppOrderProductsVo.setActivityPage(activityPage);
//			if (grouppOrderProductsVos.size() <= Integer.parseInt(entry.getKey())) {
//				grouppOrderProductsVos.add(grouppOrderProductsVo);
//			} else {
//				grouppOrderProductsVos.add(Integer.parseInt(entry.getKey()), grouppOrderProductsVo);
//			}
//		}
//
//		// 获取购买返
////		if(commonGoodsReqDtos.size() > 0)
////			this.getBuyRebates(grouppOrderProductsVos, commonGoodsReqDtos);
//
//		return grouppOrderProductsVos;
//	}

    /**
     * 获取地址四级联动
     *
     * @param code           父级code
     * @param level          父级级别
     * @param type           业务类型
     * @param gpsLongitude   经度
     * @param gpsLatitude    纬度
     * @param coordinateName 坐标类型
     * @return
     */
    @SuppressWarnings("deprecation")
    public Map<String, Object> getAreas(String code, Integer level, Integer type, String gpsLongitude,
                                        String gpsLatitude, String coordinateName) {
        HttpGet httpGet = new HttpGet();

        // 组装参数
        Map<String, Object> map = new HashMap<>();
        map.put("type", type);
        map.put("gpsLongitude", gpsLongitude);
        map.put("gpsLatitude", gpsLatitude);
        map.put("coordinateName", coordinateName);

        List<Map<String, Object>> areas = new ArrayList<>();
        Map<String, Object> area = new HashMap<>();
        area.put("code", code);
        area.put("level", level);

        areas.add(area);

        map.put("areas", areas);

        StringBuffer sb = new StringBuffer();
        sb.append(this.areaList + "?body=").append(URLEncoder.encode(JSONUtils.toJSONString(map)));

        httpGet.setURI(URI.create(sb.toString()));

        String result = httpClientUtil.doGet(httpGet);

        Map<String, Object> resultMap = new HashMap<>();
        if (StringUtils.isNotBlank(result)) {
            JSONObject resultObj = JSONObject.parseObject(result);
            if (resultObj != null && !resultObj.isEmpty()) {
                JSONArray areaLv = resultObj.getJSONArray("areaLv" + (level + 1));
                String levels = resultObj.getString("levels");

                resultMap.put("areas", areaLv);
                resultMap.put("level", levels);
            }
        }

        return resultMap;
    }

    /**
     * 商品详情
     *
     * @param productId  商品ID
     * @param skuId      商品SKUID
     * @param userId     用户ID
     * @param activityId 活动ID
     * @param groupId    团ID，可为空
     * @param areaCode   区域码
     * @param priceStoreCode   加盟店取价门店编码
     * @return
     * @throws ServiceException
     */
    public Map<String, Object> getProductInfo(Long activityId, Long groupId, Long userId, 
    		String productId, String skuId, String areaCode, 
    		String orgCode, String storeCode, Integer ppi, 
    		Byte ua, String site, String lat, String lng) throws ServiceException {

        Map<String, Object> resultMap = new HashMap<>();
        ProductDetailVo productDetail = new ProductDetailVo();

        // 商品详情 凑单详情
        ProductManagementVo proManageVo = this.getProductInfoById(activityId, productId, areaCode, skuId);
        ProductVo productVo = copyProduct(proManageVo);
        productVo.setProductId(productId);
        productVo.setHelpAllow(proManageVo.getHelpAllow());
        productVo.setInitialMaxMoney(proManageVo.getInitialMaxMoney());
        // 获取分辨率
        String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
        // 商品图url处理
        productVo.setProductImage(ImageUtils.imageUrlInfo(productVo.getProductImage(), ratio, ua));

        // 美店价
        MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productId, skuId, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
        if (null != meidianPrice) {
            String mPrice = meidianPrice.getMeidianPrice();
            if (null == mPrice) {
                productVo.setMeidianPrice(DoubleUtils.switchScientificCalculate(productVo.getPrice()));
                productVo.setPriceKey(null);
            } else {
                productVo.setMeidianPrice(mPrice);
                productVo.setPriceKey(meidianPrice.getPriceKey());
            }
            productVo.setPriceType(meidianPrice.getPriceType());

        } else {
            productVo.setMeidianPrice(DoubleUtils.switchScientificCalculate(productVo.getPrice()));
            productVo.setPriceKey(null);
        }

        // 折扣返
        Double meiPrice = Double.valueOf(productVo.getMeidianPrice());
        Double pr = DoubleUtils.mul(meiPrice, 100d);
        productVo.setRebateAmount(this.getRebateAmount(pr.longValue(), productVo.getMaxDiscount()));

        // 国美价，美店价处理，美店价大于国美价时，把美店价赋值给国美价
        if (meiPrice.doubleValue() > productVo.getPrice().doubleValue())
            productVo.setPrice(meiPrice);

        productDetail.setProduct(productVo);

        // 团信息
        GroupInfomationVo groupInfomationVo = null;

        GroupInfoVo groupInfo = this.getGroupInfoById(activityId, groupId, areaCode, skuId, null);
        if (groupInfo != null) {
            groupInfomationVo = this.copyGroupInfo(groupInfo);
            groupInfomationVo.setProductInfo(null);
            // 处理用户头像
            if (null != groupInfomationVo.getGroupUser() && groupInfomationVo.getGroupUser().size() > 0)
                ImageUtils.userImageUrlInfo(groupInfomationVo.getGroupUser(), userImage, agreement);
            productDetail.setGroupInfo(groupInfomationVo);
        } else {
            groupInfomationVo = new GroupInfomationVo();
            groupInfomationVo.setStartTime(proManageVo.getEffectiveStartTime());
            groupInfomationVo.setEndTime(proManageVo.getEffectiveEndTime());
            groupInfomationVo.setGroupBusType(proManageVo.getGroupBusType());
            productDetail.setGroupInfo(groupInfomationVo);
        }

        // 团操作状态信息
        if (userId != null && null != groupId && groupId != 0) {
            CommonResultEntity<UserToGroupStatusVo> operationResult = gorderInfoForAppNewResource
                    .getStatusToGroup(activityId, groupId, userId);
            if (operationResult != null) {
                if (operationResult.getBusinessObj() != null) {
                    int status = operationResult.getBusinessObj().getStatus();
                    if (groupInfomationVo != null) {
                        if (groupInfomationVo.getStatus().longValue() == 0) {
                            if (groupInfomationVo.getHeaderUserId().longValue() == userId.longValue()) {
                                productDetail.setOperationStatus(3);
                            } else {
                                productDetail.setOperationStatus(2);
                            }
                        } else {
                            productDetail.setOperationStatus(status);
                        }
                    } else {
                        productDetail.setOperationStatus(status);
                    }
                } else {
                    productDetail.setOperationStatus(2);
                }
            }
        } else {
            productDetail.setOperationStatus(2);
        }

        if (productDetail.getOperationStatus() != 1) {
            if (proManageVo.getEffectiveEndTime().getTime() < System.currentTimeMillis()) {
                productDetail.setOperationStatus(4);
            }
        }

        List<String> productId_skuIdList = new ArrayList<String>(1);
        StringBuilder sb = new StringBuilder(productId);
        sb.append("_").append(skuId);
        productId_skuIdList.add(sb.toString());
        List<CommodityVo> result = accessGoodsService.getProductStatus(productId_skuIdList);
        // 查询商品上下架状态
        if (null != result && result.get(0) != null) {
            int status = result.get(0).getStatus();
            if (status != 1) {
                // 商品本身已下架
                productDetail.setOperationStatus(4);
            }
        }

        // 商品详情tab
        productDetail.setProductInfo(this.getProductDetail(productId, skuId, areaCode));

        //获取节能补贴（政府）或者节能优惠（国美）
        //北京地区使用节能补贴，非北京地区使用节能优惠
        String skuNo = null;
        if (StringUtils.isNotBlank(productDetail.getProduct().getSkuNo())) {
            skuNo = productDetail.getProduct().getSkuNo();
        } else {
            SkuItem sku = this.getSkuInfo(productId, skuId);
            skuNo = sku.getSkuNo();
        }
        
        //加盟店价格逻辑begin  如果有加盟店价格，不展现 节能补贴 节能优惠
        if(meidianPrice !=null && meidianPrice.getPriceType() != null && !meidianPrice.getPriceType().equals("SHOP_PRICE")){
            if (areaCode.startsWith("110")) {
                //节能补贴
                if (null != proManageVo.getAllowanceFlag() && proManageVo.getAllowanceFlag() == 1) {
//                    SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceById(skuId, areaCode);

//                    SkuEnergyAllowance skuEnergyAllowance = null;
//                    if (StringUtils.isNotBlank(storeCode) && storeCode.length() == 4 && !storeCode.startsWith("QDMD")) {
                	if(StringUtils.isNotBlank(storeCode)){
                		Store store = storeManager.getStoreInfo(storeCode, GroupOrderConstants.GET_ORGCODE_BY_STORECODE_STORETYPE, lng, lat);
                		if(null != store){
                			orgCode = store.getOrganizationId();
                		}
                	}
                	SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceByNo(skuNo, orgCode);
//                    }
                    if (null != skuEnergyAllowance) {
                        //显示价大于报备价，则不展示节能补贴
                        if (null != skuEnergyAllowance.getRecordPrice() && productDetail.getProduct().getPrice().doubleValue() <= skuEnergyAllowance.getRecordPrice().doubleValue()) {
                            SkuEnergyAllowanceVo skuEnergyAllowanceVo = new SkuEnergyAllowanceVo();
                            BeanUtils.copyProperties(skuEnergyAllowance, skuEnergyAllowanceVo);
                            productDetail.setSkuEnergyAllowance(skuEnergyAllowanceVo);
                        }
                    }
                }
            } else {
                EnergySavingSubsidiesParamDTO param = new EnergySavingSubsidiesParamDTO();
                param.setSkuNo(skuNo);
                if (StringUtils.isNotBlank(productDetail.getProduct().getSkuNo())) {
                    param.setSkuNo(productDetail.getProduct().getSkuNo());
                } else {
                    SkuItem sku = this.getSkuInfo(productId, skuId);
                    param.setSkuNo(sku.getSkuNo());
                }
                PromotionScopeDTO scope = new PromotionScopeDTO();
                scope.setAreaCode(areaCode);
                scope.setStoreCode(storeCode);
                scope.setSite(GroupOrderConstants.ENERGY_SAVING_SUBSIDIES_MEIDIAN_SITE);

                String uId = null == userId ? null : userId.toString();
                ResultDTO<EnergySavingSubsidiesResultDTO> resultDto = energySavingSubsidiesClient.getEnergySavingSubsidiesBySkuNo(uId, param, scope, "detail");
                if (null != resultDto && resultDto.isSuccess()) {
                    EnergySavingSubsidiesResultDTO dto = resultDto.getData();
                    if (null != dto) {
                        EnergySavingSubsidiesVo dtoVo = new EnergySavingSubsidiesVo();
                        BeanUtils.copyProperties(dto, dtoVo);
                        productDetail.setEnergySavingSubsidies(dtoVo);
                    }
                }
            }
        }
        



        // 延保
        if ((proManageVo.getGroupBusType() == null ? 3 : proManageVo.getGroupBusType().intValue()) != GroupOrderConstants.free_group) {
            Integer warranty = this.appreciationServeCheckout(productVo.getSkuNo(), productVo.getMeidianPrice(), orgCode);
            productDetail.setWarranty(warranty);
        }

        resultMap.put("data", productDetail);
        return resultMap;
    }

    /**
     * 获取凑单信息
     *
     * @param activityId
     * @param productId
     * @param areaCode
     * @return
     */
    public ProductManagementVo getProductInfoById(Long activityId, String productId, String areaCode, String skuId) {
        CommonResultEntity<ProductManagementVo> productResult = gorderInfoForAppNewResource.getProductInfoById(activityId,
                productId, areaCode, skuId);
        if (productResult != null) {
            return productResult.getBusinessObj();
        }
        return null;
    }

    /**
     * 获取团信息
     *
     * @param groupId
     * @param areaCode
     * @return
     */
    public GroupInfoVo getGroupInfoById(Long activityId, Long groupId, String areaCode, String skuId, String orderId) {
        CommonResultEntity<GroupInfoVo> groupInfoResult = null;

        if (null != groupId && groupId != 0) {
            groupInfoResult = gorderInfoForAppNewResource.getGroupInfoById(groupId, areaCode, skuId, null, orderId);
        } else {
            groupInfoResult = gorderInfoForAppNewResource.getGroupInfo(activityId, areaCode, skuId);
        }
        if (groupInfoResult != null) {
            GroupInfoVo groupInfo = groupInfoResult.getBusinessObj();
            return groupInfo;
        }
        return null;
    }

    /**
     * 获取商品介绍，售后，包装信息
     *
     * @param productId
     * @param skuId
     * @param areaCode
     * @return
     */
    public ProductInfoVo getProductDetail(String productId, String skuId, String areaCode) throws ServiceException{
        ProductInfoVo productInfo = new ProductInfoVo();
        // 商品信息 状态1为上架状态
        GoodsInfoFull goodInfo = productInfoService.getGoodsFull(productId, skuId, "");
        if (null != goodInfo) {
            if (goodInfo.getProductStatus() == 1) {
                productInfo.setProductId(goodInfo.getProductId());
                productInfo.setSkuId(goodInfo.getSkuId());
                // 商品介绍
                productInfo.setProductDesc(null == goodInfo.getPrdDescription() ? ""
                        : goodInfo.getPrdDescription().replace(".html", "_mobile.html"));
                // 商品介绍协议处理
                productInfo.setProDes(this.proDes(productInfo.getProductDesc()));
                
                // 售后
                productInfo.setAfterSaleService(goodInfo.getProductService());
                // 包装，清单
                productInfo.setPackings(goodInfo.getPackingList());
            }
        }

        // 商品详情 规格参数
        PrdSpecBean specBean = prodSpecService.getSpec(productId, skuId);
        if (null != specBean) {
            productInfo.setSpecifications(null == specBean.getResult() ? null : specBean.getResult().get("returnList"));
        }

        return productInfo;
    }

    /**
     * 开团/参团
     *
     * @param userId
     * @param groupId
     * @param activityId
     * @param productId
     * @param buyNumber
     * @param skuNo
     * @param areaCode
     * @return
     * @throws ServiceException
     */
    public Map<String, Object> attendGroup(
            Long userId, Long groupId, Long activityId,
            String productId, Integer buyNumber, String skuId,
            String areaCode, String kid, Integer modeType,
            String flowActivityId, String pagecode, String staffId,
            String storeCode, String channel)
            throws ServiceException {

        logger.info("attend group: userId = {} activityId = {}", userId, activityId);
        List<String> productId_skuIdList = new ArrayList<String>(1);
        StringBuilder sb = new StringBuilder(productId);
        sb.append("_").append(skuId);
        productId_skuIdList.add(sb.toString());
        List<CommodityVo> result = accessGoodsService.getProductStatus(productId_skuIdList);
        // 查询商品上下架状态
        if (null != result && result.get(0) != null) {
            int status = result.get(0).getStatus();
            if (status != 1) {
                // 商品本身已下架
                throw new ServiceException("goods.status.pullOff");
            }
        }

        Map<String, Object> resultMap = new HashMap<>();
        GroupOrderInfoVo groupOrderInfoVo = null;

        CommonResultEntity<GroupInfoVo> resultVo = gorderInfoForAppNewResource.attendGroup(userId, groupId, activityId,
                productId, buyNumber, skuId, areaCode, modeType);

        if (resultVo.getCode() == 455) {
            throw new ServiceException("attendGroup.number.limit");
        }
        if (resultVo.getCode() == 456) {
            throw new ServiceException("attendGroup.product.numCheck");
        }
        if (478 == resultVo.getCode()) {
            throw new ServiceException("attendGroup.product.activity.notMatch");
        }
        resultMap = resultMapConvert(resultMap, resultVo);

        if (resultVo != null) {
            GroupInfoVo groupInfoVo = resultVo.getBusinessObj();
            if (groupInfoVo != null) {
                kid = "TUAN_" + groupInfoVo.getId() + "_" + kid + "_" + "isPay" + "_skuId" + "_" + skuId;
                Integer groupType = groupInfoVo.getGroupBusType();
                if (null != flowActivityId) {
                    if (null != groupType) {
//						if(groupType.intValue() == GroupOrderConstants.GROUP_ZERO_TYPE
//								|| groupType.intValue() == GroupOrderConstants.GROUP_FLOW_TYPE
//								|| groupType.intValue() == GroupOrderConstants.GROUP_CHANNEL_TYPE
//								|| groupType.intValue() == GroupOrderConstants.GROUP_FLOW_COMMON
//								|| groupType.intValue() == GroupOrderConstants.GROUP_COMMUNITY_COMMON
//								){

                        if (null == pagecode
                                || null == storeCode
                                || null == productId
                        ) {
                            throw new ServiceException("collectFlow.param.null");
                        }
                        if (null == staffId || staffId.equalsIgnoreCase(""))
                            staffId = String.valueOf(userId);
                        kid = kid + "_" + "jkId" + "-" + flowActivityId + "-" + pagecode + "-" + staffId + "-" + storeCode + "-" + productId;
//						}
                    }
                }
                
                if(StringUtils.isNotBlank(channel)) {
                	kid = kid + "_" + channel;
                }
                
                if (null != groupInfoVo.getFailGroupRefund()) {
                    if (!kid.startsWith("TUAN_0") && groupInfoVo.getFailGroupRefund() == 1) {
                        kid = kid + "_OMS";
                    }
                }

                groupOrderInfoVo = new GroupOrderInfoVo(groupInfoVo.getId(), groupInfoVo.getActivityId(), "8",
                        productId, skuId, buyNumber, userId, null, null, null,
                        this.orderUrl, kid, returnUrl + "?tuanId=" + kid + "&isPay=1");
            }
        }

        if (groupOrderInfoVo != null) {
            Map<String, Object> paraMap = new HashMap<>();
            paraMap.put("goodsNo", groupOrderInfoVo.getProductId());
            paraMap.put("skuID", groupOrderInfoVo.getSkuId());
            paraMap.put("businessType", groupOrderInfoVo.getBusinessType());
            paraMap.put("pId", "");
            paraMap.put("prdAndSkus", "");
            paraMap.put("activityType", "");
            paraMap.put("activityId", "");
            paraMap.put("addServices", new Object());
            paraMap.put("buyCount", groupOrderInfoVo.getBuyNumber().toString());
            paraMap.put("staffId", groupOrderInfoVo.getUserId().toString());
            paraMap.put("fanliKeyId", groupOrderInfoVo.getKid());
            Object obj = JSONObject.toJSON(paraMap);
            groupOrderInfoVo.setBuyGoods(obj);
        }

        resultMap.put("data", groupOrderInfoVo);

        return resultMap;
    }

    /**
     * 我的凑单列表
     *
     * @param userId   用户ID
     * @param status   状态
     * @param pageNum  页码
     * @param pageSize 条数
     * @param request
     * @return
     */
	public Map<String, Object> getMyGroupOrderList(Long userId, Integer status, Integer pageNum, Integer pageSize, String reqChannel, 
			HttpServletRequest request) {
		Map<String, Object> resultMap = new HashMap<>();
		CommonResultEntity<MyGroupOrderVo> getMyGroupOrderList = null;
		if("MINI".equals(reqChannel)) {
			getMyGroupOrderList = gorderInfoForAppNewResource.getMyGroupOrderListForMuti(userId, status, pageNum, pageSize);
		} else {
			getMyGroupOrderList = gorderInfoForAppNewResource.getMyGroupOrderList(userId,
					status, pageNum, pageSize);
		}

		resultMap = resultMapConvert(resultMap, getMyGroupOrderList);

		List<String> orderIds = new ArrayList<>();
		Map<String, GroupMemberVo> groupMemberMap = new LinkedHashMap<>();
		Map<String, Object> data = new HashMap<>();
		if (getMyGroupOrderList != null) {
			MyGroupOrderVo groupOrder = getMyGroupOrderList.getBusinessObj();
			List<GroupMemberVo> groupMemList = groupOrder.getGroupOrderInfo();

            if (groupMemList != null && groupMemList.size() > 0) {
                for (GroupMemberVo mem : groupMemList) {
                    if (StringUtils.isNotBlank(mem.getOrderId())) {
                        groupMemberMap.put(mem.getOrderId(), mem);
                        orderIds.add(mem.getOrderId());

                    }
                }
            }

            PageInfoVo page = new PageInfoVo();
            page.setCurrPageNo(pageNum);
            page.setPageSize(pageSize);
            page.setTotalCount(groupOrder.getTotalNum());

            data.put("page", page);
        }

        List<MyGroupOrderInfoVo> myGroupOrderList = new ArrayList<>();
        Map<String, Object> shipListMap = this.getShipList(orderIds, request);
        if (null != shipListMap && !shipListMap.isEmpty()) {
            for (Map.Entry<String, GroupMemberVo> en : groupMemberMap.entrySet()) {
                String id = en.getKey();
                MyGroupOrderInfoVo orderVo = new MyGroupOrderInfoVo();
                BeanUtils.copyProperties(en.getValue(), orderVo);
                orderVo.setGroupBusType(en.getValue().getGroupInfoVo().getGroupBusType());
                if (shipListMap.containsKey(id)) {
                    Map<String, List<Object>> mm = new HashMap<>();
                    mm.put("shipViewResults", Arrays.asList(shipListMap.get(id)));
                    orderVo.setShipOrder(mm);
                    myGroupOrderList.add(orderVo);
                }


            }
        }
        data.put("results", myGroupOrderList);
        resultMap.put("data", data);
        return resultMap;
    }

    /**
     * 获取配送单信息
     *
     * @param orderIds
     * @param request
     * @return
     */
    public Map<String, Object> getShipList(List<String> orderIds, HttpServletRequest request) {

        // 获取订单信息
        if (orderIds.isEmpty()) {
            return null;
        }

        StringBuffer spBuffer = new StringBuffer();
        StringBuffer unspBuffer = new StringBuffer();

        List<OrderInfo> orderInfos = orderQueryService.getOrderInfoByOrderIds(orderIds);
        for (OrderInfo order : orderInfos) {
            if ("0".equals(order.getSplitType())) {
                // 未拆单
                unspBuffer.append(order.getOrderId()).append("*");
            }

            if ("1".equals(order.getSplitType())) {
                // 拆单
                spBuffer.append(order.getOrderId()).append("*");
            }
        }

        HttpGet httpGet = new HttpGet();
        httpGet.addHeader("Cookie", request.getHeader("Cookie"));
        httpGet.addHeader("Referer", this.orderRefer);
        httpGet.setURI(URI.create(this.getShipListURL + "?spOrderIds=" + spBuffer.toString() + "&unSpOrderIds="
                + unspBuffer.toString()));
        String result = httpClientUtil.doGet(httpGet);
        JSONObject resultObj = null;
        Map<String, Object> shipListMap = new HashMap<>();
        if (StringUtils.isNotBlank(result)) {
            JSONObject jsonObj = JSONObject.parseObject(result);
            if (jsonObj != null && !jsonObj.isEmpty()) {
                resultObj = jsonObj.getJSONObject("result");
                if (resultObj != null && resultObj.containsKey("shipViewResults")) {
                    JSONArray arr = resultObj.getJSONArray("shipViewResults");
                    for (int i = 0; i < arr.size(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        JSONArray items = o.getJSONArray("itemList");
                        if (null != items && items.size() > 0) {
                            for (int j = 0; j < items.size(); j++) {
                                JSONObject item = items.getJSONObject(j);
                                if (null == item) continue;
                                String skuType = item.getString("skuType");
                                if (null == skuType || skuType.equalsIgnoreCase("")) continue;

                                // 过滤延保订单
                                if (!skuType.equalsIgnoreCase("ZYB")
                                        && !skuType.equalsIgnoreCase("ZPSB")
                                        && !skuType.equalsIgnoreCase("ZYWB")
                                ) {

                                    shipListMap.put(o.getString("orderId"), o);
                                }
                            }
                        }
                    }
                }
            }
        }

        return shipListMap;
    }

    /**
     * 根据团ID获取团成员列表
     *
     * @param groupId
     * @return
     */
    public GroupMemberListVo getGroupMemberById(Long groupId) {
        CommonResultEntity<GroupMemberListVo> resultVo = gorderInfoForAppNewResource.getGroupMemberById(groupId);
        if (resultVo != null) {
            return resultVo.getBusinessObj();
        }
        return null;
    }

    /**
     * 根据活动id，团id和userId 查询该用户对团的操作情况
     *
     * @return
     * @throws ServiceException
     */
    public int getStatusToGroup(Long activityId, Long groupId, Long userId) throws ServiceException {

        CommonResultEntity<UserToGroupStatusVo> commonResultEntity = gorderInfoForAppNewResource
                .getStatusToGroup(activityId, groupId, userId);

        logger.debug("getStatusToGroup ==> {}", JSONUtils.toJSONString(commonResultEntity));

        if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
            return commonResultEntity.getBusinessObj().getStatus();
        } else {
            logger.error("getStatusToGroup: {} userId ==> {} ", JSONUtils.toJSONString(commonResultEntity), userId);
        }
        return 4;
    }

    /**
     * 当前活动中正在进行中的团活动数量
     *
     * @return
     * @throws ServiceException
     */
    public Long getGroupNum(Long activityId) throws ServiceException {

        CommonResultEntity<ActivationGroupVo> commonResultEntity = gorderInfoForAppNewResource
                .getActivationGroupNum(activityId);

        logger.debug("getGroupNum ==> {}", JSONUtils.toJSONString(commonResultEntity));

        if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
            logger.info("getGroupNum: {} activityId ==> {} ", activityId);
            return commonResultEntity.getBusinessObj().getNum();
        } else {
            logger.error("activityId: {} getGroupNum ==> {}  ", activityId, JSONUtils.toJSONString(commonResultEntity));
        }

        return null;
    }

    /**
     * 根据活动id获取阶梯信息
     *
     * @return
     */
    public StepsVo getStepsConfig(Long activityId) {

        CommonResultEntity<StepsConfigVo> commonResultEntity = gorderInfoForAppNewResource.getStepsConfig(activityId);

        logger.debug("getStepsConfig ==> {}", JSONUtils.toJSONString(commonResultEntity));

        if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
            logger.info("getStepsConfig activityId ==> {} ", activityId);
            StepsConfigVo stepsConfigVo = commonResultEntity.getBusinessObj();
            StepsVo stepsVo = new StepsVo();
            stepsVo.setStepsNum(stepsConfigVo.getStepsNum());
            List<CurrentStepsVo> currentStepsVos = JSONObject.parseArray(stepsConfigVo.getStepsConfigStr(),
                    CurrentStepsVo.class);
            stepsVo.setCurrentStepsVos(currentStepsVos);

            return stepsVo;
        } else {
            logger.error("activityId:{} getStepsConfig ==> {} ", activityId,
                    JSONUtils.toJSONString(commonResultEntity));
        }

        return null;
    }

    /**
     * 更多推荐接口
     *
     * @return
     */
    public FirstClassificationProductsVo getMoreProducts(Long activityId, String areaCode, String firstClassificationId,
                                                         String productId, Integer pageNum, Integer pageSize) {

        CommonResultEntity<FirstClassificationProductsVo> commonResultEntity = gorderInfoForAppNewResource
                .getMoreProducts(activityId, areaCode, firstClassificationId, productId, pageNum, pageSize);

        logger.debug("getMoreProducts ==> {}", JSONUtils.toJSONString(commonResultEntity));

        if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
            logger.info("getMoreProducts productId ==> {} ", productId);
            return commonResultEntity.getBusinessObj();
        } else {
            logger.error("productId: {} getMoreProducts ==> {} ", productId,
                    JSONUtils.toJSONString(commonResultEntity));
        }

        return null;
    }

    /**
     * 换取返利kid
     *
     * @param shareKidVo
     * @return
     */
    public Map<String, String> shareUrlByKid(ShareKidVo shareKidVo) {

        UrlReqDto urlReqDto = new UrlReqDto();
        BeanUtils.copyProperties(shareKidVo, urlReqDto);
        UrlResDto resultKid = iDubboBuyersService.shareUrlByKid(urlReqDto);

//		logger.debug("shareUrlByKid ==> {} ", JSONUtils.toJSONString(resultKid));

        Map<String, String> map = new HashMap<String, String>();
        if (resultKid != null && StringUtils.equals(REBATE_SUCCESS, resultKid.getErrorCode())) {
//			logger.info("shareUrlByKid kid ==> {} ", resultKid.getShareKey());
			map.put("kid", resultKid.getShareKey());
		} else {
			logger.error("shareUrlByKid ==> {} ", resultKid.getErrorCode() + resultKid.getErrorMessage());
			map.put("kid", null);
		}

		return map;
	}

	/**
	 * 转换对象
	 * 
	 * @param a
	 * @return
	 */
	public ProductVo copyProduct(ProductManagementVo a) {
		if (a != null) {
			return new ProductVo("",a.getProductId(), a.getSkuId(),a.getSkuNo(), a.getSkuAttribute(), a.getName(),
					this.imageUrlConvert(a.getProductImage()), a.getProductTag(), this.getPrice(a.getPrice()),
					a.getActivityId(), a.getEffectiveStartTime(), a.getEffectiveEndTime(), a.getFirstClassificationId(),
					a.getFirstClassificationName(), this.getMaxDiscountPrice(a.getPrice(), a.getMaxDiscount()),
					this.convertStepsConfig(a.getStepsConfig()), this.getRebateAmount(a.getPrice(), a.getMaxDiscount()),
					a.getMaxDiscount(), a.getMiniDiscount(), a.getMaxDiscountNeedPeopleNum(),
					a.getMiniDiscountNeedPeopleNum(), a.getLimitBuyNum(), new Date(),
					(a.getTotalBuyNumber() == null ? 0 : a.getTotalBuyNumber())
							* (a.getIrrigationNumbe() == null || a.getIrrigationNumbe() == 0 ? 1
									: a.getIrrigationNumbe()),
					a.getProductStatus(), a.getShopId(), a.getIrrigationNumbe(),
					a.getModeType()
					);
		} else {
			return null;
		}

	}

	/**
	 * 转换对象
	 * 
	 * @param a
	 * @return
	 */
	private GroupInfomationVo copyGroupInfo(GroupInfoVo a) {
		if (a != null) {
			return new GroupInfomationVo(a.getId(), a.getActivityId(), a.getStatus(), a.getStartTime(), a.getEndTime(),
					a.getProductId(), a.getHeaderUserId(), a.getCurrentDiscount(), a.getNextDiscount(),
					a.getNextDtNeedPeopleNum(), a.getMaxDiscount(), a.getMiniDiscount(),
					a.getMiniDiscountNeedPeopleNum(), a.getMaxDiscountNeedPeopleNum(), a.getTotalSave(),
					a.getStepsNum(), this.convertStepsConfig(a.getStepsConfig()), a.getBuyNumber(), a.getGroupUser(),
					a.getProductInfo(), a.getCurrentMemberNum(), a.getGroupBusType(),
					a.getModeType()
					);
		} else {
			return null;
		}
	}

	/**
	 * 价格单位转换
	 * 
	 * @param price
	 * @return
	 */
	public double getPrice(Long price) {
		if (price == null) {
			price = 0L;
		}

		return BigDecimalUtils.div(price.doubleValue(), 100d, 2);
	}

	/**
	 * 最大折扣价
	 * 
	 * @param price
	 * @param maxDiscount
	 * @return
	 */
	private double getMaxDiscountPrice(Long price, Float maxDiscount) {
		if (price == null) {
			price = 0L;
		}

		if (maxDiscount == null) {
			maxDiscount = 10F;
		}
		return BigDecimalUtils.round(this.getPrice(price) - this.getRebateAmount(price, maxDiscount), 2);

	}

	/**
	 * 返利的折扣金额
	 * 
	 * @param price
	 * @param maxDiscount
	 * @return
	 */
	public double getRebateAmount(Long price, Float maxDiscount) {
		if (price == null) {
			price = 0L;
		}

		if (maxDiscount == null) {
			maxDiscount = 10F;
		}
		return BigDecimalUtils.round(BigDecimalUtils.div(
				BigDecimalUtils.mul(price.doubleValue(), BigDecimalUtils.sub(10d, maxDiscount.doubleValue())), 1000d,
				2), 2);
	}

	/**
	 * 返回结果集信息处理
	 * 
	 * @param map
	 * @param resultEntity
	 * @return
	 */
	private Map<String, Object> resultMapConvert(Map<String, Object> map,
			CommonResultEntity<? extends Object> resultEntity) {
		if (resultEntity.getCode() == 422) {
			map.put("code", StatusCode.VALIDATION_FAILED.getCode());
			map.put("message", StatusCode.VALIDATION_FAILED.getMsg());
		}

		if (resultEntity.getCode() == 404 || resultEntity.getCode() == 0) {
			map.put("code", StatusCode.SUCCESS.getCode());
			map.put("message", StatusCode.SUCCESS.getMsg());
		}

		if (resultEntity.getCode() == 500) {
			map.put("code", StatusCode.SYSTEM_ERROR.getCode());
			map.put("message", StatusCode.SYSTEM_ERROR.getMsg());
		}
		return map;
	}

	/**
	 * 替换协议
	 * 
	 * @param imageUrl
	 *            图片
	 * @param currentUrlType
	 *            请求
	 * @return
	 */
	private String imageUrlConvert(String imageUrl) {
		if (StringUtils.isBlank(imageUrl)) {
			return null;
		} else {
//			if (imageUrl.contains("http:") && currentUrlType.equals("https:")) {
//				imageUrl = imageUrl.replace("http:", "https:");
//			}
//			if (imageUrl.contains("http:") && currentUrlType.equals("http:")) {
//				imageUrl = imageUrl.replace("http:", "https:");
//			}

            if (imageUrl.contains("http:"))
                imageUrl = imageUrl.replace("http:", agreement);
            return imageUrl;
        }
    }

    /**
     * 获取当前协议类型
     *
     * @param url
     * @return
     */
    public String getCurrentUrlType(String url) {
        if (StringUtils.isBlank(url)) {
            return null;
        }

        if (url.contains("http:")) {
            return "http:";
        }

        if (url.contains("https:")) {
            return "https:";
        }

        return null;
    }

    /**
     * 解析凑单返利阶梯
     *
     * @param stepsConfig
     * @return
     */
    private List<StepsConfig> convertStepsConfig(String stepsConfig) {
        if (StringUtils.isBlank(stepsConfig)) {
            return new ArrayList<>();
        }
        List<StepsConfig> stepsConfigList = JSONObject.parseArray(stepsConfig, StepsConfig.class);

        return stepsConfigList;
    }

    /**
     * 根据uk获取凑单，爆品，banner图和商品id，活动id，优惠劵，活动页ukey
     *
     * @param uniqueKey
     * @return
     * @throws ServiceException
     */
    public BannerProductIdVo getProductIds(String uniqueKey, Integer ppi, Byte ua, HttpServletRequest request) throws ServiceException {
        Map<String, Object> map = new HashMap<String, Object>();
        BannerProductIdVo bannerProductIdVo = new BannerProductIdVo();
        map.put("unique_key", uniqueKey);
        String result = null;
        JSONObject data = null;
        data = JSONObject.parseObject(gcache.get("getProductIds" + "_" + uniqueKey), JSONObject.class);
        if (null == data) {
            try {
                result = httpClientUtil.doGet(productIdsUrl, map);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }

            JSONObject obj = null;
            try {
                obj = JSONObject.parseObject(result);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }


            try {
                data = (JSONObject) obj.get("data");
            } catch (Exception e) {
                // TODO: handle exception
            }


            if (null == data)
                return bannerProductIdVo;

            // 添加缓存20秒
            gcache.setex("getProductIds" + "_" + uniqueKey, 20, JSONObject.toJSONString(data));
        }

        JSONArray products = data.getJSONArray("list");
        List<BannerImage> bannerImages = new ArrayList<BannerImage>();
        List<ProductIdActivityIdVo> productIdActivityIdVos = new ArrayList<ProductIdActivityIdVo>();
        if (null == products || products.size() < 0)
            return bannerProductIdVo;
        for (int i = 0; i < products.size(); i++) {
            JSONObject prod = products.getJSONObject(i);
            Integer type = prod.getInteger("type");
            if (type == 1) {
                // 图片
                JSONArray datas = prod.getJSONArray("datas");
                for (int j = 0; j < datas.size(); j++) {
                    JSONObject js = datas.getJSONObject(j);
                    String image = JSONObject.toJSONString(js, SerializerFeature.WriteMapNullValue);
                    // 改字段名
                    String newImage = image.replaceAll("product_id", "productId");
                    BannerImage bannerImage = js.parseObject(newImage, BannerImage.class);

                    // 替换协议
                    String imageUrl = imageUrlConvert(bannerImage.getImage());
                    // 获取分辨率
                    String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.HOME_BANNER_IMAGE);
                    // 处理分辨率
                    String imageRatio = ImageUtils.imageUrlInfo(imageUrl, ratio, ua);

                    // 域名切换
                    String target = bannerImage.getTarget();
                    if (null != target && !target.equalsIgnoreCase("") && !target.equalsIgnoreCase("3")) {
                        bannerImage.setTarget(ImageUtils.domainInfo(target));
                    }

                    bannerImage.setImage(imageRatio);

                    bannerImages.add(bannerImage);
                }

            } else if (type == 2) {
                List<ProductIdActivityId> productIdActivityIds = new ArrayList<ProductIdActivityId>();
                // 商品
                JSONArray datas = prod.getJSONArray("datas");
                for (int j = 0; j < datas.size(); j++) {
                    JSONObject js = datas.getJSONObject(j);
                    String product = JSONObject.toJSONString(js, SerializerFeature.WriteMapNullValue);
                    // 改字段名
                    String newProduct = product.replaceAll("product_id", "productId")
                            .replaceAll("activity_id", "activityId").replaceAll("sku_id", "skuId")
                            .replaceAll("rebate_id", "rebateId").replace("coupon_type", "couponType")
                            .replaceAll("rebate_type", "rebateType");
                    ProductIdActivityId productIdActivityId = js.parseObject(newProduct, ProductIdActivityId.class);
                    productIdActivityIds.add(productIdActivityId);
                }

                ProductIdActivityIdVo productIdActivityIdVo = new ProductIdActivityIdVo();
                String productTypeName = prod.getString("name");
                productIdActivityIdVo.setProductTypeName(productTypeName);
                productIdActivityIdVo.setProductIdActivityIds(productIdActivityIds);
                productIdActivityIdVos.add(productIdActivityIdVo);
            }
        }

        bannerProductIdVo.setBannerImages(bannerImages);
        bannerProductIdVo.setProductIdActivityIdVos(productIdActivityIdVos);

        return bannerProductIdVo;
    }

//	/**
//	 * 活动页
//	 *
//	 * @param ukey
//	 * @param areaCode
//	 * @param organizationId
//	 * @param request
//	 * @return
//	 */
//	public ActivityPage getActivityPageInfo(String ukey, String areaCode, String organizationId,
//			HttpServletRequest request) {
//
//		ActivityPage activityPage = this.getActivityPage(ukey, areaCode, organizationId, request);
//		// 处理劵后价
//		List<StoreVo> storeVs = activityPage.getStoreVos();
//		if (null == storeVs)
//			return activityPage;
//
//		for (StoreVo storeVo : storeVs) {
//			List<ModelVo> modelVos = storeVo.getModel();
//			for (ModelVo modelVo : modelVos) {
//				// 为商品（爆品）计算劵后价格
//				String type = storeVo.getType();
//				if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {
//					Double couponNum = modelVo.getCoupon_num();
//					String activityId = modelVo.getActivity_id();
//					if (null != couponNum && StringUtils.isBlank(activityId)) {
//						ProductParamInfo productParamInfo = modelVo.getProductParamInfo();
//						productParamInfo.setCouponPrice(DoubleUtils.sub(productParamInfo.getPrice(), couponNum));
//					}
//				}
//			}
//		}
//
//		return activityPage;
//	}

//	/**
//	 * 获取活动页信息
//	 *
//	 * @return
//	 */
//	public ActivityPage getActivityPage(String ukey, String areaCode, String organizationId,
//			HttpServletRequest request) {
//		Map<String, Object> map = new HashMap<String, Object>();
//		map.put("unique_key", ukey);
//		String result = null;
//		try {
//			result = httpClientUtil.doGet(productIdsUrl, map);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		ActivityPage activityPage = new ActivityPage();
//		activityPage.setUkey(ukey);
//		JSONObject obj = JSONObject.parseObject(result);
//
//		JSONObject data = null;
//		try {
//			data = obj.getJSONObject("data");
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		if (null == data)
//			return activityPage;
//
//		// set cms返回值
//		CmsActivityPageVo cmsActivityPageVo = JSONObject.parseObject(
//				result.replaceAll("sku_id", "skuId").replace("rebate_id", "rebateId")
//						.replace("rebate_type", "rebateType").replaceAll("coupon_type", "couponType"),
//				CmsActivityPageVo.class);
//
//		Slot slot = new Slot();
//		BeanUtils.copyProperties(cmsActivityPageVo.getData().getSlot(), slot);
//		activityPage.setSlot(slot);
//
//		List<StoreVo> storeVos = new ArrayList<StoreVo>();
//
//		for (CmsStoreVo cmsStoreVo : cmsActivityPageVo.getData().getList()) {
//			List<ModelVo> models = new ArrayList<ModelVo>();
//			StoreVo storeVo = new StoreVo();
//
//			if (null != cmsStoreVo.getModel()) {
//				for (CmsModel cmsModel : cmsStoreVo.getModel()) {
//					ModelVo modelVo = new ModelVo();
//					BeanUtils.copyProperties(cmsModel, modelVo);
//					models.add(modelVo);
//				}
//				storeVo.setModel(models);
//				storeVo.setColor(cmsStoreVo.getColor());
//				storeVo.setName(cmsStoreVo.getName());
//				storeVo.setOperator_id(cmsStoreVo.getOperator_id());
//				storeVo.setType(cmsStoreVo.getType());
//				storeVo.setUser_id(cmsStoreVo.getUser_id());
//				storeVos.add(storeVo);
//			}
//		}
//		activityPage.setStoreVos(storeVos);
//
//		// 获取商品信息
//		List<ProductIdActivityId> productIdActivityIds = new ArrayList<ProductIdActivityId>();
//		List<StoreVo> stores = activityPage.getStoreVos();
//		for (StoreVo storeVo : stores) {
//			// 如果为图片，不用添加商品信息
//			String type = storeVo.getType();
//			if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
//					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
//					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
//					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
//					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
//					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
//					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {
//
//				List<ModelVo> models = storeVo.getModel();
//				for (ModelVo modelVo : models) {
//					ProductIdActivityId productIdActivityId = new ProductIdActivityId();
//					productIdActivityId.setActivityId(modelVo.getActivity_id());
//					productIdActivityId.setProductId(modelVo.getProduct_id());
//					productIdActivityIds.add(productIdActivityId);
//				}
//			}
//		}
//
//		// 获取商品信息
//		List<ProductVo> productVos = this.getProducts(productIdActivityIds, areaCode);
//		// 过滤下架商品
//		List<String> ids = productVos.stream().map(ProductVo::getProductId).collect(Collectors.toList());
//
//		// set商品信息
//		// 超级返入参
////		List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
//		for (StoreVo storeVo : storeVos) {
//			Iterator<ModelVo> itModel = storeVo.getModel().iterator();
//			while (itModel.hasNext()) {
//				ModelVo modelVo = itModel.next();
//				// 如果为图片，不用添加商品信息
//				String type = storeVo.getType();
//				if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {
//
//					if (!ids.contains(modelVo.getProduct_id())) {
//						// 删除下架商品
//						itModel.remove();
//						continue;
//					}
//
//					for (ProductVo productVo : productVos) {
//						if (productVo.getProductId().equals(modelVo.getProduct_id())) {
//							ProductParamInfo productParamInfo = new ProductParamInfo();
//							BeanUtils.copyProperties(productVo, productParamInfo);
//
//							// 分享佣金
//							RebatePercent rebatePercent = getPrdRebate(productParamInfo.getProductId(),
//									productParamInfo.getSkuId(), organizationId, productParamInfo.getPrice());
//							productParamInfo.setBrokerage(rebatePercent.getShareRebate());
//
//							// 转换http协议
//							if (productParamInfo.getProductImage().contains("http:")) {
//								productParamInfo
//										.setProductImage(productParamInfo.getProductImage().replace("http:", "https:"));
//							}
//
//							modelVo.setProductParamInfo(productParamInfo);
//						}
//					}
//				} else if (type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE_SKIP)
//						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE)
//						|| type.equalsIgnoreCase(GroupOrderConstants.TWO_IMAGE)
//						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_IMAGE)
//						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_COUPON)
//						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_COUPON)
//						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_THREE_IMAGE)
//						|| type.equalsIgnoreCase(GroupOrderConstants.FOUR_IMAGE)
//						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_FIVE_IMAGE)) {
//					// 为图片，更改http协议
//					if (modelVo.getImage().contains("http:")) {
//						modelVo.setImage(modelVo.getImage().replace("http:", "https:"));
//					}
//				}
//
//				// 处理爆品，超级返信息
//				if (StringUtils.isBlank(modelVo.getActivity_id())) {
//					// 优惠券信息，根据劵规则id
//					if (StringUtils.isNotBlank(modelVo.getCoupon_id())) {
//						if (null != modelVo.getCouponType()
//								&& modelVo.getCouponType().equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
//							// pop劵
//							// 根据劵批次id查询pop劵信息
//							CouponBatchResult couponBatchResult = this.getPopCoupon(modelVo.getCoupon_id());
//							if (null != couponBatchResult) {
//								modelVo.setCoupon_num(couponBatchResult.getDenomination()); // 面额
//								modelVo.setDescription(couponBatchResult.getDescription());
//								modelVo.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
//								modelVo.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券,
//																									// 2:平台券
//								modelVo.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
//							}
//						} else {
//							// 美劵，只是为了区别调用接口，红蓝劵暂时任务和美劵类型一样
//							if (StringUtils.isNotBlank(modelVo.getCoupon_id())) {
//								CouponRuleInfo couponData = this.getCoupon(modelVo.getCoupon_id());
//								if (null != couponData) {
//									modelVo.setCoupon_num(couponData.getAmount());
//									modelVo.setFullAmount(couponData.getLimitAmount());
//									modelVo.setCouponType(couponData.getType());
//								}
//							}
//						}
//					} else {
//
//
//
//
//
//
//
//						// 不是组团和爆品就是购买返
//						// 超级返入参
////						if (null != modelVo.getSkuId() && !modelVo.getSkuId().equalsIgnoreCase("")) {
////							CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
////							// 返利key，自定义，作为返回多个值的区分,以productId,skuNo作为key
////							commonGoodsReqDto.setKey(modelVo.getProduct_id());
////							// 商品productId
////							commonGoodsReqDto.setItemId(modelVo.getProduct_id());
////							// skuNo
////							commonGoodsReqDto.setSkuId(modelVo.getSkuId());
////							// 商户id
////							commonGoodsReqDto.setMerchantId(modelVo.getProductParamInfo().getShopId() == null || modelVo.getProductParamInfo().getShopId().equalsIgnoreCase("") ? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE : modelVo.getProductParamInfo().getShopId());
////							commonGoodsReqDtos.add(commonGoodsReqDto);
////						}
//
//
//
//
//
//
//
//
//
//
//
//					}
//
//					// 爆品，超级返已售件数
//
//				}
//			}
//		}
//
//		// 处理购买返
////		if(commonGoodsReqDtos.size() > 0)
////			this.getActivityPageBuyRebate(activityPage, commonGoodsReqDtos);
//
//		return activityPage;
//	}

    /**
     * 获取商品佣金
     *
     * @param productId
     * @param skuId
     * @param orgCode
     * @param price
     * @return
     */
    public RebatePercent getPrdRebate(String productId, String skuId, String orgCode, Double price) {
        String key = null;
        if (null == orgCode || orgCode.equalsIgnoreCase("")) {
            key = productId + "_" + skuId + "_" + price;
        } else {
            key = productId + "_" + skuId + "_" + orgCode + "_" + price;
        }
        RebatePercent rebatePercent = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-rebate", key),
                RebatePercent.class);
        if (null == rebatePercent) {
            rebatePercent = iGomeRebateService.getPrdRebate(productId, skuId, orgCode, price);
            // 添加缓存
            gcache.hset("meidian-restful-grouporder-rebate", key, JSONUtils.toJSONString(rebatePercent).getBytes());
        }

        return rebatePercent;
    }

    /**
     * 根据劵规则id查询卷信息
     *
     * @param ruleId
     * @return
     */
    public CouponRuleInfo getCoupon(String ruleId) {
        if (StringUtils.isNotBlank(ruleId)) {
//			CouponRuleInfo couponRuleInfo = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder", ruleId),
//					CouponRuleInfo.class);
            CouponRuleInfo couponRuleInfo = JSONObject.parseObject(gcache.get("getCoupon_" + ruleId),
                    CouponRuleInfo.class);
            if (null == couponRuleInfo) {
                ResultDTO<CouponRuleInfo> couponData = queryGomePromService.getCouponRuleInfoByRuleId(ruleId);
                if (couponData != null) {
                    couponRuleInfo = couponData.getData();
                    // 添加缓存
//					gcache.hset("meidian-restful-grouporder", ruleId,
//							JSONUtils.toJSONString(couponRuleInfo).getBytes());

					gcache.setex("getCoupon_" + ruleId, 3 * 60,
							JSONUtils.toJSONString(couponRuleInfo).getBytes());
					
					return couponData.getData();
				} else {
					return null;
				}
			} else {
				return couponRuleInfo;
			}
		}
		return null;
	}

	/**
	 * 根据劵批次id查询pop卷信息
	 * 
	 * @param ruleId
	 * @return
	 */
	public CouponBatchResult getPopCoupon(String code) {
		if (StringUtils.isNotBlank(code)) {

//			CouponBatchResult couponBatchResult = JSONObject
//					.parseObject(gcache.hget("meidian-restful-grouporder", code), CouponBatchResult.class);
            CouponBatchResult couponBatchResult = JSONObject
                    .parseObject(gcache.get("getPopCoupon_" + code), CouponBatchResult.class);
            if (null == couponBatchResult) {
                ResultDO<CouponBatchResult> couponData = iCouponAndBatchManager.getCouponBatchDetails(code);
                if (couponData != null && null != couponData.getData()) {
                    couponBatchResult = couponData.getData();
                    // 添加缓存
//					gcache.hset("meidian-restful-grouporder", code,
//							JSONUtils.toJSONString(couponBatchResult).getBytes());
					gcache.setex("getPopCoupon_" + code, 3 * 60,
							JSONUtils.toJSONString(couponBatchResult).getBytes());
					
					return couponData.getData();
				} else {
					return null;
				}
			} else {
				return couponBatchResult;
			}
		}
		return null;
	}

	/**
	 * 根据券类型领券
	 * 
	 * @param couponType
	 * @param promoId
	 * @param userId
	 * @param request
	 * @return
	 * @throws ServiceException
	 */
	public Integer fetchCoupon(String couponType, String promoId, String userId, 
			String activeId, String couponId, String channel,
			HttpServletRequest request) throws ServiceException {
		Integer result = 0;
		if (StringUtils.isNotBlank(couponType)) {
			Map<String, String> ctxMap = null;
			Cookie cookie = CookieUtils.getCookieByName(request, "ctx");
			if(null != cookie) {
				ctxMap = CookieUtils.buildRequestHeader(cookie.getValue());
			}
			String riskStatus = gcache.get("meidian-coupon-risk-switch");
			if(riskStatus == null || riskStatus.equals("1")){  //判断风控开关是否开启
				result = (int)this.fetchCouponRiskValid(couponType, userId, promoId, couponId, channel, request);
			}
			String ip = null;
			if(result == 0){
				ip = this.getIP(request);
				result = this.fetchCoupon(couponType, promoId, userId, activeId, ip, ctxMap);
			}
			
			logger.info("fetchCoupon ==> couponType={} promoId={} userId={} activeId={} ip={} result={}", couponType, promoId, userId, activeId, ip, result);
		}
		
		return result;
	}

	/**
	 * 领券风控验证
	 * 
	 * @param couponType
	 * @param userId
	 * @param promoId 劵方案id或批次号
	 * @param couponId 劵规则id
	 * @param request
	 * @throws ServiceException
	 */
	private byte fetchCouponRiskValid(String couponType, String userId, String promoId, 
			String couponId, String channel, HttpServletRequest request) throws ServiceException {

		String ip = this.getIP(request);
		String cookie = request.getHeader("Cookie");
		if(null == cookie) return 25;
		String ufpd = null;
		String bizNo = null;
		String couponLAmount = null;
		String couponFaceValue = null;

		// 1.获取UFPD设备指纹信息
		Cookie[] cookies = request.getCookies();
		for (Cookie ck : cookies) {
			if ("ufpd".equals(ck.getName())) {
				ufpd = ck.getValue();
			}
		}

		// 2.业务场景号
		switch (couponType) {
		case GroupOrderConstants.COUPON_TYPE_MEI:
			bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_MEI;
			break;
		case GroupOrderConstants.COUPON_TYPE_RED:
			bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_RED;
			break;
		case GroupOrderConstants.COUPON_TYPE_BLUE:
			bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_BLUE;
			break;
		case GroupOrderConstants.COUPON_TYPE_POP_SHOP:
			bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_POP_SHOP;
			break;
		case GroupOrderConstants.COUPON_TYPE_POP_PLATFORM:
			bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_POP_PLATFORM;
			break;
		case GroupOrderConstants.COUPON_TYPE_MARKETING:
			if(channel.equals(GroupOrderConstants.CHANNEL_WAP)){
				
				// 营销劵wap场景号
				bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_MARKET;
			}else if(channel.equals(GroupOrderConstants.CHANNEL_MINI)){
				
				// 营销劵小程序场景号
				bizNo = GroupOrderConstants.BIZ_NO_MINI_COUPON_MARKET;
			}else if(channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP)
					|| channel.equals(GroupOrderConstants.CHANNEL_IOS_APP)){
				
				// 营销劵APP场景号
				bizNo = GroupOrderConstants.BIZ_NO_APP_COUPON_MARKET;
			}else {
				// 营销劵wap场景号
				bizNo = GroupOrderConstants.BIZ_NO_WAP_COUPON_MARKET;
			}
			break;
		}

		// 3.劵满多少元可用，劵面额
		if (couponType.equals(GroupOrderConstants.COUPON_TYPE_MEI)
				|| couponType.equals(GroupOrderConstants.COUPON_TYPE_RED)
				|| couponType.equals(GroupOrderConstants.COUPON_TYPE_BLUE)
				|| couponType.equals(GroupOrderConstants.COUPON_TYPE_MARKETING)) {
			
			if(null == couponId || couponId.equals("")) {
				logger.error("fetchCouponRiskValid meiCoupon reqParam null ==> userId={} ", userId);
				return 22;
			}
			CouponRuleInfo info = this.getCoupon(couponId);
			if(null == info) {
				logger.error("fetchCouponRiskValid meiCoupon resParam null ==> userId={} ", userId);
				return 23;
			}
			couponLAmount = info.getLimitAmount() + "-" + info.getAmount();
			couponFaceValue = info.getAmount().toString();
		} else if (couponType.equals(GroupOrderConstants.COUPON_TYPE_POP_SHOP)
				|| couponType.equals(GroupOrderConstants.COUPON_TYPE_POP_PLATFORM)) {
			
			CouponBatchResult result = this.getPopCoupon(promoId);
			if(null == result) {
				logger.error("fetchCouponRiskValid popCoupon resParam null ==> userId={} ", userId);
				return 24;
			}
			couponLAmount = result.getLimitPrice() + "-" + result.getDenomination();
			couponFaceValue = String.valueOf(result.getDenomination());
		}

		if(null == ip || ip.equals("")
				|| null == ufpd || ufpd.equals("")
				|| null == bizNo || bizNo.equals("")
				|| null == couponLAmount || couponLAmount.equals("")
				|| null == couponFaceValue || couponFaceValue.equals("")
				){
			
			logger.error("fetchCouponRiskValid risk reqParam null ==> userId={} ip={} ufpd={} bizNo={} couponLAmount={} couponFaceValue={} ", userId, ip, ufpd, bizNo, couponLAmount, couponFaceValue);
			return 25;
		}
		Map<ExtKeyEnum, String> extensionField = new HashMap<>();
		extensionField.put(ExtKeyEnum.COOKIE, cookie);
		extensionField.put(ExtKeyEnum.COUPON_TYPE, couponLAmount);
		extensionField.put(ExtKeyEnum.PROMOTION_ID, promoId);
		extensionField.put(ExtKeyEnum.COUPON_FACE_VALUE, couponFaceValue);

		RequestV2 requestV2 = new RequestV2();
		requestV2.setUserId(userId);
		requestV2.setIp(ip);
		requestV2.setUfpd(ufpd);
		requestV2.setBizNo(bizNo);
		requestV2.setExtensionField(extensionField);
		
		logger.debug("fetchCouponRiskValid irisk reqParam ==> {}", JSONUtils.toJSONString(requestV2));
		
		ResultV2<ResponseV2> resultV2 = iriskService.predict(requestV2);
		
		logger.debug("fetchCouponRiskValid irisk resParam ==> {}", JSONUtils.toJSONString(resultV2));
		logger.info("fetchCouponRiskValid irisk resParam ==> {}", JSONUtils.toJSONString(resultV2));
		
		if(null == resultV2) return 26;
		switch (resultV2.getCode()) {
		case 200:
			logger.info("fetchCouponRiskValid risk success ==> userId={} couponType={}，promoId={}", userId, couponType, promoId);
			return 0;
		case 400:
			logger.error("fetchCouponRiskValid risk check param error ==> userId={} couponType={} promoId={} message={}", userId, couponType,
					promoId, resultV2.getData());
			return 27;
		case 201:
			logger.error("fetchCouponRiskValid risk intercept ==> userId={} couponType={} promoId={} message={}", userId, couponType,
					promoId, resultV2.getDescription());
			return 28;
		case 500:
			logger.error("fetchCouponRiskValid risk exception ==> userId={} couponType={} promoId={} message={}", userId, couponType,
					promoId, resultV2.getDescription());
			return 29;
		}

		return 0;
	}

	/**
	 * 领券(美券)
	 * 
	 * @param promoId
	 * @param userId
	 * @param ip
	 * @throws ServiceException
	 */
	public Integer fetchCoupon(String promoId, String userId, String ip, Map<String, String> requestHeader) {
		Integer status = GroupOrderConstants.FETCH_COUPON_COMMON_FAIL_MSG;
		if (StringUtils.isNotBlank(promoId) && StringUtils.isNotBlank(userId)) {
			String txId = UUID.randomUUID().toString().replaceAll("-", "");

			RequestDTO<FuseCouponParam> request = new RequestDTO<FuseCouponParam>();

			FuseCouponParam fcp = new FuseCouponParam();
			fcp.setPromoId(promoId);
			fcp.setSite(GroupOrderConstants.SITE_TYPE_WAP);
			fcp.setIp(ip);
			fcp.setUserId(userId);
			
			request.setBody(fcp);
			request.setRequestHeader(requestHeader);
			
			ResponseDTO<List<FuseCouponResultData>> result = null;
			try {
				result = gomeFetchFuseCouponInnoService.fetchCoupon2(txId, request);
			} catch (Exception e) {
				logger.error("fetchCoupon2 ==> userId={} planId={}", userId, promoId);
			}
			if (result != null) {
				if (result.getCode().equals("success")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_SUCCESS;
				}else if (result.getCode().equals("no_param")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_NOPARAM;
				}else if (result.getCode().equals("failed")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_FAILED;
				}else if (result.getCode().equals("data_error")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_DATAERROR;
				}else if (result.getCode().equals("end")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_END;
				}else if (result.getCode().equals("no_start")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_NOTSTART;
				}else if (result.getCode().equals("no_count")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_NOCOUNT;
				}else if (result.getCode().equals("user_no_count")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_USERNOCOUNT;
				}else if (result.getCode().equals("user_exception")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_USEREXCEPTION;
				}else if (result.getCode().equals("no_mobile")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_NOMOBILE;
				}else if (result.getCode().equals("get_grade_exception")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_GETGRADEEXCEPTION;
				}else if (result.getCode().equals("grade_limit")) {
					status = GroupOrderConstants.FETCH_COUPON_RESULT_GRADELIMIT;
				}
			}
		} else {
			logger.error("fetchCoupon ==> planId={}, userId={}", promoId, userId);
		}
		return status;
	}
	
	// 获取IP
	private String getIP(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (!StringUtils.isEmpty(ip) && ip.indexOf(",") != -1) {
			String[] ips = ip.split(",");
			if (ips.length > 1) {
				return ips[0];
			}
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

//	/**
//	 * 获取商品信息
//	 *
//	 * @return
//	 * @throws ServiceException
//	 */
//	public List<ProductVo> getProducts(List<ProductIdActivityId> productIdActivityIds, String areaCode) {
//		List<ProductsVo> productIds = new ArrayList<ProductsVo>();
//		List<ProductVo> resultList = new ArrayList<ProductVo>();
//		if (productIdActivityIds != null && productIdActivityIds.size() > 0 && null != areaCode) {
//			for (ProductIdActivityId productIdActivityId : productIdActivityIds) {
//				ProductsVo productsVo = new ProductsVo();
//				if (StringUtils.isNotBlank(productIdActivityId.getActivityId()))
//					productsVo.setActivityId(Long.valueOf(productIdActivityId.getActivityId()));
//				productsVo.setProductId(productIdActivityId.getProductId());
//				productIds.add(productsVo);
//			}
//
//			int listSize = productIds.size();
//			int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
//
//			List<ProductsVo> paramList = new ArrayList<>();
//			for (int a = 1; a <= selectCount; a++) {
//				paramList.clear();
//				if (selectCount == 1) {
//					paramList = productIds;
//				} else {
//					if (a != selectCount) {
//						paramList.addAll(productIds.subList(30 * (a - 1), 30 * a));
//					} else {
//						paramList.addAll(productIds.subList(30 * (a - 1), listSize));
//					}
//				}
//
//				CommonResultEntity<ProductInfoListVo> resultVo = GorderInfoForAppNewResource.getProductInfoByIds(paramList,
//						areaCode);
//				logger.debug("getProductsByIds resultVo ==> {} ", resultVo);
//				logger.info("getProductsByIds areaCode ==> {} ", areaCode);
//				if (resultVo.getBusinessObj() != null) {
//					ProductInfoListVo tVo = resultVo.getBusinessObj();
//					if (tVo != null) {
//						List<ProductManagementVo> tList = tVo.getProductInfo();
//						if (tList != null && tList.size() > 0) {
//							for (ProductManagementVo productManagementVo : tList) {
//								if (null != productManagementVo) {
//									ProductVo productVo = copyProduct(productManagementVo);
//									resultList.add(productVo);
//								}
//							}
//						}
//					}
//				}
//			}
//
//		}
//		return resultList;
//	}

    /**
     * 根据scn获取用户信息
     *
     * @param scn
     * @return
     * @throws ServiceException
     */
    public UserInfoCache checkScnByDubbo(String scn) throws ServiceException {
    	if(StringUtils.isBlank(scn)) return null;
        UserResult<UserInfoCache> resultEntity = authencationUtils.checkScnByDubbo(scn);
        UserInfoCache userInfo = resultEntity.getBuessObj();
        return userInfo;
    }

    /**
     * 获取单券商品详情
     *
     * @param productId
     * @param couponId
     * @param areaCode
     * @param request
     * @return
     * @throws ServiceException
     */
    public CouponMiddleOne getCouponProductView(String productId, String skuId, String couponId, 
    		String couponType, String areaCode, String orgCode, 
    		Integer ppi, Byte ua, String planId, String mOrg, String policyId
    ) throws ServiceException {

        // 商品信息
        List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
        ProductRequestParam productRequestParam = new ProductRequestParam(productId, skuId);
        productRequestParams.add(productRequestParam);
//		List<Product> products = this.getBatchProducts(productIds, areaCode, ppi, GroupOrderConstants.ONE_COUPON_DETAILS_PRODUCT_IMAGE, ua);
        List<Product> products = this.getPros(productRequestParams, areaCode, ppi, GroupOrderConstants.ONE_COUPON_DETAILS_PRODUCT_IMAGE, ua, mOrg, policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
        if (null == products || products.size() == 0) return null;
        Product product = products.get(0);
        CouponMiddleOne couponMiddleOne = new CouponMiddleOne(
                product.getId(), product.getSkuId(), product.getName(),
                product.getMainImage(), product.getProductTag(), this.getPrice(product.getSalePrice()),
                product.getStatus(), product.getShopId()
        );

        Coupon cp = new Coupon();
        if (couponType.equals(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
            // 根据批次号查询pop劵信息
            CouponBatchResult couponBatchResult = this.getPopCoupon(couponId);
            if (null != couponBatchResult) {
                cp.setCoupon_num(couponBatchResult.getDenomination()); // 面额
                cp.setDescription(couponBatchResult.getDescription());
                cp.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
                cp.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券,
                // 2:平台券
                cp.setCoupon_id(couponId); // pop劵批次号
                cp.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                cp.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
                cp.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));
                
                // pop劵加密
                String id = CouponEncryptionUtil.popCouponEncryption(couponId, cp.getCouponType(), couponBatchResult.getShopNo(), couponBatchResult.getActiveId());
                cp.setEncryptionId(id);
                
                couponMiddleOne.setCoupon(cp);
            }
        } else {
            // 根据券规则ID获取美劵，红蓝券信息
            CouponRuleInfo blueCoupon = this.getCoupon(couponId);
            if (null != blueCoupon) {
                cp.setCoupon_id(blueCoupon.getRuleId());
                cp.setCoupon_num(blueCoupon.getAmount());
                cp.setFullAmount(blueCoupon.getLimitAmount() == null ? 0D : blueCoupon.getLimitAmount());
                cp.setDescription(blueCoupon.getDescription());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                cp.setShow_start_time(sdf.format(blueCoupon.getCouponStartDate()));
                cp.setShow_end_time(sdf.format(blueCoupon.getCouponEndDate()));
                cp.setCouponType(blueCoupon.getType());
                cp.setPlan_id(planId);
                
                // 美红蓝营销劵加密
                String id = CouponEncryptionUtil.beautifulCouponEncryption(planId, blueCoupon.getType());
                cp.setEncryptionId(id);
                		
                couponMiddleOne.setCoupon(cp);
            }
        }

        // 劵后价
        double couPrice = DoubleUtils.sub(couponMiddleOne.getPrice(), cp.getCoupon_num() == null ? 0 : cp.getCoupon_num());
        if (couPrice < 0)
            couPrice = 0;
        couponMiddleOne.setCouponPrice(couPrice);

        // 延保
        Integer warranty = this.appreciationServeCheckout(product.getSkuNo(), DoubleUtils.switchScientificCalculate(couponMiddleOne.getPrice()), orgCode);
        couponMiddleOne.setWarranty(warranty);

        return couponMiddleOne;
    }

    /**
     * 爆品单品页，更多推荐
     *
     * @param ukey
     * @param areaCode
     * @param organizationId
     * @param request
     */
    public List<ProductParamInfo> getMoreCouponProductView(String ukey, String areaCode,
                                                           Integer ppi, Byte ua, String mOrg, String policyId) throws ServiceException {
        Map<String, Object> map = new HashMap<String, Object>();
        List<ProductParamInfo> productParamInfos = new ArrayList<ProductParamInfo>();
        map.put("unique_key", ukey);
        String result = null;
        try {
            result = httpClientUtil.doGet(slotUrl, map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        JSONObject obj = JSONObject.parseObject(result);

        JSONObject data = null;
        try {
            data = obj.getJSONObject("data");
        } catch (Exception e) {
            // TODO: handle exception
        }
        if (null == data)
            return productParamInfos;
        JSONArray arrays = null;
        try {
            arrays = data.getJSONArray("list");
        } catch (Exception e) {
            // TODO: handle exception
        }
        if (null == arrays)
            return productParamInfos;
        List<ProductIdActivityId> productIdActivityIds = new ArrayList<ProductIdActivityId>();
        List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
        if (null != arrays && arrays.size() > 0) {
            for (int a = 0; a < arrays.size(); a++) {
                JSONObject o = arrays.getJSONObject(a);
                String productId = o.getString("product_id");
                String couponId = o.getString("coupon_id");
                Double couponNum = o.getDouble("coupon_num");
                String planId = o.getString("plan_id");
                String couponType = o.getString("coupon_type");
                String skuNo = o.getString("sku_no");
                String skuId = o.getString("sku_id");
                ProductIdActivityId productIdActivityId = new ProductIdActivityId();
                productIdActivityId.setProductId(productId);
                productIdActivityId.setCoupon_id(couponId);
                productIdActivityId.setCoupon_num(couponNum);
                productIdActivityId.setPlan_id(planId);
                productIdActivityId.setCouponType(couponType);
                productIdActivityId.setSku_no(skuNo);
                productIdActivityId.setSkuId(skuId);
                productIdActivityIds.add(productIdActivityId);

                ProductRequestParam productRequestParam = new ProductRequestParam(productId, skuId);
                productRequestParams.add(productRequestParam);
            }
        }

        // 商品信息
//		List<Product> products = this.getBatchProducts(productIds, areaCode, ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE, ua);
        List<Product> products = this.getPros(productRequestParams, areaCode, ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE, ua, mOrg, policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
        if (null == products || products.size() == 0) return null;
        for (Product product : products) {
            ProductParamInfo productParamInfo = new ProductParamInfo();
            productParamInfo.setProductId(product.getId());
            productParamInfo.setSkuId(product.getSkuId());
            productParamInfo.setProductImage(product.getMainImage());
            productParamInfo.setPrice(this.getPrice(product.getSalePrice()));
            productParamInfo.setProductStatus(product.getStatus());
            productParamInfo.setProductTag(product.getProductTag());
            productParamInfo.setName(product.getName());
            productParamInfo.setShopId(product.getShopId());

            // 劵信息,根据劵规则id
            Coupon coupon = new Coupon();
            productIdActivityIds.stream().forEach(f -> {
                if (f.getProductId().equalsIgnoreCase(productParamInfo.getProductId())) {
                    if (f.getCouponType() != null
                            && f.getCouponType().equals(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
                        // 根据劵批次id查询pop劵信息
                        CouponBatchResult couponBatchResult = getPopCoupon(f.getCoupon_id());
                        if (null != couponBatchResult) {
                            coupon.setPlan_id(f.getPlan_id());// pop劵批次号
                            coupon.setCoupon_num(couponBatchResult.getDenomination()); // 面额
                            coupon.setDescription(couponBatchResult.getDescription());
                            coupon.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
                            coupon.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券,
                            coupon.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
                        }
                    } else {
                        // 根据劵规则id查询美，红，蓝 ，劵信息
                        CouponRuleInfo couponData = this.getCoupon(f.getCoupon_id());
                        if (null != couponData) {
                            coupon.setCoupon_id(f.getCoupon_id());
                            coupon.setPlan_id(f.getPlan_id());
                            coupon.setCoupon_num(couponData.getAmount());
                            coupon.setDescription(couponData.getDescription());
                            coupon.setFullAmount(couponData.getLimitAmount());
                            coupon.setCouponType(couponData.getType());
                        }
                    }

                    // set skuNo
                    productParamInfo.setSkuNo(f.getSku_no());
                }
            });

            // 劵后价
            productParamInfo.setCoupon(coupon);
            productParamInfo.setCouponPrice(DoubleUtils.sub(productParamInfo.getPrice(), null == coupon.getCoupon_num() ? 0 : coupon.getCoupon_num()));
            if (productParamInfo.getCouponPrice() < 0) productParamInfo.setCouponPrice(0d);

            productParamInfos.add(productParamInfo);
        }

        return productParamInfos;
    }

    /**
     * 获取product的sku列表
     *
     * @param productId
     * @param skuId
     * @return
     * @throws ServiceException
     */
    public SkuAttrVo getSkuAttr(String productId, String skuId) throws ServiceException {
        // 获取商品详情信息
        ProductItemPage productItemPage = prodDetailService.getProductDetail(productId, skuId);
        if (null == productItemPage || null == productItemPage.getPrdInfo()) return null;

        // 过滤下架skuid
        Map<String, String> reMap = new HashMap<String, String>();
        List<String> productIdSkuIds = new ArrayList<String>();
        Map<String, String> affixAttrMap = productItemPage.getPrdInfo().getAffixAttr();
        for (Map.Entry<String, String> sku : affixAttrMap.entrySet()) {
            productIdSkuIds.add(productId + "_" + sku.getValue());
            if (null != sku.getValue() && !sku.getValue().equalsIgnoreCase(""))
                reMap.put(sku.getValue(), sku.getKey());
        }
        List<CommodityVo> result = accessGoodsService.getProductStatus(productIdSkuIds);
        if (null == result) return null;
        for (CommodityVo commodityVo : result) {
            if (null != commodityVo && commodityVo.getStatus() != 1) {
                if (reMap.containsKey(commodityVo.getSkuId())) {
                    affixAttrMap.remove(reMap.get(commodityVo.getSkuId()));
                }
            }
        }

        SkuAttrVo skuAttr = new SkuAttrVo();
        skuAttr.setAffixAttr(affixAttrMap);
        skuAttr.setSalesProperty(productItemPage.getPrdInfo().getSalesProperty());

        return skuAttr;
    }

    /**
     * 获取sku信息
     *
     * @param productId
     * @param skuId
     * @return
     * @throws ServiceException
     */
    public SkuItem getSkuInfo(String productId, String skuId) {
        SkuItem skuItem = prodDetailService.getSku(productId, skuId, null);
        return skuItem;
    }

//	/**
//	 * 获取评论
//	 *
//	 * @param productId
//	 * @param page
//	 * @param appraiseType
//	 * @return
//	 */
//	public Object getAppraise(String productId, Integer pageNum, String appraiseType) {
//
//		if (StringUtils.isNotBlank(productId)) {
//			if (pageNum == null || pageNum <= 0) {
//				pageNum = 1;
//			}
//			String url = this.appraiseUrl.replace("productId", productId).replace("page", pageNum.toString())
//					.replace("appraiseType", appraiseType);
//			HttpGet httpGet = new HttpGet(url);
//			String responseData = httpClientUtil.doGet(httpGet);
//			System.out.println(responseData);
//			return JSONObject.parseObject(responseData);
//		}
//		return null;
//	}

//	/**
//	 * 库存
//	 *
//	 * @param daId
//	 * @param daId2
//	 * @param skuNo
//	 * @return
//	 */
//	public ResultDTO<AreaQueryRDTO> getSkuCount(String daId, String daId2, String skuNo) {
//		AreaQueryPDTO aqp = new AreaQueryPDTO();
//		aqp.setBuId(8270);
//		List<AreaQueryTransPDTO> trans = new ArrayList<>();
//		aqp.setTrans(trans);
//		AreaQueryTransPDTO tran = new AreaQueryTransPDTO();
//		trans.add(tran);
//		tran.setDaId("DA" + daId);
//		tran.setDaId2("DA" + daId2);
//		List<AreaQueryDetailPDTO> details = new ArrayList<>();
//		tran.setDetails(details);
//		AreaQueryDetailPDTO detail = new AreaQueryDetailPDTO();
//		details.add(detail);
//		detail.setIndexFlag("2");
//		detail.setItemFlag("N");
//		detail.setQty(1);
//		detail.setPartNum(skuNo);
//
//		ResultDTO<AreaQueryRDTO> result = atpAreaQueryClient.satisfyAreaAtpQty(aqp);
//		return result;
//	}

	/**
	 * 领POP券
	 * 
	 * @param promoId
	 * @param userId
	 * @param request
	 * @return
	 * @throws ServiceException
	 */
	public Integer fetchPOPCoupon(String atchCode, String userId, String activeId) {
		if (StringUtils.isNotBlank(atchCode) && StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(activeId)) {
			try {
				ResultDO<Integer> result = iPromotionAndCouponManager.drawCoupon(userId, atchCode, activeId);
				switch (result.getData()) {
				case 1:
					return GroupOrderConstants.FETCH_POP_COUPON_RESULT_SUCCESS;
				case 2:
					return GroupOrderConstants.FETCH_POP_COUPON_RESULT_NOTEXIT;
				case 3:
					return GroupOrderConstants.FETCH_POP_COUPON_RESULT_END;
				case 4:
					return GroupOrderConstants.FETCH_POP_COUPON_RESULT_NOSTART;
				case 5:
					return GroupOrderConstants.FETCH_POP_COUPON_RESULT_COUPONEMPTY;
				case 6:
					return GroupOrderConstants.FETCH_POP_COUPON_RESULT_USERNOCOUNT;
				default:
					return 100;
				}
			} catch (Exception e) {
				logger.error("fetch coupon error:" + e.getMessage());
//				throw new ServiceException("coupon.fetchCoupon.fail");
			}

		}
//		else {
//			throw new ServiceException("coupon.fetchCoupon.fail");
//		}
		return GroupOrderConstants.FETCH_COUPON_COMMON_FAIL_MSG;
	}

	/**
	 * 领取红蓝券
	 * 
	 * @param promoId
	 * @param userId
	 * @param ip
	 * @return
	 * @throws ServiceException
	 */
	public Integer fetchRedBlueCoupon(String promoId, String userId, String ip, Map<String, String> requestHeader) {
		Integer status = GroupOrderConstants.FETCH_COUPON_COMMON_FAIL_MSG;
		
		if (StringUtils.isNotBlank(promoId) && StringUtils.isNotBlank(userId)) {
			String txId = UUID.randomUUID().toString().replaceAll("-", "");

			GomeFetchCouponsResult result = null;
			try {
				//接口更换ctx 2020.1.19 begin
				//result = gomeFetchCouponsService.getCoupons(userId, promoId, ip, txId);
				RequestDTO<GomePackageFetchCouponParam> paramRequestDTO = new RequestDTO<GomePackageFetchCouponParam>();
				GomePackageFetchCouponParam body = new GomePackageFetchCouponParam();
				body.setUserId(userId);
				body.setPromid(promoId);
				body.setIpAddress(ip);
				body.setTxtId(txId);
				paramRequestDTO.setRequestHeader(requestHeader);
				paramRequestDTO.setBody(body);
				ResponseDTO<GomeFetchCouponsResult> responseDTO = gomeFetchCouponsInnoService.getCoupons(paramRequestDTO);
				if(responseDTO != null){
					result = responseDTO.getBody();
				}
				//接口更换ctx 2020.1.19 end
			} catch (Exception e) {
				logger.error("gomeFetchCouponsService.getCoupons ==> userId={} promoId={} ip={} txId={}", userId, promoId, ip, txId);
				e.printStackTrace();
			}
			if (null != result) {
				if (result.getState().equals("success")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_SUCCESS;
				}else if (result.getState().equals("no_login")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_NOLOGIN;
				}else if (result.getState().equals("no_promid")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_NOPROMID;
				}else if (result.getState().equals("busy")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_BUSY;
				}else if (result.getState().equals("end")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_END;
				}else if (result.getState().equals("failed")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_FAILED;
				}else if (result.getState().equals("no_start")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_NOSTART;
				}else if (result.getState().equals("no_mobile")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_NOMOBILE;
				}else if (result.getState().equals("user_no_count")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_USERNOCOUNT;
				}else if (result.getState().equals("coupon_empty")) {
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_COUPONEMPTY;
				}else{
					status = GroupOrderConstants.FETCH_REDBLUE_COUPON_RESULT_FAILED_UNKONW;
				}
			}
		}
		return status;
	}

	public GmsidValidResultVo gmsidValid(String gmsid, HttpServletRequest request) {
		String sha1 = Sha1Util.encode(gmsid);
		String token = MD5Util.encode(sha1 + "GMeidian!@#");
		String url = this.gmsidValidUrl.replace("AppID", this.appId).replace("Token", token);
		GmsidValidResultVo validVo = null;
		try {
			System.err.println("url:" + url);
			System.err.println("cookie request:" + JSONObject.toJSONString(request.getHeader("Cookie")));
			HttpGet httpGet = new HttpGet(url);
			System.err.println("httpGet1:" + JSONObject.toJSONString(httpGet));
			httpGet.addHeader("Cookie", request.getHeader("Cookie"));
			System.err.println("httpGet2:" + JSONObject.toJSONString(httpGet));
			String result = httpClientUtil.doGet(httpGet);
			System.err.println("url result:" + result);
			if (null != result) {
				validVo = JSONObject.parseObject(result, GmsidValidResultVo.class);
			}
		} catch (Exception e) {
			logger.info("valid gm_sid:" + gmsid + " error.");
		}
		return validVo;
	}

	/**
	 * 专题活动页分享
	 * 
	 * @param uniqueKey
	 * @return
	 * @throws ServiceException
	 */
	public ActivityPageShare getMdtShare(String uniqueKey) throws ServiceException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("unique_key", uniqueKey);
		String result = null;
		try {
			result = httpClientUtil.doGet(activityPageShare, map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		JSONObject obj = JSONObject.parseObject(result);

		JSONObject data = null;
		try {
			data = obj.getJSONObject("data");
		} catch (Exception e) {
			// TODO: handle exception
		}
		ActivityPageShare activityPageShare = new ActivityPageShare();
		if (null == data)
			return activityPageShare;
		String activityShare = JSONObject.toJSONString(data, SerializerFeature.WriteMapNullValue);
		activityPageShare = JSONObject.parseObject(activityShare, ActivityPageShare.class);

		return activityPageShare;
	}

	// /**
	// * 购买返
	// *
	// * @param productId
	// * @param skuId
	// * @param rebateId
	// * @return
	// */
	// public JSONObject getBuyRebate(String productId, String skuId, Integer
	// productTag, String shopId) {
	// JSONObject result = null;
	// if (StringUtils.isNotBlank(skuId)) {
	//
	// String key = "buyRebate" + "_" + productId + "_" + skuId + "_" +
	// productTag;
	// result = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder",
	// key));
	// if (result == null) {
	// if (null != productTag) {
	// if (productTag == GroupOrderConstants.PRODUCT_SELF_OPERATION_REBATE) {
	// // 自营购买返
	// PlanCommodityReqDto planComReqDto = new PlanCommodityReqDto();
	// planComReqDto.setType(GroupOrderConstants.REBATE_TYPE_SKU); // sku
	// planComReqDto.setId(skuId);
	// planComReqDto.setStatus(GroupOrderConstants.REBATE_STATUS); // 启用
	// planComReqDto.setFlow(GroupOrderConstants.REBATE_SELF_FLOW);
	// PagedList<PlanCommodityResDto> resultplanComReqDtos =
	// iDubboRebatePlanService
	// .getPlanCommodityList(planComReqDto);
	// PlanCommodityResDto dt = null;
	// if (resultplanComReqDtos != null && resultplanComReqDtos.size() > 0) {
	// // 以skuNo调用
	// for (PlanCommodityResDto d : resultplanComReqDtos) {
	// // if (Integer.parseInt(rebateId) ==
	// // d.getPlanId()) {
	// dt = d;
	// // }
	// }
	//
	// if (dt != null) {
	// result = new JSONObject();
	// result.put("startTime", dt.getValidStartTime().getTime());
	// result.put("endTime", dt.getValidEndTime().getTime());
	// result.put("ratio", dt.getRebateRatio());
	// gcache.hset("meidian-restful-grouporder", key, result.toJSONString());
	// }
	// }
	// } else if (productTag ==
	// GroupOrderConstants.PRODUCT_JOINT_OPERATION_REBATE) {
	// // 联营商家购买返
	// PlanCommodityReqDto planDto = new PlanCommodityReqDto();
	// planDto.setType(GroupOrderConstants.REBATE_TYPE_SKU); // sku
	// planDto.setId(skuId);
	// planDto.setStatus(GroupOrderConstants.REBATE_STATUS); // 启用
	// planDto.setFlow(GroupOrderConstants.REBATE_JOINT_FLOW);
	//
	// PagedList<PlanCommodityResDto> resultDto = iDubboRebatePlanService
	// .getPlanCommodityList(planDto);
	// PlanCommodityResDto dto = null;
	// if (resultDto != null && resultDto.size() > 0) {
	// // 以skuNo调用
	// for (PlanCommodityResDto d : resultDto) {
	// // if (Integer.parseInt(rebateId) ==
	// // d.getPlanId()) {
	// dto = d;
	// // }
	// }
	//
	// if (dto != null) {
	// result = new JSONObject();
	// result.put("startTime", dto.getValidStartTime().getTime());
	// result.put("endTime", dto.getValidEndTime().getTime());
	// result.put("ratio", dto.getRebateRatio());
	// gcache.hset("meidian-restful-grouporder", key, result.toJSONString());
	// }
	//
	// } else {
	// // 以productId调用
	// PlanCommodityReqDto planCommodityReqDtos = new PlanCommodityReqDto();
	// planCommodityReqDtos.setType(GroupOrderConstants.REBATE_TYPE); // sku
	// planCommodityReqDtos.setId(productId);
	// planCommodityReqDtos.setStatus(GroupOrderConstants.REBATE_STATUS); // 启用
	// planCommodityReqDtos.setFlow(GroupOrderConstants.REBATE_JOINT_FLOW);
	//
	// PagedList<PlanCommodityResDto> resultD = iDubboRebatePlanService
	// .getPlanCommodityList(planCommodityReqDtos);
	// PlanCommodityResDto dt = null;
	// if (resultD != null && resultD.size() > 0) {
	// // 以skuNo调用
	// for (PlanCommodityResDto d : resultD) {
	// // if (Integer.parseInt(rebateId) ==
	// // d.getPlanId()) {
	// dt = d;
	// // }
	// }
	//
	// if (dt != null) {
	// result = new JSONObject();
	// result.put("startTime", dt.getValidStartTime().getTime());
	// result.put("endTime", dt.getValidEndTime().getTime());
	// result.put("ratio", dt.getRebateRatio());
	// gcache.hset("meidian-restful-grouporder", key, result.toJSONString());
	// }
	// }
	// }
	// }
	// }
	// }
	// }
	// return result;
	// }

	/**
	 * 商品基础详情页
	 * 
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @param userId
	 * @param request
	 * @return
	 */
	public ProductDetailPageVo productDetail(String userId, String productId, String skuId, 
			String areaCode, String orgCode, String storeCode, 
			Integer ppi, Byte ua, String site, String lat, String lng) throws ServiceException {
		ProductDetailPageVo productDetailPageVo = new ProductDetailPageVo();

		// 1.商品信息
		List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
		ProductRequestParam productRequestParam = new ProductRequestParam(productId, skuId);
		productRequestParams.add(productRequestParam);

//		List<Product> products = this.getBatchProducts(productIds, areaCode, ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE, ua);
        List<Product> products = this.getPros(productRequestParams, areaCode, ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE, ua, storeCode, GroupOrderConstants.PRICE_POLICYID, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
        if (null == products || products.size() <= 0)
            return productDetailPageVo;
        Product product = products.get(0);

        // 获取美店价的key
        MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productId, product.getSkuId(), areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
        if (null != meidianPrice) {
            product.setPriceKey(meidianPrice.getPriceKey());
            product.setPriceType(meidianPrice.getPriceType());
        }
        productDetailPageVo.setProduct(product);

        // 2.商品详情
        ProductInfoVo productInfoVo = this.getProductDetail(productId, skuId, areaCode);
        if (null == productInfoVo)
            return productDetailPageVo;
        productDetailPageVo.setProductInfoVo(productInfoVo);

        //获取节能补贴（政府）或者节能优惠（国美）
        //北京地区使用节能补贴，非北京地区使用节能优惠
        String skuNo = null;
        if (StringUtils.isNotBlank(product.getSkuNo())) {
//			param.setSkuNo(product.getSkuNo());
            skuNo = product.getSkuNo();
        } else {
            SkuItem sku = this.getSkuInfo(productId, skuId);
//			param.setSkuNo(sku.getSkuNo());
            skuNo = sku.getSkuNo();
        }

        if(meidianPrice !=null && meidianPrice.getPriceType() != null && !meidianPrice.getPriceType().equals("SHOP_PRICE")){
            if (areaCode.startsWith("110")) {
                if (null != product && product.getAllowanceFlag() != null && product.getAllowanceFlag() == 1) {
//                    SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceById(product.getSkuId(), areaCode);

//                    SkuEnergyAllowance skuEnergyAllowance = null;
//                    if (StringUtils.isNotBlank(storeCode) && storeCode.length() == 4 && !storeCode.startsWith("QDMD")) {
                	if(StringUtils.isNotBlank(storeCode)){
                		Store store = storeManager.getStoreInfo(storeCode, GroupOrderConstants.GET_ORGCODE_BY_STORECODE_STORETYPE, lng, lat);
                		if(null != store){
                			orgCode = store.getOrganizationId();
                		}
                	}           	
                    SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceByNo(skuNo, orgCode);
//                    }
                    if (null != skuEnergyAllowance) {
                        //显示价大于报备价，则不展示节能补贴信息
                        if (null != skuEnergyAllowance.getRecordPrice() && productDetailPageVo.getProduct().getSalePrice() <= (skuEnergyAllowance.getRecordPrice().doubleValue() * 100)) {
                            SkuEnergyAllowanceVo skuEnergyAllowanceVo = new SkuEnergyAllowanceVo();
                            BeanUtils.copyProperties(skuEnergyAllowance, skuEnergyAllowanceVo);
                            productDetailPageVo.setSkuEnergyAllowance(skuEnergyAllowanceVo);
                        }
                    }
                }
            } else {
                EnergySavingSubsidiesParamDTO param = new EnergySavingSubsidiesParamDTO();
                param.setSkuNo(skuNo);
                PromotionScopeDTO scope = new PromotionScopeDTO();
                scope.setAreaCode(areaCode);
                scope.setStoreCode(storeCode);
                scope.setSite(GroupOrderConstants.ENERGY_SAVING_SUBSIDIES_MEIDIAN_SITE);

                String uId = null == userId ? null : userId.toString();
                ResultDTO<EnergySavingSubsidiesResultDTO> resultDto = energySavingSubsidiesClient.getEnergySavingSubsidiesBySkuNo(uId, param, scope, "detail");
                if (null != resultDto && resultDto.isSuccess()) {
                    EnergySavingSubsidiesResultDTO dto = resultDto.getData();
                    if (null != dto) {
                        EnergySavingSubsidiesVo dtoVo = new EnergySavingSubsidiesVo();
                        BeanUtils.copyProperties(dto, dtoVo);
                        productDetailPageVo.setEnergySavingSubsidies(dtoVo);
                    }
                }
            }
        }
        // 延保
        Double mPrice = DoubleUtils.divide(Double.valueOf(product.getSalePrice()), 100D, 2);
        Integer warranty = this.appreciationServeCheckout(product.getSkuNo(), DoubleUtils.switchScientificCalculate(mPrice), orgCode);
        productDetailPageVo.setWarranty(warranty);

        return productDetailPageVo;
    }

    /**
     * 批量获取商品信息
     *
     * @param productIds
     * @param areaCode
     * @param orgCode
     * @return
     * @throws ServiceException
     */
    public List<Product> getBatchProducts(List<String> productIds, String areaCode, Integer ppi, Byte channel, Byte ua) throws ServiceException {

        if (productIds == null || productIds.size() <= 0) {
            return null;
        }

        List<Product> products = new ArrayList<Product>();
        List<Product> pros = new ArrayList<Product>();
        List<String> pIds = new ArrayList<String>();

        for (String productId : productIds) {
            Product product = null;
//			product = JSONObject.parseObject(
//					gcache.hget("meidian-restful-grouporder-product", productId + "_" + areaCode), Product.class);
            product = JSONObject.parseObject(
                    gcache.get("product_" + productId + "_" + areaCode), Product.class);
            if (null == product) {
                pIds.add(productId);
            } else {
                products.add(product);
            }
        }

        // 拼接入参
        List<String> proIds = this.idConvert(pIds, areaCode);

        int listSize = proIds.size();
        int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
        List<String> paramList = new ArrayList<>();
        for (int a = 1; a <= selectCount; a++) {
            paramList.clear();
            if (selectCount == 1) {
                paramList = proIds;
            } else {
                if (a != selectCount) {
                    paramList.addAll(proIds.subList(30 * (a - 1), 30 * a));
                } else {
                    paramList.addAll(proIds.subList(30 * (a - 1), listSize));
                }
            }

            List<ProductShopInfo> productShopInfos = accessGoodsService.getMutiProductByStore(paramList);

            if (null == productShopInfos || productShopInfos.size() == 0)
                continue;
            for (ProductShopInfo productShopInfo : productShopInfos) {
                if (null == productShopInfo)
                    continue;
                Product pro = new Product();
                BeanUtils.copyProperties(productShopInfo, pro);
                // 替换http协议，把http替换为https
                if (pro.getMainImage() != null && pro.getMainImage().contains("http:")) {
                    pro.setMainImage(pro.getMainImage().replace("http:", agreement));
                }

                products.add(pro);
                // 添加缓存
//				gcache.hset("meidian-restful-grouporder-product", pro.getId() + "_" + areaCode,
//						JSONUtils.toJSONString(pro).getBytes());
                gcache.setex("product_" + pro.getId() + "_" + areaCode, 3 * 60,
                        JSONUtils.toJSONString(pro).getBytes());
            }
        }

        // 处理排序返参
        String ratio = null;
        if (null != channel) {
            // 获取分辨率
            ratio = ImageUtils.imagePpiInfo(ppi, channel);
        }
        for (String productId : productIds) {
            for (Product product : products) {
                if (productId.equalsIgnoreCase(product.getId())) {
                    // 处理图片
                    if (null != channel) {
                        // 处理图片分辨率
                        String image = ImageUtils.imageUrlInfo(product.getMainImage(), ratio, ua);
                        product.setMainImage(image);
                    }

                    pros.add(product);
                    break;
                }
            }
        }

        return pros;
    }
    
    /**
     * 批量获取商品信息,sku级别,兼容product级别
     *
     * @param productIds
     * @param areaCode
     * @param orgCode
     * @return
     * @throws ServiceException
     */
    public List<Product> getPros(List<ProductRequestParam> productRequestParams, String areaCode, Integer ppi, Byte channel, Byte ua, String mOrg, String policyId, String requestChannel) throws ServiceException {

        if (productRequestParams == null || productRequestParams.size() == 0) {
            return null;
        }

        // 商品信息返参
        List<Product> pros = new ArrayList<Product>();
        Map<String, Product> prMap = new HashMap<String, Product>();
        // 判断入参是否有skuId
        Map<String, String> reqMap = new HashMap<String, String>();

        // 商品信息入参
        List<String> ids = new ArrayList<String>();

        //美店定价入参
        List<Map<String, String>> priceCondition = new ArrayList<>();
        Map<String, String> condition = null;
        int num = 1;
        
        /**
         * 查询缓存  设置商品或价格查询条件
         */
        for (ProductRequestParam productRequestParam : productRequestParams) {

            Product product = null;
            String productId = productRequestParam.getProductId();
            String skuId = productRequestParam.getSkuId();

            // 处理缓存key
            String keyId = null;
            if (null == skuId || skuId.equalsIgnoreCase("")) {
                keyId = productId + "__" + areaCode;

                // 处理入参是否有skuId
                reqMap.put(productId, null);
            } else {
                keyId = productId + "_" + skuId + "_" + areaCode;

                // 处理入参是否有skuId
                reqMap.put(productId + skuId, null);
            }

            product = JSONObject.parseObject(
                    gcache.get("getPros_product_" + keyId), Product.class);
            if (null == product) {
                ids.add(keyId);
            } else {
            	if(num % 12 == 1) {
            		condition = new HashMap<>(12);
            		priceCondition.add(condition);
            	}
                // 美店定价入参
                if (null != product.getSkuId() && !product.getSkuId().equalsIgnoreCase("")) {
                    condition.put(product.getSkuId(), productId);
                    num++;
                }

                // 根据不同的key值放入商品信息
                if (null == skuId || skuId.equalsIgnoreCase(""))
                    prMap.put(productId, product);
                else
                    prMap.put(productId + skuId, product);

            }
        }

        /**
         * 查询商品信息并处理
         */
        // 商品限制30条
        int listSize = ids.size();
        if(listSize > 0) {
            int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
            List<String> paramList = new ArrayList<>();
            List<ProductShopInfo> productShopInfos = new ArrayList<>();
            for (int a = 1; a <= selectCount; a++) {
                paramList.clear();
                if (selectCount == 1) {
                    paramList = ids;
                } else {
                    if (a != selectCount) {
                        paramList.addAll(ids.subList(30 * (a - 1), 30 * a));
                    } else {
                        paramList.addAll(ids.subList(30 * (a - 1), listSize));
                    }
                }

                productShopInfos.addAll(accessGoodsService.getMutiProductByStore(paramList));

    		}
            
            if (productShopInfos.size() == 0) {
            	logger.info("未查询到商品信息,参数:{}", JSONObject.toJSONString(productRequestParams));
            	return pros;
            }
            
            for (ProductShopInfo productShopInfo : productShopInfos) {
                if (null == productShopInfo)
                    continue;
                Product pro = new Product();
                BeanUtils.copyProperties(productShopInfo, pro);
                // 替换http协议，把http替换为https
                if (pro.getMainImage() != null && pro.getMainImage().contains("http:")) {
                    pro.setMainImage(pro.getMainImage().replace("http:", agreement));
                }
                
                if(num % 12 == 1) {
                	condition = new HashMap<>(12);
                	priceCondition.add(condition);
                }
                // 美店定价入参
                if (null != pro.getSkuId() && !pro.getSkuId().equalsIgnoreCase("")) {
                    condition.put(pro.getSkuId(), pro.getId());
                    num ++;
                }

                String key = null;
                // 根据不同的key值放入商品信息
                if (reqMap.containsKey(pro.getId())) {
                    prMap.put(pro.getId(), pro);
                    key = pro.getId() + "__" + areaCode;
                } else if (reqMap.containsKey(pro.getId() + pro.getSkuId())) {
                    prMap.put(pro.getId() + pro.getSkuId(), pro);
                    key = pro.getId() + "_" + pro.getSkuId() + "_" + areaCode;
                }

                // 添加缓存
    			gcache.setex("getPros_product_" + key, 3 * 60,
    					JSONUtils.toJSONString(pro).getBytes());
    		}
        }
        
        
        /**
         * 查询价格
         */
		// 美店价12条
		Map<String, GomeUnifiedPrice> priceMap = new HashMap<String, GomeUnifiedPrice>();
		
		// 美店定价降级开关
		if(null == gcache.get("meidianPriceOnOff")){
			List<PriceConditionVo> priceConditionRequestList = new ArrayList<>();
			PriceConditionVo pcVo = null;
			Map<String, String> conditionMap = null;
			for(int a = 0; a < priceCondition.size(); a++) {
				conditionMap = priceCondition.get(a);
				if(null != conditionMap && !conditionMap.isEmpty()) {
					for(Map.Entry<String, String> mm: conditionMap.entrySet()) {
						pcVo = new PriceConditionVo();
						pcVo.setChannel(requestChannel);
						pcVo.setPolicyId(policyId);
						pcVo.setProductId(mm.getValue());
						pcVo.setSkuId(mm.getKey());
						
						priceConditionRequestList.add(pcVo);
					}
					
					List<GomeUnifiedPrice> priceRes = priceManager.getPrice(priceConditionRequestList);
					if(null != priceRes && !priceRes.isEmpty()) {
						for(GomeUnifiedPrice gup: priceRes) {
							if(gup != null) {
								priceMap.put(gup.getSkuId(), gup);
							}
						}
					}
					
					priceConditionRequestList.clear();
				
				}
				
			}
		}
		
		
		// 处理排序返参
		String ratio = null;
		if(null != channel){
			// 获取分辨率
			ratio = ImageUtils.imagePpiInfo(ppi, channel);
		}
		GomeUnifiedPrice gPrice = null;
		for (ProductRequestParam productRequestParam : productRequestParams) {
			Product prod = null;
			String skuId = productRequestParam.getSkuId();
			
			// 根据不同的key值获取商品信息
			if(null == skuId || skuId.equalsIgnoreCase("")){
				prod = prMap.get(productRequestParam.getProductId());
			}else {
				prod = prMap.get(productRequestParam.getProductId() + skuId);
			}
			
			// 美店价（priceMap.containsKey（）是降级处理）
			if(priceMap.containsKey(prod.getSkuId())){
				gPrice = priceMap.get(prod.getSkuId());
				Double meidianPrice = DoubleUtils.mul(gPrice.getPrice(), 100D);
				prod.setSalePrice(meidianPrice.longValue());
				prod.setPriceType(gPrice.getPriceType());
			}
			
			// 处理图片
			if(null != channel){
				// 处理图片分辨率
				String image = ImageUtils.imageUrlInfo(prod.getMainImage(), ratio, ua);
				prod.setMainImage(image);
			}
			
			pros.add(prod);
		}
		
		return pros;
	}

	/**
	 * 批量获取商品信息接口-id拼接
	 * 
	 * @param productIds
	 * @param areaCode
	 * @param orgCode
	 * @return
	 */
	public List<String> idConvert(List<String> productIds, String areaCode) {
		if (StringUtils.isBlank(areaCode)) {
			areaCode = "";
		}

		List<String> ids = new ArrayList<>();
		for (String pid : productIds) {
			if (StringUtils.isNotBlank(pid)) {
				ids.add(pid + "__" + areaCode);
			}
		}
		return ids;
	}

	/**
	 * 已团件数
	 * 
	 * @return
	 * @throws ServiceException
	 */
	public List<ProductGroupTotal> getProductBuyNum(List<String> productIds) throws ServiceException {
		// 获取商品的购买总件数
		List<ProductGroupTotal> productGroupTotals = new ArrayList<ProductGroupTotal>();
		CommonResultEntity<List<ProductSaleWrapNumVo>> commonResultEntity = gorderInfoForAppNewResource
				.getProductBuyNumByIds(productIds);
		List<ProductSaleWrapNumVo> productBuyNumVos = commonResultEntity.getBusinessObj();
		if (null != productBuyNumVos && productBuyNumVos.size() > 0) {
			for (ProductSaleWrapNumVo productSaleWrapNumVo : productBuyNumVos) {
				ProductGroupTotal productGroupTotal = new ProductGroupTotal();
				productGroupTotal.setProductId(productSaleWrapNumVo.getProductId());
				productGroupTotal.setTotalBuyNumbers(productSaleWrapNumVo.getProductHistorySaleNum());

				productGroupTotals.add(productGroupTotal);

			}
		}

		return productGroupTotals;
	}

	/**
	 * 首页列表活动信息
	 * 
	 * @param activities
	 * @return
	 */
//	public List<HomePageActivity> getHomePageActivityInfo(List<Long> activityIds) {
//		List<HomePageActivity> homePageActivities = new ArrayList<HomePageActivity>();
//		// 去重
//		List<Long> acIds = new ArrayList<>(new HashSet(activityIds));
//
//		for (Long activityId : acIds) {
//			String key = String.valueOf(activityId);
//			HomePageActivity homePageActivity = new HomePageActivity();
//			homePageActivity = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-activity", key),
//					HomePageActivity.class);
//			if (null == homePageActivity || null == homePageActivity.getActivityId()) {
//				CommonResultEntity<GorderActivityBaseInfoVo> commonResultEntity = GorderInfoForAppNewResource
//						.getActivityInfoById(activityId);
//				GorderActivityBaseInfoVo gorderActivityBaseInfoVo = commonResultEntity.getBusinessObj();
//				if (null == gorderActivityBaseInfoVo)
//					continue;
//				HomePageActivity activity = new HomePageActivity();
//				BeanUtils.copyProperties(gorderActivityBaseInfoVo, activity);
//				activity.setActivityId(gorderActivityBaseInfoVo.getId());
//
//				// 放入缓存
//				gcache.hset("meidian-restful-grouporder-activity", key, JSONUtils.toJSONString(activity).getBytes());
//
//				homePageActivities.add(activity);
//			} else {
//				homePageActivities.add(homePageActivity);
//			}
//
//		}
//		return homePageActivities;
//	}

    /**
     * 获取活动信息
     *
     * @param productId
     * @param skuId
     */
    public GroupActivityInfo getActivityInfo(String skuId) {
        CommonResultEntity<GorderActivityInfoConciseVo> commonResultEntity = gorderInfoForAppNewResource.getActivityInfoBySkuId(skuId);
        GorderActivityInfoConciseVo gorderActivityInfoConciseVo = commonResultEntity.getBusinessObj();
        if (null == gorderActivityInfoConciseVo) return null;
        GroupActivityInfo result = new GroupActivityInfo();
        BeanUtils.copyProperties(gorderActivityInfoConciseVo, result);
        result.setMaxDiscountNeedPeopleNum(result.getMaxDiscountPeopleNum());
        return result;
    }

    /**
     * 用户参与活动次数限制
     *
     * @param userId
     * @param activityId
     * @return
     */
    public boolean getUserGroupNumCheck(Long userId, Long activityId) {
        CommonResultEntity<UserAttendGroupVo> userAttendGroupVo = gorderInfoForAppNewResource
                .checkUserIsCanAttendGroup(userId, activityId);
        UserAttendGroupVo userAttendGroup = userAttendGroupVo.getBusinessObj();
        if (null == userAttendGroup)
            return false;
        return userAttendGroup.getIsOpen();
    }

    /**
     * 商品开团次数限制
     *
     * @param productId
     * @param activityId
     * @return
     */
    public boolean getProductGroupNumCheck(String productId, Long activityId) {
        CommonResultEntity<ProductOpenStatusVo> productOpenStatusVo = gorderInfoForAppNewResource
                .checkProductOpenStatus(productId, activityId);
        ProductOpenStatusVo productOpenStatus = productOpenStatusVo.getBusinessObj();
        if (null == productOpenStatus)
            return false;
        return productOpenStatus.getIsOpen();
    }

    public void imageSizeInfo(GroupOrderDetails groupOrderDetails, Integer ppi, Byte ua) {
        List<GroupUserInfo> groupUserInfos = groupOrderDetails.getGroupUser();
        // 处理图片分辨率
        if (null != groupUserInfos && groupUserInfos.size() > 0)
            ImageUtils.userImageUrlInfo(groupUserInfos, userImage, agreement);

        // 处理http协议
        String imageHttp = imageUrlConvert(groupOrderDetails.getProductInfo().getProductImage());
        // 获取分辨率
        String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.GROUP_DETAILS_HOME_PRODUCT_IMAGE);
        // 商品图url处理
        //String image = ImageUtils.imageUrlInfo(groupOrderDetails.getProductInfo().getProductImage(), ratio, ua);
        String image = ImageUtils.imageUrlInfo(imageHttp, ratio, ua);//于志友修改
        groupOrderDetails.getProductInfo().setProductImage(image);
    }

    /**
     * sku级别的上下架状态
     *
     * @param productSkus
     * @return
     */
    public ProductSkuStatus getProductSkuStatus(String productId, List<String> skus) {
        List<String> productIdSkuIds = new ArrayList<String>();
        for (String skuId : skus) {
            productIdSkuIds.add(productId + "_" + skuId);
        }

        List<CommodityVo> result = accessGoodsService.getProductStatus(productIdSkuIds);
        if (null == result) return null;

        ProductSkuStatus productSkuStatus = new ProductSkuStatus();
        List<SkuStatus> skuStatues = new ArrayList<SkuStatus>();
        for (CommodityVo commodityVo : result) {
            if (null != commodityVo && commodityVo.getStatus() == 1) {
                SkuStatus skuStatus = new SkuStatus();
                skuStatus.setSkuId(commodityVo.getSkuId());
                skuStatus.setStatus(commodityVo.getStatus());
                skuStatues.add(skuStatus);
            }
        }

        productSkuStatus.setProductId(productId);
        productSkuStatus.setSkuStatus(skuStatues);

        return productSkuStatus;
    }

//    /**
//     * 新老用户
//     *
//     * @param userId
//     * @return
//     * @throws ServiceException
//     */
//    public boolean checkoutNewOldUser(String userId) throws ServiceException {
//        String key = user_id + ":" + RedisKeyUtils.getHKey(userId);
//        String userInfoCache = userCenter.hget(key, userId);
//        UserInfo userInfo = JSONObject.parseObject(userInfoCache, UserInfo.class);
//        if (null != userInfo && null != userInfo.getRegisterTime()) {
//            long systemTime = System.currentTimeMillis();
//            if ((systemTime - userInfo.getRegisterTime().getTime()) > 1000 * 60 * 60 * 24)
//                return false;
//        }
//        return true;
//
//    }
    
    /**
     * 新老用户
     *
     * @param userId
     * @return true:新用户  false:老用户
     * @throws ServiceException
     */
    public boolean checkoutNewOldUser(String userId) throws ServiceException {
//        String key = user_id + ":" + RedisKeyUtils.getHKey(userId);
//        String userInfoCache = userCenter.hget(key, userId);
//        UserInfo userInfo = JSONObject.parseObject(userInfoCache, UserInfo.class);
//        if (null != userInfo && null != userInfo.getRegisterTime()) {
//            long systemTime = System.currentTimeMillis();
//            if ((systemTime - userInfo.getRegisterTime().getTime()) > 1000 * 60 * 60 * 24)
//                return false;
//        }
    	boolean flag = false;
    	try {

        	MapResults<Boolean>  map = iUserGomeInfoManager.isNewUser(userId);
        	if(map != null ){
        		flag = map.getBuessObj();
        	}
    	}catch(Exception e) {
    		//调用异常不进行处理，让程序返回false
    		
    	}
    	
        return flag;

    }

    /**
     * 组团sku详情
     *
     * @param productId
     * @param skuId
     * @param areaCode
     * @return
     * @throws ServiceException
     */
    public GroupSkuVo getGroupSku(String productId, String skuId, String areaCode, 
    		String orgCode,Integer ppi, Byte ua,
    		String site, String storeCode, Integer storeType) throws ServiceException {

        GroupSkuVo groupSkuVo = new GroupSkuVo();
        Sku sku = new Sku();
        // 1. sku基本信息
        SkuItem skuItem = this.getSkuInfo(productId, skuId);
        BeanUtils.copyProperties(skuItem, sku);

        // 2. 美店价
        MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productId, skuId, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
        String price = null;
        if (null != meidianPrice) {
            price = meidianPrice.getMeidianPrice();
            sku.setPrice(price);
            sku.setPriceKey(meidianPrice.getPriceKey());
            sku.setPriceType(meidianPrice.getPriceType());
        }

        // 3. 区域价
        List<String> ids = new ArrayList<String>();
        String id = productId + "_" + skuId + "_" + areaCode;
        ids.add(id);
        List<ProductShopInfo> productShopInfos = accessGoodsService.getMutiProductByStore(ids);
        ProductShopInfo productShopInfo = productShopInfos.get(0);
        long salePrice = productShopInfo.getSalePrice();
        Double gPrice = DoubleUtils.divide(Double.valueOf(salePrice), 100D, 2);

        // 处理美店价，国美价，当美店价大于国美价时把美店价赋值给国美价
        if (null != price) {
            if (Double.valueOf(price).doubleValue() > gPrice.doubleValue())
                sku.setGomePrice(price);
            else
                sku.setGomePrice(DoubleUtils.switchScientificCalculate(gPrice));
        }

        // 4. 根据skuId获取商品集信息
        GroupActivityInfo groupActivityInfo = this.getActivityInfo(skuId);
        groupSkuVo.setGroupActivityInfo(groupActivityInfo);


        // 6. 增值服务
        if (null != price) {
            if (null != groupActivityInfo && null != groupActivityInfo.getGroupBusType()) {
                Integer groupType = groupActivityInfo.getGroupBusType();
                int gType = groupType.intValue();
                if (gType != GroupOrderConstants.free_group) {
                    List<AppreciationServeType> appreciationServeTypes = this.appreciationServeInfo(productShopInfo.getSkuNo(), price, orgCode);
                    sku.setAppreciationServeTypes(appreciationServeTypes);
                }
            } else {
                List<AppreciationServeType> appreciationServes = this.appreciationServeInfo(productShopInfo.getSkuNo(), price, orgCode);
                sku.setAppreciationServeTypes(appreciationServes);
            }

        }
        
		// 7.处理图片
        this.skuImage(sku, ppi, ua);
		
		// 8.促销语
        // 降级开关
        String promotionSwitch = gcache.get("promotionSwitch");
        if(null == promotionSwitch){
        	String promotionkey = skuId + "_" + price + "_" + areaCode + "_" + storeCode + "_" + "promotion";
        	List<Promotion> prs = JSONObject.parseArray(gcache.get(promotionkey), Promotion.class);
        	
        	prs = null;
        	
        	if(null == prs){
        		prs = this.promotion(productId, skuId, price, 
        				areaCode, storeCode, storeType,
        				site,skuItem.getSkuNo(),skuItem.getShopNo());
        		
        		if(null == prs){
        			prs = new ArrayList<Promotion>();
        			Promotion promotion = new Promotion();
        			promotion.setCouponType("2019");
        		}
        		
        		gcache.setex(promotionkey, 3 * 60, JSONUtils.toJSONString(prs).getBytes());
        		sku.setPromotions(prs);
        	}else
        		sku.setPromotions(prs);
        }
		
        groupSkuVo.setSku(sku);
        
        return groupSkuVo;
    }

    /**
     * 获取立减，超级返sku详情
     *
     * @param productId
     * @param skuId
     * @param areaCode
     * @return
     * @throws ServiceException
     */
    public Sku getSkuDetail(String productId, String skuId, String areaCode, 
    		String orgCode, String site, String storeCode, 
    		Integer storeType, Integer ppi, Byte ua) throws ServiceException {

        Sku sku = new Sku();
        // 1. sku基本信息
        SkuItem skuItem = this.getSkuInfo(productId, skuId);
        BeanUtils.copyProperties(skuItem, sku);

        // 2. 美店价
        MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productId, skuId, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
        String price = null;
        if (null != meidianPrice) {
            price = meidianPrice.getMeidianPrice();
            sku.setPrice(price);
            sku.setPriceKey(meidianPrice.getPriceKey());
            sku.setPriceType(meidianPrice.getPriceType());
        }

        // 4.增值服务
        if (null != price) {
            List<AppreciationServeType> appreciationServeTypes = this.appreciationServeInfo(sku.getSkuNo(), price, orgCode);
            sku.setAppreciationServeTypes(appreciationServeTypes);
        }

		// 5.处理图片
        this.skuImage(sku, ppi, ua);
        
        // 6.促销语 （更改 自联营均查询）
        // 降级开关
        String promotionSwitch = gcache.get("promotionSwitch");
        if(null == promotionSwitch){
	        String promotionkey = skuId + "_" + price + "_" + areaCode + "_" + storeCode + "_" + "promotion";
	        List<Promotion> prs = JSONObject.parseArray(gcache.get(promotionkey), Promotion.class);
	        if(null == prs){
	        	prs = this.promotion(productId, skuId, price, 
	            		areaCode, storeCode, storeType,
	            		site,skuItem.getSkuNo(),skuItem.getShopNo());
	        	
	        	if(null == prs){
	        		prs = new ArrayList<Promotion>();
	        		Promotion promotion = new Promotion();
	        		promotion.setCouponType("2019");
	        	}
	        	
	        	gcache.setex(promotionkey, 3 * 60, JSONUtils.toJSONString(prs).getBytes());
	        	sku.setPromotions(prs);
	        }else
	        	sku.setPromotions(prs);
        }
        return sku;
    }

    /*
     * 获取团id
     * @param userId
     * @param activityId
     * @return
     */
    public Map<String, Object> getGroupId(Long userId, Long activityId) {

        Map<String, Object> resmap = new HashMap<String, Object>();

        CommonResultEntity<MyGroupOrderVo> commonResultEntity = gorderInfoForAppNewResource.getMyCustomersGroupOrderList(userId, activityId);
        MyGroupOrderVo myGroupOrderVo = commonResultEntity.getBusinessObj();
        if (null == myGroupOrderVo) {
            resmap.put("groupId", null);
            return resmap;
        }
        List<GroupMemberVo> groupMemberVos = myGroupOrderVo.getGroupOrderInfo();
        if (null == groupMemberVos || groupMemberVos.size() == 0) {
            resmap.put("groupId", null);
            return resmap;
        }
        GroupMemberVo groupMemberVo = groupMemberVos.get(0);

        resmap.put("groupId", groupMemberVo.getGroupId());
        resmap.put("skuId", groupMemberVo.getSkuId());
        resmap.put("productId", groupMemberVo.getProductId());

        return resmap;
    }

    /**
     * 校验登录
     *
     * @param scn
     * @return
     * @throws ServiceException
     */
    public AuthencationVo authenticationLogin(String scn) throws ServiceException {

        AuthencationVo authencationVo = new AuthencationVo();

        // 登录选择
        authencationVo.setLoginChoice(gcache.get("loginChoice"));

        // 校验scn
        if (null == scn || scn.equalsIgnoreCase("")) {
            logger.info("traceId: " + MeidianEnvironment.getTraceId() + "，scn inNull");
            // 未登录，返回主站登录页链接
            authencationVo.setLogin(USER_NOT_LOGIN);
            authencationVo.setLoginUrl(loginUrl);

            authencationVo.setCurrentEnv(currentEnv);
            return authencationVo;
        }

        // 登录校验
        UserResult<UserInfoCache> resultEntity = authencationUtils.checkScnByDubbo(scn);
        UserInfoCache userInfoCache = resultEntity.getBuessObj();
        
        String userId = null;
        
        if (null == userInfoCache || StringUtils.isBlank(userInfoCache.getId())) {
            // 未登录，返回主站登录页链接
        	if(null == userInfoCache)
        		logger.info("traceId: " + MeidianEnvironment.getTraceId() + "，userInfoCache null");
        	else
        		logger.info("traceId: " + MeidianEnvironment.getTraceId() + "，userInfoCache.getId null");
            
        	authencationVo.setLogin(USER_NOT_LOGIN);
            authencationVo.setLoginUrl(loginUrl);
        } else {
            // 登录，返回userId
            userId = userInfoCache.getId();

            logger.info("traceId: " + MeidianEnvironment.getTraceId() + "，userId：" + userId);

            authencationVo = JSONObject.parseObject(gcache.get("checkUserId_" + userId), AuthencationVo.class);

            if (authencationVo == null) {
                authencationVo = new AuthencationVo();
                authencationVo.setLogin(USER_ALREADY_LOGIN);
                authencationVo.setUserId(userId);

				com.gome.meidian.grouporder.vo.store.UserInfo user = storeManager.getUserInfo(Long.valueOf(userId));
				if(null != user){
					// 员工门店编码
					authencationVo.setStoreNo(user.getStoreCode());
					// 员工编号
					authencationVo.setStaffNo(user.getStaffNo());
				}
				
				// 昵称
				Map<String, Object> paraMap = new HashMap<>();
				paraMap.put("companyName", "gomeOnLine");
				MapResult<UnifyUserInfoExt> result = iUserInfoFacade.getItemByIdForGomeShop(userId, "gomeShopMobile", paraMap);
				if(result != null && result.isSuccess()){
					UnifyUserInfoExt userVo = result.getBuessObj();
					String nickName = null;
					if (null != userVo)
						nickName = userVo.getNikename();
					authencationVo.setNickName(nickName);
				}

				// 美店主id，（mid）
				CommonResultEntity<VshopInfo> common = vshopFacade.queryVshopByuserId(userId);
				VshopInfo vshopInfo = common.getBusinessObj();
				if(null != vshopInfo){
					authencationVo.setShopId(vshopInfo.getVshopId());
				}
				
				gcache.setex("checkUserId_" + userId, 3 * 60, JSONObject.toJSONString(authencationVo));
			} 
            
		}
		authencationVo.setCurrentEnv(currentEnv);
		
		logger.info("traceId: " + MeidianEnvironment.getTraceId() + "，成功，userId：" + userId);
		
		return authencationVo;
	}
	
	/**
	 * 增值服务
	 * @param skuNo
	 * @param price
	 * @param orgCode
	 * @return
	 */
	public List<AppreciationServeType> appreciationServeInfo(String skuNo, String price, String orgCode) {
		
		QueryIncrementServiceDetailParam param = new QueryIncrementServiceDetailParam();
		param.setSkuNo(skuNo);
		param.setGomePrice(Double.valueOf(price));
		param.setChannel(warrantyChannel);
		param.setOrganCode(orgCode);
		param.setSupplyFlag(null);
		ResultDTO<IncrementBaseGroupDTO> resultDTO = iGomeIncrementServiceClient.queryIncrementServiceDetail(param);
		if(null == resultDTO) return null;
		if(!resultDTO.getErrCode().equalsIgnoreCase("0")) return null;
		IncrementBaseGroupDTO incrementBaseGroupDTO = resultDTO.getData();
		if(null == incrementBaseGroupDTO) return null;
		List<IncrementShowGroupDTO> incrementShowGroupDTOs = incrementBaseGroupDTO.getShowGroupList();
		if(null == incrementShowGroupDTOs || incrementShowGroupDTOs.size() == 0) return null;
		
		List<AppreciationServeType> appreciationServeTypes = new ArrayList<AppreciationServeType>();
		for (IncrementShowGroupDTO incrementShowGroupDTO : incrementShowGroupDTOs) {
			if(null == incrementShowGroupDTO) continue;
			List<IncrementSkuInfoDTO> incrementSkuInfoDTOs = incrementShowGroupDTO.getIncrementSkuInfoList();
			if(null == incrementSkuInfoDTOs || incrementSkuInfoDTOs.size() == 0) continue;
			List<AppreciationServe> appreciationServes = new ArrayList<AppreciationServe>();
			for (IncrementSkuInfoDTO incrementSkuInfoDTO : incrementSkuInfoDTOs) {
				if(null == incrementSkuInfoDTO) break;
				AppreciationServe appreciationServe = new AppreciationServe(incrementSkuInfoDTO.getProductId(), incrementSkuInfoDTO.getSkuId(), incrementSkuInfoDTO.getSkuNo(), 
																			incrementSkuInfoDTO.getDisplaySkuName(), incrementSkuInfoDTO.getYears(), DoubleUtils.switchScientificCalculate(incrementSkuInfoDTO.getServicePrice()), 
																			incrementSkuInfoDTO.getServiceType());
				appreciationServes.add(appreciationServe);
			}
			AppreciationServeType appreciationServeType = new AppreciationServeType(incrementShowGroupDTO.getShowGroupId(), incrementShowGroupDTO.getShowGroupName(), incrementShowGroupDTO.getIconUrl(),
																					appreciationServes);
			appreciationServeTypes.add(appreciationServeType);
		}
		
		return appreciationServeTypes;
	}
	
	/**
	 * 判断是否有增值服务
	 * @param skuNo
	 * @param price
	 * @param orgCode
	 * @return
	 */
	public Integer appreciationServeCheckout(String skuNo, String price, String orgCode) {
		
		QueryIncrementServiceDetailParam param = new QueryIncrementServiceDetailParam();
		param.setSkuNo(skuNo);
		param.setGomePrice(Double.valueOf(price));
		param.setChannel(warrantyChannel);
		param.setOrganCode(orgCode);
		param.setSupplyFlag(null);
		ResultDTO<IncrementBaseGroupDTO> resultDTO = iGomeIncrementServiceClient.queryIncrementServiceDetail(param);
		if(null == resultDTO) return 0;
		if(!resultDTO.getErrCode().equalsIgnoreCase("0")) {
			logger.error(resultDTO.getErrMsg());
			return 0;
		}
		IncrementBaseGroupDTO incrementBaseGroupDTO = resultDTO.getData();
		if(null == incrementBaseGroupDTO) return 0;
		List<IncrementShowGroupDTO> incrementShowGroupDTOs = incrementBaseGroupDTO.getShowGroupList();
		if(null == incrementShowGroupDTOs || incrementShowGroupDTOs.size() == 0) return 0;
		
		return 1;
	}
	
	/**
	 * 获取节能补贴（政府）、节能优惠（国美）
	 * @param skuNo
	 * @param price
	 * @param orgCode
	 * @return
	 */
	public ProductDetailVo allowances(ProductDetailVo productDetail, String userId, String skuNo, String areaCode, String storeCode){
		return null;
	}
	
	/**
	 * 红劵转赠
	 * @param couponType
	 * @param couponId
	 * @param oldUserId
	 * @param newUserId
	 * @return
	 */
	public byte transitionRedCoupon(String couponType, String couponId, String oldUserId, String newUserId){
		String uuid = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		ChangeUserIdParam changeUserIdParam = new ChangeUserIdParam();
		changeUserIdParam.setCouponId(couponId);
		changeUserIdParam.setOldUserId(oldUserId);
		changeUserIdParam.setNewUserId(newUserId);
		
		// 红劵转赠
		com.gome.pangu.redcoupon.dubbo.model.ResultDO<Boolean> result = redCouponService.changeUserIdByCouponIdOrTicketId(uuid, changeUserIdParam);
		
		if(!result.isSuccess()) {
			logger.error("transitionBeautifulCoupon ==> couponType=={} couponId=={} oldUserId=={} newUserId=={} ", couponType, couponId, oldUserId, newUserId);
			return 1;	
		}
		if(!result.getData()){
			logger.error("transitionBeautifulCoupon ==> couponType=={} couponId=={} oldUserId=={} newUserId=={} ", couponType, couponId, oldUserId, newUserId);
			return 1;	
		}
		
		return 0;

	}
	
	/**
	 * 根据劵id查询劵详情
	 */
	public List<TransitionCoupon> findUserCoupons(String couponType, String oldUserId, String userId, List<String> couponIds) {
		List<TransitionCoupon> transitionCoupons = new ArrayList<TransitionCoupon>();
		// 限制20条
		int listSize = couponIds.size();
		int selectCount = listSize % 20 == 0 ? listSize / 20 : listSize / 20 + 1;
		List<String> paramList = new ArrayList<>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = couponIds;
			} else {
				if (a != selectCount) {
					paramList.addAll(couponIds.subList(20 * (a - 1), 20 * a));
				} else {
					paramList.addAll(couponIds.subList(20 * (a - 1), listSize));
				}
			}

			if (couponType.equals("101") || couponType.equals("102")) {
				// 美劵（注意：入参券id不是券规则id）
				com.gome.pangu.bluecoupon.dubbo.model.ResultDO<List<BlueCouponBaseResult>> result = fpBlueCouponQueryService
						.findFpBlueCouponByIdList(paramList);
				if (!result.isSuccess())
					return null;
				List<BlueCouponBaseResult> blueCouponBaseResults = result.getData();
				if (null == blueCouponBaseResults)
					return null;

				for (BlueCouponBaseResult blueCouponBaseResult : blueCouponBaseResults) {
					if (null == blueCouponBaseResult)
						continue;
					// 美券类型 1:线上 101:线下（ 1:蓝券 101:美券 102：神券）
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Byte cashing = null;
					if(null != oldUserId){
						if(oldUserId.equals(blueCouponBaseResult.getUserId()) ){
							if(null != userId){
								if(oldUserId.equals(userId)){
									// 是本人已领过，去使用
									cashing = 2;
								}else if(!oldUserId.equals(userId)){
									// userId可以领
									cashing = 1;
								}
							}
						}else if(!oldUserId.equals(blueCouponBaseResult.getUserId())){
							// 已被别人领了
							cashing = 3;
						}
					}
						
					TransitionCoupon transitionCoupon = new TransitionCoupon(null, null, blueCouponBaseResult.getAmount(), 
							blueCouponBaseResult.getDescription(), blueCouponBaseResult.getFullAmount(), null, 
							null, sdf.format(blueCouponBaseResult.getValidatedDate()), sdf.format(blueCouponBaseResult.getExpirationDate()),
							blueCouponBaseResult.getType() == null ? null
									: String.valueOf(blueCouponBaseResult.getType()), null, blueCouponBaseResult.getId(), 
									blueCouponBaseResult.getUserId(), cashing, blueCouponBaseResult.getRefPromotionId(),null);

					transitionCoupons.add(transitionCoupon);
				}
			} else if (couponType.equals("1")) {
				// 蓝劵，限制20条
				if(null != oldUserId){
					com.gome.pangu.bluecoupon.dubbo.model.ResultDO<List<BlueCouponBaseResult>> resultBlue = blueCouponQueryService
							.findBlueCouponsByIds(oldUserId, paramList);
					if (!resultBlue.isSuccess())
						return null;
					List<BlueCouponBaseResult> blueCouponBaseResults = resultBlue.getData();
					if (null == blueCouponBaseResults)
						return null;
					
					for (BlueCouponBaseResult blueCouponBaseResult : blueCouponBaseResults) {
						if (null == blueCouponBaseResult)
							continue;
						// 美券类型 1:线上 101:线下（ 1:蓝券 101:美券）
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						TransitionCoupon transitionCoupon = new TransitionCoupon(null, null, blueCouponBaseResult.getAmount(), 
								blueCouponBaseResult.getDescription(), blueCouponBaseResult.getFullAmount(), null, 
								null, sdf.format(blueCouponBaseResult.getValidatedDate()), sdf.format(blueCouponBaseResult.getExpirationDate()),
								blueCouponBaseResult.getType() == null ? null
										: String.valueOf(blueCouponBaseResult.getType()), null, blueCouponBaseResult.getId(), 
										blueCouponBaseResult.getUserId(), null, blueCouponBaseResult.getRefPromotionId(),null);
						
						transitionCoupons.add(transitionCoupon);
					}
				}
			} else if (couponType.equals("0") || couponType.equals("7")) {
				// 红劵
				if(null != oldUserId){
					com.gome.pangu.redcoupon.dubbo.model.ResultDO<List<RedCouponBaseResult>> resultRed = redCouponQueryService
							.findRedCouponsByIds(oldUserId, paramList);
					if (!resultRed.isSuccess())
						return null;
					List<RedCouponBaseResult> redCouponBaseResults = resultRed.getData();
					if (null == redCouponBaseResults)
						return null;
					
					for (RedCouponBaseResult redCouponBaseResult : redCouponBaseResults) {
						if (null == redCouponBaseResult)
							continue;
						// 红券类型 0-普通红券,7-虚拟红券
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						TransitionCoupon transitionCoupon = new TransitionCoupon(null, null,
								redCouponBaseResult.getAmount(), redCouponBaseResult.getDescription(),
								redCouponBaseResult.getFullAmount(), null,
								// null,
								// sdf.format(redCouponBaseResult.getValidatedDate()),
								// sdf.format(redCouponBaseResult.getExpirationDate()),
								null, null, null,
								redCouponBaseResult.getType() == null ? null
										: String.valueOf(redCouponBaseResult.getType()),
										null, redCouponBaseResult.getId(), redCouponBaseResult.getUserId(), null, redCouponBaseResult.getPromotionRule(),null);
						
						// 测试使用
						if (null != redCouponBaseResult.getValidatedDate()
								&& null != redCouponBaseResult.getExpirationDate()) {
							transitionCoupon.setShow_start_time(sdf.format(redCouponBaseResult.getValidatedDate()));
							transitionCoupon.setShow_end_time(sdf.format(redCouponBaseResult.getExpirationDate()));
						}
						
						transitionCoupons.add(transitionCoupon);
					}
				}
			}
		}
		
		return transitionCoupons;
	}
	
	/**
	 * 校验店主是否能看此订单详情
	 * @param orderUserId
	 * @param userId
	 * @return
	 */
	public byte authencationMid(String orderId, String userId){
		logger.info("authencationMid ==> orderId={} userId={} ", orderId, userId);
		MapResults<Boolean> result = iUserShareBindingManager.checkAccessAuthority(Long.valueOf(orderId), Long.valueOf(userId));
		if(result.getCode() == 500) {
			logger.error("authencationMid ==> orderId={} userId={} ", orderId, userId);
			return 1;
		}
		if(result.getBuessObj())
			return 1;
		else
			return 0;
		
	}



//    /**
//     * 获取分享时的默认助力团订单ID
//     *
//     * @param groupId
//     * @param userId
//     * @return
//     */
//    public String getHelpGroupUserInfo(Long groupId, String userId) {
//
//        CommonResultEntity<ShareHelpInfoVo> myGroupHelpInfo = gorderInfoForAppHelpResource.getHelpOrder(groupId, userId);
//        if (null != myGroupHelpInfo && myGroupHelpInfo.isSuccess()) {
//            ShareHelpInfoVo vo = myGroupHelpInfo.getBusinessObj();
//            if (null != vo) {
//                return vo.getOrderId();
//            }
//        }
//        return null;
//    }

    /**
     * 助力信息
     *
     * @param groupId
     * @param orderId
     * @param userId
     * @return
     */
    public HelpGroupInfoVo helpGroupUserInfo(Long groupId, String userId, String currentUserId, String orderId) {
        HelpGroupInfoVo helpGroupInfo = null;
        CommonResultEntity<GroupHelpInfoVo> resultVo = gorderInfoForAppHelpResource.getHelpSituation(groupId, userId, orderId);
        if (null != resultVo && resultVo.isSuccess()) {
            GroupHelpInfoVo vo = resultVo.getBusinessObj();
            if (vo != null) {
                helpGroupInfo = new HelpGroupInfoVo();
                BeanUtils.copyProperties(vo, helpGroupInfo);

                //自己不能给自己助力
                if (userId.equals(currentUserId)) {
                    helpGroupInfo.setHelped(true);
                } else {
                    helpGroupInfo.setHelped(false);
                }
//                //助力成功的团数量
//                CommonResultEntity<String> num = gorderInfoForAppHelpResource.getHelpSuccessCount();
//                if (num != null && num.isSuccess()) {
//                    String count = num.getBusinessObj();
//                    Integer helpSuccessGroupNum = StringUtils.isBlank(count) ? 0 : Integer.parseInt(count);
//                    helpGroupInfo.setHelpSuccessGroupNum(helpSuccessGroupNum);
//                }
                //是否已助力
                if (helpGroupInfo.getHelpUserList() != null && helpGroupInfo.getHelpUserList().size() > 0) {
                    for (GroupUserInfo user : helpGroupInfo.getHelpUserList()) {
                        if (user != null && Long.valueOf(currentUserId).equals(user.getUserId())) {
                            helpGroupInfo.setHelped(true);
                            break;
                        }
                    }
                }
            }

            //助力成功后奖励列表----券
            boolean getCoupon = false;
            if (userId.equals(currentUserId)) {
                //发起者在团成功后可以获得券奖励
                if ("1".equals(helpGroupInfo.getHelpState()) || "0".equals(helpGroupInfo.getHelpState())) {
                    getCoupon = true;
                }
            } else {
                //助力者在助力后可以获得券奖励
                if (helpGroupInfo.getHelped()) {
                    getCoupon = true;
                }
            }

            if (getCoupon) {
                //1--美券   2--pop券
                Integer couponType = vo.getBondType();
                HelpGroupCouponVo cp = new HelpGroupCouponVo();
                if (null != couponType) {
                    String bondType = String.valueOf(couponType.intValue());
                    if (bondType.equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
                        // 根据批次号查询pop劵信息
                        CouponBatchResult couponBatchResult = this.getPopCoupon(vo.getBondBatchNo());
                        if (null != couponBatchResult) {
                            cp.setCoupon_num(couponBatchResult.getDenomination()); // 面额
                            cp.setDescription(couponBatchResult.getDescription());
                            cp.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
                            cp.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券,
                            // 2:平台券
                            cp.setCoupon_id(vo.getBondBatchNo()); // pop劵批次号
                            cp.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            cp.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
                            cp.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));
                        }
                        cp.setCouponPageCode(vo.getPageCode());
                    } else {
                        // 根据券规则ID获取美劵，红蓝券信息

                        CouponRuleInfo blueCoupon = this.getCoupon(vo.getBondBatchNo());
                        if (null != blueCoupon) {
                            cp.setCoupon_id(blueCoupon.getRuleId());
                            cp.setCoupon_num(blueCoupon.getAmount());
                            cp.setFullAmount(blueCoupon.getLimitAmount());
                            cp.setDescription(blueCoupon.getDescription());
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            cp.setShow_start_time(sdf.format(blueCoupon.getCouponStartDate()));
                            cp.setShow_end_time(sdf.format(blueCoupon.getCouponEndDate()));
                            cp.setCouponType(blueCoupon.getType());
                        }
                        cp.setCouponPageCode(vo.getPageCode());
                    }
                }
                helpGroupInfo.setCouponList(Arrays.asList(cp));
            }
        }
        return helpGroupInfo;
    }


    /**
     * 好友助力
     *
     * @param orderId
     * @param groupId
     * @param helpUserId
     * @return
     */
    public Map<String, Object> helpGroup(String orderId, Long groupId, String helpUserId, String userId, String channel, HttpServletRequest request, Map<String, String> ctxMap) throws ServiceException {
        CommonResultEntity<Boolean> resultVo = gorderInfoForAppHelpResource.attendHelp(groupId, userId, helpUserId, orderId);
        Map<String, Object> resultMap = new HashMap<>();
        Boolean result = false;
        if (null != resultVo && resultVo.isSuccess()) {
            result = resultVo.getBusinessObj();
        }

        if (!result) {
            resultMap.put("message", resultVo.getMessage());
        }
        resultMap.put("result", result);
        CommonResultEntity<GroupHelpInfoVo> helpInfoVo = gorderInfoForAppHelpResource.getHelpSituation(groupId, userId, orderId);
        if(null == helpInfoVo || 0 != helpInfoVo.getCode()) {
        	resultMap.put("message", resultVo.getMessage());
        }else {
            if(!"2".equals(helpInfoVo.getBusinessObj().getHelpState())){
                if(result){
                    // 触发领券
                    if (null != helpInfoVo && helpInfoVo.isSuccess()) {
                        GroupHelpInfoVo groupHelpInfoVo = helpInfoVo.getBusinessObj();
                        if(null != groupHelpInfoVo.getBondType()) {
                            String bondSchemeId = groupHelpInfoVo.getBondSchemeId();
                            String bondType = String.valueOf(groupHelpInfoVo.getBondType().intValue());

                            Integer ger = null;
                            String ip = this.getIP(request);
                            
                            if (bondType.equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
                                // pop劵
                                String activeId=getPopCoupon(groupHelpInfoVo.getBondBatchNo()).getActiveId();
                                String popType=String.valueOf(getPopCoupon(groupHelpInfoVo.getBondBatchNo()).getType());
//                                ger=fetchCoupon(popType,groupHelpInfoVo.getBondBatchNo(),helpUserId,activeId,bondSchemeId,request);
                                ger = this.fetchCoupon(popType, groupHelpInfoVo.getBondBatchNo(), helpUserId, activeId, ip, ctxMap);
                            }else {
                                // 红蓝美劵
                                CouponRuleInfo batchResult= getCoupon(groupHelpInfoVo.getBondBatchNo());
                                //if (couponType.equals(GroupOrderConstants.COUPON_TYPE_MEI)) {    //领取美券
                                  /* ger = this.fetchCoupon(bondSchemeId, helpUserId, request);
                                  ger = this.fetchRedBlueCoupon(bondSchemeId, helpUserId, request);*/
//                                ger=fetchCoupon(batchResult.getType(),bondSchemeId,helpUserId,null,groupHelpInfoVo.getBondBatchNo(),request);
                                ger = this.fetchCoupon(batchResult.getType(), bondSchemeId, helpUserId, null, ip, ctxMap);
                            }

                           /* if (bondType.equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
                                CouponBatchResult batchResult=getPopCoupon(groupHelpInfoVo.getBondBatchNo());
                                // 店铺券，平台劵，商品劵
                                ger = this.fetchPOPCoupon(groupHelpInfoVo.getBondBatchNo(), helpUserId, batchResult.getActiveId());
                            } else {
                                CouponRuleInfo batchResult = getCoupon(groupHelpInfoVo.getBondBatchNo());
                                String coupontType = String.valueOf(batchResult.getType());
                                if (coupontType.equals(GroupOrderConstants.COUPON_TYPE_MEI)) {    //领取美券
                                    ger = this.fetchCoupon(bondSchemeId, helpUserId, request);
                                } else if ((coupontType.equals(GroupOrderConstants.COUPON_TYPE_BLUE)) || coupontType.equals(GroupOrderConstants.COUPON_TYPE_RED)) {
                                    ger = this.fetchRedBlueCoupon(bondSchemeId, helpUserId, request); // 红蓝券
                                }
                            }*/
                            resultMap.put("status", ger);
                        }
                    }
                }
            }
        }
        return resultMap;
    }

    /**
     * 我的助力列表信息
     *
     * @param userId
     * @param pageNo
     * @param pageSize
     * @return
     */
    public MyHelpInfoListVo myHelpList(String userId, Integer pageNo, Integer pageSize) {
        if (userId == null) return null;
        MyHelpInfoListVo listVo = new MyHelpInfoListVo();
        List<MyHelpInfoVo> myHelpInfoVos = new ArrayList<>();
        CommonResultEntity<List<MyHelpAwardVo>> resultVo = gorderInfoForAppHelpResource.getMyHelpAward(userId, pageNo, pageSize);
        if (null != resultVo && resultVo.isSuccess()) {
            List<MyHelpAwardVo> awardVos = resultVo.getBusinessObj();
            if (null != awardVos && awardVos.size() > 0) {
                for (MyHelpAwardVo myHelpAwardVo : awardVos) {
                    MyHelpInfoVo myHelpInfoVo = new MyHelpInfoVo();
                    BeanUtils.copyProperties(myHelpAwardVo, myHelpInfoVo);
                    // 封装劵信息
                    HelpGroupCouponVo coupon = new HelpGroupCouponVo();
                    handleBondInfo(coupon, myHelpAwardVo.getBondType(), myHelpAwardVo.getBondBatchNo(), myHelpAwardVo.getPageCode());
                    myHelpInfoVo.setCouponList(Arrays.asList(coupon));
                    myHelpInfoVos.add(myHelpInfoVo);
                }
            }
        }
        listVo.setMyHelpList(myHelpInfoVos);
        return listVo;
    }

    /**
     * 封装劵信息
     *
     * @param myHelpInfoVo
     * @param myHelpAwardVo
     */
    public void handleBondInfo(HelpGroupCouponVo coupon, Integer bondType, String bondBatchNo, String pageCode) {
        if (bondType == null) return;
        String bondTypeStr = String.valueOf(bondType.intValue());
        if (bondTypeStr.equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
            // pop劵
            CouponBatchResult couponBatchResult = getPopCoupon(bondBatchNo);
            if (null != couponBatchResult) {
                coupon.setCoupon_num(couponBatchResult.getDenomination()); // 面额
                coupon.setDescription(couponBatchResult.getDescription());
                coupon.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
                coupon.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券, 2:平台券，3：商品劵
                coupon.setCoupon_id(bondBatchNo); // pop劵批次号
                coupon.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                coupon.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
                coupon.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));
            }
            coupon.setCouponPageCode(pageCode);
        } else {
            // 美劵
            CouponRuleInfo couponRuleInfo = getCoupon(bondBatchNo);
            if (null != couponRuleInfo) {
                coupon.setCoupon_id(couponRuleInfo.getRuleId());
                coupon.setCoupon_num(couponRuleInfo.getAmount());
                coupon.setFullAmount(couponRuleInfo.getLimitAmount());
                coupon.setDescription(couponRuleInfo.getDescription());
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                coupon.setShow_start_time(sdf.format(couponRuleInfo.getCouponStartDate()));
                coupon.setShow_end_time(sdf.format(couponRuleInfo.getCouponEndDate()));
                coupon.setCouponType(couponRuleInfo.getType());
            }
            coupon.setCouponPageCode(pageCode);
        }
    }
    
    /**
     * 商品信息---万人团列表专用
     *
     * @param productId  商品ID
     * @param skuId      商品SKUID
     * @param userId     用户ID
     * @param activityId 活动ID
     * @param groupId    团ID，可为空
     * @param areaCode   区域码
     * @return
     * @throws ServiceException
     */
    public Map<String, Object> getProductInfoForWanren(Long activityId, Long groupId, Long userId, String productId,
                                              String skuId, String areaCode, String orgCode, String storeCode, Integer ppi, Byte ua) throws ServiceException{

        Map<String, Object> resultMap = new HashMap<>();
        ProductDetailVo productDetail = new ProductDetailVo();

        // 商品详情 凑单详情
        ProductManagementVo proManageVo = this.getProductInfoById(activityId, productId, areaCode, skuId);
        ProductVo productVo = copyProduct(proManageVo);
        productVo.setProductId(productId);
        // 获取分辨率
        String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
        // 商品图url处理
        productVo.setProductImage(ImageUtils.imageUrlInfo(productVo.getProductImage(), ratio, ua));

        // 美店价
        MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productId, skuId, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
        if (null != meidianPrice) {
            String mPrice = meidianPrice.getMeidianPrice();
            if (null == mPrice) {
                productVo.setMeidianPrice(DoubleUtils.switchScientificCalculate(productVo.getPrice()));
                productVo.setPriceKey(null);
            } else {
                productVo.setMeidianPrice(mPrice);
                productVo.setPriceKey(meidianPrice.getPriceKey());
            }

        } else {
            productVo.setMeidianPrice(DoubleUtils.switchScientificCalculate(productVo.getPrice()));
            productVo.setPriceKey(null); 
        }

        // 折扣返
        Double meiPrice = Double.valueOf(productVo.getMeidianPrice());
//        Double pr = DoubleUtils.mul(meiPrice, 100d);
//        productVo.setRebateAmount(this.getRebateAmount(pr.longValue(), productVo.getMaxDiscount()));

        // 国美价，美店价处理，美店价大于国美价时，把美店价赋值给国美价
        if (meiPrice.doubleValue() > productVo.getPrice().doubleValue())
            productVo.setPrice(meiPrice);

        productDetail.setProduct(productVo);

        // 团信息
        GroupInfomationVo groupInfomationVo = null;

        GroupInfoVo groupInfo = this.getGroupInfoById(activityId, groupId, areaCode, skuId, null);
        if (groupInfo != null) {
            groupInfomationVo = this.copyGroupInfo(groupInfo);
            groupInfomationVo.setProductInfo(null);
            // 处理用户头像
            if (null != groupInfomationVo.getGroupUser() && groupInfomationVo.getGroupUser().size() > 0)
                ImageUtils.userImageUrlInfo(groupInfomationVo.getGroupUser(), userImage, agreement);
            productDetail.setGroupInfo(groupInfomationVo);
        } else {
            groupInfomationVo = new GroupInfomationVo();
            groupInfomationVo.setStartTime(proManageVo.getEffectiveStartTime());
            groupInfomationVo.setEndTime(proManageVo.getEffectiveEndTime());
            groupInfomationVo.setGroupBusType(proManageVo.getGroupBusType());
            productDetail.setGroupInfo(groupInfomationVo);
        }

//        // 团操作状态信息
//        if (userId != null && null != groupId && groupId != 0) {
//            CommonResultEntity<UserToGroupStatusVo> operationResult = gorderInfoForAppNewResource
//                    .getStatusToGroup(activityId, groupId, userId);
//            if (operationResult != null) {
//                if (operationResult.getBusinessObj() != null) {
//                    int status = operationResult.getBusinessObj().getStatus();
//                    if (groupInfomationVo != null) {
//                        if (groupInfomationVo.getStatus().longValue() == 0) {
//                            if (groupInfomationVo.getHeaderUserId().longValue() == userId.longValue()) {
//                                productDetail.setOperationStatus(3);
//                            } else {
//                                productDetail.setOperationStatus(2);
//                            }
//                        } else {
//                            productDetail.setOperationStatus(status);
//                        }
//                    } else {
//                        productDetail.setOperationStatus(status);
//                    }
//                } else {
//                    productDetail.setOperationStatus(2);
//                }
//            }
//        } else {
//            productDetail.setOperationStatus(2);
//        }
//
//        if (productDetail.getOperationStatus() != 1) {
//            if (proManageVo.getEffectiveEndTime().getTime() < System.currentTimeMillis()) {
//                productDetail.setOperationStatus(4);
//            }
//        }

        List<String> productId_skuIdList = new ArrayList<String>(1);
        StringBuilder sb = new StringBuilder(productId);
        sb.append("_").append(skuId);
        productId_skuIdList.add(sb.toString());
        List<CommodityVo> result = accessGoodsService.getProductStatus(productId_skuIdList);
        // 查询商品上下架状态
        if (null != result && result.get(0) != null) {
            int status = result.get(0).getStatus();
            if (status != 1) {
                // 商品本身已下架
                productDetail.setOperationStatus(4);
            }
        }

        // 商品详情tab
        productDetail.setProductInfo(this.getProductDetail(productId, skuId, areaCode));

//        //获取节能补贴（政府）或者节能优惠（国美）
//        //北京地区使用节能补贴，非北京地区使用节能优惠
//        String skuNo = null;
//        if (StringUtils.isNotBlank(productDetail.getProduct().getSkuNo())) {
//            skuNo = productDetail.getProduct().getSkuNo();
//        } else {
//            SkuItem sku = this.getSkuInfo(productId, skuId);
//            skuNo = sku.getSkuNo();
//        }
//        if (areaCode.startsWith("110")) {
//            //节能补贴
//            if (null != proManageVo.getAllowanceFlag() && proManageVo.getAllowanceFlag() == 1) {
//                SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceById(skuId, areaCode);
//
//                if (skuEnergyAllowance == null && StringUtils.isNotBlank(storeCode) && storeCode.length() == 4 && !storeCode.startsWith("QDMD")) {
//                    skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceByNo(skuNo, orgCode);
//                }
//                if (null != skuEnergyAllowance) {
//                    //显示价大于报备价，则不展示节能补贴
//                    if (null != skuEnergyAllowance.getRecordPrice() && productDetail.getProduct().getPrice().doubleValue() <= skuEnergyAllowance.getRecordPrice().doubleValue()) {
//                        SkuEnergyAllowanceVo skuEnergyAllowanceVo = new SkuEnergyAllowanceVo();
//                        BeanUtils.copyProperties(skuEnergyAllowance, skuEnergyAllowanceVo);
//                        productDetail.setSkuEnergyAllowance(skuEnergyAllowanceVo);
//                    }
//                }
//            }
//        } else {
//            EnergySavingSubsidiesParamDTO param = new EnergySavingSubsidiesParamDTO();
//            param.setSkuNo(skuNo);
//            if (StringUtils.isNotBlank(productDetail.getProduct().getSkuNo())) {
//                param.setSkuNo(productDetail.getProduct().getSkuNo());
//            } else {
//                SkuItem sku = this.getSkuInfo(productId, skuId);
//                param.setSkuNo(sku.getSkuNo());
//            }
//            PromotionScopeDTO scope = new PromotionScopeDTO();
//            scope.setAreaCode(areaCode);
//            scope.setStoreCode(storeCode);
//            scope.setSite(GroupOrderConstants.ENERGY_SAVING_SUBSIDIES_MEIDIAN_SITE);
//
//            String uId = null == userId ? null : userId.toString();
//            ResultDTO<EnergySavingSubsidiesResultDTO> resultDto = energySavingSubsidiesClient.getEnergySavingSubsidiesBySkuNo(uId, param, scope, "detail");
//            if (null != resultDto && resultDto.isSuccess()) {
//                EnergySavingSubsidiesResultDTO dto = resultDto.getData();
//                if (null != dto) {
//                    EnergySavingSubsidiesVo dtoVo = new EnergySavingSubsidiesVo();
//                    BeanUtils.copyProperties(dto, dtoVo);
//                    productDetail.setEnergySavingSubsidies(dtoVo);
//                }
//            }
//        }
//
//
//        // 延保
//        if ((proManageVo.getGroupBusType() == null ? 3 : proManageVo.getGroupBusType().intValue()) != GroupOrderConstants.free_group) {
//            Integer warranty = this.appreciationServeCheckout(productVo.getSkuNo(), productVo.getMeidianPrice(), orgCode);
//            productDetail.setWarranty(warranty);
//        }

        resultMap.put("data", productDetail);
        return resultMap;
    }
    /**
     * 根据券类型领券
     * @param couponType  必填，券类型  3001：美券，3002：蓝券，3003：红券，3005：营销劵， 0：店铺劵-pop， 2：平台劵-pop，3：pop-商品劵
     * @param promoId  必填，pop券传批次号，红蓝美传方案ID
     * @param userId 领券人id，必填
     * @param activeId pop券传活动id，红蓝美不传
     * @param ip 机器ip
     * @return 0：成功 其他失败
     */
    public Integer fetchCoupon(String couponType, String promoId, String userId, String activeId, String ip, Map<String, String> requestHeader) {
        Integer result = GroupOrderConstants.FETCH_COUPON_COMMON_FAIL_MSG;
        if (couponType.equals(GroupOrderConstants.COUPON_TYPE_MEI)
        		|| couponType.equals(GroupOrderConstants.COUPON_TYPE_MARKETING)) {    
        	
        	//领取美券，营销劵
            result = this.fetchCoupon(promoId, userId, ip, requestHeader);
        } else if (couponType.equals(GroupOrderConstants.COUPON_TYPE_BLUE)
                || couponType.equals(GroupOrderConstants.COUPON_TYPE_RED)) { 
        	
        	// 红蓝券
            result = this.fetchRedBlueCoupon(promoId, userId, ip, requestHeader);
        } else if (couponType.equals(GroupOrderConstants.COUPON_TYPE_POP_SHOP)
                || couponType.equals(GroupOrderConstants.COUPON_TYPE_POP_PLATFORM)
                || couponType.equals(GroupOrderConstants.COUPON_TYPE_POP_PRODUCT)
        ) {

            // 店铺券，平台劵，商品劵
            result = this.fetchPOPCoupon(promoId, userId, activeId);
        }
        return result;
    }
    
	/**
	 * 根据skuid领券（pop+自营）
	 * @param shopNo
	 * @param skuId
	 * @param price
	 * @param userId
	 * @param areaCode
	 * @return
	 */
	public List<Coupon> getCouponBySkuId(String productId, String skuId, String userId, 
			String areaCode) {
		
		List<Coupon> coupons = new ArrayList<Coupon>();
		
		// 0.获取productId
		String param = null;
		if(null == productId || productId.equals("")){
			String propers[] = {"productIds"};
			Map<String, String> paramMap = prodDetailService.getSkuMultiProperties(skuId, propers);
			if(null == paramMap) return null;
			String productIds = paramMap.get("productIds");
			if(null == productIds || productIds.equals("")) return null;
			String proId = null;
			if(productIds.contains(":")){
				proId = productIds.split(":")[0];
			}else
				proId = productIds;
			if(null == proId) return null;
			param = proId + "_" + skuId + "_" + areaCode;
		} else
			param = productId + "_" + skuId + "_" + areaCode;
		
		// 1.获取商品信息
		List<String> params = new ArrayList<String>();
		params.add(param);
		List<ProductShopInfo> productShopInfos = accessGoodsService.getMutiProductByStore(params);
		if(null == productShopInfos || productShopInfos.size() == 0) return null;
		ProductShopInfo productShopInfo = productShopInfos.get(0);
		if(null == productShopInfo) return null;
		String proId = productShopInfo.getId();
		
		// 2.获取美店价
		GomeVipPriceItem gomeVipPriceItem = iGomeVipPriceService.getVipPrice(proId, skuId, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
		if(null == gomeVipPriceItem) return null;
		Double mdPrice = gomeVipPriceItem.getFinalPrice();
		
		// 3.获取券信息
		int productTag = productShopInfo.getProductTag();
		if(productTag == 1){
			// 自营
			this.ownCouponInfo(skuId, 1, mdPrice, areaCode,
		    		userId, coupons);
		}else if(productTag == 2){
			// 联营
			QueryShopCouponParam shopCoupon = new QueryShopCouponParam();
			shopCoupon.setShopNo(productShopInfo.getShopId());
			shopCoupon.setSku(productShopInfo.getSkuNo());
			shopCoupon.setPrice(mdPrice);
			shopCoupon.setUserId(userId);
			ResultDO<List<CouponBatchResult>> popCouponResp = iCouponAndBatchManager.getDarwPlatformCoupon(shopCoupon);
			if (null != popCouponResp
					&& null != popCouponResp.getData()
					&& popCouponResp.getData().size() > 0) {
				
				for(CouponBatchResult popCoupon : popCouponResp.getData()){
					Coupon coupon=new Coupon();
					coupon.setCoupon_num(popCoupon.getDenomination()); // 面额
					coupon.setDescription(popCoupon.getDescription());
					coupon.setFullAmount(popCoupon.getLimitPrice()); // 满多少元可用
					coupon.setCouponType(String.valueOf(popCoupon.getType())); // 0:店铺券, 2:平台券，3：商品劵
					coupon.setCoupon_id(popCoupon.getCode()); // pop劵批次号
					coupon.setActiveId(popCoupon.getActiveId()); // 领取标识，劵活动id
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
					coupon.setShow_start_time(sdf.format(popCoupon.getStartDate()));
					coupon.setShow_end_time(sdf.format(popCoupon.getEndDate()));
					// pop劵加密
					String id = CouponEncryptionUtil.popCouponEncryption(popCoupon.getCode(), coupon.getCouponType(), popCoupon.getShopNo(), popCoupon.getActiveId());
					coupon.setEncryptionId(id);
					coupons.add(coupon);
				}
			}
			
			// 全场红
			this.ownCouponInfo(skuId, 2, mdPrice, areaCode,
		    		userId, coupons);
		}
		
		return coupons;
	}
	
    /**
     * 我发起的助力团列表
     * @param pageNo
     * @param pageSize
     * @param userId
     * @return
     */
    public List<MyGroupHelpInfo> sponsoredHelpList(Integer pageNo, Integer pageSize, Long userId) {
    	if(null == userId) return null;
    	List<MyGroupHelpInfo> resultList = null;
    	CommonResultEntity<MyGroupHelpInfoVo> list = gorderInfoForAppHelpResource.myHelpList(userId, pageNo, pageSize);
    	if(null != list && list.isSuccess()) {
    		MyGroupHelpInfoVo vo = list.getBusinessObj();
    		if(null != vo && null != vo.getHelpInfoList() && vo.getHelpInfoList().size() > 0) {
    			resultList = new ArrayList<>();
    			MyGroupHelpInfo info = null;
    			HelpGroupCouponVo couponVo = null;
    			for(GroupHelpInfoVo v: vo.getHelpInfoList()) {
    				info = new MyGroupHelpInfo();
    				BeanUtils.copyProperties(v, info);
    				
    				couponVo = new HelpGroupCouponVo();
    				handleBondInfo(couponVo, v.getBondType(), v.getBondBatchNo(), v.getPageCode());
    				info.setCouponList(Arrays.asList(couponVo));
    				resultList.add(info);
    			}
    		}
    	}
    	return resultList;
    }
    
    /**
     * 促销语
     * @throws ServiceException 
     */
    public List<Promotion> promotion(String productId, String skuId, String price, 
    		String areaCode, String storeCode, Integer storeType,
    		String site,String skuNo,String shopNo) throws ServiceException{
    	List<Promotion> promotions =null;
    	//获取商品分类信息
    	Map<String, String> data = getSkuCategory(skuId);
		String  firstCatltemId= data.get("firstCatItemId");
		String  secCatltemId= data.get("secCatItemId");
		String  thridCatltemId= data.get("thridCatItemId");
		// ZBBC是联营 ZSP自营
		String  sapSkuType= data.get("sapSkuType");
    	//自营
		if(sapSkuType==null)return null;
    	if(!"ZBBC".equals(sapSkuType)){
    		GomePromotionForDetailDTO detailDTO = new GomePromotionForDetailDTO();
        	detailDTO.setSkuId(skuId);
        	// 二级区域码
        	detailDTO.setAreaCode(areaCode);
        	// 美店传美店价
        	detailDTO.setUnitPrice(new BigDecimal(price));
        	// 促销叠加标识，N:屏蔽使用
        	detailDTO.setSuperpositionType("N");
        	// 美店站点（暂时传促销定义的站点）
        	detailDTO.setSite(propertiesConfig.getPromotionSite());
        	// 1.门店brand
        	logger.info("promotion getStoreInfo ==> storeCode: {} storeType: {}", storeCode, storeType);
        	Store store = storeManager.getStoreInfo(storeCode, storeType, null, null);
        	if(null != store)
        		detailDTO.setShopBrand(store.getBrand());
        	// 2.商品属性 G3PP 3PP SMI(电器城) SMI-T(百货城)
        	Map<String, String> paramMap = this.skuProd(skuId);
        	String skuType = paramMap.get("skuType");
        	String sellType = paramMap.get("sellType");
        	String sType = null;
        	if(null != sellType){
        		if(sellType.equals("1")){
        			sType = "G3PP";
        		}else if(sellType.equals("5")){
        			sType = "3PP";
        		}else if(sellType.equals("0")){
        			if(null != skuType && skuType.equals("4009")){
        				sType = "SMI_T";
        			}else{
        				sType = "SMI";
        			}
        		}
        	}
        	detailDTO.setSkuType(sType);
        	
//        	// 3.商品三级分类id
//           	Map<String, String> pidMap = this.pIdProduct(productId);
//        	 detailDTO.setCategoryId(pidMap.get("thridCatItemId"));
        	// 3.商品三级分类id
        	detailDTO.setCategoryId(thridCatltemId);
        	
        	// 4.商品品牌id
        	detailDTO.setBrandCode(paramMap.get("brandCode"));
        	
        	logger.info("promotion getAvailablePromotionForWirelessDetail gcc==> reqParam: {}", JSONUtils.toJSONString(detailDTO));
        	
            ResultDTO<Map<String, List<GomePromotionForDetailResultDTO>>> resDTO = gomePromotionForDetailClient.getAvailablePromotionForWirelessDetail(detailDTO);	
           
            String errCode = resDTO.getErrCode();
            if(!errCode.equals("0")) return null;
            Map<String, List<GomePromotionForDetailResultDTO>> map = resDTO.getData();
            if(null == map) return null;
            List<GomePromotionForDetailResultDTO> gomePpromotions = map.get("106");
            promotions = new ArrayList<Promotion>();
            if(null != gomePpromotions && gomePpromotions.size() > 0) {
            	this.pomotion(gomePpromotions, promotions, "满返");
            }
            
            List<GomePromotionForDetailResultDTO> promotionResultDTOs = map.get("102");
            if(null != promotionResultDTOs && promotionResultDTOs.size() > 0) {
            	this.pomotion(promotionResultDTOs, promotions, "赠品");
            }
            
    	}else{
    		//联营
        	ProProduct product=new ProProduct();
        	// 1.商品skuNo
        	product.setProductId(skuNo);
        	// 2. 店铺编码
        	product.setVenderId(shopNo);
        	// 3.商品三级分类id
        	product.setSellCtgyId3Rd(thridCatltemId);
        	// 4.一级分类ID
        	product.setPcatalogId(firstCatltemId);
        	// 5.二级分类ID
        	product.setCatalogId(secCatltemId);
        	// 6.二级区域编码
        	AreaInfo areaInfo=new AreaInfo();
        	areaInfo.setAreaCode2(areaCode);
        	product.setAreaInfo(areaInfo);
        	logger.info("promotion pop ==> reqParam: {}", JSONUtils.toJSONString(product));
        	List<PromotionProductShowPageInterfaceBean> promoProductList = proPromInterfaceManager.product(product);
        	if(promoProductList == null) return null; 
        	promotions = new ArrayList<Promotion>();
    		for(PromotionProductShowPageInterfaceBean promoProduct : promoProductList){
    			//仅支持 2满返 50单品赠营销券（神券）51多品赠营销券（神券）
//    			1=满减 2=满返 3=满赠 4=满折 9=掌上专享价 10=直降? 11=单品包邮 12 = 商品预售? 13= 限购促销 14=跨店铺满减 15=跨店铺满免 16=拼团 50单品赠营销券 51多品赠营销券
    			if(null == promoProduct || null == promoProduct.getScheme()) continue;
    			int type = promoProduct.getScheme().intValue();
    			if(type == 2 
    					|| type == 50
    					|| type == 51){
    				
					String promotionId = promoProduct.getPromotionId() != null ? promoProduct.getPromotionId().toString() : null;
					List<Condition> conditions = null;
					if(null != promoProduct.getGiftList() && promoProduct.getGiftList().size() > 0){
						// 赠品
						List<Gift> gifts = null; 
						for (ProPresent giftDTO : promoProduct.getGiftList()) {
							if(null == giftDTO) continue;
							gifts = new ArrayList<Gift>();
							Gift gift = new Gift(giftDTO.getItemId(),giftDTO.getItemName(),giftDTO.getQuantity(),giftDTO.getProductId(),null,null,null);
							gifts.add(gift);
						}
						conditions = new ArrayList<Condition>();
						Condition condition =new Condition();
						condition.setGift(gifts);
						conditions.add(condition);
					}
					String tag = null;
					if(type == 2)
						tag = "满返";
					else if(type == 50)
						tag = "赠品";
					else if(type == 51)
						tag = "跨店铺满送";
					Promotion promotion = new Promotion(promotionId, String.valueOf(type), promoProduct.getAds(),
							null, null, conditions, 
							tag);
					promotions.add(promotion);
    			}
    			
    		}
    	}
    	
        return promotions;
    }

	private Map<String, String> getSkuCategory(String skuId) {
		BombDTO<Map<String, String>> skuMultipleInfo = gomeBombMultipleSkuService.getSkuMultipleInfo(SKU_CATEGORY_MID, skuId);
    	if(!skuMultipleInfo.getErrCode().equals("200")) return null;
		Map<String, String> data = skuMultipleInfo.getData();
		if(null==data) return null;
		return data;
	}
    
    /**
     * 根据skuId获取商品信息
     * @param skuId
     * @return
     */
    public Map<String, String> skuProd(String skuId){
    	Map<String, String> paramMap = null;
    	String key = skuId + "_prodMap";
    	String cacheParam = gcache.get(key);
    	if(null == cacheParam){
    		String propers[] = {"skuType", "sellType", "eaBrandCode"};
        	paramMap = prodDetailService.getSkuMultiProperties(skuId, propers);
        	if(null == paramMap){
        		paramMap = new HashMap<String, String>();
        		paramMap.put("cache", "0");
        	}
        	gcache.setex(key, 10 * 60, JSONUtils.toJSONString(paramMap).getBytes());
        	
        	return paramMap;
    	}
    	
    	paramMap = new HashMap<String, String>();
    	JSONObject jsonObject = JSONObject.parseObject(cacheParam);
    	paramMap.put("skuType", jsonObject.getString("skuType"));
    	paramMap.put("sellType", jsonObject.getString("sellType"));
    	paramMap.put("brandCode", jsonObject.getString("eaBrandCode"));
    	
    	return paramMap;
    }
    
    /**
     * 根据商品productId获取商品属性
     * @param productId
     * @return
     */
    public Map<String, String> pIdProduct(String productId){
    	Map<String, String> paramMap = null;
    	String key = productId + "_prodMap";
    	String cacheParam = gcache.get(key);
    	if(null == cacheParam){
    		String propers[] = {"thridCatItemId"};
        	paramMap = prodDetailService.getProductMultiProperties(productId, propers);
        	if(null == paramMap){
        		paramMap = new HashMap<String, String>();
        		paramMap.put("cache", "0");
        	}
        	gcache.setex(key, 10 * 60, JSONUtils.toJSONString(paramMap).getBytes());
        	
        	return paramMap;
    	}
    	
    	paramMap = new HashMap<String, String>();
    	JSONObject jsonObject = JSONObject.parseObject(cacheParam);
    	paramMap.put("thridCatItemId", jsonObject.getString("thridCatItemId"));
    	
    	return paramMap;
    }
    
    /**
     * 处理图片
     * @param sku
     */
    public void skuImage(Sku sku, Integer ppi, Byte ua){
		// 处理图片
        List<FSImgBase> skus = sku.getSkuImgs();
		if (skus != null && skus.size() > 0) {
			// 获取分辨率
			String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
			for (FSImgBase fsimgBase : skus) {
				String src = fsimgBase.getSrc();
				if (src != null && !src.equals("")) {
					StringBuffer imageInfo = new StringBuffer(src);
					imageInfo.append(ratio);
					if (ua == 1) {
						// 安卓
						imageInfo.append(".webp");
						fsimgBase.setSrc(new String(imageInfo));
					} else {
						imageInfo.append(".jpg");
						fsimgBase.setSrc(new String(imageInfo));
					}
				}
			}
		}
    }
    
    /**
     * 商品介绍处理协议
     * @param productInfo
     * @throws ServiceException
     */
    public String proDes(String url) throws ServiceException{
    	
    	if(null == url) return url;
    	
    	if(url.contains("http:")){
    		// 替换协议
    		url = url.replaceFirst("http:", agreement);
    	}else if(url.contains("https:")) {
    		
    	}else{
    		// 追加协议
    		 StringBuilder sb = new StringBuilder(url);
    	     sb.insert(0, agreement);
    	     url = String.valueOf(sb);
    	}
    	
    	String proDes = null;
		try {
			proDes = httpClientUtil.doGet(url);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(null == proDes) return null;
		if(proDes.contains("src=\"http:")){
    		// 替换协议
			proDes = proDes.replace("src=\"http:", "src=\"" + agreement);
    	}
		if(proDes.contains("src='http:")){
			// 替换协议
			proDes = proDes.replace("src='http:", "src='" + agreement);
		}
		
		return proDes;
    }
    
    public void ownCouponInfo(String skuId, Integer productTag, Double mdPrice, String areaCode,
    		String userId, List<Coupon> coupons){
    	CouponPromListParamDTO couponProm = new CouponPromListParamDTO();
		couponProm.setSkuId(skuId);
		couponProm.setPrice(mdPrice);
		// 商详页传1
		couponProm.setQty(1);
		couponProm.setAreaCode(areaCode);
		ResultDTO<Map<String, List<CouponPromListResultDTO>>> couponResp = couponPromotionClient.getCouponPromsForWireless(couponProm, userId);
		if (null != couponResp
				&& null != couponResp.getData()) {
			
			Collection<List<CouponPromListResultDTO>> values = couponResp.getData().values();
			
			if(null != values){
				for(List<CouponPromListResultDTO> value : values){
					if(null == value) continue;
					for(CouponPromListResultDTO couponPromResp : value){
						if(null == couponPromResp) continue;
						Coupon coupon = new Coupon();
						// red红券, blue蓝券, mei美券, market营销券
						if(couponPromResp.getCouponType().equals(CouponEnum.RED.getCode())){
							coupon.setCouponType(CouponEnum.RED.getId());
						} else if(couponPromResp.getCouponType().equals(CouponEnum.BLUE.getCode())){
							if(productTag == 2) {
								continue;
							}
							coupon.setCouponType(CouponEnum.BLUE.getId());
						} else if(couponPromResp.getCouponType().equals(CouponEnum.MEI.getCode())){
							if(productTag == 2) {
								continue;
							}
							coupon.setCouponType(CouponEnum.MEI.getId());
						} else if(couponPromResp.getCouponType().equals(CouponEnum.MARKET.getCode())){
							if(productTag == 2) {
								continue;
							}
							coupon.setCouponType(CouponEnum.MARKET.getId());
						} else if(couponPromResp.getCouponType().equals("service")){
							continue;
						}
						coupon.setCoupon_id(couponPromResp.getCouponRuleId());
						coupon.setCoupon_num(Double.valueOf(couponPromResp.getCouponValue()));
						coupon.setFullAmount(Double.valueOf(couponPromResp.getLimitPrice() == null ? "0" : couponPromResp.getLimitPrice()));
						coupon.setDescription(couponPromResp.getCouponShowName());
						SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd");
						coupon.setShow_start_time(couponPromResp.getUseStartDate() != null ? sdf.format(couponPromResp.getUseStartDate()) : null);
						coupon.setShow_end_time(couponPromResp.getUseEndDate() != null ? sdf.format(couponPromResp.getUseEndDate()) : null);
						coupon.setValidity(couponPromResp.getCouponUseDays());
						
			
						
						// 方案id=活动id
						coupon.setPlan_id(couponPromResp.getPromId());
						// 美红蓝营销劵加密
						String id = CouponEncryptionUtil.beautifulCouponEncryption(couponPromResp.getPromId(), coupon.getCouponType());
						coupon.setEncryptionId(id);
						coupons.add(coupon);
					}
				}
			}
		}
    }
    
    public void pomotion(List<GomePromotionForDetailResultDTO> gomePpromotions, List<Promotion> promotions, String tag){
    	
    	 for (GomePromotionForDetailResultDTO gomePromotion : gomePpromotions) {
         	if(null == gomePromotion) continue;
         	List<GomePromotionConditionDTO> gomeConditions = gomePromotion.getConditions();
         	List<Condition> conditions = null;
         	if(null != gomeConditions && gomeConditions.size() > 0){
         		conditions = new ArrayList<Condition>();
         		for (GomePromotionConditionDTO gomeCondition : gomeConditions) {
 					if(null == gomeCondition) continue;
 					List<GiftDTO> giftDTOs = gomeCondition.getGifts();
 					List<Gift> gifts = null;
 					if(null != giftDTOs && giftDTOs.size() > 0){
 						// 赠品
 						gifts = new ArrayList<Gift>();
 						for (GiftDTO giftDTO : giftDTOs) {
 							if(null == giftDTO) continue;
 							
 							Gift gift = new Gift(giftDTO.getGiftId(), giftDTO.getGiftName(), giftDTO.getGiftNum(), 
 									giftDTO.getProductId(), giftDTO.getGiftType(), giftDTO.getGroupNo(),
 									giftDTO.getGetGiftPrice());
 							gifts.add(gift);
 						}
 					}
 					
 					Condition condition = new Condition(gomeCondition.getUpLimit().toString(), gomeCondition.getLowerLimit().toString(), gomeCondition.getConditionType(), 
 							gifts);
 					conditions.add(condition);
 				}
         	}
         	
         	Promotion promotion = new Promotion(gomePromotion.getPromotionId(), gomePromotion.getShowType(), gomePromotion.getPromotionDesc(), 
         			gomePromotion.getCouponType(), gomePromotion.getLink(), conditions,
         			tag);
         	promotions.add(promotion);
 		}
    }
    
	/**
	 * 组团sku详情 (美店小程序与国美小程序融合使用)
	 * 
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @return
	 * @throws ServiceException
	 */
	public GroupSkuVo getGroupInfoBySkuId(String skuId) throws ServiceException {
		GroupSkuVo groupSkuVo = new GroupSkuVo();
		// 4. 根据skuId获取商品集信息
		GroupActivityInfo groupActivityInfo = this.getActivityInfo(skuId);
		groupSkuVo.setGroupActivityInfo(groupActivityInfo);

		return groupSkuVo;
	}
}
