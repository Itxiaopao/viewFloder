package com.gome.meidian.grouporder.manager.mshopUserManager;

import cn.com.gome.gcoin.dubbo.AccountFacadeService;
import cn.com.gome.gcoin.dubbo.bean.GCoin_ParametersVo;
import cn.com.gome.gis.dto.GisResultDto;
import cn.com.gome.gis.dubbo.CommonUploadService;
import cn.com.gome.gis.dubbo.UploadImageInfoService;
import com.alibaba.fastjson.JSON;
import com.gome.meidian.grouporder.utils.AesUtils;
import com.gome.meidian.grouporder.vo.mshopUserVo.GomeHelpStatus;
import com.gome.meidian.grouporder.vo.mshopUserVo.GomeHelpVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.reponse.StatusCode;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.service.IGrantRebateService;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MeidianBindingRelationDto;
import com.gome.meidian.user.manager.IMeidianBindingRelationManager;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import com.gome.userBase.model.weChat.GomeShopBasicInfoModel;
import com.gomeplus.bs.framework.dubbor.exceptions.code4xx.C422Exception;
import com.gomeplus.bs.interfaces.bone.common.CommonResultEntity;
import com.gomeplus.bs.interfaces.bone.dubbo.IPromoterDubbo;
import com.gomeplus.bs.interfaces.bone.dubbo.IPromotionPlanDubbo;
import com.gomeplus.bs.interfaces.bone.promoter.dto.CreatePromoterDto;
import com.gomeplus.bs.interfaces.bone.promoter.vo.InternalPromoterVo;
import com.gomeplus.bs.interfaces.bone.promplan.dto.CreateNormalPromotionPlanDto;
import com.gomeplus.bs.interfaces.bone.promplan.vo.CreatePromotionPlanVo;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.primitives.Longs;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author chenchen56
 * 小美帮帮需求开发
 */
@Slf4j
@Service
public class GomeHelpManager {

    public static final String GOME_SHOP = "gomeShop";
    public static final int USER_LIST_PAGE_SIZE = 3;
    public static final int MAX_PUSERID_SIZE = 30;
    @Autowired
    private IMeidianBindingRelationManager meidianBindingRelationManager;
    @Autowired
    private IGomeShopWeChatFacade gomeShopWeChatFacade;
    @Autowired
    private IGrantRebateService grantRebateService;
    @Autowired
    private IPromoterDubbo promoterDubbo;
    @Autowired
    private IPromotionPlanDubbo iPromotionPlanDubbo;
    @Autowired
    private AccountFacadeService accountFacadeService;
    /**
     * GFS上传凭证token
     */
    @Value("${gfs.mshop_cms_gfs_token}")
    private String token;

    public static final Long IMAGE_MAX_SIZE = 5242880L; //图片上传限制 5M

    @Autowired
    private CommonUploadService commonUploadService;
    @Autowired
    private UploadImageInfoService uploadImageInfoService;
    /**
     * 小美帮帮新建绑定关系
     * @param puserId
     * @param userId
     * @param channel
     * @param invokeFrom
     * @return
     */
    public ResponseJson<Map<String, Object>> addBinding(Long puserId, Long userId, String channel, String invokeFrom) {
        log.info("新建绑定关系入参,puserId:{},userId:{},channel:{},invokeFrom:{}",puserId,userId,channel,invokeFrom);
        ResponseJson<Map<String, Object>> mapResponseJson = new ResponseJson<>();
        try {
            MeidianBindingRelationDto meidianBindingRelationDto = new MeidianBindingRelationDto();
            meidianBindingRelationDto.setPuserId(puserId);
            meidianBindingRelationDto.setUserId(userId);
            meidianBindingRelationDto.setChannel(channel);
            MapResults<Integer> integerMapResults = meidianBindingRelationManager.addBindingRelation(meidianBindingRelationDto, "meidian-restful");
            if(null != integerMapResults && integerMapResults.getSuccess() && integerMapResults.getBuessObj().equals(1)){
                return mapResponseJson;
            }else{
                mapResponseJson.setCode(501);
                mapResponseJson.setMsg("小美帮帮新建绑定关系服务端异常");
            }
        }catch (Exception e){
            log.error("小美帮帮新建绑定关系异常,userId:{},puserId:{},异常信息:{},",userId,puserId,e);
            mapResponseJson.setCode(502);
            mapResponseJson.setMsg("Gomehelp新建注册绑定出现异常");
        }
        return mapResponseJson;
    }

    /**
     * 新建员工推广员
     * @param userId 用户id
     * @param employeeOrigin 来源
     * @param employeeId 员工id
     * @return
     */
    public String createInternalPromoter(String userId,Integer employeeOrigin,String employeeId){
        ResponseJson<String> responseJson = new ResponseJson<>();
        String promoterId = null;
        try{
            log.info("新建员工推广员入参,userId:{},employeeOrigin:{},employeeId:{}",userId,employeeOrigin,employeeId);
            CreatePromoterDto createPromoterDto = new CreatePromoterDto();
            HashMap<String, Object> applyInfo = new HashMap<>(2);
            applyInfo.put("employeeOrigin",employeeOrigin);
            applyInfo.put("employeeId",employeeId);
            createPromoterDto.setApplyInfo(applyInfo);
            //默认值
            createPromoterDto.setOrigin(0);
            //默认值
            createPromoterDto.setType(0);
            createPromoterDto.setUserId(userId);
            CommonResultEntity<InternalPromoterVo> internalPromoter = promoterDubbo.createInternalPromoter(createPromoterDto);
            if(null != internalPromoter && internalPromoter.isSuccess() && null != internalPromoter.getBusinessObj()){
                InternalPromoterVo businessObj = internalPromoter.getBusinessObj();
                promoterId = businessObj.getPromoterId();
            }else{
                log.error("创建推广员底层异常,返回值为空,userId:{},employeeOrigin:{},employeeId:{}",userId,employeeOrigin,employeeId);
            }
        }catch (Exception e){
            log.error("新建员工推广员出错,userId:{},employeeOrigin:{},employeeId:{},异常信息:{}",userId,employeeOrigin,employeeId,e);
        }
        return promoterId;
    }

    /**
     * 新建推广员方案
     * @param userId
     * @param businessId
     * @param content
     * @param locationId
     * @return
     */
    public HashMap<String, String> createNormalPromotionPlan(String userId, String businessId, String content, String locationId) {
        HashMap<String, String> hashMap = new HashMap<>(3);
        try {
            log.info("创建通用计划入参,userId:{},businessId:{},content:{},locationId:{}",userId,businessId,content,locationId);
            //业务唯一id
            String reqBusinessId = businessId + userId;
            //数据来源默认为小美帮帮
            int dataFrom = 4;
            //推广类型为默认 8:app下载
            int type = 8;
            //推广内容类型为11：活动页
            int contentType = 11;
            //结算类型 默认为20：cpa
            List<Integer> settlement = new ArrayList<Integer>(1);
            settlement.add(20);
            CreateNormalPromotionPlanDto createNormalPromotionPlanDto = new CreateNormalPromotionPlanDto();
            createNormalPromotionPlanDto.setCreateUserId(userId);
            createNormalPromotionPlanDto.setBusinessId(reqBusinessId);
            createNormalPromotionPlanDto.setDataFrom(dataFrom);
            createNormalPromotionPlanDto.setType(type);
            createNormalPromotionPlanDto.setContentType(contentType);
            createNormalPromotionPlanDto.setContent(content);
            createNormalPromotionPlanDto.setLocationId(locationId);
            createNormalPromotionPlanDto.setSettlement(settlement);
            CommonResultEntity<CreatePromotionPlanVo> normalPromotionPlan = iPromotionPlanDubbo.createNormalPromotionPlan(createNormalPromotionPlanDto);
            if(null != normalPromotionPlan && normalPromotionPlan.isSuccess() && null != normalPromotionPlan.getBusinessObj() ){
                CreatePromotionPlanVo businessObj = normalPromotionPlan.getBusinessObj();
                hashMap.put("longLink",businessObj.getLongLink());
                hashMap.put("shortLink",businessObj.getShortLink());
                hashMap.put("qRCodeUrl",businessObj.getQRCodeUrl());
            }else{
                log.info("创建通用计划返回值为空:userId:{},businessId:{},content:{},locationId:{}",userId,businessId,content,locationId);
            }
        }catch (Exception e){
            log.error("创建推广员通用计划异常:{}",e);
        }
        return hashMap;
    }
    /**
     * 查询用户列表
     * @param currentUser
     * @return
     */
    public List<GomeHelpVo> getInviteUserList(String currentUser){
         //调用接口查找邀请人信息列表
        Map<String, Object> param = new HashMap<>();
        param.put("puserId", currentUser);
        param.put("pageIndex", 0);
        param.put("pageSize", USER_LIST_PAGE_SIZE);

        List<MeidianBindingRelationDto> listByParam = getListByParam(param);
        return packageUserList(listByParam);
    }

    /**
     * 查询用户注册数，收单数，预计收益
     * @param currentUser
     * @param beginTime
     * @param endTime
     * @return
     */
    public Map<String,Object> getUserCount(String currentUser, String beginTime, String endTime) {
        //注册数，收单数，预计收益
        Map<String, Object> param = new HashMap<>();
        param.put("beginTime", beginTime);
        param.put("endTime", endTime);
        param.put("puserId", currentUser);

        List<MeidianBindingRelationDto> countByStatus = getCountByStatus(param);
        Map<Integer, MeidianBindingRelationDto> map = convertToMap(countByStatus, input -> input.getStatus());
        //调预计收益
        Integer awardPrice = getIncomeByPuserIdWithDate(currentUser, beginTime, endTime);

        Double income = BigDecimal.valueOf(awardPrice).divide(BigDecimal.valueOf(100)).setScale(2, RoundingMode.HALF_UP).doubleValue();
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("awardPrice", income);
        Integer register = Optional.ofNullable(map.get(GomeHelpStatus.REGISTER.getCode())).map(i -> i.getCount()).orElse(0);
        Integer firstOrder = Optional.ofNullable(map.get(GomeHelpStatus.APPFIRST.getCode())).map(i -> i.getCount()).orElse(0);
        Integer cancel = Optional.ofNullable(map.get(GomeHelpStatus.CANCEL.getCode())).map(i -> i.getCount()).orElse(0);
        //已注册+首单+失效
        resultMap.put("register", register + firstOrder + cancel);
        resultMap.put("firstOrder", firstOrder);
        return resultMap;

    }
    /**
     * 查询CPA报表列表信息
     * @param currentUser
     * @param beginTime
     * @param endTime
     * @return
     */
    public List<GomeHelpVo> getTableList(String currentUser,int pageNo, int pageSize,String beginTime, String endTime) {
        //调用接口查找邀请人信息列表
        Map<String, Object> param = new HashMap<>();
        param.put("puserId", currentUser);
        param.put("pageIndex", (pageNo - 1) * pageSize);
        param.put("pageSize", pageSize);
        param.put("beginTime", beginTime);
        param.put("endTime", endTime);
        //查询用户列表
        List<MeidianBindingRelationDto> listByParam = getListByParam(param);
        return packageUserList(listByParam);
    }

    /**
     * 查询前30位邀请人的人数和收益
     * @return
     */
    public List<GomeHelpVo> getMaxPuserIdList() {
        Map<String, Object> param = new HashMap<>();
        param.put("pageSize", MAX_PUSERID_SIZE);
        param.put("status", GomeHelpStatus.APPFIRST.getCode());
        //前30位邀请人数据
        List<MeidianBindingRelationDto> countByPuserId = getCountByPuserId(param);
        Map<Long, MeidianBindingRelationDto> userRelationMap = convertToMap(countByPuserId, input -> input.getPuserId());
        List<String> puserIds = userRelationMap.keySet().stream().map(i -> String.valueOf(i)).collect(Collectors.toList());
        //调会员
        Map<String, GomeShopBasicInfoModel> gomeShopMap = selectGomeShopBasicInfoModelMap(puserIds);
        //调预计收益接口
        List<Long> puserIdList = userRelationMap.keySet().stream().collect(Collectors.toList());
        Map<Long, Double> longDoubleMap = selectMaxPuserIdPredictionIncome(puserIdList);

        List<GomeHelpVo> resultList = Lists.newArrayListWithExpectedSize(puserIds.size());
        for (String puserId : puserIds) {
            Long pid = Longs.tryParse(puserId);
            GomeHelpVo gomeHelpVo = GomeHelpVo.builder().userId(pid)
                    .nickName(Optional.ofNullable(gomeShopMap.get(puserId)).map(i -> i.getGomeNickName()).orElse(""))
                    .awardPrice(Optional.ofNullable(longDoubleMap.get(pid)).orElse(0.00))
                    .firstOrdernNum(userRelationMap.get(pid).getCount()).build();
            resultList.add(gomeHelpVo);

        }
        return resultList;

    }


    private Integer getIncomeByPuserIdWithDate(String currentUser, String beginTime, String endTime) {
        long startTime = System.currentTimeMillis();
        Integer awardPrice = 0;
        try {
            awardPrice = Optional
                    .ofNullable(grantRebateService.predictionIncomeByDate(Longs.tryParse(currentUser), beginTime, endTime)).map(
                    i -> i.getBusinessObj())
                    .orElseGet(() -> {
                        log.warn(
                                "GomeHelpManager.getUserCount.getIncomeByPuserIdWithDate.predictionIncomeByDate 入参是 {},返回结果是null ",
                                Lists.newArrayList(currentUser,beginTime,endTime));
                        return 0;
                    });
            awardPrice = awardPrice == null ? 0 : awardPrice;
        } catch (Exception e) {
            log.error("GomeHelpManager.getUserCount.getIncomeByPuserIdWithDate.predictionIncomeByDate run error, params:{} ", Lists.newArrayList(currentUser,beginTime,endTime), e);
            awardPrice = 0;
        } finally {
            log.info("GomeHelpManager.getUserCount.getIncomeByPuserIdWithDate.predictionIncomeByDate 入参是 {}, 返回结果 {}, cost {} ms ", Lists.newArrayList(currentUser,beginTime,endTime), awardPrice, System.currentTimeMillis() - startTime);
        }
        return awardPrice;
    }

    private List<MeidianBindingRelationDto> getCountByStatus(Map<String, Object> param) {
        long startTime = System.currentTimeMillis();
        List<MeidianBindingRelationDto> countByStatus = null;
        try {
            countByStatus = Optional.ofNullable(meidianBindingRelationManager.getCountByStatus(param)).map(i -> i.getBuessObj())
                    .orElseGet(() -> {
                        log.warn(
                                "GomeHelpManager.getUserCount.getCountByStatus 查询每个状态的数量 入参是 {},返回结果是null ",
                                param);
                        return Collections.EMPTY_LIST;
                    });

            countByStatus = (null != countByStatus) ? countByStatus : Collections.EMPTY_LIST;
        } catch (Exception e) {
            log.error("GomeHelpManager.getUserCount.getCountByStatus 查询每个状态的数量 run error, params:{} ", param, e);
            countByStatus =  Collections.EMPTY_LIST;
        } finally {
            log.info("GomeHelpManager.getUserCount.getCountByStatus 查询每个状态的数量 入参是 {}, 返回结果 {}, cost {} ms ", param, countByStatus, System.currentTimeMillis() - startTime);
        }
        return countByStatus;
    }


    private List<MeidianBindingRelationDto> getListByParam(Map<String, Object> param) {
        long startTime = System.currentTimeMillis();
        List<MeidianBindingRelationDto> listByParam = null;
        try {
            listByParam= Optional
                        .ofNullable(meidianBindingRelationManager.getListByParam(param)).map(i -> i.getBuessObj())
                        .orElseGet(() -> {
                            log.warn(
                                    "GomeHelpManager.getListByParam 入参是 {},返回结果是null ",
                                    param);
                            return Collections.EMPTY_LIST;
                    });
            listByParam = (null != listByParam) ? listByParam : Collections.EMPTY_LIST;
        } catch (Exception e) {
            log.error("GomeHelpManager.getListByParam 查询用户列表 run error, params:{} ", param, e);
            listByParam =  Collections.EMPTY_LIST;
        } finally {
            log.info("GomeHelpManager.getListByParam 查询用户列表 入参是 {}, 返回结果 {}, cost {} ms ", param, listByParam, System.currentTimeMillis() - startTime);
        }
        return listByParam;
    }



    private List<MeidianBindingRelationDto> getCountByPuserId(Map<String, Object> param) {
        long startTime = System.currentTimeMillis();
        List<MeidianBindingRelationDto> countByPuserId = null;
        try {
            countByPuserId = Optional
                    .ofNullable(meidianBindingRelationManager.getCountByPuserId(param)).map(i -> i.getBuessObj())
                    .orElseGet(() -> {
                        log.warn(
                                "GomeHelpManager.getMaxPuserIdList.getCountByPuserId 入参是 {},返回结果是null ",
                                param);
                        return Collections.EMPTY_LIST;
                    });
            countByPuserId = (null != countByPuserId) ? countByPuserId : Collections.EMPTY_LIST;

        } catch (Exception e) {
            log.error("GomeHelpManager.getMaxPuserIdList.getCountByPuserId run error, params:{} ", param, e);
            countByPuserId =  Collections.EMPTY_LIST;

        } finally {
            log.info("GomeHelpManager.getMaxPuserIdList.getCountByPuserId 查询前30名邀请人的用户信息 入参是 {}, 返回结果 {}, cost {} ms ", param, countByPuserId, System.currentTimeMillis() - startTime);
        }
        return countByPuserId;
    }

    //T转成R
    private <T, R> Map<R, T> convertToMap(List<T> list, Function<T, R> keyFunction) {
        Map<R, T> map = Maps.newLinkedHashMap();
        for (T item : list) {
            map.put(keyFunction.apply(item), item);
        }
        return map;
    }

    private List<GomeHelpVo> packageUserList(List<MeidianBindingRelationDto> listByParam) {
        Map<Long, MeidianBindingRelationDto> userRelationMap = convertToMap(listByParam, input -> input.getUserId());
        List<String> userIds = userRelationMap.keySet().parallelStream().map(i -> String.valueOf(i)).collect(Collectors.toList());

        Map<String, GomeShopBasicInfoModel> gomeShopMap = selectGomeShopBasicInfoModelMap(userIds);
        //筛选出首单用户ID
        List<Long> rebateUserIds = listByParam.parallelStream()
                .filter(i -> (i.getStatus() == GomeHelpStatus.APPFIRST.getCode())).map(i -> i.getUserId())
                .collect(Collectors.toList());

        //  调用会员，获取预计收益
        Map<Long, Double> rebateMap = selectPredictionIncomeByUserIdList(rebateUserIds);

        List<GomeHelpVo> resultList = Lists.newArrayListWithExpectedSize(userIds.size());
        for (String userId : userIds) {
            Long uid = Longs.tryParse(userId);
            int status = Optional.ofNullable(userRelationMap.get(uid)).map(i -> i.getStatus()).orElse(-1);
            Date updateStatusTime = Optional.ofNullable(userRelationMap.get(uid)).map(i -> i.getUpdateStatusTime())
                    .orElse(new Date(0));

            GomeHelpVo gomeHelpVo = GomeHelpVo.builder().userId(uid)
                    .image(Optional.ofNullable(gomeShopMap.get(userId)).map(i -> i.getGomeImg()).orElse(""))
                    .nickName(Optional.ofNullable(gomeShopMap.get(userId)).map(i -> i.getGomeNickName()).orElse(""))
                    .awardPrice(Optional.ofNullable(rebateMap.get(uid)).orElse(0.00))
                    .status(GomeHelpStatus.codeOf(status).map(GomeHelpStatus::getMessage).orElse(""))
                    .updateStatusTime(updateStatusTime).build();

            resultList.add(gomeHelpVo);

        }
        return resultList;
    }

    private Map<Long, Double> selectMaxPuserIdPredictionIncome(List<Long> puserIdList) {
        long startTime = System.currentTimeMillis();

        Map<Long, Double> map = null;
        try {
            map = Optional.ofNullable(grantRebateService.predictionIncomeByPuserIdList(puserIdList)).map(i->i.getBusinessObj())
                    .orElseGet(() -> {
                        log.warn("GomeHelpManager.selectMaxPuserIdPredictionIncome.predictionIncomeByPuserIdList 查询邀请人的收益总和 入参是 {},返回结果是null ", puserIdList);
                        return Collections.EMPTY_MAP;
                    });
            map = (null == map) ? Collections.EMPTY_MAP : map;

        } catch (Exception e) {
            log.error("GomeHelpManager.selectMaxPuserIdPredictionIncome.predictionIncomeByPuserIdList run error, params:{} ", puserIdList, e);
            map = Collections.EMPTY_MAP;

        } finally {
            log.info("GomeHelpManager.selectMaxPuserIdPredictionIncome.predictionIncomeByPuserIdList 查询邀请人的收益总和 入参是 {}, 返回结果 {}, cost {} ms ", puserIdList, map, System.currentTimeMillis() - startTime);
        }
        return map;
    }

    private Map<Long, Double> selectPredictionIncomeByUserIdList(List<Long> rebateUserIds) {
        long startTime = System.currentTimeMillis();

        Map<Long, Double> map = null;
        try {
            map = Optional.ofNullable(grantRebateService
                    .predictionIncomeByUserIdList(rebateUserIds)).map(i->i.getBusinessObj())
                    .orElseGet(() -> {
                        log.warn("GomeHelpManager.selectPredictionIncomeByUserIdList.predictionIncomeByUserIdList 查询订单 用户预计收益接口 入参是 {},返回结果是null ", rebateUserIds);
                        return Collections.EMPTY_MAP;
                    });
            map = (null == map) ? Collections.EMPTY_MAP : map;

        } catch (Exception e) {
            log.error("GomeHelpManager.selectPredictionIncomeByUserIdList.predictionIncomeByUserIdList run error, params:{} ", rebateUserIds, e);
            map = Collections.EMPTY_MAP;

        } finally {
            log.info("GomeHelpManager.selectPredictionIncomeByUserIdList.predictionIncomeByUserIdList 入参 {}, 返回结果 {}, cost {} ms ", rebateUserIds, map, System.currentTimeMillis() - startTime);
        }
        return map;
    }

    private Map<String, GomeShopBasicInfoModel> selectGomeShopBasicInfoModelMap(List<String> userIds) {
        long startTime = System.currentTimeMillis();
        //会员
        Optional<UserResult<List<GomeShopBasicInfoModel>>> listUserResultOptional = Optional.empty();
        try {
            listUserResultOptional = Optional.ofNullable(gomeShopWeChatFacade.batchQueryUserBasicInfo(userIds, GOME_SHOP));
        } catch (Exception e) {
            log.error("GomeHelpManager.gomeShopWeChatFacade.batchQueryUserBasicInfo run error, params:{} ", userIds, e);
        } finally {
            log.info("GomeHelpManager.gomeShopWeChatFacade.batchQueryUserBasicInfo cost {} ms", System.currentTimeMillis() - startTime);
        }

        List<GomeShopBasicInfoModel> basicInfoModels = listUserResultOptional.map(i -> i.getBuessObj())
                .orElseGet(() -> {
                    log.warn("GomeHelpManager.gomeShopWeChatFacade.batchQueryUserBasicInfo 查找会员接口的入参 {},返回结果是null ", userIds);
                    return Collections.EMPTY_LIST;
                });
        log.info("GomeHelpManager.gomeShopWeChatFacade.batchQueryUserBasicInfo 查找会员接口的入参 {},查询结果是 {} ", userIds, JSON.toJSONString(basicInfoModels));
        basicInfoModels = (null != basicInfoModels) ? basicInfoModels : Lists.newArrayList();

        return convertToMap(basicInfoModels, input -> input.getUserId());
    }

    /**
     * 查询这折线图数据
     *
     * @param currentUser
     * @param beginTime
     * @param endTime
     * @return
     */
    public List<Map<String, Object>> getChartData(String currentUser, String beginTime, String endTime) {
        long startTime = System.currentTimeMillis();
        List<Map<String, Object>> list = Collections.EMPTY_LIST;
        try {
            list = Optional.ofNullable(
                    grantRebateService.selectPredictionIncomeWithEveryday(beginTime, endTime, Longs.tryParse(currentUser)))
                    .map(i -> i.getBusinessObj()).orElseGet(() -> {
                        log.warn(
                                "GomeHelpManager.getChartData.selectPredictionIncomeWithEveryday 查询订单 用户每天的预计收益 入参是 {},返回结果是null ",
                                Lists.newArrayList(currentUser, beginTime, endTime));
                        return Collections.EMPTY_LIST;
                    });
            list = (null == list) ? Collections.EMPTY_LIST : list;

        } catch (Exception e) {
            log.error("GomeHelpManager.grantRebateService.selectPredictionIncomeWithEveryday run error, params:{} ",
                    Lists.newArrayList(currentUser, beginTime, endTime), e);
            list = Collections.EMPTY_LIST;
        } finally {
            log.info("GomeHelpManager.grantRebateService.selectPredictionIncomeWithEveryday cost {} ms", System.currentTimeMillis() - startTime);
        }

        return list;
    }

    /**
     * base64上传字符串
     * @param imageStr
     * @return
     */
    public ResponseJson<String> updateImage(String imageStr) {
        long imageSizeMax = IMAGE_MAX_SIZE;
        ResponseJson<String> responseJson = new ResponseJson<>();
        try{
            byte[] imageData = AesUtils.base64Decode(imageStr);
            if (imageData.length > imageSizeMax) {
                responseJson.setCode(500);
                responseJson.setMsg("二维码大小不能超过5M哦");
                return responseJson;
            }
            String upLoadImage = fileup(imageData);
            responseJson.setCode(200);
            responseJson.setData(upLoadImage);
        }catch (Exception e){
            log.error("上传图片信息异常Exception:{},图片:{}",e,imageStr);
            responseJson.setCode(500);
            responseJson.setMsg("");
        }
        return responseJson;

    }
    private String fileup(byte [] bytes){
        try{
            GisResultDto result = uploadImageInfoService.fileup(bytes, token,null,null);
            String errorCode = result.getErrorCode();
            if(StringUtils.isNotBlank(errorCode)){
                throw new C422Exception(result.getMsg());
            }
            return result.getUrl();
        }catch(Exception e){
            log.error("ImageUploadController invoke uploadImageInfoService.fileup has errors , exception is {}",e);
        }
        return "";
    }

    /**
     * 查询国美币接口
     * @param userId
     * @return
     */
    public Long getGcoinByUserId(String userId) {
        GCoin_ParametersVo vo = new GCoin_ParametersVo();
        vo.setSources("010");
        vo.setBusinessType("ACCOUNT_QUERYACCOUNTINFO");
        vo.setInvokeSource("GCOIN_MEIDIAN_APP");
        Map<String, Object> map1 = new HashMap<>();
        map1.put("userNo", userId);
        vo.setMap(map1);
        try{
            GCoin_ParametersVo service = accountFacadeService.service(vo);//未在消费端注册
            if("0000".equals(service.getResCode()) && service.getMap()!= null && service.getMap().get("accountBalance")!=null) {
               return (Long) service.getMap().get("accountBalance");
            }
        }catch(Exception e){
            log.error("小美帮帮查询国美币出现异常:{}",userId,e);
        }
        return null;
    }
}
