package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;

/**
 * 页面属性
 * @author shichangjian
 *
 */
public class PageProperty implements Serializable{

	private static final long serialVersionUID = -1773589983099830542L;

	private String pageName;
	private String pageTitle;
	private String pageDesc;
	private String pageColor;
	private String imgUrl;
	private String shareUrl;
	
	public PageProperty() {
		super();
	}
	public PageProperty(String pageName, String pageTitle, String pageDesc, 
						String pageColor, String imgUrl, String shareUrl) {
		super();
		this.pageName = pageName;
		this.pageTitle = pageTitle;
		this.pageDesc = pageDesc;
		this.pageColor = pageColor;
		this.imgUrl = imgUrl;
		this.shareUrl = shareUrl;
	}
	public String getPageName() {
		return pageName;
	}
	public void setPageName(String pageName) {
		this.pageName = pageName;
	}
	public String getPageTitle() {
		return pageTitle;
	}
	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}
	public String getPageDesc() {
		return pageDesc;
	}
	public void setPageDesc(String pageDesc) {
		this.pageDesc = pageDesc;
	}
	public String getPageColor() {
		return pageColor;
	}
	public void setPageColor(String pageColor) {
		this.pageColor = pageColor;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getShareUrl() {
		return shareUrl;
	}
	public void setShareUrl(String shareUrl) {
		this.shareUrl = shareUrl;
	}
	
	
}
