package com.gome.meidian.grouporder.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.MinMessageManager;
import com.gome.meidian.grouporder.vo.register.MinUserVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@Validated
@RequestMapping("/minMessage")
@SuppressWarnings({ "rawtypes" })
public class MinMessageController {
	
	@Autowired
	private MinMessageManager minMessageManager;
	
	/**
	 * 收集用户发送条件
	 * @param minUserVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/pushUserMinFormId")
	public ResponseJson pushUserMinFormId(@Valid @RequestBody MinUserVo minUserVo) throws MeidianException {
		return minMessageManager.pushUserMinFormId(minUserVo);
	}
	
}
