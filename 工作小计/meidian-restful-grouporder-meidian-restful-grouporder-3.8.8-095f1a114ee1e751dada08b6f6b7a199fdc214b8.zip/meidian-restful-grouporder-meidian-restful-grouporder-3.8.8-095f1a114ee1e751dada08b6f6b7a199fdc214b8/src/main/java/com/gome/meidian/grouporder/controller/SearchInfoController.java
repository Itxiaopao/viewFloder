package com.gome.meidian.grouporder.controller;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.SearchInfoManager;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReqVo;
import com.gome.meidian.grouporder.vo.search.SearchInfoReqVo;
import com.gome.meidian.grouporder.vo.search.SearchProductInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.sso.model.UserInfoCache;
/**
 * 搜索控制层
 * @author lishouxu-ds
 *
 */
@RestController
@Validated
@RequestMapping("/v1/search")
public class SearchInfoController {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private SearchInfoManager searchInfoManager;

	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	
	@Autowired
	private GroupOrderManager groupOrderManager;
	/**
	 * 联想词搜索
	 * @param query
	 * @param ppi
	 * @param scn
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/suggestInfo")
	public ResponseJson suggestInfo(
			@NotBlank(message = "{param.error}") @RequestParam(value = "query", required = true) String query,
			@NotBlank(message = "{param.error}") @RequestParam(value = "siteModule", required = true) String siteModule,
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@CookieValue(value = "SCN", required = false) String scn, 
			HttpServletRequest request)throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String,Object> map = searchInfoManager.suggestInfo(query,siteModule);
		response.setData(map);
		return response;
	}
	/**
	 * 搜索主接口
	 * @param searchInfoReqVo
	 * @param ppi
	 * @param request
	 * @return
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/searchInfo", method = RequestMethod.POST)
	public ResponseJson<Map<String, Object>> suggestInfo(
			@RequestBody @Validated SearchInfoReqVo searchInfoReqVo,
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "ctx", required = false) String ctx,
//			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestParam(required = false) PriceReqUtils priceReqUtils,
//			/*加盟店价格参数end*/
			HttpServletRequest request
			) throws MeidianException{
		
		ResponseJson response = new ResponseJson();

		if(StringUtils.isNotBlank(searchInfoReqVo.getSiteModule()) && searchInfoReqVo.getSiteModule().equals("app")){
			return response;
		}
		
		if(searchInfoReqVo.getCurrentPage()==null){
			searchInfoReqVo.setCurrentPage(1);
		}
		
		if(searchInfoReqVo.getPageSize()==null){
			searchInfoReqVo.setPageSize(10);
		}
		
		if(searchInfoReqVo.getSortBy()==null){
			searchInfoReqVo.setSortBy(6);
		}
		
		if(StringUtils.isNotBlank(searchInfoReqVo.getRemain())){
		    searchInfoReqVo.setKeyWord(searchInfoReqVo.getRemain());
		}
		
		if(StringUtils.isEmpty(searchInfoReqVo.getKeyWord())&&(searchInfoReqVo.getQueryCatList()==null || searchInfoReqVo.getQueryCatList().size()<=0 )){
			throw new ServiceException("suggestInfo.param");
		}
		
		String userId = null;
		if(StringUtils.isNotBlank(scn)&&StringUtils.isNotBlank(searchInfoReqVo.getOrganizationId())){
			UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
			if (userInfo != null && StringUtils.isNotBlank(userInfo.getId())) {
				userId = userInfo.getId();
			}
		}
		
		if(searchInfoReqVo.getSale() == null){
			searchInfoReqVo.setSale(0);
		}
		
		Map<String,Object> map=new HashMap<String,Object>();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
		if (null == searchInfoReqVo.getAreaCode() || searchInfoReqVo.getAreaCode().equalsIgnoreCase(""))
			searchInfoReqVo.setAreaCode(defaultAreaCode) ;
		//2020.02.17ctx begin
		if(StringUtils.isBlank(ctx)){
			Cookie ctxCookie = CookieUtils.getCookieByName(request, "ctx");
			if(null != ctxCookie) {
				ctx = ctxCookie.getValue();
			}
	    }
		//2020.02.17ctx end
		map=searchInfoManager.searchInfo(searchInfoReqVo, ua,ppi,userId,ctx);
		response.setData(map);
	    return response;
	}
}
