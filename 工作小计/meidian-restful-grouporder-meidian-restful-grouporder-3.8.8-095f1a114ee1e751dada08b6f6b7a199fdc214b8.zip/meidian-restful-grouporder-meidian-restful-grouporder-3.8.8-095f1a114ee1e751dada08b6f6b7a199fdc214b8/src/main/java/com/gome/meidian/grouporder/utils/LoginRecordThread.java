package com.gome.meidian.grouporder.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.user.entity.UserInfo;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.meidian.user.manager.IUserRoleManager;
import com.gomeo2o.facade.vshop.entity.VshopInfo;

import redis.Gcache;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/4 10:20
 * @Description
 */
public class LoginRecordThread extends Thread {

    private Logger logger = LoggerFactory.getLogger(getClass());

    private  String userId;
    //新增类型
    private  String createType;

    //加类型：1-注册，2-激活
    private  String addType;

    private Gcache venusVshopGcache;

    private Gcache userCenter;

    private IUserInfoManager iUserInfoManager;


    private IUserRoleManager iUserRoleManager;


    private static final String USER_ID_SET="user.center.userInfo.manager";
    //普通用户
    public static final String ROLE_NORMAL="1";
    //美店主
    public static final String ROLE_SHOP="2";


    public LoginRecordThread(String userId,String createType,String addType,Gcache userCenter,Gcache venusVshopGcache,IUserInfoManager iUserInfoManager,IUserRoleManager iUserRoleManager){
        this.userId=userId;
        this.createType=createType;
        this.addType=addType;
        this.userCenter=userCenter;
        this.venusVshopGcache=venusVshopGcache;
        this.iUserInfoManager=iUserInfoManager;
        this.iUserRoleManager=iUserRoleManager;
    }

    @Override
    public void run() {
        logger.info("LoginRecordThread:userId-{},createType-{},addType-{} ",userId,createType,addType);
        String key = USER_ID_SET + ":" + RedisKeyUtils.getHKey(userId);
        String userInfoCache=userCenter.hget(key,userId);
        if(null==userInfoCache){
            //用户池不存在
            UserInfo userInfo=new UserInfo();
            userInfo.setUserId(this.userId);

            String vshopKey = "vshop:vshopInfo_userId:" + userId;
            VshopInfo shopInfo = JSONObject.parseObject(venusVshopGcache.get(vshopKey), VshopInfo.class);
            if(null==shopInfo){
            	//TODO
            	
            }
            //0：非法用户
            //1：普通用户
            //2：美店主
            //3：团长
            //普通用户
            boolean roleFlag=true;
            if(null!=shopInfo){
                Long vshopId=shopInfo.getVshopId();
                if(null!=vshopId){
                    userInfo.setMid(vshopId.toString());
                    //美店主
                    roleFlag=false;
                }
            }
            userInfo.setCreateType(this.createType);
            //添加类型：1-注册，2-激活
            userInfo.setAddType(this.addType);
            try {
                //用户信息入库
                iUserInfoManager.addUserInfoByInviteUser(userInfo, null, WechatLoginManager.INVOKE_FROM);
                //用户角色信息入库
                if (roleFlag == true) {
                    iUserRoleManager.addUserRole(userId, ROLE_NORMAL);
                } else {
                    iUserRoleManager.addUserRole(userId, ROLE_SHOP);
                }
            }catch (Exception e){
                logger.info("LoginRecordThread:userId-{},createType-{},addType-{},e-{} ",userId,createType,addType,e);
            }

        }
         //用户池存在不处理

    }
}
