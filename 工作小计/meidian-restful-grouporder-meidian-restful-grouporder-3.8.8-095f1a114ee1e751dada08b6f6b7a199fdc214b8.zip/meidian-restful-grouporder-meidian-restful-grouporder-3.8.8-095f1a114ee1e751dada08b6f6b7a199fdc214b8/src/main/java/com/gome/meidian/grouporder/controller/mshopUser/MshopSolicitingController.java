package com.gome.meidian.grouporder.controller.mshopUser;

import cn.com.gome.gis.dto.GisResultDto;
import cn.com.gome.gis.dubbo.UploadImageInfoService;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.MshopSolicitingManager;
import com.gome.meidian.grouporder.utils.AesUtils;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.vo.mshopUserVo.MshopSolicitVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.UpWeChartImageParamVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gomeplus.bs.framework.dubbor.exceptions.code4xx.C422Exception;
import com.google.common.collect.ImmutableSet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Slf4j
@RestController
@Validated
@RequestMapping("/mshopSoliciting")
@SuppressWarnings({ "rawtypes"})
public class MshopSolicitingController {

    public static final Set<String> ALLOWED_TYPES = ImmutableSet.of("jpg", "jpeg", "png", "gif");//文件格式限制


    /**
     * GFS上传凭证token
     */
    @Value("${gfs.mshop_cms_gfs_token}")
    private String token;

    public static final Long IMAGE_MAX_SIZE = 5242880L; //图片上传限制 5M

    @Autowired
    private UploadImageInfoService uploadImageInfoService;

    @Autowired
    private MshopSolicitingManager mshopSolicitingManager;

    @Autowired
    private AuthencationUtils authencationUtils;

    /**
     * 存储当前人信息
     * @param scn
     * @param upWeChartImageParamVo
     * @return
     * @throws MeidianException
     */
    @RequestMapping(value = "/addUserInfo", method = RequestMethod.POST)
    public ResponseJson<Map<String,Object>> addUserInfo( @CookieValue(value="SCN",required=false) String scn,
                                                         @RequestBody @Validated UpWeChartImageParamVo upWeChartImageParamVo,
                                                         HttpServletRequest request
    ) throws MeidianException {
        long imageSizeMax = IMAGE_MAX_SIZE;
        ResponseJson<Map<String,Object>> response = new ResponseJson<Map<String,Object>>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        String upLoadImage=null;
        String userId = authencationUtils.authenticationLogin(scn);
        if(null == userId) {
            resMap.put("login", 0);
            response.setData(resMap);
            return response;
        }
        resMap.put("login", 1);
        if(StringUtils.isBlank(upWeChartImageParamVo.getImage())){
            response.setCode(10004);
            response.setMsg("上传图片不能为空哦~");
            return response;
        }
            try {
                byte[] imageData = AesUtils.base64Decode(upWeChartImageParamVo.getImage());
                if (imageData.length > imageSizeMax) {
                    response.setCode(10005);
                    response.setMsg("二维码大小不能超过5M哦");
                    return response;
                }
                upLoadImage = fileup(imageData);
                if(StringUtils.isBlank(upLoadImage)){
                    resMap.put("amount", 0);
                    response.setCode(100503);
                    response.setData(resMap);
                    return response;
                }
                //调用底层
                MShopShareBindingDto mShopShareBindingDto = new MShopShareBindingDto();
                mShopShareBindingDto.setUserId(Long.valueOf(userId));
                mShopShareBindingDto.setQrCode(upLoadImage);
                mShopShareBindingDto.setWechatNum(upWeChartImageParamVo.getMicrosignal());
                Boolean aBoolean = mshopSolicitingManager.addUserInfo(mShopShareBindingDto);
                log.info("二维码地址"+upLoadImage);
                if(aBoolean){
                    resMap.put("amount", 1);
                }else {
                    resMap.put("amount", 0);
                }
            } catch (Exception e) {
                log.error("上传图片发生错误", e);
                resMap.put("amount", 0);
                response.setCode(100502);
                response.setData(resMap);
                return response;
            }
        response.setData(resMap);
        return response;
    }

    /**
     * 查询当前人信息-当前顾问-邀请人信息
     * @param request
     * @return
     * @throws MeidianException
     */
    @RequestMapping(value = "/selectUserInfo", method = {RequestMethod.GET , RequestMethod.POST})
    public ResponseJson<Map<String,Object>> selectUserInfo (
            @CookieValue(value="SCN",required=false) String scn,
            @RequestParam(value = "invitationId", required = false) String invitationId,
            HttpServletRequest request
    ) throws MeidianException {
        ResponseJson<Map<String,Object>> response = new ResponseJson<Map<String,Object>>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        String userId = authencationUtils.authenticationLogin(scn);
        if(null == userId) {
            resMap.put("login", 0);
            response.setData(resMap);
            return response;
        }
        resMap.put("login", 1);
        Long invitaId = 0l;
        if(StringUtils.isNotBlank(invitationId)){
            invitaId =  Long.valueOf(invitationId);
        }else {
            invitaId = null;
        }
        //调用底层接口
        MshopSolicitVo mshopSolicitVo = mshopSolicitingManager.getUserRefInfo(Long.valueOf(userId),invitaId);
        resMap.put("mshopSolicitVo", mshopSolicitVo);
        response.setData(resMap);
        return response;
    }

    /**
     * 切换邀请人
     * @param scn
     * @param invitationId
     * @param request
     * @return
     * @throws MeidianException
     */
    @RequestMapping(value = "/switchUser", method = RequestMethod.POST)
    public ResponseJson<Map<String,Object>> switchUser(
            @CookieValue(value="SCN",required=true) String scn,
            @RequestParam(value = "invitationId", required = true) String invitationId,
            HttpServletRequest request
    ) throws MeidianException {
        ResponseJson<Map<String,Object>> response = new ResponseJson<Map<String,Object>>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        MshopShareRecordDto mshopShareRecordDto = new MshopShareRecordDto();
        String userId = authencationUtils.authenticationLogin(scn);
        if(null == userId) {
            resMap.put("login", 0);
            response.setData(resMap);
            return response;
        }
        if(StringUtils.isNotBlank(invitationId) && userId.equals(invitationId)){
            resMap.put("isSwither",0);
            response.setCode(120218);//00120218=当前人无法切换自己. 后期优化管理
            response.setMsg("您无法切换自己身份哦~");
            response.setData(resMap);
            return response;
        }
        resMap.put("login", 1);
        mshopShareRecordDto.setUserId(Long.valueOf(userId));
        mshopShareRecordDto.setUpuserId(Long.valueOf(invitationId));
        MapResults mapResults = mshopSolicitingManager.switchUser(mshopShareRecordDto);
        if(mapResults.getSuccess()){
            resMap.put("isSwither",1);
        }else{
            resMap.put("isSwither",0);
            response.setCode(mapResults.getCode());
            response.setMsg(mapResults.getMessage());
        }
        response.setData(resMap);
        return response;
    }

    private String fileup(byte [] bytes){
        try{
            GisResultDto result = uploadImageInfoService.fileup(bytes, token, null, null);
            String errorCode = result.getErrorCode();
            if(StringUtils.isNotBlank(errorCode)){
                throw new C422Exception(result.getMsg());
            }
            return result.getUrl();
        }catch(Exception e){
            log.error("ImageUploadController invoke uploadImageInfoService.fileup has errors , exception is {}",e);
        }
        return "";
    }

}
