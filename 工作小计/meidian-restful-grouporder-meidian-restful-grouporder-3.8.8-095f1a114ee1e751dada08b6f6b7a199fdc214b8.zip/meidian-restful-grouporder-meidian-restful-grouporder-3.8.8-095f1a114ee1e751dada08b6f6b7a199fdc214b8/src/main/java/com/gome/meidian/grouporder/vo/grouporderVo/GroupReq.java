package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupProduct;

/**
 * 商品基础列表入参
 * @author shichangjian
 *
 */
public class GroupReq implements Serializable{

	private static final long serialVersionUID = -343662362386292547L;
	
//	@NotEmpty(message = "{param.error}", groups = { groupProduct.class})
//	private List<String> productIds; // 商品Id

	private List<ProductCouponReq> productCouponReqs;

	public List<ProductCouponReq> getProductCouponReqs() {
		return productCouponReqs;
	}

	public void setProductCouponReqs(List<ProductCouponReq> productCouponReqs) {
		this.productCouponReqs = productCouponReqs;
	}
	
//	public List<String> getProductIds() {
//		return productIds;
//	}
//
//	public void setProductIds(List<String> productIds) {
//		this.productIds = productIds;
//	}

	
	
	
}
