package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;
import java.util.List;

public class AppreciationServeType implements Serializable{

	private static final long serialVersionUID = 2160660128198028193L;

	private Long showGroupId;							// 分组id
	private String showGroupName;						// 分组名称，比如，延长保，碎片保
	private String iconUrl;								// 图标
	private List<AppreciationServe> appreciationServes;	// 增值服务信息
	
	
	public AppreciationServeType() {
		super();
	}
	public AppreciationServeType(Long showGroupId, String showGroupName, String iconUrl,
					List<AppreciationServe> appreciationServes) {
		super();
		this.showGroupId = showGroupId;
		this.showGroupName = showGroupName;
		this.iconUrl = iconUrl;
		this.appreciationServes = appreciationServes;
	}
	public Long getShowGroupId() {
		return showGroupId;
	}
	public void setShowGroupId(Long showGroupId) {
		this.showGroupId = showGroupId;
	}
	public String getShowGroupName() {
		return showGroupName;
	}
	public void setShowGroupName(String showGroupName) {
		this.showGroupName = showGroupName;
	}
	public String getIconUrl() {
		return iconUrl;
	}
	public void setIconUrl(String iconUrl) {
		this.iconUrl = iconUrl;
	}
	public List<AppreciationServe> getAppreciationServes() {
		return appreciationServes;
	}
	public void setAppreciationServes(List<AppreciationServe> appreciationServes) {
		this.appreciationServes = appreciationServes;
	}

	
	
}
