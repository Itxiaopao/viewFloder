package com.gome.meidian.grouporder.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gome.frontSe.interfaces.IProdDetailService;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.PriceConditionVo;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.Slot;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReq;
import com.gome.meidian.grouporder.vo.grouporderVo.HomeGroupProductActivityPage;
import com.gome.meidian.grouporder.vo.grouporderVo.HomePageActivity;
import com.gome.meidian.grouporder.vo.grouporderVo.HomeProductActivity;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductCouponReq;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.meidiancms.Icon;
import com.gome.meidian.grouporder.vo.meidiancms.ImageElement;
import com.gome.meidian.grouporder.vo.meidiancms.Model;
import com.gome.meidian.grouporder.vo.meidiancms.ModelVo;
import com.gome.meidian.grouporder.vo.product.HomeCouponProductRes;
import com.gome.meidian.grouporder.vo.product.HomeProductCouponVo;
import com.gome.meidian.grouporder.vo.product.MeidianPrice;
import com.gome.meidian.grouporder.vo.product.ProductCms;
import com.gome.meidian.grouporder.vo.product.ProductInfo;
import com.gome.meidian.grouporder.vo.product.ProductRequestParam;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebate;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;
import com.gome.meidian.grouporder.vo.rebate.ShareRebate;
import com.gome.meidian.grouporder.vo.rebate.ShareRebateResponse;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.mobile.common.utils.math.BigDecimalUtils;
import com.gome.pangu.bluecoupon.dubbo.model.ChangeUserIdParam;
import com.gome.pangu.bluecoupon.dubbo.model.ResultDO;
import com.gome.pangu.bluecoupon.dubbo.service.FpBlueCouponService;
import com.gome.stage.bean.price.GomeUnifiedPrice;
import com.gome.stage.interfaces.item.IGomeVipPriceService;
import com.gome.stage.interfaces.item.IProductInfoService;
import com.gome.stage.item.GomeVipPriceItem;
import com.gome.stage.item.GoodsInfo;
import com.gome.stage.item.SkuItem;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.service.business.SuspendIconResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.Menus;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.SecondPageMI;
import com.gomeplus.bs.interfaces.cms2.vo.business.suspendicon.SuspendIcons;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.ProductInfoListVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductManagementConciseVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductsVo;
import com.gomeplus.bs.interfaces.gorder.vo.UserAttendGroupVo;

import cn.com.gome.rebate.dubbo.service.app.IDubboSellersService;
import cn.com.gome.rebate.model.seller.CommonGoodsReqDto;
import redis.Gcache;

@Service
public class HomeProductsManager {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private IGomeVipPriceService iGomeVipPriceService;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	@Autowired
	private IDubboSellersService iDubboSellersService;
	@Autowired
	private HttpClientUtil httpClientUtil;
	@Autowired
	private IProductInfoService productInfoService;
	@Autowired
	private IProdDetailService prodDetailService;
	@Autowired
	private SuspendIconResource suspendIconResource;
	@Autowired
    private PageInfoResource pageInfoResource;
	@Autowired
	private FpBlueCouponService fpBlueCouponService;

	@Value("${cms.productIdsUrl}")
	private String productIdsUrl; // http://shark-cms.pre.video.api/v1/slot/store/getStoreSlot?unique_key=A017entitystorecontent661217
	@Resource(name = "gcache")
	private Gcache gcache;
	@Resource(name = "gcachezz")
	private Gcache gcachezz;
	@Value("${meidian.image.agreement}")
	private String agreement;			// http协议

	private String[] properties =new String[]{"brandCode"};
	@Autowired
	private PriceManager priceManager;//价格服务
	@Autowired
	private PropertiesConfig propertiesConfig;
	
	
	
	/**
	 * 美店价格
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @param channel
	 * @return
	 */
    public MeidianPrice getMeidianPrice(String productId, String skuId, String areaCode, String channel, String mOrg, String policyId){
//		GomeVipPriceItem gomeVipPriceItem = iGomeVipPriceService.getVipPrice(productId, skuId, areaCode, channel);
//		GomeUnifiedPrice GomeUnifiedPrice = priceManager.getPrice(areaCode,  mOrg,  policyId ,skuId);
//		if(null == gomeVipPriceItem) return null;
//		MeidianPrice meidianPrice = new MeidianPrice();
//		BeanUtils.copyProperties(gomeVipPriceItem, meidianPrice);
//		if(null == gomeVipPriceItem.getFinalPrice()) return null;
//		meidianPrice.setMeidianPrice(DoubleUtils.switchScientificCalculate(gomeVipPriceItem.getFinalPrice()));
    	PriceConditionVo condition = new PriceConditionVo();
    	condition.setChannel(channel);
    	condition.setPolicyId(policyId);
    	condition.setProductId(productId);
    	condition.setSkuId(skuId);
    	
		GomeUnifiedPrice GomeUnifiedPrice = priceManager.getPrice(condition);
		if(null == GomeUnifiedPrice) return null;
		MeidianPrice meidianPrice = new MeidianPrice();
		if(null == GomeUnifiedPrice.getPrice()) return null;
		meidianPrice.setMeidianPrice(DoubleUtils.switchScientificCalculate(GomeUnifiedPrice.getPrice()));
		meidianPrice.setSkuId(GomeUnifiedPrice.getSkuId());
		meidianPrice.setPriceKey(GomeUnifiedPrice.getSign());
		meidianPrice.setPriceType(GomeUnifiedPrice.getPriceType());
		return meidianPrice;
	}

	/**
	 * 获取组团列表
	 * @param groupInfoReqs
	 * @param areaCode
	 * @return
	 * @throws ServiceException
	 */
	public List<ProductGroupInfoVo> groupInfo(List<GroupInfoReq> groupInfoReqs, String areaCode, Integer ppi, Byte ua, String storeCode) throws ServiceException{

		// 记录活动页下标位
		Map<Integer, String> acUkeySubscriptMap = new LinkedHashMap<Integer, String>();

		// 记录缓存中查不到的
		Map<Integer, String> indexMap = new LinkedHashMap<Integer, String>();
		// 请求数据
		List<ProductsVo> productsVos = new ArrayList<ProductsVo>();
		List<ProductGroupInfoVo> productGroupInfoVos = new ArrayList<ProductGroupInfoVo>();

		int index = 0;
		for (GroupInfoReq groupInfoReq : groupInfoReqs) {

			// 记住下标位
			index ++;

			// 1.记录专题活动页下标位
			if(null != groupInfoReq.getActivityUkey() && !groupInfoReq.getActivityUkey().equalsIgnoreCase("")){
				acUkeySubscriptMap.put(index - 1, groupInfoReq.getActivityUkey());
				continue;
			}

//			ProductGroupInfoVo productGroupInfoVo = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-group", groupInfoReq.getProductId() + "_" + groupInfoReq.getSkuId() + "_" + groupInfoReq.getActivityId() + "_" + areaCode), ProductGroupInfoVo.class);
			ProductGroupInfoVo productGroupInfoVo = JSONObject.parseObject(gcache.get("homePageGroup_" + groupInfoReq.getProductId() + "_" + groupInfoReq.getSkuId() + "_" + groupInfoReq.getActivityId() + "_" + areaCode + "_" + storeCode), ProductGroupInfoVo.class);

			// 2.记住缓存中没有的商品的下标位
			if(null == productGroupInfoVo){
				indexMap.put(index - 1, groupInfoReq.getProductId());
				ProductsVo productsVo = new ProductsVo();
				productsVo.setProductId(groupInfoReq.getProductId());
				productsVo.setActivityId(groupInfoReq.getActivityId());
				productsVo.setSkuId(groupInfoReq.getSkuId());
				productsVos.add(productsVo);
			} else{
				productGroupInfoVos.add(productGroupInfoVo);
			}
		}

		int listSize = productsVos.size();
		int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;

		List<ProductsVo> paramList = new ArrayList<>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = productsVos;
			} else {
				if (a != selectCount) {
					paramList.addAll(productsVos.subList(30 * (a - 1), 30 * a));
				} else {
					paramList.addAll(productsVos.subList(30 * (a - 1), listSize));
				}
			}
			//获取商品和活动信息
			CommonResultEntity<ProductInfoListVo> resultVo = gorderInfoForAppNewResource.getProductInfoByIds(paramList, areaCode);

			ProductInfoListVo productInfoListVo = resultVo.getBusinessObj();
			if(null != productInfoListVo) {

				List<ProductManagementConciseVo> productManagementConciseVos = productInfoListVo.getProductInfo();

				for (ProductManagementConciseVo productManagementConciseVo : productManagementConciseVos) {
					ProductGroupInfoVo productGroupInfoVo = this.getProductInfo(productManagementConciseVo);
					// 插入相应的下标
					for (Map.Entry<Integer, String> entry : indexMap.entrySet()) {
						if(entry.getValue().equalsIgnoreCase(productGroupInfoVo.getProductInfo().getProductId())){
							if(productGroupInfoVos.size() <= entry.getKey()){
								productGroupInfoVos.add(productGroupInfoVo);
							}else
								productGroupInfoVos.add(entry.getKey(), productGroupInfoVo);
							// 添加到缓存
//							gcache.hset("meidian-restful-grouporder-group", productManagementConciseVo.getProductId() + "_" + productManagementConciseVo.getSkuId() + "_" + productManagementConciseVo.getActivityId() + "_" + areaCode,
//									JSONUtils.toJSONString(productGroupInfoVo).getBytes());
							gcache.setex("homePageGroup_" + productManagementConciseVo.getProductId() + "_" + productManagementConciseVo.getSkuId() + "_" + productManagementConciseVo.getActivityId() + "_" + areaCode + "_" + storeCode, 3 * 60,
									JSONUtils.toJSONString(productGroupInfoVo).getBytes());
							break;
						}
					}
				}
			}
			

		}

		// 处理活动页
		if(!acUkeySubscriptMap.isEmpty())
			this.getHomeActivityPageInfo(acUkeySubscriptMap, productGroupInfoVos, areaCode);

		// 处理图片
		List<Map<String, String>> proSkuIdMap = this.groupsImageInfo(productGroupInfoVos, ppi, ua);

		// 美店定价 (meidianPriceOnOff: 开关)
		if(null == gcache.get("meidianPriceOnOff"))
			this.meidianPrices(productGroupInfoVos, proSkuIdMap, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
		else
			this.mDPrice(productGroupInfoVos);
			
		return productGroupInfoVos;
	}

	public ProductGroupInfoVo getProductInfo(ProductManagementConciseVo productManagementConciseVo){
		ProductGroupInfoVo productGroupInfoVo = new ProductGroupInfoVo();

		// 1.商品信息
		ProductInfo product = new ProductInfo();
		BeanUtils.copyProperties(productManagementConciseVo, product);
		if(null == product.getHelpAllow()) {
			product.setHelpAllow(0);
		}
		// 替换http协议，把http替换为https
		if(product.getProductImage().contains("http:"))
			product.setProductImage(product.getProductImage().replace("http:", agreement));
		// 价格
		double price = groupOrderManager.getPrice(productManagementConciseVo.getPrice());
		product.setPrice(DoubleUtils.switchScientificCalculate(price));
		productGroupInfoVo.setProductInfo(product);

		// 2.活动信息
		HomePageActivity homePageActivity = new HomePageActivity(
				productManagementConciseVo.getActivityId(), productManagementConciseVo.getIrrigationNumbe(),
				productManagementConciseVo.getMaxDiscount(), productManagementConciseVo.getMaxDiscountNeedPeopleNum(),
				productManagementConciseVo.getGroupBusType(), productManagementConciseVo.getModeType()
				);
		// 折扣返利
		double rebatePrice = groupOrderManager.getRebateAmount(productManagementConciseVo.getPrice(), productManagementConciseVo.getMaxDiscount());
		homePageActivity.setDiscountRebate(DoubleUtils.switchScientificCalculate(rebatePrice));
		productGroupInfoVo.setHomePageActivity(homePageActivity);

		return productGroupInfoVo;

	}

	/**
	 * 首页超级返商品列表
	 * @param productBuyRebates
	 * @param areaCode
	 * @return
	 * @throws ServiceException
	 */
	public List<ProductBuyRebateVo> getProductBuyRebates(List<ProductBuyRebate> productBuyRebates, String areaCode, Integer ppi, Byte ua, String mOrg, String policyId) throws ServiceException{
		List<ProductBuyRebateVo> productBuyRebateVos = new ArrayList<ProductBuyRebateVo>();
		
		Map<String, String> keyMap = new HashMap<String, String>();
		List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
		for (ProductBuyRebate productBuyRebate : productBuyRebates) {
			ProductRequestParam productRequestParam = new ProductRequestParam(productBuyRebate.getProductId(), productBuyRebate.getSkuId());
			productRequestParams.add(productRequestParam);
			
			String sId = productBuyRebate.getSkuId();
			if(null == sId || sId.equalsIgnoreCase(""))
				keyMap.put(productBuyRebate.getProductId(), productBuyRebate.getSkuNo());
			else
				keyMap.put(productBuyRebate.getProductId() + "_" + sId, productBuyRebate.getSkuNo());
		}

		// 1.获取基础商品列表
//		List<Product> products = groupOrderManager.getBatchProducts(productIds, areaCode, ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE, ua);
		List<Product> products = groupOrderManager.getPros(productRequestParams, areaCode, ppi, GroupOrderConstants.TWO_LIST_PRODUCT_IMAGE, ua, mOrg, policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
		// 购买返开关
		String onOff = gcache.get("buyRebateOnOff");
		if(null == onOff){
			// 2.获取购买返信息
			List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
			// 记录缓存key
			Map<String, Integer> buyKey = new HashMap<String, Integer>();
			if(null == products || products.size() == 0) return null;
			for (Product product : products) {
				String pid = product.getId();
				String skuNo = null;
				if(keyMap.containsKey(pid + "_" + product.getSkuId()))
					skuNo = keyMap.get(pid + "_" + product.getSkuId());
				else if(keyMap.containsKey(pid))
					skuNo = keyMap.get(pid);
					
				product.setSkuNo(skuNo);
				String key = pid + "_" + skuNo;

				Integer re = JSONObject.parseObject(propertiesConfig.getGcacheNew().hget("meidian-restful-grouporder-buyRebate", key), Integer.class);
//				Integer re = JSONObject.parseObject(gcache.get("buyRebate_" + key), Integer.class);
				if(null == re){
					CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
					// 返利key，自定义，作为返回多个值的区分,以productId作为key
					commonGoodsReqDto.setKey(key);
					// 商品productId
					commonGoodsReqDto.setItemId(pid);
					commonGoodsReqDto.setSkuId(skuNo);
					// 商户id
					commonGoodsReqDto.setMerchantId(product.getShopId() == null || product.getShopId().equalsIgnoreCase("") ? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE : product.getShopId());
					commonGoodsReqDtos.add(commonGoodsReqDto);
				}else{
					buyKey.put(key, re);
				}

			}
			Map<String, Integer> rebatePlanDtoMap = new HashMap<String, Integer>();
//			logger.debug("buyRebates ==> {}", JSONUtils.toJSONString(commonGoodsReqDtos));
//			System.err.println(JSONUtils.toJSONString(commonGoodsReqDtos));
			if(commonGoodsReqDtos.size() > 0)
				rebatePlanDtoMap = iDubboSellersService.getRebatePlanAmountToBsShop(commonGoodsReqDtos);
			// 把从缓存中取到的合并到返参中
			rebatePlanDtoMap.putAll(buyKey);
			for (Product product : products) {
				ProductBuyRebateVo productBuyRebateVo = new ProductBuyRebateVo();

				// 价格单位转换
				double price = groupOrderManager.getPrice(product.getSalePrice());
				String proId = product.getId();
				String sNo = product.getSkuNo();
				String pskey = proId + "_" + sNo;
				Integer reba = rebatePlanDtoMap.get(pskey);
				Double rebate = 0d;
				if(null != reba && reba != 0){
					rebate = BigDecimalUtils.round(
							DoubleUtils.mul(price, Double.valueOf(reba))
									/ 10000,
							2);

					// 添加缓存
					if(!buyKey.containsKey(pskey))
						propertiesConfig.getGcacheNew().hset("meidian-restful-grouporder-buyRebate", pskey, JSONUtils.toJSONString(reba).getBytes());
//						gcache.setex("buyRebate_" + proId + "_" + keyMap.get(proId), 3 * 60, JSONUtils.toJSONString(reba).getBytes());
				}else {
					// 添加缓存
					if(!buyKey.containsKey(pskey))
						propertiesConfig.getGcacheNew().hset("meidian-restful-grouporder-buyRebate", pskey, JSONUtils.toJSONString(0).getBytes());
//						gcache.setex("buyRebate_" + proId + "_" + keyMap.get(proId), 3 * 60, JSONUtils.toJSONString(0).getBytes());
				}

				productBuyRebateVo.setBuyRebate(DoubleUtils.switchScientificCalculate(rebate));
				productBuyRebateVo.setProduct(product);
				productBuyRebateVos.add(productBuyRebateVo);
			}
		}else {
			for (Product product : products) {
				ProductBuyRebateVo productBuyRebateVo = new ProductBuyRebateVo();
				productBuyRebateVo.setProduct(product);
				productBuyRebateVos.add(productBuyRebateVo);
			}
			return productBuyRebateVos;
		}

		return productBuyRebateVos;
	}


	public Double getBuyRebate(String productId, String skuNo, String areaCode, String price) throws ServiceException{
		// 1.获取基础商品列表
		List<String> productIds = new ArrayList<String>();
		productIds.add(productId);
		Byte ua = 0;
		List<Product> products = groupOrderManager.getBatchProducts(productIds, areaCode, null, null, ua);
		Product product = products.get(0);

		// 2.获取购买返
		Integer re = JSONObject.parseObject(propertiesConfig.getGcacheNew().hget("meidian-restful-grouporder-buyRebate", productId + "_" + skuNo), Integer.class);
//		Integer re = JSONObject.parseObject(gcache.get("buyRebate_" + productId + "_" + skuNo), Integer.class);
		List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
		if(null == re){
			CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
			// 返利key，自定义，作为返回多个值的区分,以productId,skuNo作为key
			commonGoodsReqDto.setKey(productId + "_" + skuNo);
			// 商品productId
			commonGoodsReqDto.setItemId(productId);
			// skuNo
			commonGoodsReqDto.setSkuId(skuNo);
			// 商户id
			commonGoodsReqDto.setMerchantId(product.getShopId() == null || product.getShopId().equalsIgnoreCase("") ? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE : product.getShopId());
			commonGoodsReqDtos.add(commonGoodsReqDto);
		}else{
			if(re == 0){
				return 0d;
			}
			return BigDecimalUtils.round(
					DoubleUtils.mul(Double.valueOf(price), Double.valueOf(re))
							/ 10000,
					2);
		}

//		System.err.println(JSONUtils.toJSONString(commonGoodsReqDtos));

		Map<String, Integer> rebatePlanDtoMap = iDubboSellersService.getRebatePlanAmountToBsShop(commonGoodsReqDtos);

		Integer rebatePlanDtos = rebatePlanDtoMap.get(productId + "_" + skuNo);
		if(null == rebatePlanDtos || rebatePlanDtos == 0) {
			// 添加缓存
			propertiesConfig.getGcacheNew().hset("meidian-restful-grouporder-buyRebate", product.getId() + "_" + skuNo, JSONUtils.toJSONString(rebatePlanDtos).getBytes());
//			gcache.setex("buyRebate_" + product.getId() + "_" + skuNo, 3 * 60, JSONUtils.toJSONString(rebatePlanDtos).getBytes());
			return 0d;
		}

		// 添加缓存
		propertiesConfig.getGcacheNew().hset("meidian-restful-grouporder-buyRebate", product.getId() + "_" + skuNo, JSONUtils.toJSONString(rebatePlanDtos).getBytes());
//		gcache.setex("buyRebate_" + product.getId() + "_" + skuNo, 3 * 60, JSONUtils.toJSONString(rebatePlanDtos).getBytes());

		return BigDecimalUtils.round(
				DoubleUtils.mul(Double.valueOf(price), Double.valueOf(rebatePlanDtos))
						/ 10000,
				2);
	}

	/**
	 * 处理主页商品列表中的组团专题活动页
	 * @param acUkeySubscriptMap
	 * @param productGroupInfoVos
	 * @param areaCode
	 * @param request
	 */
	public void getHomeActivityPageInfo(Map<Integer, String> acUkeySubscriptMap, List<ProductGroupInfoVo> productGroupInfoVos, String areaCode){
		for (Map.Entry<Integer, String> entry : acUkeySubscriptMap.entrySet()) {
//			HomeGroupProductActivityPage activityPage = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-interface", entry.getValue() + "_" + areaCode), HomeGroupProductActivityPage.class);
			HomeGroupProductActivityPage activityPage = JSONObject.parseObject(gcache.get("homePageActivity_interface_" + entry.getValue() + "_" + areaCode), HomeGroupProductActivityPage.class);
			if(null == activityPage){
				// 调取活动页接口
				activityPage = this.getHomePageActivity(entry.getValue(), areaCode);

				// 加入缓存
//				gcache.hset("meidian-restful-grouporder-interface", entry.getValue() + "_" + areaCode, JSONUtils.toJSONString(activityPage).getBytes());
				gcache.setex("homePageActivity_interface_" + entry.getValue() + "_" + areaCode, 3 * 60, JSONUtils.toJSONString(activityPage).getBytes());
			}

			ProductGroupInfoVo productGroupInfoVo = new ProductGroupInfoVo();
			productGroupInfoVo.setHomeGroupProductActivityPage(activityPage);
			if(productGroupInfoVos.size() <= entry.getKey()){
				productGroupInfoVos.add(productGroupInfoVo);
			}else{
				productGroupInfoVos.add(entry.getKey(), productGroupInfoVo);
			}
		}
	}

	/**
	 * 获取商品信息
	 *
	 * @return
	 * @throws ServiceException
	 */
//	public List<ProductVo> getProducts(List<ProductsVo> productIds, String areaCode, HttpServletRequest request) {
//		List<ProductVo> resultList = new ArrayList<ProductVo>();
//
//		int listSize = productIds.size();
//		int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
//
//		List<ProductsVo> paramList = new ArrayList<>();
//		for (int a = 1; a <= selectCount; a++) {
//			paramList.clear();
//			if (selectCount == 1) {
//				paramList = productIds;
//			} else {
//				if (a != selectCount) {
//					paramList.addAll(productIds.subList(30 * (a - 1), 30 * a));
//				} else {
//					paramList.addAll(productIds.subList(30 * (a - 1), listSize));
//				}
//			}
//
//			CommonResultEntity<ProductInfoListVo> resultVo = GorderInfoForAppNewResource.getProductInfoByIds(paramList,
//					areaCode);
//			logger.debug("getProductsByIds resultVo ==> {} ", resultVo);
//			logger.info("getProductsByIds areaCode ==> {} ", areaCode);
//			if (resultVo.getBusinessObj() != null) {
//				ProductInfoListVo tVo = resultVo.getBusinessObj();
//				if (tVo != null) {
//					List<ProductManagementVo> tList = tVo.getProductInfo();
//					if (tList != null && tList.size() > 0) {
//						// 过滤掉ProductStatus == -1 （下架）的商品对象
//						for (ProductManagementVo productManagementVo : tList) {
//							if (null != productManagementVo && null != productManagementVo.getProductStatus()
//									&& productManagementVo.getProductStatus() == 1) {
//
//								ProductVo productVo = groupOrderManager.copyProduct(productManagementVo);
//								resultList.add(productVo);
//							}
//						}
//					}
//				}
//			}
//		}
//
//		return resultList;
//	}

	/**
	 * 获取首页立减商品列表
	 * @param productCouponReqs
	 * @param areaCode
	 * @param request
	 * @throws ServiceException
	 */
	public List<HomeCouponProductRes> getHomeProductCoupons(List<ProductCouponReq> productCouponReqs, String areaCode, Integer ppi, Byte ua, String mOrg, String policyId) throws ServiceException{
		List<HomeCouponProductRes> homeCouponProducts = new ArrayList<HomeCouponProductRes>();

		List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
		Map<Integer, String> activityUkeysubscriptMap = new LinkedHashMap<Integer, String>();
		int i = 0;
		for (ProductCouponReq productCouponReq : productCouponReqs) {
			i ++;
			if(null != productCouponReq.getActivityUkey() && !productCouponReq.getActivityUkey().equalsIgnoreCase("")){
				activityUkeysubscriptMap.put(i - 1, productCouponReq.getActivityUkey());
				continue;
			}else{
				ProductRequestParam productRequestParam = new ProductRequestParam(productCouponReq.getProductId(), productCouponReq.getSkuId());
				productRequestParams.add(productRequestParam);
			}
		}
		// 获取商品列表
//		List<Product> products = groupOrderManager.getBatchProducts(productIds, areaCode, ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE, ua);
		List<Product> products = groupOrderManager.getPros(productRequestParams, areaCode, ppi, GroupOrderConstants.TWO_LIST_PRODUCT_IMAGE, ua, mOrg, policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);

		for (Product prod : products) {
			HomeCouponProductRes homeCouponProductRes = new HomeCouponProductRes();
			homeCouponProductRes.setProduct(prod);
			homeCouponProducts.add(homeCouponProductRes);
		}


		// 获取专题活动信息
		if(!activityUkeysubscriptMap.isEmpty())
			this.getHomeActivityPage(activityUkeysubscriptMap, homeCouponProducts, areaCode, mOrg, policyId);

		// 处理图片
		this.couponImageInfo(homeCouponProducts, ppi, ua);

		return homeCouponProducts;
	}

	/**
	 * 首页列表中的专题活动页
	 * @param activityUkeysubscriptMap
	 * @param homeCouponProducts
	 * @param areaCode
	 * @throws ServiceException
	 */
	public void getHomeActivityPage(Map<Integer, String> activityUkeysubscriptMap, List<HomeCouponProductRes> homeCouponProducts, String areaCode, String mOrg, String policyId) throws ServiceException{

		for (Map.Entry<Integer, String> entry : activityUkeysubscriptMap.entrySet()) {
			HomeProductCouponVo homeProductCouponVo = JSONObject.parseObject(gcache.get("homePageProduct_" + entry.getValue() + "_" + areaCode + "_" + mOrg), HomeProductCouponVo.class);
			if(null == homeProductCouponVo){
				// 获取活动页信息
				homeProductCouponVo = this.getHomePageCouponActivityInfo(entry.getValue(), areaCode, mOrg, policyId);

				// 加入缓存
				gcache.setex("homePageProduct_" + entry.getValue() + "_" + areaCode + "_" + mOrg, 3 * 60, JSONUtils.toJSONString(homeProductCouponVo).getBytes());
			}

			HomeCouponProductRes homeCouponProductRes = new HomeCouponProductRes();
			homeCouponProductRes.setHomeProductCouponVo(homeProductCouponVo);
			if(homeCouponProducts.size() <= entry.getKey()){
				homeCouponProducts.add(homeCouponProductRes);
			}else{
				homeCouponProducts.add(entry.getKey(), homeCouponProductRes);
			}
		}
	}

	/**
	 * 首页列表中的组团专题活动页
	 * @param ukey
	 * @param areaCode
	 * @return
	 */
	public HomeGroupProductActivityPage getHomePageActivity(String ukey, String areaCode){

		HomeGroupProductActivityPage homeGroupProductActivityPage = new HomeGroupProductActivityPage();
		List<HomeProductActivity> homeProductActivities = new ArrayList<HomeProductActivity>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("unique_key", ukey);
		String result = null;
		try {
			result = httpClientUtil.doGet(productIdsUrl, map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		JSONObject obj = JSONObject.parseObject(result);

		JSONObject data = null;
		JSONObject slot = null;
		JSONArray list = null;

		try {
			data = obj.getJSONObject("data");
			slot = data.getJSONObject("slot");
			list = data.getJSONArray("list");
		} catch (Exception e) {
			// TODO: handle exception
		}
		if (null == data || null == slot || null == list)
			return homeGroupProductActivityPage;

		Slot sl = new Slot();
		sl.setName(slot.getString("name"));
		sl.setTable_name(slot.getString("table_name"));
		homeGroupProductActivityPage.setSlot(sl);
		homeGroupProductActivityPage.setUkey(ukey);

		for (int i = 0; i < list.size(); i++) {
			JSONObject ob = list.getJSONObject(i);
			String type = ob.getString("type");
			if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

				JSONArray models = ob.getJSONArray("model");
				List<ProductsVo> productsVos = new ArrayList<ProductsVo>();
				if(null != models && models.size() > 0){
					if(null != models && models.size() > 0){
						for (int j = 0; j < models.size(); j++) {
							if(j >= 6)
								break;
							JSONObject jsob = models.getJSONObject(j);
							String productId = jsob.getString("product_id");
							Long activityId = jsob.getLong("activity_id");
							String skuId = jsob.getString("sku_id");
							ProductsVo productsVo = new ProductsVo();
							productsVo.setProductId(productId);
							productsVo.setActivityId(activityId);
							productsVo.setSkuId(skuId);
							productsVos.add(productsVo);
						}
					}
				}

				// 获取商品信息
				List<ProductsVo> pros = new ArrayList<ProductsVo>();
				Map<Integer, String> subscriptMap = new LinkedHashMap<Integer, String>();
				int k = 0;
				for (ProductsVo productsVo : productsVos) {
					k ++;
//					HomeProductActivity homeProductActivity = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-group", productsVo.getProductId() + "_" + productsVo.getSkuId() + "_" + productsVo.getActivityId() + "_" + areaCode), HomeProductActivity.class);
					HomeProductActivity homeProductActivity = JSONObject.parseObject(gcache.get("homePageGroup_" + productsVo.getProductId() + "_" + productsVo.getSkuId() + "_" + productsVo.getActivityId() + "_" + areaCode), HomeProductActivity.class);
					if(null == homeProductActivity){
						subscriptMap.put(k - 1, productsVo.getProductId());
						pros.add(productsVo);
					}else{
						homeProductActivities.add(homeProductActivity);
					}
				}
				if(null == pros || pros.size() == 0)
					break;
				CommonResultEntity<ProductInfoListVo> resultVo = gorderInfoForAppNewResource.getProductInfoByIds(pros, areaCode);
				ProductInfoListVo productInfoListVo = resultVo.getBusinessObj();
				List<ProductManagementConciseVo> productManagementConciseVos = productInfoListVo.getProductInfo();

				for (ProductManagementConciseVo productManagementConciseVo : productManagementConciseVos) {
					ProductGroupInfoVo productGroupInfoVo = this.getProductInfo(productManagementConciseVo);
					HomeProductActivity homePrAc = new HomeProductActivity();
					homePrAc.setProductInfo(productGroupInfoVo.getProductInfo());
					homePrAc.setHomePageActivity(productGroupInfoVo.getHomePageActivity());
					// 插入相应的下标
					for (Map.Entry<Integer, String> entry : subscriptMap.entrySet()) {
						if(entry.getValue().equalsIgnoreCase(homePrAc.getProductInfo().getProductId())){
							if(homeProductActivities.size() <= entry.getKey()){
								homeProductActivities.add(homePrAc);
							}else
								homeProductActivities.add(entry.getKey(), homePrAc);

							// 添加到缓存
							gcache.setex("homePageGroup_" + productManagementConciseVo.getProductId() + "_" + productManagementConciseVo.getSkuId() + "_" + productManagementConciseVo.getActivityId() + "_" + areaCode,
									3 * 60, JSONUtils.toJSONString(homePrAc).getBytes());
							break;
						}
					}
				}
				break;
			}
		}

		homeGroupProductActivityPage.setHomeProductActivities(homeProductActivities);

		return homeGroupProductActivityPage;
	}

	/**
	 * 首页商品列表中的立减专题活动页
	 * @param ukey
	 * @param areaCode
	 * @return
	 * @throws ServiceException
	 */
	public HomeProductCouponVo getHomePageCouponActivityInfo(String ukey, String areaCode, String mOrg, String policyId) throws ServiceException{

		HomeProductCouponVo homeProductCouponVo = new HomeProductCouponVo();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("unique_key", ukey);
		String result = null;
		try {
			result = httpClientUtil.doGet(productIdsUrl, map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		JSONObject obj = JSONObject.parseObject(result);

		JSONObject data = null;
		JSONObject slot = null;
		JSONArray list = null;

		try {
			data = obj.getJSONObject("data");
			slot = data.getJSONObject("slot");
			list = data.getJSONArray("list");
		} catch (Exception e) {
			// TODO: handle exception
		}
		if (null == data || null == slot || null ==list)
			return homeProductCouponVo;

		Slot sl = new Slot();
		sl.setName(slot.getString("name"));
		sl.setTable_name(slot.getString("table_name"));
		homeProductCouponVo.setSlot(sl);
		homeProductCouponVo.setUkey(ukey);

		for (int i = 0; i < list.size(); i++) {
			JSONObject ob = list.getJSONObject(i);
			String type = ob.getString("type");
			if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

				JSONArray models = ob.getJSONArray("model");
				
				List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
				if(null != models && models.size() > 0){
					for (int j = 0; j < models.size(); j++) {
						if(j >= 6)
							break;
						JSONObject jsob = models.getJSONObject(j);
						String proId = jsob.getString("product_id");
						String skuId = jsob.getString("sku_id");
						ProductRequestParam productRequestParam = new ProductRequestParam(proId, skuId);
						productRequestParams.add(productRequestParam);
					}
				}

				// 获取商品列表
//				List<Product> products = groupOrderManager.getBatchProducts(productIds, areaCode, null, null, null);
				List<Product> products = groupOrderManager.getPros(productRequestParams, areaCode, null, null, null, mOrg, policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
				
				homeProductCouponVo.setProducts(products);

				break;
			}
		}

		return homeProductCouponVo;
	}

	/**
	 * 美店佣金-批量
	 * @param shareRebates
	 * @return
	 * @throws ServiceException
	 */
	public List<ShareRebateResponse> shareRebate(List<ShareRebate> shareRebates, String organizationId , String userId) throws ServiceException{
		
		List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
		List<ShareRebateResponse> shareRebateResponses = new ArrayList<ShareRebateResponse>();
		Map<String, Long> reMap = new HashMap<String, Long>();
		String key = null;
		if (null != organizationId && !organizationId.equalsIgnoreCase("")) key = organizationId;
		for(ShareRebate shareRebate : shareRebates){
			//add by lsx 根据sku查询商品信息begin	
			String productId = shareRebate.getProductId();
			String brandCode = gcache.get("productBrandCode_" + productId);
			if(StringUtils.isEmpty(brandCode)){
				//StoreSkuInfo storeSkuInfo=gomeSkuService.getSkuInfo(skuNo);
				Map<String, String> mapResult=prodDetailService.getProductMultiProperties(shareRebate.getProductId(),properties);
				//logger.debug("gomeSkuService.getSkuInfo>>>> {} ",mapResult);
				if(mapResult != null ){
					brandCode = mapResult.get("brandCode");
					if(!StringUtils.isEmpty(brandCode)){
						gcache.setex("productBrandCode_" + productId, 20 * 60 , brandCode);
					}
				}
				
			}
			shareRebate.setBrandCode(brandCode);
			//add by lsx 根据sku查询商品信息end
			
			String shareRebateKey = shareRebate.getProductId() + "_" + shareRebate.getSkuNo() + "_" + shareRebate.getPrice() + "_" + key +"_"+ userId +"_" + brandCode; //追加 userId brandCode 为key
			Long re = JSONObject.parseObject(propertiesConfig.getGcacheNew().hget("meidian-restful-grouporder-rebate", shareRebateKey), Long.class);
//			Long re = JSONObject.parseObject(gcache.get("shareRebate_" + shareRebateKey), Long.class);
			if(null == re){
				CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
				// 自定义，返参取值使用，以productId为key
				commonGoodsReqDto.setKey(shareRebate.getProductId() + "_" + shareRebate.getSkuNo());
				// productId
				commonGoodsReqDto.setItemId(shareRebate.getProductId());
				// shopId
				commonGoodsReqDto.setMerchantId(shareRebate.getShopId() == null || shareRebate.getShopId().equalsIgnoreCase("") ? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE : shareRebate.getShopId());
				// skuNo
				commonGoodsReqDto.setSkuId(shareRebate.getSkuNo());
				// 销售组织id
				commonGoodsReqDto.setMarketOrgId(organizationId);
				// 单位分
				commonGoodsReqDto.setPrice(shareRebate.getPrice());
				// 指定分享返的flow类型，优化
				Integer flow[] = {1,15,22,23};
				commonGoodsReqDto.setFlow(flow);
				//add by lsx begin
				commonGoodsReqDto.setBrandCode(brandCode);
				commonGoodsReqDto.setMicroUserId(userId);
			    //add by lsx end	
				commonGoodsReqDtos.add(commonGoodsReqDto);
				
			}else {
				reMap.put(shareRebate.getProductId() + "_" + shareRebate.getSkuNo(), re);
			}
			
		}
		
		Map<String, Long> shareRebateMap = new HashMap<String, Long>();
		
		// 限制10条
		int listSize = commonGoodsReqDtos.size();
		int selectCount = listSize % 10 == 0 ? listSize / 10 : listSize / 10 + 1;
		List<CommonGoodsReqDto> paramList = new ArrayList<CommonGoodsReqDto>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = commonGoodsReqDtos;
			} else {
				if (a != selectCount) {
					paramList.addAll(commonGoodsReqDtos.subList(10 * (a - 1), 10 * a));
				} else {
					paramList.addAll(commonGoodsReqDtos.subList(10 * (a - 1), listSize));
				}
			}
			
			//System.err.println(JSONUtils.toJSONString(paramList));
			
			if(commonGoodsReqDtos.size() > 0)
				shareRebateMap.putAll(iDubboSellersService.getRebatePlanAmount(paramList));
		}
		
		reMap.putAll(shareRebateMap);
		for(ShareRebate shareRe : shareRebates){
			if(null != shareRebateMap.get(shareRe.getProductId() + "_" + shareRe.getSkuNo())){
				// 添加到缓存
				String shareRebateKey = shareRe.getProductId() + "_" + shareRe.getSkuNo() + "_" + shareRe.getPrice() + "_" + key +"_"+ userId +"_" + shareRe.getBrandCode(); //追加 userId brandCode 为key
				propertiesConfig.getGcacheNew().hset("meidian-restful-grouporder-rebate", shareRebateKey, JSONUtils.toJSONString(shareRebateMap.get(shareRe.getProductId() + "_" + shareRe.getSkuNo())).getBytes());
//				gcache.setex("shareRebate_" + shareRebateKey, 3 * 60, JSONObject.toJSONString(shareRebateMap.get(shareRe.getProductId())).getBytes());
			}
			ShareRebateResponse shareRebateResponse = new ShareRebateResponse(shareRe.getProductId(), shareRe.getSkuNo(), DoubleUtils.switchScientificCalculate(groupOrderManager.getPrice(reMap.get(shareRe.getProductId() + "_" + shareRe.getSkuNo()))));
			shareRebateResponses.add(shareRebateResponse);
		}
		
		return shareRebateResponses;
	}

	/**
	 * 实时查询，提供给楼上cms后台使用
	 * @param productIds
	 * @param areaCode
	 * @return
	 */
	public List<ProductCms> products(List<String> skuIds, String imageSize){
		List<ProductCms> products = new ArrayList<ProductCms>();

		if(null == skuIds || skuIds.size() == 0) return null;

		// 限制20条
		int listSize = skuIds.size();
		int selectCount = listSize % 20 == 0 ? listSize / 20 : listSize / 20 + 1;
		List<String> paramList = new ArrayList<>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = skuIds;
			} else {
				if (a != selectCount) {
					paramList.addAll(skuIds.subList(20 * (a - 1), 20 * a));
				} else {
					paramList.addAll(skuIds.subList(20 * (a - 1), listSize));
				}
			}
			List<GoodsInfo> goodsInfos = productInfoService.getGoodsInfos(paramList, imageSize);
			if(null == goodsInfos || goodsInfos.size() == 0) continue;
			for (GoodsInfo goodsInfo : goodsInfos) {
				ProductCms productCms = new ProductCms();
				BeanUtils.copyProperties(goodsInfo, productCms);
				productCms.setMainImage(goodsInfo.getGoodsImgUrl());
				productCms.setName(goodsInfo.getGoodsName());
				products.add(productCms);
			}
		}

		return products;
	}

	/**
	 * 美店佣金单个使用
	 * @param productId
	 * @param skuNo
	 * @param price
	 * @param shopId
	 * @param organizationId
	 * @return
	 * @throws ServiceException
	 */
	public String shareRebateOneself(String productId, String skuNo, String skuId, Long price, String shopId, String organizationId , String userId) throws ServiceException{
		
		// 获取skuNo
		if(null == skuNo || skuNo.equalsIgnoreCase("")){
			if(null == skuId || skuId.equalsIgnoreCase("")) return "0";
			SkuItem skuItem = prodDetailService.getSku(productId, skuId, null);
			if(null == skuItem) return "0";
			skuNo = skuItem.getSkuNo();
		}
		if(null == skuNo || skuNo.equalsIgnoreCase("")) return "0";
		
		//add by lsx 根据sku查询商品信息begin	
		String brandCode = gcache.get("productBrandCode_" + productId);
		if(StringUtils.isEmpty(brandCode)){
			//StoreSkuInfo storeSkuInfo=gomeSkuService.getSkuInfo(skuNo);
			Map<String, String> mapResult=prodDetailService.getProductMultiProperties(productId,properties);
			logger.debug("gomeSkuService.getSkuInfo>>>> {} ",mapResult);
			if(mapResult != null ){
				brandCode = mapResult.get("brandCode");
				if(!StringUtils.isEmpty(brandCode)){
					gcache.setex("productBrandCode_" + productId, 20 * 60 , brandCode);
				}
			}
			
		}
		//add by lsx 根据sku查询商品信息end
		
		
		
		
		String key = null;
		if (null != organizationId && !organizationId.equalsIgnoreCase("")) key = organizationId;
		String shareRebateKey = productId + "_" + skuNo + "_" + price + "_" + key +"_"+ userId +"_" + brandCode; //追加 userId brandCode 为key
		Long re = JSONObject.parseObject(propertiesConfig.getGcacheNew().hget("meidian-restful-grouporder-rebate", shareRebateKey), Long.class);
//		Long re = JSONObject.parseObject(gcache.get("shareRebate_" + shareRebateKey), Long.class);
		if(null == re){
			List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
			CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
			// 自定义，返参取值使用，以productId为key
			commonGoodsReqDto.setKey(productId + "_" + skuNo);
			// productId
			commonGoodsReqDto.setItemId(productId);
			// shopId
			commonGoodsReqDto.setMerchantId(shopId == null || shopId.equalsIgnoreCase("") ? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE : shopId);
			// skuNo
			commonGoodsReqDto.setSkuId(skuNo);
			// 销售组织id
			commonGoodsReqDto.setMarketOrgId(organizationId);
			// 单位分
			commonGoodsReqDto.setPrice(price);
			// 指定分享返的flow类型，优化
			Integer flow[] = {1,15,22,23};
			commonGoodsReqDto.setFlow(flow);
			//add by lsx begin 
			commonGoodsReqDto.setBrandCode(brandCode);
			commonGoodsReqDto.setMicroUserId(userId);
			//add by lsx end
			commonGoodsReqDtos.add(commonGoodsReqDto);
		
//			System.err.println(JSONUtils.toJSONString(commonGoodsReqDtos));

			Map<String, Long> shareRebateMap = iDubboSellersService.getRebatePlanAmount(commonGoodsReqDtos);
			
			if(null != shareRebateMap){
				// 添加到缓存
				propertiesConfig.getGcacheNew().hset("meidian-restful-grouporder-rebate", shareRebateKey, JSONUtils.toJSONString(shareRebateMap.get(productId + "_" + skuNo)).getBytes());
//				gcache.setex("shareRebate_" + shareRebateKey, 3 * 60, JSONUtils.toJSONString(shareRebateMap.get(productId)).getBytes());
				return DoubleUtils.switchScientificCalculate(groupOrderManager.getPrice(shareRebateMap.get(productId + "_" + skuNo)));
			}
		} else {
			return DoubleUtils.switchScientificCalculate(groupOrderManager.getPrice(re));
		}
		
		return "0";
	}

	/**
	 * 查询CMS配置 悬浮窗 Icon 功能模块信息
	 * @param code
	 * @return
	 */
	public List<Icon> getHomePageSetInfoByCode(String code){
		List<SuspendIcons> suspendIcons = suspendIconResource.findSuspendIconList(code);
		if(null == suspendIcons || suspendIcons.size() == 0) return null;
		List<Icon> icons = new ArrayList<Icon>();
		for (SuspendIcons suspendIcon : suspendIcons) {
			Icon icon = new Icon();
			BeanUtils.copyProperties(suspendIcon, icon);
			icons.add(icon);
		}
		
		return icons;
	}

	/**
	 * 用户参与同一个团的次数
	 * @param userId
	 * @param mutiCollectionId
	 *
	 * @param groupId
	 * @return
	 */
	public Boolean userSameGroupRestrict(Long userId, Long mutiCollectionId, Long groupId){
		CommonResultEntity<UserAttendGroupVo> commonResult = gorderInfoForAppNewResource.checkUserAttendOneGroupStatus(userId, mutiCollectionId, groupId);
		UserAttendGroupVo userAttendGroupVo = commonResult.getBusinessObj();
		if(null == userAttendGroupVo || null == userAttendGroupVo.getIsOpen()) return false;
		return userAttendGroupVo.getIsOpen();
	}

	/**
	 * 商详页图片楼层
	 * @param storeCode
	 * @param pageCode
	 * @param channel
	 * @return
	 */
	public Model getProductDetailsFloor(String storeCode,String pageCode,int channel){
		Model model = new Model();
		
		if(channel == GroupOrderConstants.MEIDIAN_CMS_IOS_APP) channel = 3;
		SecondPageMI secondPageMI = pageInfoResource.getSecondPageMI(pageCode, storeCode, channel);
		List<Menus> menus = secondPageMI.getModuleMenuList();
		Map<String, Object> moduleMap = secondPageMI.getModuleJsonMap();
		
		List<ModelVo> modelVos = new ArrayList<ModelVo>(); 
		for (Menus menu : menus) {
			ModelVo modelVo = new ModelVo();
			int modeType = menu.getModuleType();
			modelVo.setType(modeType);
			
			String moduleCode = menu.getModuleCode();
			
			// 图片处理
			if(modeType == GroupOrderConstants.MEIDIAN_BANNER
					|| modeType == GroupOrderConstants.MEIDIAN_ADVERT
					|| modeType == GroupOrderConstants.MEIDIAN_PICTURE
					|| modeType == GroupOrderConstants.MEIDIAN_ICON
//					|| modeType == GroupOrderConstants.MEIDIAN_PICTURE_LEFT_BIG
//					|| modeType == GroupOrderConstants.MEIDIAN_PICTURE_RIGHT_BIG
//					|| modeType == GroupOrderConstants.MEIDIAN_PICTURE_NOT_RULE
					|| modeType == GroupOrderConstants.MEIDIAN_BOTTOM_NAVIGATION
					|| modeType == GroupOrderConstants.MEIDIAN_PLACEHOLDER
					){
				
				List<ImageElement> imageElements = new ArrayList<ImageElement>();
				// WriteMapNullValue:保留null值
				Object ob = moduleMap.get(moduleCode);
				if(null == ob) continue;
				String obj = JSONObject.toJSONString(ob, SerializerFeature.WriteMapNullValue);
				JSONObject jsOb = JSONObject.parseObject(obj);
				JSONArray jsonArraies = jsOb.getJSONArray("itemList");
				if(null == jsonArraies) continue;
				for (int i = 0; i < jsonArraies.size(); i++) {
					JSONObject jo = jsonArraies.getJSONObject(i);
					if(null == jo) continue;
					ImageElement imageElement = new ImageElement();
					imageElement.setImageUrl(jo.getString("imgUrl"));
					imageElement.setTarget(jo.getString("skipInfo"));
					imageElements.add(imageElement);
				}
				modelVo.setImageElements(imageElements);
			}
			modelVos.add(modelVo);
		}
		model.setModelVos(modelVos);

		return model;
	}


	/**
	 * 处理首页组团列表图片
	 * @param productGroupInfoVos
	 * @param ppi
	 * @param ua
	 */
	public List<Map<String, String>> groupsImageInfo(List<ProductGroupInfoVo> productGroupInfoVos, Integer ppi, Byte ua){

		// 处理图片的同时趁着获取美店价格接口的入参
//		Map<String, List<String>> proSkuMap = new HashMap<String, List<String>>();
//		List<String> pros = new ArrayList<String>();
//		List<String> skus = new ArrayList<String>();
		
		List<Map<String, String>> infoList = new ArrayList<>();
		Map<String, String> infoMap = null;
		int count = 1;
		
		// 获取分辨率
		String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.TWO_LIST_PRODUCT_IMAGE);
		String ratioActivityPage = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.HOME_ACTIVITY_PRODUCT_IMAGE);

		for (ProductGroupInfoVo productGroupInfoVo : productGroupInfoVos) {
			if(null != productGroupInfoVo.getProductInfo()){
				ProductInfo productInfo = productGroupInfoVo.getProductInfo();
				// 处理首页组团列表图片分辨率
				String image = ImageUtils.imageUrlInfo(productInfo.getProductImage(), ratio, ua);
				productInfo.setProductImage(image);

				// 处理美店价入参
				if(null != productInfo.getSkuId() && !productInfo.getSkuId().equalsIgnoreCase("")){
					if(count % 12 == 1) {
						infoMap = new HashMap<>();
						infoList.add(infoMap);
					}
					infoMap.put(productInfo.getSkuId(), productInfo.getProductId());
					count++;
//					pros.add(productInfo.getProductId());
//					skus.add(productInfo.getSkuId());
				}

			}else if(null != productGroupInfoVo.getHomeGroupProductActivityPage()){
				// 处理首页组团列表中的专题活动页的图片分辨率
				List<HomeProductActivity> homeProductActivities = productGroupInfoVo.getHomeGroupProductActivityPage().getHomeProductActivities();
				if(null == homeProductActivities || homeProductActivities.size() == 0) continue;
				for (HomeProductActivity homeProductActivity : homeProductActivities) {
					ProductInfo proInfo = homeProductActivity.getProductInfo();
					// 处理首页组团列表中专题活动的图片分辨率
					String image = ImageUtils.imageUrlInfo(proInfo.getProductImage(), ratioActivityPage, ua);
					proInfo.setProductImage(image);

					// 处理美店价入参
					if(null != proInfo.getSkuId() && !proInfo.getSkuId().equalsIgnoreCase("")){
						if(count % 12 == 1) {
							infoMap = new HashMap<>();
							infoList.add(infoMap);
						}
						infoMap.put(proInfo.getSkuId(), proInfo.getProductId());
						count++;
//						pros.add(proInfo.getProductId());
//						skus.add(proInfo.getSkuId());
					}
				}
			}
		}
//		proSkuMap.put("pros", pros);
//		proSkuMap.put("skus", skus);
		return infoList;
	}

	public void couponImageInfo(List<HomeCouponProductRes> homeCouponProducts, Integer ppi, Byte ua){
		// 获取分辨率
		String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.HOME_ACTIVITY_PRODUCT_IMAGE);
		for (HomeCouponProductRes homeCouponProductRes : homeCouponProducts) {
			if(null == homeCouponProductRes.getHomeProductCouponVo()) continue;
			List<Product> pros = homeCouponProductRes.getHomeProductCouponVo().getProducts();
			if(null == pros || pros.size() == 0) continue;
			for (Product product : pros) {
				// 处理首页组团列表中专题活动的图片分辨率
				String image = ImageUtils.imageUrlInfo(product.getMainImage(), ratio, ua);
				product.setMainImage(image);
			}
		}
	}


	/**
	 * 首页组团列表美店价处理
	 * @param productGroupInfoVos
	 * @param infoList
	 * @param areaCode
	 * @param channel
	 */
	public void meidianPrices(List<ProductGroupInfoVo> productGroupInfoVos, List<Map<String, String>> infoList, String areaCode, String channel, String storeCode, String policyId){

//		List<String> proIds = infoList.get("pros");
//		List<String> skuIds = infoList.get("skus");
//		List<GomeVipPriceItem> meidianPrices = new ArrayList<GomeVipPriceItem>();

//		int listSize = proIds.size();
//		int selectCount = listSize % 12 == 0 ? listSize / 12 : listSize / 12 + 1;
//
//		List<String> proParamIds = new ArrayList<String>();
//		List<String> skuParamIds = new ArrayList<String>();
//		for (int a = 1; a <= selectCount; a++) {
//			proParamIds.clear();
//			skuParamIds.clear();
//			if (selectCount == 1) {
//				proParamIds = proIds;
//				skuParamIds = skuIds;
//			} else {
//				if (a != selectCount) {
//					proParamIds.addAll(proIds.subList(12 * (a - 1), 12 * a));
//					skuParamIds.addAll(skuIds.subList(12 * (a - 1), 12 * a));
//				} else {
//					proParamIds.addAll(proIds.subList(12 * (a - 1), listSize));
//					skuParamIds.addAll(skuIds.subList(12 * (a - 1), listSize));
//				}
//			}
		List<GomeUnifiedPrice> priceResult = new ArrayList<>();
		List<PriceConditionVo> conditionList = new ArrayList<>();
		PriceConditionVo priceCondition = null;
		Map<String, String> infoMap = null;
		for(int i = 0; i < infoList.size(); i++) {
			infoMap = infoList.get(i);
			if(null != infoMap && !infoMap.isEmpty()) {
				for(Map.Entry<String, String> mm: infoMap.entrySet()) {
					priceCondition = new PriceConditionVo();
					priceCondition.setSkuId(mm.getKey());
					priceCondition.setProductId(mm.getValue());
					priceCondition.setChannel(channel);
					priceCondition.setPolicyId(policyId);
					
					conditionList.add(priceCondition);
				}
				
				List<GomeUnifiedPrice> priceRes = priceManager.getPrice(conditionList);
				if(null != priceRes && !priceRes.isEmpty()) {
					priceResult.addAll(priceRes);
				}
				conditionList.clear();
			}
//			List<GomeVipPriceItem> gomeVipPriceItems = iGomeVipPriceService.getVipPrices(proParamIds, skuParamIds, areaCode, channel);
//			if(null == gomeVipPriceItems || gomeVipPriceItems.size() == 0) continue;
//			meidianPrices.addAll(gomeVipPriceItems);
		}

		for (ProductGroupInfoVo productGroupInfoVo : productGroupInfoVos) {
			if(null == productGroupInfoVo) continue;
			ProductInfo productInfo = productGroupInfoVo.getProductInfo();
			if(null != productInfo){
				for (GomeUnifiedPrice priceItem : priceResult) {
					if(null == priceItem) continue;
					if(null!=priceItem.getSkuId()&&priceItem.getSkuId().equalsIgnoreCase(productInfo.getSkuId())){
						//单位：元，保留2位小数点
						Double fPrice = priceItem.getPrice();

						// 美店价
						if(null == fPrice){
							productInfo.setMeidianPrice(productInfo.getPrice());
						}else{
							productInfo.setMeidianPrice(DoubleUtils.switchScientificCalculate(fPrice));
							productInfo.setPriceType(priceItem.getPriceType());
						}

						// 单位转换，元变分
						Double price = DoubleUtils.mul(Double.valueOf(productInfo.getMeidianPrice()), 100d);
						// 折扣返利
						double rebatePrice = groupOrderManager.getRebateAmount(price.longValue(), productGroupInfoVo.getHomePageActivity().getMaxDiscount());
						if(null != productGroupInfoVo.getHomePageActivity())
							productGroupInfoVo.getHomePageActivity().setDiscountRebate(DoubleUtils.switchScientificCalculate(rebatePrice));

						// 处理美店价，国美价，当美店价大于国美价时，美店价赋值给国美价
						if(fPrice.doubleValue() > Double.valueOf(productInfo.getPrice()).doubleValue())
							productInfo.setPrice(DoubleUtils.switchScientificCalculate(fPrice));
						
						break;
					}
				}
			}else if(null != productGroupInfoVo.getHomeGroupProductActivityPage()){
				List<HomeProductActivity> homeProductActivities = productGroupInfoVo.getHomeGroupProductActivityPage().getHomeProductActivities();
				if(null == homeProductActivities || homeProductActivities.size() == 0) continue;
				for (HomeProductActivity homeProductActivity : homeProductActivities) {

					if(null == homeProductActivity) continue;
					ProductInfo proInfo = homeProductActivity.getProductInfo();
					if(null == proInfo) continue;

					for (GomeUnifiedPrice priceItem : priceResult) {
						if(null == priceItem) continue;
						if(priceItem.getSkuId().equalsIgnoreCase(proInfo.getSkuId())){
							Double mPrice = priceItem.getPrice();

							// 美店价
							if(null == mPrice){
								proInfo.setMeidianPrice(proInfo.getPrice());
							}else{
								proInfo.setMeidianPrice(DoubleUtils.switchScientificCalculate(mPrice));
								productInfo.setPriceType(priceItem.getPriceType());
							}

							// 单位转换，元变分
							Double price = DoubleUtils.mul(Double.valueOf(proInfo.getMeidianPrice()), 100d);
							// 折扣返利
							double rebPrice = groupOrderManager.getRebateAmount(price.longValue(), homeProductActivity.getHomePageActivity().getMaxDiscount());
							if(null != homeProductActivity.getHomePageActivity())
								homeProductActivity.getHomePageActivity().setDiscountRebate(DoubleUtils.switchScientificCalculate(rebPrice));

							// 处理美店价，国美价，当美店价大于国美价时，美店价赋值给国美价
							if(mPrice.doubleValue() > Double.valueOf(proInfo.getPrice()).doubleValue())
								proInfo.setPrice(DoubleUtils.switchScientificCalculate(mPrice));
							
							break;
						}
					}
				}
			}
		}
	}
	
	/**
	 * 美店定价降级处理
	 * @param productGroupInfoVos
	 */
	public void mDPrice(List<ProductGroupInfoVo> productGroupInfoVos){
		if(null != productGroupInfoVos && productGroupInfoVos.size() > 0){
			
			for (ProductGroupInfoVo productGroupInfoVo : productGroupInfoVos) {
				if(null == productGroupInfoVo) continue;
				ProductInfo productInfo = productGroupInfoVo.getProductInfo();
				if(null != productInfo)
					productInfo.setMeidianPrice(productInfo.getPrice());
				
				HomeGroupProductActivityPage homeGroupProductActivityPage = productGroupInfoVo.getHomeGroupProductActivityPage();
				if(null != homeGroupProductActivityPage){
					List<HomeProductActivity> homeProductActivities = homeGroupProductActivityPage.getHomeProductActivities();
					if(null != homeProductActivities && homeProductActivities.size() > 0){
						for (HomeProductActivity homeProductActivity : homeProductActivities) {
							if(null == homeProductActivity) continue;
							ProductInfo proInfo = homeProductActivity.getProductInfo();
							if(null == proInfo) continue;
							proInfo.setMeidianPrice(proInfo.getPrice());
						}
					}
				}
			}
		}
	}
	
	/**
	 * 美蓝劵转赠
	 * @param couponType
	 * @param couponId
	 * @param oldUserId
	 * @param newUserId
	 * @return
	 */
	public byte transitionBeautifulCoupon(String couponType, String couponId, String oldUserId, String newUserId){
		String uuid = UUID.randomUUID().toString().replace("-", "").toLowerCase();
		ChangeUserIdParam changeUserIdParam = new ChangeUserIdParam();
		changeUserIdParam.setCouponId(couponId);
		changeUserIdParam.setOldUserId(oldUserId);
		changeUserIdParam.setNewUserId(newUserId);
		// 美蓝劵转赠
		ResultDO<Boolean> result = fpBlueCouponService.changeUserIdByCouponIdOrTicketId(uuid, changeUserIdParam);
		if(!result.isSuccess()) {
			logger.error("transitionBeautifulCoupon ==> couponType=={} couponId=={} oldUserId=={} newUserId=={} ", couponType, couponId, oldUserId, newUserId);
			if(null != result.getErrCode() && result.getErrCode().equals("2")){
				return 2;
			}
			return 1;	
		}
		if(!result.getData()){
			logger.error("transitionBeautifulCoupon ==> couponType=={} couponId=={} oldUserId=={} newUserId=={} ", couponType, couponId, oldUserId, newUserId);
			return 1;	
		}
		
		return 0;
	}
	
	/**
	 * 获取商品的返利信息
	 * @param skuNo
	 * @param skuId
	 * @param areaCode
	 * @return
	 * @throws ServiceException
	 */
	public Double getgetBuyRebateOneInfo(String skuNo,String skuId,String areaCode,String channel,String mOrg,String policyId) throws ServiceException{
		String productId = null;
		//skuId  优先级高
		if(!StringUtils.isEmpty(skuId)){
			
			GoodsInfo  goodsInfo = JSONObject.parseObject(gcache.get("getgetBuyRebateOneInfo_getGoodsInfos_"+skuId), GoodsInfo.class) ;
			
			if(goodsInfo != null){
				productId = goodsInfo.getProductId();
				skuNo = goodsInfo.getSkuNo();
			}
			
			if(StringUtils.isEmpty(productId) || StringUtils.isEmpty(skuNo)){
				List<String> paramList = new ArrayList<String>();
				paramList.add(skuId);
				List<GoodsInfo> list = productInfoService.getGoodsInfos(paramList,"210");
				if(!CollectionUtils.isEmpty(list)){
					goodsInfo = list.get(0);
					if(goodsInfo != null){
						productId = goodsInfo.getProductId();
						skuNo = goodsInfo.getSkuNo();
						if(!StringUtils.isEmpty(productId) && !StringUtils.isEmpty(skuNo)){
							gcache.setex("getgetBuyRebateOneInfo_getGoodsInfos_"+skuId, 30 * 60, JSONUtils.toJSONString(goodsInfo).getBytes());
						}
					}
				}
			}


			return getBuyRebateOne(productId, skuId, areaCode, skuNo, channel, mOrg, policyId);
		}else if(!StringUtils.isEmpty(skuNo)){
			
			GoodsInfo goodsInfo = JSONObject.parseObject(gcache.get("getgetBuyRebateOneInfo_getGoodsInfosBySkuNo_"+skuNo), GoodsInfo.class) ;
			if(goodsInfo != null){
				productId = goodsInfo.getProductId();
				skuId = goodsInfo.getSkuId();
			}
			
			if(StringUtils.isEmpty(productId) || StringUtils.isEmpty(skuId)){
				List<String> skuNoList = new ArrayList<String>();
				skuNoList.add(skuNo);
				List<GoodsInfo> goodsList= productInfoService.getGoodsInfosBySkuNo(skuNoList, null);
				if(!CollectionUtils.isEmpty(goodsList)){
					goodsInfo = goodsList.get(0);
					if(goodsInfo != null){
						productId = goodsInfo.getProductId();
						skuId = goodsInfo.getSkuId();
						if(!StringUtils.isEmpty(productId) && !StringUtils.isEmpty(skuId)){
							gcache.setex("getgetBuyRebateOneInfo_getGoodsInfosBySkuNo_"+skuNo, 30 * 60, JSONUtils.toJSONString(goodsInfo).getBytes());
						}
					}
				}
			}

			return getBuyRebateOne(productId, skuId, areaCode, skuNo, channel, mOrg, policyId);
		}else{
			return 0d;
		}

	}
	
	/**
	 * 单个返利信息
	 * @param skuIdParam
	 * @param skuNoParam
	 * @param areaCode
	 * @return
	 * @throws ServiceException
	 */
	public Double getBuyRebateOne(String productId, String skuId, String areaCode,String skuNo,String channel,String mOrg,String policyId) throws ServiceException{

		if(StringUtils.isEmpty(productId) ||  StringUtils.isEmpty(skuNo) || StringUtils.isEmpty(skuId)){
			return 0d;
		}
		
		String price = null;
//		List<String> pidParams = new ArrayList<>();
//		List<String> skuIdParams = new ArrayList<>();
//		pidParams.add(productId);
//		skuIdParams.add(skuId);
//		List<GomeVipPriceItem> gomeVipPriceItems = iGomeVipPriceService.getVipPrices(pidParams, skuIdParams, areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
//	
//		if(null != gomeVipPriceItems || gomeVipPriceItems.size() >0 ){
//			GomeVipPriceItem gomeVipPriceItem = gomeVipPriceItems.get(0);
//			if(gomeVipPriceItem !=null){
//				Double finalPrice = gomeVipPriceItem.getFinalPrice();
//				if(finalPrice != null && finalPrice.doubleValue() != 0d ){
//					price = finalPrice.toString();
//				}
//			}
//		}
		
		//上边注释部分为老差价逻辑，以下为新查价逻辑 begin
    	PriceConditionVo condition = new PriceConditionVo();
    	condition.setChannel(channel);
    	condition.setPolicyId(policyId);
    	condition.setProductId(productId);
    	condition.setSkuId(skuId);
    	
		GomeUnifiedPrice GomeUnifiedPrice = priceManager.getPrice(condition);
		if(GomeUnifiedPrice != null ){
			Double finalPrice = GomeUnifiedPrice.getPrice();
			if(finalPrice != null && finalPrice.doubleValue() != 0d ){
				price = finalPrice.toString();
			}
		}
		//end
		
		if(StringUtils.isEmpty(productId) ||  StringUtils.isEmpty(skuNo) || StringUtils.isEmpty(price)){
			return 0d;
		}

		return getBuyRebate( productId,  skuNo,  areaCode,  price);

		
		
	}

}
