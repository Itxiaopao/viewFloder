package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.List;

/**
 * 用户足迹初始化
 * 
 * @author libinbin-ds
 *
 */
public class UserFootprintInit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2401628122925366268L;

	private GuestInfo guestInfo;	// 店主用户
	private List<UserFootprintInfo> footPrints;	// 用户足迹
	
	
	public GuestInfo getGuestInfo() {
		return guestInfo;
	}
	public void setGuestInfo(GuestInfo guestInfo) {
		this.guestInfo = guestInfo;
	}
	public List<UserFootprintInfo> getFootPrints() {
		return footPrints;
	}
	public void setFootPrints(List<UserFootprintInfo> footPrints) {
		this.footPrints = footPrints;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
