package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.store.Store;

public class Model implements Serializable{

	private static final long serialVersionUID = 8353948389820849713L;

	private PageProperty pageProperty;			// 页面属性
	private List<HomePageHead> homePageHeads;	// 头部导航
	private List<ModelVo> modelVos;				// 楼层
	private Store store;						// 首页门店信息
	
	public List<ModelVo> getModelVos() {
		return modelVos;
	}

	public void setModelVos(List<ModelVo> modelVos) {
		this.modelVos = modelVos;
	}

	public PageProperty getPageProperty() {
		return pageProperty;
	}

	public void setPageProperty(PageProperty pageProperty) {
		this.pageProperty = pageProperty;
	}

	public List<HomePageHead> getHomePageHeads() {
		return homePageHeads;
	}

	public void setHomePageHeads(List<HomePageHead> homePageHeads) {
		this.homePageHeads = homePageHeads;
	}

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}





	
}
