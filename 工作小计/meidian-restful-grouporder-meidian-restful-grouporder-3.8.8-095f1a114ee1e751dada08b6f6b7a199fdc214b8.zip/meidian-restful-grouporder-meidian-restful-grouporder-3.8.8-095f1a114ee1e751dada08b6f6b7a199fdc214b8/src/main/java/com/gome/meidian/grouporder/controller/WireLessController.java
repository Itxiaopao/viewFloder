package com.gome.meidian.grouporder.controller;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.UserAndRegisterRiskSwitchManager;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.utils.*;
import com.gome.meidian.grouporder.vo.wechatLogin.DoSNSLoginVO;
import com.gome.meidian.grouporder.vo.wechatLogin.WeChatOpenIdAndUserIdVO;
import com.gome.meidian.grouporder.vo.wechatLogin.WeChatUserInfo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.entity.UserRelation;
import com.gome.memberCore.lang.model.GomeSNSUser;
import com.gome.userCenter.common.constants.LoginConstants;
import com.gome.userCenter.facade.login.ISNSLoginFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UserInfo;
import com.gome.userCenter.model.UserLoginResult;
import com.gome.userCenter.model.enu.CompanyNameEnum;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Pattern;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * 无线接口对接
 *
 */
@RestController
@Validated
@RequestMapping("/v1/wireLess")
public class WireLessController {

	private Logger logger = LoggerFactory.getLogger(getClass());


	@Autowired
	private WechatLoginManager wechatLoginManager;




	/**
	 * 微商城获取微信用户关注信息接口说明
	 * @param url
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/user/subscribe", method = RequestMethod.POST)
	public ResponseJson userSubscribe(
			@NotBlank(message = "{param.error}") @RequestParam("url") String url,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=wechatLoginManager.handleShareToken(url);
		result.setData(object);
		return result;
	}


}
