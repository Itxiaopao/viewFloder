package com.gome.meidian.grouporder.utils;

import org.springframework.util.StringUtils;

public class StrUtils extends StringUtils{

	/**
	 * 匹配前几位字符
	 * @param st 原字符串
	 * @param matchingSt 要匹配的字符串
	 * @param subLength 匹配前几位
	 * @return
	 */
	public static boolean indexContains(String st, String matchingSt, int subLength){
		if(null != st && st.equals("")) return false;
		if(st.length() < subLength) return false;
		String s = st.substring(0, subLength);
		if(s.equals(matchingSt))
			return true;
		else 
			return false;
	}
	
}
