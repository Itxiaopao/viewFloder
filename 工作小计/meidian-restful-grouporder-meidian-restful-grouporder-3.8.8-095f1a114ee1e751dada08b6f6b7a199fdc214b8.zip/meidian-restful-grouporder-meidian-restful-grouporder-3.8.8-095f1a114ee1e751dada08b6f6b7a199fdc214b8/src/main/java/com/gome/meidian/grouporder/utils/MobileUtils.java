package com.gome.meidian.grouporder.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MobileUtils {
	
	//手机号合法性校验
	public static boolean isPhone(String phone) {
	    String regMobile = "^(13\\d{9}|14\\d{9}|15\\d{9}|16\\d{9}|17\\d{9}|18\\d{9}|19\\d{9})$";
	    if (phone.length() != 11) {
	        return false;
	    } else {
	        Pattern p = Pattern.compile(regMobile);
	        Matcher m = p.matcher(phone);
	        boolean isMatch = m.matches();
	        return isMatch;
	    }
	}
	
	//设定密码合法性校验
	public static boolean isPassword(String password) {
		if(password.length() < 6 || password.length() > 20){
	        return false;
	    }else{
	    	String regexZT = "[a-zA-Z~!@#$%^&*.]+";
    	    String regexZS = "[0-9A-Za-z]+";
    	    String regexST = "[\\d~!@#$%^&*.]*";
    	    String regexZST = "[\\da-zA-Z~!@#$%^&*.]+";
    	    if((password.matches(regexZT))||(password.matches(regexZS))||(password.matches(regexST))||(password.matches(regexZST))){
    	        return true;
    	    }else{
    	    	return false;
    	    }
	    }
	}
	
}
