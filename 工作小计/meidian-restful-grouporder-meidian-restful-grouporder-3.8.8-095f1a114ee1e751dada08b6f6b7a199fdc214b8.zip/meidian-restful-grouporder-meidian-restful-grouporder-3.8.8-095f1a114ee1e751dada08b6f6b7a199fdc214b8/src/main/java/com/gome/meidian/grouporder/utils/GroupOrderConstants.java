package com.gome.meidian.grouporder.utils;


/**
 * 常量
 * @author shichangjian
 *
 */
public class GroupOrderConstants {
	//通过门店code查询销售组织ID时storeType   数字门店
	public static final Integer 	GET_ORGCODE_BY_STORECODE_STORETYPE = 0;
	//价格请求策略ID
	public static final String PRICE_POLICYID = "IGUP0001";
	// 渠道来源
	public static final String CHANNEL_WAP = "WAP";
	public static final String CHANNEL_IOS_APP = "IOS";
	public static final String CHANNEL_ANDROID_APP = "Android";
	public static final String CHANNEL_MINI = "Mini";
	public static final int MEIDIAN_CMS_WAP = 1;
	public static final int MEIDIAN_CMS_IOS_APP = 4;
	public static final int MEIDIAN_CMS_ANDROID_APP = 3;
	public static final int MEIDIAN_CMS_MINI = 2;
	
	// 美店站点
	// 美店wap站点
	public static final String meidian_wap_site = "meidianWapSite";
	// 美店pc站点
	public static final String meidian_pc_site = "meidianPcSite";
	// 美店app站点
	public static final String meidian_app_site = "meidianMobileSite";
	// 美店小程序站点
	public static final String meidian_mini_site = "meidianMiniprogramSite";
	
	public static final int SUCCESS_CODE = 0;
	
	//非美店店主
	public static final String VHOP_OWNER_TYPE_NOT = "not";
	//普通美店店主
	public static final String VSHOP_OWNER_TYPE_NORMAL = "normal";
	//vip美店店主
	public static final String VSHOP_OWNER_TYPE_VIP = "vip";
	// 员工归属店接口入参
	public static final String USER_SHOP_INVOKEFROM = "gomeShop";
	
	
	
	public static final String ONE_IMAGE_SKIP = "1";		//单图不跳转
	public static final String ONE_IMAGE = "2";				//单图
	public static final String TWO_IMAGE = "3";				//双图
	public static final String THREE_IMAGE = "4";			//三图
	public static final String TWO_LINE_PRODUCT = "5";		//双列商品
	public static final String THREE_LINE_PRODUCT = "6";	//三列商品
	public static final String TAG_TWO_LINE_PRODUCT = "7";	//标签双列商品
	public static final String TAG_THREE_LINE_PRODUCT = "8";//标签三列商品
	public static final String ONE_COUPON = "9";			//单券
	public static final String MORE_COUPON = "10";			//多券轮播
	public static final String ONE_LINE_PRODUCT = "11";		//单列商品
	public static final String MORE_PRODUCT = "12";			//多商品轮播
	public static final String SIZE_THREE_IMAGE = "13";		//大小三图
	public static final String FOUR_IMAGE = "14";			//四图
	public static final String SIZE_FIVE_IMAGE = "15";		//大小五图（被底部导航占用）
	public static final String TYPE_NAVIGATION = "16";		//分类导航
	public static final String TYPE_LINE_PRODUCT_BACKGROUND = "17";	//单列商品背景图
	
	public static final int MEIDIAN_BANNER = 0;						// 轮播图模块
	public static final int MEIDIAN_ADVERT = 1;						// 广告图模块
	public static final int MEIDIAN_ICON = 2;						// Icon模块
	public static final int MEIDIAN_PICTURE = 3;					// 图片模块 *尺寸一致*
	public static final int MEIDIAN_COUPON_PRODUCT = 4;				// 立减(券)模块 *常规*，不分页
	public static final int MEIDIAN_GROUP_PRODUCT = 5;				// 组团模块 *常规*，不分页
	public static final int MEIDIAN_TEXT = 6;						// 文本模块
	public static final int MEIDIAN_HELP_PRODUCT = 7;				// 助力团模块【常规】
	public static final int MEIDIAN_PRODUCT = 9;					// 商品模块 *常规*，不分页
	public static final int MEIDIAN_BUYREBATE_PRODUCT = 10;			// 超级返 *常规*，不分页
	public static final int MEIDIAN_BOTTOM_NAVIGATION = 11;			// 底部导航,图片
	public static final int MEIDIAN_PLACEHOLDER = 13;				// 空占位模块
	public static final int MEIDIAN_COUPON = 14;					// 劵
	public static final int MEIDIAN_NAVIGATION = 15;				// 分类导航，锚点
	public static final int MEIDIAN_VIDEO = 16;						// 视频
	public static final int ZUTUAN_SOCI = 17;						// 社交组团[常规]
	public static final int MEIDIAN_PICTURE_LEFT_BIG = 301;			// 图片模块 *左 > 右*,左边一个大图，右边4个小图
	public static final int MEIDIAN_PICTURE_RIGHT_BIG = 302;		// 图片模块 *左 < 右*，左边4个小图，右边1个大图
	public static final int MEIDIAN_PICTURE_NOT_RULE = 303;			// 图片，没有规则
	public static final int MEIDIAN_SUSPEND_BUTTON = 18;			// 悬浮按钮
	public static final int MEIDIAN_GROUP_PRODUCTS_PAGE = 205;		// 组团模块 *底部瀑布流*，分页
	public static final int MEIDIAN_COUPON_PRODUCTS_PAGE = 206;		// 立减(券)模块 *底部瀑布流*，分页
	public static final int MEIDIAN_BUYREBATE_PRODUCT_PAGE = 207;	// 超级返 *底部瀑布流*，分页
	public static final int MEIDIAN_PRODUCT_PAGE = 208;				// 商品模块 *底部瀑布流*

	public static final int MEIDIAN_SURVEY_PAGE_A = 211;            // 热度调研商品我喜欢面模块 *底部瀑布流*，分页
	public static final int MEIDIAN_SURVEY_PAGE_B = 212;            // 热度调研商品我要卖页面模块 *底部瀑布流*，分页
	public static final int MEIDIAN_HELP_PRODUCTS_PAGE=213;			// 助力团【瀑布流】
	public static final int ZUTUAN_SOCI_BTM = 209;					// 社交组团[瀑布流]
	public static final int THOUSAND_GROUP_MATERIAL = 101;			// 万人团素材楼层
	public static final int ASSISTANCE_GROUP_MATERIAL = 102;		// 助力团素材楼层

	public static final int MEIDIAN_MERGE_MODEL = 1001;				// 合并楼层
	public static final int MEIDIAN_COLLECTFLOW = 21;				// 集客
	public static final int MEIDIAN_COLLECTFLOW_GROUP_PRODUCT = 22;	// 集客组团商品

	public static final int PARTITION_SOCI = 8;     				//瓜分团常规
	public static final int PARTITION_BTM = 214;     				//瓜分团瀑布流
	public static final int CMS_THOUSAND_GROUP_MATERIAL = 305;     	//cms万人团素材楼层
	public static final int CMS_ASSISTANCE_GROUP_MATERIAL = 306;    //cms助力团素材楼层
	public static final int ACTIVITY_MATERIAL = 308;    			//活动素材楼层
	public static final int COMMON_PRODUCT = 215;    			//普通商品瀑布流
	
	//单券商品更多推荐UK
	public static final String MORE_PRODUCT_UKEY = "morerecommend";
	
	//站点类型--wap
	public static final String SITE_TYPE_WAP = "wapsite";
	
	//领美券
	//领券结果-成功
	public static final Integer FETCH_COUPON_RESULT_SUCCESS = 0;	
	//领券结果-参数为空
	public static final Integer FETCH_COUPON_RESULT_NOPARAM = 1;		
	//领券结果-服务器繁忙
	public static final Integer FETCH_COUPON_RESULT_FAILED = 2;	
	//领券结果-活动信息获取失败
	public static final Integer FETCH_COUPON_RESULT_DATAERROR = 3;	
	//领券结果-结束
	public static final Integer FETCH_COUPON_RESULT_END = 4;	
	//领券结果-未开始
	public static final Integer FETCH_COUPON_RESULT_NOTSTART = 5;	
	//领券结果-已领完
	public static final Integer FETCH_COUPON_RESULT_NOCOUNT = 6;	
	//领券结果-用户无次数
	public static final Integer FETCH_COUPON_RESULT_USERNOCOUNT = 7;	
	//领券结果-用户信息获取失败
	public static final Integer FETCH_COUPON_RESULT_USEREXCEPTION = 8;	
	//领券结果-未绑定手机号
	public static final Integer FETCH_COUPON_RESULT_NOMOBILE = 9;	
	//领券结果-用户等级信息获取失败
	public static final Integer FETCH_COUPON_RESULT_GETGRADEEXCEPTION = 10;	
	//领券结果-会员等级不足
	public static final Integer FETCH_COUPON_RESULT_GRADELIMIT = 11;
	
	
	//领红蓝券
	//领券结果-成功
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_SUCCESS = 0;
	//领券结果-活动不存在
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_NOPROMID = 3;
	//领券结果-活动已结束
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_END = 4;
	//领券结果-活动未开始
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_NOSTART = 5;
	//领券结果-已发完
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_COUPONEMPTY = 6;
	//领券结果-没有可领取次数
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_USERNOCOUNT = 7;
	//领券结果-手机号未激活
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_NOMOBILE = 9;
	//领券结果-未登录
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_NOLOGIN = 12;
	//领券结果-点击过快
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_BUSY = 13;
	//领券结果-领取失败
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_FAILED = 14;
	//领券结果-编码无法识别
	public static final Integer FETCH_REDBLUE_COUPON_RESULT_FAILED_UNKONW = 15;
	
	//领POP券
	//领券结果-成功
	public static final Integer FETCH_POP_COUPON_RESULT_SUCCESS = 0;
	//领券结果-优惠券批次不存在
	public static final Integer FETCH_POP_COUPON_RESULT_NOTEXIT = 15;
	//领券结果-优惠券达到上限 
	public static final Integer FETCH_POP_COUPON_RESULT_END = 16;
	//领券结果-插入数据库失败
	public static final Integer FETCH_POP_COUPON_RESULT_NOSTART = 17;
	//领券结果-领券的Id不存在
	public static final Integer FETCH_POP_COUPON_RESULT_COUPONEMPTY = 18;
	//领券结果-用户领券已经达到上限
	public static final Integer FETCH_POP_COUPON_RESULT_USERNOCOUNT = 19;

	//领券结果--通用失败信息
	public static final Integer FETCH_COUPON_COMMON_FAIL_MSG = 14;
	//券类型
	//美券
	public static final String COUPON_TYPE_MEI = "3001";
	//蓝券
	public static final String COUPON_TYPE_BLUE = "3002";
	//红券
	public static final String COUPON_TYPE_RED = "3003";
	//营销劵
	public static final String COUPON_TYPE_MARKETING = "3005";
	
	//pop券 0：店铺劵(pop)   
	public static final String COUPON_TYPE_POP_SHOP = "0";
	//pop券 	2：pop-平台劵(pop)
	public static final String COUPON_TYPE_POP_PLATFORM = "2";
	// pop劵 3：商品劵
	public static final String COUPON_TYPE_POP_PRODUCT = "3";
	
	//cms劵类型
	public static final String COUPON_TYPE_CMS_BEAUTY = "1";
	public static final String COUPON_TYPE_CMS_POP = "2";
	
	// 自营
	public static final int PRODUCT_SELF_OPERATION = 1;
	// 联营
	public static final int PRODUCT_JOINT_OPERATION = 2;
	
	// 自营shopId默认值
	public static final String PRODUCT_SELF_DEFAULT_SHOPID_REBATE = "888";

	//风控抢券-业务场景号
	//美券
	public static final String BIZ_NO_WAP_COUPON_MEI = "WapMeidianMeiCoupon";
	//红券
	public static final String BIZ_NO_WAP_COUPON_RED = "WapMeidianRedCoupon";
	//蓝券
	public static final String BIZ_NO_WAP_COUPON_BLUE = "WapMeidianBlueCoupon";
	//店铺pop券
	public static final String BIZ_NO_WAP_COUPON_POP_SHOP = "WapMeidianShopCoupon";
	//平台pop券
	public static final String BIZ_NO_WAP_COUPON_POP_PLATFORM = "WapMeidianShopCoupon";
	//美店PC神券
	public static final String BIZ_NO_PC_COUPON_MARKET = "PCMeidianMarketCoupon";
	//美店Wap神券
	public static final String BIZ_NO_WAP_COUPON_MARKET = "WapMeidianMarketCoupon";
	//美店App神券
	public static final String BIZ_NO_APP_COUPON_MARKET = "AppMeidianMarketCoupon";
	//美店小程序神券
	public static final String BIZ_NO_MINI_COUPON_MARKET = "WeiXinMeidianMarketCoupon";
	
	
	// 美店价格渠道
	public static final String MEIDIANPRICE_CHANNEL = "MD";

	// 微信SCN延长时间
	public final static int GOME_SHOP_WECHAT_SCN_TIMEOUT = 7 * 24 * 60 *60;
	// 调用会员组公共参数  invokeFrom
	public final static String GOME_SHOP_INVOKE_FROM = "gomeShop";
	
	// 美店cms图片type
	public static final int MEIDIAN_CMS_IMAGE = 3;
	
	// 分辨率
	// 首页banner图
	public static final Byte HOME_BANNER_IMAGE = 1;
	// 单列商品图
	public static final Byte ONE_LIST_PRODUCT_IMAGE = 2;
	// 双列商品图
	public static final Byte TWO_LIST_PRODUCT_IMAGE = 3;
	// 商详页主图
	public static final Byte DETAILS_PRODUCT_IMAGE = 4;
	// 单劵商品详情页
	public static final Byte ONE_COUPON_DETAILS_PRODUCT_IMAGE = 5;
	// 主页列表中的专题活动页
	public static final Byte HOME_ACTIVITY_PRODUCT_IMAGE = 6;
	// 团详情页主商品图
	public static final Byte GROUP_DETAILS_HOME_PRODUCT_IMAGE = 7;
	
	// 团类型
	// 集客团
	public static final byte GROUP_FLOW_TYPE = 14;		// 集客0折
	// 0折团
	public static final byte GROUP_ZERO_TYPE = 3;
	// 渠道社区团
	public static final int GROUP_CHANNEL_TYPE = 16;	// 社区0折
	public static final int common_group = 1;			// 常规返利
	public static final int commander_free_group = 2;	// 团长免单
	public static final int free_group = 3;				// 0元团
	public static final int official_group = 5;			// 官方多人团
	public static final int earnest_group = 7;			// 定金团
	public static final int presell_group = 15;			// 预售团
//	1:常规返利,2:团长免单,3:0元团,4:开团有奖,5:官方多人团,6:5折开团,7:定金团,8:阶梯优惠团,9:新人团,10:秒杀团，11：100人5折团 12： 6人5折团 13： 50人5折团 14： 集客团 15： 预售团

	public static final int GROUP_FLOW_COMMON = 17;		// 集客普通
	public static final int GROUP_COMMUNITY_COMMON = 18;// 社区普通
	
	//节能优惠站点
	public static final String ENERGY_SAVING_SUBSIDIES_MEIDIAN_SITE = "meidianSite";
}
