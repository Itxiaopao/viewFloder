package com.gome.meidian.grouporder.manager;

import com.alibaba.fastjson.JSONObject;
import com.gome.coupon.model.cartBean.CouponBatchResult;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.carveUp.CarveUpCouponVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpActivity.CarveUpActivityInfoVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpActivity.CarveUpBaseActivityInfoVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpActivity.CarveUpRankActivityInfoVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpDetail.CarveUpDetailBaseVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpDetail.CarveUpDetailRankVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpDetail.CarveUpDetailVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpInfo.*;
import com.gome.meidian.grouporder.vo.carveUp.myCarveUpList.CarveUpBaseGroupVo;
import com.gome.meidian.grouporder.vo.carveUp.myCarveUpList.CarveUpGroupVo;
import com.gome.meidian.grouporder.vo.carveUp.myCarveUpList.CarveUpRankGroupVo;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.Partition;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppCarveResource;
import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;
import com.gomeplus.bs.interfaces.gorder.vo.carve.*;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import redis.Gcache;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 瓜分团manager
 */
@Service
public class CarveUpManager {
    @Autowired
    private GorderInfoForAppCarveResource gorderInfoForAppCarveResource;
    @Autowired
    private GroupOrderManager groupOrderManager;
    @Autowired
    private PageInfoResource pageInfoResource;


//    @Resource(name = "venusVshop")
//    private Gcache venusVshopGcache;
//    private String vshopKey = "vshop:vshopInfo_userId:";
    @Autowired
    private VshopFacade vshopFacade;
    
    @Value(value="${meidian.image.userImage}")
    private String ratio;

    public List<CarveUpActivityInfoVo> carveUpActivityList(String storeCode, String moduleCode, String pageCode, Long pageNo, Long pageSize, Long userId, Integer ppi, Byte ua){
        List<Partition> list = pageInfoResource.modulePartitionList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        if(null == list || list.isEmpty()) return null;
        return this.carveUpGroupList(list, userId, ppi, ua);
    }
    /**
     * 瓜分团活动列表
     * @param partitions  CMS获取的瓜分团数据
     * @param userId  用来判断是否是美店主
     * @return
     */
    public List<CarveUpActivityInfoVo> carveUpGroupList(List<Partition> partitions, Long userId, Integer ppi, Byte ua) {

        //非美店主返回空
//        String userKey = vshopKey + userId;
//        VshopInfo vshopInfo = JSONObject.parseObject(venusVshopGcache.get(userKey), VshopInfo.class);
//        if(null == vshopInfo || vshopInfo.getVshopId() <= 0){
//            return null;
//        }
    	CommonResultEntity<VshopInfo> vshop = vshopFacade.queryVshopByuserId(userId.toString());
        if(null == vshop || null == vshop.getBusinessObj()) {
        	return null;
        }

        List<CarveUpActivityInfoVo> carveActivityList = null;
        if(null != partitions && partitions.size() > 0){
            //组合查询的ids
            List<Long> ids = new ArrayList<>();
            for(Partition p: partitions){
                if(StringUtils.isNotBlank(p.getActivityCode())){
                    ids.add(Long.parseLong(p.getActivityCode()));
                }
            }
            
            //查询活动列表
            CommonResultEntity<List<GroupCarveActivityInfoResourceVo>> result = gorderInfoForAppCarveResource.getCraveActivityInfoByIds(ids);
            if(null != result && result.isSuccess()){
                List<GroupCarveActivityInfoResourceVo> resultList = result.getBusinessObj();
                if(null != resultList && resultList.size() > 0){
                	CarveUpBaseActivityInfoVo baseInfo = null;
                	CarveUpRankActivityInfoVo rankInfo = null;


//                    CarveUpCouponVo initCoupon = null;
//                    CarveUpCouponVo attendCoupon = null;
//                    CarveUpCouponVo rankCoupon = null;

                    carveActivityList = new ArrayList<>();

                    // 获取分辨率
                    String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
                    for(GroupCarveActivityInfoResourceVo vo: resultList){
                    	//TODO  解决double的精度问题    这是只是暂时做下兼容  等服务端改正后去除
                    	if(null != vo.getInitialFixMoney()) {
                        	vo.setInitialFixMoney(DoubleUtils.round(vo.getInitialFixMoney(), 2));
                    	}
                    	
                    	
                        //开团人券信息
//                        initCoupon = this.getCarveUpCoupon(vo.getAttendBondType(), vo.getAttendBondBatchNo(), vo.getAttendBondSchemeId(), vo.getAttendPageCode());
                        //参团人券信息
//                        attendCoupon = this.getCarveUpCoupon(vo.getInitialBondType(), vo.getInitialBondBatchNo(), vo.getInitialBondSchemeId(), vo.getInitialPageCode());

                        //基础团
                        if(1 == vo.getCarveGroupType()){
                            baseInfo = new CarveUpBaseActivityInfoVo();
                            BeanUtils.copyProperties(vo, baseInfo);

                            baseInfo.setStartTime(vo.getStartTime().getTime());
                            baseInfo.setEndTime(vo.getEndTime().getTime());

//                            baseInfo.setInitCoupon(Arrays.asList(initCoupon));
//                            baseInfo.setAttendCoupon(Arrays.asList(attendCoupon));

                            baseInfo.setImageUrl(ImageUtils.imageUrlInfo(baseInfo.getImageUrl(), ratio, ua));
                            
                            carveActivityList.add(baseInfo);
                        }

                        //排名团
                        if(2 == vo.getCarveGroupType() || 3 == vo.getCarveGroupType()){
                            rankInfo = new CarveUpRankActivityInfoVo();
                            BeanUtils.copyProperties(vo, rankInfo);

                            rankInfo.setStartTime(vo.getStartTime().getTime());
                            rankInfo.setEndTime(vo.getEndTime().getTime());

//                            rankInfo.setInitCoupon(Arrays.asList(initCoupon));
//                            rankInfo.setAttendCoupon(Arrays.asList(attendCoupon));

                            //排名团券信息
//                            rankCoupon = this.getCarveUpCoupon(vo.getRankBondType(), vo.getRankBondBatchNo(), vo.getRankBondSchemeId(), vo.getRankPageCode());
//                            rankInfo.setRankCoupon(Arrays.asList(rankCoupon));

                            rankInfo.setImageUrl(ImageUtils.imageUrlInfo(rankInfo.getImageUrl(), ratio, ua));
                            
                            //团长奖励计算
//                            if(null != rankInfo.getCarveBaseNum() && rankInfo.getCarveBaseNum().intValue() > 0 && null != rankInfo.getInitialFixMoney() && rankInfo.getInitialFixMoney().doubleValue() > 0) {
//                            	rankInfo.setInitialFixMoney(DoubleUtils.mul(rankInfo.getInitialFixMoney(), rankInfo.getCarveBaseNum().doubleValue() -1));
//                            }
                            
                            List<CarveRankAwardVo> carveRankAwardList = vo.getCarveRankAwardList();
                            if(null != carveRankAwardList && carveRankAwardList.size() > 0) {
                            	for(CarveRankAwardVo award: carveRankAwardList) {
                            		if(null != award.getRanking() && award.getRanking().intValue() == 1) {
                            			rankInfo.setLeaderMoney(award.getLeaderMoney());
                            			rankInfo.setTotalCarveMoney(award.getTotalCarveMoney()-award.getLeaderMoney());
                            			break;
                            		}
                            	}
                            }
                            carveActivityList.add(rankInfo);
                        }
                    }
                }
            }
        }
        return carveActivityList;
    }

    /**
     * 开团详情页
     * @param carveId
     * @param userId
     * @return
     */
    public CarveUpDetailVo carveUpGroupDetail(Long carveId, Long userId) {
        //非美店主返回空
//        String userKey = vshopKey + userId;
//        VshopInfo vshopInfo = JSONObject.parseObject(venusVshopGcache.get(userKey), VshopInfo.class);
//        if(null == vshopInfo || vshopInfo.getVshopId() <= 0){
//            return null;
//        }
    	  CommonResultEntity<VshopInfo> vshop = vshopFacade.queryVshopByuserId(userId.toString());
          if(null == vshop || null == vshop.getBusinessObj()) {
          	return null;
          }
        
    	CarveUpDetailVo carveDetail = null;
    	CommonResultEntity<GroupCarveActivityInfoResourceVo> result = gorderInfoForAppCarveResource.getCraveOpenGroupDetail(carveId, userId);
    	if(null != result && result.isSuccess()) {
    		GroupCarveActivityInfoResourceVo resource = result.getBusinessObj();
    		if(null != resource) {

            	//TODO  解决double的精度问题    这是只是暂时做下兼容  等服务端改正后去除
            	if(null != resource.getInitialFixMoney()) {
            		resource.setInitialFixMoney(DoubleUtils.round(resource.getInitialFixMoney(), 2));
            	}
            	
            	if(null != resource.getLeaderUserAward()) {
            		resource.setLeaderUserAward(DoubleUtils.round(resource.getLeaderUserAward(), 2));
            	}
                //券信息
//                CarveUpCouponVo attendCoupon = this.getCarveUpCoupon(resource.getAttendBondType(), resource.getAttendBondBatchNo(), resource.getAttendBondSchemeId(), resource.getAttendPageCode());
//                CarveUpCouponVo initCoupon = this.getCarveUpCoupon(resource.getInitialBondType(), resource.getInitialBondBatchNo(), resource.getInitialBondSchemeId(), resource.getInitialPageCode());
                
                if(resource.getCarveGroupType() == 1) {
                	carveDetail = new CarveUpDetailBaseVo();
                	BeanUtils.copyProperties(resource, carveDetail);
                	
//                	((CarveUpDetailBaseVo)carveDetail).setInitCoupon(Arrays.asList(initCoupon));
//                	((CarveUpDetailBaseVo)carveDetail).setAttendCoupon(Arrays.asList(attendCoupon));
                	
                	((CarveUpDetailBaseVo)carveDetail).setInitialFixMoney(resource.getLeaderUserAward());
                }
                
                if(resource.getCarveGroupType() == 2 || resource.getCarveGroupType() == 3) {
                	carveDetail = new CarveUpDetailRankVo();
                	BeanUtils.copyProperties(resource, carveDetail);
                	
//                	((CarveUpDetailRankVo)carveDetail).setInitCoupon(Arrays.asList(initCoupon));
//                	((CarveUpDetailRankVo)carveDetail).setAttendCoupon(Arrays.asList(attendCoupon));
//
//                    CarveUpCouponVo rankCoupon = this.getCarveUpCoupon(resource.getRankBondType(), resource.getRankBondBatchNo(), resource.getRankBondSchemeId(), resource.getRankPageCode());
//                	((CarveUpDetailRankVo)carveDetail).setRankCoupon(Arrays.asList(rankCoupon));

                	((CarveUpDetailRankVo)carveDetail).setInitialFixMoney(resource.getLeaderUserAward());
                    List<CarveRankAwardVo> carveRankAwardList = resource.getCarveRankAwardList();
                    if(null != carveRankAwardList && carveRankAwardList.size() > 0) {
                    	for(CarveRankAwardVo award: carveRankAwardList) {
                    		if(null != award.getRanking() && award.getRanking().intValue() == 1) {
                    			((CarveUpDetailRankVo)carveDetail).setLeaderMoney(award.getLeaderMoney());
                    			break;
                    		}
                    	}
                    }
                }
                
                if(null != carveDetail) {
                	carveDetail.setGroupResidueNum(resource.getUserGroupResidueNum());
                    if(null != resource.getStartTime()) {
                        carveDetail.setStartTime(resource.getStartTime().getTime());
                    }
                    if(null != resource.getEndTime()) {
                        carveDetail.setEndTime(resource.getEndTime().getTime());
                    }

                    Long surplusTime = carveDetail.getEndTime() - System.currentTimeMillis();
                    if(surplusTime >= 0) {
                    	carveDetail.setSurplusTime(surplusTime);
                    }
                    
                    CommonResultEntity<List<String>> marquee = gorderInfoForAppCarveResource.getCarveMarquee(carveId, 10);
                    if(null != marquee && null != marquee.getBusinessObj()) {
                    	carveDetail.setMarquee(marquee.getBusinessObj());
                    }
                }
                

    		}
    	}
    	return carveDetail;
    }
    
    /**
     * 我的瓜分团
     * @param userId
     * @param state
     * @param pageSize
     * @param pageNum
     * @return
     */
    public List<CarveUpGroupVo> myCarveUpGroupList(Long userId, Integer state, Integer pageSize, Integer pageNum) {
        List<CarveUpGroupVo> list = null;
        CommonResultEntity<MyGroupCarveMemberListVo> result = gorderInfoForAppCarveResource.getMyCraveOrderList(userId, state, pageNum, pageSize);
        if (null != result && result.isSuccess()) {
            MyGroupCarveMemberListVo listVo = result.getBusinessObj();
            List<MyGroupCarveMemberVo> memberList = listVo.getMemberList();
            if (null != memberList && memberList.size() > 0) {
                list = new ArrayList<>();

                CarveUpBaseGroupVo baseGroup = null;
                CarveUpRankGroupVo rankGroup = null;

//                CarveUpCouponVo initCoupon = null;
//                CarveUpCouponVo attendCoupon = null;
//                CarveUpCouponVo rankCoupon = null;

                for (MyGroupCarveMemberVo mem : memberList) {
                	//TODO  解决double的精度问题    这是只是暂时做下兼容  等服务端改正后去除
                	if(null != mem.getInitialFixMoney()) {
                		mem.setInitialFixMoney(DoubleUtils.round(mem.getInitialFixMoney(), 2));
                	}
                    //开团人券信息
//                    initCoupon = this.getCarveUpCoupon(mem.getAttendBondType(), mem.getAttendBondBatchNo(), mem.getAttendBondSchemeId(), mem.getAttendPageCode());
                    //参团人券信息
//                    attendCoupon = this.getCarveUpCoupon(mem.getInitialBondType(), mem.getInitialBondBatchNo(), mem.getInitialBondSchemeId(), mem.getInitialPageCode());

                    //基础团
                    if (mem.getCarveGroupType() == 1) {
                        baseGroup = new CarveUpBaseGroupVo();
                        BeanUtils.copyProperties(mem, baseGroup);

                        baseGroup.setStartTime(mem.getStartTime().getTime());
                        baseGroup.setEndTime(mem.getEndTime().getTime());

//                        baseGroup.setInitCoupons(Arrays.asList(initCoupon));
//                        baseGroup.setAttendCoupons(Arrays.asList(attendCoupon));

                        if(null != baseGroup.getSurplusTime() && baseGroup.getSurplusTime() < 0) {
                        	baseGroup.setSurplusTime(null);
                        }
                        
                        
                        list.add(baseGroup);
                    }

                    //排名团
                    if (mem.getCarveGroupType() == 2 || mem.getCarveGroupType() == 3) {
                        rankGroup = new CarveUpRankGroupVo();
                        BeanUtils.copyProperties(mem, rankGroup);

                        rankGroup.setStartTime(mem.getStartTime().getTime());
                        rankGroup.setEndTime(mem.getEndTime().getTime());

//                        rankGroup.setInitCoupons(Arrays.asList(initCoupon));
//                        rankGroup.setAttendCoupons(Arrays.asList(attendCoupon));

                        //排名团券信息
//                        rankCoupon = this.getCarveUpCoupon(mem.getRankBondType(), mem.getRankBondBatchNo(), mem.getRankBondSchemeId(), mem.getRankPageCode());
//                        rankGroup.setRankCoupons(Arrays.asList(rankCoupon));

                        if(null != rankGroup.getSurplusTime() && rankGroup.getSurplusTime() < 0) {
                        	rankGroup.setSurplusTime(null);
                        }
                        
                        //团长奖励计算
                        if(null != rankGroup.getCarveBaseNum() && rankGroup.getCarveBaseNum().intValue() > 0 && null != rankGroup.getInitialFixMoney() && rankGroup.getInitialFixMoney().doubleValue() > 0) {
                            rankGroup.setInitialFixMoney(DoubleUtils.mul(rankGroup.getInitialFixMoney(), rankGroup.getCarveBaseNum().doubleValue() -1));
                        }
                        
                        //进行中排名奖励显示冠军
                        if(rankGroup.getCarveOrderStatus() == 1) {
                            List<CarveRankAwardVo> carveRankAwardList = mem.getCarveRankAwardList();
                            if(null != carveRankAwardList && carveRankAwardList.size() > 0) {
                            	for(CarveRankAwardVo award: carveRankAwardList) {
                            		if(null != award.getRanking() && award.getRanking().intValue() == 1) {
                            			rankGroup.setLeaderMoney(award.getLeaderMoney());
//                            			rankGroup.setTotalCarveMoney(award.getTotalCarveMoney()-award.getLeaderMoney());
                            			rankGroup.setTotalCarveMoney(DoubleUtils.sub(award.getTotalCarveMoney(), award.getLeaderMoney()));
                            			break;
                            		}
                            	}
                            }else {
                            	//兼容一期
                            	if(mem.getRankFixMoney() > 0) {
                        			rankGroup.setLeaderMoney(mem.getRankFixMoney());
                        			rankGroup.setTotalCarveMoney(mem.getRankFixMoney());
                            	}else if(mem.getRankTotalMoney() > 0) {
                        			rankGroup.setLeaderMoney(mem.getRankTotalMoney());
                        			rankGroup.setTotalCarveMoney(mem.getRankTotalMoney());
                            	}else {
                        			rankGroup.setLeaderMoney(0D);
                        			rankGroup.setTotalCarveMoney(0D);
                            	}
                            }
                        }
                        
                        //已结束排名奖励显示获得的
                        if(rankGroup.getCarveOrderStatus() == 2 || rankGroup.getCarveOrderStatus() == 3) {
                    		rankGroup.setLeaderMoney(mem.getLeaderUserAward());
                    		rankGroup.setTotalCarveMoney(mem.getRankUserReward());
//                        	//进入榜单
//                        	if(null != mem.getLeaderUserAward() || null != mem.getRankUserReward()) {
//                        		rankGroup.setLeaderMoney(mem.getLeaderUserAward());
//                        		rankGroup.setTotalCarveMoney(mem.getRankUserReward());
//                        	}
//                        	//未进入榜单显示基础奖励
//                        	if(null == mem.getLeaderUserAward() && null == mem.getRankUserReward()) {
//                        		rankGroup.setLeaderMoney(rankGroup.getInitialFixMoney());
//                        		rankGroup.setTotalCarveMoney(rankGroup.getAttendFixMoney());
//                        	}
                        }
                        list.add(rankGroup);
                    }

                }
            }
        }
        return list;
    }

    /**
     * 瓜分团详情
     * @param userId
     * @param groupId
     * @return
     */
    public CarveUpInfoVo carveUpGroupInfo(Long userId, Long groupId, Integer ppi, Byte ua) {
        CarveUpInfoVo carve = null;
        MyGroupCarveInfoVo carveInfo = this.getCarveGroupInfo(userId, groupId);
        if (null != carveInfo) {

        	//TODO  解决double的精度问题    这是只是暂时做下兼容  等服务端改正后去除
        	if(null != carveInfo.getInitialFixMoney()) {
        		carveInfo.setInitialFixMoney(DoubleUtils.round(carveInfo.getInitialFixMoney(), 2));
        	}
            //券信息
            CarveUpCouponVo attendCoupon = this.getCarveUpCoupon(carveInfo.getAttendBondType(), carveInfo.getAttendBondBatchNo(), carveInfo.getAttendBondSchemeId(), carveInfo.getAttendPageCode());
            CarveUpCouponVo initCoupon = this.getCarveUpCoupon(carveInfo.getInitialBondType(), carveInfo.getInitialBondBatchNo(), carveInfo.getInitialBondSchemeId(), carveInfo.getInitialPageCode());

            //基础团信息
            if(carveInfo.getCarveGroupType() == 1){
                carve = new CarveUpBaseInfoVo();
                BeanUtils.copyProperties(carveInfo, carve);
                if(initCoupon != null) {
                    ((CarveUpBaseInfoVo)carve).setInitCoupon(Arrays.asList(initCoupon));
                }
                if(attendCoupon != null) {
                    ((CarveUpBaseInfoVo)carve).setAttendCoupon(Arrays.asList(attendCoupon));
                }
            }

            //排名团信息
            if(carveInfo.getCarveGroupType() ==2 || carveInfo.getCarveGroupType() == 3){
                carve = new CarveUpRankInfoVo();
                BeanUtils.copyProperties(carveInfo, carve); 
                if(initCoupon != null) {
                    ((CarveUpRankInfoVo)carve).setInitCoupon(Arrays.asList(initCoupon));
                }
                if(attendCoupon != null) {
                    ((CarveUpRankInfoVo)carve).setAttendCoupon(Arrays.asList(attendCoupon));
                }

                CarveUpCouponVo rankCoupon = this.getCarveUpCoupon(carveInfo.getRankBondType(), carveInfo.getRankBondBatchNo(), carveInfo.getRankBondSchemeId(), carveInfo.getRankPageCode());
                if(rankCoupon != null) {
                    ((CarveUpRankInfoVo)carve).setRankCoupons(Arrays.asList(rankCoupon));
                }
                
                
                Map<String, Integer> map = this.getRankNeedPeople(carve.getCarveBaseNum(), carve.getCurrentMemberNum(), carve.getCarveMinNewNum(), carve.getNewUserNum());
                if(null != map) {
                	((CarveUpRankInfoVo)carve).setNeedNewNum(map.get("needNewNum"));
                	((CarveUpRankInfoVo)carve).setNeedTotalNum(map.get("needTotalNum"));
                }
                ((CarveUpRankInfoVo)carve).setLeaderMoney(carveInfo.getLeaderUserAward());
                if(null != carveInfo.getTotalCarveMoney() && null != carveInfo.getLeaderUserAward()) {
                    ((CarveUpRankInfoVo)carve).setTotalCarveMoney(carveInfo.getTotalCarveMoney() - carveInfo.getLeaderUserAward());
                }
                
                List<CarveRankAwardVo> list = ((CarveUpRankInfoVo)carve).getCarveRankAwardList();
                if(null != list && list.size() > 0) {
                	for(CarveRankAwardVo vl: list) {
                		vl.setTotalCarveMoney(DoubleUtils.sub(vl.getTotalCarveMoney(), vl.getLeaderMoney()));
                	}
                }
            }
            
            List<GroupUserInfo> memberList = carve.getMemberList();
            if(null != memberList && memberList.size() > 0) {
            	for(GroupUserInfo user: memberList) {
            		user.setImage(this.imageConvertURL(user.getImage()));
            	}
            }
            
            carve.setImage(this.imageConvertURL(carve.getImage()));
            
            // 获取分辨率
//            String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
//            carve.setImageUrl(ImageUtils.imageUrlInfo(carve.getImageUrl(), ratio, ua));
            carve.setStartTime(carveInfo.getStartTime().getTime());
            carve.setEndTime(carveInfo.getEndTime().getTime());
            carve.setGroupStartTime(carveInfo.getGroupStartTime().getTime());
            carve.setGroupEndTime(carveInfo.getGroupEndTime().getTime());
            carve.setUserId(userId);
            
            carve.setUserUnusedAttendNum(carveInfo.getUserUnUsedAttendNum());
//            if(carveInfo.getCarveLimitNum() != null && carveInfo.getUserUsedAttendNum() != null) {
//            	carve.setUserUnusedAttendNum(carveInfo.getCarveLimitNum() - carveInfo.getUserUsedAttendNum() < 0 ? 0 : carveInfo.getCarveLimitNum() - carveInfo.getUserUsedAttendNum());
//            }
            
            Long surplusTime = carve.getGroupEndTime() - System.currentTimeMillis();
            if(surplusTime >= 0) {
                carve.setSurplusTime(surplusTime);
            }

            CommonResultEntity<List<String>> marquee = gorderInfoForAppCarveResource.getCarveMarquee(carve.getCarveId(), 10);
            if(null != marquee && null != marquee.getBusinessObj()) {
            	carve.setMarquee(marquee.getBusinessObj());
            }
            
            //奖励
            CommonResultEntity<List<GroupCarveRewardVo>> reward = gorderInfoForAppCarveResource.getUserRewardByGroupId(userId, groupId);
            List<CarveUpRewardVo> rdList = null;
            if(null != reward && reward.isSuccess()){
                List<GroupCarveRewardVo> rewardList = reward.getBusinessObj();
                if(null != rewardList && rewardList.size() > 0){
                    rdList = new ArrayList<>();
                    CarveUpRewardVo rdVo = null;
                    CarveUpCouponVo rdCoupon = null;
                    for(GroupCarveRewardVo rd: rewardList){
                        rdVo = new CarveUpRewardVo();
                        rdVo.setType(rd.getType());
                        rdVo.setMoney(rd.getMoney());
                        rdVo.setStatus(rd.getStatus());
                        rdCoupon = this.getCarveUpCoupon(rd.getBondType(), rd.getBondBatchNo(), rd.getBondSchemeId(), rd.getPageCode());
                        if(rdCoupon != null) {
                            rdVo.setCoupon(Arrays.asList(rdCoupon));
                        }

                        rdList.add(rdVo);
                    }
                    carve.setRewards(rdList);
                }
            }

//            //统计信息
//            CommonResultEntity<Map<String,Object>> statistics = gorderInfoForAppCarveResource.getCraveGroupTotalByActivityId(carveInfo.getCarveId());
//            if(null != statistics && statistics.isSuccess()){
//                Map<String, Object> map = statistics.getBusinessObj();
//                if(null != map){
//                    //已成功团数
//                    if(map.containsKey("carveNum")){
//                        if(NumberUtils.isNumber(map.get("carveNum").toString())){
//                            carve.setCarveNum(Integer.parseInt(map.get("carveNum").toString()));
//                        }
//                    }
//
//                    //已成功瓜分金额
//                    if(map.containsKey("carveMoney")){
//                        if(NumberUtils.isNumber(map.get("carveMoney").toString())){
//                            carve.setCarveMoney(MapUtils.getDouble(map, "carveMoney"));
//                        }
//                    }
//                }
//            }

//            //是否已助力参团
//            if(userId.equals(carve.getHeaderUserId())){
//                //自己不能给自己助力
//                carve.setHelped(true);
//            }else{
//                carve.setHelped(false);
//
//                if(null != carve.getMemberList() && carve.getMemberList().size() > 0){
//                    for(GroupUserInfo user: carve.getMemberList()){
//                        if(null != user && userId.equals(user.getUserId())){
//                            carve.setHelped(true);
//                            break;
//                        }
//                    }
//                }
//            }


        }

        return carve;
    }

    /**
     * 开团/参团
     *
     * @param userId  参团人userId
     * @param carveId 瓜分团活动ID
     * @param groupId 团ID
     * @return
     * @throws ServiceException
     */
    public Map<String, Object> attendCarveUpGroup(Long userId, Long carveId, Long groupId) throws ServiceException {
        /**
         * 开团：groupId为空
         * 参团：groupId必填
         */
        if (null != groupId) {
            //参团者不能参与自己开的团
            MyGroupCarveInfoVo carveInfo = this.getCarveGroupInfo(userId, groupId);
            if (null != carveInfo) {
                Long headUserId = carveInfo.getHeaderUserId();
                if (userId.longValue() == headUserId.longValue()) {
                    throw new ServiceException("gorder.carveup.attend.joinself");
                }
            } else {
                throw new ServiceException("gorder.carveup.group.notFound");
            }
        }else{
            //开团验证美店主身份
//            String userKey = vshopKey + userId;
//            VshopInfo vshopInfo = JSONObject.parseObject(venusVshopGcache.get(userKey), VshopInfo.class);
//            if(null == vshopInfo || vshopInfo.getVshopId() <= 0){
//                throw new ServiceException("gorder.carveup.attend.validFail");
//            }
        	  CommonResultEntity<VshopInfo> vshop = vshopFacade.queryVshopByuserId(userId.toString());
              if(null == vshop || null == vshop.getBusinessObj()) {
            	  throw new ServiceException("gorder.carveup.attend.validFail");
              }
        }
        
        Map<String, Object> resultMap = new HashMap<>();
        CommonResultEntity<GroupCarveInfoVo> result = gorderInfoForAppCarveResource.attendCarveGroup(userId, groupId, carveId);
        if (result != null) {
       	 if(result.getCode() == 0) {
    		 resultMap.put("result", true);
    		 if(null != result.getBusinessObj()) {
    			 CarveUpInfoVo car = new CarveUpInfoVo();
    			 BeanUtils.copyProperties(result.getBusinessObj(), car);
        		 resultMap.put("info", car);
    		 }
    	 }else {
    		 resultMap.put("result", false);
    		 resultMap.put("message", result.getMessage());
    	 }
    	 return resultMap;
        } else {
            throw new ServiceException("gorder.carveup.attend.fail");
        }
    }

    /**
     * 榜单信息
     * @param userId
     * @param groupId
     * @param pageNum
     * @param pageSize
     * @return
     */
    public CarveUpBoardVo rankGroupInfo(Long userId, Long groupId, Integer pageNum, Integer pageSize){
        CarveUpBoardVo board = null;
        MyGroupCarveInfoVo carveInfo = this.getCarveGroupInfo(userId, groupId);
        if(null != carveInfo){
        	if(carveInfo.getCarveGroupType() == 1) {
        		return board;
        	}
            board = new CarveUpBoardVo();
            BeanUtils.copyProperties(carveInfo, board);

//            board.setCarveGroupRewardNum(carveInfo.getRankGroupRewardNum());
//            board.setStartTime(carveInfo.getStartTime().getTime());
//            board.setEndTime(carveInfo.getEndTime().getTime());

//            board.setRankCoupons(Arrays.asList(this.getCarveUpCoupon(carveInfo.getRankBondType(), carveInfo.getRankBondBatchNo(), carveInfo.getRankBondSchemeId(), carveInfo.getRankPageCode())));

            //我开的团、我参的团
            MyCarveUpGroupVo tempVo = null;
            CommonResultEntity<MyCarveGroupListVo> listVo = gorderInfoForAppCarveResource.getMyAttendCraveGroupList(userId, board.getCarveId());
            if(null != listVo && listVo.isSuccess()){
                MyCarveGroupListVo groupList = listVo.getBusinessObj();
                if(null != groupList && null != groupList.getGroupInfoList()){
                    List<MyCarveGroupInfoVo> groupInfoList = groupList.getGroupInfoList();
                    if(null != groupInfoList && groupInfoList.size() > 0){
                        List<MyCarveUpGroupVo> initGroups = new ArrayList<>();
                        List<MyCarveUpGroupVo> attendGroups = new ArrayList<>();

                        Map<String, Integer> map = null;
                        for(MyCarveGroupInfoVo vo: groupInfoList){
                            tempVo = new MyCarveUpGroupVo();
                            BeanUtils.copyProperties(vo, tempVo);
                            
                            map = this.getRankNeedPeople(vo.getCarveBaseNum(), vo.getCurrentMemberNum(), vo.getCarveMinNewNum(), vo.getNewUserNum());
                            if(null != map) {
                            	tempVo.setNeedNewNum(map.get("needNewNum"));
                            	tempVo.setNeedTotalNum(map.get("needTotalNum"));
                            }
                            
                            tempVo.setImage(this.imageConvertURL(tempVo.getImage()));
                            
                            //开团
                            if(vo.getUserGroupType().intValue() == 0){
                                initGroups.add(tempVo);
                            }

                            //参团
                            if(vo.getUserGroupType().intValue() == 1){
                                attendGroups.add(tempVo);
                            }
                            
                            
                        }
                        
                        board.setInitGroups(initGroups);
                        board.setAttendGroups(attendGroups);
                    }
                }
            }

            //团排名列表
            CommonResultEntity<MyGroupCarveInfoListVo> sortList = gorderInfoForAppCarveResource.getCraveGroupSortList(board.getCarveId(), pageNum, pageSize);
            if(null != sortList && sortList.isSuccess()){
                MyGroupCarveInfoListVo sortVo = sortList.getBusinessObj();
                if(null != sortVo && null != sortVo.getMemberList()){
                    List<MyGroupCarveInfoVo> memberList = sortVo.getMemberList();
                    if(memberList.size() > 0){
                        List<CarveUpGroupRankingVo> groups = new ArrayList<>();
                        CarveUpGroupRankingVo temp = null;

                		SimpleDateFormat sdf = new SimpleDateFormat("MM月dd日HH:mm:ss");
                        for(MyGroupCarveInfoVo vo: memberList){
                        	if(vo != null) {
                                temp = new CarveUpGroupRankingVo();
                                BeanUtils.copyProperties(vo, temp);
                                if(null != vo.getTotalCarveMoney() && null != vo.getLeaderUserAward()) {
                                    temp.setTotalCarveMoney(DoubleUtils.sub(vo.getTotalCarveMoney(), vo.getLeaderUserAward()));
                                }
                                temp.setLeaderMoney(vo.getLeaderUserAward());
                                temp.setCurrentUserId(userId);
                                //前端要求返回月日时分秒
                                if(null != vo.getSucessDate()) {
                                	temp.setSucessDate(sdf.format(vo.getSucessDate()));
                                }
                                
                                List<GroupUserInfo> memList = temp.getMemberList();
                                if(null != memList && memList.size() > 0) {
                                	for(GroupUserInfo user: memList) {
                                		user.setImage(this.imageConvertURL(user.getImage()));
                                	}
                                }
                                
                                temp.setImage(this.imageConvertURL(temp.getImage()));
                                
                                groups.add(temp);
                        	}
                        }

                        board.setGroups(groups);
                    }
                }
            }
        }
        return board;
    }

    /**
     * 获取团详情
     * @param userId
     * @param groupId
     * @return
     */
    private MyGroupCarveInfoVo getCarveGroupInfo(Long userId, Long groupId) {
        CommonResultEntity<MyGroupCarveInfoVo> result = gorderInfoForAppCarveResource.getCarveGroupInfo(userId, groupId);
        if (null != result && result.isSuccess()) {
            return result.getBusinessObj();
        }
        return null;
    }

    /**
     * 处理券信息
     * 此接口可使用fetchCouponService.getCoupon优化
     * @param couponType
     * @param batchNo   凑单服务查券信息的id都配在了这个字段上
     * @param schemeId  这个字段配置的是领券的id
     * @param pageCode
     * @return
     */
    private CarveUpCouponVo getCarveUpCoupon(Integer couponType, String batchNo, String schemeId, String pageCode) {
        CarveUpCouponVo cp = null;
        if (null != couponType) {
            String type = String.valueOf(couponType);
            if (type.equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
                // 根据批次号查询pop劵信息
                CouponBatchResult couponBatchResult = groupOrderManager.getPopCoupon(batchNo);
                if (null != couponBatchResult) {
                    cp = new CarveUpCouponVo();
                    cp.setCoupon_num(couponBatchResult.getDenomination()); // 面额
                    cp.setDescription(couponBatchResult.getDescription());
                    cp.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
                    cp.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券,
                    // 2:平台券
                    cp.setCoupon_id(batchNo); // pop劵批次号
                    cp.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    cp.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
                    cp.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));
                    cp.setCouponPageCode(pageCode);
                }
            } else {
                // 根据券规则ID获取美劵，红蓝券信息
                CouponRuleInfo blueCoupon = groupOrderManager.getCoupon(batchNo);
                if (null != blueCoupon) {
                    cp = new CarveUpCouponVo();
                    cp.setCoupon_id(blueCoupon.getRuleId());
                    cp.setCoupon_num(blueCoupon.getAmount());
                    cp.setFullAmount(blueCoupon.getLimitAmount());
                    cp.setDescription(blueCoupon.getDescription());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    cp.setShow_start_time(sdf.format(blueCoupon.getCouponStartDate()));
                    cp.setShow_end_time(sdf.format(blueCoupon.getCouponEndDate()));
                    cp.setCouponType(blueCoupon.getType());
                    cp.setCouponPageCode(pageCode);
                }

            }
        }
        return cp;
    }
    
    /**
     * 计算排名团还差新人、总人数
     * @param carveBaseNum 达标人数
     * @param currentMemberNum 当前团人数
     * @param carveMinNewNum 最低新人数
     * @param newUserNum 当前新人数
     * @return
     */
    private Map<String, Integer> getRankNeedPeople(Integer carveBaseNum, Integer currentMemberNum, Integer carveMinNewNum, Integer newUserNum){
    	if(null == newUserNum) {
    		return null;
    	}
    	Map<String, Integer> map = new HashMap<>();
    	if(null == carveMinNewNum) {
    		carveMinNewNum = 0;
        	map.put("needNewNum", 0);
    	}
    	
    	Integer needNewNum = carveMinNewNum - newUserNum;
    	if(needNewNum >= 0) {
        	map.put("needNewNum", needNewNum);
    	}
    	
    	if(null == carveBaseNum || null == currentMemberNum) {
    		return map;
    	}
    	
    	Integer needTotalNum = carveBaseNum - currentMemberNum;
    	if(needNewNum > needTotalNum) {
    		needTotalNum = needNewNum;
    	}
    	map.put("needTotalNum", needTotalNum);
    	return map;
    }
    
    /**
     * 将用户头像中的http和https协议去掉
     * @param image
     * @return
     */
    private String imageConvertURL(String image) {
    	if(StringUtils.isBlank(image)) {
    		return image;
    	}
    	
    	image = image.replace("http:", "").replace("https:", "");
    	
    	int index = image.lastIndexOf(".");
    	if(index >= 0) {
        	StringBuffer s = new StringBuffer(image);
    		s.insert(index, ratio);
    		image = s.toString();
    	}
    	
    	return image;
    }
}
