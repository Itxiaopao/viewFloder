package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

public class UpWeChartImageParamVo implements Serializable{
	private static final long serialVersionUID = 8974307361052508989L;

	//微信号
	private String microsignal;

	//微信号
	private String image;

	public String getMicrosignal() {
		return microsignal;
	}

	public void setMicrosignal(String microsignal) {
		this.microsignal = microsignal;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
}
