package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.Slot;
import com.gome.meidian.grouporder.vo.product.ProductInfo;

/**
 * 主页商品列表中的专题活动页
 * @author shichangjian
 *
 */
public class HomeGroupProductActivityPage implements Serializable{

	private static final long serialVersionUID = 8301875707127197053L;

	private Slot slot;
	private String ukey;
	private List<HomeProductActivity> homeProductActivities;
	
	public Slot getSlot() {
		return slot;
	}
	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	public String getUkey() {
		return ukey;
	}
	public void setUkey(String ukey) {
		this.ukey = ukey;
	}
	public List<HomeProductActivity> getHomeProductActivities() {
		return homeProductActivities;
	}
	public void setHomeProductActivities(List<HomeProductActivity> homeProductActivities) {
		this.homeProductActivities = homeProductActivities;
	}
	
	
}
