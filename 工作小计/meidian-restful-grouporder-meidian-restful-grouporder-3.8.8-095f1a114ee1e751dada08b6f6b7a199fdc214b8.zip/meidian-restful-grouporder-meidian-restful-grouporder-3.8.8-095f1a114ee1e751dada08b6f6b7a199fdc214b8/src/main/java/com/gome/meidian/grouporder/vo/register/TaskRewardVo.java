package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class TaskRewardVo implements Serializable {

	private static final long serialVersionUID = -2837995511598361310L;
	
	@NotNull(message = "{shop.task.info.taskId.notNull}")
    private Long taskId;//任务id
	@NotNull(message = "{shop.task.user.userId.notNull}")
    private Long inviterUserId;//邀请者会员ID
	@NotNull(message = "{shop.task.cms.pageNo.notNull}")
    private Integer pageNo;
	@NotNull(message = "{shop.task.cms.pageSize.notNull}")
    private Integer pageSize;
    
	public Long getTaskId() {
		return taskId;
	}
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}
	public Long getInviterUserId() {
		return inviterUserId;
	}
	public void setInviterUserId(Long inviterUserId) {
		this.inviterUserId = inviterUserId;
	}
	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

}
