package com.gome.meidian.grouporder.utils;


import com.gome.meidian.grouporder.vo.wechatLogin.WeChatUserInfo;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import redis.clients.util.JedisClusterCRC16;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static com.gome.meidian.grouporder.manager.WechatLoginManager.WX_TOKEN;

public class DesTest {

    public static void main(String[] args) throws Exception {

        /*Long time=System.currentTimeMillis()/1000l;
        System.out.println("时间戳："+time);
        String md5=WxDES.md5("tqn21am98krr0v8pc1grlaufm4q8pvbimzk");
        System.out.println("MD5："+md5);
        String sign=md5+time.toString();
        System.out.println("MD5(token+time)之后："+sign);
        String encodeSS = MobileDES.encryptDES(sign,"wxMShop2");
        System.out.println("succ:"+encodeSS);

        encodeSS=encodeSS.replace(" ","");
        String urlEncode= null;
        try {
            urlEncode = URLEncoder.encode(encodeSS,"UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        System.out.println("MD5之后DES后UrlEncode后："+urlEncode);
        System.out.println("=============");
        String result=MobileDES.decryptDES(encodeSS,"wxMShop2");
       // System.out.println(decodeSS);
        //Dz%252Ba3GgzKdZhYKtFNNM9o5YXktBAnuFZC7O3utHSJR8kLNy10fSd94AOqRVvEizBTWgAh9yeRAoq8g4tPF4RLEooVLRxU5a2ln6NMFg0cP40okZtna0JqOHZhK8NX%252Bo9knCO0Auj84eqwdONc7TKBYYh3kZ3726aX58kd7g5LY8%253D
        System.out.println("result:"+result);

        String  decode1="";
        String  decode=URLDecoder.decode("Dz%2Ba3GgzKdZhYKtFNNM9o5YXktBAnuFZC7O3utHSJR8kLNy10fSd94AOqRVvEizBTWgAh9yeRAoq8g4tPF4RLEooVLRxU5a2ln6NMFg0cP40okZtna0JqOHZhK8NX%2Bo9knCO0Auj84eqwdONc7TKBYYh3kZ3726aX58kd7g5LY8%3D","UTF-8");
        System.out.println("decode:"+decode);
        String userInfo=MobileDES.decryptDES(decode,"tqn21am9");

        System.out.println("userInfo:"+userInfo);*/

        /*List<String> listMIWEN=new ArrayList<String>();
        List<String> listUNION=new ArrayList<String>();

        for (int i=0;i<100;i++) {

            UUID uuidOpenId=UUID.randomUUID();
            UUID uuidUnioID=UUID.randomUUID();
            WeChatUserInfo weChatUserInfo=new WeChatUserInfo();
            weChatUserInfo.setNickname("小美100"+i);
            weChatUserInfo.setOpenid(uuidOpenId.toString().substring(0,28));
            weChatUserInfo.setUnionid(uuidUnioID.toString().substring(0,28));
            String result=JSONUtils.toJSONString(weChatUserInfo);
            System.out.println("微信授权信息明文"+i+":"+result);

            String encodeSS = MobileDES.encryptDES(result,WX_TOKEN.substring(0,8));
            encodeSS=encodeSS.replace(" ","");
            String urlEncode= null;
            try {
                urlEncode = URLEncoder.encode(encodeSS,"UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            listUNION.add(uuidUnioID.toString().substring(0,28));
            listMIWEN.add("微信授权信息密文："+i+":"+urlEncode);
        }

        for(int i=0;i<100;i++){
            System.out.println(listUNION.get(i));
        }

        for(int i=0;i<100;i++){
            System.out.println(listMIWEN.get(i));
        }*/


        System.out.println("==="+JedisClusterCRC16.getSlot("aC:大致".getBytes()));
    }



}
