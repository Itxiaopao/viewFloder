package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 凑单活动页
 * @author shichangjian
 *
 */
public class CmsActivityPageVo implements Serializable{

	private static final long serialVersionUID = -4441157636527761875L;
	private Integer code;
    private String msg;
	private CmsAvtivityPage data;
	
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public CmsAvtivityPage getData() {
		return data;
	}
	public void setData(CmsAvtivityPage data) {
		this.data = data;
	}
	
	
	
}
