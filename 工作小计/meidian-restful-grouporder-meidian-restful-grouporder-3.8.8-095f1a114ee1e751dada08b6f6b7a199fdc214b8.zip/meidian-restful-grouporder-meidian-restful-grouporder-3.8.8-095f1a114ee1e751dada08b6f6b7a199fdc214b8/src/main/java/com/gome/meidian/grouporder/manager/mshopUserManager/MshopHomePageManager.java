package com.gome.meidian.grouporder.manager.mshopUserManager;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.entity.MyGradesVo;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.vo.store.UserInfo;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.user.dto.MShopOwnerInfoDto;
import com.gome.meidian.user.dto.MShopPerformanceDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MeidianVshopSummaryDto;
import com.gome.meidian.user.manager.IMShopOwnerInfoManager;
import com.gome.meidian.user.manager.IUserShareBindingManager;

import cn.com.gome.gcoin.dubbo.AccountFacadeService;
import cn.com.gome.gcoin.dubbo.bean.GCoin_ParametersVo;
import cn.com.gome.rebate.dubbo.service.app.IDubboBuyersService;
import redis.Gcache;

@Service
public class MshopHomePageManager {
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private AccountFacadeService accountFacadeService;
	@Autowired
	private IMShopOwnerInfoManager iMShopOwnerInfoManager;
	@Autowired
	private INewOrderService iNewOrderService;
	
	@Autowired
	private IDubboBuyersService iDubboBuyersService;
	@Autowired
	private IUserShareBindingManager iUserShareBindingManager;
	
	@Autowired
	private StoreManager storeManager;
	
	
	@Autowired
	private IOrderShopService iOrderShopService;
	
	@Resource(name = "gcache")
	private Gcache gcache;
	
	/**
	 * 获取整体收益信息
	 * @param userId
	 * @return
	 * @throws ServiceException
	 */
	public  Map<String,Long> getTotalProfit(String userId)throws ServiceException{
		Map<String,Long> map = new HashMap<String,Long>();
		map.put("totalIncome", 0L);
		map.put("accountBalance", 0L);
		map.put("todayExpectIncome", 0L);
		map.put("expectIncome", 0L);
		map.put("downgrade", 0L);
		
		String onOff = gcache.get("gomeCoinCheckOnOff");
		if(onOff != null && !onOff.equals("")){
			map.put("downgrade", 1L);
		}else{
			//取余额
			GCoin_ParametersVo vo = new GCoin_ParametersVo();
			vo.setSources("010");
			vo.setBusinessType("ACCOUNT_QUERYACCOUNTINFO");
			vo.setInvokeSource("GCOIN_MEIDIAN_APP");
			Map<String, Object> map1 = new HashMap<>();
			map1.put("userNo", userId);
			vo.setMap(map1);
			try{
				GCoin_ParametersVo service = accountFacadeService.service(vo);//未在消费端注册
				if("0000".equals(service.getResCode()) && service.getMap()!= null && service.getMap().get("accountBalance")!=null) {
					map.put("accountBalance", (Long) service.getMap().get("accountBalance"));
				}
			}catch(Exception e){
				logger.error("getTotalProfit error!userId="+userId,e);
			}
			
			try{
				//查询收益信息(今日预计) 1：已入账；2：待入账；3：失效   统计维度，1：今天，2：昨天，3：本月，4：累计    已入账 -累计收入   待入账 -预计收入
				Long  todayExpectIncome = iDubboBuyersService.getRebateStatusTotalAmount(userId, 2, null, null, "1");
				if(todayExpectIncome != null){
					map.put("todayExpectIncome", todayExpectIncome);	
				}
			}catch(Exception e){
				logger.error("getTotalProfit error!userId="+userId,e);
			}
	
			//modify by lsx begin 2020.4.23
			try{
				//查询收益信息(累计预计) 1：已入账；2：待入账；3：失效   统计维度，1：今天，2：昨天，3：本月，4：累计    已入账 -累计收入   待入账 -预计收入
				Long  expectIncome = iDubboBuyersService.getRebateStatusTotalAmount(userId, 2, null, null, "4");
				if(expectIncome != null){
					map.put("expectIncome", expectIncome);	
				}
			}catch(Exception e){
				logger.error("getTotalProfit error!userId="+userId,e);
			}
			//modify by lsx end 2020.4.23


			try{
	            //累计收益
				Long  totalIncome = iDubboBuyersService.getRebateStatusTotalAmount(userId, 1, null, null, "4");
				if(totalIncome != null){
					map.put("totalIncome", totalIncome);	
				}
			}catch(Exception e){
				logger.error("getTotalProfit error!userId="+userId,e);
			}
		}

		return map;
	}
	
	
	
	/**
	 * 获取账户的收益信息
	 * @param userId
	 * @return
	 * @throws ServiceException
	 */
	public  Map<String,Object> getProfit(String userId,String dimension)throws ServiceException{
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("orderNum", 0L);
		map.put("salesAmount", 0L);
		map.put("expectIncome", 0L);
		try { 
			//取销售额，订单数量
			ResultEntity<MyGradesVo> getMyGrades = iNewOrderService.getMyGrades(Long.valueOf(userId), dimension);
			if(getMyGrades != null){
				MyGradesVo myGradesVo = getMyGrades.getBusinessObj();
				if(myGradesVo != null ){
					map.put("salesAmount", myGradesVo.getOrderGmv());
					map.put("orderNum", myGradesVo.getOrderNums());
				}
			}
            //取预计收入
			//查询收益信息(今日预计) 1：已入账；2：待入账；3：失效   统计维度，1：今天，2：昨天，3：本月，4：累计    已入账 -累计收入   待入账 -预计收入
			Long  todayExpectIncome = iDubboBuyersService.getRebateStatusTotalAmount(userId, 2, null, null, dimension);
			if(todayExpectIncome != null ){
				map.put("expectIncome", todayExpectIncome);	
			}
		}catch (Exception e){
			logger.error("getProfit error!userId="+userId,e);
		}
		return map;
	}
	/**
	 * 获取用户微信信息、邀请码等
	 * @param userId
	 * @return
	 * @throws ServiceException
	 */
	public  Map<String,Object> getUserInfo1(String userId)throws ServiceException{
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("invitationCode", null);
		map.put("imagePath", null);
		map.put("nickName", null);
		map.put("userIdentity", null);
		map.put("mshopUserNum", 0L);
		map.put("totalSalesAmount", 0L);
		map.put("consumerCount", 0L);
		// 店主对应的微信信息，店主信息
		try {
			MapResults<MShopPerformanceDto> mapResults = iMShopOwnerInfoManager.queryMshopInfoWithPerformance(Long.valueOf(userId));
			if (mapResults != null) {
				MShopPerformanceDto mShopPerformanceDto = mapResults.getBuessObj();
				if (mShopPerformanceDto != null) {
					map.put("mshopUserNum", mShopPerformanceDto.getMshopOwnerCount());
					map.put("consumerCount", mShopPerformanceDto.getConsumerCount());
					MShopOwnerInfoDto mShopOwnerInfoDto = mShopPerformanceDto.getMShopOwnerInfoDto();
					if (mShopOwnerInfoDto != null) {
						map.put("invitationCode", mShopOwnerInfoDto.getInvitationCode());
						map.put("imagePath", mShopOwnerInfoDto.getImagePath());
						map.put("nickName", mShopOwnerInfoDto.getWeiXinNickName());
						map.put("userIdentity", mShopOwnerInfoDto.getUserIdentity());
					}
				}
			}
		} catch (Exception e) {
			logger.error("getUserInfo error!userId=" + userId, e);
		}

		// 获取累计销售金额
		try{
			ResultEntity<MyGradesVo> getMyGrades = iNewOrderService.getMyGrades(Long.valueOf(userId), "4");
			if (getMyGrades != null) {
				MyGradesVo myGradesVo = getMyGrades.getBusinessObj();
				if (myGradesVo != null) {
					map.put("totalSalesAmount", myGradesVo.getOrderGmv());
				}
			}
		}catch (Exception e) {
			logger.error("getUserInfo error!userId=" + userId, e);
		}


		return map;
	}
	
	/**
	 * 获取mid
	 * @param userId
	 * @return
	 */
	public String getMid(Long userId){
		//获取mid
		String mid = null;
		try{
			MapResults<String>  midMapResults =  iMShopOwnerInfoManager.queryMidByUserId(userId);
			if(midMapResults != null){
				mid = midMapResults.getBuessObj();
			}
		}catch (Exception e){
			logger.error("getMid error!userId="+userId,e);
		}
		return mid;
	}


	
	/**
	 * 获取用户微信信息、邀请码等
	 * @param userId
	 * @return
	 * @throws ServiceException
	 */
	public  Map<String,Object> getUserInfo(String userId)throws ServiceException{
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("invitationCode", null);
		map.put("imagePath", null);
		map.put("nickName", null);
		map.put("userIdentity", null);
		map.put("mshopUserNum", 0L);
		map.put("totalSalesAmount", 0L);
		map.put("consumerCount", 0L);
		
		map.put("organizationId", "");
		map.put("stid", "");
		map.put("userId", userId);
		// 店主对应的微信信息，店主信息
		try {
			MapResults<MShopOwnerInfoDto> mapResults = iMShopOwnerInfoManager.queryMshopOwnerIndexByUserId(Long.valueOf(userId));
			if (mapResults != null) {
				MShopOwnerInfoDto mShopOwnerInfoDto = mapResults.getBuessObj();
				if (mShopOwnerInfoDto != null) {
					if (mShopOwnerInfoDto != null) {
						map.put("invitationCode", mShopOwnerInfoDto.getInvitationCode());
						map.put("imagePath", mShopOwnerInfoDto.getImagePath());
						map.put("nickName", mShopOwnerInfoDto.getWeiXinNickName());
						map.put("userIdentity", mShopOwnerInfoDto.getUserIdentity());
					}
				}
			}
		} catch (Exception e) {
			logger.error("getUserInfo error  == >> iMShopOwnerInfoManager.queryMshopOwnerIndexByUserId !userId=" + userId, e);
		}
		//店主数量，销售额
		try {
			MapResults<MeidianVshopSummaryDto>  mapResults = iMShopOwnerInfoManager.selectByUserId(Long.valueOf(userId));
			if(mapResults != null){
				MeidianVshopSummaryDto meidianVshopSummaryDto = mapResults.getBuessObj();
				if(meidianVshopSummaryDto != null){
					map.put("mshopUserNum", meidianVshopSummaryDto.getShopNum());
					map.put("consumerCount", meidianVshopSummaryDto.getCustomNum());
				}
			}

		} catch (Exception e) {
			logger.error("getUserInfo error== >> iMShopOwnerInfoManager.selectByUserId !userId=" + userId, e);
		}

		// 获取累计销售金额
		try{
			ResultEntity<MyGradesVo> getMyGrades = iNewOrderService.getMyGrades(Long.valueOf(userId), "4");
			if (getMyGrades != null) {
				MyGradesVo myGradesVo = getMyGrades.getBusinessObj();
				if (myGradesVo != null) {
					map.put("totalSalesAmount", myGradesVo.getOrderGmv());
				}
			}
		}catch (Exception e) {
			logger.error("getUserInfo error == >> iNewOrderService.getMyGrades !userId=" + userId, e);
		}
		
		String stid = "";
		try {
			UserInfo userInfo = storeManager.getUserInfo(Long.valueOf(userId));
			if (null != userInfo) {
				if (userInfo.getStoreCode() != null) {
					stid = userInfo.getStoreCode();
					map.put("stid", stid);
				}
			}
		} catch (Exception e) {
			logger.error("getUserInfo error == >> storeManager.getUserInfo !userId=" + userId, e);
		}
		String organizationId = "";
		try {
			 organizationId = iOrderShopService.findOrganizationByUserId(Long.valueOf(userId));
			 if(organizationId != null){
				 map.put("organizationId", organizationId);
			 }
		} catch (Exception e) {
			logger.error("getUserInfo error == >> iOrderShopService.findOrganizationByUserId !userId=" + userId, e);
		}

		return map;
	}
	
}
