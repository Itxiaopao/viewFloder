package com.gome.meidian.grouporder.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.ProductRecommendManager;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.GrouppOrderProductsVo;
import com.gome.meidian.grouporder.vo.RecProductInfoVo;
import com.gome.meidian.grouporder.vo.ShopInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

import redis.Gcache;
/**
 * 商品详情页，商品推荐部分控制层
 * @author lishouxu-ds
 *
 */
@RestController
@Validated
@RequestMapping("/v1")
public class ProductRecommendController {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource(name = "gcache")
	private Gcache gcache;
	
	@Autowired
	private ProductRecommendManager productRecommendManager;

	
    /**
     * 查询店铺信息
     * @param shopId
     * @param ppi
     * @param scn
     * @param request
     * @return
     * @throws MeidianException
     */
	@GetMapping("/recommend/getShopInfo")
	public ResponseJson<ShopInfoVo> getShopInfo(
			@NotBlank(message = "{param.error}") @RequestParam(value = "shopId", required = true) String shopId,
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@CookieValue(value = "SCN", required = false) String scn, 
			HttpServletRequest request)throws MeidianException {
		ResponseJson<ShopInfoVo> response = new ResponseJson<ShopInfoVo>();
        //先取缓存数据
		String key = "recommendShopInfo" + "_" + shopId; 
		ShopInfoVo shopInfoVo = JSONObject.parseObject(gcache.get(key), ShopInfoVo.class);
		//logger.info("gcache.get("+key+") ==> {} ", shopInfoVo);
		if(null == shopInfoVo){
			shopInfoVo = productRecommendManager.getShopInfo(shopId);
			if(shopInfoVo != null){
				gcache.setex(key, 30, JSONObject.toJSONString(shopInfoVo));
			}			
		}
		response.setData(shopInfoVo);
		return response;
	}
    /**
     * 查询推荐商品信息12条
     * @param shopId
     * @param productId
     * @param ppi
     * @param scn
     * @param request
     * @return
     * @throws MeidianException
     */
	@MDStorePriceAnnotation
	@GetMapping("/recommend/getProductInfo")
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ResponseJson<Map<String, Object>> getProductInfo(
			@NotBlank(message = "{param.error}") @RequestParam(value = "shopId", required = true) String shopId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@CookieValue(value = "SCN", required = false) String scn, 
			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			/*加盟店价格参数end*/
			
			HttpServletRequest request)throws MeidianException {
//		long begin = System.currentTimeMillis();
		ResponseJson response = new ResponseJson();
		Map<String, Object> resultMap = new HashMap<>();
		List<RecProductInfoVo> listResult = null;
		String key = "recommendShopProductInfo" + "_" + shopId; 
		List<RecProductInfoVo> list= JSON.parseArray(gcache.get(key), RecProductInfoVo.class); 
		if(CollectionUtils.isEmpty(list)){
			// 获取设备
			Byte ua = ImageUtils.userAgentChannel(request);
			 list = productRecommendManager.getProductInfo(shopId, 13, 1, ppi,ua, MeidianEnvironment.getKey("priceReqAreaCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
		}
		if(!CollectionUtils.isEmpty(list)){
			gcache.setex(key, 30, JSON.toJSON(list).toString());
			//判断返回的集合中是否包含当前商品
			filterProductInfo(list,productId);
			if( list.size() >= 3 && list.size() < 6) {
				listResult =new ArrayList<RecProductInfoVo>();
				listResult.addAll(list.subList(0, 3));
			}else if(list.size() >= 6 && list.size() < 9){
				listResult =new ArrayList<RecProductInfoVo>();
				listResult.addAll(list.subList(0, 6));
			}else if(list.size() >= 9 && list.size() < 12){
				listResult =new ArrayList<RecProductInfoVo>();
				listResult.addAll(list.subList(0, 9));
			}else if(list.size() >= 12){
				listResult =new ArrayList<RecProductInfoVo>();
				listResult.addAll(list.subList(0, 12));
			}
		}
		resultMap.put("productInfos", listResult);
		response.setData(resultMap);
//		long end = System.currentTimeMillis();
//		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>总共花费："+ (end-begin));
		return response;
	}
	
	
	/**
	 * 全部商品信息
	 * @param shopId
	 * @param pageSize
	 * @param pageNum
	 * @param ppi
	 * @param scn
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@GetMapping("/recommend/getProductInfoList")
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public ResponseJson<Map<String, Object>> getProductInfoList(
			@NotBlank(message = "{param.error}") @RequestParam(value = "shopId", required = true) String shopId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageSize", required = true) String pageSize,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageNum", required = true) String pageNum,
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@CookieValue(value = "SCN", required = false) String scn, 
			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			/*加盟店价格参数end*/
			
			HttpServletRequest request)throws MeidianException {
		Integer pageSize1 = null;
		Integer pageNum1 = null;
        try{
    		pageSize1=Integer.valueOf(pageSize);
    		pageNum1=Integer.valueOf(pageNum);
    		if(pageSize1>20){
    			throw new ServiceException("param.error");
    		}
        }catch(Exception e){
        	throw new ServiceException("param.error");
        }

		ResponseJson response = new ResponseJson();
		Map<String, Object> resultMap = new HashMap<>();
		Byte ua = ImageUtils.userAgentChannel(request);
		List<RecProductInfoVo> list = productRecommendManager.getProductInfo(shopId, pageSize1, pageNum1,ppi,ua ,MeidianEnvironment.getKey("priceReqAreaCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
		resultMap.put("productInfos", list);
		response.setData(resultMap);
		return response;
	}
	
	
	private List<RecProductInfoVo> filterProductInfo(List<RecProductInfoVo> list,String productId){
		for(int i=0;i<list.size();i++){
			if(list.get(i).getProductId().equals(productId)){
				list.remove(i);
			}
		}
		return list;
	}
	



    
    public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		for(int i=0;i<11;i++){
			list.add(i+"");
		}
		
		for(int i=0;i<list.size();i++){
			if(list.get(i).equals("4")){
				list.remove(i);
				break;
			}
		}
 
		System.out.println(list.size()+">>>>>>>>>>>>");
		for(int i=0;i<list.size();i++){
			System.out.println(i+"###########"+list.get(i));
		}
	}



	

	



	
	
}
