package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gome.meidian.grouporder.vo.grouporderVo.EnergySavingSubsidiesVo;
import com.gome.meidian.grouporder.vo.grouporderVo.SkuEnergyAllowanceVo;
import com.gomeplus.bs.interfaces.gorder.vo.GroupInfoVo;

/**
 * 凑单详情
 * @author shichangjian
 *
 */
public class GroupOrderDetails extends GroupInfoVo implements Serializable{

	private static final long serialVersionUID = 4740980256001191073L;

	private Integer userGroupStatus;				//用户对团的操作情况
	private Long groupNum;							//正在进行的团数量
	private List<CurrentStepsVo> currentStepsVos;	//阶梯信息
	private Long groupCountdown;					//团倒计时
	private String meidianPrice;					// 美店定价
	private String priceKey;						// 下单使用，区分美店定价
	private SkuEnergyAllowanceVo skuEnergyAllowance; //节能补贴信息
	private EnergySavingSubsidiesVo energySavingSubsidies; //节能优惠信息
	private Integer warranty;						// 延保 1：有延保，0：没有延保
	
	private Integer currentUserFlag;  //当前用户是否新用户 0:老用户   1:新用户
	
	public Integer getUserGroupStatus() {
		return userGroupStatus;
	}
	public void setUserGroupStatus(Integer userGroupStatus) {
		this.userGroupStatus = userGroupStatus;
	}
	public Long getGroupNum() {
		return groupNum;
	}
	public void setGroupNum(Long groupNum) {
		this.groupNum = groupNum;
	}
	public List<CurrentStepsVo> getCurrentStepsVos() {
		return currentStepsVos;
	}
	public void setCurrentStepsVos(List<CurrentStepsVo> currentStepsVos) {
		this.currentStepsVos = currentStepsVos;
	}
	public Long getGroupCountdown() {
		return groupCountdown;
	}
	public void setGroupCountdown(Long groupCountdown) {
		this.groupCountdown = groupCountdown;
	}
	public String getMeidianPrice() {
		return meidianPrice;
	}
	public void setMeidianPrice(String meidianPrice) {
		this.meidianPrice = meidianPrice;
	}
	public String getPriceKey() {
		return priceKey;
	}
	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}
	public SkuEnergyAllowanceVo getSkuEnergyAllowance() {
		return skuEnergyAllowance;
	}
	public void setSkuEnergyAllowance(SkuEnergyAllowanceVo skuEnergyAllowance) {
		this.skuEnergyAllowance = skuEnergyAllowance;
	}
	public Integer getWarranty() {
		return warranty;
	}
	public void setWarranty(Integer warranty) {
		this.warranty = warranty;
	}
	public EnergySavingSubsidiesVo getEnergySavingSubsidies() {
		return energySavingSubsidies;
	}
	public void setEnergySavingSubsidies(EnergySavingSubsidiesVo energySavingSubsidies) {
		this.energySavingSubsidies = energySavingSubsidies;
	}
	public Integer getCurrentUserFlag() {
		return currentUserFlag;
	}
	public void setCurrentUserFlag(Integer currentUserFlag) {
		this.currentUserFlag = currentUserFlag;
	}
	
}
