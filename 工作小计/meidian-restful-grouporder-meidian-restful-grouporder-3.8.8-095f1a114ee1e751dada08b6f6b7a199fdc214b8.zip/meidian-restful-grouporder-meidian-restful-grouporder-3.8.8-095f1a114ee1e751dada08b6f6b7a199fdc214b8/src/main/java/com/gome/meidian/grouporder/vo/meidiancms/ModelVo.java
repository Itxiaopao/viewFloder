package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.ProductDetailVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.homePage.ThousandGroup;
import com.gome.meidian.grouporder.vo.homePage.WanrenGroupListVo;
import com.gome.meidian.grouporder.vo.product.HomeCouponProductRes;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;

/**
 * 活动页封装
 * @author shichangjian
 *
 */
public class ModelVo implements Serializable{

	private static final long serialVersionUID = 5544421714063428582L;

	private List<ImageElement> imageElements;				// 图片元素
	private List<ProductGroupInfoVo> productGroupInfoVos;	// 组团列表
	private List<HomeCouponProductRes> homeCouponProductRes;// 立减列表
	private List<ProductBuyRebateVo> productBuyRebateVos;	// 超级返列表
	private List<ModelMerge> modelMerges;					// 合并楼层
	private List<Coupon> coupons;							// 合并楼层
	private List<ThousandGroup> thousandGroups;				// 万人团
	private Integer type;									// 楼层类型
	private Integer rowCount;								// 每行显示条数,单列，双列，多商品轮播
	private String name;									// 名称
	private String backColor;								// 底色
	private String backImgUrl;								// 低图片
	private String textColor; 								// 元素文字颜色
	private String sctTextColor; 							// 字体选中时颜色
	private String moduleCode;								// 挂载的模块code
	private String pageCode;								// 挂载的页面Code
	private String expanded1; 								// 扩展内容
	
	
	public String getExpanded1() {
		return expanded1;
	}
	public void setExpanded1(String expanded1) {
		this.expanded1 = expanded1;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<ImageElement> getImageElements() {
		return imageElements;
	}
	public void setImageElements(List<ImageElement> imageElements) {
		this.imageElements = imageElements;
	}
	public List<ProductGroupInfoVo> getProductGroupInfoVos() {
		return productGroupInfoVos;
	}
	public void setProductGroupInfoVos(List<ProductGroupInfoVo> productGroupInfoVos) {
		this.productGroupInfoVos = productGroupInfoVos;
	}
	public List<HomeCouponProductRes> getHomeCouponProductRes() {
		return homeCouponProductRes;
	}
	public void setHomeCouponProductRes(List<HomeCouponProductRes> homeCouponProductRes) {
		this.homeCouponProductRes = homeCouponProductRes;
	}
	public List<ProductBuyRebateVo> getProductBuyRebateVos() {
		return productBuyRebateVos;
	}
	public void setProductBuyRebateVos(List<ProductBuyRebateVo> productBuyRebateVos) {
		this.productBuyRebateVos = productBuyRebateVos;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModuleCode() {
		return moduleCode;
	}
	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}
	public String getPageCode() {
		return pageCode;
	}
	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public List<ModelMerge> getModelMerges() {
		return modelMerges;
	}
	public void setModelMerges(List<ModelMerge> modelMerges) {
		this.modelMerges = modelMerges;
	}
	public Integer getRowCount() {
		return rowCount;
	}
	public void setRowCount(Integer rowCount) {
		this.rowCount = rowCount;
	}
	public List<Coupon> getCoupons() {
		return coupons;
	}
	public void setCoupons(List<Coupon> coupons) {
		this.coupons = coupons;
	}
	public String getBackColor() {
		return backColor;
	}
	public void setBackColor(String backColor) {
		this.backColor = backColor;
	}
	public String getBackImgUrl() {
		return backImgUrl;
	}
	public void setBackImgUrl(String backImgUrl) {
		this.backImgUrl = backImgUrl;
	}
	public String getTextColor() {
		return textColor;
	}
	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}
	public String getSctTextColor() {
		return sctTextColor;
	}
	public void setSctTextColor(String sctTextColor) {
		this.sctTextColor = sctTextColor;
	}
	public List<ThousandGroup> getThousandGroups() {
		return thousandGroups;
	}
	public void setThousandGroups(List<ThousandGroup> thousandGroups) {
		this.thousandGroups = thousandGroups;
	}
	
	
	
	
}
