package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

public class ActivityPage implements Serializable{

	private static final long serialVersionUID = 3586776211782673335L;
	
	private Slot slot;
	private List<StoreVo> storeVos;
	private String ukey;
	
	public Slot getSlot() {
		return slot;
	}
	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	public List<StoreVo> getStoreVos() {
		return storeVos;
	}
	public void setStoreVos(List<StoreVo> storeVos) {
		this.storeVos = storeVos;
	}
	public String getUkey() {
		return ukey;
	}
	public void setUkey(String ukey) {
		this.ukey = ukey;
	}
	
	
}
