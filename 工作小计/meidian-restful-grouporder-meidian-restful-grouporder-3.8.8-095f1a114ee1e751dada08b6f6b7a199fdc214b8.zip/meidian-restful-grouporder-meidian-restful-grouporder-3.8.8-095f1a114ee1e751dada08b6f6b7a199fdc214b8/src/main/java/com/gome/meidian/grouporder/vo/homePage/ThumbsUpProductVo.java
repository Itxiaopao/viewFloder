package com.gome.meidian.grouporder.vo.homePage;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

public class ThumbsUpProductVo extends CollectionProductVo {

	private static final long serialVersionUID = -200090674180695004L;
	
	//0--取消点赞   1--点赞
	@NotBlank(message = "{param.error}")
	@Pattern(regexp="^[0-1]{1}$",message="{param.error}")
	private String thumbsUped;

	public String getThumbsUped() {
		return thumbsUped;
	}

	public void setThumbsUped(String thumbsUped) {
		this.thumbsUped = thumbsUped;
	}
	
}
