package com.gome.meidian.grouporder.vo.homePage;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @Author yuliang-ds1
 * @Date 2019/1/12 15:13
 * @Description
 */
@Setter
@Getter
@ToString
public class RebateCmsVo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -4118776165050972616L;

    private Long id;
    private String code;	// code

    private String productId;
    private String skuNo;
    private String skuId;

    private Double price;
    private String shopId;


}
