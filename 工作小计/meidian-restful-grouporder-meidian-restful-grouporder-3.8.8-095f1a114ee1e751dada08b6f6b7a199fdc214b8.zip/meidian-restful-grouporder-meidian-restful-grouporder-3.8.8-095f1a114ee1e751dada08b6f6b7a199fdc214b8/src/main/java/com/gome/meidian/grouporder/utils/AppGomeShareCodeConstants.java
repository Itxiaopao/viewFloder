package com.gome.meidian.grouporder.utils;

import java.util.HashMap;
import java.util.Map;

public class AppGomeShareCodeConstants {
	// sharePage
	public static Map<String, AppShareCodeInfo> pageUrlMap;//美店小程序
	public static Map<String, AppShareCodeInfo> gomePageUrlMap;//国美小程序
	static {
		pageUrlMap = new HashMap<String, AppShareCodeInfo>();
        //生产配置
		pageUrlMap.put("sharePage1", new AppShareCodeInfo("https://d.m.gome.com.cn",
				"pages/guides/index/index","mid#stid#areaCode","areaCode"));//首页
		
		pageUrlMap.put("sharePage2", new AppShareCodeInfo("https://mshop.m.gome.com.cn/views/appActivity/appActivity.html",
				"pages/guides/web/index","mid#stid#areaCode#pageCode","areaCode#pageCode"));//活动页
		
		pageUrlMap.put("sharePage3", new AppShareCodeInfo("https://d.m.gome.com.cn/singleCoupons",
				"pages/personals/getCoupons/index","mid#stid#areaCode#productId#skuId#skuNo#couponId#couponType",
				"areaCode#couponId#couponType#plan_id#productId"));//领券中间页
		
		pageUrlMap.put("sharePage4", new AppShareCodeInfo("https://gorder.m.gome.com.cn/productdetail",
				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuId#skuNo#couponPrice"
				,"areaCode#productId#skuId#couponNum"));//领券商品详情
		
		pageUrlMap.put("sharePage5", new AppShareCodeInfo("https://gorder.m.gome.com.cn/productdetail",
				"pages/personals/product_details/index","mid#stid#areaCode#skuNo#buyRebate#productId#skuId"
				,"areaCode#productId#skuId#buyRebate"));//超级返商品详情
		
		pageUrlMap.put("sharePage6", new AppShareCodeInfo("https://gorder.m.gome.com.cn/detail",
				"pages/personals/product_details/index","mid#stid#areaCode#activityId#skuNo#productId#skuId"
				,"areaCode#groupId#productId#skuId#activityId"));//未开团-组团商品详情
		
		pageUrlMap.put("sharePage7", new AppShareCodeInfo("https://gorder.m.gome.com.cn/detail",
				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuNo#skuId#activityId#tuanId"
				,"areaCode#groupId#productId#skuId#activityId"));//开团-组团商品详情
		
		pageUrlMap.put("sharePage8", new AppShareCodeInfo("https://mshop.m.gome.com.cn/views/coudanDetail/coudanDetail.html",
				"pages/personals/single_groups/index","mid#stid#areaCode#tuanId#createType"
				,"areaCode#groupId#skuId"));//组团详情
		pageUrlMap.put("sharePage9", new AppShareCodeInfo("",
				"pages/personals/product_details/index",""
				,"areaCode#skuId#activityId#productId"));//助力团
		pageUrlMap.put("sharePage10", new AppShareCodeInfo("",
				"pages/personals/product_details/index",""
				,"areaCode#groupId#skuId#activityId#productId"));//万人团
		
		pageUrlMap.put("sharePage11", new AppShareCodeInfo("",
				"pages/personals/single_groups2/index",""
				,"areaCode#groupId#zlUserId"));//瓜分团
		//测试配置
//		pageUrlMap.put("sharePage1", new AppShareCodeInfo("http://d.m.atguat.com.cn",
//				"pages/guides/index/index","mid#stid#areaCode","areaCode"));//首页
//		
//		pageUrlMap.put("sharePage2", new AppShareCodeInfo("http://mshop.m.atguat.com.cn/views/appActivity/appActivity.html",
//				"pages/guides/web/index","mid#stid#areaCode#pageCode","areaCode#pageCode"));//活动页
//		
//		pageUrlMap.put("sharePage3", new AppShareCodeInfo("http://d.m.atguat.com.cn/singleCoupons",
//				"pages/personals/getCoupons/index","mid#stid#areaCode#productId#skuId#skuNo#couponId#couponType",
//				"areaCode#couponId#couponType#plan_id#productId"));//领券中间页
//		
//		pageUrlMap.put("sharePage4", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/productdetail",
//				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuId#skuNo#couponPrice"
//				,"areaCode#productId#skuId#couponNum"));//领券商品详情
//		
//		pageUrlMap.put("sharePage5", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/productdetail",
//				"pages/personals/product_details/index","mid#stid#areaCode#skuNo#buyRebate#productId#skuId"
//				,"areaCode#productId#skuId#buyRebate"));//超级返商品详情
//		
//		pageUrlMap.put("sharePage6", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/detail",
//				"pages/personals/product_details/index","mid#stid#areaCode#activityId#skuNo#productId#skuId"
//				,"areaCode#groupId#productId#skuId#activityId"));//未开团-组团商品详情
//		
//		pageUrlMap.put("sharePage7", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/detail",
//				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuNo#skuId#activityId#tuanId"
//				,"areaCode#groupId#productId#skuId#activityId"));//开团-组团商品详情
//		
//		pageUrlMap.put("sharePage8", new AppShareCodeInfo("http://mshop.m.atguat.com.cn/views/coudanDetail/coudanDetail.html",
//				"pages/personals/single_groups/index","mid#stid#areaCode#tuanId#createType"
//				,"areaCode#groupId#skuId"));//组团详情
//		pageUrlMap.put("sharePage9", new AppShareCodeInfo("",
//				"pages/personals/single_groups/index",""
//				,"areaCode#skuId#activityId#productId"));//助力团
//		pageUrlMap.put("sharePage10", new AppShareCodeInfo("",
//				"pages/personals/single_groups/index",""
//				,"areaCode#groupId#skuId#activityId#productId"));//万人团
//		
//		pageUrlMap.put("sharePage11", new AppShareCodeInfo("",
//				"pages/personals/single_groups2/index",""
//				,"areaCode#groupId#zlUserId"));//瓜分团
		
		
		////以下为国美小程序的逻辑
		gomePageUrlMap = new HashMap<String, AppShareCodeInfo>();
        //生产配置
		gomePageUrlMap.put("sharePage1", new AppShareCodeInfo("",
				"pages/index/index","",""));//首页	
		gomePageUrlMap.put("sharePage2", new AppShareCodeInfo("",
				"pages/active/active","","url"));//活动页		
		gomePageUrlMap.put("sharePage5", new AppShareCodeInfo("",
				"pages/prod/prod",""
				,"productId#skuId"));//超级返商品详情  productId=A0006565935&skuId=pop8012805327
		
		gomePageUrlMap.put("sharePage6", new AppShareCodeInfo("",
				"pages/prod/prod",""
				,"activityId#productId#skuId"));//未开团-组团商品详情  activityId=9359&productId=A0006565935&skuId=pop8012805327
		
		gomePageUrlMap.put("sharePage7", new AppShareCodeInfo("",
				"packGroup/pages/singleGroups/singleGroups",""
				,"groupId#skuId#orderId"));//开团-组团商品详情  groupId=13071&skuId=1000156554&orderId=19015193393
		

		gomePageUrlMap.put("sharePage9", new AppShareCodeInfo("",
				"pages/prod/prod",""
				,"activityId#productId#skuId"));//助力团  activityId=8625&productId=9200001522&skuId=1000088546
		gomePageUrlMap.put("sharePage10", new AppShareCodeInfo("",
				"packGroup/pages/singleGroups/singleGroups",""
				,"groupId#skuId#orderId"));//万人团 groupId=13071&skuId=1000156554&orderId=19015193393
		
		gomePageUrlMap.put("sharePage11", new AppShareCodeInfo("",
				"packGroup/pages/singleGroups2/index",""
				,"groupId"));//瓜分团  groupId=235037
		
	}



}
