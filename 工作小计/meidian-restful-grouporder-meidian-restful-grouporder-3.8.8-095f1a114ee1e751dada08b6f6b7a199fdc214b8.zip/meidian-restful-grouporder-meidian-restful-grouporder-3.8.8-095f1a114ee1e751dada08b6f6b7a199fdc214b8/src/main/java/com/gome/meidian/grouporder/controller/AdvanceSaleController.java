package com.gome.meidian.grouporder.controller;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.AdvanceSaleManager;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.vo.advanceSale.PresellQueryParamVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;


/**
 * 预售
 *
 */
@RestController
@Validated
@RequestMapping("/v1/advanceSale")
public class AdvanceSaleController {

	private Logger logger = LoggerFactory.getLogger(getClass());


	@Autowired
	private AdvanceSaleManager advanceSaleManager;




	/**
	 * 微商城获取微信用户关注信息接口说明
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/queryPresellInfoById", method = RequestMethod.GET)
	public ResponseJson queryPresellInfoById(
			@NotBlank(message = "{param.error}") @RequestParam("promId") String promId,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=advanceSaleManager.queryPresellInfoById(promId);
		result.setData(object);
		return result;
	}


	/**
	 * 根据skuno+门店+区域 获取预售基本信息
	 * @param skuNo
	 * @param isShop
	 * @param countyCode
	 * @param townCode
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/queryOnePresellInfoBySkuNo", method = RequestMethod.GET)
	public ResponseJson queryOnePresellInfoBySkuNo(
			@NotBlank(message = "{param.error}") @RequestParam("skuNo") String skuNo,
			String storeCode,
			Boolean isShop
			,String countyCode,String townCode,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=advanceSaleManager.queryOnePresellInfoByParam(skuNo,storeCode,isShop,countyCode,townCode);
		result.setData(object);
		return result;
	}


	/**
	 * 批量根据skuno+门店+区域 获取预售基本信息
	 * @param presellQueryParamVo
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/queryAllPresellInfoBySkuNo", method = RequestMethod.POST)
	public ResponseJson queryAllPresellInfoBySkuNo(@RequestBody @Validated  PresellQueryParamVo presellQueryParamVo,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=advanceSaleManager.queryAllPresellInfoByParam(presellQueryParamVo);
		result.setData(object);
		return result;
	}


	/**
	 * 根据skuno+区域 获取下级区域列表
	 * @param skuNo
	 * @param areaCode
	 * @param areaLevel
	 * @param isShop
	 * @param skuId
	 * @param productId
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/queryPresellAreaInfo", method = RequestMethod.GET)
	public ResponseJson queryPresellAreaInfo(
			String skuNo,
			String areaCode,
			int areaLevel,
			Boolean isShop
			,String skuId,String productId,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=advanceSaleManager.queryPresellAreaInfo(skuNo,areaCode,areaLevel,isShop,skuId,productId);
		result.setData(object);
		return result;
	}
}
