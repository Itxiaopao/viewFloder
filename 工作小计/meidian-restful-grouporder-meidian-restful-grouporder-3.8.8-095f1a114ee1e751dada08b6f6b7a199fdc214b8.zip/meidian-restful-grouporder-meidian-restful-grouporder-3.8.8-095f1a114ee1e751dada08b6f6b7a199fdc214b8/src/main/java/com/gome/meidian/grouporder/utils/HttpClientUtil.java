package com.gome.meidian.grouporder.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.app.MinTokenManager;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

import redis.Gcache;


@Component
public class HttpClientUtil {
	
	private static Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);
	@Autowired
	private CloseableHttpClient httpClient;
	@Autowired
	private RequestConfig config;
	/**
	 * 此接口使用连接池 不带参数的get请求
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public String doGet(String url) throws Exception {

		// 声明 http get 请求
		HttpGet httpGet = new HttpGet(url);
		// 装载配置信息
		httpGet.setConfig(config);

		// 设置请求头
		// httpGet.setHeader("Accept",
		// "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
		// httpGet.setHeader("Accept-Encoding", "gzip, deflate");
		// httpGet.setHeader("Accept-Language", "zh-CN,zh;q=0.8");
		// httpGet.setHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64;
		// x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.91
		// Safari/537.36");

		CloseableHttpResponse response = null;
		try {
			// 发起请求
			response = this.httpClient.execute(httpGet);
			HttpEntity entity = response.getEntity();
			String result = EntityUtils.toString(entity, "utf-8");
			// 关闭内容流和关闭响应之间的区别是：前者将尝试通过消耗实体内容来保持底层连接活动，而后者立即关闭并丢弃连接
			// 把底层的流给关闭了,可以看源码，
			EntityUtils.consume(entity);
			return result;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// 关闭响应,立即关闭并丢弃连接,(如果已经释放连接回连接池，则什么也不做)
				if (response != null)
					response.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public String doGet(HttpGet httpGet){
		String result = null;
		// 装载配置信息
		httpGet.setConfig(config);
		CloseableHttpResponse response = null;
		try {
			response = this.httpClient.execute(httpGet);
			HttpEntity ent = response.getEntity();
			result = EntityUtils.toString(ent, "utf-8");
			// 关闭内容流和关闭响应之间的区别是：前者将尝试通过消耗实体内容来保持底层连接活动，而后者立即关闭并丢弃连接
			// 把底层的流给关闭了,可以看源码，
			EntityUtils.consume(ent);
			return result;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				// 关闭响应,立即关闭并丢弃连接,(如果已经释放连接回连接池，则什么也不做)
				if (response != null)
					response.close();
			} catch (IOException e) {
				e.printStackTrace();
				return null;
			}
		}
		
	}

	/**
	 * 此接口使用连接池 带参数的get请求
	 * 
	 * @param url
	 * @return
	 * @throws URISyntaxException 
	 * @throws Exception
	 */
	public String doGet(String url, Map<String, Object> map) throws URISyntaxException, Exception {
		URIBuilder uriBuilder = new URIBuilder(url);
		if (map != null) {
			// 遍历map,拼接请求参数
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				uriBuilder.setParameter(entry.getKey(), entry.getValue().toString());
			}
		}
		// 调用不带参数的get请求
		return this.doGet(uriBuilder.build().toString());

	}
	

	/**
	 * 此接口使用连接池 带参数的post请求
	 * 
	 * @param url
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public String doPost(String url, JSONObject jsonParam) throws ServiceException {
		// 声明httpPost请求
		HttpPost httpPost = new HttpPost(url);
		// 加入配置信息
		httpPost.setConfig(config);
		JSONObject jsonResult = null;
		// 封装json
		if (null != jsonParam) {
			// 解决中文乱码问题
			StringEntity entity = new StringEntity(jsonParam.toString(), "utf-8");
			entity.setContentEncoding("UTF-8");
			entity.setContentType("application/json");
			httpPost.setEntity(entity);
		}

		CloseableHttpResponse response = null;
		String str = "";
		try {
			// 发起请求
			response = this.httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			String result = EntityUtils.toString(entity, "utf-8");
			// 关闭内容流和关闭响应之间的区别是：前者将尝试通过消耗实体内容来保持底层连接活动，而后者立即关闭并丢弃连接
			// 把底层的流给关闭了,可以看源码，
			EntityUtils.consume(entity);
			return result;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// 关闭响应,立即关闭并丢弃连接
				if (response != null)
					response.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * 此接口使用连接池 带参数的from表单post请求
	 * 
	 * @param url
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public String doFromPost(String url, Map<String, Object> map) throws ServiceException {
		// 声明httpPost请求
		HttpPost httpPost = new HttpPost(url);
		// 加入配置信息
		//httpPost.setConfig(config);
		JSONObject jsonResult = null;
		// 判断map是否为空，不为空则进行遍历，封装from表单对象
		if (map != null) {
			List<NameValuePair> list = new ArrayList<NameValuePair>();
			for (Map.Entry<String, Object> entry : map.entrySet()) {
				list.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
			}
			// 构造from表单对象
			UrlEncodedFormEntity urlEncodedFormEntity = null;
			try {
				urlEncodedFormEntity = new UrlEncodedFormEntity(list, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				logger.error("构造from表单对象异常",e);
				throw new ServiceException("doFromPost.exception");
			}
			// 把表单放到post里
			httpPost.setEntity(urlEncodedFormEntity);
		}

		CloseableHttpResponse response = null;
		try {
			// 发起请求
			response = this.httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			String result = EntityUtils.toString(entity, "utf-8");
			// 关闭内容流和关闭响应之间的区别是：前者将尝试通过消耗实体内容来保持底层连接活动，而后者立即关闭并丢弃连接
			// 把底层的流给关闭了,可以看源码，
			EntityUtils.consume(entity);
			return result;
		} catch (IOException e) {
			logger.error("doFromPost请求异常",e);
			throw new ServiceException("doFromPost.exception");
		} finally {
			try {
				// 关闭响应,立即关闭并丢弃连接
				if (response != null)
					response.close();
			} catch (IOException e) {
				logger.error("关闭响应异常",e);
				throw new ServiceException("doFromPost.exception");
			}
		}
	}

	/**
	 * 此接口使用连接池 不带参数post请求
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public String doPost(String url) throws Exception {
		return this.doPost(url, null);
	}
	
	/**
	 * 获取流的post的请求
	 * @param url
	 * @param jsonParam
	 * @return
	 * @throws ServiceException
	 */
	public byte[] doPostStream(String url, JSONObject jsonParam) throws ServiceException {
		
		logger.info("getMinProgramCode url== >" + url + "==paramJson==>"+JSON.toJSONString(jsonParam));
		
		// 声明httpPost请求
		HttpPost httpPost = new HttpPost(url);
		// 加入配置信息
		httpPost.setConfig(config);
		JSONObject jsonResult = null;
		// 封装json
		if (null != jsonParam) {
			// 解决中文乱码问题
			StringEntity entity = new StringEntity(jsonParam.toString(), "utf-8");
			entity.setContentType("application/json");
			entity.setContentEncoding(new BasicHeader("Content-Type", "UTF-8"));
			httpPost.setEntity(entity);
		}

		CloseableHttpResponse response = null;
		try {
			// 发起请求
			response = this.httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			
			if(!entity.getContentType().getValue().contains("image/jpeg")){
				String result = EntityUtils.toString(entity, "utf-8");
				// 关闭内容流和关闭响应之间的区别是：前者将尝试通过消耗实体内容来保持底层连接活动，而后者立即关闭并丢弃连接
				// 把底层的流给关闭了,可以看源码，
				EntityUtils.consume(entity);
				logger.error("生成二维码异常>>>>>>"+result);
//				if(result!=null && result.contains("40001")){
//					//token失效，重新获取
//					minTokenManager.getMustToken();
//				}
				return null;
			}
			
			InputStream instream = entity.getContent();
			ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
			int ch;
			try {
				while ((ch = instream.read()) != -1) {
					bytestream.write(ch);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				logger.error("doPostStream请求异常",e);
			}
			byte[] program = bytestream.toByteArray();

			EntityUtils.consume(entity);
			return program;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				// 关闭响应,立即关闭并丢弃连接
				if (response != null)
					response.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
}

