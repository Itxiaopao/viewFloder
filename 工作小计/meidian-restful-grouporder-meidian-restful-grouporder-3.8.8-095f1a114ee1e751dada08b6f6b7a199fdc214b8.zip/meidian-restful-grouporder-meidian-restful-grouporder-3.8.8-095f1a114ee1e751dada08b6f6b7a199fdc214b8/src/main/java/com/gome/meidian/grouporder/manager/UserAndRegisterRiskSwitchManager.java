package com.gome.meidian.grouporder.manager;

import com.gome.meidian.grouporder.utils.RequestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/15 11:16
 * @Description  用户中心管理风控开关
 */
@Service
public class UserAndRegisterRiskSwitchManager {

    private Logger logger = LoggerFactory.getLogger(getClass());


    @Resource(name = "userCenter")
    private Gcache userCenter;


    //1.登录场景-账号密码登录——WapMeidianLogin //已处理
    public   static  final String   RISK_SWITCH_WAP_MEIDIAN_LOGIN="Swicth_WapMeidianLogin";

    //2.登录场景-短信验证码登录——WapMeidianSmsLogin
    public  static  final String   RISK_SWITCH_WAP_MEIDIAN_SMS_LOGIN="Swicth_WapMeidianSmsLogin";

    //3.注册场景-注册——WapMeidianRegister //已处理
    public  static  final String   RISK_SWITCH_WAP_MEIDIAN_REGISTER="Swicth_WapMeidianRegister";

    //4.短信防刷场景-短信验证码登录短信防刷——WapMeidianSmsLogin //已处理
    public  static  final String   RISK_SWITCH_WAP_MEIDIAN_LOGIN_SMS="Swicth_WapMeidianLoginSms";

    //5.短信防刷场景-注册短信防刷——WapMeidianSmsLogin //已处理
    public  static  final String   RISK_SWITCH_WAP_MEIDIAN_REGISTER_SMS="Swicth_WapMeidianRegisterSms";

    //6.短信防刷场景-手机号绑定短信防刷——WapMeidianSmsLogin 已处理
    public  static  final String   RISK_SWITCH_WAP_MEIDIAN_MOBILE_SMS="Swicth_WapMeidianMobileSms";


    /**
     * 用户中心各场景风控开关开启关闭
     * @param riskKey
     * @param status
     * @param request
     * @return
     */
    public String riskSwitchOnOrOff(String riskKey,String status, HttpServletRequest request){
        String ip = RequestUtils.getIP(request);
        String statusStr = userCenter.get(riskKey);

        //取消开关
        if(statusStr != null && status.equals("2")){
            logger.info(" 用户中心各场景风控开关开启关闭------时间：" + new Date().toLocaleString() + ", IP：" + ip + ", 原值：" + statusStr);
            userCenter.del(riskKey);
            return status;
        }

        if(statusStr == null || !statusStr.equals(status)){
            logger.info(" 用户中心各场景风控开关开启关闭------时间：" + new Date().toLocaleString() + ", IP：" + ip + ", 原值：" + statusStr + ", 现值：" + status);
            userCenter.set(riskKey, status);
        }
        return status;
    }




}
