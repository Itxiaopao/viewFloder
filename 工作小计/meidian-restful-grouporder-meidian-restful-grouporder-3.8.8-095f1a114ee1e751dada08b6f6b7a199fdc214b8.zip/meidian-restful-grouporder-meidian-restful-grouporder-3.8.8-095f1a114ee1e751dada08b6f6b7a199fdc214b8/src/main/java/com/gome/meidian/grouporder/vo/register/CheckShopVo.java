package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class CheckShopVo implements Serializable {

	private static final long serialVersionUID = -4524473022345910309L;
	
	@NotBlank(message = "{shop.task.param.name.notBlank}")
	@Size(min=2,max=30,message="店铺名称长度必须在2-20之间")
	private String name;
	@NotBlank(message = "{base.user.mobile.notBlank}")
	private String phoneNo;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

}
