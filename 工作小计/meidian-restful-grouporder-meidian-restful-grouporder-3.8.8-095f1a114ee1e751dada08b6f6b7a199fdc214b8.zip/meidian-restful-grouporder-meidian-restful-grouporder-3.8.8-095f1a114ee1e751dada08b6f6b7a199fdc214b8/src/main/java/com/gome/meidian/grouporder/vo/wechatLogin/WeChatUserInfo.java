package com.gome.meidian.grouporder.vo.wechatLogin;

import java.io.Serializable;

/**
 * 微信对象
 */
public class WeChatUserInfo implements Serializable{

	private static final long serialVersionUID = 3560108593382399620L;
	
	private String nickname;//微信昵称
	private String openid;//微信openId
	private String unionid;//微信unionId
	private String headImageUrl;//微信头像

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getUnionid() {
		return unionid;
	}

	public void setUnionid(String unionid) {
		this.unionid = unionid;
	}

	public String getHeadImageUrl() {
		return headImageUrl;
	}

	public void setHeadImageUrl(String headImageUrl) {
		this.headImageUrl = headImageUrl;
	}

	@Override
	public String toString() {
		return "WeChatUserInfo{" +
				"nickname='" + nickname + '\'' +
				", openid='" + openid + '\'' +
				", unionid='" + unionid + '\'' +
				'}';
	}
}
