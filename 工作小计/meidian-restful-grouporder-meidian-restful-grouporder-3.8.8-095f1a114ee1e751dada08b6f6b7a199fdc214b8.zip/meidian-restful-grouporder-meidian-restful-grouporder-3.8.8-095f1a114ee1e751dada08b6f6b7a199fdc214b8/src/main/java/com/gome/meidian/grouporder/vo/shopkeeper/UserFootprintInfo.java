package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.Set;

/**
 * 用户足迹初始化
 * 
 * @author libinbin-ds
 *
 */
public class UserFootprintInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8836178932466863016L;
	/**
	 * 用户 ID
	 */
	private String userId;
	/**
	 * userNmae
	 */
	private String userName;
	/**
	 * 用户头像
	 */
	private String userImg;
	
	/**
	 * 商品 ID
	 */
	private String productId;
	/**
	 * SKU ID
	 */
	private String skuId;

	/**
	 * 商品名称
	 */
	private String productName;

	/**
	 *  商品URL
	 */
	private String productUrl;
	/**
	 * 上下架状态：1-上架，0-下架
	 */
	private int onShelf;
	/**
	 * 库存，可卖数：小于0时库存为空
	 */
	private long stockNum;
	/**
	 * 商品图片
	 */
	private String imgUrl;

	/**
	 * 商品价格
	 */
	private double price;
	/**
	 * 浏览日期
	 */
	private String visitDate;
	/**
	 * 一级品类名称 （当商品下架状态时可能为空）
	 */
	private String catName1;
	/**
	 * 二级品类名称 （当商品下架状态时可能为空）
	 */
	private String catName2;

	/**
	 * 用逗号分隔，里面是一天内该商品被重复浏览N次，在表中的游标。用于有删除需求时，将此值传过来
	 */
	private String hiddenFlag;

	/**
	 * 一天内该商品被重复看的次数
	 */
	private Integer reViewCount;
	
	/**
     * 区分浏览行为类型; 0为商品 | 1为活动
     */
    private int viewBehaviorType;

    /**
     * 活动类型 : 1:页面, 2.瓜分, 3.助力
     */
    private String activityType;	

    /**
     * 活动Id
     */
    private String activityId;	// 活动id
    private String activityName;	// 活动name
    private String attendDate;	// 参与时间
//    private Integer isAttendGroup;	// 是否已经参与 0: 未参与, 1: 参与
//    private String isAttendGroupStr;	// 是否已经参与 0:未参与, 1:参与
    private Integer isSuccessGroup;	// 是否已成团 0: 未成团, 1: 已成团
    private String isSuccessGroupStr;	// 是否已成团 0: 未成团, 1: 已成团
    private String headNickname;	// 团长匿名	
    private Long headUserId;	// 团长id
    private Integer groupType; //团类型（0：助力团，1：瓜分基础团，2：瓜分排名团）
    private Integer activityStatus;		// 状态  0: 以结束, 1:进行中
    private Long groupId;//团ID
    private String groupOrderId;//团ID

    /**
     * 商品标签
     */
    private Set<String> productLable;
    
    

	public String getGroupOrderId() {
		return groupOrderId;
	}

	public void setGroupOrderId(String groupOrderId) {
		this.groupOrderId = groupOrderId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Integer getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(Integer activityStatus) {
		this.activityStatus = activityStatus;
	}

	public Integer getGroupType() {
		return groupType;
	}

	public void setGroupType(Integer groupType) {
		this.groupType = groupType;
	}

	public String getHeadNickname() {
		return headNickname;
	}

	public void setHeadNickname(String headNickname) {
		this.headNickname = headNickname;
	}

	public Long getHeadUserId() {
		return headUserId;
	}

	public void setHeadUserId(Long headUserId) {
		this.headUserId = headUserId;
	}

	
//	public Integer getIsAttendGroup() {
//		return isAttendGroup;
//	}
//
//	public void setIsAttendGroup(Integer isAttendGroup) {
//		this.isAttendGroup = isAttendGroup;
//	}
//
//	public String getIsAttendGroupStr() {
//		return isAttendGroupStr;
//	}
//
//	public void setIsAttendGroupStr(String isAttendGroupStr) {
//		this.isAttendGroupStr = isAttendGroupStr;
//	}

	public Integer getIsSuccessGroup() {
		return isSuccessGroup;
	}

	public void setIsSuccessGroup(Integer isSuccessGroup) {
		this.isSuccessGroup = isSuccessGroup;
	}

	public String getIsSuccessGroupStr() {
		return isSuccessGroupStr;
	}

	public void setIsSuccessGroupStr(String isSuccessGroupStr) {
		this.isSuccessGroupStr = isSuccessGroupStr;
	}

	public String getAttendDate() {
		return attendDate;
	}

	public void setAttendDate(String attendDate) {
		this.attendDate = attendDate;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public int getViewBehaviorType() {
		return viewBehaviorType;
	}

	public void setViewBehaviorType(int viewBehaviorType) {
		this.viewBehaviorType = viewBehaviorType;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public Set<String> getProductLable() {
		return productLable;
	}

	public void setProductLable(Set<String> productLable) {
		this.productLable = productLable;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductUrl() {
		return productUrl;
	}

	public void setProductUrl(String productUrl) {
		this.productUrl = productUrl;
	}

	public int getOnShelf() {
		return onShelf;
	}

	public void setOnShelf(int onShelf) {
		this.onShelf = onShelf;
	}

	public long getStockNum() {
		return stockNum;
	}

	public void setStockNum(long stockNum) {
		this.stockNum = stockNum;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getVisitDate() {
		return visitDate;
	}

	public void setVisitDate(String visitDate) {
		this.visitDate = visitDate;
	}

	public String getCatName1() {
		return catName1;
	}

	public void setCatName1(String catName1) {
		this.catName1 = catName1;
	}

	public String getCatName2() {
		return catName2;
	}

	public void setCatName2(String catName2) {
		this.catName2 = catName2;
	}

	public String getHiddenFlag() {
		return hiddenFlag;
	}

	public void setHiddenFlag(String hiddenFlag) {
		this.hiddenFlag = hiddenFlag;
	}

	public Integer getReViewCount() {
		return reViewCount;
	}

	public void setReViewCount(Integer reViewCount) {
		this.reViewCount = reViewCount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getUserImg() {
		return userImg;
	}

	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}
	
	
}
