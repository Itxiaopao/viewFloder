package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

/**
 * 团信息
 * @author shichangjian
 *
 */
public class Group implements Serializable{

	private static final long serialVersionUID = 1525587435828508657L;

	private Long groupId; 						// 团id
	private Integer currentMemberNum; 			// 团成员人数
	private Boolean accomplishGroup;			// 是否成团
	private Integer groupStatus;				// 团状态 
	private Integer groupBusType;;				// 团类型 
	
	public Group() {
		super();
	}
	public Group(Long groupId, Integer currentMemberNum, Boolean accomplishGroup, 
			Integer groupStatus, Integer groupBusType) {
		super();
		this.groupId = groupId;
		this.currentMemberNum = currentMemberNum;
		this.accomplishGroup = accomplishGroup;
		this.groupStatus = groupStatus;
		this.groupBusType = groupBusType;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Integer getCurrentMemberNum() {
		return currentMemberNum;
	}
	public void setCurrentMemberNum(Integer currentMemberNum) {
		this.currentMemberNum = currentMemberNum;
	}
	public Boolean getAccomplishGroup() {
		return accomplishGroup;
	}
	public void setAccomplishGroup(Boolean accomplishGroup) {
		this.accomplishGroup = accomplishGroup;
	}
	public Integer getGroupStatus() {
		return groupStatus;
	}
	public void setGroupStatus(Integer groupStatus) {
		this.groupStatus = groupStatus;
	}
	public Integer getGroupBusType() {
		return groupBusType;
	}
	public void setGroupBusType(Integer groupBusType) {
		this.groupBusType = groupBusType;
	}
	
	
}
