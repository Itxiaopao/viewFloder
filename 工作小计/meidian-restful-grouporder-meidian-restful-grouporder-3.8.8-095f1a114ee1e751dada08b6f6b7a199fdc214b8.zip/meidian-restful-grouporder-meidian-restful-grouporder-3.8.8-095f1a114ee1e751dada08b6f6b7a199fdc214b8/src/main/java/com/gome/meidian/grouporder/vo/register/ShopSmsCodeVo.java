package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class ShopSmsCodeVo implements Serializable {

	private static final long serialVersionUID = -8835994844412291613L;
	
	@NotBlank(message = "{base.user.mobile.notBlank}")
	private String mobile;//用户手机号
	@NotBlank(message = "{base.user.smsCode.notBlank}")
	private String smsCode;//短信验证码
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getSmsCode() {
		return smsCode;
	}
	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}
	
}
