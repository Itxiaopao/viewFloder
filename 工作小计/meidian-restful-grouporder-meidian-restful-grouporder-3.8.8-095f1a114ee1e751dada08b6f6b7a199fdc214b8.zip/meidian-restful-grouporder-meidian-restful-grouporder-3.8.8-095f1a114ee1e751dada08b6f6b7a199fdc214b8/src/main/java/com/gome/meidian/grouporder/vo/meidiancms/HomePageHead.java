package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;

public class HomePageHead implements Serializable{

	private static final long serialVersionUID = -8649569131483236503L;

	private String bsCode;		// 业务code 该头部导航归属于那个业务, 方便后期管理, 门店首页默认 bsCode = b_mshop
	private String headName;	// 导航名称
	private String pageCode;	// 绑定:页面code
	
	public HomePageHead() {
		super();
	}
	public HomePageHead(String bsCode, String headName, String pageCode) {
		super();
		this.bsCode = bsCode;
		this.headName = headName;
		this.pageCode = pageCode;
	}
	public String getBsCode() {
		return bsCode;
	}
	public void setBsCode(String bsCode) {
		this.bsCode = bsCode;
	}
	public String getHeadName() {
		return headName;
	}
	public void setHeadName(String headName) {
		this.headName = headName;
	}
	public String getPageCode() {
		return pageCode;
	}
	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}
	
	
}
