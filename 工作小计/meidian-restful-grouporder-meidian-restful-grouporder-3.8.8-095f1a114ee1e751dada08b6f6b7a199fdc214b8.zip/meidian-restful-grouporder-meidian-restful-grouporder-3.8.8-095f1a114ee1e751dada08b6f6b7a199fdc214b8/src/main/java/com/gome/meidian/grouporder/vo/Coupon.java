package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 优惠券
 * @author shichangjian
 *
 */
public class Coupon implements Serializable{

	private static final long serialVersionUID = 5374291698010539305L;
	
    private String coupon_id;		//优惠券规则id
    private String plan_id;			//优惠券方案id
    private String encryptionId;	//加密id
    private Double coupon_num;		//劵面额
    private String description;		//券描述
    private Double fullAmount;		//限额  满多少元可用
    private String get_start_time;	//券开始领取时间
    private String get_end_time;	//券领取结束时间
    private String show_start_time;	//券展示开始时间
    private String show_end_time;	//券展示结束时间
    private String couponType;  	//类型 3001:美券  3002:蓝券  3003:红券  0：店铺劵(pop)   2：pop-平台劵(pop)
	private String activeId;        //pop券领取标识，劵活动id
	private Integer validity;        //券有效期
	
	
	
	public Coupon() {
		super();
	}
	public Coupon(String coupon_id, String plan_id, Double coupon_num, 
			String description, Double fullAmount, String get_start_time, 
			String get_end_time, String show_start_time, String show_end_time, 
			String couponType, String activeId,Integer validity) {
		super();
		this.coupon_id = coupon_id;
		this.plan_id = plan_id;
		this.coupon_num = coupon_num;
		this.description = description;
		this.fullAmount = fullAmount;
		this.get_start_time = get_start_time;
		this.get_end_time = get_end_time;
		this.show_start_time = show_start_time;
		this.show_end_time = show_end_time;
		this.couponType = couponType;
		this.activeId = activeId;
		this.validity = validity;
	}
	public String getCoupon_id() {
		return coupon_id;
	}
	public void setCoupon_id(String coupon_id) {
		this.coupon_id = coupon_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getGet_start_time() {
		return get_start_time;
	}
	public void setGet_start_time(String get_start_time) {
		this.get_start_time = get_start_time;
	}
	public String getGet_end_time() {
		return get_end_time;
	}
	public void setGet_end_time(String get_end_time) {
		this.get_end_time = get_end_time;
	}
	public String getShow_start_time() {
		return show_start_time;
	}
	public void setShow_start_time(String show_start_time) {
		this.show_start_time = show_start_time;
	}
	public String getShow_end_time() {
		return show_end_time;
	}
	public void setShow_end_time(String show_end_time) {
		this.show_end_time = show_end_time;
	}
	public Double getCoupon_num() {
		return coupon_num;
	}
	public void setCoupon_num(Double coupon_num) {
		this.coupon_num = coupon_num;
	}
	public Double getFullAmount() {
		return fullAmount;
	}
	public void setFullAmount(Double fullAmount) {
		this.fullAmount = fullAmount;
	}
	public String getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(String plan_id) {
		this.plan_id = plan_id;
	}
	public String getCouponType() {
		return couponType;
	}
	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}
	public String getActiveId() {
		return activeId;
	}
	public void setActiveId(String activeId) {
		this.activeId = activeId;
	}
	public String getEncryptionId() {
		return encryptionId;
	}
	public void setEncryptionId(String encryptionId) {
		this.encryptionId = encryptionId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Integer getValidity() {
		return validity;
	}
	public void setValidity(Integer validity) {
		this.validity = validity;
	}
    
    
}
