package com.gome.meidian.grouporder.vo.homePage;

import com.gome.meidian.grouporder.vo.ProductDetailVo;

public class WanrenProductDetailVo extends ProductDetailVo{

	private static final long serialVersionUID = -6657367988183414495L;
	private CollectionProductInfoVo collInfo;
	public CollectionProductInfoVo getCollInfo() {
		return collInfo;
	}
	public void setCollInfo(CollectionProductInfoVo collInfo) {
		this.collInfo = collInfo;
	}
	
}
