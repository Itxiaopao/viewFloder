package com.gome.meidian.grouporder.vo.carveUp.carveUpActivity;

import java.io.Serializable;
import java.util.Date;

/**
 * 瓜分团活动信息
 */
public class CarveUpActivityInfoVo implements Serializable {

	private static final long serialVersionUID = 4885003867243866422L;

//	private String name; //瓜分活动名称
	private Long startTime; //开始时间
	private Long endTime; //结束时间
//	private String hyperLinks; //图片跳转链接
	private String imageUrl; //图片地址
	private Long id; //瓜分活动所属活动ID
//	private String carveName; //活动名称
//	private Integer carveMinNewNum; //最低新用户人数
	private Integer carveBaseNum; //达标人数',--团
	private Integer carveGroupType; //瓜分团类型：1：基础团，2：排名团--奖励定额，3：排名团--奖励瓜分
	private Double newInitialFixMoney; //开团者返利基数国美币（元）--固定金额 乘以 团内新人数量，不含自己
	private Double oldInitialFixMoney; //开团者返利基数国美币（元）--固定金额 乘以 团内老人数量，不含自己
	private String activityImageUrl; //活动图标

//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}
	public Long getEndTime() {
		return endTime;
	}
	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}
//	public String getHyperLinks() {
//		return hyperLinks;
//	}
//	public void setHyperLinks(String hyperLinks) {
//		this.hyperLinks = hyperLinks;
//	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

//	public String getCarveName() {
//		return carveName;
//	}
//	public void setCarveName(String carveName) {
//		this.carveName = carveName;
//	}
//	public Integer getCarveMinNewNum() {
//		return carveMinNewNum;
//	}
//	public void setCarveMinNewNum(Integer carveMinNewNum) {
//		this.carveMinNewNum = carveMinNewNum;
//	}
	public Integer getCarveBaseNum() {
		return carveBaseNum;
	}
	public void setCarveBaseNum(Integer carveBaseNum) {
		this.carveBaseNum = carveBaseNum;
	}

	public Integer getCarveGroupType() {
		return carveGroupType;
	}

	public void setCarveGroupType(Integer carveGroupType) {
		this.carveGroupType = carveGroupType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public Double getOldInitialFixMoney() {
		return oldInitialFixMoney;
	}
	public void setOldInitialFixMoney(Double oldInitialFixMoney) {
		this.oldInitialFixMoney = oldInitialFixMoney;
	}
	public Double getNewInitialFixMoney() {
		return newInitialFixMoney;
	}
	public void setNewInitialFixMoney(Double newInitialFixMoney) {
		this.newInitialFixMoney = newInitialFixMoney;
	}
	public String getActivityImageUrl() {
		return activityImageUrl;
	}
	public void setActivityImageUrl(String activityImageUrl) {
		this.activityImageUrl = activityImageUrl;
	}
}
