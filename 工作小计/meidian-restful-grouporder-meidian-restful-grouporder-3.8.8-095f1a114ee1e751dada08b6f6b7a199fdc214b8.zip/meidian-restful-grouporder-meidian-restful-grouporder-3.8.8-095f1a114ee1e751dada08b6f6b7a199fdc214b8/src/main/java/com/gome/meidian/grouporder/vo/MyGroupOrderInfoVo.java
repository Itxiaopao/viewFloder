package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.Date;

public class MyGroupOrderInfoVo implements Serializable {

	private static final long serialVersionUID = -6224014524523018590L;
	private Long id;
	private Long groupId;
	private Long activityId;
	private Float maxDiscount;
	private Integer maxPeopleNum;//最高折扣需要的人数
	private Float currentDiscount;
	private Float nextDiscount;
	private Integer nextDtNeedPeopleNum;
	private Integer status;
	private Long userId;
	private String orderId;
	private String deliveryOrderId;
	private String skuNo;
	private Integer buyNumber;
	private Date startTime;
	private Date endTime;
	private Object shipOrder;
	private Integer currentPeopleNum;
	private Integer groupBusType;    //组团业务类型：1:常规返利,2:团长免单,3:0元团,4:开团有奖,5:官方多人团,6:5折开团,7:定金团,8:阶梯优惠团,9:新人团,10:秒杀团
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Float getCurrentDiscount() {
		return currentDiscount;
	}
	public void setCurrentDiscount(Float currentDiscount) {
		this.currentDiscount = currentDiscount;
	}
	public Float getNextDiscount() {
		return nextDiscount;
	}
	public void setNextDiscount(Float nextDiscount) {
		this.nextDiscount = nextDiscount;
	}
	public Integer getNextDtNeedPeopleNum() {
		return nextDtNeedPeopleNum;
	}
	public void setNextDtNeedPeopleNum(Integer nextDtNeedPeopleNum) {
		this.nextDtNeedPeopleNum = nextDtNeedPeopleNum;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryOrderId() {
		return deliveryOrderId;
	}
	public void setDeliveryOrderId(String deliveryOrderId) {
		this.deliveryOrderId = deliveryOrderId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public Integer getBuyNumber() {
		return buyNumber;
	}
	public void setBuyNumber(Integer buyNumber) {
		this.buyNumber = buyNumber;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Object getShipOrder() {
		return shipOrder;
	}
	public void setShipOrder(Object shipOrder) {
		this.shipOrder = shipOrder;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Float getMaxDiscount() {
		return maxDiscount;
	}
	public void setMaxDiscount(Float maxDiscount) {
		this.maxDiscount = maxDiscount;
	}
	public Integer getMaxPeopleNum() {
		return maxPeopleNum;
	}
	public void setMaxPeopleNum(Integer maxPeopleNum) {
		this.maxPeopleNum = maxPeopleNum;
	}
	public Integer getCurrentPeopleNum() {
		return currentPeopleNum;
	}
	public void setCurrentPeopleNum(Integer currentPeopleNum) {
		this.currentPeopleNum = currentPeopleNum;
	}

	public Integer getGroupBusType() {
		return groupBusType;
	}

	public void setGroupBusType(Integer groupBusType) {
		this.groupBusType = groupBusType;
	}
}
