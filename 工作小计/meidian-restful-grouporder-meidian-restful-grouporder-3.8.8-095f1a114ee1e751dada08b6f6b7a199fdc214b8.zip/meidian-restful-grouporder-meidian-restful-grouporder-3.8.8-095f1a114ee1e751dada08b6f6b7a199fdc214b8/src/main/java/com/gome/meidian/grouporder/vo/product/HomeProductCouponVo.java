package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.Slot;

/**
 * 主页中的立减活动页
 * @author shichangjian
 *
 */
public class HomeProductCouponVo implements Serializable{

	private static final long serialVersionUID = 5270239060633467986L;

	private Slot slot;
	private String ukey;
	private List<Product> products;		// 商品信息
	
	public Slot getSlot() {
		return slot;
	}
	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	public String getUkey() {
		return ukey;
	}
	public void setUkey(String ukey) {
		this.ukey = ukey;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	
	
}
