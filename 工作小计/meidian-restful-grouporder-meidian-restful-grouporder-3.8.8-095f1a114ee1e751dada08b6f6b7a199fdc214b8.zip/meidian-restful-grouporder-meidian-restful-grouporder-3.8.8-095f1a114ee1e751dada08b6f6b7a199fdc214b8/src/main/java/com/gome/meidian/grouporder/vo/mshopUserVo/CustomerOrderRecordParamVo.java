package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class CustomerOrderRecordParamVo implements Serializable{

	private static final long serialVersionUID = 3990090021211507338L;
	@NotBlank(message = "{param.error}")
	private String userId;
	@NotBlank(message = "{param.error}")
	private String dateState;
	@NotNull(message = "{param.error}")
	private Integer pageNo;
	@NotNull(message = "{param.error}")
	private Integer pageSize;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDateState() {
		return dateState;
	}
	public void setDateState(String dateState) {
		this.dateState = dateState;
	}
	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	
	

}
