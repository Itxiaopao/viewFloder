package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.mshopUserManager.MshopHomePageManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

import lombok.extern.slf4j.Slf4j;

/**
 * 美店主页面控制层
 * @author lishouxu-ds
 *
 */

@RestController
@RequestMapping("/mshopUser/homePage")
public class MshopHomePageController {

    private Logger logger = LoggerFactory.getLogger(getClass());
    
    
	@Autowired
	private AuthencationUtils authencationUtils;
	@Autowired
	private MshopHomePageManager mshopHomePageManager;
	
	/**
	 * 查询用户的整体收益信息（楼层一）
	 * @param scn
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getTotalProfit", method = RequestMethod.GET)
	public ResponseJson<Map<String,Long>> getTotalProfit(
			@CookieValue(value = "SCN", required = false) String scn, 
			HttpServletRequest request
			)throws MeidianException{
		ResponseJson<Map<String,Long>> response = new ResponseJson<Map<String,Long>>();
		Map<String,Long> map = new HashMap<String,Long>();
		map.put("totalIncome", 0L);
		map.put("accountBalance", 0L);
		map.put("todayExpectIncome", 0L);	
		map.put("login", 1L);
		//modify by lsx begin 2020.4.23
		map.put("expectIncome", 0L);
		map.put("downgrade", 0L);
		//modify by lsx end 2020.4.23
		
		
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(userId == null){
			map.put("login", 0L);
			response.setData(map);
			return response;
		}
		map = mshopHomePageManager.getTotalProfit(userId);
		response.setData(map);
		return response;
	}
	
	
    /**
     * 首页查询用户的收益信息
     * @param scn
     * @param request
     * @return
     * @throws MeidianException
     */
	@RequestMapping(value = "/getProfit", method = RequestMethod.GET)
	public ResponseJson<Map<String,Object>> getProfit(
			@CookieValue(value = "SCN", required = false) String scn, 
			@RequestParam(value = "dimension", required = true)String dimension,
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson<Map<String,Object>> response = new ResponseJson<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("orderNum", 0L);
		map.put("salesAmount", 0L);
		map.put("expectIncome", 0L);
		map.put("login", 1L);
		String userId = authencationUtils.authenticationLogin(scn);
		if(userId == null){
			map.put("login", 0L);
			response.setData(map);
			return response;
		}
		map = mshopHomePageManager.getProfit(userId,dimension);
		response.setData(map);
		return response;
	}
    /**
     * 获取微信用户信息
     * @param scn
     * @param request
     * @return
     * @throws MeidianException
     */
	@RequestMapping(value = "/getUserInfo", method = RequestMethod.GET)
	public ResponseJson<Map<String,Object>> getUserInfo(
			@CookieValue(value = "SCN", required = false) String scn, 
			HttpServletRequest request
			)throws MeidianException{
		ResponseJson<Map<String,Object>> response = new ResponseJson<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("invitationCode", null);
		map.put("imagePath", null);
		map.put("nickName", null);
		map.put("userIdentity", null);
		map.put("mshopUserNum", 0L);
		map.put("totalSalesAmount", 0L);
		map.put("consumerCount", 0L);
		map.put("login", 1L);
		map.put("stid", "");
		map.put("userId", "");
		map.put("organizationId", "");
		
//		map.put("invitationCode", "yaoqingma");
//		map.put("imagePath", "http://gfs11.atguat.net.cn/T1VaVTByh_1RCvBVdK.jpeg");
//		map.put("nickName", "给你接口了");
//		map.put("userIdentity", "1");
//		map.put("mshopUserNum", 0L);
//		map.put("totalSalesAmount", 0L);
//		map.put("consumerCount", 0L);
		
		String userId = authencationUtils.authenticationLogin(scn);
		
		if(userId == null){
			map.put("login", 0L);
			response.setData(map);
			return response;
		}
		map = mshopHomePageManager.getUserInfo(userId);
		map.put("login", 1L);
		response.setData(map);
		return response;
	}

  
}
