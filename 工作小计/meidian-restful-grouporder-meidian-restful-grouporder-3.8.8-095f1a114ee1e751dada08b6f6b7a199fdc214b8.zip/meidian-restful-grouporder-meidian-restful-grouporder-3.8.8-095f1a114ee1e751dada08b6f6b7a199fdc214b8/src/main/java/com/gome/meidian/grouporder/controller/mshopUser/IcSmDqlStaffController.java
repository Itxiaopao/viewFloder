package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.UUID;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.mq.HandlerEmployMQProducer;
import com.gome.meidian.grouporder.vo.mshopUserVo.IcSmDqlStaffVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import lombok.extern.slf4j.Slf4j;

/**
 * @author limenghui-ds
 * @create 2019-11-27 10:59
 * 销售排行榜
 */
@RestController
@Validated
@Slf4j
@RequestMapping("/icSmDqlStaff")
public class IcSmDqlStaffController {
    @Autowired
    private IUserShareBindingManager userShareBindingManager;

    @Value("${rocketmq.producer2.topic}")
    private String TOPIC_EMPLOY;

    /**
     * 处理入职或者离职的员工
     * @param icSmDqlStaffVo
     */
    @PostMapping(value = "/handlerDqlStaff")
    public Object handlerDqlStaff(@Valid @RequestBody IcSmDqlStaffVo icSmDqlStaffVo) throws ServiceException {
        if (icSmDqlStaffVo.getStatus().intValue() != 0 && null == icSmDqlStaffVo.getMid()) {
            return new ResponseJson<>(500, "非离职状态下mid不能为空");
        }
        if (icSmDqlStaffVo.getStatus().intValue() == 2 && (null == icSmDqlStaffVo.getStoreCode() || null == icSmDqlStaffVo.getOrgCode())) {
            return new ResponseJson<>(500, "切换门店门店和销售组织编码不能为空");
        }
        //mq发送消息
        String messageBody= JSON.toJSONString(icSmDqlStaffVo);
        String messageKey = UUID.randomUUID().toString();
        try {
            SendResult result = HandlerEmployMQProducer.sendMessageSelectQueue(TOPIC_EMPLOY, null, messageKey, messageBody,String.valueOf(icSmDqlStaffVo.getUserId()));
            log.info("MQProducer 消息发送成功！msgId:{},topic:{},key:{}，消息内容 {} ", result.getMsgId(), TOPIC_EMPLOY, messageKey, messageBody);
        } catch (MQClientException e) {
            log.error("MQProducer 消息发送失败！失败原因:{},topic:{},key:{}", e, TOPIC_EMPLOY, messageKey);
            throw new ServiceException(e);
        }
        return new ResponseJson<>(200,"接口调用成功");
    }
}
