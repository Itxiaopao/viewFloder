package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;

public class MyGroupHelpInfo implements Serializable {

	private static final long serialVersionUID = -2125273544785918573L;
	private Long id; //id
	private Long groupId; //团id 
	private Long activityId; //商品集id
	private Long userId; //被助力者userId（团成员userId）
	private Integer attendUserNum; //参与助力总人数
	private Integer oldUserNum; //参与助力老用户人数
	private Integer newUserNum; //参与助力新用户人数
	private Long orderMemberId; //被助力者memberId
	private String orderId; //订单ID
	private String deliveryOrderId; //配送单id
	private Integer helpIsSucess; //助力是否达标 0:未达标，1:已达标
	private Integer isSucess; //用户是否中奖 0:未中奖，1:中奖
	private String nickName;//昵称
	private String image;//头像
	private Long sort;//排名
	private Integer needNewUserHelp;//需要新人助力条目
	private Integer needSumUserHelp;//需要用户总人数助力条目
	private String myBonus;//我的奖金
	private String helpBonus;//助力用户奖金
	private String helpState;//助力状态 0:可以分享 ，1：助力成功，2：团结束，3：用户产生逆向单
	private Integer helpMinTotalNum;// 助力最低总人数
	private Integer helpMinNewNum;// 助力最低新用户人数
	//优惠券信息
	private List<GroupUserInfo> helpUserList;//助力成员
    private List<HelpGroupCouponVo> couponList; //奖励的券信息
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Integer getAttendUserNum() {
		return attendUserNum;
	}
	public void setAttendUserNum(Integer attendUserNum) {
		this.attendUserNum = attendUserNum;
	}
	public Integer getOldUserNum() {
		return oldUserNum;
	}
	public void setOldUserNum(Integer oldUserNum) {
		this.oldUserNum = oldUserNum;
	}
	public Integer getNewUserNum() {
		return newUserNum;
	}
	public void setNewUserNum(Integer newUserNum) {
		this.newUserNum = newUserNum;
	}
	public Long getOrderMemberId() {
		return orderMemberId;
	}
	public void setOrderMemberId(Long orderMemberId) {
		this.orderMemberId = orderMemberId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryOrderId() {
		return deliveryOrderId;
	}
	public void setDeliveryOrderId(String deliveryOrderId) {
		this.deliveryOrderId = deliveryOrderId;
	}
	public Integer getHelpIsSucess() {
		return helpIsSucess;
	}
	public void setHelpIsSucess(Integer helpIsSucess) {
		this.helpIsSucess = helpIsSucess;
	}
	public Integer getIsSucess() {
		return isSucess;
	}
	public void setIsSucess(Integer isSucess) {
		this.isSucess = isSucess;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public Long getSort() {
		return sort;
	}
	public void setSort(Long sort) {
		this.sort = sort;
	}
	public Integer getNeedNewUserHelp() {
		return needNewUserHelp;
	}
	public void setNeedNewUserHelp(Integer needNewUserHelp) {
		this.needNewUserHelp = needNewUserHelp;
	}
	public Integer getNeedSumUserHelp() {
		return needSumUserHelp;
	}
	public void setNeedSumUserHelp(Integer needSumUserHelp) {
		this.needSumUserHelp = needSumUserHelp;
	}
	public String getMyBonus() {
		return myBonus;
	}
	public void setMyBonus(String myBonus) {
		this.myBonus = myBonus;
	}
	public String getHelpBonus() {
		return helpBonus;
	}
	public void setHelpBonus(String helpBonus) {
		this.helpBonus = helpBonus;
	}
	public String getHelpState() {
		return helpState;
	}
	public void setHelpState(String helpState) {
		this.helpState = helpState;
	}
	public Integer getHelpMinTotalNum() {
		return helpMinTotalNum;
	}
	public void setHelpMinTotalNum(Integer helpMinTotalNum) {
		this.helpMinTotalNum = helpMinTotalNum;
	}
	public Integer getHelpMinNewNum() {
		return helpMinNewNum;
	}
	public void setHelpMinNewNum(Integer helpMinNewNum) {
		this.helpMinNewNum = helpMinNewNum;
	}
	public List<GroupUserInfo> getHelpUserList() {
		return helpUserList;
	}
	public void setHelpUserList(List<GroupUserInfo> helpUserList) {
		this.helpUserList = helpUserList;
	}
	public List<HelpGroupCouponVo> getCouponList() {
		return couponList;
	}
	public void setCouponList(List<HelpGroupCouponVo> couponList) {
		this.couponList = couponList;
	}
	
}
