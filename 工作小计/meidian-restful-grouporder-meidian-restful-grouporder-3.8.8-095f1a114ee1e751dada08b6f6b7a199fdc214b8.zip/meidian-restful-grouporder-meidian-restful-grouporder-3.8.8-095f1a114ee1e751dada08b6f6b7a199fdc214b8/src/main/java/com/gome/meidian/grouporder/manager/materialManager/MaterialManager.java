package com.gome.meidian.grouporder.manager.materialManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.velocity.runtime.directive.Foreach;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReq;
import com.gome.meidian.grouporder.vo.grouporderVo.HomePageActivity;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.materialVo.ActivityMaterialProductVo;
import com.gome.meidian.grouporder.vo.materialVo.ActivityMaterialVo;
import com.gome.meidian.grouporder.vo.materialVo.ProductMaterialVo;
import com.gome.meidian.grouporder.vo.product.ProductInfo;
import com.gome.meidian.product.entity.MaterialShare;
import com.gome.meidian.product.entity.ProductBaseInfo;
import com.gome.meidian.product.manager.IMaterialShareManager;
import com.gome.meidian.product.manager.IProductBaseInfoManager;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gomeplus.bs.interfaces.cms2.enums.CmsItemSkipType;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.Material;

@Service
public class MaterialManager {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private final String PRODUCT_BASE_KEY = "product.base.key.";
	
	@Autowired
	private PropertiesConfig propertiesConfig;
	@Autowired
	private IMaterialShareManager iMaterialShareManager;
	@Autowired
	private IProductBaseInfoManager iProductBaseInfoManager;
	@Autowired
	private HomeProductsManager homeProductsManager;
	
    @Autowired
    private PageInfoResource pageInfoResource;


    /**
     * 万人团素材分页
     * @param storeCode
     * @param moduleCode
     * @param pageCode
     * @param pageNo
     * @param pageSize
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException 
     */
    public Map<String, Object> thousandGroupMaterials(String storeCode, String moduleCode, String pageCode, 
    		int pageNo, int pageSize, String areaCode, 
    		Integer ppi, Byte ua) throws ServiceException{
    	
    	Map<String, Object> restMap = this.productMaterial(storeCode, moduleCode, pageCode, 
        		pageNo, pageSize, areaCode, 
        		ppi, ua);
    	
    	return restMap;
    }
    
    /**
     * 助力团素材分页
     * @param storeCode
     * @param moduleCode
     * @param pageCode
     * @param pageNo
     * @param pageSize
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException 
     */
    public Map<String, Object> helpGroupMaterials(String storeCode, String moduleCode, String pageCode, 
    		int pageNo, int pageSize, String areaCode, 
    		Integer ppi, Byte ua) throws ServiceException{
    	
    	Map<String, Object> restMap = this.productMaterial(storeCode, moduleCode, pageCode, 
        		pageNo, pageSize, areaCode, 
        		ppi, ua);
    	
    	return restMap;
    }
    
    /**
     * 活动素材分页
     * @param storeCode
     * @param moduleCode
     * @param pageCode
     * @param pageNo
     * @param pageSize
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     */
    public Map<String, Object> activityMaterials(String storeCode, String moduleCode, String pageCode, 
    		int pageNo, int pageSize){
    	
    	Map<String, Object> restMap = new HashMap<String, Object>();
    	
    	List<ActivityMaterialVo> activityMaterialVos = new ArrayList<ActivityMaterialVo>();
    	List<String> acCodes = new ArrayList<String>();
    	
    	// 1,cms接口
    	List<Material> materials = pageInfoResource.moduleMaterialList(storeCode, moduleCode, pageCode, Long.valueOf(pageNo), Long.valueOf(pageSize));
    	//System.err.println(JSON.toJSON(materials));
    	if(null == materials || materials.size() == 0) {
    		// 判断分页是否到底,0:结束，1：未结束
        	restMap.put("pageEnd", 0);
        	restMap.put("activityMaterialVos", activityMaterialVos);
        	return restMap;
    	}
    	
    	//CmsItemSkipType
    	for (Material material : materials) {
			if(null == material) continue;
			if(null == material.getSkipType()) continue;
			int skipType = material.getSkipType();
			
			// 扩展字段
			String shareUrl = null;
			String expande = material.getExpanded1();
			if(StringUtils.isNotBlank(expande)){
				String exp = expande.replace(" ","");
				String urls[] = exp.split("__");
				shareUrl = urls[0];
			}
			
			String activityCode = material.getActivityMaterialID();
			if(StringUtils.isEmpty(activityCode)){
				activityCode = material.getCode() + "_item2";
			}
			
			MaterialShare materialShare = JSONObject.parseObject(propertiesConfig.getUserCenter().hget("productServiceMaterialShareNum", activityCode), MaterialShare.class);
			
			//如果是活动页配置
			if(CmsItemSkipType.ACTIVITY_MATERIAL.getType().intValue() == skipType){
				ActivityMaterialVo activityMaterialVo = new ActivityMaterialVo();
				activityMaterialVo.setShareUrl(shareUrl);
				activityMaterialVo.setMaterialShareNum(0l);
				 // 2,获取素材分享次数

		        
		        if(null != materialShare)
		        	activityMaterialVo.setMaterialShareNum(materialShare.getShareNum());
		        else{
		        	acCodes.add(activityCode);
		        }
		        
		        activityMaterialVo.setActivityCode(activityCode);
		        activityMaterialVo.setSkipType(2);
		        activityMaterialVo.setMaterialDes(material.getRecordActivity());
		        activityMaterialVo.setProposal(material.getTips());
		        List<String> images = new ArrayList<String>();
		        images.add(0, material.getPosterImgUrl());
		        activityMaterialVo.setMaterialImages(images);
		        activityMaterialVos.add(activityMaterialVo);
			}else if(CmsItemSkipType.PRE_SALE.getType().intValue() == skipType || CmsItemSkipType.PRODUCT.getType().intValue() == skipType || CmsItemSkipType.CASHBACK.getType().intValue() == skipType ){
				//预售、商品、超级返
				ActivityMaterialProductVo activityMaterialProductVo = new ActivityMaterialProductVo();
				activityMaterialProductVo.setShareUrl(shareUrl);
				activityMaterialProductVo.setMaterialShareNum(0l);
		        if(null != materialShare)
		        	activityMaterialProductVo.setMaterialShareNum(materialShare.getShareNum());
		        else{
		        	acCodes.add(activityCode);
		        }
		        
		        activityMaterialProductVo.setActivityCode(activityCode);
				activityMaterialProductVo.setSkipType(5);
				activityMaterialProductVo.setSkuId(material.getSkuId());
				
				activityMaterialProductVo.setMaterialDes(material.getRecordActivity());
				activityMaterialProductVo.setProposal(material.getTips());
		        List<String> images = new ArrayList<String>();
		        images.add(0, material.getPosterImgUrl());
		        activityMaterialProductVo.setMaterialImages(images);
		        activityMaterialProductVo.setProductId(material.getProductId());
				
				activityMaterialVos.add(activityMaterialProductVo);
			}else if(CmsItemSkipType.ZUTUAN.getType().intValue() == skipType ){
				ActivityMaterialProductVo activityMaterialProductVo = new ActivityMaterialProductVo();
				activityMaterialProductVo.setShareUrl(shareUrl);
				activityMaterialProductVo.setMaterialShareNum(0l);
				activityMaterialProductVo.setProductId(material.getProductId());
				
		        if(null != materialShare)
		        	activityMaterialProductVo.setMaterialShareNum(materialShare.getShareNum());
		        else{
		        	acCodes.add(activityCode);
		        }
				
		        activityMaterialProductVo.setActivityCode(activityCode);
				Long groupId = material.getGroupId();
				Integer activityType = material.getActivityType();//团类型
				//activityMaterialProductVo.setSkipType(5);//
				if(activityType != null ){
					activityMaterialProductVo.setActivityId(material.getActivityCode());
					activityMaterialProductVo.setSkuId(material.getSkuId());
					
					activityMaterialProductVo.setMaterialDes(material.getRecordActivity());
					activityMaterialProductVo.setProposal(material.getTips());
			        List<String> images = new ArrayList<String>();
			        images.add(0, material.getPosterImgUrl());
			        activityMaterialProductVo.setMaterialImages(images);
					
					 if(activityType == 7){
						//定金团
						 activityMaterialProductVo.setSkipType(10);
						 if(groupId != null && groupId.intValue() != 0){
							 activityMaterialProductVo.setGroupId(String.valueOf(material.getGroupId()));
						 }
					 }else if(activityType == 19){
						//助力团 
						 activityMaterialProductVo.setSkipType(9);
					 }else{
						// 普通团
						if (groupId != null && groupId.intValue() != 0) {
							// 参团
							activityMaterialProductVo.setGroupId(String.valueOf(material.getGroupId()));
							activityMaterialProductVo.setSkipType(7);
						}else{
							//开团
							activityMaterialProductVo.setSkipType(6);
						}
					}
					 activityMaterialVos.add(activityMaterialProductVo);
				}
			}

		}
    	
    	// 3,批量调素材分享次数接口
    	List<MaterialShare> materialShares = null;
        if(acCodes.size() > 0)
        	materialShares = iMaterialShareManager.selectActivityMaterialShares(acCodes);
    	if(null != materialShares && materialShares.size() != 0){
			for (MaterialShare materialShare : materialShares) {
				for(ActivityMaterialVo activityMaterialVo : activityMaterialVos){
	    			String activityCode = activityMaterialVo.getActivityCode();
					if(activityCode.equals(materialShare.getActivityCode())){
						activityMaterialVo.setMaterialShareNum(materialShare.getShareNum());
						break;
					}
				}
			}
    	}
    	
    	// 判断分页是否到底,0:结束，1：未结束
    	byte pageEnd = 1;
    	if(activityMaterialVos.size() < pageSize) pageEnd = 0;
    	restMap.put("pageEnd", pageEnd);
    	
    	restMap.put("activityMaterialVos", activityMaterialVos);
    	return restMap;
    }

    /**
     * 添加商品素材分享次数
     * @param productId
     * @return
     */
    public byte proMaterialShareNum(String productId){
    	
    	byte status = iMaterialShareManager.insertProMaterialShareNum(productId);
    	
    	return status;
    }
    
    /**
     * 添加活动素材分享次数
     * @param activityCode
     * @return
     */
    public byte activityMaterialShareNum(String activityCode){
    	
    	byte status = iMaterialShareManager.insertAcMaterialShareNum(activityCode);
    	
    	return status;
    }
    
    public Map<String, Object> productMaterial(String storeCode, String moduleCode, String pageCode, 
    		int pageNo, int pageSize, String areaCode, 
    		Integer ppi, Byte ua) throws ServiceException{
    	
    	Map<String, Object> restMap = new HashMap<String, Object>();
    	List<ProductMaterialVo> productMaterialVos = new ArrayList<ProductMaterialVo>();
    	
    	List<Material> materials = pageInfoResource.moduleMaterialList(storeCode, moduleCode, pageCode, Long.valueOf(pageNo), Long.valueOf(pageSize));
    	if(materials == null || materials.size() == 0) {
    		// 分页是否到底0：结束，1：未结束
        	restMap.put("pageEnd", 0);
            restMap.put("productMaterialVos", productMaterialVos);
        	return restMap;
    	}
    	
    	
    	List<String> pids = new ArrayList<String>();
    	List<GroupInfoReq> groupInfoReqs = new ArrayList<GroupInfoReq>();
    	Map<String, Long> groupIdMap = new HashMap<String, Long>();
    	Map<String, String> skuNoMap = new HashMap<String, String>();
    	
    	boolean end = true;
    	for (Material material : materials) {
			if(null == material) continue;
			String productId = material.getProductId();
			if(productId.equals("")) continue;
			String skuId = material.getSkuId();
			String skuNo = material.getSkuNo();
			skuNoMap.put(skuId, skuNo);
			Long groupId = material.getGroupId();
			if(null != groupId && groupId != 0)
				groupIdMap.put(skuId, groupId);
			
			 // 1，商品服务获取信息
	        ProductBaseInfo baseInfo = null;
	        String proJson = propertiesConfig.getUserCenter().get(PRODUCT_BASE_KEY + productId);

	        if (StringUtils.isNotBlank(proJson)) {
	            baseInfo = JSONObject.parseObject(proJson, ProductBaseInfo.class);
	        } else {
	            baseInfo = iProductBaseInfoManager.selectOneByProductId(productId);
	        }
	        if(null == baseInfo) {
	        	end = false;
	        	continue;
	        }
	        
	        ProductMaterialVo productMaterialVo = new ProductMaterialVo();
	        
	        // 处理图片，获取分辨率
            String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
	        String bgImages = baseInfo.getBackgroundImage();
            if (StringUtils.isNotBlank(bgImages)) {
                List<String> images = JSONObject.parseArray(bgImages, String.class);
                List<String> newImages = new ArrayList<>();
                for (String str : images) {
                    newImages.add(ImageUtils.imageUrlInfo(str, ratio, ua));
                }
                productMaterialVo.setMaterialImages(newImages);
            }
	        
            productMaterialVo.setMaterialDes(baseInfo.getProductDesc());
            productMaterialVo.setProposal(material.getTips());
            // 2,获取素材分享次数
            MaterialShare materialShare = JSONObject.parseObject(propertiesConfig.getUserCenter().hget("productServiceMaterialShareNum", productId), MaterialShare.class);
            if(null != materialShare)
            	productMaterialVo.setMaterialShareNum(materialShare.getShareNum());
            else{
            	pids.add(productId);
            }
            
            // 商品信息入参
            GroupInfoReq groupInfoReq = new GroupInfoReq(productId, Long.valueOf(material.getActivityCode()), material.getSkuId());
            groupInfoReqs.add(groupInfoReq);
            
            ProductInfo productInfo = new ProductInfo();
            productInfo.setProductId(productId);
            productInfo.setSkuId(skuId);
            productMaterialVo.setProductInfo(productInfo);
            
            productMaterialVos.add(productMaterialVo);
		}
    	
    	// 3,批量调素材分享次数接口
    	List<MaterialShare> materialShares = null;
        if(pids.size() > 0)
        	materialShares = iMaterialShareManager.selectProMaterialShares(pids);
        
        // 4，批量获取商品信息
        List<ProductGroupInfoVo> productGroupInfoVos = homeProductsManager.groupInfo(groupInfoReqs, areaCode, ppi, ua, storeCode);
        
        // 5,set返参
        for (ProductMaterialVo productMaterialVo : productMaterialVos) {
			// set素材分享
        	String proId = productMaterialVo.getProductInfo().getProductId();
        	String skuId = productMaterialVo.getProductInfo().getSkuId();
        	if(null != materialShares && materialShares.size() != 0){
	    		for (MaterialShare materialShare : materialShares) {
	    			if(null == materialShare) continue;
	    			String productId = materialShare.getProductId();
	    			if(productId.equals(proId)){
	    				productMaterialVo.setMaterialShareNum(materialShare.getShareNum());
	    				break;
	    			}
				}
        	}
        	if(null == productMaterialVo.getMaterialShareNum()){
        		productMaterialVo.setMaterialShareNum(0L);
        	}
        	
    		// set商品，组团活动信息
    		for (ProductGroupInfoVo productGroupInfoVo : productGroupInfoVos) {
    			if(null == productGroupInfoVo) continue;
    			ProductInfo productInfo = productGroupInfoVo.getProductInfo();
    			HomePageActivity homePageActivity = productGroupInfoVo.getHomePageActivity();
    			if(skuId.equals(productInfo.getSkuId())){
    				productInfo.setSkuNo(skuNoMap.get(skuId));
    				homePageActivity.setGroupId(groupIdMap.get(skuId));
    				productMaterialVo.setProductInfo(productInfo);
    				productMaterialVo.setHomePageActivity(homePageActivity);
    				break;
    			}
    		}
		}
        
        // 分页是否到底0：结束，1：未结束
    	byte pageEnd = 1;
    	if(productMaterialVos.size() < pageSize){
    		if(!end)
    			pageEnd = 1;
    		else
    			pageEnd = 0;
    	} 
    	restMap.put("pageEnd", pageEnd);
        
        restMap.put("productMaterialVos", productMaterialVos);
    	return restMap;
    }
    
    /**
     * 删除商品素材分享
     * @param productId
     * @return
     */
    public byte deleteProMaterialShare(String productId){
    	
    	int num = iMaterialShareManager.deleteProMaterialShare(productId);
    	return 1;
    }
    
    /**
     * 删除活动素材分享
     * @param activityCode
     * @return
     */
    public byte deleteAcMaterialShare(String activityCode){
    	
    	int num = iMaterialShareManager.deleteAcMaterialShare(activityCode);
    	return 1;
    }
}
