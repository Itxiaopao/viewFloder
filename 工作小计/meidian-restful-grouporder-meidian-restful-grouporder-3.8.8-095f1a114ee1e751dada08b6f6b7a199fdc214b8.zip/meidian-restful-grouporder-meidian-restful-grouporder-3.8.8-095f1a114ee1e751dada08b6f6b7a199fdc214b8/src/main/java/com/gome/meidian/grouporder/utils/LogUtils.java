package com.gome.meidian.grouporder.utils;


import org.slf4j.LoggerFactory;

import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

public class LogUtils{


	
	public static void logInfo(Class clazz) {
        LoggerFactory.getLogger(clazz).info("parseRequestHeader ==> traceId:{}, userId:{}, URI:{}, channel:{}, version:{}, IP:{}, storeCode:{}, areaCode:{}, countyAreaCode:{}, longitude:{}, latitude:{}, switchingStore:{}, shareUserId:{}, priceReqStore:{}, priceReqAreaCode:{}", 
        		MeidianEnvironment.getTraceId(), MeidianEnvironment.getUserId(), MeidianEnvironment.getURI(), 
        		MeidianEnvironment.getChannel(), MeidianEnvironment.getVersion(), MeidianEnvironment.getIP(), 
        		MeidianEnvironment.getStoreCode(), MeidianEnvironment.getAeaCode(), MeidianEnvironment.getCountyAreaCode(), 
        		MeidianEnvironment.getLongitude(), MeidianEnvironment.getLaitude(), MeidianEnvironment.getSwitchingStore(), 
        		MeidianEnvironment.getShareUserId(), MeidianEnvironment.getKey("priceReqStoreCode"), MeidianEnvironment.getKey("priceReqAreaCode"));

	}
	
	public static void logInfo(Class clazz, String message) {
		LoggerFactory.getLogger(clazz).info("parseRequestHeader ==> traceId:{}, userId:{}, URI:{}, channel:{}, version:{}, IP:{}, storeCode:{}, areaCode:{}, countyAreaCode:{}, longitude:{}, latitude:{}, switchingStore:{}, shareUserId:{}, priceReqStore:{}, priceReqAreaCode:{}, message:{}", 
				MeidianEnvironment.getTraceId(), MeidianEnvironment.getUserId(), MeidianEnvironment.getURI(), 
				MeidianEnvironment.getChannel(), MeidianEnvironment.getVersion(), MeidianEnvironment.getIP(), 
				MeidianEnvironment.getStoreCode(), MeidianEnvironment.getAeaCode(), MeidianEnvironment.getCountyAreaCode(), 
				MeidianEnvironment.getLongitude(), MeidianEnvironment.getLaitude(), MeidianEnvironment.getSwitchingStore(), 
				MeidianEnvironment.getShareUserId(), MeidianEnvironment.getKey("priceReqStoreCode"), MeidianEnvironment.getKey("priceReqAreaCode"),
				message);
		
	}
	
	public static void logError(Class clazz, String message) {
		LoggerFactory.getLogger(clazz).info("parseRequestHeader ==> traceId:{}, userId:{}, URI:{}, channel:{}, version:{}, IP:{}, storeCode:{}, areaCode:{}, countyAreaCode:{}, longitude:{}, latitude:{}, switchingStore:{}, shareUserId:{}, priceReqStore:{}, priceReqAreaCode:{}, message:{}", 
				MeidianEnvironment.getTraceId(), MeidianEnvironment.getUserId(), MeidianEnvironment.getURI(), 
				MeidianEnvironment.getChannel(), MeidianEnvironment.getVersion(), MeidianEnvironment.getIP(), 
				MeidianEnvironment.getStoreCode(), MeidianEnvironment.getAeaCode(), MeidianEnvironment.getCountyAreaCode(), 
				MeidianEnvironment.getLongitude(), MeidianEnvironment.getLaitude(), MeidianEnvironment.getSwitchingStore(), 
				MeidianEnvironment.getShareUserId(), MeidianEnvironment.getKey("priceReqStoreCode"), MeidianEnvironment.getKey("priceReqAreaCode"),
				message);
		
	}
}
