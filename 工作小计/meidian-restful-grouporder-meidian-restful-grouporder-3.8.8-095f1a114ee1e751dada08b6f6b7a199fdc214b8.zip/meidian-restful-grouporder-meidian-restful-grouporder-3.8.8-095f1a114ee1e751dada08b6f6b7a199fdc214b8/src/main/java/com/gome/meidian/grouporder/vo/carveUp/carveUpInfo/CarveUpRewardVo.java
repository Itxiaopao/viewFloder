package com.gome.meidian.grouporder.vo.carveUp.carveUpInfo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.Coupon;

public class CarveUpRewardVo implements Serializable {

	private static final long serialVersionUID = -1324030959330702993L;

	private Integer type; //奖励类型0：基础奖励，1：团长额外奖励，2：排名团额外奖励
	private Integer status; //奖励发放状态：0：待发放，1：已发放，2：已失效
	private Double money; //金额
	private List<Coupon> coupon;
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	public List<Coupon> getCoupon() {
		return coupon;
	}
	public void setCoupon(List<Coupon> coupon) {
		this.coupon = coupon;
	}
	
}
