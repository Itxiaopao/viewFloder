package com.gome.meidian.grouporder.vo.carveUp.myCarveUpList;

import java.util.List;

import com.gome.meidian.grouporder.vo.Coupon;

/**
 * 排名团信息
 */
public class CarveUpRankGroupVo extends CarveUpBaseGroupVo {

	private static final long serialVersionUID = 7871238682932416611L;
//	private Integer rankGroupRewardNum; //排名团，额外奖励的团数',--商品集
//	private List<Coupon> rankCoupons;  //排名团券信息
//	private Integer rankMaxPeopleNum; //排名团，最多人数限制',--团
//	private Double rankFixMoney; //排名团额外每人固定国美币
//	private Double rankTotalMoney; //排名团额外总国美币
	private Double rankBondTotalNum; //排名奖励劵面值总和（元）
	private Double leaderMoney;//团长独享金额（根据瓜分比例和总额计算结果）
	private Double totalCarveMoney;//共同瓜分金额(元、小数最多2位)
	private Integer rankGroupRewardNum; //排名团奖励团数

	private Integer activityIsMaxNum; //当前活动是否达到上限人数 0 未达到， 1 已达到
	private Integer groupFinalSort;//团当前排名
	private Integer userNum;//距离上一名/下一名差几人
	private Integer userFlag;//需要的是新客还是老客  0:老人 、1：新人
//	public List<Coupon> getRankCoupons() {
//		return rankCoupons;
//	}
//	public void setRankCoupons(List<Coupon> rankCoupons) {
//		this.rankCoupons = rankCoupons;
//	}
//	public Double getRankFixMoney() {
//		return rankFixMoney;
//	}
//	public void setRankFixMoney(Double rankFixMoney) {
//		this.rankFixMoney = rankFixMoney;
//	}
//	public Double getRankTotalMoney() {
//		return rankTotalMoney;
//	}
//	public void setRankTotalMoney(Double rankTotalMoney) {
//		this.rankTotalMoney = rankTotalMoney;
//	}
//	public Integer getRankGroupRewardNum() {
//		return rankGroupRewardNum;
//	}
//	public void setRankGroupRewardNum(Integer rankGroupRewardNum) {
//		this.rankGroupRewardNum = rankGroupRewardNum;
//	}
//	public Integer getRankMaxPeopleNum() {
//		return rankMaxPeopleNum;
//	}
//	public void setRankMaxPeopleNum(Integer rankMaxPeopleNum) {
//		this.rankMaxPeopleNum = rankMaxPeopleNum;
//	}
	public Double getRankBondTotalNum() {
		return rankBondTotalNum;
	}
	public void setRankBondTotalNum(Double rankBondTotalNum) {
		this.rankBondTotalNum = rankBondTotalNum;
	}
	public Double getLeaderMoney() {
		return leaderMoney;
	}
	public void setLeaderMoney(Double leaderMoney) {
		this.leaderMoney = leaderMoney;
	}
	public Double getTotalCarveMoney() {
		return totalCarveMoney;
	}
	public void setTotalCarveMoney(Double totalCarveMoney) {
		this.totalCarveMoney = totalCarveMoney;
	}
	public Integer getGroupFinalSort() {
		return groupFinalSort;
	}
	public void setGroupFinalSort(Integer groupFinalSort) {
		this.groupFinalSort = groupFinalSort;
	}
	public Integer getUserNum() {
		return userNum;
	}
	public void setUserNum(Integer userNum) {
		this.userNum = userNum;
	}
	public Integer getUserFlag() {
		return userFlag;
	}
	public void setUserFlag(Integer userFlag) {
		this.userFlag = userFlag;
	}
	public Integer getRankGroupRewardNum() {
		return rankGroupRewardNum;
	}
	public void setRankGroupRewardNum(Integer rankGroupRewardNum) {
		this.rankGroupRewardNum = rankGroupRewardNum;
	}
	public Integer getActivityIsMaxNum() {
		return activityIsMaxNum;
	}
	public void setActivityIsMaxNum(Integer activityIsMaxNum) {
		this.activityIsMaxNum = activityIsMaxNum;
	}
	
}
