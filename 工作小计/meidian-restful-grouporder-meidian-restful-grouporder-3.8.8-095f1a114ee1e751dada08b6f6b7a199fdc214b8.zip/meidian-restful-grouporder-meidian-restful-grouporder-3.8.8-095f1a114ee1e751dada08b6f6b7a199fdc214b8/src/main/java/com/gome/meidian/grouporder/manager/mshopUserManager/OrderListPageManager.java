package com.gome.meidian.grouporder.manager.mshopUserManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.annotation.Resource;

import com.gomeo2o.facade.vshop.entity.VshopInfoLabel;
import com.gomeo2o.facade.vshop.service.VshopInfoLabelFacade;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.entity.OrderInfo;
import com.gome.meidian.entity.OrderListParam;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.SkuInfo;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.mshopUserVo.OrderInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.RebateInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.ShopInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.SkuInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.UserInfoVo;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.UserAuthDto;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.meidian.vo.Pagination;
import com.gome.stage.bean.vo.ProductShopInfo;
import com.gome.stage.bean.vo.ShopResultVo;
import com.gome.stage.interfaces.item.IProductInfoService;
import com.gome.stage.item.GoodsInfo;
import com.gome.stage.service.IAccessGoodsService;
import com.gome.stage.service.IAccessShopService;
import com.gomeo2o.common.entity.CommonResultEntity;


import cn.com.gome.rebate.dubbo.service.app.IDubboBuyersService;
import cn.com.gome.rebate.model.buyer.RebateUserDetailDto;
import cn.com.gome.user.model.OnlineUserSimpleInfo;
import cn.com.gome.user.service.QueryOnlineUserInfoFacade;
import redis.Gcache;

@Service
public class OrderListPageManager {
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private IDubboBuyersService iDubboBuyersService;
	
	@Autowired
	private IProductInfoService productInfoService;
	
	
    @Autowired
    private QueryOnlineUserInfoFacade queryOnlineUserInfoFacade;
    
    
    @Autowired
    private IAccessShopService accessShopService;
    
	@Autowired
	private INewOrderService iNewOrderService;
	
	@Autowired
	private IAccessGoodsService accessGoodsService;
	
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认三级区域，朝阳，全国价
	
	@Value("${meidian.image.agreement}")
	private String agreement;			// http协议
	
	@Resource(name = "gcache")
	private Gcache gcache;
	
	
	@Autowired
	private IUserShareBindingManager iUserShareBindingManager;

	@Autowired
	private VshopInfoLabelFacade vshopInfoLabelFacade;
	

	/**
	 * 列表页查询收益信息
	 * @param userId
	 * @param dimension
	 * @param statusType
	 * @return
	 * @throws ServiceException
	 */
	public  Map<String,Long> getProfitInfo(String userId,Integer statusType,
			String dimension)throws ServiceException{
		Map<String,Long> map = new HashMap<String,Long>();
		map.put("amount", 0L);
		try { 
            //取预计收入
			//查询收益信息1：已入账；2：待入账；3：失效   统计维度，1：今天，2：昨天，3：本月，4：累计    已入账 -累计收入   待入账 -预计收入
			Long  amount = iDubboBuyersService.getRebateStatusTotalAmount(userId, statusType, null, null, dimension);
			if(amount != null ){
				map.put("amount", amount);	
			}
		}catch (Exception e){
			logger.error("getProfit error!userId="+userId,e);
		}
		return map;
	}
	
	/**
	 * 查询收益明细列表
	 * @param userId
	 * @param statusType
	 * @param dimension
	 * @throws ServiceException
	 */
	public List<RebateInfoVo> getProfitList(String userId,Integer statusType,
			Integer pageNum,Integer pageSize,
			String dimension,
			Byte ua,Integer ppi)throws ServiceException{
		List<RebateInfoVo> resultList = null;
		List<RebateUserDetailDto> list = iDubboBuyersService.getMyRebateDetailsList(userId, statusType,null, null,pageNum,pageSize,dimension);
		if(list != null && list.size() > 0){
			Set <String> goodsParamSet =new HashSet<String>();
			Set <Long> usersParamSet =new HashSet<Long>();
			Set <String> shopsParamSet =new HashSet<String>();
			resultList = new ArrayList<RebateInfoVo>();
			for(RebateUserDetailDto rebateUserDetailDto : list){
				RebateInfoVo rebateInfoVo = new RebateInfoVo();
				BeanUtils.copyProperties(rebateUserDetailDto, rebateInfoVo);
				if(rebateInfoVo.getSkuId() != null && !rebateInfoVo.getSkuId().equals("")){
					goodsParamSet.add(rebateInfoVo.getSkuId());
				}
				if(rebateInfoVo.getPurchaserId() != null){
					usersParamSet.add(Long.parseLong(rebateInfoVo.getPurchaserId()));
				}
				if(rebateInfoVo.getInviteeId() != null){
					usersParamSet.add(Long.parseLong(rebateInfoVo.getInviteeId()));
				}
				if(rebateInfoVo.getShopId() != null && !rebateInfoVo.getShopId().equals("")){
					shopsParamSet.add(rebateInfoVo.getShopId());
				}
				
				SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd HH:mm");
				if(rebateUserDetailDto.getPurchaseTime() != null){
					rebateInfoVo.setPurchaseTimeStr(s.format(rebateUserDetailDto.getPurchaseTime()));
				}
				if(rebateUserDetailDto.getInvalidTime() != null){
					rebateInfoVo.setInvalidTimeStr(s.format(rebateUserDetailDto.getInvalidTime()));
				}
				if(rebateUserDetailDto.getRebateTime() != null){
					rebateInfoVo.setRebateTimeStr(s.format(rebateUserDetailDto.getRebateTime()));
				}
				resultList.add(rebateInfoVo);
			}
			
			//格式化
			Map<String,GoodsInfo> goodsMap = new HashMap<String,GoodsInfo>();
			if(goodsParamSet.size()>0){
				goodsMap = getGoodsInfos(new ArrayList<String>(goodsParamSet),null);
			}
			Map<Long, OnlineUserSimpleInfo> userMap =  new HashMap<Long, OnlineUserSimpleInfo>();
			if(usersParamSet.size()>0){
				userMap = getUserInfo(new ArrayList<Long>(usersParamSet));
			}
			Map<String, ShopResultVo> shopInfosMap =  new HashMap<String, ShopResultVo>();
			if(shopsParamSet.size()>0){
				shopInfosMap = getShopInfo(new ArrayList<String>(shopsParamSet));
			}
			
			for(RebateInfoVo rebateInfoVo : resultList){
				if(rebateInfoVo.getSkuId() != null && !rebateInfoVo.getSkuId().equals("")){
					GoodsInfo goodsInfo = goodsMap.get(rebateInfoVo.getSkuId());
					if(goodsInfo != null ){
						SkuInfoVo skuInfo = new SkuInfoVo();
						skuInfo.setSkuId(rebateInfoVo.getSkuId());
						skuInfo.setPid(skuInfo.getPid());

						skuInfo.setGoodsName(goodsInfo.getGoodsName());
						rebateInfoVo.setSkuInfo(skuInfo);
						
						// 处理排序返参
						//String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE);

						String imageUrl = goodsInfo.getGoodsImgUrl();
                        // 处理图片后缀
                        String imageInfo = ImageUtils.imageUrlInfo(imageUrl, ua);
                        // 处理图片协议
                        if (imageInfo.contains("http:"))
                        	skuInfo.setGoodsImgUrl(imageInfo.replace("http:", agreement));
                        else
                        	skuInfo.setGoodsImgUrl(imageInfo);
						
					}
				}
                if(rebateInfoVo.getPurchaserId() != null){
   				    OnlineUserSimpleInfo onlineUserSimpleInfo = userMap.get(Long.parseLong(rebateInfoVo.getPurchaserId()));
   				    if(onlineUserSimpleInfo != null){
   				    	UserInfoVo userInfoVo = new UserInfoVo();
   				    	userInfoVo.setPurchaserId(rebateInfoVo.getPurchaserId());
   				    	userInfoVo.setNickName(onlineUserSimpleInfo.getNickname());
   				    	userInfoVo.setFacePicUrl(onlineUserSimpleInfo.getFacePicUrl());
   				    	rebateInfoVo.setPurchaser(userInfoVo);
   				    }
                }
                if(rebateInfoVo.getShopId() != null){
                	ShopResultVo shopInfo = shopInfosMap.get(rebateInfoVo.getShopId());
                	if(shopInfo != null){
                		ShopInfoVo shopInfoVo = new ShopInfoVo();
                		shopInfoVo.setDescription(shopInfo.getDescription());
                		shopInfoVo.setIcon(shopInfo.getIcon());
                		shopInfoVo.setShopId(shopInfo.getId());
                		shopInfoVo.setName(shopInfo.getName());
                		shopInfoVo.setStatus(shopInfo.getStatus());
                		shopInfoVo.setType(shopInfo.getType());
                		rebateInfoVo.setShopInfo(shopInfoVo);
                	}
                }
                if(rebateInfoVo.getInviteeId() != null){
   				    OnlineUserSimpleInfo onlineUserSimpleInfo = userMap.get(Long.parseLong(rebateInfoVo.getInviteeId()));
   				    if(onlineUserSimpleInfo != null){
   				    	UserInfoVo userInfoVo = new UserInfoVo();
   				    	userInfoVo.setPurchaserId(rebateInfoVo.getInviteeId());
   				    	userInfoVo.setNickName(onlineUserSimpleInfo.getNickname());
   				    	userInfoVo.setFacePicUrl(onlineUserSimpleInfo.getFacePicUrl());
   				    	rebateInfoVo.setPurchaser(userInfoVo);
   				    }
                }
				 
				 

				 
			}
		}
		return resultList;
		
	}
	/**
	 * 获取商品组的商品信息（根据sku查询）
	 * @param imageSize
	 * @return
	 */
	private Map<String,GoodsInfo> getGoodsInfos(List<String> paramList1, String imageSize){
		
		Map<String,GoodsInfo> map = new HashMap<String,GoodsInfo>();
		List<String> newparamList = new  ArrayList<String>();
		for(String key : paramList1){
			GoodsInfo goodsInfo = JSONObject.parseObject(gcache.get("mShopUser_orderProductSku_"+key), GoodsInfo.class);
			if(goodsInfo != null){
				map.put(goodsInfo.getSkuId(), goodsInfo);
			}else{
				newparamList.add(key);
			}
		}
		
		
		if(StringUtils.isEmpty(imageSize)){
			imageSize = "210";
		}
		
		// 商品限制30条
		int listSize = newparamList.size();
		int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
		List<String> paramList = new ArrayList<>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = newparamList;
			} else {
				if (a != selectCount) {
					paramList.addAll(newparamList.subList(30 * (a - 1), 30 * a));
				} else {
					paramList.addAll(newparamList.subList(30 * (a - 1), listSize));
				}
			}
			List<GoodsInfo>  list = productInfoService.getGoodsInfos(paramList,imageSize);
			if(list != null && list.size()>0){
				for(GoodsInfo goodsInfo : list){
					map.put(goodsInfo.getSkuId(), goodsInfo);
					gcache.setex("mShopUser_orderProductSku_"+goodsInfo.getSkuId(), 3 * 60,JSONUtils.toJSONString(goodsInfo).getBytes());
				}
			}
			
		}
		

		return map;
	}
	
	/**
	 * 获取商品信息
	 * @param productId_skuIdList
	 * @return
	 */
	private Map<String,ProductShopInfo> getGoodesInfosByIdSkuId(List<String> productId_skuIdList){
		Map<String,ProductShopInfo> map = new HashMap<String,ProductShopInfo>();
		List<String> newproductId_skuIdList = new  ArrayList<String>();
		for(String key : productId_skuIdList){
			ProductShopInfo productShopInfo = JSONObject.parseObject(gcache.get("mShopUser_orderProduct_"+key), ProductShopInfo.class);
			//ProductShopInfo productShopInfo = null;
			if(productShopInfo != null){
				map.put(productShopInfo.getId()+"_"+productShopInfo.getSkuId(), productShopInfo);
			}else{
				newproductId_skuIdList.add(key);
			}
		}
		
		// 商品限制30条
		int listSize = newproductId_skuIdList.size();
		int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
		List<String> paramList = new ArrayList<>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = newproductId_skuIdList;
			} else {
				if (a != selectCount) {
					paramList.addAll(newproductId_skuIdList.subList(30 * (a - 1), 30 * a));
				} else {
					paramList.addAll(newproductId_skuIdList.subList(30 * (a - 1), listSize));
				}
			}
			
			List<ProductShopInfo> productShopInfos = accessGoodsService.getMutiProductByStore(paramList);
			if(productShopInfos != null && productShopInfos.size()>0){
				for(ProductShopInfo productShopInfo : productShopInfos){
					map.put(productShopInfo.getId()+"_"+productShopInfo.getSkuId(), productShopInfo);
					gcache.setex("mShopUser_orderProduct_"+productShopInfo.getId()+"_"+productShopInfo.getSkuId()+"_"+defaultAreaCode, 3 * 60,JSONUtils.toJSONString(productShopInfo).getBytes());
				}
				
			}
			
		}
		return map;
	}
	
	
	/**
	 * 查询用户是否授权
	 * @param userSet
	 */
	private Map<String, Integer> getUserAuthorization(Set<Long> userSet) {
		// 查询用户是否授权
		Map<String, Integer> userAuthMap = new HashMap<String, Integer>();
		try{
			MapResults<List<UserAuthDto>> mapResults = iUserShareBindingManager.getUserAuthList(userSet);
			if (mapResults != null) {
				List<UserAuthDto> userAuthList = mapResults.getBuessObj();
				if (userAuthList != null && userAuthList.size() > 0) {
					for (UserAuthDto userAuthDto : userAuthList) {
						if (userAuthDto != null && userAuthDto.getUserId() != null) {
							userAuthMap.put(String.valueOf(userAuthDto.getUserId().longValue()),userAuthDto.getAuthorization());
						}
					}
				}
			}
		}catch(Exception e){
			logger.error("getUserAuthorization error!paramSet=" + JSON.toJSONString(userSet), e);
		}
		return userAuthMap;
	}
	
	
	
	/**
	 * 批量获取用户信息
	 * @param userIds
	 * @return
	 */
	private Map<Long, OnlineUserSimpleInfo> getUserInfo(List<Long> userIds){
		 Map<Long, OnlineUserSimpleInfo> userInfosMap = new HashMap<Long, OnlineUserSimpleInfo>();
		 CommonResultEntity<Map<Long, OnlineUserSimpleInfo>> userInfos = queryOnlineUserInfoFacade.queryOnlineUserInfoByBatch(userIds);//未注册
		 if(userInfos != null){
			userInfosMap = userInfos.getBusinessObj();
		 }
		 return userInfosMap;
	}
    /**
     * 批量获取店铺信息
     * @param shopIds
     * @return
     */
	private  Map<String, ShopResultVo> getShopInfo(List<String> shopIds){
		Map<String, ShopResultVo> shopInfosMap = new HashMap<String, ShopResultVo>();
        List<ShopResultVo> shopInfos = accessShopService.getMultipleShopInfo(shopIds);
        if (shopInfos != null && shopInfos.size() > 0) {
            for (ShopResultVo shopInfo : shopInfos) {
                shopInfosMap.put(shopInfo.getId(), shopInfo);
            }
        }
        return shopInfosMap;
	}
	
	
	
    /**
     * 多维度查询销售额
     * @param userId 
     * @param filter  模糊查询条件
     * @param orderStatus 订单状态
     * @param dateState 时间维度
     * @return
     */
	public Long getAchievementInfo(Long userId,String filter,Integer orderStatus,
			String dateState){
		OrderListParam orderListParam =new OrderListParam();
		orderListParam.setUserId(userId);
		orderListParam.setOrderStatus(orderStatus);
		orderListParam.setFilter(filter);
		orderListParam.setDateState(dateState);
		orderListParam.setBizSource("2");
		ResultEntity<Long>  resultEntity = iNewOrderService.getAccumSales(orderListParam);
		if(resultEntity != null){
			return resultEntity.getBusinessObj();
		}
		return 0L;
	}
	
    /**
     * 查询订单信息
     * @param pid 店主上级id
     * @param userId 店主id
     * @param filter 查询条件
     * @param orderStatus 订单状态
     * @param dateState 订单查询维度
     * @param pageNo 页码
     * @param pageSize 条数
     * @param year 年
     * @param month 月
     * @param ua 
     * @param ppi
     * @param bizSource 业务类型  1 提奖订单 2 业绩订单 3 销售订单
     * @return
     */
	public List<OrderInfoVo> getOrderList(Long pid,Long userId, String filter,Integer orderStatus, String dateState,Integer pageNo, Integer pageSize,
										  String year, String month,Byte ua,Integer ppi,String bizSource) {
		List<OrderInfoVo> resultList = new ArrayList<>();
		try {
			OrderListParam orderListParam = new OrderListParam();
			if ("1".equals(bizSource)) {
				orderListParam.setPid(pid);
			}
			orderListParam.setUserId(userId);
			orderListParam.setOrderStatus(orderStatus);
			orderListParam.setDateState(dateState);
			orderListParam.setPageNo(pageNo);
			orderListParam.setPageSize(pageSize);
			orderListParam.setFilter(filter);
			orderListParam.setBizSource(bizSource);
			if (year != null && month != null) {
				String beginTime = year + "-" + month + "-" + "01 00:00:00";
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date startDate = simpleDateFormat.parse(beginTime);
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(startDate);
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.add(Calendar.MONTH, 1);
				Date endDate = calendar.getTime();
				orderListParam.setStartDate(startDate);
				orderListParam.setEndDate(endDate);

			}
			ResultEntity<Pagination<OrderInfo>> resultEntity = iNewOrderService.getOrderList(orderListParam);
			if (resultEntity == null || resultEntity.getBusinessObj() == null || CollectionUtils.isEmpty(resultEntity.getBusinessObj().getList())) {
				return null;
			}
			SimpleDateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			List<OrderInfo> list = resultEntity.getBusinessObj().getList();
			Set<String> goodsParamSet = new HashSet<>();
			Set<Long> userSet = new HashSet<>();
			for (OrderInfo orderInfo : list) {
				OrderInfoVo orderInfoVo = new OrderInfoVo();
				BeanUtils.copyProperties(orderInfo, orderInfoVo);
				orderInfoVo.setAwardMoney(ObjectUtils.defaultIfNull(orderInfo.getOrderAwardMoney(), 0L));
				orderInfoVo.setCommMoney(ObjectUtils.defaultIfNull(orderInfo.getOrderCommMoney(), 0L));
				if (orderInfo.getOrderTime() != null) {
					orderInfoVo.setOrderTimeStr(s.format(orderInfo.getOrderTime()));
				}
				orderInfoVo.setCommMoney(Arrays.asList("2", "3").contains(bizSource) && (orderInfo.getParentUserId() != null && orderInfo.getParentUserId().equals(userId)) ?
						ObjectUtils.defaultIfNull(orderInfo.getOrderCommMoney(), 0L) : 0L);
				if (orderInfoVo.getUserId() != null) {
					userSet.add(orderInfoVo.getUserId());
				}
				orderInfoVo.setAuthorization(NumberUtils.INTEGER_ONE);
				List<SkuInfoVo> goodsList = new ArrayList<>();
				List<SkuInfo> skuInfoList = orderInfo.getSkuInfoList();
				if (CollectionUtils.isNotEmpty(skuInfoList)) {
					for (SkuInfo skuInfo : skuInfoList) {
						SkuInfoVo skuInfoVo = new SkuInfoVo();
						if (skuInfo.getSkuId() != null && !skuInfo.getSkuId().equals("") && skuInfo.getItemId() != null && !skuInfo.getItemId().equals("")) {
							goodsParamSet.add(skuInfo.getItemId() + "_" + skuInfo.getSkuId() + "_" + defaultAreaCode);
							skuInfoVo.setSkuId(skuInfo.getSkuId());
							skuInfoVo.setUnitPrice(skuInfo.getUnitPrice());
							skuInfoVo.setBuyNum(skuInfo.getBuyNum());
							skuInfoVo.setPid(skuInfo.getItemId());
							skuInfoVo.setCommerceId(skuInfo.getCommerceId());
							goodsList.add(skuInfoVo);
						}
					}
				}
				orderInfoVo.setGoodsList(goodsList);
				resultList.add(orderInfoVo);
			}
			Map<String, ProductShopInfo> goodsMap = goodsParamSet.size() > 0 ? getGoodesInfosByIdSkuId(new ArrayList<>(goodsParamSet)) : new HashMap<>();
			//查询用户是否授权
			Map<String, Integer> userAuthMap = userSet.size() > 0 ? getUserAuthorization(userSet) : new HashMap<>();
			//业绩订单百货店主确认提货
			boolean isBhsk = Boolean.FALSE;
			if ("2".equals(bizSource)) {
				CommonResultEntity<VshopInfoLabel> skResult = vshopInfoLabelFacade.queryVshopInfoLabelByUserId(userId, 1);
				isBhsk = skResult.isSuccess() && skResult.getBusinessObj() != null;
			}
			for (OrderInfoVo orderInfoVo : resultList) {
				if (isBhsk && userId.equals(orderInfoVo.getParentUserId())) {
					//设置默认值为未提货
					orderInfoVo.setIsPickGoods(ObjectUtils.defaultIfNull(orderInfoVo.getIsPickGoods(), 0));
				} else if (isBhsk && !userId.equals(orderInfoVo.getParentUserId())) {
					//无权限操作
					orderInfoVo.setIsPickGoods(-1);
				}
				//处理用户权限
				if (orderInfoVo.getUserId() != null) {
					Integer authorization = userAuthMap.get(String.valueOf(orderInfoVo.getUserId()));
					if (orderInfoVo.getUserId().equals(userId)) {
						orderInfoVo.setAuthorization(1);//当前用户 不进行处理
					} else if (NumberUtils.INTEGER_ZERO.equals(authorization)) {
						//未授权  显示信息进行处理
						orderInfoVo.setAuthorization(NumberUtils.INTEGER_ZERO);
						orderInfoVo.setOrderId(null);
					}
				}
				List<SkuInfoVo> goodsList = orderInfoVo.getGoodsList();
				for (SkuInfoVo skuInfoVo : goodsList) {
					if (StringUtils.isNotBlank(skuInfoVo.getSkuId())) {
						ProductShopInfo productShopInfo = goodsMap.get(skuInfoVo.getPid() + "_" + skuInfoVo.getSkuId());
						if (productShopInfo != null) {
							skuInfoVo.setGoodsName(productShopInfo.getName());
							skuInfoVo.setProductTag(productShopInfo.getProductTag());
							// 处理排序返参
							String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE);
							// 处理图片分辨率
							String image = ImageUtils.imageUrlInfo(productShopInfo.getMainImage(), ratio, ua);
							// 处理图片协议
							skuInfoVo.setGoodsImgUrl(image.contains("http:") ? image.replace("http:", agreement) : image);
						}

					}
					//判断用户是否授权
					if (NumberUtils.INTEGER_ZERO.equals(orderInfoVo.getAuthorization())) {
						//未授权
						skuInfoVo.setSkuId("");
						skuInfoVo.setPid("");
						skuInfoVo.setGoodsImgUrl("");
						String yuanName = skuInfoVo.getGoodsName();
						if (StringUtils.isNotEmpty(yuanName)) {
							skuInfoVo.setGoodsName(yuanName.length() <= 4 ? "****" : yuanName.substring(0, 4) + "****");
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("getOrderList error!userId=" + userId + "filter=" + filter + "orderStatus=" + orderStatus + "pageNo=" + pageNo + "pageSize=" + pageSize, e);
		}
		return resultList;
	}
	
	
	/**
	 * 
	 * @param userId
	 * @param pageNo
	 * @param pageSize
	 * @param ua
	 * @param ppi
	 * @return
	 */
	public List<OrderInfoVo> getUserOrderList(Long userId,String dateState,Integer pageNo,Integer pageSize,Byte ua,Integer ppi){
		List<OrderInfoVo> resultList = null;
		try {
			ResultEntity<Pagination<OrderInfo>> resultEntity = iNewOrderService.getUserOrderList(userId,dateState,pageNo,pageSize);
			if(resultEntity != null){
				Pagination<OrderInfo>  page = resultEntity.getBusinessObj();
				if(page != null){
					List<OrderInfo> list = page.getList();
					if(list != null && list.size() >0){
						resultList = new ArrayList<OrderInfoVo>();
						Set <String> goodsParamSet =new HashSet<String>();
						//获取用户权限
						UserAuthDto userAuthDto = null;
						MapResults<UserAuthDto>  mapResults = iUserShareBindingManager.getUserAuth(userId);
						if(mapResults != null ){
							userAuthDto = mapResults.getBuessObj();
						}
						
						for(OrderInfo orderInfo : list){
							OrderInfoVo orderInfoVo = new OrderInfoVo();
							BeanUtils.copyProperties(orderInfo, orderInfoVo);
							orderInfoVo.setAwardMoney(orderInfo.getOrderAwardMoney());
							orderInfoVo.setCommMoney(orderInfo.getOrderCommMoney());
							SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd HH:mm");
							if(orderInfo.getOrderTime() != null ){
								orderInfoVo.setOrderTimeStr(s.format(orderInfo.getOrderTime()));
							}
							List<SkuInfoVo> goodsList = new ArrayList<SkuInfoVo>();
							
							List<SkuInfo> skuInfoList = orderInfo.getSkuInfoList();
							if(skuInfoList != null && skuInfoList.size()>0){
								for(SkuInfo skuInfo :skuInfoList){
									SkuInfoVo skuInfoVo = new SkuInfoVo();
									if(skuInfo.getSkuId() != null && !skuInfo.getSkuId().equals("")  && skuInfo.getItemId() != null && !skuInfo.getItemId().equals("")){
										goodsParamSet.add(skuInfo.getItemId()+"_"+skuInfo.getSkuId()+"_"+defaultAreaCode);
										skuInfoVo.setSkuId(skuInfo.getSkuId());
										skuInfoVo.setUnitPrice(skuInfo.getUnitPrice());
										skuInfoVo.setBuyNum(skuInfo.getBuyNum());
										skuInfoVo.setPid(skuInfo.getItemId());
										skuInfoVo.setCommerceId(skuInfo.getCommerceId());
										goodsList.add(skuInfoVo);
									}
								}
								
							}
							
							

							orderInfoVo.setGoodsList(goodsList);
							resultList.add(orderInfoVo);
						}
						Map<String,ProductShopInfo> goodsMap = new HashMap<String,ProductShopInfo>();
						if(goodsParamSet.size()>0){							
							goodsMap = getGoodesInfosByIdSkuId(new ArrayList<String>(goodsParamSet));
						}
						for(OrderInfoVo orderInfoVo : resultList){
							
							//权限处理
							if(userAuthDto  != null && userAuthDto.getAuthorization() != null && userAuthDto.getAuthorization().intValue() == 0){
								orderInfoVo.setAuthorization(0);
								orderInfoVo.setOrderId(null);
//								String yuanName = orderInfoVo.getUserWeixin();
//								yuanName = EmojiParser.removeAllEmojis(yuanName);//删除所有表情
//								if(!StringUtils.isEmpty(yuanName)){
//									if(yuanName.length() <= 2){
//										yuanName = "****";
//										orderInfoVo.setUserWeixin(yuanName);
//									}else{
//										StringBuilder sb= new StringBuilder("");
//										sb.append(yuanName.charAt(0)).append("****").append(yuanName.charAt(yuanName.length()-1));
//										orderInfoVo.setUserWeixin(sb.toString());
//									}
//								}
								
							}else{
								orderInfoVo.setAuthorization(1);
							}
							
							List<SkuInfoVo> goodsList = orderInfoVo.getGoodsList();
							for(SkuInfoVo skuInfoVo : goodsList){
								if(skuInfoVo.getSkuId() != null && !skuInfoVo.getSkuId().equals("")){
									ProductShopInfo productShopInfo = goodsMap.get(skuInfoVo.getPid()+"_"+skuInfoVo.getSkuId());
									if(productShopInfo != null){
										//skuInfoVo.setGoodsImgUrl(goodsInfo.getGoodsImgUrl());
										skuInfoVo.setGoodsName(productShopInfo.getName());
										skuInfoVo.setProductTag(productShopInfo.getProductTag());
//										// 处理排序返参
//										String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE);
//										// 处理图片分辨率
//										String image = ImageUtils.imageUrlInfo(productShopInfo.getMainImage(), ratio, ua);
//										skuInfoVo.setGoodsImgUrl(image);
										// 处理排序返参
										String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE);
										// 处理图片分辨率
										String image = ImageUtils.imageUrlInfo(productShopInfo.getMainImage(), ratio, ua);
										
				                        // 处理图片协议
				                        if (image.contains("http:"))
				                        	skuInfoVo.setGoodsImgUrl(image.replace("http:", agreement));
				                        else
				                        	skuInfoVo.setGoodsImgUrl(image);
									}

								}
								
								if(orderInfoVo.getAuthorization()==0){
									skuInfoVo.setGoodsImgUrl("");
									skuInfoVo.setPid("");
									skuInfoVo.setSkuId("");
									String yuanName = skuInfoVo.getGoodsName();
									if(!StringUtils.isEmpty(yuanName)){
										if(yuanName.length() <= 4){
											yuanName = "****";
											skuInfoVo.setGoodsName(yuanName);
										}else{
											StringBuilder sb= new StringBuilder("");
											sb.append(yuanName.substring(0, 4)).append("****");
											skuInfoVo.setGoodsName(sb.toString());
										}
									}
								}
								
							}
						}
						
					}
				}
			}
		}catch (Exception e){
			logger.error("getOrderList error!userId="+userId+"pageNo="+pageNo+"pageSize="+pageSize,e);
		}

		return resultList;
	}


	public Boolean savePickGoods(String deliveryId, Long userId, Integer isPickGoods) throws ServiceException {
		//判断是否是百货店主
		CommonResultEntity<VshopInfoLabel> result = vshopInfoLabelFacade.queryVshopInfoLabelByUserId(userId, 1);
		if (result.isSuccess() && result.getBusinessObj() == null) {
			throw new ServiceException("base.shop.not.bhsk");
		}
		ResultEntity<Boolean> orderResult = iNewOrderService.savePickGoods(deliveryId, userId, isPickGoods);
		logger.info("保存百货店主提货标识,入参 deliveryId:{},userId:{},isPickGoods:{},返回值:{}", deliveryId, userId, isPickGoods, JSON.toJSON(orderResult));
		return orderResult != null && orderResult.isSuccess() && orderResult.getBusinessObj();
	}
	
	
	
	public static void main(String[] args) throws ParseException {
		Integer year = 2019;
		Integer month = 07;
		String beginTime =year.toString()+"-"+month.toString()+"-"+"01 00:00:00";
		SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //SimpleDateFormat sDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //加上时间
        Date startDate=simpleDateFormat.parse(beginTime);		        
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        calendar.set(Calendar.DAY_OF_MONTH,1);
        calendar.add(Calendar.MONTH, 1);
        Date endDate = calendar.getTime();
        System.out.println(simpleDateFormat.format(startDate));
        System.out.println(simpleDateFormat.format(endDate));
	}
	
}
