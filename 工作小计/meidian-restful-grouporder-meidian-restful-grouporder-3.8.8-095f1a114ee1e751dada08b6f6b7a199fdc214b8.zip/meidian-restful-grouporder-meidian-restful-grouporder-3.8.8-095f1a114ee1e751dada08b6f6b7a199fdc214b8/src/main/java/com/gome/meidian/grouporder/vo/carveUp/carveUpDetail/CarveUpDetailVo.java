package com.gome.meidian.grouporder.vo.carveUp.carveUpDetail;

import java.io.Serializable;
import java.util.List;

public class CarveUpDetailVo implements Serializable {

	private static final long serialVersionUID = -8236533001200266333L;

	private Long id; //id
	private Long startTime; //开始时间
	private Long endTime; //结束时间
	private String hyperLinks; //图片跳转链接
	private String imageUrl; //图片地址
	private Integer carveGroupType; //瓜分团类型：1：基础团，2：排名团--奖励定额，3：排名团--奖励瓜分
	private Integer carveBaseNum; //达标人数
	private Integer carveMinNewNum; //最低新用户人数
	private Integer activityResidueNum;//活动剩余开团数量
	private Integer groupResidueNum;//当前用户在当前活动开团剩余数量
	private Long surplusTime;  //距团结束时间
	
	private String appletImageUrl; //小程序card图片
	private String friendImageUrl; //好友朋友圈图片
	private String friendSubImageUrl; //好友朋友圈配图
	
	private List<String> marquee; //跑马灯
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}
	public Long getEndTime() {
		return endTime;
	}
	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public Integer getCarveGroupType() {
		return carveGroupType;
	}
	public void setCarveGroupType(Integer carveGroupType) {
		this.carveGroupType = carveGroupType;
	}
	public Integer getCarveBaseNum() {
		return carveBaseNum;
	}
	public void setCarveBaseNum(Integer carveBaseNum) {
		this.carveBaseNum = carveBaseNum;
	}
	public Integer getCarveMinNewNum() {
		return carveMinNewNum;
	}
	public void setCarveMinNewNum(Integer carveMinNewNum) {
		this.carveMinNewNum = carveMinNewNum;
	}
	public Integer getActivityResidueNum() {
		return activityResidueNum;
	}
	public void setActivityResidueNum(Integer activityResidueNum) {
		this.activityResidueNum = activityResidueNum;
	}
	public Integer getGroupResidueNum() {
		return groupResidueNum;
	}
	public void setGroupResidueNum(Integer groupResidueNum) {
		this.groupResidueNum = groupResidueNum;
	}
	public Long getSurplusTime() {
		return surplusTime;
	}
	public void setSurplusTime(Long surplusTime) {
		this.surplusTime = surplusTime;
	}
	public String getAppletImageUrl() {
		return appletImageUrl;
	}
	public void setAppletImageUrl(String appletImageUrl) {
		this.appletImageUrl = appletImageUrl;
	}
	public String getFriendImageUrl() {
		return friendImageUrl;
	}
	public void setFriendImageUrl(String friendImageUrl) {
		this.friendImageUrl = friendImageUrl;
	}
	public String getFriendSubImageUrl() {
		return friendSubImageUrl;
	}
	public void setFriendSubImageUrl(String friendSubImageUrl) {
		this.friendSubImageUrl = friendSubImageUrl;
	}
	public List<String> getMarquee() {
		return marquee;
	}
	public void setMarquee(List<String> marquee) {
		this.marquee = marquee;
	}
	public String getHyperLinks() {
		return hyperLinks;
	}
	public void setHyperLinks(String hyperLinks) {
		this.hyperLinks = hyperLinks;
	}
	
}
