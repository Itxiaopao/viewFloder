package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;

public class SearchProInfo implements Serializable{
	private static final long serialVersionUID = -6260449341266121732L;
	private String pid;
	private String skuid;
	private String skuNo;
	private String name;
	private String sImg;
	private Integer rebate;
	private String mgroupActivityId;
	private Integer mgroupState;
	private String mrebateActivityId;
	private Integer mrebateState ;
	private Boolean mshopTag;
	private int stock;
	private int presale;//预售状态 1：预售，2：盲售
	private String promId;//预售方案id
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getSkuid() {
		return skuid;
	}
	public void setSkuid(String skuid) {
		this.skuid = skuid;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getsImg() {
		return sImg;
	}
	public void setsImg(String sImg) {
		this.sImg = sImg;
	}
	public Integer getRebate() {
		return rebate;
	}
	public void setRebate(Integer rebate) {
		this.rebate = rebate;
	}
	public String getMgroupActivityId() {
		return mgroupActivityId;
	}
	public void setMgroupActivityId(String mgroupActivityId) {
		this.mgroupActivityId = mgroupActivityId;
	}
	public Integer getMgroupState() {
		return mgroupState;
	}
	public void setMgroupState(Integer mgroupState) {
		this.mgroupState = mgroupState;
	}
	public String getMrebateActivityId() {
		return mrebateActivityId;
	}
	public void setMrebateActivityId(String mrebateActivityId) {
		this.mrebateActivityId = mrebateActivityId;
	}
	public Integer getMrebateState() {
		return mrebateState;
	}
	public void setMrebateState(Integer mrebateState) {
		this.mrebateState = mrebateState;
	}
	public Boolean getMshopTag() {
		return mshopTag;
	}
	public void setMshopTag(Boolean mshopTag) {
		this.mshopTag = mshopTag;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public int getPresale() {
		return presale;
	}
	public void setPresale(int presale) {
		this.presale = presale;
	}
	public String getPromId() {
		return promId;
	}
	public void setPromId(String promId) {
		this.promId = promId;
	}

	
	

}
