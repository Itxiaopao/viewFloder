package com.gome.meidian.grouporder.vo.coupon;

import java.io.Serializable;
import java.util.List;

/**
 * 促销语
 * @author shichangjian
 *
 */
public class Promotion implements Serializable{

	private static final long serialVersionUID = 735418521130350022L;

	private String promotionId;			// 活动id
	private String showType;			// 活动展示类型，领券:101 买即赠:102 满减:103 满折:104 满赠:105 满返:106 加价换购:107
	private String promotionDesc;		// 促销语
	private String couponType;			// 返劵类型，1美券、2全场红券、3自营红、4自营蓝券、5旅游票务券、6虚拟券、7金融券、8营销券
	private String link;				// 活动详情链接
	private List<Condition> conditions;	// 条件，满*件
	private String tag;					// 促销标签
	
	public Promotion() {
		super();
	}
	public Promotion(String promotionId, String showType, String promotionDesc, 
			String couponType, String link, List<Condition> conditions,
			String tag) {
		super();
		this.promotionId = promotionId;
		this.showType = showType;
		this.promotionDesc = promotionDesc;
		this.couponType = couponType;
		this.link = link;
		this.conditions = conditions;
		this.tag = tag;
	}
	public String getPromotionId() {
		return promotionId;
	}
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	public String getShowType() {
		return showType;
	}
	public void setShowType(String showType) {
		this.showType = showType;
	}
	public String getPromotionDesc() {
		return promotionDesc;
	}
	public void setPromotionDesc(String promotionDesc) {
		this.promotionDesc = promotionDesc;
	}
	public String getCouponType() {
		return couponType;
	}
	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<Condition> getConditions() {
		return conditions;
	}
	public void setConditions(List<Condition> conditions) {
		this.conditions = conditions;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	
	
}
