package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.gome.meidian.grouporder.vo.mshopUserVo.GomeHelpAddBindingVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.GomeHelpCreatePromotionVo;
import com.gome.meidian.restfulcommon.reponse.StatusCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.GomeHelpManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.vo.mshopUserVo.GomeHelpVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.UpWeChartImageParamVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import lombok.extern.slf4j.Slf4j;

/**
 * 小美帮帮
 */

@RestController
@Validated
@RequestMapping("/gomeHelp/inviteUserRegister")
@Slf4j
public class GomeHelpController {
    @Autowired
    private GomeHelpManager gomeHelpManager;
    @Autowired
    private GroupOrderManager groupOrderManager;
    @Autowired
    private AuthencationUtils authencationUtils;

    @RequestMapping(value = "/addBinding", method = RequestMethod.POST)
    public ResponseJson<Map<String, Object>> addBinding(@RequestBody @Validated GomeHelpAddBindingVo gomeHelpAddBindingVo) {
        if(gomeHelpAddBindingVo.getPuserId().equals(0L) || gomeHelpAddBindingVo.getUserId().equals(0L)){
            return new ResponseJson<Map<String, Object>>(StatusCode.VALIDATION_FAILED);
        }
        ResponseJson<Map<String, Object>> responseJson = gomeHelpManager.addBinding(gomeHelpAddBindingVo.getPuserId(),gomeHelpAddBindingVo.getUserId(),gomeHelpAddBindingVo.getChannel(),gomeHelpAddBindingVo.getInvokeFrom());
        return responseJson;
    }

    /**
     * 查询邀请好友列表
     * @param scn
     * @return
     * @throws ServiceException
     */
    @GetMapping(value = "/getInviteUserList")
    public Object getInviteUserList(@CookieValue(value = "SCN", required = true) String scn) throws ServiceException {
        // 检验登录
        ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        String currentUser = getUserIdByScn(scn);
        //判断用户是否登录
        if (null == currentUser) {
            resMap.put("login", 0);
            resMap.put("msg", "未登录");
            responseJson.setData(resMap);
            return responseJson;
        } else {
            resMap.put("login", 1);
            resMap.put("msg", "已登录");
        }
        //已经登录
        List<GomeHelpVo> resultList = gomeHelpManager.getInviteUserList(currentUser);
        log.info("GuestController.getInviteUserList 查询邀请人列表当前用户ID是 {},查询结果是 {} ", currentUser, resultList);
        resMap.put("list", resultList);
        responseJson.setData(resMap);
        return responseJson;
    }

    /**
     * 查询注册数，收单数，收益
     *
     * @param scn
     * @return
     * @throws ServiceException
     */
    @GetMapping(value = "/getUserCount")
    public Object getUserCount(
            @CookieValue(value = "SCN", required = false) String scn,
            @NotNull(message = "{param.error}") @RequestParam("beginTime") String beginTime,
            @NotNull(message = "{param.error}") @RequestParam("endTime") String endTime) throws ServiceException {
        // 检验登录
        ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        String currentUser = getUserIdByScn(scn);
        //判断用户是否登录
        if (null == currentUser) {
            resMap.put("login", 0);
            resMap.put("msg", "未登录");
            responseJson.setData(resMap);
            return responseJson;
        } else {
            resMap.put("login", 1);
            resMap.put("msg", "已登录");
        }
        Map<String, Object> resultMap = gomeHelpManager.getUserCount(currentUser,beginTime,endTime);
        resMap.put("map", resultMap);
        responseJson.setData(resMap);
        return responseJson;
    }

    /**
     * 查询国美币
     * @param scn
     * @return
     */
    @RequestMapping(value = "/getGcoinByUserId", method = RequestMethod.POST)
    public ResponseJson<HashMap<String,Object>> getGcoinByUserId(@CookieValue(value = "SCN", required = false) String scn){
        ResponseJson<HashMap<String,Object>> responseJson = new ResponseJson<HashMap<String,Object>>();
        try {
            HashMap<String, Object> hashMap = new HashMap<>(3);
            String userId = getUserIdByScn(scn);
            //判断用户是否登录
            if (null == userId) {
                hashMap.put("login", 0);
                hashMap.put("msg", "未登录");
                responseJson.setData(hashMap);
                return responseJson;
            } else {
                hashMap.put("login", 1);
                hashMap.put("msg", "已登录");
            }
            Long gcoin = gomeHelpManager.getGcoinByUserId(userId);
            HashMap<String, Long> gcoinMap = new HashMap<>(1);
            gcoinMap.put("gCoin",gcoin);
            hashMap.put("result",gcoinMap);
            responseJson.setData(hashMap);
        }catch (Exception e){
            log.error("查询国美币出现异常:{}",e.getMessage());
            responseJson.setCode(500);
            return responseJson;
        }
        return responseJson;
    }

    @GetMapping(value = "/getTableList")
    public Object getTableList(
            @CookieValue(value = "SCN", required = false) String scn,
            @NotNull(message = "{param.error}") @RequestParam("pageNo") int pageNo,
            @NotNull(message = "{param.error}") @RequestParam("pageSize") int pageSize,
            @NotNull(message = "{param.error}") @RequestParam("beginTime") String beginTime,
            @NotNull(message = "{param.error}") @RequestParam("endTime") String endTime) throws ServiceException {
        // 检验登录
        ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        String currentUser = getUserIdByScn(scn);
        //判断用户是否登录
        if (null == currentUser) {
            resMap.put("login", 0);
            resMap.put("msg", "未登录");
            responseJson.setData(resMap);
            return responseJson;
        } else {
            resMap.put("login", 1);
            resMap.put("msg", "已登录");
        }
        pageNo = (pageNo <= 0) ? 1 : pageNo;
        //已经登录
        List<GomeHelpVo> resultList = gomeHelpManager.getTableList(currentUser,pageNo,pageSize,beginTime,endTime);
        log.info("GuestController.GomeHelpManager.getTableList 查询列表数据 当前用户 {}, 开始时间 {}, 结束时间 {}, 页码 {}, 返回数据是 {} ",
                currentUser, beginTime, endTime, pageNo, resultList);
        //查询这折线图的的数据 日期-收益
        List<Map<String, Object>> chartData = gomeHelpManager.getChartData(currentUser, beginTime, endTime);
        log.info("GuestController.GomeHelpManager.getTableList 折线图数据 当前用户 {},开始时间 {},结束时间 {} ,返回结果是 {}  ", currentUser,
                beginTime, endTime, chartData);
        resMap.put("list", resultList);
        resMap.put("chartData", chartData);
        responseJson.setData(resMap);
        return responseJson;
    }

    /**
     * 查询邀请人数最多的前30名用户
     * @param scn
     * @return
     * @throws ServiceException
     */
    @GetMapping(value = "/getMaxPuserIdList")
    public Object getMaxPuserIdList(@CookieValue(value = "SCN", required = false) String scn) throws ServiceException {
        // 检验登录
        ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        String currentUser = getUserIdByScn(scn);
        //判断用户是否登录
        if (null == currentUser) {
            resMap.put("login", 0);
            resMap.put("msg", "未登录");
            responseJson.setData(resMap);
            return responseJson;
        } else {
            resMap.put("login", 1);
            resMap.put("msg", "已登录");
        }
        //已经登录
        List<GomeHelpVo> resultList = gomeHelpManager.getMaxPuserIdList();
        log.info("GuestController.GomeHelpManager.getMaxPuserIdList 查询邀请人数最多的前30名用户, 返回数据是 {} ", resultList);

        resMap.put("list", resultList);
        responseJson.setData(resMap);
        return responseJson;
    }

    /**
     * 内部员工推广员创建
     * @param scn
     * @param employeeOrigin 	员工来源
     * @param employeeId	    员工id
     * @return
     */
    @RequestMapping(value = "/createInternalPromoter", method = RequestMethod.POST)
    public ResponseJson<HashMap<String,Object>> createInternalPromoter(@CookieValue(value = "SCN", required = false) String scn,
                                               @RequestBody GomeHelpCreatePromotionVo gomeHelpCreatePromotionVo){
        ResponseJson<HashMap<String,Object>> rtnResponse = new ResponseJson<>();
        if(null == gomeHelpCreatePromotionVo || StringUtils.isBlank(gomeHelpCreatePromotionVo.getEmployeeId()) || null == gomeHelpCreatePromotionVo.getEmployeeOrigin()){
            return new ResponseJson(StatusCode.VALIDATION_FAILED);
        }
        String userId = getUserIdByScn(scn);
        HashMap<String, Object> hashMap = new HashMap<String, Object>(3);
        if (null == userId) {
            hashMap.put("login", 0);
            hashMap.put("msg", "未登录");
            rtnResponse.setData(hashMap);
            return rtnResponse;
        } else {
            hashMap.put("login", 1);
            hashMap.put("msg", "已登录");
        }
        HashMap<String, String> result = new HashMap<>(1);
        result.put("promoterId",gomeHelpManager.createInternalPromoter(userId,gomeHelpCreatePromotionVo.getEmployeeOrigin(),gomeHelpCreatePromotionVo.getEmployeeId()));
        hashMap.put("result",result);
        rtnResponse.setData(hashMap);
        return rtnResponse;
    }

    /**
     * 创建推广方案
     * @param scn
     * @param businessId    	业务id
     * @param content           推广内容
     * @param locationId        推广位置
     * @return
     */
    @RequestMapping(value = "/createNormalPromotionPlan", method = RequestMethod.POST)
    public ResponseJson<HashMap<String,Object>> createNormalPromotionPlan(@CookieValue(value = "SCN", required = false) String scn,
                                                                          @RequestBody GomeHelpCreatePromotionVo gomeHelpCreatePromotionVo){
        ResponseJson<HashMap<String,Object>> rtnResponse = new ResponseJson<>();
        if(null == gomeHelpCreatePromotionVo || StringUtils.isBlank(gomeHelpCreatePromotionVo.getContent()) ||
                StringUtils.isBlank(gomeHelpCreatePromotionVo.getLocationId()) || StringUtils.isBlank(gomeHelpCreatePromotionVo.getBusinessId())){
            return new ResponseJson<HashMap<String,Object>>(StatusCode.VALIDATION_FAILED);
        }
        HashMap<String, Object> hashMap = new HashMap<String, Object>(3);
        String userId = getUserIdByScn(scn);
        if (null == userId) {
            hashMap.put("login", 0);
            hashMap.put("msg", "未登录");
            rtnResponse.setData(hashMap);
            return rtnResponse;
        } else {
            hashMap.put("login", 1);
            hashMap.put("msg", "已登录");
        }
        hashMap.put("result",gomeHelpManager.createNormalPromotionPlan(userId,gomeHelpCreatePromotionVo.getBusinessId(),gomeHelpCreatePromotionVo.getContent(),gomeHelpCreatePromotionVo.getLocationId()));
        rtnResponse.setData(hashMap);
        return rtnResponse;
    }


    /**
     * base64方式上传图片
     * @param
     * @return
     */
    @RequestMapping(value = "/uploadImage",method = RequestMethod.POST)
    public ResponseJson<String> uploadImage( @RequestBody UpWeChartImageParamVo upWeChartImageParamVo){
        ResponseJson<String> responseJson = new ResponseJson<>();
        if(null == upWeChartImageParamVo || StringUtils.isBlank(upWeChartImageParamVo.getImage())){
            responseJson.setCode(500);
            responseJson.setMsg("图片为空");
            return responseJson;
        }
        responseJson = gomeHelpManager.updateImage(upWeChartImageParamVo.getImage());
        return responseJson;
    }

//    @RequestMapping(value = "/checkAuthencation",method = RequestMethod.GET)
//    public ResponseJson<HashMap<String,String>> checkAuthencation(@CookieValue(value = "SCN", required = false) String scn){
//        ResponseJson<HashMap<String,String>> responseJson = null;
//        HashMap<String, String> stringStringHashMap = new HashMap<>(1);
//        try{
//            String userId = getUserIdByScn(scn);
//            if(StringUtils.isBlank(userId)){
//                return new ResponseJson<HashMap<String,String>>(StatusCode.NOT_LOGGED_ON);
//            }else{
//                stringStringHashMap.put("userId",userId);
//                return new ResponseJson<HashMap<String,String>>(stringStringHashMap);
//            }
//        }catch (Exception e){
//            log.error("小美帮帮scn获取userId出现异常:{},scn:{}",e,scn);
//            return new ResponseJson(StatusCode.SYSTEM_ERROR);
//        }
//    }

    public String getUserIdByScn(String scn) {
        String userId = "";
        try {
            userId = authencationUtils.authenticationLogin(scn);
        } catch (ServiceException e) {
            log.error("check scn msg is NOT_LOGGED_ON, scn:" + scn, e.getMessage());
        }
        return userId;
    }

}
