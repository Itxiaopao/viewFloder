package com.gome.meidian.grouporder.vo.coupon;

import java.io.Serializable;

/**
 * 赠品
 * @author shichangjian
 *
 */
public class Gift implements Serializable{

	private static final long serialVersionUID = -5419590494289585370L;

	private String giftId;		// 赠品ID
	private String giftName;	// 赠品名称
	private int giftNum;		// 赠品数量（*1）
	private String productId;	// 赠品productId
	private String giftType;	// 赠品类型   1实物赠品   2美豆  3券
	private String groupNo;		// 赠品分组ID
	private Double getGiftPrice;// 赠品单价/券面值，（可返10元）
	
	public Gift() {
		super();
	}
	public Gift(String giftId, String giftName, int giftNum, 
			String productId, String giftType, String groupNo,
			Double getGiftPrice) {
		super();
		this.giftId = giftId;
		this.giftName = giftName;
		this.giftNum = giftNum;
		this.productId = productId;
		this.giftType = giftType;
		this.groupNo = groupNo;
		this.getGiftPrice = getGiftPrice;
	}
	public String getGiftId() {
		return giftId;
	}
	public void setGiftId(String giftId) {
		this.giftId = giftId;
	}
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}
	public int getGiftNum() {
		return giftNum;
	}
	public void setGiftNum(int giftNum) {
		this.giftNum = giftNum;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getGiftType() {
		return giftType;
	}
	public void setGiftType(String giftType) {
		this.giftType = giftType;
	}
	public String getGroupNo() {
		return groupNo;
	}
	public void setGroupNo(String groupNo) {
		this.groupNo = groupNo;
	}
	public Double getGetGiftPrice() {
		return getGiftPrice;
	}
	public void setGetGiftPrice(Double getGiftPrice) {
		this.getGiftPrice = getGiftPrice;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
