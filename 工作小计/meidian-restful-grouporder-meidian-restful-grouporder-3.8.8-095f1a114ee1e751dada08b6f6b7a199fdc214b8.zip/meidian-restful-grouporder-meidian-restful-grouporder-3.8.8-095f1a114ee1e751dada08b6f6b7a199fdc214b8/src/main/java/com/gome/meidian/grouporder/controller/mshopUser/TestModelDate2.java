package com.gome.meidian.grouporder.controller.mshopUser;

import com.gome.meidian.grouporder.vo.mshopUserVo.*;

public class TestModelDate2 {

	public static MshopSolicitVo getMshopSolicitingVo(){
		MshopSolicitVo mshopSolicitingVo = new MshopSolicitVo();
		/*mshopSolicitingVo.setSelfUrl("www.baidu.com");
		mshopSolicitingVo.setSelfNickname("火娃");
		mshopSolicitingVo.setConsultantUrl("www.gogle.com");
		mshopSolicitingVo.setConsultantNickname("水娃");
		mshopSolicitingVo.setInvitationUrl("www.sina.com");
		mshopSolicitingVo.setInvitationNickname("力娃");
		mshopSolicitingVo.setTutorUrl("www.firfox.com");
		mshopSolicitingVo.setTutorNickname("导师昵称");*/
		return mshopSolicitingVo;
	}
}
