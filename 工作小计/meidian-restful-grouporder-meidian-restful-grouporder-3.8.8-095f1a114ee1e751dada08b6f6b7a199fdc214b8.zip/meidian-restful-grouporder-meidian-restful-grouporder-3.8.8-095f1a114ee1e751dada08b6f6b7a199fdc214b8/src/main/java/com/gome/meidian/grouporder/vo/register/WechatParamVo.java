package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

public class WechatParamVo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String wechatName;

	public String getWechatName() {
		return wechatName;
	}
	public void setWechatName(String wechatName) {
		this.wechatName = wechatName;
	}
	
}
