package com.gome.meidian.grouporder.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;

import com.gome.track.filter.TrackFilter;

@Order(1)//过滤顺序，值越小，越先执行（第2個過濾器用到jar包meidian-restful-common,xssFilter）
@WebFilter(filterName = "gcatFilter", urlPatterns = "/*")
public class GcatFilter extends TrackFilter{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {
		// cat处理
		super.doFilter(servletRequest, servletResponse, filterChain);
	}

}
