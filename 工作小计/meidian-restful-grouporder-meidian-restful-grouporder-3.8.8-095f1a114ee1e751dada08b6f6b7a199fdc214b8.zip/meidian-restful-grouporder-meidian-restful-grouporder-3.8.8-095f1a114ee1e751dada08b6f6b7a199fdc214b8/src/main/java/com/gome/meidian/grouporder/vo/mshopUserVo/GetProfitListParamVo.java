package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;


public class GetProfitListParamVo implements Serializable{
	private static final long serialVersionUID = 1970376652325109893L;

	@NotNull(message = "{param.error}")
	private Integer statusType;
    private String dimension;
    @NotNull(message = "{param.error}")
    private Integer pageNum;
    @NotNull(message = "{param.error}")
    private Integer pageSize;
	public Integer getStatusType() {
		return statusType;
	}
	public void setStatusType(Integer statusType) {
		this.statusType = statusType;
	}
	public String getDimension() {
		return dimension;
	}
	public void setDimension(String dimension) {
		this.dimension = dimension;
	}
	public Integer getPageNum() {
		return pageNum;
	}
	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
    

}
