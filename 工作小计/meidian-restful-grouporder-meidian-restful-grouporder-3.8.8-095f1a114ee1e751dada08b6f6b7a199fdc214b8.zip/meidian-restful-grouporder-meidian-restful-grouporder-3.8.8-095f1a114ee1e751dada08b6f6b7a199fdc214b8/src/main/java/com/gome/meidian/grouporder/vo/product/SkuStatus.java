package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;

public class SkuStatus implements Serializable{

	private static final long serialVersionUID = 1807092186694943062L;

	private String skuId;
	private Integer status;
	
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	
}
