package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 凑单商品列表和活动页
 * @author shichangjian
 *
 */
public class GrouppOrderProductsVo implements Serializable{

	private static final long serialVersionUID = -154631617669642488L;

	private ProductParamInfo productParamInfo;	// 主页列表
	private ActivityPage activityPage;			// 活动页
	
	public ActivityPage getActivityPage() {
		return activityPage;
	}
	public void setActivityPage(ActivityPage activityPage) {
		this.activityPage = activityPage;
	}
	public ProductParamInfo getProductParamInfo() {
		return productParamInfo;
	}
	public void setProductParamInfo(ProductParamInfo productParamInfo) {
		this.productParamInfo = productParamInfo;
	}
	
	
	
}
