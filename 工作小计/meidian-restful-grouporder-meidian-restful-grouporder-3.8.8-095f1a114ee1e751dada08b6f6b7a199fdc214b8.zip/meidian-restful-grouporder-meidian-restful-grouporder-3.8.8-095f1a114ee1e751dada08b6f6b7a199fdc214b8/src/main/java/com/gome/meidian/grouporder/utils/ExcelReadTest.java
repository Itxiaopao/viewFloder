//package com.gome.meidian.grouporder.utils;
//
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.InputStream;
//import java.util.List;
//
//import com.alibaba.fastjson.JSON;
//import com.gomeplus.bs.excel.ExcelContext;
//import com.gomeplus.bs.excel.vo.ExcelImportResult;
//
//public class ExcelReadTest {
//	public static void main(String[] args)throws Exception {
//		InputStream excelStream = new FileInputStream(new File("E:/JKINFO.xls"));
//		ExcelContext context = new ExcelContext("excel-config.xml");
//		ExcelImportResult result = context.readExcel("GroupJKInfo", excelStream);
//		List<GroupJKInfo> listBean = result.getListBean();
//		for (GroupJKInfo jk:listBean) {
//			
//			System.out.println(jk);
//		}
//		System.err.println(listBean.size());
//	}
//}
