package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;
/**
 * 店铺信息
 * @author lishouxu-ds
 *
 */
public class ShopInfoVo implements Serializable{

	private static final long serialVersionUID = -8196713969334389554L;
    private String shopId;//店铺Id
    private String name;//店铺名称
    private String icon;//头像地址
    private Integer status;//状态
    private String type;//类型
    private String description;//描述
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIcon() {
		return icon;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
    

}
