package com.gome.meidian.grouporder.controller.collectFlow;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.collectFlow.CollectFlowManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.UserBasicInfoManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.utils.RequestUtils;
import com.gome.meidian.grouporder.vo.collectFlow.FlowActivity;
import com.gome.meidian.grouporder.vo.collectFlow.FlowCoupon;
import com.gome.meidian.grouporder.vo.collectFlow.MyCollectFlow;
import com.gome.meidian.grouporder.vo.grouporderVo.FlowGroup;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.sum.client.dto.BindShortUrlData;

@RestController
@Validated
@RequestMapping("/v1/collectFlow")
public class CollectFlowController {
	
	@Autowired
	private UserBasicInfoManager userBasicInfoManager;
	@Autowired
	private CollectFlowManager collectFlowManager;
	@Autowired
	private AuthencationUtils authencationUtils;
	
	
	
	/**
	 * 获取用户手机号
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getMobile", method = RequestMethod.GET)
	public ResponseJson getMobile(
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		Map<String, String> usMap = userBasicInfoManager.getUserInfo(userId);
		
		resMap.put("mobile", usMap.get("mobile"));
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 获取集客信息，开始结束时间
	 * @param flowActivityId
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getCollectFlowInfo", method = RequestMethod.GET)
	public ResponseJson getCollectFlowInfo(
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId
			){
		ResponseJson response = new ResponseJson();
		
		FlowActivity flowActivity = collectFlowManager.getCollectFlow(flowActivityId);
		if(null == flowActivity){
			flowActivity = new FlowActivity();
			flowActivity.setTimeScope((byte)2);
		}
		
		response.setData(flowActivity);
		return response;
	}
	
	/**
	 * 校验是否领取集客劵
	 * @param flowActivityId
	 * @return
	 * @throws MeidianException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/checkoutCollectFlow", method = RequestMethod.GET)
	public ResponseJson checkoutCollectFlow(
			@CookieValue(value = "SCN", required = false) String scn,
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		String userId = authencationUtils.authenticationLogin(scn);
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		
		resMap.put("login", 1);
		Map<String, Object> res = collectFlowManager.collectFlowCoupon(userId, flowActivityId);
		
		resMap.put("flowGroup", res.get("flowGroup"));
		resMap.put("staffId", res.get("staffId"));
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 获取集客团列表
	 * @param scn
	 * @param flowActivityId
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@MDStorePriceAnnotation
	@RequestMapping(value = "/flowGroup", method = RequestMethod.GET)
	public ResponseJson flowGroup(
			@CookieValue(value = "SCN", required = false) String scn,
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		String userId = authencationUtils.authenticationLogin(scn);
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		List<FlowGroup> flowGroups = collectFlowManager.flowGroup(userId, flowActivityId, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getKey("priceReqStoreCode"));
		resMap.put("login", 1);
		resMap.put("flowGroups", flowGroups);
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 生成集客劵
	 * @param flowActivityId
	 * @return
	 * @throws MeidianException 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/collectFlowCoupon", method = RequestMethod.GET)
	public ResponseJson collectFlowCoupon(
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId,
			@RequestParam(value = "staffId", required = false) String staffId,
			@NotBlank(message = "{param.error}") @RequestParam("pageCode") String pageCode,
			@RequestParam(value = "vCode", required = false) String vCode,
			@Pattern(regexp="[\u4e00-\u9fa5]{2,6}", message="{chinese.limit}") @RequestParam("nickName") String nickName,
			@Pattern(regexp="^1[0-9]{10}$", message="{mobile.limit}") @RequestParam("mobile") String mobile,
			@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "ctx", required = false) String ctx,
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		// 获取ip
		String ip = null;
		if(null != vCode && !vCode.equalsIgnoreCase(""))
			ip = RequestUtils.getIP(request);
		
		Map<String, String> requestHeader  = CookieUtils.buildRequestHeader(ctx);
		resMap.put("status", collectFlowManager.collectFlowCoupon(flowActivityId, userId, staffId, 
				nickName, pageCode, mobile, 
				vCode, ip, requestHeader));
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 集客劵列表
	 * @param pageNum
	 * @param pageSize
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/getFlowCoupons", method = RequestMethod.GET)
	public ResponseJson getFlowCoupons(
			@RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		List<FlowCoupon> flowCoupons = collectFlowManager.collectFlowCoupons(pageNum, pageSize, userId);
		resMap.put("flowCoupons", flowCoupons);
		
		response.setData(resMap);
		return response;
	}
	/**
	 * 我的集客
	 * @param pageNum
	 * @param pageSize
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/myCollectFlow", method = RequestMethod.GET)
	public ResponseJson myCollectFlow(
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId,
			@RequestParam(value = "pageNum", required = false, defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		List<MyCollectFlow> myCollectFlows = collectFlowManager.myCollectFlow(userId, flowActivityId, pageNum, pageSize);
		resMap.put("myCollectFlows", myCollectFlows);
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 集客分享获取用户头像
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/userImage", method = RequestMethod.GET)
	public ResponseJson userImage(
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		resMap.put("userImage", collectFlowManager.userImage(userId));
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * url长链接转换短链接
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/urlSwitch", method = RequestMethod.GET)
	public ResponseJson urlSwitch(
			@NotBlank(message = "{param.error}") @RequestParam("longUrl") String longUrl,
			@RequestParam(value = "expireDate", required = false) String expireDate
			) throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> resMap = new HashMap<String, Object>();
		resMap.put("shortUrl", null);
		resMap.put("dateTimeVerify", 1);
		if(null != expireDate && !expireDate.equalsIgnoreCase("")){
			// 定时失效
			if(DateUtils.validDate(expireDate)) {
				// 1:需要二维码，2：不需要二维码
				BindShortUrlData bindShortUrlData = collectFlowManager.urlSwitch(longUrl, DateUtils.strDate(expireDate), null);
				if(null != bindShortUrlData){
					resMap.put("shortUrl", bindShortUrlData.getShortUrl());
					response.setData(resMap);
				} else 
					response.setData(resMap);
			} else {
				resMap.put("dateTimeVerify", 0);				
				response.setData(resMap);
			}
		}else {
			// 永久不失效，隔一段时间会手动删除
			BindShortUrlData bindShortUrlData = collectFlowManager.urlSwitch(longUrl, null, null);
			if(null != bindShortUrlData)
				resMap.put("shortUrl", bindShortUrlData.getShortUrl());
			else 
				response.setData(resMap);
		}
		
		
		return response;
	}
	
	
	/**
	 * 发送验证码-集客修改手机号功能
	 * @param mobile 
	 * @param flowActivityId
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/sendCode", method = RequestMethod.GET)
	public ResponseJson sendCode(
			@Pattern(regexp="^1[0-9]{10}$", message="{mobile.limit}") @RequestParam("mobile") String mobile,
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId
			) throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		byte status = collectFlowManager.sendCode(mobile, flowActivityId);
		resMap.put("status", status);
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 添加虚拟集客活动信息
	 * @param flowActivityId
	 * @param pageCode
	 * @param staffId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/insertVMCollectFlow", method = RequestMethod.GET)
	public ResponseJson insertVMCollectFlow(
			@NotBlank(message = "{param.error}") @RequestParam("flowActivityId") String flowActivityId,
			@NotBlank(message = "{param.error}") @RequestParam("pageCode") String pageCode,
			@RequestParam(value = "staffId", required = false) String staffId,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		byte status = collectFlowManager.insertVMCollectFlow(flowActivityId, staffId, userId, pageCode);
		
		resMap.put("status", status);
		
		response.setData(resMap);
		return response;
	}
	
	
	
	
}
