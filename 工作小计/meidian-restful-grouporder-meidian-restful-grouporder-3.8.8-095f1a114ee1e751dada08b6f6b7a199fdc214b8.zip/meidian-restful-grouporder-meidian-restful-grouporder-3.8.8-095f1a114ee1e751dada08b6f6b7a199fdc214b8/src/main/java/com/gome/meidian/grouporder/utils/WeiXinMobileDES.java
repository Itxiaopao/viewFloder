package com.gome.meidian.grouporder.utils;

import java.math.BigInteger;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class WeiXinMobileDES {
	
	private static byte[] eniv = { 1, 2, 3, 4, 5, 6, 7, 8 };
    /**
     * 根据appid, security获取token
     * @param key
     * @param appid
     * @return
     */
    public static String createToken(String appid, String appSercet) {
        if (appid == null || appSercet == null || appid.equals("") || appSercet.equals("")) {
            return "";
        }
        appid = appid.substring(0, 8);
        String timeStamp = String.valueOf(new Date().getTime()).substring(0, 10);
        appSercet = md5(appSercet) + timeStamp;
        try {
            String token = encryptDES(appSercet, appid);
            token = token.replaceAll(" ", "");
            token  = URLEncoder.encode(token,"utf-8");
            return token;
        } catch (Exception e) {
            return "";
        }
    }
    public static String encryptDES(String encryptString, String encryptKey) throws Exception {
        IvParameterSpec zeroIv = new IvParameterSpec(eniv);
        SecretKeySpec key = new SecretKeySpec(encryptKey.getBytes(), "DES");
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key, zeroIv);
        byte[] encryptedData = cipher.doFinal(encryptString.getBytes());
        return MobileBase64.encode(encryptedData);
    }

    private static byte[] deiv = { 1, 2, 3, 4, 5, 6, 7, 8 };
    public static String decryptDES(String decryptString, String decryptKey) throws Exception {
        byte[] byteMi = MobileBase64.decode(decryptString);
        IvParameterSpec zeroIv = new IvParameterSpec(deiv);
        SecretKeySpec key = new SecretKeySpec(decryptKey.getBytes(), "DES");
        Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, key, zeroIv);
        byte decryptedData[] = cipher.doFinal(byteMi);
        return new String(decryptedData);
    }

    /**
     * md5加密
     * @param plainText
     * @return
     */
    private static String md5(String plainText) {
        byte[] secretBytes = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(plainText.getBytes());
            secretBytes = md.digest();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("没有md5这个算法！");
        }
        String md5code = new BigInteger(1, secretBytes).toString(16);// 16进制数字
        for (int i = 0; i < 32 - md5code.length(); i++) {
            md5code = "0" + md5code;
        }
        return md5code;
    }
}