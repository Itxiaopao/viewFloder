package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;

/**
 * 增值服务信息
 * @author shichangjian
 *
 */
public class AppreciationServe implements Serializable{

	private static final long serialVersionUID = 9222418243943521441L;

	private String appreciationServeProductId;	// 增值服务productId
	private String appreciationServeSkuId;		// 增值服务skuId
	private String appreciationServeSkuNo;		// 增值服务skuNo
	private String appreciationServeName;		// 增值服务名称
	private Integer appreciationServeYear;		// 增值服务年限
	private String appreciationServePrice;		// 增值服务金额
	private Integer appreciationServeType;		// 增值服务类型 0-延保,1-屏碎保,2-意外保,3-组合保,4-以换代修

	public AppreciationServe() {
		super();
	}

	public AppreciationServe(String appreciationServeProductId, String appreciationServeSkuId, String appreciationServeSkuNo, 
							String appreciationServeName, Integer appreciationServeYear, String appreciationServePrice, 
							Integer appreciationServeType) {
		super();
		this.appreciationServeProductId = appreciationServeProductId;
		this.appreciationServeSkuId = appreciationServeSkuId;
		this.appreciationServeSkuNo = appreciationServeSkuNo;
		this.appreciationServeName = appreciationServeName;
		this.appreciationServeYear = appreciationServeYear;
		this.appreciationServePrice = appreciationServePrice;
		this.appreciationServeType = appreciationServeType;
	}

	public String getAppreciationServeProductId() {
		return appreciationServeProductId;
	}

	public void setAppreciationServeProductId(String appreciationServeProductId) {
		this.appreciationServeProductId = appreciationServeProductId;
	}

	public String getAppreciationServeSkuId() {
		return appreciationServeSkuId;
	}

	public void setAppreciationServeSkuId(String appreciationServeSkuId) {
		this.appreciationServeSkuId = appreciationServeSkuId;
	}

	public String getAppreciationServeSkuNo() {
		return appreciationServeSkuNo;
	}

	public void setAppreciationServeSkuNo(String appreciationServeSkuNo) {
		this.appreciationServeSkuNo = appreciationServeSkuNo;
	}

	public String getAppreciationServeName() {
		return appreciationServeName;
	}

	public void setAppreciationServeName(String appreciationServeName) {
		this.appreciationServeName = appreciationServeName;
	}

	public Integer getAppreciationServeYear() {
		return appreciationServeYear;
	}

	public void setAppreciationServeYear(Integer appreciationServeYear) {
		this.appreciationServeYear = appreciationServeYear;
	}

	public String getAppreciationServePrice() {
		return appreciationServePrice;
	}

	public void setAppreciationServePrice(String appreciationServePrice) {
		this.appreciationServePrice = appreciationServePrice;
	}

	public Integer getAppreciationServeType() {
		return appreciationServeType;
	}

	public void setAppreciationServeType(Integer appreciationServeType) {
		this.appreciationServeType = appreciationServeType;
	}

	
	
}
