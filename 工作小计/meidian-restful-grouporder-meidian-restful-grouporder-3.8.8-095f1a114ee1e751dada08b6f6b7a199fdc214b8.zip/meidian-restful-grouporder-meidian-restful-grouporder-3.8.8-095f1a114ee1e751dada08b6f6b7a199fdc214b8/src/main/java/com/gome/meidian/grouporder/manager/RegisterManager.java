package com.gome.meidian.grouporder.manager;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.rocketmq.client.exception.MQBrokerException;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.remoting.exception.RemotingException;
import com.gome.architect.risk.dto.RequestV2;
import com.gome.loom.model.TpModel;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.common.MeidianMemberService;
import com.gome.meidian.grouporder.common.MeidianRiskService;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.MobileUtils;
import com.gome.meidian.grouporder.utils.RequestUtils;
import com.gome.meidian.grouporder.utils.UserConstants;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.register.BaseUserVo;
import com.gome.meidian.grouporder.vo.register.ShopSmsCodeVo;
import com.gome.meidian.grouporder.vo.register.SlideInfoVo;
import com.gome.meidian.grouporder.vo.register.UserInfoVo;
import com.gome.meidian.grouporder.vo.register.UserRegistVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.entity.UserInfo;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.base.IUserBaseProfileFacade;
import com.gome.userCenter.facade.userservice.profile.IEmailMobileFacade;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.GomeUnifyRegisterUser;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gome.userCenter.model.UserRegisterResult;

import redis.Gcache;

@Service
public class RegisterManager {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private MeidianMemberService meidianMemberService;
	@Autowired
	private MeidianRiskService meidianRiskService;
	@Autowired
	private IUserBaseProfileFacade iUserBaseProfileFacade;
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	@Autowired
	private IEmailMobileFacade iEmailMobileFacade;
	@Autowired
	private IUserInfoManager iUserInfoManager;
	@Autowired
    private WechatLoginManager wechatLoginManager;

	@Resource(name = "userCenter")
	private Gcache userCenter;
	
	@Value("${cookie.path}")
    private String path;
    @Value("${cookie.domain}")
    private String domain;
    @Value("${cookie.time}")
    private int time;
    
	/**
	 * 检查手机号是否存在
	 * @param userInfoVo
	 * @return
	 */
	public void checkMobile(UserInfoVo userInfoVo) throws MeidianException {
		//手机号合法校验
		boolean checkStatus = MobileUtils.isPhone(userInfoVo.getMobile());
		if(!checkStatus){
			throw new ServiceException("base.user.mobile.noCheck");
		}else{
			//手机号是否存在
			boolean status = meidianMemberService.existUser(userInfoVo.getMobile());
			if(status){
				throw new ServiceException("base.user.mobile.exit");
			}
		}
	}
	
	/**
	 * 发送短信验证码+短信风控
	 * @param userInfoVo
	 */
	public void sendSmsCode(UserInfoVo userInfoVo,HttpServletRequest request) throws MeidianException {
		//手机号合法校验
		this.checkMobile(userInfoVo);
		//短信风控
		String riskStatus=userCenter.get(UserAndRegisterRiskSwitchManager.RISK_SWITCH_WAP_MEIDIAN_REGISTER_SMS);
		if(null!=riskStatus&&WechatLoginManager.RESULT_SUCCESS_NO.equals(riskStatus)){
			//当标识不是null 或者 false的时候,风控降级
		}else{
			//true 或者  null 使用风控
			RequestV2 requestV2 = new RequestV2();
			requestV2.setBizNo(UserConstants.BIZNO_REGISTER_SMS);//美店注册短信防刷风控
			requestV2.setUserId(userInfoVo.getMobile());
			requestV2.setPhone(userInfoVo.getMobile());
			meidianRiskService.predict(requestV2,request);
		}
		//发送短信验证码
		TpModel smsModel = new TpModel(UserConstants.GOMESHOP_REG_PHONE_BUSINESSNAME,UserConstants.GOMESHOP_REG_PHONE_BUSINESSNAME_ID);//设置注册短信模版
		smsModel.setPhone(userInfoVo.getMobile());
		boolean status = meidianMemberService.sendSms(smsModel);
		if(!status){
			throw new ServiceException("base.user.smsCode.fail");
		}
	}
	
	/**
	 * 校验滑块风控
	 * @param userInfoVo
	 * @return
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	public ResponseJson checkSlide(SlideInfoVo slideInfoVo) throws MeidianException {
		//校验滑块
		return meidianRiskService.sliderVal(slideInfoVo.getToken());
	}
	
	/**
	 * 注册风控+短信验证码校验+注册接口+登录返scn+异步同步信息
	 * @param userInfoVo
	 */
	public Map<String,Object> registerUser(UserRegistVo userRegistVo,HttpServletRequest request,HttpServletResponse response) throws MeidianException, MQClientException, RemotingException, MQBrokerException, InterruptedException {
		//手机号合法校验
		UserInfoVo userInfo = new UserInfoVo();
		userInfo.setMobile(userRegistVo.getMobile());
		this.checkMobile(userInfo);
		//密码合法校验
		boolean checkStatus = MobileUtils.isPassword(userRegistVo.getPassword());
		if(!checkStatus){
			throw new ServiceException("base.user.password.noCheck");
		}
		//注册风控
		String riskStatus=userCenter.get(UserAndRegisterRiskSwitchManager.RISK_SWITCH_WAP_MEIDIAN_REGISTER);
		if(null!=riskStatus&&WechatLoginManager.RESULT_SUCCESS_NO.equals(riskStatus)){
			//当标识不是null 或者 false的时候,风控降级
		}else{
			//null or true 使用注册风控
			RequestV2 requestV2 = new RequestV2();
			requestV2.setBizNo(UserConstants.BIZNO_REGISTER);//美店注册风控
			requestV2.setUserId(userRegistVo.getMobile());
			requestV2.setPhone(userRegistVo.getMobile());
			meidianRiskService.predict(requestV2,request);
		}

		//短信验证码校验
		boolean status = meidianMemberService.checkVcode(UserConstants.GOMESHOP_REG_PHONE_BUSINESSNAME,userRegistVo.getMobile(),userRegistVo.getSmsCode(),true);
		if(!status){
			throw new ServiceException("base.user.smsCode.checkFail");
		}
		//新用户注册接口-成功返scn/同步信息
		Map<String, Object> map = this.executeRegister(userRegistVo, request, response);
		return map;
	}
	
	/**
	 * 获取用户头型昵称
	 * @param baseUserVo
	 * @return
	 * @throws MeidianException
	 */
	public Map<String,Object> queryUserInfo(BaseUserVo baseUserVo) throws MeidianException {
		Map<String,Object> map = new HashMap<String,Object>();
		//获取用户昵称
		Map<String, Object> param = new HashMap<>();
		param.put("companyName", UserConstants.CHANNEL_FLAG);
		MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(baseUserVo.getUserId(),UserConstants.INVOKE_FROM,param);
		if(userResult!=null && userResult.isSuccess()) {
			UnifyUserInfoExt userInfo = userResult.getBuessObj();
			if(userInfo!=null){
				map.put("userName", userInfo.getLogin());//用户名
				String nikeName = userInfo.getNikename();
				if(nikeName==null || nikeName.equals("")){
					nikeName = "";//昵称为空
				}
				map.put("nikeName", nikeName);//昵称
				map.put("mobile", userInfo.getMobile());//手机号
			}else{
				logger.info("用户昵称信息不存在");
				throw new ServiceException("base.user.info.exception");
			}
		}else{
			logger.info("用户呢称信息失败信息,code:{},message:{}",userResult.getCode(),userResult.getMessage());
			throw new ServiceException("base.user.info.exception");
		}
		//获取用户头像
		UserResult<String> userImgResult = iUserBaseProfileFacade.getMyImagePath(baseUserVo.getUserId(), UserConstants.INVOKE_FROM);
		if(userImgResult!=null && userImgResult.isSuccess()) {
			String userImg = userImgResult.getBuessObj();
			map.put("userImg", userImg);
		}else{
			logger.info("用户头像失败信息,code:{},message:{}",userImgResult.getCode(),userImgResult.getMessage());
			throw new ServiceException("base.user.img.exception");
		}
		return map;
	}
	
	//新用户注册接口-成功返scn/同步信息
	private Map<String,Object> executeRegister(UserRegistVo userRegistVo,HttpServletRequest request,HttpServletResponse response) throws MeidianException, MQClientException, RemotingException, MQBrokerException, InterruptedException {
		Map<String,Object> map = new HashMap<String, Object>();
		GomeUnifyRegisterUser gomeUser = new GomeUnifyRegisterUser();
		gomeUser.setRegisterType(UserConstants.REGISTER_TYPE_MOBILEREG);//手机注册
		gomeUser.setRegisterIp(RequestUtils.getIP(request));
		gomeUser.setRegisterSource(userRegistVo.getRegisterSource());//注册来源-会员申请
		gomeUser.setLogin(userRegistVo.getMobile());
		gomeUser.setPassword(userRegistVo.getPassword());
		gomeUser.setMobile(userRegistVo.getMobile());
		Map<String,Object> extMap = new HashMap<String,Object>();
		extMap.put("companyName", UserConstants.CHANNEL_FLAG);//渠道标识
		extMap.put("distinctId", userRegistVo.getDistinctId());//灯塔埋码
		UserRegisterResult<GomeUnifyRegisterUser> registerUnifyUser = meidianMemberService.registerUnifyUser(gomeUser, extMap);
		if(registerUnifyUser.isSuccess()){
			//注册成功
			map.put("status",UserConstants.REGIST_SUCCESS);//注册状态
			GomeUnifyRegisterUser registerUser = registerUnifyUser.getBuessObj();
			map.put("buessObj",registerUser);//用户信息
			map.put("extMap",registerUnifyUser.getExtMap());//扩展字段(含scn)
			//封装注册人信息
			AuthencationVo userInfo = wechatLoginManager.getAutencationVo(registerUser.getId());
			map.put("userInfo", userInfo);
			//存储SCN
			this.backScn(registerUnifyUser, response);
			//异步消息-用户信息
			logger.info("获取用户信息:{}",registerUser.toString());
			this.executeSynUser(userRegistVo, registerUser);
		}else{
			//注册失败
			map.put("status",UserConstants.REGIST_FAILS);//注册状态
			map.put("code",registerUnifyUser.getCode());//注册错误码
			map.put("message",registerUnifyUser.getMessage());//注册错误信息
		}
		return map;
	}
	
	//执行scn回写操作
	private void backScn(UserRegisterResult<GomeUnifyRegisterUser> registerUnifyUser,HttpServletResponse response) throws MeidianException {
		String SCN = null;
		String userId = null;
		if(registerUnifyUser.getExtMap()!=null && registerUnifyUser.getExtMap().size()>0){
            SCN = (String)registerUnifyUser.getExtMap().get("SCN");
            try {
                SCN = URLEncoder.encode(SCN,"UTF-8");
            } catch (UnsupportedEncodingException e) {
            	logger.info("doSNSLogin-URLEncoder SCN:{},error:{}",SCN,e);
            }
        }
		if(registerUnifyUser.getBuessObj()!=null){
			userId = registerUnifyUser.getBuessObj().getId();
		}
		if(StringUtils.isNotBlank(SCN)&&StringUtils.isNotBlank(userId)){
			CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID,userId,path,domain,time);
		}
	}
	
	//执行异步用户信息发送
	private void executeSynUser(UserRegistVo userRegistVo,GomeUnifyRegisterUser registerUser) throws MeidianException, MQClientException, RemotingException, MQBrokerException, InterruptedException {
		String inviteMobile = userRegistVo.getInviteMobile();
		if(inviteMobile!=null&&!inviteMobile.equals("")){
			boolean checkStatus = MobileUtils.isPhone(inviteMobile);
			if(!checkStatus){
				logger.info("邀请人手机号不合法，邀请人手机号为:{}",inviteMobile);
			}else{
				Map<String, Object> param = new HashMap<>();
				param.put("companyName", UserConstants.CHANNEL_FLAG);
				UserResult<List<UnifyUserInfoExt>> userResult = iEmailMobileFacade.queryUserInfoListByMobile(inviteMobile,UserConstants.INVOKE_FROM,param);
				if(userResult != null && userResult.isSuccess() && userResult.getCode() == 200) {
					List<UnifyUserInfoExt> list = userResult.getBuessObj();
					if(list!=null && list.size() > 0) {
						UnifyUserInfoExt ext = list.get(0);
						userRegistVo.setInviteUserId(ext.getId());
					}else{
						logger.info("邀请人手机号未找到用户信息，邀请人手机号为:{}",inviteMobile);
					}
				}else{
					logger.info("邀请人手机号未找到用户信息，邀请人手机号为:{}",inviteMobile);
				}
			}
		}
		UserInfo user = new UserInfo();
		user.setUserId(registerUser.getId());
		user.setCreateType(userRegistVo.getCreateType());
		user.setAddType(UserConstants.REGISTE);
		user.setParentInviteUserId(userRegistVo.getInviteUserId());
		iUserInfoManager.addUserInfoByInviteUser(user,null,UserConstants.INVOKE_FROM);
		logger.info("同步用户信息成功，用户id为:{},邀请人id为:{}",registerUser.getId(),user.getParentInviteUserId());
	}
	
	/**
	 * 店主认证-发送短信验证码
	 * @param userInfoVo
	 * @throws MeidianException
	 */
	public void sendSmsCodeShop(UserInfoVo userInfoVo) throws MeidianException {
		//手机号合法校验
		boolean checkStatus = MobileUtils.isPhone(userInfoVo.getMobile());
		if(!checkStatus){
			throw new ServiceException("base.user.mobile.noCheck");
		}
		//发送短信验证码
		TpModel smsModel = new TpModel(UserConstants.GOMESHOP_PHONE_AUTH_BUSINESSNAME,UserConstants.GOMESHOP_PHONE_AUTH_BUSINESSNAME_ID);//设置注册短信模版
		smsModel.setPhone(userInfoVo.getMobile());
		boolean status = meidianMemberService.sendSms(smsModel);
		if(!status){
			throw new ServiceException("base.user.smsCode.fail");
		}
	}
	
	/**
	 * 校验短信验证码
	 * @param shopSmsCodeVo
	 * @throws MeidianException
	 */
	public void checkSmsCodeShop(ShopSmsCodeVo shopSmsCodeVo) throws MeidianException {
		//手机号合法校验
		boolean checkStatus = MobileUtils.isPhone(shopSmsCodeVo.getMobile());
		if(!checkStatus){
			throw new ServiceException("base.user.mobile.noCheck");
		}
		//短信验证码校验
		boolean status = meidianMemberService.checkVcode(UserConstants.GOMESHOP_PHONE_AUTH_BUSINESSNAME,shopSmsCodeVo.getMobile(),shopSmsCodeVo.getSmsCode(),true);
		if(!status){
			throw new ServiceException("base.user.smsCode.checkFail");
		}
	}
	
}
