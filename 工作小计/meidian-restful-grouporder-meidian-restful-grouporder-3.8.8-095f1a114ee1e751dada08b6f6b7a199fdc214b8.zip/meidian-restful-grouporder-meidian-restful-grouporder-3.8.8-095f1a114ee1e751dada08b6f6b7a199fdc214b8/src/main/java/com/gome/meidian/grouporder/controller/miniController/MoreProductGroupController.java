package com.gome.meidian.grouporder.controller.miniController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.miniManager.MoreProductGroupManager;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReqVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.sso.model.UserInfoCache;

import redis.Gcache;

@RestController
@Validated
@RequestMapping("/v1/moreProductGroup")
public class MoreProductGroupController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private MoreProductGroupManager moreProductGroupManager;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Resource(name = "gcachezz")
	private Gcache gcachezz;
	
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认三级区域，朝阳，全国价
	
	@RequestMapping(value = "/userMoreProSameGroupRestrict", method = RequestMethod.GET)
	public ResponseJson userMoreProSameGroupRestrict(
			@NotBlank(message = "{param.error}") @RequestParam("mutiCollectionId") String mutiCollectionId,
			@RequestParam(value = "groupId") Long groupId,
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == scn || scn.equalsIgnoreCase("")) {
			resMap.put("login", 0);			
			response.setData(resMap);
			return response;
		}
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		Long userId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		}else {
			resMap.put("login", 0);			
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
		Boolean userRestrict = moreProductGroupManager.userSameGroupRestrict(userId, mutiCollectionId, groupId);
		resMap.put("userRestrict", userRestrict);
		
		response.setData(resMap);
		return response;
	}
}
