package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class TaskMatchVo implements Serializable {

	private static final long serialVersionUID = 1523870780265621391L;

	@NotNull(message = "{shop.task.info.taskId.notNull}")
	private Long taskId;
	
	public Long getTaskId() {
		return taskId;
	}
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

}
