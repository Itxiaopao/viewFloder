package com.gome.meidian.grouporder.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtils {

	public static int getWeekDay() {
		Calendar now = Calendar.getInstance();
		// 一周第一天是否为星期天
		boolean isFirstSunday = (now.getFirstDayOfWeek() == Calendar.SUNDAY);
		// 获取周几
		int weekDay = now.get(Calendar.DAY_OF_WEEK);
		// 若一周第一天为星期天，则-1
		if (isFirstSunday) {
			weekDay = weekDay - 1;
			if (weekDay == 0) {
				weekDay = 7;
			}
		}
		return weekDay;
	}

	public static long currentTimeSecs() {
		return System.currentTimeMillis();
	}
	
	public static Date transDateForNum(long timestamp) {
		SimpleDateFormat sdf =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //设置格式
		String timeStr = sdf.format(timestamp);
		try {
			return sdf.parse(timeStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static long getLong(String date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date da = null;
		try {
			da = simpleDateFormat.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long ts = da.getTime();

		return ts;
	}

	public static boolean validDate(String str) {
		boolean convertSuccess = true;
//　　　　　指定日期格式为四位年/两位月份/两位日期，注意yyyy/MM/dd区分大小写；
//		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
//　　　　　	设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
			format.setLenient(false);
			format.parse(str);
		} catch (ParseException e) {
//			e.printStackTrace();
//			如果throw java.text.ParseException或者NullPointerException，就说明格式不对
			convertSuccess=false;
		} 
		return convertSuccess;
	}
	
	public static Date strDate(String strDate){
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date da = null;
		try {
			da = simpleDateFormat.parse(strDate);
		} catch (ParseException e) {
			return null;
		}
		return da;
	}
	
	public static Date getDayStartTime(int day) {
		Calendar calendar = new GregorianCalendar();
        calendar.add(Calendar.DAY_OF_MONTH,day);
        calendar.set(Calendar.HOUR_OF_DAY,0);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.SECOND,0);
        calendar.set(Calendar.MILLISECOND,0);
		return calendar.getTime();
	}
	

	/**
	 * 获取当月第一天
	 * @return
	 */
	public static Date getThisMonthFirstDay(Date date) {
		Calendar sameMonth = Calendar.getInstance();
		sameMonth.setTime(date);
		sameMonth.add(Calendar.MONTH, 0);
		sameMonth.set(Calendar.DAY_OF_MONTH,1);
		sameMonth.set(Calendar.HOUR_OF_DAY, 0);// 时
		sameMonth.set(Calendar.MINUTE, 0); // 分
		sameMonth.set(Calendar.SECOND, 0);// 秒
		sameMonth.set(Calendar.MILLISECOND, 0);// 秒
		return sameMonth.getTime();
	}
	
	/**
	 * 获取下个月第一天
	 * @return
	 */
	public static Date getNextMonthFirstDay(Date date) {
		Calendar nextMonth = Calendar.getInstance();
		nextMonth.setTime(date);
		nextMonth.add(Calendar.MONTH, 1);
		nextMonth.set(Calendar.DAY_OF_MONTH,1);
		nextMonth.set(Calendar.HOUR_OF_DAY, 0);// 时
		nextMonth.set(Calendar.MINUTE, 0); // 分
		nextMonth.set(Calendar.SECOND, 0);// 秒
		nextMonth.set(Calendar.MILLISECOND, 0);// 秒
		return nextMonth.getTime();
	}
	public static Date getDayEndTime(int day) {
		Calendar calendar = new GregorianCalendar();
        calendar.add(Calendar.DAY_OF_MONTH,day);
		calendar.set(Calendar.HOUR_OF_DAY,23);
        calendar.set(Calendar.MINUTE,59);
        calendar.set(Calendar.SECOND,59);
        calendar.set(Calendar.MILLISECOND,999);
		return calendar.getTime();
	}
	
}
