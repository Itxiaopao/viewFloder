package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class ShareProductInfoVo implements Serializable {

	private static final long serialVersionUID = 5284569627722383292L;
	
	//商品ID
	@NotBlank(message = "{param.error}")
	private String productId;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
}
