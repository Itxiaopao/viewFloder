package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;

public class MeidianPrice implements Serializable{

	private static final long serialVersionUID = 6334712068675827913L;

	
	private String skuId;		// 商品skuId
	private String meidianPrice;// 最终价格
	private String promotionId;	// 价格方案id
	private String priceType;	// 价格类型
	private String channel;		// 价格渠道
    private Integer rq;			// 价格售卖剩余数量
    private String priceKey;	// 快速购，传购物车，促销id密文
    
	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getPromotionId() {
		return promotionId;
	}

	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}

	public String getPriceType() {
		return priceType;
	}

	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Integer getRq() {
		return rq;
	}

	public void setRq(Integer rq) {
		this.rq = rq;
	}

	public String getMeidianPrice() {
		return meidianPrice;
	}

	public void setMeidianPrice(String meidianPrice) {
		this.meidianPrice = meidianPrice;
	}

	public String getPriceKey() {
		return priceKey;
	}

	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}
    
    
    
}
