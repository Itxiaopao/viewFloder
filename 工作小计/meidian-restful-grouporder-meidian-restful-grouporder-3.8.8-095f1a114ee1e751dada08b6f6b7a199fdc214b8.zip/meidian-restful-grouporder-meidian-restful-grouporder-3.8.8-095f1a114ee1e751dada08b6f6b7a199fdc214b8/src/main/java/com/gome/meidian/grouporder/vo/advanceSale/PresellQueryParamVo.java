package com.gome.meidian.grouporder.vo.advanceSale;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;
import java.util.List;

/**
 * @Author yuliang-ds1
 * @Date 2019/2/16 13:52
 * @Description
 */
public class PresellQueryParamVo implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * skuNo
     */
    @NotBlank(message = "{param.error}")
    private String skuNo;
    /**
     * 自营:false
     * 联营:true
     */
    private boolean isShop;
    /**
     * 门店码
     */
    private String storeCode;
    /**
     * 三级区域码
     */
    private String countyCode;
    /**
     * 四级区域码
     */
    private String townCode;
    /**
     * 门店码列表 批量查询时
     */
    private List<String> storeCodeList;
    /**
     * 三级区域码列表 批量查询时
     */
    private List<String> countyCodeList;
    /**
     * 四级区域码列表 批量查询时
     */
    private List<String> townCodeList;


    public PresellQueryParamVo(){

    }

    public String getSkuNo() {
        return skuNo;
    }

    public void setSkuNo(String skuNo) {
        this.skuNo = skuNo;
    }

    public boolean isShop() {
        return isShop;
    }

    public void setShop(boolean shop) {
        isShop = shop;
    }

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public String getCountyCode() {
        return countyCode;
    }

    public void setCountyCode(String countyCode) {
        this.countyCode = countyCode;
    }

    public String getTownCode() {
        return townCode;
    }

    public void setTownCode(String townCode) {
        this.townCode = townCode;
    }

    public List<String> getStoreCodeList() {
        return storeCodeList;
    }

    public void setStoreCodeList(List<String> storeCodeList) {
        this.storeCodeList = storeCodeList;
    }

    public List<String> getCountyCodeList() {
        return countyCodeList;
    }

    public void setCountyCodeList(List<String> countyCodeList) {
        this.countyCodeList = countyCodeList;
    }

    public List<String> getTownCodeList() {
        return townCodeList;
    }

    public void setTownCodeList(List<String> townCodeList) {
        this.townCodeList = townCodeList;
    }
}