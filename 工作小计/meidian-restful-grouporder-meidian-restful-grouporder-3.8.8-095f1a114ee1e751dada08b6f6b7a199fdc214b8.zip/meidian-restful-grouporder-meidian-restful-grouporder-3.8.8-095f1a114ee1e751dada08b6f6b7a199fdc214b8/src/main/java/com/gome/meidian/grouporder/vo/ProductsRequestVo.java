package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupOrderVerify;

/**
 * 618
 * 获取商品列表
 * @author shichangjian
 *
 */
public class ProductsRequestVo implements Serializable{

	private static final long serialVersionUID = -7012263843268883071L;

	private List<ProductIdActivityId> productIdActivityIds;
//	@NotBlank(message = "{param.error}", groups = { groupOrderVerify.class})
	private String areaCode;
//	@NotBlank(message = "{param.error}", groups = { groupOrderVerify.class})
	private String organizationId;
	private String storeCode;		//门店编码
	private String ukey;			//凑单，爆品ukey
	private String typeName;		//商品类型名
	
	
	public List<ProductIdActivityId> getProductIdActivityIds() {
		return productIdActivityIds;
	}
	public void setProductIdActivityIds(List<ProductIdActivityId> productIdActivityIds) {
		this.productIdActivityIds = productIdActivityIds;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getStoreCode() {
		return storeCode;
	}
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}
	public String getUkey() {
		return ukey;
	}
	public void setUkey(String ukey) {
		this.ukey = ukey;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	
	
}
