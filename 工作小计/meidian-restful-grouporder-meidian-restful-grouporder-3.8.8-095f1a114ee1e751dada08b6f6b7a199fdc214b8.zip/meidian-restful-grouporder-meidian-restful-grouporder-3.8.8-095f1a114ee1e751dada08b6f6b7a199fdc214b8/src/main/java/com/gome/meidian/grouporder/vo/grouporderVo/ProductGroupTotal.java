package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

/**
 * 商品已团件数
 * @author shichangjian
 *
 */
public class ProductGroupTotal implements Serializable{

	private static final long serialVersionUID = -3292073827762740373L;

	private String productId;			//商品id
	private Integer totalBuyNumbers;	//已团件数
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Integer getTotalBuyNumbers() {
		return totalBuyNumbers;
	}
	public void setTotalBuyNumbers(Integer totalBuyNumbers) {
		this.totalBuyNumbers = totalBuyNumbers;
	}
	
	
	
	
}
