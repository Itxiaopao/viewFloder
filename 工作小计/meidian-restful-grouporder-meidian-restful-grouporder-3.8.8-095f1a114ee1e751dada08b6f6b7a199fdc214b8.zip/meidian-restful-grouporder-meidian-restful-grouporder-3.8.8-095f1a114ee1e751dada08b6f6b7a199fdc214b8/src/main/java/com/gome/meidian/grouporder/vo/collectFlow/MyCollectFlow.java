package com.gome.meidian.grouporder.vo.collectFlow;

import java.io.Serializable;

/**
 * 我的集客
 * @author shichangjian
 *
 */
public class MyCollectFlow implements Serializable{

	private static final long serialVersionUID = -8649122734130490828L;

	private String flowActivityId;	// 集客活动id
	private String nickName;		// 客户昵称
	private String userImage;		// 客户头像
	private String mobile;			// 客户手机号
	private Byte flowGroupStatus;	// 0:未参与，1：参与集客团
	private Integer verification;	// 是否核销 0：已核销   1：已取消   2：未核销
	
	public MyCollectFlow() {
		super();
	}
	public MyCollectFlow(String flowActivityId, String nickName, String userImage, 
						String mobile, Byte flowGroupStatus, Integer verification) {
		super();
		this.flowActivityId = flowActivityId;
		this.nickName = nickName;
		this.userImage = userImage;
		this.mobile = mobile;
		this.flowGroupStatus = flowGroupStatus;
		this.verification = verification;
	}
	public String getFlowActivityId() {
		return flowActivityId;
	}
	public void setFlowActivityId(String flowActivityId) {
		this.flowActivityId = flowActivityId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getUserImage() {
		return userImage;
	}
	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Byte getFlowGroupStatus() {
		return flowGroupStatus;
	}
	public void setFlowGroupStatus(Byte flowGroupStatus) {
		this.flowGroupStatus = flowGroupStatus;
	}
	public Integer getVerification() {
		return verification;
	}
	public void setVerification(Integer verification) {
		this.verification = verification;
	}
	
	
	
}
