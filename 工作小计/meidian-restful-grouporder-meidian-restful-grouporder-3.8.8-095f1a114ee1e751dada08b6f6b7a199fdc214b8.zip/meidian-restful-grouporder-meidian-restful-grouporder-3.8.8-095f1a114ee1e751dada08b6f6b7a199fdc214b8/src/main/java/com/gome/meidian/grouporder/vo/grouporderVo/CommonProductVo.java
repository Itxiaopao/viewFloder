package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

public class CommonProductVo implements Serializable {

	private static final long serialVersionUID = -3140652020003209212L;
	private String productId;
	private String skuId;
	private String skuNo;
	private Integer productTag;  // 1：自营 2：联营
	private String image;  //商品图
	private Integer productStatus;  // 上下价状态1：上架，-1：下架
	private String productName;  
	private String shopId;  // 联营pop商铺id

	private Integer preSellFlag; //预售标识 1:预售 0:非预售
    private String depositExpand; //是否膨胀金额 //1:是  0:不是
	private String deductibleDepositDesc; //膨胀金额描述
	private Double deposit; //定金
	private Double deductibleDeposit;  //膨胀金额
	private Double sellPrice; //初始预售价
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public Integer getProductTag() {
		return productTag;
	}
	public void setProductTag(Integer productTag) {
		this.productTag = productTag;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public Integer getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(Integer productStatus) {
		this.productStatus = productStatus;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public Integer getPreSellFlag() {
		return preSellFlag;
	}
	public void setPreSellFlag(Integer preSellFlag) {
		this.preSellFlag = preSellFlag;
	}
	public String getDepositExpand() {
		return depositExpand;
	}
	public void setDepositExpand(String depositExpand) {
		this.depositExpand = depositExpand;
	}
	public String getDeductibleDepositDesc() {
		return deductibleDepositDesc;
	}
	public void setDeductibleDepositDesc(String deductibleDepositDesc) {
		this.deductibleDepositDesc = deductibleDepositDesc;
	}
	public Double getDeposit() {
		return deposit;
	}
	public void setDeposit(Double deposit) {
		this.deposit = deposit;
	}
	public Double getSellPrice() {
		return sellPrice;
	}
	public void setSellPrice(Double sellPrice) {
		this.sellPrice = sellPrice;
	}
	public Double getDeductibleDeposit() {
		return deductibleDeposit;
	}
	public void setDeductibleDeposit(Double deductibleDeposit) {
		this.deductibleDeposit = deductibleDeposit;
	}

	
	
}
