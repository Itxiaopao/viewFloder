package com.gome.meidian.grouporder.manager.mshopUserManager;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.entity.UserRaceVo;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.mshopUserVo.SalesLeaderboardVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.service.ISaleRaceService;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.weChat.IGomeShopWeChatFacade;
import com.gome.userBase.model.weChat.GomeShopBasicInfoModel;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import lombok.extern.slf4j.Slf4j;

/**
 * 销售排名
 * @author limenghui-ds
 * @create 2019-11-27 11:24
 */
@Slf4j
@Service
public class SalesLeaderboardManager {
    /**
     * 头像分辨率
     */
    @Value("${meidian.image.userImage}")
    private String userImage;
    /**
     * http、https协议
     */
    @Value("${meidian.image.agreement}")
    private String agreement;

    @Autowired
    private IGomeShopWeChatFacade gomeShopWeChatFacade;
    @Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private ISaleRaceService saleRaceService;
    @Autowired
    private RestTemplate restTemplate;
    /**
     * 员工身份http地址
     */
    @Value("${mshop.employeeType.url}")
    private String employeeTypeUrl;



    public ResponseJson<Map<String,Object>> salesLeaderboardList(String currentUser, int pageNo) {
        ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        //判断用户是否登录
        if (null == currentUser) {
            resMap.put("login", 0);
            resMap.put("msg", "未登录");
            responseJson.setData(resMap);
            return responseJson;
        } else {
            resMap.put("login", 1);
        }
        //判断用户是否是(电器员工+互联网员工)
        Integer identity = 1;
        String employeeType = getEmployeeType(Long.valueOf(currentUser));
        if (EmployeeTypeEnum.dql.name().equals(employeeType) || EmployeeTypeEnum.hlwl.name().equals(employeeType)) {
            identity = 3;
        }

        resMap.put("identity", identity);
        if (identity == 1) {
            resMap.put("msg", "非电器员工和非互联网员工");
            responseJson.setData(resMap);
            return responseJson;
        }
        //片总：查询排行榜的列表，分页
        ResultEntity<Map<String, Object>> mapResultEntity = saleRaceService.queryRaceTopN(Long.valueOf(currentUser), pageNo, 100);
        if (null != mapResultEntity && MapUtils.isNotEmpty(mapResultEntity.getBusinessObj())) {
            //列表
            List<UserRaceVo> ranking = (List<UserRaceVo>) mapResultEntity.getBusinessObj().get("ranking");
            List<UserRaceVo> salesList = null == ranking ? Lists.newArrayList() : ranking;
            List<String> collect = salesList.parallelStream().map(i -> String.valueOf(i.getUserId())).collect(Collectors.toList());
            if (!collect.contains(currentUser)) {
                //自己
                UserRaceVo raceVo = (UserRaceVo) mapResultEntity.getBusinessObj().get("self");
                if (null != raceVo) {
                    collect.add(String.valueOf(raceVo.getUserId()));
                    salesList.add(raceVo);
                }
            }
            //封装Map集合对象
            HashMap<Long, SalesLeaderboardVo> salesVoMap = Maps.newHashMap();
            //批量调用会员的接口，获取头像和昵称
            UserResult<List<GomeShopBasicInfoModel>> userResult = gomeShopWeChatFacade.batchQueryUserBasicInfo(collect, "gomeShop");
            if (null != userResult && CollectionUtils.isNotEmpty(userResult.getBuessObj())) {
                userResult.getBuessObj().stream().forEach(basicInfoModel -> {
                    SalesLeaderboardVo salesLeaderboardVo = new SalesLeaderboardVo();
                    String image = StringUtils.isNotEmpty(basicInfoModel.getWeixinImg()) ? basicInfoModel.getWeixinImg() : basicInfoModel.getGomeImg();
                    String nickName = StringUtils.isNotEmpty(basicInfoModel.getWeixinNickName()) ? basicInfoModel.getWeixinNickName() : basicInfoModel.getGomeNickName();
                    //对头像缩小处理
                    String imagePath = ImageUtils.userImageUrlInfo2(image, userImage, agreement);
                    salesLeaderboardVo.setHeadImage(imagePath);
                    salesLeaderboardVo.setNickName(nickName);
                    salesVoMap.put(Long.valueOf(basicInfoModel.getUserId()), salesLeaderboardVo);
                });
            }

            //遍历结果集，组装数据
            List<SalesLeaderboardVo> resultList = Lists.newArrayList();
            Iterator<UserRaceVo> iterator = salesList.iterator();
            while (iterator.hasNext()) {
                UserRaceVo userRaceVo = iterator.next();
                SalesLeaderboardVo voMap = null == salesVoMap.get(userRaceVo.getUserId()) ?
                        new SalesLeaderboardVo() :
                        salesVoMap.get(userRaceVo.getUserId());
                voMap.setUserId(userRaceVo.getUserId());
                voMap.setIntegral(null == userRaceVo.getIntegral() ? 0 : userRaceVo.getIntegral());
                voMap.setRank(null == userRaceVo.getRanking() ? 0 : userRaceVo.getRanking());
                voMap.setSales(null == userRaceVo.getSaleVolume() ? 0 : userRaceVo.getSaleVolume());
                voMap.setInviteCount(null == userRaceVo.getInviteUserCount() ? 0 : userRaceVo.getInviteUserCount());
                if (userRaceVo.getUserId().longValue() == Long.valueOf(currentUser).longValue()) {
                    resMap.put("self", voMap);
                    //未上榜,不将自己放到list榜单中
                    if (voMap.getRank() == 0) {
                        continue;
                    }
                }
                resultList.add(voMap);
            }
            resMap.put("list", resultList);
        }
        responseJson.setData(resMap);
        return responseJson;
    }
    public ResponseJson<Map<String, Object>> getActivityStartTime(String currentUser) {
        ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
        Map<String, Object> resMap = new HashMap<String, Object>();
        //判断用户是否登录
        if (null == currentUser) {
            resMap.put("login", 0);
            resMap.put("msg", "未登录");
            responseJson.setData(resMap);
            return responseJson;
        } else {
            resMap.put("login", 1);
        }
        long startTime = 0L;
        ResultEntity<Map<String, Long>> mapResultEntity = saleRaceService.queryActivityCountdown();
        if (null != mapResultEntity && null != mapResultEntity.getBusinessObj()) {
            startTime = mapResultEntity.getBusinessObj().get("timeMillis");
        }
        resMap.put("startTime", startTime);
        responseJson.setData(resMap);
        return responseJson;
    }


    public String getEmployeeType(Long userId) {
        try {
            JSONObject result = restTemplate.getForObject(employeeTypeUrl, JSONObject.class, userId);
            if (result.getIntValue("code") != 200) {
                log.info("调用无线接口成功,但反回结果不是200，入参:userId:{},详情如下:{}", userId, result.getString("msg"));
                return null;
            }
            return result.getJSONObject("data").getString("type");
        } catch (Exception e) {
            log.error("调用无线接口失败，服务异常，异常堆栈如下", e);
            return null;
        }
    }
}

enum EmployeeTypeEnum {

    dql("电器员工"),
    hlwl("互联网员工"),
    gsl("公司员工");

    private String desc;

    private EmployeeTypeEnum(String desc) {
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }
}
