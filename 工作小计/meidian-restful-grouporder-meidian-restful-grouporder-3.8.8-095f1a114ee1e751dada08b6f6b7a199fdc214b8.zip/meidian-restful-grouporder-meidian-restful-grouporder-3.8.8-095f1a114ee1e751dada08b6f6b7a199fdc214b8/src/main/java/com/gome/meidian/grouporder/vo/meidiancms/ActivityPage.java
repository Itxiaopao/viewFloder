package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;

public class ActivityPage implements Serializable{

	private static final long serialVersionUID = 959531775533502800L;

	
}
