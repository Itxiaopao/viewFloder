package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 商品集信息
 * @author shichangjian
 *
 */
public class ProductVo implements Serializable{

	private static final long serialVersionUID = -4911943527614248622L;
	//扩展字段
	private  String expanded1;
	//productId
	private String productId;
	//skuid
	private String skuId;

	private String skuNo;
	//默认sku销售属性
	private String skuAttribute;
	//商品名称
	private String name;
	//商品图
	private String productImage;
	//自营联营标识  1自营  2联营
	private Integer productTag;
	//价格
	private Double price;
	//活动id
	private Long activityId;
	//活动实际开始时间
	private Date effectiveStartTime;
	//活动实际结束时间
	private Date effectiveEndTime;
	//一级分类id
	private String firstClassificationId;
	//一级分类名称
	private String firstClassificationName;
	//是否精选   0否  1是
//	private Integer isChoiceness;
	//是否热推  0否  1是
//	private Integer isHotPush;
	//促销语
//	private String promotions;
	//排序值
//	private Integer sortNum;
	//最大折扣价
	private Double maxDiscountPrice;
	//折扣规则
	private List<StepsConfig> stepsConfigs;
	//折扣规则描述
//	private String stepsConfigText;
	//返回的折扣金额
	private Double rebateAmount;
	//最大折扣
	private Float maxDiscount;
	//最小折扣
	private Float minDiscount;
	//最大折扣人数
	private Integer maxDiscountNeedPeopleNum;
	//最小折扣人数
	private Integer miniDiscountNeedPeopleNum;
	//限制购买件数
	private Integer limitBuyNum;
	//当前系统时间
	private Date currentTime;
	//是否显示
//	private Integer isShow;
	//已凑件数
	private Integer alreadyGroupOrderNumber;
//	private Long gomePrice;//国美价
	private Integer productStatus;		//商品状态  1上架  -1 下架
	private String shopId;
	private Integer irrigationNumbe=1;	//灌水数
	private Integer modeType;			//模式类型  0:参团,1:开团
	private String meidianPrice;		// 美店定价
	private String priceKey;			// 下单带着，区分美店价
	private Integer helpAllow; //是否允许助力 0:不允许,1:允许 （默认0）
	private String initialMaxMoney;//开团者最大返利（元）
	private String priceType;	// 价格类型
	
	public ProductVo() {
		super();
	}
	public ProductVo(String expanded1,String productId, String skuId,String skuNo, String skuAttribute, String name, String productImage, Integer productTag, Double price,
			Long activityId, Date effectiveStartTime, Date effectiveEndTime, String firstClassificationId,
			String firstClassificationName,
			Double maxDiscountPrice, List<StepsConfig> stepsConfigs, Double rebateAmount, Float maxDiscount,
			Float minDiscount, Integer maxDiscountNeedPeopleNum, Integer miniDiscountNeedPeopleNum, Integer limitBuyNum, Date currentTime,
			 Integer alreadyGroupOrderNumber,Integer productStatus,String shopId,Integer irrigationNumbe,
			 Integer modeType
			) {
		super();
		this.expanded1 = expanded1;
		this.productId = productId;
		this.skuId = skuId;
		this.skuNo=skuNo;
		this.skuAttribute = skuAttribute;
		this.name = name;
		this.productImage = productImage;
		this.productTag = productTag;
		this.price = price;
		this.activityId = activityId;
		this.effectiveStartTime = effectiveStartTime;
		this.effectiveEndTime = effectiveEndTime;
		this.firstClassificationId = firstClassificationId;
		this.firstClassificationName = firstClassificationName;
//		this.isChoiceness = isChoiceness;
//		this.isHotPush = isHotPush;
//		this.promotions = promotions;
//		this.sortNum = sortNum;
		this.maxDiscountPrice = maxDiscountPrice;
		this.stepsConfigs = stepsConfigs;
//		this.stepsConfigText = stepsConfigText;
		this.rebateAmount = rebateAmount;
		this.maxDiscount = maxDiscount;
		this.minDiscount = minDiscount;
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
		this.miniDiscountNeedPeopleNum = miniDiscountNeedPeopleNum;
		this.limitBuyNum = limitBuyNum;
		this.currentTime = currentTime;
//		this.isShow = isShow;
		this.alreadyGroupOrderNumber = alreadyGroupOrderNumber;
//		this.gomePrice = gomePrice;
		this.productStatus = productStatus;
		this.shopId = shopId;
		this.irrigationNumbe = irrigationNumbe;
		this.modeType = modeType;
	}

	public Integer getHelpAllow() {
		return helpAllow;
	}
	public void setHelpAllow(Integer helpAllow) {
		this.helpAllow = helpAllow;
	}
	public String getInitialMaxMoney() {
		return initialMaxMoney;
	}
	public void setInitialMaxMoney(String initialMaxMoney) {
		this.initialMaxMoney = initialMaxMoney;
	}
	public String getExpanded1() {
		return expanded1;
	}

	public void setExpanded1(String expanded1) {
		this.expanded1 = expanded1;
	}

	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Integer getProductTag() {
		return productTag;
	}
	public void setProductTag(Integer productTag) {
		this.productTag = productTag;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Date getEffectiveStartTime() {
		return effectiveStartTime;
	}
	public void setEffectiveStartTime(Date effectiveStartTime) {
		this.effectiveStartTime = effectiveStartTime;
	}
	public Date getEffectiveEndTime() {
		return effectiveEndTime;
	}
	public void setEffectiveEndTime(Date effectiveEndTime) {
		this.effectiveEndTime = effectiveEndTime;
	}
	public String getFirstClassificationId() {
		return firstClassificationId;
	}
	public void setFirstClassificationId(String firstClassificationId) {
		this.firstClassificationId = firstClassificationId;
	}
	public String getFirstClassificationName() {
		return firstClassificationName;
	}
	public void setFirstClassificationName(String firstClassificationName) {
		this.firstClassificationName = firstClassificationName;
	}

//	public Integer getIsChoiceness() {
//		return isChoiceness;
//	}
//	public void setIsChoiceness(Integer isChoiceness) {
//		this.isChoiceness = isChoiceness;
//	}
//	public Integer getIsHotPush() {
//		return isHotPush;
//	}
//	public void setIsHotPush(Integer isHotPush) {
//		this.isHotPush = isHotPush;
//	}
//	public String getPromotions() {
//		return promotions;
//	}
//	public void setPromotions(String promotions) {
//		this.promotions = promotions;
//	}

	public Double getMaxDiscountPrice() {
		return maxDiscountPrice;
	}
	public void setMaxDiscountPrice(Double maxDiscountPrice) {
		this.maxDiscountPrice = maxDiscountPrice;
	}
	public List<StepsConfig> getStepsConfigs() {
		return stepsConfigs;
	}
	public void setStepsConfig(List<StepsConfig> stepsConfigs) {
		this.stepsConfigs = stepsConfigs;
	}

//	public String getStepsConfigText() {
//		return stepsConfigText;
//	}
//	public void setStepsConfigText(String stepsConfigText) {
//		this.stepsConfigText = stepsConfigText;
//	}

	public Double getRebateAmount() {
		return rebateAmount;
	}
	public void setRebateAmount(Double rebateAmount) {
		this.rebateAmount = rebateAmount;
	}

//	public Integer getSortNum() {
//		return sortNum;
//	}
//	public void setSortNum(Integer sortNum) {
//		this.sortNum = sortNum;
//	}

	public Float getMaxDiscount() {
		return maxDiscount;
	}
	public void setMaxDiscount(Float maxDiscount) {
		this.maxDiscount = maxDiscount;
	}
	public Float getMinDiscount() {
		return minDiscount;
	}
	public void setMinDiscount(Float minDiscount) {
		this.minDiscount = minDiscount;
	}
	public Integer getMaxDiscountNeedPeopleNum() {
		return maxDiscountNeedPeopleNum;
	}
	public void setMaxDiscountNeedPeopleNum(Integer maxDiscountNeedPeopleNum) {
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
	}
	public Integer getMiniDiscountNeedPeopleNum() {
		return miniDiscountNeedPeopleNum;
	}
	public void setMiniDiscountNeedPeopleNum(Integer miniDiscountNeedPeopleNum) {
		this.miniDiscountNeedPeopleNum = miniDiscountNeedPeopleNum;
	}
	public Integer getLimitBuyNum() {
		return limitBuyNum;
	}
	public void setLimitBuyNum(Integer limitBuyNum) {
		this.limitBuyNum = limitBuyNum;
	}
	public String getSkuAttribute() {
		return skuAttribute;
	}
	public void setSkuAttribute(String skuAttribute) {
		this.skuAttribute = skuAttribute;
	}
	public Date getCurrentTime() {
		return currentTime;
	}
	public void setCurrentTime(Date currentTime) {
		this.currentTime = currentTime;
	}

//	public Integer getIsShow() {
//		return isShow;
//	}
//	public void setIsShow(Integer isShow) {
//		this.isShow = isShow;
//	}

	public Integer getAlreadyGroupOrderNumber() {
		return alreadyGroupOrderNumber;
	}
	public void setAlreadyGroupOrderNumber(Integer alreadyGroupOrderNumber) {
		this.alreadyGroupOrderNumber = alreadyGroupOrderNumber;
	}

//	public Long getGomePrice() {
//		return gomePrice;
//	}
//	public void setGomePrice(Long gomePrice) {
//		this.gomePrice = gomePrice;
//	}

	public Integer getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(Integer productStatus) {
		this.productStatus = productStatus;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public void setStepsConfigs(List<StepsConfig> stepsConfigs) {
		this.stepsConfigs = stepsConfigs;
	}
	public Integer getIrrigationNumbe() {
		return irrigationNumbe;
	}
	public void setIrrigationNumbe(Integer irrigationNumbe) {
		this.irrigationNumbe = irrigationNumbe;
	}
	public String getMeidianPrice() {
		return meidianPrice;
	}
	public void setMeidianPrice(String meidianPrice) {
		this.meidianPrice = meidianPrice;
	}
	public String getPriceKey() {
		return priceKey;
	}
	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}
	public Integer getModeType() {
		return modeType;
	}
	public void setModeType(Integer modeType) {
		this.modeType = modeType;
	}

	public String getSkuNo() {
		return skuNo;
	}

	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}
	
	
}
