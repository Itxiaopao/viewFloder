package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.List;

/**
 * 出事页面
 * @author libinbin-ds
 *
 */
public class MyAwardInit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6138274968270609064L;
	
	
	private Long myAwardTotalMoney;
	private AwardInfo myAward;
	private List<AwardInfo> myMasAwards;
	public Long getMyAwardTotalMoney() {
		return myAwardTotalMoney;
	}
	public void setMyAwardTotalMoney(Long myAwardTotalMoney) {
		this.myAwardTotalMoney = myAwardTotalMoney;
	}
	public AwardInfo getMyAward() {
		return myAward;
	}
	public void setMyAward(AwardInfo myAward) {
		this.myAward = myAward;
	}
	public List<AwardInfo> getMyMasAwards() {
		return myMasAwards;
	}
	public void setMyMasAwards(List<AwardInfo> myMasAwards) {
		this.myMasAwards = myMasAwards;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public MyAwardInit() {
		super();
	}
	public MyAwardInit(Long myAwardTotalMoney, AwardInfo myAward, List<AwardInfo> myMasAwards) {
		this.myAwardTotalMoney = myAwardTotalMoney;
		this.myAward = myAward;
		this.myMasAwards = myMasAwards;
	}
	
	

}
