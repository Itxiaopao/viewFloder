package com.gome.meidian.grouporder.controller.mshopUser;

import com.gome.architect.risk.dto.RequestV2;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.common.MeidianRiskService;
import com.gome.meidian.grouporder.manager.RegisterManager;
import com.gome.meidian.grouporder.manager.UserAndRegisterRiskSwitchManager;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.AccountLoginManager;
import com.gome.meidian.grouporder.utils.AesUtils;
import com.gome.meidian.grouporder.utils.RequestUtils;
import com.gome.meidian.grouporder.utils.UserConstants;
import com.gome.meidian.grouporder.vo.mshopUserVo.AccountLoginVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.CommonVariableVo;
import com.gome.meidian.grouporder.vo.register.UserInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UserInfo;
import com.gome.userCenter.model.UserLoginResult;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: AccountLoginController
 * @ProjectName meidian-restful-grouporder
 * @Description: 账号密码登录
 * @date 2018/11/29 11:26
 */
@Slf4j
@RestController
@RequestMapping("/mshopUser/login")
public class AccountLoginController {

    private Logger logger = LoggerFactory.getLogger(getClass());


    @Autowired
    private AccountLoginManager accountLoginManager;
    @Autowired
    private MeidianRiskService meidianRiskService;
    @Autowired
    private RegisterManager registerManager;

    @Resource(name = "userCenter")
    private Gcache userCenter;

    /**
     * 账号密码登录
     *
     * @param request
     * @return
     */
    @PostMapping(value = "/accountLogin")
    public ResponseJson accountLogin(@RequestBody AccountLoginVo accountLoginVo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        log.info("AccountLoginController.accountLogin,params:{},{}", accountLoginVo.toString());
        ResponseJson responseJson = new ResponseJson(1, "请求参数错误");
        UserLoginResult<UserInfo> userInfoUserLoginResult = null;
        RequestV2 requestV2 = new RequestV2();
//        UserLoginResult<UserInfo> userInfoUserLoginResult = null;
        if (StringUtils.isEmpty(accountLoginVo.getLogin()) || StringUtils.isEmpty(accountLoginVo.getPassword()))
            return responseJson;

        accountLoginVo.setPassword(AesUtils.aesDecrypt(accountLoginVo.getPassword()));

        if (StringUtils.isNotEmpty(accountLoginVo.getToken())) {
            responseJson = accountLoginManager.sliderVal(accountLoginVo.getToken());
        } else {

            //注册风控
            String riskStatus=userCenter.get(UserAndRegisterRiskSwitchManager.RISK_SWITCH_WAP_MEIDIAN_LOGIN);
            if(null!=riskStatus&& WechatLoginManager.RESULT_SUCCESS_NO.equals(riskStatus)){
                //当标识不是null 或者 false的时候,风控降级
            }else{
                //null or true 使用注册风控
                requestV2.setBizNo(CommonVariableVo.account_login_bizNo);
                requestV2.setUserId(accountLoginVo.getLogin());//暂时传用户名
                accountLoginManager.riskLogin(requestV2, request);//登录风控
            }

        }
        try {
            String ip = RequestUtils.getIP(request);
            String port = request.getRemotePort() + "";
            RequestParams requestParams = new RequestParams();
            requestParams.setInvokeChannel(CommonVariableVo.invokeChannel);
            requestParams.setClientIp(ip);
            requestParams.setRemotePort(port);
            Map<String, Object> map = new HashMap<>();
            map.put("companyName", CommonVariableVo.companyName);
            if(StringUtils.isNotEmpty(accountLoginVo.getDistinctId())){
                map.put("distinctId", accountLoginVo.getDistinctId());
            }
            //            map.put("isAutoLogin", true);
            responseJson = accountLoginManager.doLogin(accountLoginVo, requestParams, map, requestV2, request, response);
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("AccountLoginController-accountLoginManager.doLogin error {}",e.getMessage());
            responseJson.setCode(3);
            responseJson.setMsg("账号密码登录服务异常");
        }
        return responseJson;
    }

    /**
     * 激活手机号
     *
     * @param accountLoginVo
     * @return
     */
    @RequestMapping(value = "/mobileActivated")
    public ResponseJson mobileActivated(@RequestBody AccountLoginVo accountLoginVo) {
        log.info("AccountLoginController.mobileActivated, params:{}", accountLoginVo.toString());
        ResponseJson responseJson = new ResponseJson(1, "请求参数错误");
        if (StringUtils.isEmpty(accountLoginVo.getPhone()) || StringUtils.isEmpty(accountLoginVo.getCode()) || StringUtils.isEmpty(accountLoginVo.getUserId()))
            return responseJson;
        try {
            accountLoginVo.setNewMobile(accountLoginVo.getPhone());
            boolean b = accountLoginManager.checkCode(accountLoginVo);
            if (!b) {
                responseJson.setCode(2);
                responseJson.setMsg("校验短信验证码失败");
                return responseJson;
            }
            responseJson = accountLoginManager.mobileActivated(accountLoginVo);
        } catch (Exception e) {
            logger.info("AccountLoginController-accountLoginManager.mobileActivated error {}",e);
            responseJson.setCode(3);
            responseJson.setMsg("校验短信验证码服务异常");
            log.error(e.getMessage());
        }
        return responseJson;
    }

    /**
     * 登录风控
     *
     * @param accountLoginVo
     * @return
     */
//    @PostMapping(value = "/riskLogin")
//    public ResponseJson riskLogin(@RequestBody AccountLoginVo accountLoginVo, HttpServletRequest request) {
//        ResponseJson responseJson = new ResponseJson();
//        try {
//            if (StringUtils.isNotEmpty(accountLoginVo.getUserId()) && StringUtils.isNotEmpty(accountLoginVo.getPassword())) {
//                RequestV2 requestV2 = new RequestV2();
//                requestV2.setBizNo(CommonVariableVo.bizNo);
//                requestV2.setUserId(accountLoginVo.getUserId());
//                accountLoginManager.riskLogin(requestV2, request);
//            }
//        } catch (Exception e) {
//            responseJson.setCode(1);
//            responseJson.setMsg("调用登录风控异常");
//        }
//        return responseJson;
//    }


    /**
     * 滑块风控
     *
     * @param accountLoginVo
     * @return
     */
//    @PostMapping(value = "/sliderVal")
    public ResponseJson sliderVal(@RequestBody AccountLoginVo accountLoginVo) throws Exception {
        ResponseJson responseJson = new ResponseJson();
        if (StringUtils.isNotEmpty(accountLoginVo.getToken())) {
            responseJson = accountLoginManager.sliderVal(accountLoginVo.getToken());
        }
        return responseJson;
    }

    /**
     * 发送短信验证码
     *
     * @param accountLoginVo
     * @return
     */
    @PostMapping(value = "/sendSms")
    public ResponseJson sendSms(@RequestBody AccountLoginVo accountLoginVo, HttpServletRequest request) throws MeidianException {
        ResponseJson responseJson = new ResponseJson();
        if (StringUtils.isNotEmpty(accountLoginVo.getPhone())) {
            UserInfoVo userInfo = new UserInfoVo();
            userInfo.setMobile(accountLoginVo.getPhone());
            registerManager.checkMobile(userInfo);//校验手机号是否存在
            boolean b = accountLoginManager.sendSms(accountLoginVo.getPhone(), request);
            if (b) {
                responseJson.setCode(0);
                responseJson.setMsg("发送手机验证码成功");
            } else {
                responseJson.setCode(1);
                responseJson.setMsg("发送手机验证码失败");
            }
        }
        return responseJson;
    }

    /**
     * 校验短信验证码
     *
     * @param accountLoginVo
     * @return
     */
    @PostMapping(value = "/checkCode")
    public ResponseJson checkCode(@RequestBody AccountLoginVo accountLoginVo) {
        ResponseJson responseJson = new ResponseJson();
        try {
            if (StringUtils.isNotEmpty(accountLoginVo.getPhone()) && StringUtils.isNotEmpty(accountLoginVo.getCode())) {
                boolean b = accountLoginManager.checkCode(accountLoginVo);
                if (b) {
                    responseJson.setCode(0);
                } else {
                    responseJson.setCode(1);
                }
            }
        } catch (Exception e) {
            logger.info("AccountLoginController-accountLoginManager.checkCode error {}",e);
            responseJson.setCode(1);
        }
        return responseJson;
    }
}
