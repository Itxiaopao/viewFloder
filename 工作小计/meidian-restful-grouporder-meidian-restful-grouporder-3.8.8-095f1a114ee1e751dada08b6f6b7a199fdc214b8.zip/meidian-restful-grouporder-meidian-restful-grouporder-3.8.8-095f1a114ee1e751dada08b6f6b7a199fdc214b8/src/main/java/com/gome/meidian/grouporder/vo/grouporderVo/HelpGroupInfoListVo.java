package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

public class HelpGroupInfoListVo implements Serializable{

	private static final long serialVersionUID = 656466689387891575L;
	private Integer helpMaxRebateNum;// 助力团最大返利人数
	private List<HelpGroupInfoVo> helpList; //榜单
	public Integer getHelpMaxRebateNum() {
		return helpMaxRebateNum;
	}
	public void setHelpMaxRebateNum(Integer helpMaxRebateNum) {
		this.helpMaxRebateNum = helpMaxRebateNum;
	}
	public List<HelpGroupInfoVo> getHelpList() {
		return helpList;
	}
	public void setHelpList(List<HelpGroupInfoVo> helpList) {
		this.helpList = helpList;
	}
	
}
