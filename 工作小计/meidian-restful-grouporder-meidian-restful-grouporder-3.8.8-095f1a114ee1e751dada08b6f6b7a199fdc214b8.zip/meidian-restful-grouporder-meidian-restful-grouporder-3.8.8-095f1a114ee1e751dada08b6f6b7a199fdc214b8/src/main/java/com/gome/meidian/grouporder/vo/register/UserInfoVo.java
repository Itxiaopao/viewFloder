package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class UserInfoVo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "{base.user.mobile.notBlank}")
	private String mobile;//用户手机号
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
}
