package com.gome.meidian.grouporder.manager;

import com.gome.framework.base.ResultDTO;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.vo.advanceSale.GomePromPresellVo;
import com.gome.meidian.grouporder.vo.advanceSale.PresellQueryParamVo;
import com.gome.pangu.promotiondata.client.PromotionPresellService;
import com.gome.pangu.promotiondata.client.dto.presellprom.*;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


/**
 * 预售服务层
 */
@Service
public class AdvanceSaleManager {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private PromotionPresellService promotionPresellService;


	/**
	 * 根据预售id 获取预售基本信息
	 * @param promId
	 * @return
	 * @throws MeidianException
	 */
	public GomePromPresellVo queryPresellInfoById(String promId) throws MeidianException {

		ResultDTO<GomePromPresellRedisDTO>  resultDTO= promotionPresellService.queryPresellInfo(promId);
		GomePromPresellRedisDTO  gomePromPresellRedisDTO=resultDTO.getData();
		if(null==gomePromPresellRedisDTO){
			logger.info("queryPresellInfoById result is null {}",promId);
			return null;
		}
		GomePromPresellVo  vo=new GomePromPresellVo();
		BeanUtils.copyProperties(gomePromPresellRedisDTO,vo);
		String deductibleDeposit = vo.getDeductibleDeposit();
		if(StringUtils.isNotBlank(deductibleDeposit)) {
    		if(deductibleDeposit.endsWith(".0")) {
    			deductibleDeposit = deductibleDeposit.replace(".0", "");
    		}else if(deductibleDeposit.endsWith(".00")) {
    			deductibleDeposit = deductibleDeposit.replace(".00", "");
    		}else if(deductibleDeposit.contains(".") && deductibleDeposit.endsWith("0")) {
    			deductibleDeposit = deductibleDeposit.substring(0, deductibleDeposit.lastIndexOf("0"));
    		}
    		vo.setDeductibleDeposit(deductibleDeposit);
		}
		return vo;

	}


	/**
	 * 根据skuno+门店+区域 获取预售基本信息
	 * @param skuNo
	 * @param isShop
	 * @param countyCode
	 * @param townCode
	 * @return
	 * @throws MeidianException
	 */
	public GomePromPresellVo queryOnePresellInfoByParam(String skuNo,String storeCode,Boolean  isShop,String countyCode,String townCode) {
		PresellQueryParam presellQueryParam=new PresellQueryParam();
		presellQueryParam.setSkuNo(skuNo);
		if(null!=isShop) {
			presellQueryParam.setShop(isShop);
		}
		presellQueryParam.setStoreCode(storeCode);
		presellQueryParam.setCountyCode(countyCode);
		presellQueryParam.setTownCode(townCode);
		ResultDTO<GomePromPresellRedisDTO> resultDTO=promotionPresellService.queryPresellInfoByParam(presellQueryParam);
		GomePromPresellRedisDTO gomePromPresellRedisDTO=resultDTO.getData();
		if(null==gomePromPresellRedisDTO){
			logger.info("queryPresellInfoByParam result is null skuNo:{}  isShop:{} countyCode:{} townCode:{} ",skuNo,isShop,countyCode,townCode);
			return null;
		}
		//美店支持扫码专享
		String showTerminal = gomePromPresellRedisDTO.getShowTerminal();
		if(StringUtils.isEmpty(showTerminal) || !showTerminal.contains("2")){
			return null;
		}
		GomePromPresellVo  vo=new GomePromPresellVo();
		BeanUtils.copyProperties(gomePromPresellRedisDTO,vo);
		String deductibleDeposit = vo.getDeductibleDeposit();
		if(StringUtils.isNotBlank(deductibleDeposit)) {
    		if(deductibleDeposit.endsWith(".0")) {
    			deductibleDeposit = deductibleDeposit.replace(".0", "");
    		}else if(deductibleDeposit.endsWith(".00")) {
    			deductibleDeposit = deductibleDeposit.replace(".00", "");
    		}else if(deductibleDeposit.contains(".") && deductibleDeposit.endsWith("0")) {
    			deductibleDeposit = deductibleDeposit.substring(0, deductibleDeposit.lastIndexOf("0"));
    		}
    		vo.setDeductibleDeposit(deductibleDeposit);
		}
		return vo;

	}


	/**
	 * V1.4批量根据skuno+门店+区域 获取预售id
	 * @param presellQueryParamVo
	 * @return
	 * @throws MeidianException
	 */
	public List<GomePromPresellVo> queryAllPresellInfoByParam(PresellQueryParamVo presellQueryParamVo) throws MeidianException {
		String skuNo=presellQueryParamVo.getSkuNo();
		Boolean isShop=presellQueryParamVo.isShop();
		List<String> storeCodeList =presellQueryParamVo.getStoreCodeList();
		List<String> countyCodeList=presellQueryParamVo.getCountyCodeList();
		List<String> townCodeList=presellQueryParamVo.getTownCodeList();
		PresellQueryParam presellQueryParam=new PresellQueryParam();
		presellQueryParam.setSkuNo(skuNo);
		presellQueryParam.setShop(isShop);
		presellQueryParam.setStoreCodeList(storeCodeList);
		presellQueryParam.setCountyCodeList(countyCodeList);
		presellQueryParam.setTownCodeList(townCodeList);

		ResultDTO<List<PromPresellCodeDTO>> resultDTO=promotionPresellService.batchQueryPresellIdsByParam(presellQueryParam);
		List<PromPresellCodeDTO>  list=resultDTO.getData();
		if(null==list||list.size()<1){
			logger.info("batchQueryPresellIdsByParam result is null skuNo:{}  shop:{}  storeCodeList:{}  countyCodeList:{}  townCodeList:{}",skuNo,isShop,storeCodeList,countyCodeList,townCodeList);
			return null;
		}
		List<GomePromPresellVo>  voList=new ArrayList<GomePromPresellVo>();
		for (PromPresellCodeDTO promPresellCodeDTO:list) {
			GomePromPresellVo  vo=new GomePromPresellVo();
			BeanUtils.copyProperties(promPresellCodeDTO,vo);
			voList.add(vo);
		}
		return voList;

	}


	/**
	 * 查询下级区域地址
	 * @param skuNo
	 * @param areaCode
	 * @param areaLevel
	 * @param isShop
	 * @param skuId
	 * @param productId
	 * @return
	 * @throws MeidianException
	 */
	public Object queryPresellAreaInfo(String skuNo,
										String areaCode,
										int areaLevel,
										Boolean isShop,String skuId,String productId) throws MeidianException {

		PresellAreaInfoQueryParam presellAreaInfoQueryParam=new PresellAreaInfoQueryParam();
		presellAreaInfoQueryParam.setSkuNo(skuNo);
		presellAreaInfoQueryParam.setShop(isShop);
		presellAreaInfoQueryParam.setAreaCode(areaCode);
		presellAreaInfoQueryParam.setAreaLevel(areaLevel);
		presellAreaInfoQueryParam.setSkuId(skuId);
		presellAreaInfoQueryParam.setProductId(productId);
		ResultDTO<List<PromPresellAreaInfoDTO>>  resultDTO= promotionPresellService.queryPresellAreaInfo(presellAreaInfoQueryParam);
		List<PromPresellAreaInfoDTO>  list=resultDTO.getData();
		if(null==list){
			logger.info("queryPresellAreaInfo result is null");
			return null;
		}
		return list;

	}

}
