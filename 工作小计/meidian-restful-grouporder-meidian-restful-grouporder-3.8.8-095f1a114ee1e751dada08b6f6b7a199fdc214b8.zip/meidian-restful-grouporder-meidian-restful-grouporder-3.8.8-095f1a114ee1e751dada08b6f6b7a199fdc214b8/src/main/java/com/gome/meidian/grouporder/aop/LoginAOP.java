package com.gome.meidian.grouporder.aop;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

@Aspect
@Component
@Order(1) 
public class LoginAOP {
	
	@Autowired
	private AuthencationUtils authencationUtils;
	
	// 切入点
	@Pointcut("execution(* com.gome.meidian.grouporder.controller..*.*(..)) && @annotation(com.gome.meidian.grouporder.aop.MDLoginAnnotation)")
	public void logPoin(){}  
	
	// 前置增强
	@Before("logPoin()")
	public void login(JoinPoint joinPoint) {
		
		String scn = MeidianEnvironment.getSCN();
		if(null != scn && !scn.equals("")){
			String scnDecoder = null;
			try {
				scnDecoder = URLDecoder.decode(scn, "UTF-8");
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String userId = null;
			try {
				userId = authencationUtils.authenticationLogin(scnDecoder);
			} catch (Exception e) {
				e.printStackTrace();
			}
			MeidianEnvironment.putUserId(userId);
		}
	}
}
