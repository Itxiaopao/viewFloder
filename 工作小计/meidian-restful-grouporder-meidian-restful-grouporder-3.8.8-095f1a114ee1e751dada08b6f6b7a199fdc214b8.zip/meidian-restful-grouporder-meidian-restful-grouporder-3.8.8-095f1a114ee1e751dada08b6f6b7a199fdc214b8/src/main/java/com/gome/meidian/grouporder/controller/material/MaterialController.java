package com.gome.meidian.grouporder.controller.material;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.homePageManager.HomePageManager;
import com.gome.meidian.grouporder.manager.materialManager.MaterialManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.materialVo.ActivityMaterialVo;
import com.gome.meidian.grouporder.vo.materialVo.ProductMaterialVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.sso.model.UserInfoCache;

@RestController
@Validated
@RequestMapping("/material")
public class MaterialController {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private HomePageManager homePageManager;
	@Autowired
	private PropertiesConfig propertiesConfig;
	@Autowired
	private MaterialManager materialManager;
	@Autowired
	private AuthencationUtils authencationUtils;
	
	/**
	 * 素材tab
	 * @param StoreCode
	 * @param Channel
	 * @param ppi
	 * @param AreaCode
	 * @param scn
	 * @param storeCode
	 * @param channel
	 * @param pageCode
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/material", method = RequestMethod.GET)
	public ResponseJson material(
			@CookieValue(value = "storeCode", required = false) String StoreCode,
			@CookieValue(value = "Channel", required = false) String Channel,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
			@CookieValue(value = "SCN", required = false) String scn,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@RequestParam(value = "channel", required = false) String channel,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		
		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, propertiesConfig.getDefaultStoreCode());
		int chan = ChannelUtils.getCmsChannel(Channel, channel);
		
		String arCode = null;
		if (null == AreaCode || AreaCode.equalsIgnoreCase("")){
			if(null == areaCode || areaCode.equalsIgnoreCase("")){
				arCode = propertiesConfig.getDefaultAreaCode();
			}else {
				arCode = areaCode;
			}
		}else {
			arCode = AreaCode;
		}
		response.setData(homePageManager.material(null, stoCode, pageCode, arCode, chan, ua, ppi));
		return response;
	}
	
	/**
	 * 万人团素材分页
	 * @param StoreCode
	 * @param Channel
	 * @param ppi
	 * @param AreaCode
	 * @param scn
	 * @param storeCode
	 * @param channel
	 * @param pageCode
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/thousandGroupMaterials", method = RequestMethod.GET)
	public ResponseJson thousandGroupMaterials(
			@CookieValue(value = "storeCode", required = false) String StoreCode,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
			@CookieValue(value = "SCN", required = false) String scn,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "moduleCode", required = true) String moduleCode,
			@NotNull(message = "{param.error}") @RequestParam(value = "pageNo", required = true) int pageNo,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		
		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, propertiesConfig.getDefaultStoreCode());
		
		String arCode = null;
		if (null == AreaCode || AreaCode.equalsIgnoreCase("")){
			if(null == areaCode || areaCode.equalsIgnoreCase("")){
				arCode = propertiesConfig.getDefaultAreaCode();
			}else {
				arCode = areaCode;
			}
		}else {
			arCode = AreaCode;
		}
		
		restMap = materialManager.thousandGroupMaterials(stoCode, moduleCode, pageCode, pageNo, pageSize, arCode, ppi, ua);
		
		response.setData(restMap);
		return response;
	}
	
	/**
	 * 助力团素材分页
	 * @param StoreCode
	 * @param Channel
	 * @param ppi
	 * @param AreaCode
	 * @param scn
	 * @param storeCode
	 * @param channel
	 * @param pageCode
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/helpGroupMaterials", method = RequestMethod.GET)
	public ResponseJson helpGroupMaterials(
			@CookieValue(value = "storeCode", required = false) String StoreCode,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
			@CookieValue(value = "SCN", required = false) String scn,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "moduleCode", required = true) String moduleCode,
			@NotNull(message = "{param.error}") @RequestParam(value = "pageNo", required = true) int pageNo,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		
		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, propertiesConfig.getDefaultStoreCode());
		
		String arCode = null;
		if (null == AreaCode || AreaCode.equalsIgnoreCase("")){
			if(null == areaCode || areaCode.equalsIgnoreCase("")){
				arCode = propertiesConfig.getDefaultAreaCode();
			}else {
				arCode = areaCode;
			}
		}else {
			arCode = AreaCode;
		}
		
		restMap = materialManager.helpGroupMaterials(stoCode, moduleCode, pageCode, pageNo, pageSize, arCode, ppi, ua);
		
		response.setData(restMap);
		return response;
	}
	
	/**
	 * 活动素材分页
	 * @param StoreCode
	 * @param Channel
	 * @param ppi
	 * @param AreaCode
	 * @param scn
	 * @param storeCode
	 * @param channel
	 * @param pageCode
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/activityMaterials", method = RequestMethod.GET)
	public ResponseJson activityMaterials(
			@CookieValue(value = "storeCode", required = false) String StoreCode,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "moduleCode", required = true) String moduleCode,
			@NotNull(message = "{param.error}") @RequestParam(value = "pageNo", required = true) int pageNo,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		
		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, propertiesConfig.getDefaultStoreCode());
		
		restMap = materialManager.activityMaterials(stoCode, moduleCode, pageCode, pageNo, pageSize);
		
		response.setData(restMap);
		return response;
	}
	
	/**
	 * 添加商品素材分享次数
	 * @param productId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/proMaterialShareNum", method = RequestMethod.GET)
	public ResponseJson proMaterialShareNum(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId") String productId
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		
		restMap.put("status", materialManager.proMaterialShareNum(productId));
		
		response.setData(restMap);
		return response;
	}
	
	/**
	 * 添加活动素材分享次数
	 * @param pageCode
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/activityMaterialShareNum", method = RequestMethod.GET)
	public ResponseJson activityMaterialShareNum(
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		
		restMap.put("status", materialManager.activityMaterialShareNum(pageCode));
		
		response.setData(restMap);
		return response;
	}
	
	/**
	 * 删除商品素材分享（内部使用，不对外）
	 * @param productId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/dProMaterialShare", method = RequestMethod.GET)
	public ResponseJson dProMaterialShare(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId") String productId,
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		
		//是否登录
		String userId = authencationUtils.authenticationLogin(scn);
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		
		// 不是我的账号不能使用此接口
		if(!userId.equals(propertiesConfig.getAccount())){
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		
		restMap.put("status", materialManager.deleteProMaterialShare(productId));
		
		response.setData(restMap);
		return response;
	}
	
	/**
	 * 删除活动素材分享（内部使用，不对外）
	 * @param pageCode
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/v1/dAcMaterialShare", method = RequestMethod.GET)
	public ResponseJson dAcMaterialShare(
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		Map<String, Object> restMap = new HashMap<String, Object>();
		
		//是否登录
		String userId = authencationUtils.authenticationLogin(scn);
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		
		// 不是我的账号不能使用此接口
		if(!userId.equals(propertiesConfig.getAccount())){
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		
		restMap.put("status", materialManager.deleteAcMaterialShare(pageCode));
		
		response.setData(restMap);
		return response;
	}
	
}
