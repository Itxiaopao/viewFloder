package com.gome.meidian.grouporder.controller.store;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.config.PageCodeConfig;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

import redis.Gcache;

@RestController
@Validated
@RequestMapping("/v1/store")
public class StoreController {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private HomeProductsManager homeProductsManager;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private StoreManager storeManager;

	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	@Value("${gome.defaultStoreCode}")
	private String defaultStoreCode; // 默认门店，西坝河
	
	/**
	 * 根据门店编码获取门店信息
	 * @param StoreCode
	 * @param Channel
	 * @param storeCode
	 * @param channel
	 * @param storeType
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getStoreInfo", method = RequestMethod.GET)
	public ResponseJson getStoreInfo(
			@CookieValue(value = "StoreCode", required = false) String StoreCode,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@NotNull(message = "{param.error}") @RequestParam(value = "storeType") Integer storeType,
			String lng,
			String lat
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		
		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
		
		response.setData(storeManager.getStoreInfo(stoCode, storeType, lng, lat));
		return response;
	}
	
//	/**
//	 * 根据门店编码获取区域码
//	 * @param StoreCode
//	 * @param Channel
//	 * @param storeCode
//	 * @param channel
//	 * @param storeType
//	 * @return
//	 * @throws MeidianException
//	 */
//	@RequestMapping(value = "/getFourAreaCode", method = RequestMethod.GET)
//	public ResponseJson getFourAreaCode(
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@RequestParam(value = "storeCode", required = false) String storeCode,
//			@RequestParam(value = "channel", required = false) String channel,
//			@NotNull(message = "{param.error}") @RequestParam(value = "storeType") Integer storeType
//			)throws MeidianException {
//		
//		ResponseJson response = new ResponseJson();
//		
//		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
//		int chan = ChannelUtils.getCmsChannel(Channel, channel);
//		
//		response.setData(storeManager.getFourAreaCode(storeCode, storeType));
//		return response;
//	}
	
	/**
	 * 根据userId获取用户信息
	 * @param userId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getUserInfo", method = RequestMethod.GET)
	public ResponseJson getUserInfo(
			@NotNull(message = "{param.error}") @RequestParam(value = "userId") Long userId
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		
		response.setData(storeManager.getUserInfo(userId));
		return response;
	}
	
	/**
	 * 手动更新门店
	 * @param userId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/updateStore", method = RequestMethod.GET)
	public ResponseJson updateStore(
			)throws MeidianException {
		
		ResponseJson response = new ResponseJson();
		
		storeManager.updateStore();
		
		response.setData("ok");
		return response;
	}
}
