package com.gome.meidian.grouporder.utils;

import java.util.HashMap;
import java.util.Map;

public class AppShareCodeConstants {
	// sharePage
	public static Map<String, AppShareCodeInfo> pageUrlMap;
	static {
		pageUrlMap = new HashMap<String, AppShareCodeInfo>();
        //生产配置
		pageUrlMap.put("sharePage1", new AppShareCodeInfo("https://d.m.gome.com.cn",
				"pages/guides/index/index","mid#stid#areaCode","areaCode"));//首页
		
		pageUrlMap.put("sharePage2", new AppShareCodeInfo("https://mshop.m.gome.com.cn/views/appActivity/appActivity.html",
				"pages/guides/web/index","mid#stid#areaCode#pageCode","areaCode#pageCode"));//活动页
		
		pageUrlMap.put("sharePage3", new AppShareCodeInfo("https://d.m.gome.com.cn/singleCoupons",
				"pages/personals/getCoupons/index","mid#stid#areaCode#productId#skuId#skuNo#couponId#couponType",
				"areaCode#couponId#couponType#plan_id#productId"));//领券中间页
		
		pageUrlMap.put("sharePage4", new AppShareCodeInfo("https://gorder.m.gome.com.cn/productdetail",
				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuId#skuNo#couponPrice"
				,"areaCode#productId#skuId#couponNum"));//领券商品详情
		
		pageUrlMap.put("sharePage5", new AppShareCodeInfo("https://gorder.m.gome.com.cn/productdetail",
				"pages/personals/product_details/index","mid#stid#areaCode#skuNo#buyRebate#productId#skuId"
				,"areaCode#productId#skuId#buyRebate"));//超级返商品详情
		
		pageUrlMap.put("sharePage6", new AppShareCodeInfo("https://gorder.m.gome.com.cn/detail",
				"pages/personals/product_details/index","mid#stid#areaCode#activityId#skuNo#productId#skuId"
				,"areaCode#groupId#productId#skuId#activityId"));//未开团-组团商品详情
		
		pageUrlMap.put("sharePage7", new AppShareCodeInfo("https://gorder.m.gome.com.cn/detail",
				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuNo#skuId#activityId#tuanId"
				,"areaCode#groupId#productId#skuId#activityId"));//开团-组团商品详情
		
		pageUrlMap.put("sharePage8", new AppShareCodeInfo("https://mshop.m.gome.com.cn/views/coudanDetail/coudanDetail.html",
				"pages/personals/single_groups/index","mid#stid#areaCode#tuanId#createType"
				,"areaCode#groupId#skuId"));//组团详情
		
		//测试配置
//		pageUrlMap.put("sharePage1", new AppShareCodeInfo("http://d.m.atguat.com.cn",
//				"pages/guides/index/index","mid#stid#areaCode","areaCode"));//首页
//		
//		pageUrlMap.put("sharePage2", new AppShareCodeInfo("http://mshop.m.atguat.com.cn/views/appActivity/appActivity.html",
//				"pages/guides/web/index","mid#stid#areaCode#pageCode","areaCode#pageCode"));//活动页
//		
//		pageUrlMap.put("sharePage3", new AppShareCodeInfo("http://d.m.atguat.com.cn/singleCoupons",
//				"pages/personals/getCoupons/index","mid#stid#areaCode#productId#skuId#skuNo#couponId#couponType",
//				"areaCode#couponId#couponType#plan_id#productId"));//领券中间页
//		
//		pageUrlMap.put("sharePage4", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/productdetail",
//				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuId#skuNo#couponPrice"
//				,"areaCode#productId#skuId#couponNum"));//领券商品详情
//		
//		pageUrlMap.put("sharePage5", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/productdetail",
//				"pages/personals/product_details/index","mid#stid#areaCode#skuNo#buyRebate#productId#skuId"
//				,"areaCode#productId#skuId#buyRebate"));//超级返商品详情
//		
//		pageUrlMap.put("sharePage6", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/detail",
//				"pages/personals/product_details/index","mid#stid#areaCode#activityId#skuNo#productId#skuId"
//				,"areaCode#groupId#productId#skuId#activityId"));//未开团-组团商品详情
//		
//		pageUrlMap.put("sharePage7", new AppShareCodeInfo("http://gorder.m.atguat.com.cn/detail",
//				"pages/personals/product_details/index","mid#stid#areaCode#productId#skuNo#skuId#activityId#tuanId"
//				,"areaCode#groupId#productId#skuId#activityId"));//开团-组团商品详情
//		
//		pageUrlMap.put("sharePage8", new AppShareCodeInfo("http://mshop.m.atguat.com.cn/views/coudanDetail/coudanDetail.html",
//				"pages/personals/single_groups/index","mid#stid#areaCode#tuanId#createType"
//				,"areaCode#groupId#skuId"));//组团详情
		
		
		
		
		
	}

}
