package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;

/**
 * 提奖用户
 * @author libinbin-ds
 *
 */
public class AwardInfo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4992004787092442031L;
	private Long userId;//用户id
	private String weiXinNickName;//微信昵称
    private String weixinNum;//微信号
    private String phone;//手机号
    private String imagePath;//头像 
    private Integer userIdentity;//店主身份 1.店主2.店总3.片总
    
    private String registrationTime;//注册时间
    private Integer mshopOwnerCount;//下线店主个数
    private Integer consumerCount;//客户数量
	private Long saleAmount;	// 销售额
	private Long awardAmout;	// 当月提奖额
	
	private String uniqueId;	// uniqueId 游客id
    
    public String getUniqueId() {
    	return uniqueId;
    }
	
	
	public Integer getUserIdentity() {
		return userIdentity;
	}
	public void setUserIdentity(Integer userIdentity) {
		this.userIdentity = userIdentity;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getWeiXinNickName() {
		return weiXinNickName;
	}
	public void setWeiXinNickName(String weiXinNickName) {
		this.weiXinNickName = weiXinNickName;
	}
	public String getWeixinNum() {
		return weixinNum;
	}
	public void setWeixinNum(String weixinNum) {
		this.weixinNum = weixinNum;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRegistrationTime() {
		return registrationTime;
	}
	public void setRegistrationTime(String registrationTime) {
		this.registrationTime = registrationTime;
	}
	public Integer getMshopOwnerCount() {
		return mshopOwnerCount;
	}
	public void setMshopOwnerCount(Integer mshopOwnerCount) {
		this.mshopOwnerCount = mshopOwnerCount;
	}
	public Integer getConsumerCount() {
		return consumerCount;
	}
	public void setConsumerCount(Integer consumerCount) {
		this.consumerCount = consumerCount;
	}
	public Long getSaleAmount() {
		return saleAmount;
	}
	public void setSaleAmount(Long saleAmount) {
		this.saleAmount = saleAmount;
	}
	public Long getAwardAmout() {
		return awardAmout;
	}
	public void setAwardAmout(Long awardAmout) {
		this.awardAmout = awardAmout;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public AwardInfo() {
		super();
	}
	public AwardInfo(Long userId, String weiXinNickName, String weixinNum, String phone, String registrationTime,
			Integer mshopOwnerCount, Integer consumerCount, Long saleAmount, Long awardAmout) {
		this.userId = userId;
		this.weiXinNickName = weiXinNickName;
		this.weixinNum = weixinNum;
		this.phone = phone;
		this.registrationTime = registrationTime;
		this.mshopOwnerCount = mshopOwnerCount;
		this.consumerCount = consumerCount;
		this.saleAmount = saleAmount;
		this.awardAmout = awardAmout;
	}
	
	
	
	
    
}
