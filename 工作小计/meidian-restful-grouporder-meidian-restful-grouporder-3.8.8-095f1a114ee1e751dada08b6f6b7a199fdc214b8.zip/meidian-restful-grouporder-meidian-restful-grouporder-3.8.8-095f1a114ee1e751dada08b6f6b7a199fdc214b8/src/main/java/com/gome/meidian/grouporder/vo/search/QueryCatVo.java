package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;
/**
 * 查询类目信息
 * @author lishouxu-ds
 *
 */
public class QueryCatVo implements Serializable{
	private static final long serialVersionUID = -4303546319787017679L;
	private String catId;//类目id
	private String catLevel;//类目级别
	public String getCatId() {
		return catId;
	}
	public void setCatId(String catId) {
		this.catId = catId;
	}
	public String getCatLevel() {
		return catLevel;
	}
	public void setCatLevel(String catLevel) {
		this.catLevel = catLevel;
	}
    
}
