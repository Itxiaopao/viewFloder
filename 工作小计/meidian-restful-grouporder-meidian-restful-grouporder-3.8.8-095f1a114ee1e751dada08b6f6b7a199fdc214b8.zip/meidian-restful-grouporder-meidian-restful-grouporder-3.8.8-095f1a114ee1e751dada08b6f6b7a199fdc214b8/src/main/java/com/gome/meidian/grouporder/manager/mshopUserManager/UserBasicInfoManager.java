package com.gome.meidian.grouporder.manager.mshopUserManager;


import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import com.gome.meidian.grouporder.utils.RedisKeyUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.vo.UserInfoDto;
import com.gome.meidian.user.entity.UserInfo;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.base.IUserBaseProfileFacade;
import com.gome.userBase.model.base.UserBasicInfo;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;

import redis.Gcache;

@Component
public class UserBasicInfoManager{
	private static Logger logger = LoggerFactory.getLogger(UserBasicInfoManager.class);

	@Autowired
	private IUserBaseProfileFacade iUserBaseProfileFacade;
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	@Resource(name = "userCenter")
	private Gcache userCenterCache;
	private String userCacheKey = "user.center.userInfo.manager";
	/**
	 * 获取用户信息--用户中心
	 * @param userId
	 * @param invokeFrom
	 * @return
	 */
	public UserInfoDto getUserBasicInfo(String userId) {
		String invokeFrom = GroupOrderConstants.GOME_SHOP_INVOKE_FROM;
		UserInfoDto uDto = null;
		try {
			uDto = new UserInfoDto();
			//基础信息
			UserResult<UserBasicInfo> userBasicInfo = iUserBaseProfileFacade.getUserBasicInfo(userId, invokeFrom);
			if(null != userBasicInfo && userBasicInfo.isSuccess()) {
				UserBasicInfo basic = userBasicInfo.getBuessObj();
				uDto.setBirthday(basic.getBirthday());
				uDto.setGender(basic.getGender());
				uDto.setUserId(basic.getUserId());
			}
			
			//头像
			UserResult<String> imageResult = iUserBaseProfileFacade.getMyImagePath(userId, invokeFrom);
			if(null != imageResult && imageResult.isSuccess()) {
				uDto.setImagePath(imageResult.getBuessObj());
			}
			
			//用户信息
			Map<String, Object> param = new HashMap<>();
			param.put("companyName", "gomeOnLine");
			MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(userId, invokeFrom, param);
			if(null != userResult && userResult.isSuccess()) {
				UnifyUserInfoExt info = userResult.getBuessObj();
				uDto.setUserName(info.getLogin());
				uDto.setNickName(info.getNikename());
				uDto.setPhone(info.getMobile());
			}
			
			//邀请人
			String key= userCacheKey + ":" + RedisKeyUtils.getHKey(userId);
			String userStr = userCenterCache.hget(key, userId);
			if(StringUtils.isNotBlank(userStr)){
				UserInfo user = JSONObject.parseObject(userStr, UserInfo.class);
				String inviteUserId = user.getParentInviteUserId();
				userResult = iUserInfoFacade.getItemByIdForGomeShop(inviteUserId, invokeFrom, param);
				if(null != userResult && userResult.isSuccess()){
					UnifyUserInfoExt info = userResult.getBuessObj();
					uDto.setInviteNickName(info.getNikename());
					uDto.setInviteUserName(info.getLogin());
					uDto.setInviteUserId(inviteUserId);
				}
			}
		}catch(Exception e) {
			logger.error("获取用户基本信息异常，userId：{}，异常信息：{}", userId, e.getMessage());
		}

		return uDto;
	}
	
	/**
	 * 获取手机号
	 * @param userId
	 * @return
	 */
	public Map<String, String> getUserInfo(String userId){
		//用户信息
		Map<String, String> resMap = new HashMap<String, String>();
		
		Map<String, Object> param =  new HashMap<String, Object>();
		param.put("companyName", "gomeOnLine");
		MapResult<UnifyUserInfoExt> userResult = iUserInfoFacade.getItemByIdForGomeShop(userId, GroupOrderConstants.GOME_SHOP_INVOKE_FROM, param);
		if(null != userResult && userResult.isSuccess() && null != userResult.getBuessObj()) {
			UnifyUserInfoExt info = userResult.getBuessObj();
			resMap.put("mobile", info.getMobile());
			resMap.put("nickName", info.getNikename());
		}
		
		return resMap;
	}
}
