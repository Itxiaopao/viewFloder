package com.gome.meidian.grouporder.controller.app;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.app.MinProgramManager;
import com.gome.meidian.grouporder.manager.app.MinTokenManager;
import com.gome.meidian.grouporder.manager.app.ShareCardManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.app.ShareCardParamVo;
import com.gome.meidian.grouporder.vo.app.ShareCardVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupActivityTimeInfo;
import com.gome.meidian.grouporder.vo.mshopUserVo.CustomerOrderRecordParamVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import java.util.Base64;
import redis.Gcache;

@RestController
@Validated
@RequestMapping("/app")
public class AppController {
private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private MinProgramManager minProgramManager;
	
	@Resource(name = "gcache")
	private Gcache gcache;
	
	@Autowired
	private MinTokenManager minTokenManager;
	
	@Autowired
	private AuthencationUtils authencationUtils;
	
	@Autowired
	private ShareCardManager shareCardManager;
	
	/**
	 * 
	 * @param pageCode  分享页面编号1、2、3
	 * @param params  分享页面参数
	 * @param request 
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/v1/twoDimensionCode", method = RequestMethod.GET)
	public void twoDimensionCode(
			@RequestParam(value = "pageCode", required = true) String pageCode,
			@RequestParam(value = "params", required = false) String params,
			HttpServletRequest request,
			HttpServletResponse response
			){
		//ResponseJson responseJson = new ResponseJson();
		OutputStream os = null;
    	try {
    		byte[] data = minProgramManager.getShareCode(pageCode, params); 
    		if(data !=null){
    	    	response.setContentType("image/png");
    	        os = response.getOutputStream();
    	        os.write(data);
		        os.flush();
    		}
		} catch (Exception e) {
			logger.error("twoDimensionCode() == > pageCode=={},params=={}", pageCode,params);
			e.printStackTrace();
		}finally {
	        try {
	        	if(os != null){
	        		os.close();
	        	}
			} catch (IOException e) {
				logger.error("twoDimensionCode() == > pageCode=={},params=={}", pageCode,params);
				e.printStackTrace();
			}
		}
        
        //return responseJson;
	}
	
	/**
	 * 获取活动时间信息
	 * @param skuId
	 * @return
	 * @throws MeidianException
	 */
//    @RequestMapping(value = "/v1/getActivityTimeInfo", method = RequestMethod.GET)
//    public ResponseJson getActivityTimeInfo( @RequestParam(value = "skuId", required = false) String skuId) throws MeidianException {
//        ResponseJson response = new ResponseJson();
//        GroupActivityTimeInfo groupActivityTimeInfo = minProgramManager.getActivityTimeInfo(skuId);
//        response.setData(groupActivityTimeInfo);
//        return response;
//    } 
	
//	@RequestMapping(value = "/testId", method = RequestMethod.GET)
//	public ResponseJson testId(){
//		
//		ResponseJson responseJson = new ResponseJson();
//		long aa = iDGenerator.next();
//		
//		responseJson.setData(aa);
//		return responseJson;
//	}
    
    @RequestMapping(value = "/v1/getShareParamValue", method = RequestMethod.GET)
    public ResponseJson getShareParamValue( @RequestParam(value = "paramKey", required = true) String paramKey) throws MeidianException {
        ResponseJson response = new ResponseJson();
        String value = minProgramManager.getShareParamValue(paramKey);
        Map map = new HashMap<String,String>();
        map.put("value", value);
        response.setData(map);
        return response;
    } 
	
    
    @RequestMapping(value = "/v1/getGomeShareParamValue", method = RequestMethod.GET)
    public ResponseJson getGomeShareParamValue( @RequestParam(value = "paramKey", required = true) String paramKey) throws MeidianException {
        ResponseJson response = new ResponseJson();
        String value = minProgramManager.getGomeShareParamValue(paramKey);
        Map map = new HashMap<String,String>();
        map.put("value", value);
        response.setData(map);
        return response;
    } 
	
    
    /**
     * 给测试用
     * @param testKey
     * @return
     * @throws MeidianException
     */
    @RequestMapping(value = "/v1/testKey", method = RequestMethod.GET)
    public ResponseJson testKey( @RequestParam(value = "testKey", required = true) String testKey) throws MeidianException {
        ResponseJson response = new ResponseJson();
        String value = gcache.get("zhubingtestKey_"+testKey);
        Map map = new HashMap<String,String>();
        map.put("value", value);
        response.setData(map);
        return response;
    }

	public static void main(String[] args) throws UnsupportedEncodingException {
		byte[] shareCodedata = {1,2,3,4,6,6};//二进制分享码
		Base64.Encoder encoder = Base64.getEncoder();
		String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
		System.out.println(newParams);

		Base64.Decoder decoder = Base64.getDecoder();
		byte[]   result =decoder.decode(newParams);
		for(byte a:result){
			System.out.println(a);
		}
	}
}
