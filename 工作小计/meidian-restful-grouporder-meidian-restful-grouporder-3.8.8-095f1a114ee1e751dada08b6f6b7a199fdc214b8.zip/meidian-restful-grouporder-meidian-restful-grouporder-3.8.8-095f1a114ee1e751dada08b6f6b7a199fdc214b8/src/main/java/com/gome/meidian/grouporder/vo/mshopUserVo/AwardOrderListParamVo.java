package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class AwardOrderListParamVo implements Serializable{

	private static final long serialVersionUID = 5491582364892036230L;
	
	@NotNull(message = "{param.error}")
	private Integer orderStatus;
	@NotNull(message = "{param.error}")
	private Integer pageNo;
	@NotNull(message = "{param.error}")
	private Integer pageSize;
	@NotBlank(message = "{param.error}")
	private String yearMonth;
	@NotBlank(message = "{param.error}")
	private String userId;
	public Integer getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public String getYearMonth() {
		return yearMonth;
	}
	public void setYearMonth(String yearMonth) {
		this.yearMonth = yearMonth;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	
	
	

}
