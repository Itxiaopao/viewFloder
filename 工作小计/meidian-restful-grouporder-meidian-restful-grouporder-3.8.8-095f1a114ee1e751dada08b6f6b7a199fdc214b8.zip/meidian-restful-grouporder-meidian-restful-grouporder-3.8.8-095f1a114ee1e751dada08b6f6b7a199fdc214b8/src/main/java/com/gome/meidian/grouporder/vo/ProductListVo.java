package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProductListVo implements Serializable{

	private static final long serialVersionUID = -2280094510593928029L;
	private List<ProductVo> productInfos = new ArrayList<>();
	
	public ProductListVo() {
		super();
	}
	public ProductListVo(List<ProductVo> productInfoList) {
		super();
		this.productInfos = productInfoList;
	}
	public List<ProductVo> getProductInfos() {
		return productInfos;
	}
	public void setProductInfos(List<ProductVo> productInfos) {
		this.productInfos = productInfos;
	}
	
	
}
