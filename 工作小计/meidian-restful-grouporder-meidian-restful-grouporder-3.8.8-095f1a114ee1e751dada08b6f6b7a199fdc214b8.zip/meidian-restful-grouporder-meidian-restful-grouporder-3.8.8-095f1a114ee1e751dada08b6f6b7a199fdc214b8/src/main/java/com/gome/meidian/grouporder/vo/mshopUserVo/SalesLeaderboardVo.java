package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 销售排行榜
 * @author limenghui-ds
 * @create 2019-11-27 11:12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SalesLeaderboardVo implements Serializable{
    private static final long serialVersionUID = 6214041315317808182L;
    /**
     * 用户ID
     */
    private Long userId;
    /**
     * 头像
     */
    private String headImage;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 邀请新人数量
     */
    private Integer inviteCount;
    /**
     * 积分
     */
    private Double integral;
    /**
     * 销售额
     */
    private Long Sales;

    /**
     * 排位
     */
    private Integer rank;




}
