package com.gome.meidian.grouporder.controller.mshopUser;

import com.gome.architect.risk.dto.RequestV2;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.common.MeidianMemberService;
import com.gome.meidian.grouporder.common.MeidianRiskService;
import com.gome.meidian.grouporder.manager.RegisterManager;
import com.gome.meidian.grouporder.manager.UserAndRegisterRiskSwitchManager;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.AccountLoginManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.QuickLoginManager;
import com.gome.meidian.grouporder.utils.*;
import com.gome.meidian.grouporder.vo.mshopUserVo.CommonVariableVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.QuickLoginVo;
import com.gome.meidian.grouporder.vo.register.UserInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.meidian.user.manager.IUserRoleManager;
import com.gome.userCenter.model.GomeUnifyRegisterUser;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UserRegisterResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: QuickLoginController
 * @ProjectName meidian-restful-grouporder
 * @Description: TODO
 * @date 2018/11/29 17:00
 */
@Slf4j
@RestController
@RequestMapping("/mshopUser/mobileLogin")
public class QuickLoginController {

    @Autowired
    private QuickLoginManager quickLoginManager;
    @Autowired
    private MeidianRiskService meidianRiskService;
    @Autowired
    private RegisterManager registerManager;
    @Autowired
    private AccountLoginManager accountLoginManager;
    @Autowired
    private MeidianMemberService meidianMemberService;

    @Value("${cookie.path}")
    private String path;

    @Value("${cookie.domain}")
    private String domain;

    @Value("${cookie.time}")
    private int time;


    @Resource(name = "userCenter")
    private Gcache userCenter;

    @Resource(name = "venusVshop")
    private Gcache venusVshopGcache;

    @Autowired
    private IUserInfoManager iUserInfoManager;

    @Autowired
    private IUserRoleManager iUserRoleManager;

    @PostMapping(value = "quickLogin")
    public ResponseJson quickLogin(@RequestBody QuickLoginVo quickLoginVo, HttpServletRequest request, HttpServletResponse response) throws Exception {
        log.info("QuickLoginController.quickLogin,params:{}", quickLoginVo.getMobile());
        ResponseJson responseJson = new ResponseJson(1, "请求参数错误");
        if (StringUtils.isEmpty(quickLoginVo.getMobile()) || StringUtils.isEmpty(quickLoginVo.getCode()))
            return responseJson;
        RequestV2 requestV2 = new RequestV2();
        if (StringUtils.isNotEmpty(quickLoginVo.getToken())) {
            meidianRiskService.sliderVal(quickLoginVo.getToken());//滑块风控
        } else {
            String riskStatus=userCenter.get(UserAndRegisterRiskSwitchManager.RISK_SWITCH_WAP_MEIDIAN_SMS_LOGIN);
            if(null!=riskStatus&& WechatLoginManager.RESULT_SUCCESS_NO.equals(riskStatus)){
                //当标识不是null 或者 false的时候,风控降级
            }else{
                //null or true 使用注册风控
                requestV2.setBizNo(CommonVariableVo.quick_login_bizNo);
                requestV2.setUserId(quickLoginVo.getMobile());//userID暂时传手机号
                requestV2.setPhone(quickLoginVo.getMobile());
                meidianRiskService.predict(requestV2, request);//登录风控验证 通过登录 不通过滑块验证
            }
        }
        UserInfoVo userInfo = new UserInfoVo();
        userInfo.setMobile(quickLoginVo.getMobile());
        boolean b = quickLoginManager.checkMobileAndRegist(userInfo);//校验手机号是否存在
        if(!b){//手机号不存在   注册
            //注册接口调用-登录返回scn
            GomeUnifyRegisterUser gomeUser = new GomeUnifyRegisterUser();
            gomeUser.setRegisterType(UserConstants.REGISTER_TYPE_MOBILEREG);//手机注册
            gomeUser.setRegisterIp(RequestUtils.getIP(request));
            gomeUser.setRegisterSource("gomeShopWap");//注册来源-会员申请
            gomeUser.setLogin(quickLoginVo.getMobile());
            gomeUser.setPassword("SNS_GOME_PWD");
            gomeUser.setMobile(quickLoginVo.getMobile());
            Map<String,Object> extMap = new HashMap<String,Object>();
            extMap.put("companyName", CommonVariableVo.companyName);//渠道标识
            if(StringUtils.isNotEmpty(quickLoginVo.getDistinctId())){
                extMap.put("distinctId", quickLoginVo.getDistinctId());
            }
            String SCN = null;
            String id = null;
            UserRegisterResult<GomeUnifyRegisterUser> registerUnifyUser = meidianMemberService.registerUnifyUser(gomeUser, extMap);
            if(null != registerUnifyUser.getExtMap() && registerUnifyUser.getExtMap().size()>0){
                SCN= (String)registerUnifyUser.getExtMap().get("SCN");
                try {
                    SCN=URLEncoder.encode(SCN,"UTF-8");
                } catch (UnsupportedEncodingException e) {
                    log.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",SCN,e);
                }
            }
            if(registerUnifyUser.isSuccess()){
                //添加用户记录
                if(null != registerUnifyUser.getBuessObj().getId()){
                    LoginRecordThread thread= new LoginRecordThread(registerUnifyUser.getBuessObj().getId(), quickLoginVo.getCreateType(),"1", userCenter, venusVshopGcache, iUserInfoManager, iUserRoleManager);
                    ThreadPoolManager.newInstance().addExecuteTask(thread);
                    id = registerUnifyUser.getBuessObj().getUserId();
                }

            }
            //写COOKIE
            if(StringUtils.isNotBlank(SCN)){
                CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
                CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID, id,path,domain,time);
            }
            if(!registerUnifyUser.isSuccess()){
                //注册失败
                responseJson.setCode(5);
                responseJson.setMsg("注册失败");
                return responseJson;
            }
        }

        //登录风控通过 手机号快登
        try {
            String ip = RequestUtils.getIP(request);
            String port = request.getRemotePort() + "";
            RequestParams requestParams = new RequestParams();
            requestParams.setInvokeChannel(CommonVariableVo.invokeChannel);
            requestParams.setClientIp(ip);
            requestParams.setRemotePort(port);
            Map<String, Object> map = new HashMap<>();
            map.put("companyName", CommonVariableVo.companyName);
            map.put("businessName", CommonVariableVo.BusinessName_quick);
            map.put("templateId", CommonVariableVo.BusinessId_quick);
            map.put("msgCode", quickLoginVo.getCode());
            if(StringUtils.isNotEmpty(quickLoginVo.getDistinctId())){
                map.put("distinctId", quickLoginVo.getDistinctId());
            }
            //            map.put("isAutoLogin", true);
            responseJson = quickLoginManager.quickLogin(quickLoginVo, CommonVariableVo.invokeFrom, requestParams, map, response);
        } catch (Exception e) {
            e.printStackTrace();
            log.info("QuickLoginController quickLogin:{}",e.getMessage());
            responseJson.setCode(3);
            responseJson.setMsg("手机快登服务异常");
        }
        return responseJson;
    }

//    /**
//     * 手机号密码登录
//     *
//     * @param quickLoginVo
//     * @param request
//     * @return
//     */
//    public ResponseJson mobileLogin(@RequestBody QuickLoginVo quickLoginVo, HttpServletRequest request) throws MeidianException {
//        ResponseJson responseJson = new ResponseJson(1, "请求参数异常");
//        try {
//            //校验登录验证码
//            if (StringUtils.isNotEmpty(quickLoginVo.getMobile()) && StringUtils.isNotEmpty(quickLoginVo.getCode())) {
//                boolean b = quickLoginManager.checkCode(quickLoginVo);
//                if (b) {
//                    if (StringUtils.isNotEmpty(quickLoginVo.getPassword())) {
//                        UserInfoVo userInfo = new UserInfoVo();
//                        userInfo.setMobile(quickLoginVo.getMobile());
//                        quickLoginManager.checkMobile(userInfo);//校验手机号是否存在
//                    } else return responseJson;
//
//                    RequestV2 requestV2 = new RequestV2();
//                    requestV2.setBizNo(CommonVariableVo.bizNo);
//                    requestV2.setUserId(quickLoginVo.getMobile());//暂时传入手机号
//
//                    String ip = RequestUtils.getIP(request);
//                    String port = request.getRemotePort() + "";
//                    RequestParams requestParams = new RequestParams();
//                    requestParams.setInvokeChannel(CommonVariableVo.invokeFrom);
//                    requestParams.setClientIp(ip);
//                    requestParams.setRemotePort(port);
//                    Map<String, Object> map = new HashMap<>();
//                    map.put("companyName", CommonVariableVo.companyName);
//                    //            map.put("isAutoLogin", true);
//                    responseJson = accountLoginManager.doLogin(quickLoginVo.getUserId(), quickLoginVo.getPassword(), requestParams, map, requestV2, request);
//                } else {
//                    responseJson.setCode(2);
//                    responseJson.setMsg("校验码验证错误");
//                }
//            }
//        } catch (Exception e) {
//            responseJson.setCode(3);
//            responseJson.setMsg("服务异常");
//        }
//        return responseJson;
//    }


    /**
     * 短信风控 + 发送短信验证码
     *
     * @param quickLoginVo
     * @return
     */
    @RequestMapping(value = "/sendSms", method = RequestMethod.POST)
    public ResponseJson sendSms(@RequestBody QuickLoginVo quickLoginVo, HttpServletRequest request) throws MeidianException {
        log.info("QuickLoginController.quickLogin,params:{}", quickLoginVo.getMobile());
        ResponseJson responseJson = new ResponseJson(2, "请求参数异常");
//        try {
        if (StringUtils.isNotEmpty(quickLoginVo.getMobile())) {

            boolean b = quickLoginManager.sendSms(quickLoginVo.getMobile(), request);
            if (b) {
                responseJson.setCode(0);
                responseJson.setMsg("发送短信成功");
            } else {
                responseJson.setCode(1);
                responseJson.setMsg("发送短信失败");
            }
        }
//        } catch (Exception e) {
//            responseJson.setCode(3);
//            responseJson.setMsg("发送短信服务异常");
//        }
        return responseJson;
    }

    /**
     * 校验短信验证码
     *
     * @param quickLoginVo
     * @return
     */
//    @PostMapping(value = "/checkCode")
    public ResponseJson checkCode(@RequestBody QuickLoginVo quickLoginVo) {
        ResponseJson responseJson = new ResponseJson();
        try {
            if (StringUtils.isNotEmpty(quickLoginVo.getMobile()) && StringUtils.isNotEmpty(quickLoginVo.getCode())) {
                boolean b = quickLoginManager.checkCode(quickLoginVo);
                if (b) {
                    responseJson.setCode(0);
                } else {
                    responseJson.setCode(1);
                }
            }
        } catch (Exception e) {
            responseJson.setCode(1);
        }
        return responseJson;
    }
}
