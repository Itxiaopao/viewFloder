package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.coupon.Promotion;
import com.gome.meidian.grouporder.vo.product.AppreciationServeType;

/**
 * 组团sku封装
 * @author shichangjian
 *
 */
public class GroupSkuVo implements Serializable{

	private static final long serialVersionUID = 501752879862869712L;

	private Sku sku;								// sku基本信息
	private GroupActivityInfo groupActivityInfo;	// 商品集信息
	
	
	public Sku getSku() {
		return sku;
	}
	public void setSku(Sku sku) {
		this.sku = sku;
	}
	public GroupActivityInfo getGroupActivityInfo() {
		return groupActivityInfo;
	}
	public void setGroupActivityInfo(GroupActivityInfo groupActivityInfo) {
		this.groupActivityInfo = groupActivityInfo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
