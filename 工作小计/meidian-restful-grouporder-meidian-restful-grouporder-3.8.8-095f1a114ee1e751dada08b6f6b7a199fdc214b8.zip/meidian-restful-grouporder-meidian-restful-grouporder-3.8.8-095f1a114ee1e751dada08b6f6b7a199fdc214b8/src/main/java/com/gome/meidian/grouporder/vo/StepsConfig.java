package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

public class StepsConfig implements Serializable {
	private static final long serialVersionUID = 7656770417440824359L;
	private String step;
	private String peopleNum;
	private String discount;
	public String getStep() {
		return step;
	}
	public void setStep(String step) {
		this.step = step;
	}
	public String getPeopleNum() {
		return peopleNum;
	}
	public void setPeopleNum(String peopleNum) {
		this.peopleNum = peopleNum;
	}
	public String getDiscount() {
		return discount;
	}
	public void setDiscount(String discount) {
		this.discount = discount;
	}
	
}