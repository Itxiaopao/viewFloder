package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.List;

/**
 * 客户管理页面初始化
 * @author libinbin-ds
 *
 */
public class MyGuestInit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1939965396450916224L;
	
	private List<GuestCount> guestReduces;
	
	private List<GuestInfo> guestInfos;


	public List<GuestCount> getGuestReduces() {
		return guestReduces;
	}

	public void setGuestReduces(List<GuestCount> guestReduces) {
		this.guestReduces = guestReduces;
	}

	public List<GuestInfo> getGuestInfos() {
		return guestInfos;
	}

	public void setGuestInfos(List<GuestInfo> guestInfos) {
		this.guestInfos = guestInfos;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

}
