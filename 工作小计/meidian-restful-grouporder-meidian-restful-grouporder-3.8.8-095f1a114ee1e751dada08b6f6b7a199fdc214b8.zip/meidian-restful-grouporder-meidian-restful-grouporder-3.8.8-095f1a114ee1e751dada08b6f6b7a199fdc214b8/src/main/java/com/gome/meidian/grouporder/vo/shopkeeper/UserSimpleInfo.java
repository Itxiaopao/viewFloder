package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;

/**
 * 简单用户
 * 
 * @author libinbin-ds
 *
 */
public class UserSimpleInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1599469101331047599L;
	
	private String weiXinNickName;//微信昵称
    private String weixinNum;//微信号
    private String imagePath;//头像
	private String userId;
	private String uniqueId;	// 游客id
	
	
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getWeiXinNickName() {
		return weiXinNickName;
	}
	public void setWeiXinNickName(String weiXinNickName) {
		this.weiXinNickName = weiXinNickName;
	}
	public String getWeixinNum() {
		return weixinNum;
	}
	public void setWeixinNum(String weixinNum) {
		this.weixinNum = weixinNum;
	}
	public String getImagePath() {
		return imagePath;
	}
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public UserSimpleInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserSimpleInfo(String weiXinNickName, String weixinNum, String imagePath, String userId) {
		this.weiXinNickName = weiXinNickName;
		this.weixinNum = weixinNum;
		this.imagePath = imagePath;
		this.userId = userId;
	}
	

}
