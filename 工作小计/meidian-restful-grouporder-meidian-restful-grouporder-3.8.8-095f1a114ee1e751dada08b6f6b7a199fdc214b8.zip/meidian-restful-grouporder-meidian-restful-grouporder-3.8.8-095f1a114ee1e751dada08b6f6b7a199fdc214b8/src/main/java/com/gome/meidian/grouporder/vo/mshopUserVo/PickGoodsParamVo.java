package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class PickGoodsParamVo implements Serializable{

	private static final long serialVersionUID = 8215391893507550256L;

	@NotBlank(message = "{param.error}")
	private String deliveryId;
	@NotNull(message = "{param.error}")
	private Integer isPickGoods;

}
