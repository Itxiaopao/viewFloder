package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.Product;

/**
 * 首页超级返列表
 * @author shichangjian
 *
 */
public class ProductBuyRebateVo implements Serializable{

	private static final long serialVersionUID = 1033714241906681200L;

	private Product product;	// 商品信息
	private String buyRebate;	// 购买返
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public String getBuyRebate() {
		return buyRebate;
	}
	public void setBuyRebate(String buyRebate) {
		this.buyRebate = buyRebate;
	}
	
	
}
