package com.gome.meidian.grouporder.vo.monitor;

import java.io.Serializable;

/**
 * 接口监控
 * @author shichangjian
 *
 */
public class MonitorVo implements Serializable{

	private static final long serialVersionUID = 5147032197843497067L;

	private String interfacePerson;			// 接口负责人
	private String interfaceName;			// 接口名
	private String interfaceState;			// 接口状态
	private String interfaceResponse;		// 接口返参
	
	public MonitorVo() {
		super();
	}


	public MonitorVo(String interfacePerson, String interfaceName, String interfaceState, 
			String interfaceResponse) {
		super();
		this.interfacePerson = interfacePerson;
		this.interfaceName = interfaceName;
		this.interfaceState = interfaceState;
		this.interfaceResponse = interfaceResponse;
	}

	public String getInterfacePerson() {
		return interfacePerson;
	}


	public void setInterfacePerson(String interfacePerson) {
		this.interfacePerson = interfacePerson;
	}


	public String getInterfaceName() {
		return interfaceName;
	}


	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}


	public String getInterfaceState() {
		return interfaceState;
	}


	public void setInterfaceState(String interfaceState) {
		this.interfaceState = interfaceState;
	}


	public String getInterfaceResponse() {
		return interfaceResponse;
	}


	public void setInterfaceResponse(String interfaceResponse) {
		this.interfaceResponse = interfaceResponse;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
