package com.gome.meidian.grouporder.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.cxf.common.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.gome.frontSe.interfaces.IProdDetailService;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.PriceConditionVo;
import com.gome.meidian.grouporder.vo.RecProductInfoVo;
import com.gome.meidian.grouporder.vo.ShopInfoVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupTotal;
import com.gome.stage.bean.price.GomeUnifiedPrice;
import com.gome.stage.interfaces.item.IShopService;
import com.gome.stage.item.SkuItem;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.ProductInfoListVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductManagementConciseVo;

import jodd.util.StringUtil;
import redis.Gcache;
/**
 * 商品推荐逻辑处理层
 * @author lishouxu-ds
 *
 */
@Service
public class ProductRecommendManager {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private IShopService shopService;
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private IProdDetailService prodDetailService;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Value("${meidian.image.agreement}")
	private String agreement;			// http协议
	@Autowired
	private PriceManager priceManager;
	
	
	//private String[] shopProperties = {"shopId","shopName","shopHotLine","goodsMatch","serviceScore","deliverySpeed","shopLogoUrl"};
	private String[] shopProperties = {"merchantId","merchantName","shopHotLine","goodsMatch","serviceScore","deliverySpeed","shopLogoUrl"};
	/**
	 * 获取店铺信息
	 * @param id
	 * @return
	 */
	public ShopInfoVo getShopInfo(String id){
		ShopInfoVo ShopInfo = null;
		Map<String, String> shopMap = shopService.getShopMultiProperties(id, shopProperties);
		//logger.info("shopService.getShopMultiProperties ==> {} ", shopMap);
		if(shopMap != null && !shopMap.isEmpty()){
			String shopId = shopMap.get("merchantId");
			if(shopId == null){
				return ShopInfo;
			}else{
				ShopInfo = new ShopInfoVo();
				ShopInfo.setShopId(shopId);
				String shopName = shopMap.get("merchantName");
				ShopInfo.setShopName(shopName == null?"":shopName);
				String shopHotLine = shopMap.get("shopHotLine");
				ShopInfo.setShopHotLine(shopHotLine == null?"":shopHotLine);
				String goodsMatch = shopMap.get("goodsMatch");
				ShopInfo.setGoodsMatch(goodsMatch == null?0d:DoubleUtils.round(Double.valueOf(goodsMatch),1));
				String serviceScore = shopMap.get("serviceScore");
				ShopInfo.setServiceScore(serviceScore == null?0d:DoubleUtils.round(Double.valueOf(serviceScore),1));
				String deliverySpeed = shopMap.get("deliverySpeed");
				ShopInfo.setDeliverySpeed(deliverySpeed == null?0d:DoubleUtils.round(Double.valueOf(deliverySpeed),1));
				String shopLogoUrl = shopMap.get("shopLogoUrl");
				ShopInfo.setShopLogoUrl(shopLogoUrl == null?"":shopLogoUrl);
                // 替换http协议，把http替换为https
                if (ShopInfo.getShopLogoUrl() != null && ShopInfo.getShopLogoUrl().contains("http:")) {
                	ShopInfo.setShopLogoUrl(ShopInfo.getShopLogoUrl().replace("http:", agreement));
                }
				//计算平均分、星级
				Double sumScore = DoubleUtils.add(DoubleUtils.add(ShopInfo.getDeliverySpeed(), ShopInfo.getGoodsMatch()), ShopInfo.getServiceScore());
				Double avgScore = DoubleUtils.divide(sumScore,3d,1);
				ShopInfo.setAvgScore(avgScore);
				if(avgScore > 0.0d){
					String smallNum = String.valueOf(avgScore).replaceAll("\\d+\\.", "");
					String bigNum = String.valueOf(avgScore).replaceAll("\\.+\\d", "");
					if(0 < Integer.valueOf(smallNum) && Integer.valueOf(smallNum) < 6){
						ShopInfo.setStarNumber(DoubleUtils.add(Double.valueOf(bigNum), 0.5d));
					}else if(Integer.valueOf(smallNum) >=6){
						ShopInfo.setStarNumber(DoubleUtils.add(Double.valueOf(bigNum), 1.0d));
					}else{
						ShopInfo.setStarNumber(avgScore);
					}
				}else{
					ShopInfo.setStarNumber(0d);
				}
			}
		}
		return ShopInfo;
	}
	
	/**
	 * 获取店铺的组团商品信息
	 * @param shopId
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws ServiceException 
	 */
	public List<RecProductInfoVo> getProductInfo(String shopId,Integer pageSize, Integer pageNum ,Integer ppi ,Byte ua ,String priceAreaCode, String channel, String priceStoreCode, String policyId) throws ServiceException{
//		long gorderInfoForAppNewResourcebegin = System.currentTimeMillis();
		CommonResultEntity<ProductInfoListVo> commonResultEntity=gorderInfoForAppNewResource.getProductInfoByShopId(shopId,pageSize,pageNum);
//		long gorderInfoForAppNewResourceend = System.currentTimeMillis();
//		System.out.println("################################gorderInfoForAppNewResource.getProductInfoByShopId"+(gorderInfoForAppNewResourceend-gorderInfoForAppNewResourcebegin));
		String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE);
		List<RecProductInfoVo> list = null;
		Map<String,RecProductInfoVo> map = null;
		if(commonResultEntity !=null && commonResultEntity.getCode() ==0){
			ProductInfoListVo productInfoListVo = commonResultEntity.getBusinessObj();
			if(productInfoListVo !=null && !CollectionUtils.isEmpty(productInfoListVo.getProductInfo())){
				map = new LinkedHashMap<String,RecProductInfoVo>();
				list = new ArrayList<RecProductInfoVo>();
				List<ProductGroupTotal> productGroupTotals = null;
				List<String> productIds = new ArrayList<String>();
				
				List<Map<String, String>> infoList = new ArrayList<>();
				Map<String, String> infoMap = null;
				int count = 1;
				
				for(ProductManagementConciseVo productManagementConciseVo:productInfoListVo.getProductInfo()){
					RecProductInfoVo recProductInfoVo=new RecProductInfoVo();
					recProductInfoVo.setActivityId(productManagementConciseVo.getActivityId());
					recProductInfoVo.setMaxDiscountNeedPeopleNum(productManagementConciseVo.getMaxDiscountNeedPeopleNum());
					recProductInfoVo.setName(productManagementConciseVo.getName());
					recProductInfoVo.setPrice(DoubleUtils.divide(Double.valueOf(String.valueOf(productManagementConciseVo.getPrice())), 100d,2));
					recProductInfoVo.setProductId(productManagementConciseVo.getProductId());
					recProductInfoVo.setProductImage(productManagementConciseVo.getProductImage());
					
	                // 替换http协议，把http替换为https
	                if (recProductInfoVo.getProductImage() != null && recProductInfoVo.getProductImage().contains("http:")) {
	                	recProductInfoVo.setProductImage(recProductInfoVo.getProductImage().replace("http:", agreement));
	                }
					
	                String image = ImageUtils.imageUrlInfo(recProductInfoVo.getProductImage(), ratio, ua);
	                recProductInfoVo.setProductImage(image);
					
					recProductInfoVo.setProductStatus(productManagementConciseVo.getProductStatus());
					recProductInfoVo.setProductTag(productManagementConciseVo.getProductTag());
					recProductInfoVo.setShopId(productManagementConciseVo.getShopId());
					recProductInfoVo.setSkuId(productManagementConciseVo.getSkuId());
					recProductInfoVo.setIrrigationNumbe(productManagementConciseVo.getIrrigationNumbe());;
					recProductInfoVo.setMaxDiscount(productManagementConciseVo.getMaxDiscount());
					recProductInfoVo.setRebateAmount(groupOrderManager.getRebateAmount(productManagementConciseVo.getPrice(), productManagementConciseVo.getMaxDiscount()));
					productIds.add(productManagementConciseVo.getProductId());
					recProductInfoVo.setSalesVolume(0);
					//查询商品的skuNo
					if(!StringUtils.isEmpty(recProductInfoVo.getProductId()) && !StringUtils.isEmpty(recProductInfoVo.getSkuId())){
						String key = "recommendShopProductInfo" + "_" + recProductInfoVo.getProductId() + "_" + recProductInfoVo.getSkuId(); 
						String skuNo = gcache.get(key);
						if(StringUtils.isEmpty(skuNo)){
							SkuItem skuItem = prodDetailService.getSku(recProductInfoVo.getProductId(), recProductInfoVo.getSkuId(), null);
							if(null != skuItem){
								if(!StringUtils.isEmpty(skuItem.getSkuNo())){
									gcache.setex(key, 60,skuItem.getSkuNo());
								}
								recProductInfoVo.setSkuNo(skuItem.getSkuNo());
							}
						}else{
							recProductInfoVo.setSkuNo(skuNo);
						}

					}

					map.put(recProductInfoVo.getProductId()+"||"+recProductInfoVo.getSkuId(), recProductInfoVo);
					
					if(count % 12 == 1) {
						infoMap = new HashMap<>();
						infoList.add(infoMap);
					}
					infoMap.put(productManagementConciseVo.getSkuId(), productManagementConciseVo.getProductId());
					count++;
					
					
				}
//				long getProductBuyNumbegin = System.currentTimeMillis();
				productGroupTotals = groupOrderManager.getProductBuyNum(productIds);
//				long getProductBuyNumend = System.currentTimeMillis();
//				System.out.println(">>>>>>>>>>>>>>>>>>>groupOrderManager.getProductBuyNum"+(getProductBuyNumend-getProductBuyNumbegin));
				//渲染
				if(!CollectionUtils.isEmpty(productGroupTotals)){
					for(ProductGroupTotal productGroupTotal:productGroupTotals){
						if(!StringUtil.isBlank(productGroupTotal.getProductId()) && productGroupTotal.getTotalBuyNumbers() != null){
							Iterator<String> it = map.keySet().iterator();
							while (it.hasNext()) {
								String key = it.next().toString();
								RecProductInfoVo recProductInfoVo = map.get(key);
								if(!StringUtil.isBlank(recProductInfoVo.getProductId())&&recProductInfoVo.getProductId().equals(productGroupTotal.getProductId())){
									Integer salesVolume = productGroupTotal.getTotalBuyNumbers()*recProductInfoVo.getIrrigationNumbe();
									recProductInfoVo.setSalesVolume(salesVolume);
									map.put(key, recProductInfoVo);
								}

							}
						}
						
					}
				}
				
				//取美店价逻辑  begin
				List<PriceConditionVo> conditionList = new ArrayList<>();
				PriceConditionVo priceCondition = null;
				Map<String, String> infoMapre = null;
				for(int i = 0; i < infoList.size(); i++) {
					infoMapre = infoList.get(i);
					if(null != infoMapre && !infoMapre.isEmpty()) {
						for(Map.Entry<String, String> mm: infoMapre.entrySet()) {
							priceCondition = new PriceConditionVo();
							priceCondition.setSkuId(mm.getKey());
							priceCondition.setProductId(mm.getValue());
							priceCondition.setChannel(channel);
							priceCondition.setPolicyId(policyId);
							
							conditionList.add(priceCondition);
						}
						
						List<GomeUnifiedPrice> priceRes = priceManager.getPrice(conditionList);
						if(null != priceRes && !priceRes.isEmpty()) {
                            for(GomeUnifiedPrice GomeUnifiedPrice : priceRes){
                            	if(GomeUnifiedPrice != null && GomeUnifiedPrice.getPrice()!= null && !StringUtils.isEmpty(GomeUnifiedPrice.getSkuId())){
        							Iterator<String> it = map.keySet().iterator();
        							while (it.hasNext()) {
        								String key = it.next().toString();
        								RecProductInfoVo recProductInfoVo = map.get(key);
        								if(!StringUtil.isBlank(recProductInfoVo.getSkuId())&&recProductInfoVo.getSkuId().equals(GomeUnifiedPrice.getSkuId())){
        									
        									recProductInfoVo.setPriceType(GomeUnifiedPrice.getPriceType());
        									// 单位转换，元变分
        									Double price = DoubleUtils.mul(GomeUnifiedPrice.getPrice(), 100d);
        									// 折扣返利
        									double rebatePrice = groupOrderManager.getRebateAmount(price.longValue(), recProductInfoVo.getMaxDiscount());
        									recProductInfoVo.setRebateAmount(rebatePrice);
        									recProductInfoVo.setPrice(GomeUnifiedPrice.getPrice());
        									map.put(key, recProductInfoVo);
        								}

        							}
                            	}
                            }
						}
						conditionList.clear();
					}
				}
				//取美店价逻辑  end
				
				
				//转list
				Iterator<String> it = map.keySet().iterator();
				while (it.hasNext()) {
					String key = it.next().toString();
					list.add(map.get(key));
				}
				
			}
			
		}
		return list;
	}
	
	public static void main(String[] args) {
		double avgScore=3.d;
		String bigNum = String.valueOf(avgScore).replaceAll("\\.+\\d", "");
		System.out.println(bigNum);
	}
	

}
