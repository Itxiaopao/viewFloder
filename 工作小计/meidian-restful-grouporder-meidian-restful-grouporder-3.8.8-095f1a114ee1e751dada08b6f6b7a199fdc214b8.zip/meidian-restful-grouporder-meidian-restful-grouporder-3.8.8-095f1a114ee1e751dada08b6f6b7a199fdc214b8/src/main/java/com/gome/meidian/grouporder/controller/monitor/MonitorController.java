package com.gome.meidian.grouporder.controller.monitor;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.methods.HttpGet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.aop.MDLoginAnnotation;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.monitor.MonitorManager;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.thread.ThreadPoolUtils;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

@RestController
@Validated
//@CrossOrigin(origins= {"http://devops.atguat.com.cn","http://10.115.2.30:9109"})
//允许H5的域名http://devops.atguat.com.cn跨域（接口地址是http://10.115.2.30:9109）
@CrossOrigin(origins= {"http://devops.atguat.com.cn"})

//本机调试
//@CrossOrigin
@RequestMapping("/monitor")
public class MonitorController {

	@Autowired
	private PropertiesConfig propertiesConfig;
	@Autowired
	private MonitorManager monitorManager;
	@Autowired
	private ThreadPoolUtils threadPoolUtils;
	@Autowired
	private HttpClientUtil httpClientUtil;
	
	@RequestMapping(value = "/v1/interfaceMonitor", method = RequestMethod.GET)
	public ResponseJson interfaceMonitor(
			@CookieValue(value = "StoreCode", required = false) String StoreCode,
			@CookieValue(value = "Channel", required = false) String Channel,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
			@CookieValue(value = "SCN", required = false) String SCN,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@RequestParam(value = "channel", required = false) String channel,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "scn", required = false) String scn,
			HttpServletRequest request,
			HttpServletResponse response
			) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		
//		// 读cookie
//		Cookie cookie[] = request.getCookies();
//		for(int i = 0; i < cookie.length; i++){
//			System.err.println(cookie[i].getName() + " --------- " + cookie[i].getValue());
//		}
//		
//		// 写cookie
//		Cookie writeCookie = new Cookie("aa", "bb"); 
//		writeCookie.setMaxAge(3600);
//		//设置路径，这个路径即该工程下都可以访问该cookie 如果不设置路径，那么只有设置该cookie路径及其子路径可以访问
//		writeCookie.setPath("/");
//		response.addCookie(writeCookie);
//		
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		
//		resMap.put("model", "kkkk");
		
		String s = null;
		if(null == SCN || SCN.equals("")){
			s = scn;
		}else
			s = SCN;
		Map<String, Object> resMap = monitorManager.monitor(s);
		
		responseJson.setData(resMap);
		return responseJson;
	}
	
	@MDLoginAnnotation
	@MDStorePriceAnnotation
	@RequestMapping(value = "test", method = RequestMethod.GET)
	public ResponseJson test(
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "SCN", required = false) String SCN,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@CookieValue(value = "switching_store", required = false) String switchingStore,
//			@RequestParam(value = "storeCode", required = false) String storeCode,
//			@RequestParam(value = "channel", required = false) String channel,
//			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@RequestParam(value = "scn", required = false) String scn,
//			@RequestParam(required = false) PriceReqUtils priceReqUtils,
//			@RequestBody @Validated Store store,
//			@RequestBody @Validated SearchInfoReqVo searchInfoReqVo,
//			HttpServletRequest request,
//			HttpServletResponse response
			){
		
		ResponseJson responseJson = new ResponseJson();
		
		System.err.println("priceReqStoreCode =====" + MeidianEnvironment.getKey("priceReqStoreCode")); 
		System.err.println("priceReqAreaCode =====" + MeidianEnvironment.getKey("priceReqAreaCode")); 
		for (int i = 0; i < 10; i++) {
			try {
				// 声明 http get 请求
				HttpGet httpGet = new HttpGet("http://10.115.2.30:9109/grouporder/home/v2/homePage?AreaCode=11010000&StoreCode=A00F");
				httpGet.setHeader("Cookie", "isnew=992783578947.1578467923882; __clickidc=138860338978467923; __c_visitor=138860338978467923; __gmc=d853971; __gmv=1594956151438.1578467923893; ctx=app-meidian|ver-1.0|plt-wap|cmpid-; PPI=1000500; route=afeeb95dcb0b8338641b991b569b836f; m_u_text=m_u_text; m_s_mid=; m_s_back=; Channel=WAP; m_u_orgId=1001; m_u_areaCode=11010000; storeCode=A00F; m_u_storeType=0; ShareUserId=; g_province=11000000; g_city=11010000; g_district=11010200; g_town=110102002; g_longitude=116.447456; g_latitude=39.974936; __gma=d853971.1594956151438.1578467923893.1578467923893.1578580512220.2; __gmz=d853971|-|-|direct|-|-|-|1594956151438.1578467923893|dc-2|1578580512221; gm_sid=j5t797jdo3ablr8p2h0gaecqn3c8h3q27k915785804823; ufpd=316e32c3aa65c541877b563a4c805ccda649710927c4af5502043e6515ce9023a9191419905f7bccfa2e99e3b77ee2f4a9c2d2d1a06fef69c9eac19ebb8feba2|5e173a02YhrTnMLT4gWn1RT14dRxHAODsBh759s1; ufpd=316e32c3aa65c541877b563a4c805ccda649710927c4af5502043e6515ce9023a9191419905f7bccfa2e99e3b77ee2f4a9c2d2d1a06fef69c9eac19ebb8feba2|5e173a02YhrTnMLT4gWn1RT14dRxHAODsBh759s1; http_referer=http%3A%2F%2Flogin.m.gomeuat.com.cn%2Flogin.html%3Freturn_url%3DaHR0cDovL2QubS5nb21ldWF0LmNvbS5jbi9teT9zdG9yZUNvZGU9QTAwRg%253D%253D; __ugk=c6bcc4abec864839a31928bedab9e65c; __uls=Y; __unick=%25E5%25B0%258F%25E6%2597%25B6-%25E5%2587%2591%25E5%258D%2595; __uxglt=Pc0jlCMLaajjicLtzw%252BxjTZr%252BI6%252Bk4xpHjTV3svtxH809vSGdxfXho82ZOeF4dKK21G1uYVQRi6%252Fld9fk4zrSDBs84fD32fsKUZL7nMZApzoJD%252FqvMzDHRoRrGRY4lGfb231057647e7135879360fee817c0a5e; SSO_USER_ID=100041721122; SCN=Pc0jlCMLaajjicLtzw%2BxjTZr%2BI6%2Bk4xpHjTV3svtxH809vSGdxfXho82ZOeF4dKK21G1uYVQRi6%2Fld9fk4zrSDBs84fD32fsKUZL7nMZApzoJD%2FqvMzDHRoRrGRY4lGfb231057647e7135879360fee817c0a5e; gome_pin=15238837072; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%22100041721122%22%2C%22%24device_id%22%3A%2216f84051874f47-04a8c279074e28-2d604637-250125-16f84051875437%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_referrer%22%3A%22%22%2C%22%24latest_referrer_host%22%3A%22%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%7D%2C%22first_id%22%3A%2216f84051874f47-04a8c279074e28-2d604637-250125-16f84051875437%22%7D; DNY_USER_ID=100041721122; m_u_id=100041721122; m_u_name=%E5%B0%8F%E6%97%B6-%E5%87%91%E5%8D%95; m_u_mid=2632; plasttime=1578580662; __gmb=d853971.4.1594956151438|2.1578580512220; m_s_kid=2a8LGhiC562BHgJ3jlPdSp; m_s_stid=A00F");
				String result = httpClientUtil.doGet(httpGet);
				JSONObject jSONObject = JSONObject.parseObject(result);
//				System.err.println(jSONObject.get("data"));
				
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		Map<String, String> restMap = threadPoolUtils.getThreadPoolMonitor();
		restMap.put("userId", MeidianEnvironment.getUserId());
		responseJson.setData(restMap);
		return responseJson;
	}
	
	/**
	 * 线程池监控
	 * @return
	 */
	@RequestMapping(value = "threadPoolMonitor", method = RequestMethod.GET)
	public ResponseJson threadPoolMonitor(){
		
		ResponseJson responseJson = new ResponseJson();
		
		Map<String, String> restMap = threadPoolUtils.getThreadPoolMonitor();
		responseJson.setData(restMap);
		return responseJson;
	}
}
