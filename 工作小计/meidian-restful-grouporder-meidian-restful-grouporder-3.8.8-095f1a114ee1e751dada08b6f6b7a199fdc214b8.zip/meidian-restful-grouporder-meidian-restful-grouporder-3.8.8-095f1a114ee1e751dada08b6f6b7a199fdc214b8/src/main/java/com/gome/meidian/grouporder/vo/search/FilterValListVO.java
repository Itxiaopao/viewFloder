package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;
import java.util.List;

public class FilterValListVO implements Serializable{
	private static final long serialVersionUID = 4447721029263534337L;
    private List<FilterValVo> filterValList;
	public List<FilterValVo> getFilterValList() {
		return filterValList;
	}
	public void setFilterValList(List<FilterValVo> filterValList) {
		this.filterValList = filterValList;
	}
    
}
