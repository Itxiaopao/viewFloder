package com.gome.meidian.grouporder.vo.carveUp.carveUpInfo;

import java.io.Serializable;
import java.util.List;

import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;

public class MyCarveUpGroupVo implements Serializable {

	private static final long serialVersionUID = -2609130664696420396L;
	private Long id;
	private Long carveId;
	private Long headerUserId;
	private String image;
	private String nickName;
	
//	private Integer status; //瓜分团状态： 0：初始值；1：已开始；2：已结束
//	private Integer carveGroupType; //瓜分团类型：1：基础团，2：排名团--奖励定额，3：排名团--奖励瓜分
//	private Integer isReward;//团是否获得排名额外奖励 0 未获得  1 已获得
	private Integer groupFinalSort;//团当前排名
	
//	private Integer currentMemberNum; //当前成员人数
	private Integer isSucess; //是否达标 0 未达标  1 已达标（判断条件--新人数达到标准且总人数达到标准）
//	private List<GroupUserInfo> memberList;//团成员列表

	private Integer oldUserNum; //老用户参与团人数
	private Integer newUserNum; //新用户参与团人数
	private Integer carveBaseNum; //达标人数',--团
	private Integer carveMinNewNum; //最低新用户人数
	
	private Integer needNewNum; //还需新人助力数
	private Integer needTotalNum; //还需总助力数
	
	private Integer userNum;//距离上一名/下一名差几人
	private Integer userFlag;//需要的是新客还是老客  0:老人 、1：新人
	

	private Integer rankingNum;//榜单排名数（已有多少个团进入排行）
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCarveId() {
		return carveId;
	}
	public void setCarveId(Long carveId) {
		this.carveId = carveId;
	}
	public Long getHeaderUserId() {
		return headerUserId;
	}
	public void setHeaderUserId(Long headerUserId) {
		this.headerUserId = headerUserId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
//	public Integer getStatus() {
//		return status;
//	}
//	public void setStatus(Integer status) {
//		this.status = status;
//	}
//	public Integer getCarveGroupType() {
//		return carveGroupType;
//	}
//	public void setCarveGroupType(Integer carveGroupType) {
//		this.carveGroupType = carveGroupType;
//	}
//	public Integer getIsReward() {
//		return isReward;
//	}
//	public void setIsReward(Integer isReward) {
//		this.isReward = isReward;
//	}
	public Integer getGroupFinalSort() {
		return groupFinalSort;
	}
	public void setGroupFinalSort(Integer groupFinalSort) {
		this.groupFinalSort = groupFinalSort;
	}
//	public Integer getCurrentMemberNum() {
//		return currentMemberNum;
//	}
//	public void setCurrentMemberNum(Integer currentMemberNum) {
//		this.currentMemberNum = currentMemberNum;
//	}
	public Integer getIsSucess() {
		return isSucess;
	}
	public void setIsSucess(Integer isSucess) {
		this.isSucess = isSucess;
	}
//	public List<GroupUserInfo> getMemberList() {
//		return memberList;
//	}
//	public void setMemberList(List<GroupUserInfo> memberList) {
//		this.memberList = memberList;
//	}
	public Integer getUserNum() {
		return userNum;
	}
	public void setUserNum(Integer userNum) {
		this.userNum = userNum;
	}
	public Integer getUserFlag() {
		return userFlag;
	}
	public void setUserFlag(Integer userFlag) {
		this.userFlag = userFlag;
	}
	public Integer getOldUserNum() {
		return oldUserNum;
	}
	public void setOldUserNum(Integer oldUserNum) {
		this.oldUserNum = oldUserNum;
	}
	public Integer getNewUserNum() {
		return newUserNum;
	}
	public void setNewUserNum(Integer newUserNum) {
		this.newUserNum = newUserNum;
	}
	public Integer getCarveBaseNum() {
		return carveBaseNum;
	}
	public void setCarveBaseNum(Integer carveBaseNum) {
		this.carveBaseNum = carveBaseNum;
	}
	public Integer getCarveMinNewNum() {
		return carveMinNewNum;
	}
	public void setCarveMinNewNum(Integer carveMinNewNum) {
		this.carveMinNewNum = carveMinNewNum;
	}
	public Integer getNeedNewNum() {
		return needNewNum;
	}
	public void setNeedNewNum(Integer needNewNum) {
		this.needNewNum = needNewNum;
	}
	public Integer getNeedTotalNum() {
		return needTotalNum;
	}
	public void setNeedTotalNum(Integer needTotalNum) {
		this.needTotalNum = needTotalNum;
	}
	public Integer getRankingNum() {
		return rankingNum;
	}
	public void setRankingNum(Integer rankingNum) {
		this.rankingNum = rankingNum;
	}
	
	
}
