package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class TaskShopVo implements Serializable {

	private static final long serialVersionUID = -1834009322493240748L;
	
	@NotNull(message = "{shop.task.info.taskId.notNull}")
	private Long taskId;
	@NotNull(message = "{shop.task.user.userId.notNull}")
	private Long userId;
	
	public Long getTaskId() {
		return taskId;
	}
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
