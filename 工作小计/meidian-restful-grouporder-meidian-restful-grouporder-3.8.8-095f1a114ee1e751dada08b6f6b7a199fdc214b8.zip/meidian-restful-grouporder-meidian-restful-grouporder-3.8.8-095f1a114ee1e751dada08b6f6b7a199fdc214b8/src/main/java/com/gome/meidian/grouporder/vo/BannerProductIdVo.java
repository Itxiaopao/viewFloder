package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 618
 * 数字门店首页默认显示
 * @author shichangjian
 *
 */
public class BannerProductIdVo implements Serializable{

	private static final long serialVersionUID = 3131260670435004739L;
	
	private List<BannerImage> bannerImages;
	private List<ProductIdActivityIdVo> productIdActivityIdVos;
	
	public List<BannerImage> getBannerImages() {
		return bannerImages;
	}
	public void setBannerImages(List<BannerImage> bannerImages) {
		this.bannerImages = bannerImages;
	}
	public List<ProductIdActivityIdVo> getProductIdActivityIdVos() {
		return productIdActivityIdVos;
	}
	public void setProductIdActivityIdVos(List<ProductIdActivityIdVo> productIdActivityIdVos) {
		this.productIdActivityIdVos = productIdActivityIdVos;
	}
	
	

}
