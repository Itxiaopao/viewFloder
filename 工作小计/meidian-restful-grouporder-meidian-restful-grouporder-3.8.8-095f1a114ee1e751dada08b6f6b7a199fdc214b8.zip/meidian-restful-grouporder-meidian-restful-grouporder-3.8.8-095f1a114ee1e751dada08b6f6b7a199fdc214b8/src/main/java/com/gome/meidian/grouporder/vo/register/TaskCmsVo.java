package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class TaskCmsVo implements Serializable {

	private static final long serialVersionUID = 3350373967151548913L;
	
	@NotBlank(message = "{shop.task.cms.pageCode.notBlank}")
	private String pageCode;//test:P534334062735654912
	@NotBlank(message = "{shop.task.cms.mshopCode.notBlank}")
	private String mshopCode;//0
	@NotNull(message = "{shop.task.cms.portType.notNull}")
	private Integer portType;//wap:1
	@NotNull(message = "{shop.task.cms.pageNo.notNull}")
	private Long pageNo;
	@NotNull(message = "{shop.task.cms.pageSize.notNull}")
	private Long pageSize;
	@NotNull(message = "{shop.task.user.userId.notNull}")
	private Long userId;
	
	public String getPageCode() {
		return pageCode;
	}
	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}
	public String getMshopCode() {
		return mshopCode;
	}
	public void setMshopCode(String mshopCode) {
		this.mshopCode = mshopCode;
	}
	public Integer getPortType() {
		return portType;
	}
	public void setPortType(Integer portType) {
		this.portType = portType;
	}
	public Long getPageNo() {
		return pageNo;
	}
	public void setPageNo(Long pageNo) {
		this.pageNo = pageNo;
	}
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
}
