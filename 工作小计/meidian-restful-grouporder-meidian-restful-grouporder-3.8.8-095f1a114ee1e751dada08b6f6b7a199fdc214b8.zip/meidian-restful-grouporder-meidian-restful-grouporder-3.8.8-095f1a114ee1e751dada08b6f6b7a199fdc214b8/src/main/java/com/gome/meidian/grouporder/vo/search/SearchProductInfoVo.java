package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.grouporderVo.HomePageActivity;

public class SearchProductInfoVo implements Serializable{
	private static final long serialVersionUID = -289755212728468304L;
	private String productType;//活动类型1：组团 2 ：超级返3：主站商品
	private String goodsName;
	private String goodsId;
	private String productImgURL;
	private String skuID;
	private String skuNo;
	private String shopId;
	private Integer productTag;
	private String salePrice;
	private Integer status;
	private String buyRebate;
	private String meidianPrice;
	private String priceKey;
	private HomePageActivity homePageActivity;
	private String rebate;
	private String unit;
	private int stock;
	
	
	private Integer helpMinTotalNum;// 助力最低总人数
	private Integer helpMinNewNum;// 助力最低新用户人数
	private String attendFixMoney; //参与者每人固定国美币（元）
	private String initialFixMoney; //开团者返利国美币（元）
	private Integer helpAllow; //是否允许助力 0:不允许,1:允许 （默认0）
	
	private int presale;//1:预售 2:盲售  默认0
		
	private String deposit;//定金
	
    /**
     * 定金翻倍定金抵扣金额(定金+资源金额)
     */
    private String deductibleDeposit;

    /**
     * 是否定金膨胀 0否1是
     */
    private String depositExpand;
    
    private String priceType;	// 价格类型


	
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public String getGoodsId() {
		return goodsId;
	}
	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}
	public String getProductImgURL() {
		return productImgURL;
	}
	public void setProductImgURL(String productImgURL) {
		this.productImgURL = productImgURL;
	}
	public String getSkuID() {
		return skuID;
	}
	public void setSkuID(String skuID) {
		this.skuID = skuID;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public Integer getProductTag() {
		return productTag;
	}
	public void setProductTag(Integer productTag) {
		this.productTag = productTag;
	}

	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getBuyRebate() {
		return buyRebate;
	}
	public void setBuyRebate(String buyRebate) {
		this.buyRebate = buyRebate;
	}
	public String getMeidianPrice() {
		return meidianPrice;
	}
	public void setMeidianPrice(String meidianPrice) {
		this.meidianPrice = meidianPrice;
	}
	public String getPriceKey() {
		return priceKey;
	}
	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}
	public HomePageActivity getHomePageActivity() {
		return homePageActivity;
	}
	public void setHomePageActivity(HomePageActivity homePageActivity) {
		this.homePageActivity = homePageActivity;
	}
	public String getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(String salePrice) {
		this.salePrice = salePrice;
	}
	public String getRebate() {
		return rebate;
	}
	public void setRebate(String rebate) {
		this.rebate = rebate;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public Integer getHelpMinTotalNum() {
		return helpMinTotalNum;
	}
	public void setHelpMinTotalNum(Integer helpMinTotalNum) {
		this.helpMinTotalNum = helpMinTotalNum;
	}
	public Integer getHelpMinNewNum() {
		return helpMinNewNum;
	}
	public void setHelpMinNewNum(Integer helpMinNewNum) {
		this.helpMinNewNum = helpMinNewNum;
	}
	public String getAttendFixMoney() {
		return attendFixMoney;
	}
	public void setAttendFixMoney(String attendFixMoney) {
		this.attendFixMoney = attendFixMoney;
	}
	public String getInitialFixMoney() {
		return initialFixMoney;
	}
	public void setInitialFixMoney(String initialFixMoney) {
		this.initialFixMoney = initialFixMoney;
	}
	public Integer getHelpAllow() {
		return helpAllow;
	}
	public void setHelpAllow(Integer helpAllow) {
		this.helpAllow = helpAllow;
	}
	public int getPresale() {
		return presale;
	}
	public void setPresale(int presale) {
		this.presale = presale;
	}

	public String getDeductibleDeposit() {
		return deductibleDeposit;
	}
	public void setDeductibleDeposit(String deductibleDeposit) {
		this.deductibleDeposit = deductibleDeposit;
	}
	public String getDepositExpand() {
		return depositExpand;
	}
	public void setDepositExpand(String depositExpand) {
		this.depositExpand = depositExpand;
	}
	public String getDeposit() {
		return deposit;
	}
	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}
	
	

	

}
