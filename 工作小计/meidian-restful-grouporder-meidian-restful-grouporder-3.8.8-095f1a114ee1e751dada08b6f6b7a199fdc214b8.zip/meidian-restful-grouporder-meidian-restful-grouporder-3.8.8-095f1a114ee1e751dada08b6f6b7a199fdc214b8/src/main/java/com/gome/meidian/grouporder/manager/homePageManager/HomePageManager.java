package com.gome.meidian.grouporder.manager.homePageManager;

import com.alibaba.fastjson.JSONObject;
import com.gome.appraise.meidian.model.MeidianGoodsAppraise;
import com.gome.appraise.meidian.service.IMeidianGoodsAppraiseQueryService;
import com.gome.appraise.meidian.service.IMeidianGoodsAppraiseWriteService;
import com.gome.appraise.report.model.common.PJPage;
import com.gome.coupon.model.cartBean.CouponBatchResult;
import com.gome.frontSe.interfaces.IProdDetailService;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.AdvanceSaleManager;
import com.gome.meidian.grouporder.manager.CarveUpManager;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.utils.CouponEncryptionUtil;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.ProductDetailVo;
import com.gome.meidian.grouporder.vo.ProductVo;
import com.gome.meidian.grouporder.vo.advanceSale.GomePromPresellVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpActivity.CarveUpActivityInfoVo;
import com.gome.meidian.grouporder.vo.grouporderVo.CommonProductVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReq;
import com.gome.meidian.grouporder.vo.grouporderVo.HomePageActivity;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductCouponReq;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.homePage.*;
import com.gome.meidian.grouporder.vo.meidiancms.HomePageHead;
import com.gome.meidian.grouporder.vo.meidiancms.ImageElement;
import com.gome.meidian.grouporder.vo.meidiancms.Model;
import com.gome.meidian.grouporder.vo.meidiancms.ModelMerge;
import com.gome.meidian.grouporder.vo.meidiancms.ModelVo;
import com.gome.meidian.grouporder.vo.meidiancms.PageProperty;
import com.gome.meidian.grouporder.vo.product.HomeCouponProductRes;
import com.gome.meidian.grouporder.vo.product.ProductInfo;
import com.gome.meidian.grouporder.vo.product.ProductRequestParam;
import com.gome.meidian.grouporder.vo.product.ProductSurveyInfoVo;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebate;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;
import com.gome.meidian.product.entity.ProductBaseInfo;
import com.gome.meidian.product.entity.ProductInteractionInfo;
import com.gome.meidian.product.entity.ProductUserCollection;
import com.gome.meidian.product.entity.ProductUserLike;
import com.gome.meidian.product.manager.IProductBaseInfoManager;
import com.gome.meidian.product.manager.IProductInteractionInfoManager;
import com.gome.meidian.product.manager.IProductUserCollectionManager;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.memberCore.lang.MapResult;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gome.qiantai.model.ResultMsg;
import com.gome.stage.interfaces.item.ISkuEnergyAllowanceService;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.cms2.enums.CmsItemType;
import com.gomeplus.bs.interfaces.cms2.enums.CmsPortType;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.*;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.module.Modules;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.BasePageI;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.IndexPageMshopMI;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.PageIndexI;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.PageSecondI;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.SecondPageMI;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.GroupInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductManagementVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductSaleWrapNumVo;

import redis.Gcache;

import org.apache.http.client.methods.HttpGet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.annotation.Resource;


/**
 * APP首页接口
 */
@Service
public class HomePageManager {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private PageInfoResource pageInfoResource;

    @Autowired
    private GorderInfoForAppNewResource gorderInfoForAppNewResource;

    @Value("${gome.defaultAreaCode}")
    private String defaultAreaCode;    // 默认三级区域，朝阳，全国价
    @Value("${gome.defaultStoreCode}")
    private String defaultStoreCode;    // 默认门店，西坝河
    @Value("${meidian.image.agreement}")
    private String agreement;            // http协议
    @Value("${gome.checkagentUrl}")
    private String checkagentUrl;

    @Autowired
    private HomeProductsManager homeProductsManager;
    @Autowired
    private GroupOrderManager groupOrderManager;
    @Autowired
    private IProductInteractionInfoManager iProductInteractionInfoManager;
    @Autowired
    private IProductUserCollectionManager iProductUserCollectionManager;
    @Autowired
    private IProductBaseInfoManager iProductBaseInfoManager;
    @Autowired
    private IMeidianGoodsAppraiseQueryService iMeidianGoodsAppraiseQueryService;
    @Autowired
    private IMeidianGoodsAppraiseWriteService iMeidianGoodsAppraiseWriteService;
    @Autowired
    private IUserInfoFacade iUserInfoFacade;
    @Autowired
    private IProdDetailService prodDetailService;
    @Autowired
    private HttpClientUtil httpClientUtil;
    @Autowired
    private CarveUpManager carveUpManager;
	@Autowired
	private AdvanceSaleManager advanceSaleManager;

    @Resource(name = "gcache")
    private Gcache gcache;
    @Resource(name = "userCenter")
    private Gcache userCenter;


    private final String PRODUCT_USER_COLLECTION_USER_KEY = "product.user.collection.userId.key.";
    private final String PRODUCT_USER_THUMBSUP_USER_KEY = "product.user.like.userId.key.";
    private final String PRODUCT_BASE_KEY = "product.base.key.";

    /**
     * 查询首页详情信息
     *
     * @param storeCode
     * @param pageCode
     * @param areaCode
     * @return
     */
    public HomePageVo getHomePageDetailInfo(String storeCode, String pageCode, String areaCode, int channel) {
        HomePageVo homePageVo = new HomePageVo();

        // 美店cms把ios，android合并了
        if (channel == GroupOrderConstants.MEIDIAN_CMS_IOS_APP) channel = 3;

        IndexPageMshopMI indexPageMshopMI = new IndexPageMshopMI();
        try {
            indexPageMshopMI = pageInfoResource.getIndexPageMshopMI(pageCode, storeCode, channel);
            BeanUtils.copyProperties(indexPageMshopMI, homePageVo);
        } catch (Exception e) {
            logger.error("HomePageManager.getHomePageDetailInfo.error ==> storeCode:{} pageCode:{} protType:{} , e:{}", storeCode, pageCode, GroupOrderConstants.MEIDIAN_CMS_ANDROID_APP, e);
            e.printStackTrace();
        }
        return homePageVo;
    }

    /**
     * 首页
     *
     * @param storeCode
     * @param areaCode
     * @param channel
     * @param ua
     * @param ppi
     * @param userId
     * @return
     * @throws ServiceException
     */
    public Model getHome(String storeCode, String areaCode, int channel, Byte ua, Integer ppi, Long userId) throws ServiceException {
        // 美店cms把ios，android合并了
        if (channel == GroupOrderConstants.MEIDIAN_CMS_IOS_APP) channel = 3;

        String keyId = "meidianCMSHome_" + storeCode + "_" + channel;
        PageIndexI pageIndexI = JSONObject.parseObject(gcache.get(keyId), PageIndexI.class);
        if (null == pageIndexI) {
            pageIndexI = pageInfoResource.getPageIndexI(storeCode, channel);
            gcache.setex(keyId, 30, JSONUtils.toJSONString(pageIndexI).getBytes());
        }
        List<PageHeadMenu> pageHeadMenus = pageIndexI.getHeadMenuList();
        if (null == pageHeadMenus || pageHeadMenus.size() == 0) return null;
        List<HomePageHead> homePageHeads = new ArrayList<HomePageHead>();
        pageHeadMenus.forEach(pageHead -> {
            HomePageHead homePageHead = new HomePageHead(pageHead.getBsCode(), pageHead.getHeadName(), pageHead.getPageCode());
            homePageHeads.add(homePageHead);
        });

        Model model = this.cmsInfo(pageIndexI.getBasePage(), userId, storeCode,
                homePageHeads.get(0).getPageCode(), areaCode, null, channel,
                ua, ppi);

        model.setHomePageHeads(homePageHeads);
        return model;
    }


    /**
     * 获取二级页面信息
     *
     * @param storeCode
     * @param pageCode
     * @param areaCode
     * @return
     */
    public SecondPageVo getSecondDetailInfo(String storeCode, String pageCode, String areaCode) {
        SecondPageVo secondPageVo = new SecondPageVo();
        SecondPageMI secondPageMI = new SecondPageMI();
        try {
            secondPageMI = pageInfoResource.getSecondPageMI(pageCode, storeCode, GroupOrderConstants.MEIDIAN_CMS_ANDROID_APP);
            BeanUtils.copyProperties(secondPageMI, secondPageVo);
        } catch (Exception e) {
            logger.error("HomePageManager.getHomePageDetailInfo.error ==> storeCode:{} pageCode:{} protType:{} , e:{}", storeCode, pageCode, GroupOrderConstants.MEIDIAN_CMS_ANDROID_APP, e);
            e.printStackTrace();
        }
        return secondPageVo;
    }

    /**
     * 美店cms活动页
     *
     * @param storeCode
     * @param pageCode
     * @param areaCode
     * @param channel
     * @param ua
     * @param ppi
     * @return
     * @throws ServiceException
     */
    public Model getActivityPageInfo(Long userId, String storeCode, String pageCode, String areaCode, String townCode, int channel, Byte ua, Integer ppi) throws ServiceException {
        // 美店cms把ios，android合并了
        if (channel == GroupOrderConstants.MEIDIAN_CMS_IOS_APP) channel = 3;
        String keyId = "meidianCMSActivityPage_" + pageCode + "_" + storeCode + "_" + channel;
        PageSecondI pageSecondI = JSONObject.parseObject(gcache.get(keyId), PageSecondI.class);
        if (null == pageSecondI) {
            pageSecondI = pageInfoResource.getPageSecondI(pageCode, storeCode, channel);
            gcache.setex(keyId, 2, JSONUtils.toJSONString(pageSecondI).getBytes());
        }
        Model model = this.cmsInfo(pageSecondI.getBasePage(), userId, storeCode,
                pageCode, areaCode, townCode, channel,
                ua, ppi);
        return model;
    }

    public List<ThousandGroup> getWanrenGroupListByPage(String storeCode, String moduleCode, String pageCode, Long pageNo, Long pageSize, Long userId, String areaCode, Integer ppi, Byte ua) throws ServiceException {
        List<ZutuanSoci> sociList = pageInfoResource.moduleZutuanSociList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        if (null == sociList || sociList.size() == 0) return null;
        return this.getWanrenGroupList(sociList, userId, areaCode, null, storeCode, ppi, ua);
    }

    public List<ThousandGroup> getWanrenGroupList(List<ZutuanSoci> sociList, Long userId, String areaCode, String orgCode, String storeCode, Integer ppi, Byte ua) throws ServiceException {
        List<ThousandGroup> thousandGroups = new ArrayList<ThousandGroup>();

        for (ZutuanSoci soci : sociList) {
            ThousandGroup thousandGroup = new ThousandGroup();
            thousandGroup.setGroupId(soci.getGroupId());

            WanrenProductDetailVo wanren = this.groupDetail(userId, soci.getProductId(), soci.getSkuId(), Long.valueOf(soci.getActivityCode()), soci.getGroupId(), soci.getExpanded1(),areaCode, orgCode, storeCode, ppi, ua);
            WanrenProductVo wProVo = (WanrenProductVo) wanren.getProduct();

            // 用户头像
            if (null != wanren.getGroupInfo()) {
                thousandGroup.setGroupUser(wanren.getGroupInfo().getGroupUser());
                // 已团人数
                thousandGroup.setCurrentMemberNum(wanren.getGroupInfo().getCurrentMemberNum());
            }

            // 分享，点赞
            CollectionProductInfoVo collectionProductInfoVo = wanren.getCollInfo();
            thousandGroup.setCollectionProductInfoVo(collectionProductInfoVo);
            thousandGroup.setWanrenProductVo(wProVo);

            long currentTime = System.currentTimeMillis();
            //已开团
            if (null != wanren.getGroupInfo()) {
                if (null != wanren.getGroupInfo().getId() && wanren.getGroupInfo().getStartTime().getTime() < currentTime && currentTime < wanren.getGroupInfo().getEndTime().getTime()) {
                    // 距图结束倒计时
                    long groupCountdown = wProVo.getEffectiveEndTime().getTime() - currentTime;
                    if (groupCountdown <= 0)
                        groupCountdown = 0;

                    thousandGroup.setEndCountdown(groupCountdown);
                    thousandGroups.add(thousandGroup);
                } else if (null == wanren.getGroupInfo().getId()) {
                	String expanded1 = soci.getExpanded1();
                	//如果扩展字段里以助力团code结尾，将其视作未开团处理
                	if((null != expanded1 && expanded1.endsWith("213")) || wanren.getGroupInfo().getStartTime().getTime() > currentTime) {
                        //即将开团
                        // 距开团倒计时
                        long startCountdown = wProVo.getEffectiveStartTime().getTime() - currentTime;
                        thousandGroup.setStartCountdown(startCountdown);
                        thousandGroups.add(thousandGroup);
                	}
                }
            }
        }

        return thousandGroups;
    }

    /**
     * 查询组团列表
     *
     * @param storeCode
     * @param pageCode
     * @param moduleCode
     * @param areaCode
     * @param pageNo
     * @param pageSize
     * @return
     */
    public List<ZutuanCmsVo> getMenuGroupInfoList(String storeCode, String pageCode, String moduleCode, String areaCode, Long pageNo, Long pageSize) {

        List<Zutuan> moduleZutuanList = null;
        try {
            moduleZutuanList = pageInfoResource.moduleZutuanList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        } catch (Exception e) {
            logger.error("HomePageManager.getHomePageMenuGroupInfoList.moduleZutuanList==> storeCode:{} moduleCode:{} pageCode:{} , e:{}", storeCode, moduleCode, pageCode, e);
        }
        List<ZutuanCmsVo> moduleZutuanVoList = new ArrayList<ZutuanCmsVo>();
        if (null != moduleZutuanList && moduleZutuanList.size() > 0) {
            for (Zutuan zutuan : moduleZutuanList) {
                ZutuanCmsVo vo = new ZutuanCmsVo();
                BeanUtils.copyProperties(zutuan, vo);
                vo.setActivityId(zutuan.getActivityCode());
                moduleZutuanVoList.add(vo);
            }

        }
        return moduleZutuanVoList;
    }


    /**
     * 查询超级返(分享返, 购买返)列表
     *
     * @param storeCode
     * @param pageCode
     * @param moduleCode
     * @param areaCode
     * @param pageNo
     * @param pageSize
     * @return
     */
    public List<RebateCmsVo> getMenuRebateInfoList(String storeCode, String pageCode, String moduleCode, String areaCode, Long pageNo, Long pageSize) {

        List<Cashback> moduleCashbackList = null;
        try {
            moduleCashbackList = pageInfoResource.moduleCashbackList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        } catch (Exception e) {
            logger.error("HomePageManager.getHomePageMenuRebateInfoList.moduleCashbackList==> storeCode:{} moduleCode:{} pageCode:{} , e:{}", storeCode, moduleCode, pageCode, e);
        }

        List<RebateCmsVo> moduleRebateVoList = new ArrayList<RebateCmsVo>();
        if (null != moduleCashbackList && moduleCashbackList.size() > 0) {
            for (Cashback cashback : moduleCashbackList) {
                RebateCmsVo vo = new RebateCmsVo();
                BeanUtils.copyProperties(cashback, vo);
                moduleRebateVoList.add(vo);
            }

        }
        return moduleRebateVoList;
    }

    /**
     * 超级返
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param ppi
     * @param pageSize
     * @param pageNo
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ProductBuyRebateVo> getRebateDetailInfoList(String pageCode, String storeCode, String areaCode, String moduleCode, Integer ppi, Long pageSize, Long pageNo, Byte ua, String policyId) throws ServiceException {
        //从CMS获取超级返ID列表
        List<RebateCmsVo> cmsVos = this.getMenuRebateInfoList(storeCode, pageCode, moduleCode, areaCode, pageNo, pageSize);

        //组装数据
        List<ProductBuyRebate> pList = new ArrayList<>();
        List<ProductBuyRebateVo> result = null;
        if (null != cmsVos && cmsVos.size() > 0) {
            ProductBuyRebate rebateVo = null;
            for (RebateCmsVo vo : cmsVos) {
                rebateVo = new ProductBuyRebate(vo.getProductId(), vo.getSkuNo(), vo.getSkuId());
                pList.add(rebateVo);
            }


            if (null == areaCode || areaCode.equalsIgnoreCase("") || "0".equals(areaCode)) areaCode = defaultAreaCode;

            //获取超级返列表信息
            result = homeProductsManager.getProductBuyRebates(pList, areaCode, ppi, ua, storeCode, policyId);
        }

        return result;
    }

    /**
     * 我要卖活动页各模块商品详情
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param ppi
     * @param pageSize
     * @param pageNo
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ProductSurveyInfoVo> getProductDetailInfoList(String pageCode, String storeCode, String areaCode, String moduleCode, Integer ppi, Long pageSize, Long pageNo, Byte ua) throws ServiceException {

        List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> moduleProductList = null;
        try {
            moduleProductList = this.pageInfoResource.moduleProductList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        } catch (Exception e) {
            logger.error("HomePageManager.getProductInfoList.moduleProductList==> storeCode:{} moduleCode:{} pageCode:{} , e:{}", storeCode, moduleCode, pageCode, e);
        }
        List<ProductSurveyInfoVo> productSurveyInfoVoList = null;
        productSurveyInfoVoList = this.getProductSurveyDetailInfo(moduleProductList, areaCode, ppi, ua, storeCode);
        return productSurveyInfoVoList;
    }

    /**
     * 获取热度调研详情信息
     * @param moduleProductList
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ProductSurveyInfoVo> getProductSurveyDetailInfo(List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> moduleProductList, String areaCode, Integer ppi, Byte ua, String storeCode) throws ServiceException{
        //查询热度调研的商品信息
        List<ProductSurveyInfoVo> productSurveyInfoVoList = new ArrayList<>();
        List<ProductRequestParam> productRequestParams = new ArrayList<>();
        Map<String, String> maps = new HashMap<>();
        if (null != moduleProductList && moduleProductList.size() > 0) {
            for (com.gomeplus.bs.interfaces.cms2.vo.business.base.Product product : moduleProductList) {
                if (null == product) continue;
                String key = product.getProductId() + product.getSkuId();
                maps.put(key, product.getExpanded1());
                ProductRequestParam requestParam = new ProductRequestParam(product.getProductId(),product.getSkuId());
                productRequestParams.add(requestParam);
            }
        }
        //查询商品信息
        List<com.gome.meidian.grouporder.vo.Product> productList = groupOrderManager.getPros(productRequestParams, areaCode, ppi, GroupOrderConstants.TWO_LIST_PRODUCT_IMAGE, ua, storeCode, GroupOrderConstants.PRICE_POLICYID, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
        if (null != productList && productList.size() > 0) {
            for (com.gome.meidian.grouporder.vo.Product product : productList) {
                ProductSurveyInfoVo productInfoVo = new ProductSurveyInfoVo();
                if (product == null) continue;
                String key = product.getId() + product.getSkuId();
                productInfoVo.setExpanded1(maps.get(key));
                productInfoVo.setProduct(product);
                productSurveyInfoVoList.add(productInfoVo);
            }
        }
        return productSurveyInfoVoList;
    }


    /**
     * 查询劵信息id集合
     *
     * @param storeCode
     * @param pageCode
     * @param moduleCode
     * @param areaCode
     * @param pageNo
     * @param pageSize
     * @return
     */
    public List<CouponCmsVo> getMenuCouponInfoList(String storeCode, String pageCode, String moduleCode, String areaCode, Long pageNo, Long pageSize) {

        List<CouponRule> moduleCouponList = null;
        try {
            moduleCouponList = pageInfoResource.moduleCouponList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        } catch (Exception e) {
            logger.error("HomePageManager.getMenuCouponInfoList.moduleCouponList==> storeCode:{} moduleCode:{} pageCode:{} , e:{}", storeCode, moduleCode, pageCode, e);
        }

        List<CouponCmsVo> moduleCouponVoList = new ArrayList<CouponCmsVo>();
        if (null != moduleCouponList && moduleCouponList.size() > 0) {
            for (CouponRule cashback : moduleCouponList) {
                CouponCmsVo vo = new CouponCmsVo();
                BeanUtils.copyProperties(cashback, vo);
                moduleCouponVoList.add(vo);
            }

        }
        return moduleCouponVoList;
    }

    /**
     * 立减商品信息集合
     *
     * @param pageCode
     * @param storeCode
     * @param moduleCode
     * @param areaCode
     * @param ppi
     * @param pageSize
     * @param pageNo
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<HomeCouponProductRes> getCouponDetailInfoList(String pageCode, String storeCode, String moduleCode, String areaCode, Integer ppi, Long pageSize, Long pageNo, Byte ua, String policyId) throws ServiceException {
        //从CMS获取立减商品ID列表
        List<CouponCmsVo> cmsVos = this.getMenuCouponInfoList(storeCode, pageCode, moduleCode, areaCode, pageNo, pageSize);

        //组装数据
        List<ProductCouponReq> cList = new ArrayList<>();
        Map<String, CouponCmsVo> cmsMap = new HashMap<>();
        List<HomeCouponProductRes> result = null;
        if (null != cmsVos && cmsVos.size() > 0) {
            ProductCouponReq couponVo = null;
            for (CouponCmsVo vo : cmsVos) {
                couponVo = new ProductCouponReq(vo.getProductId(), vo.getSkuId());
                cList.add(couponVo);
                cmsMap.put(vo.getSkuId(), vo);
            }


            if (null == areaCode || areaCode.equalsIgnoreCase("") || "0".equals(areaCode)) areaCode = defaultAreaCode;
            //获取立减商品列表信息
            result = homeProductsManager.getHomeProductCoupons(cList, areaCode, ppi, ua, storeCode, policyId);

            //将配置的券信息放入列表
            if (null != result && result.size() > 0) {
                CouponCmsVo cVo = null;
                for (HomeCouponProductRes res : result) {
                    cVo = cmsMap.get(res.getProduct().getSkuId());
                    if (null != cVo) {
                        res.getProduct().setSkuNo(cVo.getSkuNo());
                        res.setCouponCmsVo(cVo);
                    }
                }
            }
        }


        return result;
    }

    /**
     * 查询组团详情列表
     *
     * @param storeCode
     * @param pageCode
     * @param moduleCode
     * @param areaCode
     * @param pageNo
     * @param pageSize
     * @return
     */
    public List<ProductGroupInfoVo> getGroupDetailInfoList(String storeCode, String pageCode, String moduleCode, String areaCode, Long pageNo, Long pageSize, Integer ppi, Byte ua) throws ServiceException {
        //1.查询cms ids详情
        List<Zutuan> moduleZutuanIdList = null;
        try {
            moduleZutuanIdList = pageInfoResource.moduleZutuanList(storeCode, moduleCode, pageCode, pageNo, pageSize);
        } catch (Exception e) {
            logger.error("HomePageManager.getHomePageMenuGroupInfoList.moduleZutuanList==> storeCode:{} moduleCode:{} pageCode:{} , e:{}", storeCode, moduleCode, pageCode, e);
        }

        //2.查询组团详情
        List<GroupInfoReq> groupInfoReqs = new ArrayList<GroupInfoReq>();
        Map<String, String> productIdAndSkuNoMap = new HashMap<String, String>();
        Map<String, Long> groupIdMap = new HashMap<String, Long>();
        List<String> productIdList = new ArrayList<String>();

        if (null != moduleZutuanIdList && moduleZutuanIdList.size() > 0) {

            for (Zutuan zu : moduleZutuanIdList) {
                GroupInfoReq groupInfoReq = new GroupInfoReq();
                String actiqvityCode = zu.getActivityCode();
                if (null != actiqvityCode) {
                    Long activityId = Long.parseLong(actiqvityCode);
                    groupInfoReq.setActivityId(activityId);
                    groupInfoReq.setSkuId(zu.getSkuId());
                    groupInfoReq.setProductId(zu.getProductId());
                    productIdList.add(zu.getProductId());
                    productIdAndSkuNoMap.put(zu.getSkuId(), zu.getSkuNo());
                    if (null != zu.getGroupId())
                        groupIdMap.put(zu.getSkuId(), zu.getGroupId());

                    groupInfoReqs.add(groupInfoReq);
                }

            }

        }
        if (null == areaCode || areaCode.equalsIgnoreCase("") || "0".equals(areaCode)) areaCode = defaultAreaCode;
        List<ProductGroupInfoVo> productGroupInfoVos = homeProductsManager.groupInfo(groupInfoReqs, areaCode, ppi, ua, storeCode);
        //3.已团人数
        Map<String, Integer> productIdAndToalBuyMap = getProductBuyNum(productIdList);

        if (null != productGroupInfoVos && productGroupInfoVos.size() > 0) {
            for (ProductGroupInfoVo productGroupInfoVo : productGroupInfoVos) {
                ProductInfo productInfo = productGroupInfoVo.getProductInfo();
                String productId = productInfo.getProductId();
                if (null != productId) {
                    //填充skuNo
                    String skuNO = productIdAndSkuNoMap.get(productInfo.getSkuId());
                    if (null != skuNO) {
                        productInfo.setSkuNo(skuNO);
                    } else {
                        productInfo.setSkuNo("");
                    }

                    //填充已团件数
                    HomePageActivity homePageActivity = productGroupInfoVo.getHomePageActivity();
                    Integer buyNum = productIdAndToalBuyMap.get(productId);
                    if (null != buyNum)
                        homePageActivity.setTotalBuyNum(buyNum * homePageActivity.getIrrigationNumber());

                    if (groupIdMap.containsKey(productInfo.getSkuId()))
                        homePageActivity.setGroupId(groupIdMap.get(productInfo.getSkuId()));
                }
            }
        }

        return productGroupInfoVos;
    }


    /**
     * 查询商品已团人数
     *
     * @param productIds
     * @return
     * @throws ServiceException
     */
    public Map<String, Integer> getProductBuyNum(List<String> productIds) throws ServiceException {
        Map<String, Integer> totalNum = new HashMap<String, Integer>();
        // 获取商品的购买总件数
        CommonResultEntity<List<ProductSaleWrapNumVo>> commonResultEntity = gorderInfoForAppNewResource
                .getProductBuyNumByIds(productIds);
        List<ProductSaleWrapNumVo> productBuyNumVos = commonResultEntity.getBusinessObj();
        if (null != productBuyNumVos && productBuyNumVos.size() > 0) {
            for (ProductSaleWrapNumVo productSaleWrapNumVo : productBuyNumVos) {
                totalNum.put(productSaleWrapNumVo.getProductId(), productSaleWrapNumVo.getProductHistorySaleNum());
            }
        }
        return totalNum;
    }

    /**
     * 处理组团信息
     *
     * @param groups
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ProductGroupInfoVo> getGroupInfo(List<Zutuan> groups, String areaCode, Integer ppi, Byte ua, String storeCode) throws ServiceException {

        List<GroupInfoReq> groupInfoReqs = new ArrayList<GroupInfoReq>();
        Map<String, String> skuNoMap = new HashMap<String, String>();
        Map<String, Long> groupMap = new HashMap<String, Long>();
        List<String> productIds = new ArrayList<String>();

        for (Zutuan group : groups) {
            String skuId = group.getSkuId();
            String productId = group.getProductId();
            GroupInfoReq groupInfoReq = new GroupInfoReq(productId, Long.valueOf(group.getActivityCode()), skuId);
            groupInfoReqs.add(groupInfoReq);

            skuNoMap.put(skuId, group.getSkuNo());
            if (null != group.getGroupId())
                groupMap.put(skuId, group.getGroupId());

            productIds.add(productId);
        }

        List<ProductGroupInfoVo> productGroupInfoVos = homeProductsManager.groupInfo(groupInfoReqs, areaCode, ppi, ua, storeCode);
        // 已团人数
        Map<String, Integer> productIdAndToalBuyMap = this.getProductBuyNum(productIds);

        if (null == productGroupInfoVos) return null;
        productGroupInfoVos.forEach(productGroupInfoVo -> {
            ProductInfo productInfo = productGroupInfoVo.getProductInfo();
            productInfo.setSkuNo(skuNoMap.get(productInfo.getSkuId()));
            
            HomePageActivity homePageActivity = productGroupInfoVo.getHomePageActivity();
            // TODO  暂时由discountRebate兼容initialFixMoney字段值
            if(null == productInfo.getHelpAllow()) {
            	productInfo.setHelpAllow(0);
            }
            if(productInfo.getHelpAllow().intValue() == 1) {
                homePageActivity.setDiscountRebate(productInfo.getInitialFixMoney());
            }
            
            Integer totalBuyNum = productIdAndToalBuyMap.get(productInfo.getProductId());
            if (null != totalBuyNum)
                homePageActivity.setTotalBuyNum(totalBuyNum * homePageActivity.getIrrigationNumber());

            if (groupMap.containsKey(productInfo.getSkuId()))
                homePageActivity.setGroupId(groupMap.get(productInfo.getSkuId()));
        });

        return productGroupInfoVos;
    }

    /**
     * 处理立减商品信息
     *
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<HomeCouponProductRes> getCouponProductInfo(List<CouponRule> couponRules, String areaCode, Integer ppi, Byte ua, String mOrg, String policyId) throws ServiceException {
        //组装数据
        List<ProductCouponReq> productCouponReqs = new ArrayList<ProductCouponReq>();
        Map<String, CouponCmsVo> cmsMap = new HashMap<String, CouponCmsVo>();
        List<HomeCouponProductRes> homeCouponProductRes = null;
        
        for (CouponRule couponRule : couponRules) {
            if (null == couponRule) continue;
            ProductCouponReq couponVo = new ProductCouponReq(couponRule.getProductId(), couponRule.getSkuId());
            productCouponReqs.add(couponVo);
            CouponCmsVo couponCmsVo = new CouponCmsVo();
            BeanUtils.copyProperties(couponRule, couponCmsVo);
            cmsMap.put(couponRule.getSkuId(), couponCmsVo);
        }

        //获取立减商品列表信息
        homeCouponProductRes = homeProductsManager.getHomeProductCoupons(productCouponReqs, areaCode, ppi, ua, mOrg, policyId);

        //将配置的券信息放入列表
        if (null != homeCouponProductRes && homeCouponProductRes.size() > 0) {
            CouponCmsVo cVo = null;
            String expandString = null;
            String skuId = null;
            for (HomeCouponProductRes res : homeCouponProductRes) {
            	skuId = res.getProduct().getSkuId();
                cVo = cmsMap.get(skuId);
                if (null != cVo) {
                    res.getProduct().setSkuNo(cVo.getSkuNo());
                    res.setCouponCmsVo(cVo);
                }
                
//                if(expandMap.containsKey(skuId)) {
//                	expandString = expandMap.get(skuId);
//                	if(StringUtils.isNotBlank(expandString) && expandString.contains("isPreSale:1")) {
//                    	GomePromPresellVo prese = advanceSaleManager.queryOnePresellInfoByParam(cVo.getSkuNo(), storeCode, res.getProduct().getProductTag() != 1, areaCode, null);
//                    	res.setPreSellFlag(1);
//                    	res.setDeposit(prese.getDeposit());
//                    	res.setPresellPrice(prese.getPresellPrice());
//                    	res.setDepositExpand(prese.getDepositExpand());
//                    	if("1".equals(prese.getDepositExpand())) {
//                    		res.setDeductibleDepositDesc("订金" + res.getDeposit() + "可抵" + res.getPresellPrice());
//                    	}
//                	}
//                }
            }
        }

        return homeCouponProductRes;
    }

    /**
     * 处理超级返商品信息
     *
     * @param buyRes
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ProductBuyRebateVo> getBuyRebateInfo(List<Cashback> buyRes, String areaCode, Integer ppi, Byte ua, String mOrg, String policyId) throws ServiceException {

        // 组装数据
        List<ProductBuyRebate> productBuyRebates = new ArrayList<ProductBuyRebate>();
        List<ProductBuyRebateVo> productBuyRebateVos = null;

        if (null != buyRes && buyRes.size() > 0) {
            for (Cashback cashback : buyRes) {
                ProductBuyRebate rebateVo = new ProductBuyRebate(cashback.getProductId(), cashback.getSkuNo(), cashback.getSkuId());
                productBuyRebates.add(rebateVo);
            }

            // 获取超级返列表信息
            productBuyRebateVos = homeProductsManager.getProductBuyRebates(productBuyRebates, areaCode, ppi, ua, mOrg, policyId);
        }

        return productBuyRebateVos;
    }

    public List<Coupon> getCoupon(List<SimpleCoupon> simpleCoupons) {

        List<Coupon> coupons = new ArrayList<Coupon>();
        for (SimpleCoupon simpleCoupon : simpleCoupons) {
            // 多劵轮播
            // 美劵
            if (String.valueOf(simpleCoupon.getCouponType()).equals(GroupOrderConstants.COUPON_TYPE_CMS_BEAUTY)) {
                CouponRuleInfo couponRuleInfo = groupOrderManager.getCoupon(simpleCoupon.getCouponRuleId());
                if (null != couponRuleInfo) {
                    Coupon coupon = new Coupon();
                    coupon.setCoupon_id(couponRuleInfo.getRuleId());
                    coupon.setCoupon_num(couponRuleInfo.getAmount());
                    coupon.setFullAmount(couponRuleInfo.getLimitAmount() == null ? 0D : couponRuleInfo.getLimitAmount());
                    coupon.setDescription(couponRuleInfo.getDescription());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    coupon.setShow_start_time(sdf.format(couponRuleInfo.getCouponStartDate()));
                    coupon.setShow_end_time(sdf.format(couponRuleInfo.getCouponEndDate()));
                    coupon.setCouponType(couponRuleInfo.getType());
                    coupon.setPlan_id(simpleCoupon.getPlanId());

                    // 美红蓝营销劵加密
                    String id = CouponEncryptionUtil.beautifulCouponEncryption(coupon.getPlan_id(), coupon.getCouponType());
                    coupon.setEncryptionId(id);
                    
                    coupons.add(coupon);
                }
            } else if (String.valueOf(simpleCoupon.getCouponType()).equals(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
                // pop劵
                CouponBatchResult couponBatchResult = groupOrderManager.getPopCoupon(simpleCoupon.getCouponRuleId());
                if (null != couponBatchResult) {
                    Coupon coupon = new Coupon();
                    coupon.setCoupon_num(couponBatchResult.getDenomination());            // 面额
                    coupon.setDescription(couponBatchResult.getDescription());
                    coupon.setFullAmount(couponBatchResult.getLimitPrice());            // 满多少元可用
                    coupon.setCouponType(String.valueOf(couponBatchResult.getType()));    // 0:店铺券, 2:平台券，3：商品劵
                    coupon.setCoupon_id(couponBatchResult.getCode());                    // pop劵批次号
                    coupon.setActiveId(couponBatchResult.getActiveId());                // 领取标识，劵活动id
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    coupon.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
                    coupon.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));

                    // pop劵加密
                    String id = CouponEncryptionUtil.popCouponEncryption(coupon.getCoupon_id(), coupon.getCouponType(), couponBatchResult.getShopNo(), couponBatchResult.getActiveId());
                    coupon.setEncryptionId(id);
                    
                    coupons.add(coupon);
                }
            }
        }

        return coupons;
    }

    public void groupList(String userId, String pageCode, String areaCode, String ppi, Byte ua) {

    }

    /**
     * 热度调研我要卖活动页默认数据详情
     *
     * @param products
     * @param areaCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ProductSurveyInfoVo> getProductSurveyInfo(List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> products, String areaCode, Integer ppi, Byte ua, String storeCode) throws ServiceException {
        List<ProductSurveyInfoVo> productSurveyInfoVoList = null;
        productSurveyInfoVoList=this.getProductSurveyDetailInfo(products,areaCode,ppi,ua, storeCode);
        return productSurveyInfoVoList;
    }


    /**
     * 万人团商详页
     *
     * @param userId
     * @param productId
     * @param skuId
     * @param activityId
     * @param groupId
     * @param areaCode
     * @param orgCode
     * @param ppi
     * @param ua
     */
    public WanrenProductDetailVo groupDetail(Long userId, String productId, String skuId, Long activityId, Long groupId,String expanded1,String areaCode, String orgCode, String storeCode, Integer ppi, Byte ua) throws ServiceException {
        WanrenProductDetailVo vo = new WanrenProductDetailVo();
        //商品服务获取信息
        ProductBaseInfo baseInfo = null;
        String proJson = userCenter.get(PRODUCT_BASE_KEY + productId);

        if (StringUtils.isNotBlank(proJson)) {
            baseInfo = JSONObject.parseObject(proJson, ProductBaseInfo.class);
        } else {
            baseInfo = iProductBaseInfoManager.selectOneByProductId(productId);
        }

        if (null != baseInfo) {
            Map<String, Object> responseMap = groupOrderManager.getProductInfoForWanren(activityId, groupId, userId, productId, skuId, areaCode, orgCode, storeCode, ppi, ua);
            ProductDetailVo detailVo = (ProductDetailVo) responseMap.get("data");
            BeanUtils.copyProperties(detailVo, vo);
            WanrenProductVo wanrenProduct = new WanrenProductVo();
            BeanUtils.copyProperties(detailVo.getProduct(), wanrenProduct);
            // 获取分辨率
            String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);

//    		if(null != baseInfo.getStartTime() && null != baseInfo.getEndTime()){
            if (detailVo.getGroupInfo() != null && null != detailVo.getGroupInfo().getStartTime() && null != detailVo.getGroupInfo().getEndTime()) {
                long currentTime = System.currentTimeMillis();
//        		long startTime = baseInfo.getStartTime().getTime();
//        		long endTime = baseInfo.getEndTime().getTime();
                long startTime = detailVo.getGroupInfo().getStartTime().getTime();
                long endTime = detailVo.getGroupInfo().getEndTime().getTime();
                if (currentTime >= startTime && currentTime <= endTime) {
                    String bgImages = baseInfo.getBackgroundImage();
                    if (StringUtils.isNotBlank(bgImages)) {
                        List<String> images = JSONObject.parseArray(bgImages, String.class);
                        List<String> newImages = new ArrayList<>();
                        for (String str : images) {
                            newImages.add(ImageUtils.imageUrlInfo(str, ratio, ua));
                        }
                        wanrenProduct.setImages(newImages);
                    }

                }
            }

            wanrenProduct.setBgVideo(baseInfo.getBackgroundVideo());
            wanrenProduct.setDesc(baseInfo.getProductDesc());
            wanrenProduct.setBrandId(baseInfo.getBrandId());
            wanrenProduct.setBrandName(baseInfo.getBrandTitile());
            wanrenProduct.setBrandImage(baseInfo.getBrandLogo());
            wanrenProduct.setExpanded1(expanded1); //万人团类型 返回扩展字段
            vo.setProduct(wanrenProduct);
            vo.setCollInfo(this.getShareCollectionAppraiseInfo(userId == null ? null : userId.toString(), productId, skuId, activityId.toString()));
        }
        return vo;
    }


    /**
     * 分享商品，不记录与用户关系
     *
     * @param productId
     */
    public void shareProduct(String productId) {
        iProductInteractionInfoManager.increaseShareNum(productId);
    }

    /**
     * 点赞商品
     *
     * @param userId
     * @param thumbsUpProductVo
     * @throws ServiceException
     */
    public void thumbsUpProduct(String userId, ThumbsUpProductVo thumbsUpProductVo) throws ServiceException {
        Long activityId = Long.parseLong(thumbsUpProductVo.getActivityId());
        Long groupId = StringUtils.isEmpty(thumbsUpProductVo.getGroupId()) ? 0L : Long.parseLong(thumbsUpProductVo.getGroupId());
        Integer thumbsUped = this.thumbsUpedProduct(userId, thumbsUpProductVo.getProductId(), thumbsUpProductVo.getSkuId(), activityId);

        ProductUserLike productUserLike = new ProductUserLike();
        productUserLike.setActivityId(activityId);
        productUserLike.setProductId(thumbsUpProductVo.getProductId());
        productUserLike.setSkuId(thumbsUpProductVo.getSkuId());
        productUserLike.setUserId(userId);
        productUserLike.setTuanId(groupId);

        //取消点赞
        if (thumbsUpProductVo.getThumbsUped().equals("0")) {
            if (thumbsUped == 0) {
                throw new ServiceException("home.page.thumbsUpProduct.notThumbsUped");
            }

            iProductInteractionInfoManager.reduceLikeNum(productUserLike);
        }

        //点赞
        if (thumbsUpProductVo.getThumbsUped().equals("1")) {
            if (thumbsUped == 1) {
                throw new ServiceException("home.page.thumbsUpProduct.thumbsUped");
            }

            iProductInteractionInfoManager.increaseLikeNum(productUserLike);
        }
    }

    /**
     * 收藏商品
     *
     * @param userId
     * @param collectionProduct
     * @throws ServiceException
     */
    public void collectionProduct(String userId, CollectionProductVo collectionProduct) throws ServiceException {
        Long activityId = Long.parseLong(collectionProduct.getActivityId());
        Long groupId = StringUtils.isEmpty(collectionProduct.getGroupId()) ? 0L : Long.parseLong(collectionProduct.getGroupId());
        Integer collected = this.collectedProduct(userId, collectionProduct.getProductId(), collectionProduct.getSkuId(), activityId);

        if (collected == 1) {
            throw new ServiceException("home.page.collectionProduct.collected");
        }

        ProductUserCollection productUserCollection = new ProductUserCollection();

        productUserCollection.setUserId(userId);
        productUserCollection.setProductId(collectionProduct.getProductId());
        productUserCollection.setSkuId(collectionProduct.getSkuId());
        productUserCollection.setSkuNo(collectionProduct.getSkuNo());
        productUserCollection.setActivityId(activityId);
        productUserCollection.setTuanId(groupId);

        iProductInteractionInfoManager.increaseCollectionNum(productUserCollection);
    }

    /**
     * 取消收藏商品
     *
     * @param userId
     * @param collectionProduct
     * @throws ServiceException
     */
    public void unCollectionProduct(String userId, UnCollectionProductVo collectionProduct) throws ServiceException {

        Long activityId = Long.parseLong(collectionProduct.getActivityId());
        Long groupId = StringUtils.isEmpty(collectionProduct.getGroupId()) ? 0L : Long.parseLong(collectionProduct.getGroupId());
        Integer collected = this.collectedProduct(userId, collectionProduct.getProductId(), collectionProduct.getSkuId(), activityId);

        if (collected == 1) {

            ProductUserCollection collection = new ProductUserCollection();
            Long collectionId = null;
            if (StringUtils.isNotEmpty(collectionProduct.getCollectionId())) {
                collectionId = Long.parseLong(collectionProduct.getCollectionId());
            }
            collection.setId(collectionId);
            collection.setProductId(collectionProduct.getProductId());
            collection.setSkuId(collectionProduct.getSkuId());
            collection.setActivityId(activityId);
            collection.setUserId(userId);
            collection.setTuanId(groupId);

            boolean realFlag = true;
            if ("3".equals(collectionProduct.getFromSource())) {
                realFlag = false;
            }

            iProductInteractionInfoManager.reduceCollectionNum(collection, realFlag);
        } else {
            throw new ServiceException("home.page.unCollectionProduct.notCollected");
        }


    }

    /**
     * 评价商品
     *
     * @param userId
     * @param appraiseProduct
     * @throws ServiceException
     */
    public void appraiseProduct(String userId, AppraiseProductVo appraiseProduct) throws ServiceException {
        try {
            MeidianGoodsAppraise appraise = new MeidianGoodsAppraise();
            appraise.setProductId(appraiseProduct.getProductId());
            appraise.setProductName(appraiseProduct.getProductName());
            appraise.setPostUserId(userId);
            appraise.setContent(appraiseProduct.getAppraiseContent());
            appraise.setPostType("0");

            // 根据userId获取用户昵称
            Map<String, Object> paraMap = new HashMap<>();
            paraMap.put("companyName", "gomeOnLine");
            MapResult<UnifyUserInfoExt> result = iUserInfoFacade.getItemByIdForGomeShop(userId, "gomeShopMobile", paraMap);
            if (result != null && result.isSuccess()) {
                UnifyUserInfoExt userVo = result.getBuessObj();
                String nickName = null;
                if (null != userVo)
                    nickName = userVo.getNikename();
                appraise.setPostUserName(nickName);
            }
            System.out.println(JSONObject.toJSONString(appraise));
            ResultMsg msg = iMeidianGoodsAppraiseWriteService.addMeidianGoodsAppraise(appraise);
            if (null == msg || !msg.isSuccess()) {
                throw new ServiceException("home.page.appraise.fail");
            }
        } catch (Exception e) {
            throw new ServiceException("home.page.appraise.fail");
        }

    }

    /**
     * 获取商品分享、点赞、收藏、评价信息
     *
     * @param userId
     * @param productId
     */
    private CollectionProductInfoVo getShareCollectionAppraiseInfo(String userId, String productId, String skuId, String activityId) {
        Long huodongId = Long.parseLong(activityId);
        //商品的分享、点赞、收藏数量信息
        ProductInteractionInfo productInteractionInfo = iProductInteractionInfoManager.selectOneByProductId(productId);

        CollectionProductInfoVo info = new CollectionProductInfoVo();
        if (null != productInteractionInfo) {

            info.setShareNum(productInteractionInfo.getShareNum() == null ? 0 : productInteractionInfo.getShareNum());
            info.setCollectionNum(productInteractionInfo.getCollectionNum() == null ? 0 : productInteractionInfo.getCollectionNum());
            info.setThumbsUpNum(productInteractionInfo.getLikeNum() == null ? 0 : productInteractionInfo.getLikeNum());
            //商详页获取
//                //默认20条评论
//          info.setAppraiseList(this.getAppraise(productId, 1, 20));
            if (StringUtils.isNotEmpty(userId)) {
                //当前用户是否收藏过
                Integer collected = this.collectedProduct(userId, productId, skuId, huodongId);
                //当前用户是否点赞过
                Integer thumbsUped = this.thumbsUpedProduct(userId, productId, skuId, huodongId);
                info.setCollected(collected);
                info.setThumbsUped(thumbsUped);
            }
        }
        return info;
    }

    public AppraiseListVo getAppraise(String productId, Integer pageNo, Integer pageSize) {
        AppraiseListVo list = new AppraiseListVo();
        String onOff = gcache.get("appraiseOnOff");

        if(onOff != null && onOff.equals("0")){
        	return list;
        }
        PJPage<MeidianGoodsAppraise> result = iMeidianGoodsAppraiseQueryService.getPageByProuctId(productId, pageNo, pageSize);
        if (null != result && result.isIsuc()) {
            list.setTotalNum(result.getTim());
            list.setTotalPageNum(result.getTpg());
            list.setCurrentPageNo(result.getCurpg());
            list.setPageSize(result.getLen());
            List<MeidianGoodsAppraise> appraiseList = result.getCtn();
            if (null != appraiseList && !appraiseList.isEmpty()) {
                List<AppraiseVo> voList = new ArrayList<>();
                list.setAppraises(voList);
                AppraiseVo appraise = null;
                for (MeidianGoodsAppraise app : appraiseList) {
                    appraise = new AppraiseVo();
                    appraise.setId(app.getId());
                    appraise.setProductId(app.getProductId());
                    appraise.setProductName(app.getProductName());
                    appraise.setPostUserId(app.getPostUserId());
                    appraise.setPostUserName(app.getPostUserName());
                    appraise.setContent(app.getContent());
                    appraise.setPostTime(app.getPostTime());
                    appraise.setPostDay(app.getPostDay());
                    voList.add(appraise);
                }
            }
        }
        return list;
    }

    /**
     * 我的收藏列表
     *
     * @param userId
     * @throws ServiceException
     */
    public List<CollectionInfoVo> getCollectionProductList(String userId, String areaCode, Integer ppi, Byte ua, String storeCode) throws ServiceException {
        List<CollectionInfoVo> infoList = null;
        //获取收藏列表数据
        List<ProductUserCollection> list = iProductUserCollectionManager.selectListByUserId(userId);

        //遍历列表
        if (null != list && !list.isEmpty()) {
            List<GroupInfoReq> groupInfoReqs = new ArrayList<>();
            Map<String, ProductUserCollection> map = new HashMap<>();
            List<String> productIds = new ArrayList<>();

            GroupInfoReq group = null;
            for (ProductUserCollection coll : list) {
                group = new GroupInfoReq();
                group.setActivityId(coll.getActivityId());
                group.setProductId(coll.getProductId());
                group.setSkuId(coll.getSkuId());
                map.put(coll.getProductId() + "-" + coll.getSkuId() + "-" + coll.getActivityId(), coll);
                productIds.add(coll.getProductId());
                groupInfoReqs.add(group);
            }

            List<ProductGroupInfoVo> result = homeProductsManager.groupInfo(groupInfoReqs, areaCode, ppi, ua, storeCode);

            Map<String, Integer> productIdAndToalBuyMap = getProductBuyNum(productIds);

            if (null != result && !result.isEmpty()) {

                infoList = new ArrayList<>();
                CollectionInfoVo infoVo = null;
                ProductUserCollection temp = null;
                for (ProductGroupInfoVo vo : result) {
                    infoVo = new CollectionInfoVo();
                    infoVo.setHomeGroupProductActivityPage(null);
                    infoVo.setHomePageActivity(vo.getHomePageActivity());
                    infoVo.setProductInfo(vo.getProductInfo());

                    temp = map.get(vo.getProductInfo().getProductId() + "-" + vo.getProductInfo().getSkuId() + "-" + vo.getHomePageActivity().getActivityId());
                    infoVo.setCollectionId(temp.getId());
                    infoVo.getProductInfo().setSkuNo(temp.getSkuNo());
                    infoVo.setCollected(this.collectedProduct(userId, vo.getProductInfo().getProductId(), vo.getProductInfo().getSkuId(), vo.getHomePageActivity().getActivityId()));

                    Integer totalNum = productIdAndToalBuyMap.get(vo.getProductInfo().getProductId());
                    if (null != totalNum) {
                        infoVo.getHomePageActivity().setTotalBuyNum(totalNum);
                    }

                    if (null != temp.getTuanId() && 0L != temp.getTuanId()) {
                        infoVo.getHomePageActivity().setGroupId(temp.getTuanId());
                    }


                    ProductManagementVo pVo = groupOrderManager.getProductInfoById(vo.getHomePageActivity().getActivityId(), temp.getProductId(), areaCode, vo.getProductInfo().getSkuId());
                    long endTime = 0;
                    if (pVo != null) {
                        if (pVo.getEffectiveEndTime() != null) {
                            endTime = pVo.getEffectiveEndTime().getTime();
                        } else {
                            GroupInfoVo groupInfo = groupOrderManager.getGroupInfoById(vo.getHomePageActivity().getActivityId(), temp.getTuanId() == 0 ? null : temp.getTuanId(), areaCode, vo.getProductInfo().getSkuId(), null);
                            if (null != groupInfo) {
                                if (groupInfo.getEndTime() != null) {
                                    endTime = groupInfo.getEndTime().getTime();
                                }
                            }
                        }
                    }

                    if (endTime != 0) {
                        if (System.currentTimeMillis() > endTime) {
                            infoVo.setActivityExpired(1);
                        } else {
                            infoVo.setActivityExpired(0);
                        }
                    }
                    infoList.add(infoVo);
                }
            }
        }

        return infoList;
    }

    /**
     * 用户是否收藏过万人团
     *
     * @param userId
     * @param productId
     * @param skuId
     * @param activityId
     * @return
     */
    private Integer collectedProduct(String userId, String productId, String skuId, Long activityId) {
        Integer collected = 0;
        String userCollectionInfo = userCenter.get(this.PRODUCT_USER_COLLECTION_USER_KEY + userId);
        if (StringUtils.isNotEmpty(userCollectionInfo)) {
            List<ProductUserCollection> list = JSONObject.parseArray(userCollectionInfo, ProductUserCollection.class);
            if (list != null && !list.isEmpty()) {
                for (ProductUserCollection coll : list) {
                    if (null != coll && productId.equals(coll.getProductId()) && skuId.equals(coll.getSkuId()) && activityId.longValue() == coll.getActivityId().longValue()) {
                        collected = 1;
                        break;
                    }
                }
            }
        }
        return collected;
    }

    /**
     * 用户是否点赞商品
     *
     * @param userId
     * @param productId
     * @param skuId
     * @param activityId
     * @return
     */
    private Integer thumbsUpedProduct(String userId, String productId, String skuId, Long activityId) {
        Integer thumbsUped = 0;
        String userThumbsUpInfo = userCenter.get(this.PRODUCT_USER_THUMBSUP_USER_KEY + userId);
        if (StringUtils.isNotEmpty(userThumbsUpInfo)) {
            List<ProductUserLike> list = JSONObject.parseArray(userThumbsUpInfo, ProductUserLike.class);
            if (list != null && !list.isEmpty()) {
                for (ProductUserLike like : list) {
                    if (null != like && productId.equals(like.getProductId()) && skuId.equals(like.getSkuId()) && activityId.longValue() == like.getActivityId().longValue()) {
                        thumbsUped = 1;
                        break;
                    }
                }
            }
        }

        return thumbsUped;
    }

    public Object checkagent(String productId, String skuId, String brandId, String shopId) throws ServiceException {
        Object result = null;
        Map<String, String> catMap = this.getProductMultiProperties(productId);
        String cat = null;
        if (null != catMap) {
            if (null != catMap.get("firstCatItemId")) {
                cat = catMap.get("firstCatItemId").toString();
            }

            if (null != catMap.get("secCatItemId")) {
                cat = cat + "_" + catMap.get("secCatItemId").toString();
            }

            if (null != catMap.get("thridCatItemId")) {
                cat = cat + "_" + catMap.get("thridCatItemId").toString();
            }
        }

        JSONObject paraObject = new JSONObject();
        paraObject.put("shopid", shopId);
        paraObject.put("entry", "product");  //入口类型， composite=综合入口,order=订单入口,product=商品入口
        paraObject.put("categoryid", cat);
        paraObject.put("brandid", brandId);
        paraObject.put("skuid", skuId);
        paraObject.put("area", "11000000_11010000_11010200_110102002");   //默认

        String httpResult = httpClientUtil.doPost(this.checkagentUrl, paraObject);
        if (StringUtils.isNotBlank(httpResult)) {
            JSONObject obj = JSONObject.parseObject(httpResult);
            if (null != obj && obj.containsKey("data")) {
                result = obj.get("data");
            }
        }
        return result;
    }

    public Map<String, String> getProductMultiProperties(String productId) {
        Map<String, String> resultMap = null;
        String[] properties = new String[]{"firstCatItemId", "secCatItemId", "thridCatItemId"};
        resultMap = prodDetailService.getProductMultiProperties(productId, properties);
        return resultMap;
    }

    public Model cmsInfo(BasePageI basePage, Long userId, String storeCode,
                         String pageCode, String areaCode, String townCode, int channel,
                         Byte ua, Integer ppi) throws ServiceException {

        if (null == basePage) return null;
        List<MenusModule> menusModules = basePage.getModuleMenuList();
        Map<String, Modules> moduleMap = basePage.getModuleValueMap();

        if (null == menusModules || menusModules.size() == 0) return null;
        List<ModelVo> modelVos = new ArrayList<ModelVo>();

        for (MenusModule menusModule : menusModules) {
            if (null == menusModule) continue;
            int type = menusModule.getType();
            ModelVo modelVo = new ModelVo();
            if (type == 1) {
                // 常规楼层
                // 楼层数据
                Menus menus = menusModule.getSingleMenus();
                if (null == menus) continue;
                int modeType = menus.getModuleType();
                String moduleCode = menus.getModuleCode();
                modelVo.setType(modeType);
                modelVo.setModuleCode(moduleCode);
                modelVo.setPageCode(pageCode);
                modelVo.setName(menus.getName());

                Modules modules = moduleMap.get(moduleCode);
                if (null == modules) {
                    modelVos.add(modelVo);
                    continue;
                }
                Module module = modules.getModule();
                if (null != module) {
                    modelVo.setRowCount(module.getRowCount());
                    modelVo.setBackColor(module.getBackColor());
                    modelVo.setBackImgUrl(module.getBackImgUrl());
                    modelVo.setExpanded1(module.getExpanded1());
                }

                // 图片处理
                if (modeType == GroupOrderConstants.MEIDIAN_BANNER
                        || modeType == GroupOrderConstants.MEIDIAN_ADVERT
                        || modeType == GroupOrderConstants.MEIDIAN_PICTURE
                        || modeType == GroupOrderConstants.MEIDIAN_ICON
                        || modeType == GroupOrderConstants.MEIDIAN_BOTTOM_NAVIGATION
                        || modeType == GroupOrderConstants.MEIDIAN_PLACEHOLDER
                        || modeType == GroupOrderConstants.MEIDIAN_SUSPEND_BUTTON
                        || modeType == GroupOrderConstants.MEIDIAN_COLLECTFLOW
                ) {

                    // 为前端合并1,3楼层
                    if (modeType == GroupOrderConstants.MEIDIAN_ADVERT)
                        modelVo.setType(GroupOrderConstants.MEIDIAN_PICTURE);

                    List<ImageElement> imageElements = new ArrayList<ImageElement>();

                    List<Picture> pictures = modules.getPicList();
                    if (null == pictures || pictures.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }
                    for (Picture picture : pictures) {
                        if (null == picture) continue;
                        ImageElement imageElement = new ImageElement();
                        if(StringUtils.isNotBlank(picture.getItemName())){
                            imageElement.setItemName(picture.getItemName());
                        }
                        String imageUrl = picture.getImgUrl();
                        if (null == imageUrl) continue;
                        // 处理图片后缀
                        String imageInfo = ImageUtils.imageUrlInfo(imageUrl, ua);
                        // 处理图片协议
                        if (imageInfo.contains("http:"))
                            imageElement.setImageUrl(imageInfo.replace("http:", agreement));
                        else
                            imageElement.setImageUrl(imageInfo);

                        imageElement.setTarget(picture.getSkipInfo());
                        // 图片按钮，有值是图片带按钮，没有值就是普通图片
                        imageElement.setButton(picture.getTitle());

                        // ICON处理
                        if (modeType == GroupOrderConstants.MEIDIAN_ICON)
                            imageElement.setTitle(picture.getItemName());

                        imageElements.add(imageElement);
                    }

                    modelVo.setImageElements(imageElements);

                } else if (modeType == GroupOrderConstants.MEIDIAN_NAVIGATION) {
                    // 分类导航，锚点
                    List<Anchor> anchors = modules.getAnchorList();
                    if (null == anchors || anchors.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }
                    List<ImageElement> images = new ArrayList<ImageElement>();
                    for (Anchor anchor : anchors) {
                        ImageElement image = new ImageElement();
                        image.setTitle(anchor.getItemName());
                        image.setTarget(anchor.getSkipInfo());
                        images.add(image);
                    }

                    modelVo.setImageElements(images);
                    if (null != module) {
                        modelVo.setTextColor(module.getTextColor());
                        modelVo.setSctTextColor(module.getSctTextColor());
                    }

                } else if (modeType == GroupOrderConstants.MEIDIAN_GROUP_PRODUCT || modeType == GroupOrderConstants.MEIDIAN_HELP_PRODUCT) {
                    // 处理组团商品，不分页
                    List<Zutuan> gros = modules.getZutuanList();
                    if (null == gros || gros.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }

                    List<ProductGroupInfoVo> productGroupInfoVos = this.getGroupInfo(gros, areaCode, ppi, ua, storeCode);

                    modelVo.setProductGroupInfoVos(productGroupInfoVos);
                } else if (modeType == GroupOrderConstants.MEIDIAN_COUPON_PRODUCT) {
                    // 处理立减商品，不分页
                    List<CouponRule> couponRules = modules.getCouponList();
                    if (null == couponRules || couponRules.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }
                    List<HomeCouponProductRes> homeCouponProductRes = this.getCouponProductInfo(couponRules, areaCode, ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);

                    modelVo.setHomeCouponProductRes(homeCouponProductRes);

                } else if (modeType == GroupOrderConstants.MEIDIAN_BUYREBATE_PRODUCT) {
                    // 处理超级返商品，不分页
                    List<Cashback> buyRes = modules.getCashbackList();
                    if (null == buyRes || buyRes.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }
                    List<ProductBuyRebateVo> productBuyRebateVos = this.getBuyRebateInfo(buyRes, areaCode, ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);

                    modelVo.setProductBuyRebateVos(productBuyRebateVos);

                } else if (modeType == GroupOrderConstants.MEIDIAN_COUPON) {
                    // 劵
                    List<SimpleCoupon> simpleCoupons = modules.getSimpleCouponList();
                    if (null == simpleCoupons || simpleCoupons.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }

                    List<Coupon> coupons = this.getCoupon(simpleCoupons);
                    modelVo.setCoupons(coupons);
                } else if (modeType == GroupOrderConstants.MEIDIAN_VIDEO) {
                    // 视频
                    List<Vedio> vedios = modules.getVedioList();
                    if (null == vedios || vedios.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }

                    List<ImageElement> imageElements = new ArrayList<ImageElement>();
                    for (Vedio vedio : vedios) {
                        if (null == vedio) continue;
                        ImageElement imageElement = new ImageElement();
                        imageElement.setTarget(vedio.getSkipInfo());

                        imageElements.add(imageElement);
                    }

                    modelVo.setImageElements(imageElements);
                } else if (modeType == GroupOrderConstants.MEIDIAN_COLLECTFLOW_GROUP_PRODUCT) {
                    // 集客组团商品
                    List<Zutuan> flowGros = modules.getZutuanList();
                    if (null == flowGros || flowGros.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }

                    List<ProductGroupInfoVo> productGroupInfoVos = this.getGroupInfo(flowGros, areaCode, ppi, ua, storeCode);

                    modelVo.setProductGroupInfoVos(productGroupInfoVos);
                } else if (modeType == GroupOrderConstants.ZUTUAN_SOCI) {
                    //万人团
                    List<ZutuanSoci> sociList = modules.getZutuanSociList();
                    if (null == sociList || sociList.size() == 0) {
                        modelVos.add(modelVo);
                        continue;
                    }
                    List<ThousandGroup> thousandGroups = this.getWanrenGroupList(sociList, userId, areaCode, null, storeCode, ppi, ua);
                    modelVo.setThousandGroups(thousandGroups);
                }
            } else if (type == 2) {
                // 合并楼层，比如组团，立减，超级返3个同时显示
                List<Menus> mergeMenus = menusModule.getMergeMenus();
                if (null == mergeMenus || mergeMenus.size() == 0) continue;
                List<ModelMerge> modelMerges = new ArrayList<ModelMerge>();

                // 处理合并中的楼层
                for (Menus menus : mergeMenus) {
                    if (null == menus) continue;
                    int modeType = menus.getModuleType();
                    String modCode = menus.getModuleCode();

                    // 楼层数据
                    ModelMerge modelMerge = new ModelMerge();
                    modelMerge.setType(modeType);
                    modelMerge.setModuleCode(modCode);
                    modelMerge.setPageCode(pageCode);
                    modelMerge.setName(menus.getName());

                    // 楼层中的元素处理
                    Modules mods = moduleMap.get(modCode);
                    if (null == mods) {
                        modelMerges.add(modelMerge);
                        continue;
                    }
                    Module mode = mods.getModule();
                    if (null != mode) {
                        modelMerge.setRowCount(mode.getRowCount());
                    }

                    if (modeType == GroupOrderConstants.MEIDIAN_GROUP_PRODUCTS_PAGE || modeType == GroupOrderConstants.MEIDIAN_HELP_PRODUCTS_PAGE) {
                        // 组团模块底部列表，分页，默认返回10条
                        List<Zutuan> groups = mods.getZutuanList();
                        if (null == groups || groups.size() == 0) {
                        	modelMerges.add(modelMerge);
                            continue;
                        }

                        List<ProductGroupInfoVo> productGroupInfoVos = this.getGroupInfo(groups, areaCode, ppi, ua, storeCode);

                        modelMerge.setProductGroupInfoVos(productGroupInfoVos);


                    } else if (modeType == GroupOrderConstants.MEIDIAN_COUPON_PRODUCTS_PAGE) {
                        // 立减模块底部列表，分页，默认返回10条
                        List<CouponRule> coupons = mods.getCouponList();
                        if (null == coupons || coupons.size() == 0) {
                        	modelMerges.add(modelMerge);
                            continue;
                        }
                        List<HomeCouponProductRes> homeCouponProductRes = this.getCouponProductInfo(coupons, areaCode, ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);

                        modelMerge.setHomeCouponProductRes(homeCouponProductRes);


                    } else if (modeType == GroupOrderConstants.MEIDIAN_BUYREBATE_PRODUCT_PAGE) {
                        // 超级返模块底部列表，分页，默认返回10条
                        List<Cashback> buyRebates = mods.getCashbackList();
                        if (null == buyRebates || buyRebates.size() == 0) {
                        	modelMerges.add(modelMerge);
                            continue;
                        }
                        List<ProductBuyRebateVo> productBuyRebateVos = this.getBuyRebateInfo(buyRebates, areaCode, ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);

                        modelMerge.setProductBuyRebateVos(productBuyRebateVos);

                    } else if (modeType == GroupOrderConstants.MEIDIAN_SURVEY_PAGE_B) {
                        // 热度调研我要卖模块底部列表，分页，默认返回10条
                        List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> products = mods.getProductList();
                        if (null == products || products.size() == 0) {
                        	modelMerges.add(modelMerge);
                            continue;
                        }
                        List<ProductSurveyInfoVo> productSurveyInfoVos = this.getProductSurveyInfo(products, areaCode, ppi, ua, storeCode);
                        modelMerge.setProductSurveyInfoVos(productSurveyInfoVos);

                    } else if (modeType == GroupOrderConstants.ZUTUAN_SOCI_BTM) {
                        // 万人团
                        List<ZutuanSoci> thousands = mods.getZutuanSociList();
                    	if (null == thousands || thousands.size() == 0) {
                        	modelMerges.add(modelMerge);
                            continue;
                        }
                        List<ThousandGroup> thousandGroups = this.getWanrenGroupList(thousands, userId, areaCode, null, storeCode, ppi, ua);
                        modelMerge.setThousandGroups(thousandGroups);
                    }else if(modeType == GroupOrderConstants.PARTITION_BTM){
                        //瓜分团瀑布流
                        List<Partition> partitions = mods.getPartitiontList();
                        if(null == partitions || partitions.isEmpty()){
                            modelMerges.add(modelMerge);
                            continue;
                        }
                        List<CarveUpActivityInfoVo> carveUpGroups = carveUpManager.carveUpGroupList(partitions, userId, ppi, ua);
                        modelMerge.setCarveUpGroups(carveUpGroups);
                    }else if(modeType == GroupOrderConstants.COMMON_PRODUCT) {  //普通商品
                    	List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> productList = mods.getProductList();
                    	if(null == productList || productList.isEmpty()) {
                    		modelMerges.add(modelMerge);
                    		continue;
                    	}

						List<CommonProductVo> pVos = this.getCommonProductList(productList, areaCode, townCode, storeCode, ppi, ua, GroupOrderConstants.PRICE_POLICYID);
						modelMerge.setCommonProducts(pVos);
                    	
                    }

                    modelMerges.add(modelMerge);
                }

                // 合并楼层类型
                modelVo.setType(GroupOrderConstants.MEIDIAN_MERGE_MODEL);
                modelVo.setModelMerges(modelMerges);
            }

            modelVos.add(modelVo);
        }

        // 页面元素处理
        PageInfo pageInfo = basePage.getDefaultPageInfo();
        PageProperty pageProperty = new PageProperty(pageInfo.getPageName(), pageInfo.getPageTitle(), pageInfo.getPageDesc(),
                pageInfo.getBackColor(), pageInfo.getImgUrl(), pageInfo.getShareUrl());
        if (channel == 3){
        	pageProperty.setShareUrl(pageInfo.getWxShareImg());
        }
        Model model = new Model();
        model.setModelVos(modelVos);
        model.setPageProperty(pageProperty);

        return model;

    }

    public PageInfo getSecondInfo(String pageCode) {
        PageInfo pageInfo = pageInfoResource.selectPageInfo(pageCode);
        return pageInfo;
    }
    
    /**
     * 万人团商品素材
     * @param sociList
     * @param userId
     * @param areaCode
     * @param orgCode
     * @param storeCode
     * @param ppi
     * @param ua
     * @return
     * @throws ServiceException
     */
    public List<ThousandGroup> getThousandGroupMaterial(List<ZutuanSoci> sociList, Long userId, String areaCode, String orgCode, String storeCode, Integer ppi, Byte ua) throws ServiceException {
        List<ThousandGroup> thousandGroups = new ArrayList<ThousandGroup>();

        for (ZutuanSoci soci : sociList) {
            ThousandGroup thousandGroup = new ThousandGroup();
            WanrenProductVo wanrenProductVo = new WanrenProductVo();
            String productId = soci.getProductId();
            thousandGroup.setGroupId(soci.getGroupId());

            //商品服务获取信息
            ProductBaseInfo baseInfo = null;
            String proJson = userCenter.get(PRODUCT_BASE_KEY + productId);
            if (StringUtils.isNotBlank(proJson)) {
                baseInfo = JSONObject.parseObject(proJson, ProductBaseInfo.class);
            } else {
                baseInfo = iProductBaseInfoManager.selectOneByProductId(productId);
            }

            if (null != baseInfo) {
            	String bgImages = baseInfo.getBackgroundImage();
                if (StringUtils.isNotBlank(bgImages)) {
                	 // 获取分辨率
                    String ratio = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE);
                    
                    List<String> images = JSONObject.parseArray(bgImages, String.class);
                    List<String> newImages = new ArrayList<>();
                    for (String str : images) {
                        newImages.add(ImageUtils.imageUrlInfo(str, ratio, ua));
                    }
                    wanrenProductVo.setImages(newImages);
                }
                wanrenProductVo.setBgVideo(baseInfo.getBackgroundVideo());
                wanrenProductVo.setDesc(baseInfo.getProductDesc());
                wanrenProductVo.setBrandId(baseInfo.getBrandId());
                wanrenProductVo.setBrandName(baseInfo.getBrandTitile());
                wanrenProductVo.setBrandImage(baseInfo.getBrandLogo());
                wanrenProductVo.setExpanded1(soci.getExpanded1());
                
                Long acId = null;
                String activityId = soci.getActivityCode();
                if(null != activityId) {
                	acId = Long.valueOf(activityId);
                }
                wanrenProductVo.setActivityId(acId);
                wanrenProductVo.setProductId(productId);
                wanrenProductVo.setSkuId(soci.getSkuId());
                wanrenProductVo.setSkuNo(soci.getSkuNo());
                thousandGroup.setWanrenProductVo(wanrenProductVo);
                thousandGroups.add(thousandGroup);
            }
            
        }

        return thousandGroups;
    }
    
    /**
     * 店主页使用
     * @param userId
     * @param storeCode
     * @param pageCode
     * @param areaCode
     * @param channel
     * @param ua
     * @param ppi
     * @return
     * @throws ServiceException
     */
    public Model material(Long userId, String storeCode, String pageCode, String areaCode, int channel, Byte ua, Integer ppi) throws ServiceException {
        // 美店cms把ios，android合并了
        if (channel == GroupOrderConstants.MEIDIAN_CMS_IOS_APP) channel = 3;
        String keyId = "meidianCMSActivityPage_" + pageCode + "_" + storeCode + "_" + channel;
        PageSecondI pageSecondI = JSONObject.parseObject(gcache.get(keyId), PageSecondI.class);
        if (null == pageSecondI) {
        	pageSecondI = pageInfoResource.getPageFloor(pageCode, storeCode, channel);
//            pageSecondI = pageInfoResource.getPageSecondI(pageCode, storeCode, channel);
            gcache.setex(keyId, 60, JSONUtils.toJSONString(pageSecondI).getBytes());
        }
        Model model = this.material(pageSecondI.getBasePage(), userId, storeCode,
                pageCode, areaCode, null, channel,
                ua, ppi);
        return model;
    }
    
	/**
	 * 店主页使用
	 * @param basePage
	 * @param userId
	 * @param storeCode
	 * @param pageCode
	 * @param areaCode
	 * @param channel
	 * @param ua
	 * @param ppi
	 * @return
	 * @throws ServiceException
	 */
	public Model material(BasePageI basePage, Long userId, String storeCode, String pageCode, String areaCode, String townCode,
			int channel, Byte ua, Integer ppi) throws ServiceException {

		if (null == basePage)
			return null;
		List<MenusModule> menusModules = basePage.getModuleMenuList();
		Map<String, Modules> moduleMap = basePage.getModuleValueMap();

		if (null == menusModules || menusModules.size() == 0)
			return null;
		List<ModelVo> modelVos = new ArrayList<ModelVo>();

		for (MenusModule menusModule : menusModules) {
			if (null == menusModule)
				continue;
			int type = menusModule.getType();
			ModelVo modelVo = new ModelVo();
			if (type == 1) {
				// 常规楼层
				// 楼层数据
				Menus menus = menusModule.getSingleMenus();
				if (null == menus)
					continue;
				int modeType = menus.getModuleType();
				String moduleCode = menus.getModuleCode();
				modelVo.setType(modeType);
				modelVo.setModuleCode(moduleCode);
				modelVo.setPageCode(pageCode);
				modelVo.setName(menus.getName());

				Modules modules = moduleMap.get(moduleCode);
				if (null == modules) {
					modelVos.add(modelVo);
					continue;
				}
				Module module = modules.getModule();
				if (null != module) {
					modelVo.setRowCount(module.getRowCount());
					modelVo.setBackColor(module.getBackColor());
					modelVo.setBackImgUrl(module.getBackImgUrl());
					modelVo.setExpanded1(module.getExpanded1());
				}

				// 图片处理
				if (modeType == GroupOrderConstants.MEIDIAN_BANNER || modeType == GroupOrderConstants.MEIDIAN_ADVERT
						|| modeType == GroupOrderConstants.MEIDIAN_PICTURE
						|| modeType == GroupOrderConstants.MEIDIAN_ICON
						|| modeType == GroupOrderConstants.MEIDIAN_BOTTOM_NAVIGATION
						|| modeType == GroupOrderConstants.MEIDIAN_PLACEHOLDER
						|| modeType == GroupOrderConstants.MEIDIAN_SUSPEND_BUTTON
						|| modeType == GroupOrderConstants.MEIDIAN_COLLECTFLOW) {

					// 为前端合并1,3楼层
					if (modeType == GroupOrderConstants.MEIDIAN_ADVERT)
						modelVo.setType(GroupOrderConstants.MEIDIAN_PICTURE);

					List<ImageElement> imageElements = new ArrayList<ImageElement>();

					List<Picture> pictures = modules.getPicList();
					if (null == pictures || pictures.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}
					for (Picture picture : pictures) {
						if (null == picture)
							continue;
						ImageElement imageElement = new ImageElement();
						if (StringUtils.isNotBlank(picture.getItemName())) {
							imageElement.setItemName(picture.getItemName());
						}
						String imageUrl = picture.getImgUrl();
						if (null == imageUrl)
							continue;
						// 处理图片后缀
						String imageInfo = ImageUtils.imageUrlInfo(imageUrl, ua);
						// 处理图片协议
						if (imageInfo.contains("http:"))
							imageElement.setImageUrl(imageInfo.replace("http:", agreement));
						else
							imageElement.setImageUrl(imageInfo);

						imageElement.setTarget(picture.getSkipInfo());
						// 图片按钮，有值是图片带按钮，没有值就是普通图片
						imageElement.setButton(picture.getTitle());

						// ICON处理
						if (modeType == GroupOrderConstants.MEIDIAN_ICON)
							imageElement.setTitle(picture.getItemName());

						imageElements.add(imageElement);
					}

					modelVo.setImageElements(imageElements);

				} else if (modeType == GroupOrderConstants.MEIDIAN_NAVIGATION) {
					// 分类导航，锚点
					List<Anchor> anchors = modules.getAnchorList();
					if (null == anchors || anchors.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}
					List<ImageElement> images = new ArrayList<ImageElement>();
					for (Anchor anchor : anchors) {
						ImageElement image = new ImageElement();
						image.setTitle(anchor.getItemName());
						image.setTarget(anchor.getSkipInfo());
						images.add(image);
					}

					modelVo.setImageElements(images);
					if (null != module) {
						modelVo.setTextColor(module.getTextColor());
						modelVo.setSctTextColor(module.getSctTextColor());
					}

				} else if (modeType == GroupOrderConstants.MEIDIAN_GROUP_PRODUCT
						|| modeType == GroupOrderConstants.MEIDIAN_HELP_PRODUCT) {
					// 处理组团商品，不分页
					List<Zutuan> gros = modules.getZutuanList();
					if (null == gros || gros.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}

					List<ProductGroupInfoVo> productGroupInfoVos = this.getGroupInfo(gros, areaCode, ppi, ua, storeCode);

					modelVo.setProductGroupInfoVos(productGroupInfoVos);
				} else if (modeType == GroupOrderConstants.MEIDIAN_COUPON_PRODUCT) {
					// 处理立减商品，不分页
					List<CouponRule> couponRules = modules.getCouponList();
					if (null == couponRules || couponRules.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}
					List<HomeCouponProductRes> homeCouponProductRes = this.getCouponProductInfo(couponRules, areaCode,  
							ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);

					modelVo.setHomeCouponProductRes(homeCouponProductRes);

				} else if (modeType == GroupOrderConstants.MEIDIAN_BUYREBATE_PRODUCT) {
					// 处理超级返商品，不分页
					List<Cashback> buyRes = modules.getCashbackList();
					if (null == buyRes || buyRes.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}
					List<ProductBuyRebateVo> productBuyRebateVos = this.getBuyRebateInfo(buyRes, areaCode, ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);

					modelVo.setProductBuyRebateVos(productBuyRebateVos);

				} else if (modeType == GroupOrderConstants.MEIDIAN_COUPON) {
					// 劵
					List<SimpleCoupon> simpleCoupons = modules.getSimpleCouponList();
					if (null == simpleCoupons || simpleCoupons.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}

					List<Coupon> coupons = this.getCoupon(simpleCoupons);
					modelVo.setCoupons(coupons);
				} else if (modeType == GroupOrderConstants.MEIDIAN_VIDEO) {
					// 视频
					List<Vedio> vedios = modules.getVedioList();
					if (null == vedios || vedios.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}

					List<ImageElement> imageElements = new ArrayList<ImageElement>();
					for (Vedio vedio : vedios) {
						if (null == vedio)
							continue;
						ImageElement imageElement = new ImageElement();
						imageElement.setTarget(vedio.getSkipInfo());

						imageElements.add(imageElement);
					}

					modelVo.setImageElements(imageElements);
				} else if (modeType == GroupOrderConstants.MEIDIAN_COLLECTFLOW_GROUP_PRODUCT) {
					// 集客组团商品
					List<Zutuan> flowGros = modules.getZutuanList();
					if (null == flowGros || flowGros.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}

					List<ProductGroupInfoVo> productGroupInfoVos = this.getGroupInfo(flowGros, areaCode, ppi, ua, storeCode);

					modelVo.setProductGroupInfoVos(productGroupInfoVos);
				} else if (modeType == GroupOrderConstants.ZUTUAN_SOCI) {
					// 万人团
					List<ZutuanSoci> sociList = modules.getZutuanSociList();
					if (null == sociList || sociList.size() == 0) {
						modelVos.add(modelVo);
						continue;
					}
					List<ThousandGroup> thousandGroups = this.getWanrenGroupList(sociList, userId, areaCode, null,
							storeCode, ppi, ua);
					modelVo.setThousandGroups(thousandGroups);
				}
			} else if (type == 2) {
				// 合并楼层，比如组团，立减，超级返3个同时显示
				List<Menus> mergeMenus = menusModule.getMergeMenus();
				if (null == mergeMenus || mergeMenus.size() == 0)
					continue;
				List<ModelMerge> modelMerges = new ArrayList<ModelMerge>();

				// 处理合并中的楼层
				for (Menus menus : mergeMenus) {
					if (null == menus)
						continue;
					int modeType = menus.getModuleType();
					String modCode = menus.getModuleCode();

					// 楼层数据
					ModelMerge modelMerge = new ModelMerge();
					modelMerge.setType(modeType);
					modelMerge.setModuleCode(modCode);
					modelMerge.setPageCode(pageCode);
					modelMerge.setName(menus.getName());

					// 楼层中的元素处理
					Modules mods = moduleMap.get(modCode);
					if (null == mods) {
						modelMerges.add(modelMerge);
						continue;
					}
					Module mode = mods.getModule();
					if (null != mode) {
						modelMerge.setRowCount(mode.getRowCount());
					}

					if (modeType == GroupOrderConstants.MEIDIAN_GROUP_PRODUCTS_PAGE
							|| modeType == GroupOrderConstants.MEIDIAN_HELP_PRODUCTS_PAGE) {
						// 组团模块底部列表，分页，默认返回10条
						List<Zutuan> groups = mods.getZutuanList();
						if (null == groups || groups.size() == 0) {
							modelMerges.add(modelMerge);
							continue;
						}
						
						List<ProductGroupInfoVo> productGroupInfoVos = this.getGroupInfo(groups, areaCode, ppi, ua, storeCode);
						
						modelMerge.setProductGroupInfoVos(productGroupInfoVos);
					} else if (modeType == GroupOrderConstants.MEIDIAN_COUPON_PRODUCTS_PAGE) {
						// 立减模块底部列表，分页，默认返回10条
						List<CouponRule> coupons = mods.getCouponList();
						if (null == coupons || coupons.size() == 0) {
							modelMerges.add(modelMerge);
							continue;
						}
						
						List<HomeCouponProductRes> homeCouponProductRes = this.getCouponProductInfo(coupons, areaCode, 
								ppi, ua, storeCode, GroupOrderConstants.PRICE_POLICYID);
						
						modelMerge.setHomeCouponProductRes(homeCouponProductRes);

					} else if (modeType == GroupOrderConstants.MEIDIAN_BUYREBATE_PRODUCT_PAGE) {
						// 超级返模块底部列表，分页，默认返回10条
						List<Cashback> buyRebates = mods.getCashbackList();
						if (null == buyRebates || buyRebates.size() == 0) {
							modelMerges.add(modelMerge);
							continue;
						}
						
						List<ProductBuyRebateVo> productBuyRebateVos = this.getBuyRebateInfo(buyRebates, areaCode, ppi,
								ua, storeCode, GroupOrderConstants.PRICE_POLICYID);
						
						modelMerge.setProductBuyRebateVos(productBuyRebateVos);

					} else if (modeType == GroupOrderConstants.MEIDIAN_SURVEY_PAGE_B) {
						// 热度调研我要卖模块底部列表，分页，默认返回10条
						List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> products = mods.getProductList();
						if (null == products || products.size() == 0) {
							modelMerges.add(modelMerge);
							continue;
						}
						
						List<ProductSurveyInfoVo> productSurveyInfoVos = this.getProductSurveyInfo(products, areaCode,
								ppi, ua, storeCode);
						modelMerge.setProductSurveyInfoVos(productSurveyInfoVos);

					} else if (modeType == GroupOrderConstants.ZUTUAN_SOCI_BTM) {
						// 万人团
						List<ZutuanSoci> thousands = mods.getZutuanSociList();
						// 临时优化扩展素材楼层
						String expand = mode.getExpanded1();
						if (null == expand || expand.equals("")) {
							// 正常的万人团楼层
							if (null == thousands || thousands.size() == 0) {
								modelMerges.add(modelMerge);
								continue;
							}
							List<ThousandGroup> thousandGroups = this.getWanrenGroupList(thousands, userId, areaCode,
									null, storeCode, ppi, ua);
							modelMerge.setThousandGroups(thousandGroups);
						} else {
							if (expand.equals("mt1")) {
								// 万人团素材楼层
								if (null == thousands || thousands.size() == 0) {
									modelMerge.setType(GroupOrderConstants.THOUSAND_GROUP_MATERIAL);
									modelMerges.add(modelMerge);
									continue;
								}
								List<ThousandGroup> thousandGroups = this.getThousandGroupMaterial(thousands, userId,
										areaCode, null, storeCode, ppi, ua);
								modelMerge.setType(GroupOrderConstants.THOUSAND_GROUP_MATERIAL);
								modelMerge.setThousandGroups(thousandGroups);
							} else if (expand.equals("mt2")) {
								// 助力团素材楼层
								if (null == thousands || thousands.size() == 0) {
									modelMerge.setType(GroupOrderConstants.ASSISTANCE_GROUP_MATERIAL);
									modelMerges.add(modelMerge);
									continue;
								}
								List<ThousandGroup> thousandGroups = this.getThousandGroupMaterial(thousands, userId,
										areaCode, null, storeCode, ppi, ua);
								modelMerge.setType(GroupOrderConstants.ASSISTANCE_GROUP_MATERIAL);
								modelMerge.setThousandGroups(thousandGroups);
							}
						}
					} else if (modeType == GroupOrderConstants.PARTITION_BTM) {
						// 瓜分团瀑布流
						List<Partition> partitions = mods.getPartitiontList();
						if (null == partitions || partitions.isEmpty()) {
							modelMerges.add(modelMerge);
							continue;
						}
						
						List<CarveUpActivityInfoVo> carveUpGroups = carveUpManager.carveUpGroupList(partitions, userId,
								ppi, ua);
						modelMerge.setCarveUpGroups(carveUpGroups);
					}else if (modeType == GroupOrderConstants.CMS_THOUSAND_GROUP_MATERIAL) {
						// 万人团素材
						List<Partition> partitions = mods.getPartitiontList();
						if (null == partitions || partitions.isEmpty()) {
							modelMerges.add(modelMerge);
							continue;
						}
						
					}else if (modeType == GroupOrderConstants.CMS_ASSISTANCE_GROUP_MATERIAL) {
						// 助力团素材
						List<Partition> partitions = mods.getPartitiontList();
						if (null == partitions || partitions.isEmpty()) {
							modelMerges.add(modelMerge);
							continue;
						}
						
					}else if (modeType == GroupOrderConstants.ACTIVITY_MATERIAL) {
						// 活动素材
						List<Partition> partitions = mods.getPartitiontList();
						if (null == partitions || partitions.isEmpty()) {
							modelMerges.add(modelMerge);
							continue;
						}
					}else if(modeType == GroupOrderConstants.COMMON_PRODUCT) {
						List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> productList = mods.getProductList();
						if(null == productList || productList.isEmpty()) {
							modelMerges.add(modelMerge);
							continue;
						}
						List<CommonProductVo> pVos = this.getCommonProductList(productList, areaCode, townCode, storeCode, ppi, ua, GroupOrderConstants.PRICE_POLICYID);
						modelMerge.setCommonProducts(pVos);
					}

					modelMerges.add(modelMerge);
				}

				// 合并楼层类型
				modelVo.setType(GroupOrderConstants.MEIDIAN_MERGE_MODEL);
				modelVo.setModelMerges(modelMerges);
			}

			modelVos.add(modelVo);
		}

		// 页面元素处理
		PageInfo pageInfo = basePage.getDefaultPageInfo();
		PageProperty pageProperty = new PageProperty(pageInfo.getPageName(), pageInfo.getPageTitle(),
				pageInfo.getPageDesc(), pageInfo.getBackColor(), pageInfo.getImgUrl(), pageInfo.getShareUrl());
		if (channel == 3) {
			pageProperty.setShareUrl(pageInfo.getWxShareImg());
		}
		Model model = new Model();
		model.setModelVos(modelVos);
		model.setPageProperty(pageProperty);

		return model;

	}
	
	public List<CommonProductVo> getCommonProductList(List<com.gomeplus.bs.interfaces.cms2.vo.business.base.Product> productList, String areaCode, String townCode, String storeCode, Integer ppi, Byte ua, String policyId) throws ServiceException{
		List<ProductRequestParam> reqList = new ArrayList<ProductRequestParam>();
		ProductRequestParam req = null;
		Map<String, String> preSellMap = new HashMap<>();
		for(com.gomeplus.bs.interfaces.cms2.vo.business.base.Product pro: productList) {
			req = new ProductRequestParam();
			req.setProductId(pro.getProductId());
			req.setSkuId(pro.getSkuId());
			reqList.add(req);
			preSellMap.put(pro.getSkuId(), pro.getExpanded1());
		}
		
		List<CommonProductVo> pVoList = new ArrayList<>();
		//查询商品信息
		List<Product> products = groupOrderManager.getPros(reqList, areaCode, ppi, GroupOrderConstants.TWO_LIST_PRODUCT_IMAGE, ua, storeCode, policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
		
		CommonProductVo pVo = null;
		if(null != products && !products.isEmpty()) {
			String expand = null;
    		String depositStr = null;
    		String deductibleDepositStr = null;
			for(Product p: products) {
				pVo = new CommonProductVo();
				pVo.setSkuId(p.getSkuId());
				pVo.setSkuNo(p.getSkuNo());
				pVo.setProductTag(p.getProductTag());
				pVo.setShopId(p.getShopId());
				pVo.setProductId(p.getId());
				pVo.setImage(p.getMainImage());
				pVo.setProductStatus(p.getStatus());
				pVo.setProductName(p.getName());
				
				expand = preSellMap.get(p.getSkuId());
				//判断是否预售，如果是预售显示预售信息，不是预售显示美店定价
				if(StringUtils.isNotBlank(expand) && expand.contains("isPreSale:1")) {
                	GomePromPresellVo prese = advanceSaleManager.queryOnePresellInfoByParam(p.getSkuNo(), storeCode, p.getProductTag() != 1, areaCode, townCode);
                	
                	long curTime = System.currentTimeMillis();
                	//预售未开始或结束显示美店定价
                	if(null == prese || (null != prese.getStartDate() && curTime < prese.getStartDate().getTime()) || (null != prese.getEndDate() && curTime > prese.getEndDate().getTime()) ) {
                		pVo.setSellPrice(DoubleUtils.divide(Double.valueOf(String.valueOf(p.getSalePrice())), 100D, 2));
                	}else {
                    	pVo.setPreSellFlag(1);
                    	pVo.setDeposit(prese.getDeposit());
                    	pVo.setSellPrice(prese.getPresellPrice());
                    	pVo.setDepositExpand(prese.getDepositExpand());
                    	if(StringUtils.isNotBlank(prese.getDeductibleDeposit())) {
                        	pVo.setDeductibleDeposit(Double.valueOf(prese.getDeductibleDeposit()));
                    	}
                    	if("1".equals(prese.getDepositExpand())) {
                    		if(prese.getDeposit() - prese.getDeposit().intValue() == 0) {
                        		depositStr = String.valueOf(prese.getDeposit().intValue());
                    		}else {
                        		depositStr = String.valueOf(prese.getDeposit());
                    		}

                    		deductibleDepositStr = prese.getDeductibleDeposit();
                    		if(deductibleDepositStr.endsWith(".0")) {
                    			deductibleDepositStr = deductibleDepositStr.replace(".0", "");
                    		}else if(deductibleDepositStr.endsWith(".00")) {
                    			deductibleDepositStr = deductibleDepositStr.replace(".00", "");
                    		}else if(deductibleDepositStr.contains(".") && deductibleDepositStr.endsWith("0")) {
                    			deductibleDepositStr = deductibleDepositStr.substring(0, deductibleDepositStr.lastIndexOf("0"));
                    		}
                    		
                    		pVo.setDeductibleDepositDesc("订金" + depositStr + "可抵" + deductibleDepositStr);
                    	}
                	}
				}else {

					pVo.setSellPrice(DoubleUtils.divide(Double.valueOf(String.valueOf(p.getSalePrice())), 100D, 2));
				}
				
				pVoList.add(pVo);
			}
		}
		
		return pVoList;
	}
}
