package com.gome.meidian.grouporder.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.ActivityManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.ActivityPage;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

import redis.Gcache;

@RestController
@Validated
@RequestMapping("/v1/activityPage")
public class ActivityPageController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private ActivityManager activityManager;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认三级区域，朝阳，全国价
    @Value("${gome.defaultStoreCode}")
    private String defaultStoreCode;
    
	
	/**
	 * 组团活动页
	 * @param ukey
	 * @param areaCode
	 * @param organizationId
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getGroupActivityPage", method = RequestMethod.GET)
	public ResponseJson getGroupActivityPage(
			@NotBlank(message = "{param.error}") @RequestParam("uniqueKey") String ukey,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
		
		String key = ukey + "_" + "groupActivityPage";
		
		// 拉取缓存
//		ActivityPage activityPage = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-interface", key), ActivityPage.class);
		ActivityPage activityPage = JSONObject.parseObject(gcache.get("groupActivityPageInterface_" + key), ActivityPage.class);
		if(null == activityPage){
			activityPage = activityManager.getGroupActivityPage(ukey, areaCode, MeidianEnvironment.getPPI(), ua);
			// 添加到缓存
//			gcache.hset("meidian-restful-grouporder-interface", key, JSONUtils.toJSONString(activityPage).getBytes());
			gcache.setex("groupActivityPageInterface_" + key, 3 * 60, JSONUtils.toJSONString(activityPage).getBytes());
		}
		
		// 处理图片
		List<Map<String, String>> proSkuMap = activityManager.groupActivityPage(activityPage, MeidianEnvironment.getPPI(), ua);
		
		// 美店价格处理
		activityManager.activityMeidianPrice(activityPage, proSkuMap, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getKey("priceReqStoreCode"));
		
		response.setData(activityPage);
		return response;
	}
	
	/**
	 * 立减活动页
	 * @param ukey
	 * @param areaCode
	 * @param organizationId
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getCouponActivityPage", method = RequestMethod.GET)
	public ResponseJson getCouponActivityPage(
			@NotBlank(message = "{param.error}") @RequestParam("uniqueKey") String ukey,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultStoreCode;
		
		String key = ukey + "_" + "couponActivityPage";
		
		// 拉取缓存
//		ActivityPage activityPage = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-interface", key), ActivityPage.class);
		ActivityPage activityPage = JSONObject.parseObject(gcache.get("couponActivityPageInterface_" + key), ActivityPage.class);
		if(null == activityPage){
			activityPage = activityManager.getCouponActivityPage(ukey, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
			// 添加到缓存
//			gcache.hset("meidian-restful-grouporder-interface", key, JSONUtils.toJSONString(activityPage).getBytes());
			gcache.setex("couponActivityPageInterface_" + key, 3 * 60, JSONUtils.toJSONString(activityPage).getBytes());
		}

		// 处理图片
		activityManager.groupActivityPage(activityPage, MeidianEnvironment.getPPI(), ua);
		
		response.setData(activityPage);
		return response;
	}
	
	/**
	 * 超级返活动页
	 * @param ukey
	 * @param areaCode
	 * @param organizationId
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getBuyRebateActivityPage", method = RequestMethod.GET)
	public ResponseJson getBuyRebateActivityPage(
			@NotBlank(message = "{param.error}") @RequestParam("uniqueKey") String ukey,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
		
		String key = ukey + "_" + "buyRebateActivityPage";
		
		// 拉取缓存
//		ActivityPage activityPage = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-interface", key), ActivityPage.class);
		ActivityPage activityPage = JSONObject.parseObject(gcache.get("buyRebateActivityPageInterface_" + key), ActivityPage.class);
		if(null == activityPage){
			activityPage = activityManager.getBuyRebateActivityPage(ukey, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
			// 添加到缓存
//			gcache.hset("meidian-restful-grouporder-interface", key, JSONUtils.toJSONString(activityPage).getBytes());
			gcache.setex("buyRebateActivityPageInterface_" + key, 3 * 60, JSONUtils.toJSONString(activityPage).getBytes());
		}
		
		// 处理图片
		activityManager.groupActivityPage(activityPage, MeidianEnvironment.getPPI(), ua);
				
		response.setData(activityPage);
		return response;
	}
}
