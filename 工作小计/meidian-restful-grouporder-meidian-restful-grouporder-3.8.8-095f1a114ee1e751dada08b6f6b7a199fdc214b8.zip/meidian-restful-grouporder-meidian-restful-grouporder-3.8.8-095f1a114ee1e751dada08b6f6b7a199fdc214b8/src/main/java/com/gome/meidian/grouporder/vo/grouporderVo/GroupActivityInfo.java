package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

/**
 * 组团活动信息
 * @author shichangjian
 *
 */
public class GroupActivityInfo implements Serializable{

	private static final long serialVersionUID = 2315361346456285386L;

	private Long id; 					// 活动id
	private Integer status; 			// 活动状态：0：初始状态；1：新建（编辑）；2：送审（待审核）；3：审核通过；4：生效中；5：过期；-1：作废；-2：审核不通过；-3：手动停用；-4：自动停用（超预算等）
	private Integer purchaseLimitNum; 	// 限购件数
	private Integer groupBusType; 		// 组团业务类型：1:常规返利,2:团长免单,3:0元团,4:开团有奖,5:官方多人团,6:5折开团,7:定金团,8:阶梯优惠团,9:新人团,10:秒杀团
	private Integer failGroupRefund; 	// 不成团退款,0:否,1:是
	private String maxDiscount;			// 最大折扣
	private Integer maxDiscountPeopleNum;// 最大折扣 需要的人数
	private Integer oldUserMaxNum;//老用户最大参团人数

	private Integer helpAllow; //是否允许助力 0:不允许,1:允许 （默认0）
	private String initialMaxMoney;//开团者最大返利（元）
	
	private Integer maxDiscountNeedPeopleNum; //冗余字段  同maxDiscountPeopleNum，等待前端优化后去掉其中一个
	public GroupActivityInfo() {
		super();
	}
	public GroupActivityInfo(
			Long id, Integer status, Integer purchaseLimitNum, 
			Integer groupBusType, Integer failGroupRefund, String maxDiscount,
			Integer maxDiscountPeopleNum,
			Integer oldUserMaxNum
			) {
		super();
		this.id = id;
		this.status = status;
		this.purchaseLimitNum = purchaseLimitNum;
		this.groupBusType = groupBusType;
		this.failGroupRefund = failGroupRefund;
		this.maxDiscount = maxDiscount;
		this.maxDiscountPeopleNum = maxDiscountPeopleNum;
		this.oldUserMaxNum = oldUserMaxNum;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getPurchaseLimitNum() {
		return purchaseLimitNum;
	}
	public void setPurchaseLimitNum(Integer purchaseLimitNum) {
		this.purchaseLimitNum = purchaseLimitNum;
	}
	public Integer getGroupBusType() {
		return groupBusType;
	}
	public void setGroupBusType(Integer groupBusType) {
		this.groupBusType = groupBusType;
	}
	public Integer getFailGroupRefund() {
		return failGroupRefund;
	}
	public void setFailGroupRefund(Integer failGroupRefund) {
		this.failGroupRefund = failGroupRefund;
	}
	public String getMaxDiscount() {
		return maxDiscount;
	}
	public void setMaxDiscount(String maxDiscount) {
		this.maxDiscount = maxDiscount;
	}
	public Integer getMaxDiscountPeopleNum() {
		return maxDiscountPeopleNum;
	}
	public void setMaxDiscountPeopleNum(Integer maxDiscountPeopleNum) {
		this.maxDiscountPeopleNum = maxDiscountPeopleNum;
	}
	public Integer getOldUserMaxNum() {
		return oldUserMaxNum;
	}
	public void setOldUserMaxNum(Integer oldUserMaxNum) {
		this.oldUserMaxNum = oldUserMaxNum;
	}
	public Integer getHelpAllow() {
		return helpAllow;
	}
	public void setHelpAllow(Integer helpAllow) {
		this.helpAllow = helpAllow;
	}
	public String getInitialMaxMoney() {
		return initialMaxMoney;
	}
	public void setInitialMaxMoney(String initialMaxMoney) {
		this.initialMaxMoney = initialMaxMoney;
	}
	public Integer getMaxDiscountNeedPeopleNum() {
		return maxDiscountNeedPeopleNum;
	}
	public void setMaxDiscountNeedPeopleNum(Integer maxDiscountNeedPeopleNum) {
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
	}
	
	
	
}
