package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

/**
 * 分享返，佣金入参
 * @author shichangjian
 *
 */
public class ShareRebateVo implements Serializable{

	private static final long serialVersionUID = 3284719877855951610L;

	@Valid
	private List<ShareRebate> shareRebates; 	// 分享返，佣金

	public List<ShareRebate> getShareRebates() {
		return shareRebates;
	}

	public void setShareRebates(List<ShareRebate> shareRebates) {
		this.shareRebates = shareRebates;
	}
	
}
