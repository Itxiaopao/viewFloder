package com.gome.meidian.grouporder.utils;

public class GroupOrderVerifyGroup {

	public interface groupOrderVerify{}
	public interface goodsProductVerify{}
	public interface groupProduct{}
	public interface shareRebate{}
	public interface buyRebate{}
	public interface activity{}
	public interface productCms{}
}
