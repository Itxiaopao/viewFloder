//package com.gome.meidian.grouporder.config;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.stereotype.Component;
//
//import com.gome.architect.idgnrt.IDGenerator;
//
////@Configuration
////public class Idgenerato {
////
////	@Value("${dubbo.registry.idGenerator_address}")
////	private String idGeneratorZK;
////	
////	@Bean(name = "iDGenerator", initMethod = "init")
////    public IDGenerator iDGenerator(){
////		IDGenerator iDGenerator = new IDGenerator(idGeneratorZK, "meidian_grouporder.code.id");
////		iDGenerator.init();
////		
////        return iDGenerator;
////    }
////}
