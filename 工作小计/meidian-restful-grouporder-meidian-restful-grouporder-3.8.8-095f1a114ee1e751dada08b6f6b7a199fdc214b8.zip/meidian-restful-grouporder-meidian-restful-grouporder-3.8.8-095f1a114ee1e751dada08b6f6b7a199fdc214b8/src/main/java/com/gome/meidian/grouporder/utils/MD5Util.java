package com.gome.meidian.grouporder.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.DigestUtils;

import com.gome.meidian.restfulcommon.utils.JSONUtils;

import sun.misc.BASE64Encoder;

public class MD5Util {
	public static String encode(String text){
		if(StringUtils.isNotBlank(text)){
			return DigestUtils.md5DigestAsHex(text.getBytes());
		}
		return null;
	}
	
	/**
	 * 
	 * @param pwd
	 *            需要加密的字符串
	 * @param type
	 *            字母大小写(false为默认小写，true为大写)
	 * @param bit
	 *            加密的类型（16,32,64）
	 * @return
	 */
	public static String getMD5(String pwd, boolean isUpper, Integer bit) {
		String md5 = new String();
		try {
			// 创建加密对象
			MessageDigest md = MessageDigest.getInstance("md5");
			if (bit == 64) {
				BASE64Encoder bw = new BASE64Encoder();
				String bsB64 = bw.encode(md.digest(pwd.getBytes("utf-8")));
				md5 = bsB64;
			} else {
				// 计算MD5函数
				md.update(pwd.getBytes());
				byte b[] = md.digest();
				int i;
				StringBuffer sb = new StringBuffer("");
				for (int offset = 0; offset < b.length; offset++) {
					i = b[offset];
					if (i < 0)
						i += 256;
					if (i < 16)
						sb.append("0");
					sb.append(Integer.toHexString(i));
				}
				md5 = sb.toString();
				if(bit == 16) {
					//截取32位md5为16位
					String md16 = md5.substring(8, 24).toString();
					md5 = md16;
					if (isUpper)
						md5 = md5.toUpperCase();
					return md5;
				}
			}
			//转换成大写
			if (isUpper)
				md5 = md5.toUpperCase();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
 
		return md5;
	}
	
    public static void main(String[] args) {   
    	String aa = MD5Util.getMD5("areaCode=11010000&activityId=6955&skuNo=100467212&productId=9140113920&skuId=1130570220", false, 16);
    	System.err.println(aa);
    	
    	// 缓存的
//    	gcache.setex(aa, 3 * 60, 参数);
//    	gcache.hset("总key", "aa", "参数");
    	
    	// 生成二维码的参数
//    	aa + "_01234567"; 
//    	aa
    	
    	// 端上换取参数使用
//    	aa
    } 
	    
}
