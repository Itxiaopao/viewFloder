package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.ProductDetailVo;

public class WanrenGroupListVo implements Serializable {

	private static final long serialVersionUID = 1176465468506839167L;
	private List<ProductDetailVo> allList;
	public List<ProductDetailVo> getAllList() {
		return allList;
	}
	public void setAllList(List<ProductDetailVo> allList) {
		this.allList = allList;
	}
	
}
