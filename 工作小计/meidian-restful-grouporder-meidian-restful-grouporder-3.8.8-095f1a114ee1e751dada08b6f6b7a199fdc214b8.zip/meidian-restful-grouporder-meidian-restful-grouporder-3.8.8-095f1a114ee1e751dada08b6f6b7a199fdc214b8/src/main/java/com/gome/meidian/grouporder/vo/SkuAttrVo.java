package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gome.stage.bean.item.SalesProperty;

public class SkuAttrVo implements Serializable{

	private static final long serialVersionUID = 7175157875756917712L;

	/** 附加信息 */
	private Map<String, String> affixAttr = new HashMap<>();
	/**ben 多销售属性信息 */
	private List<SalesProperty> salesProperty = new ArrayList<SalesProperty>();
	public Map<String, String> getAffixAttr() {
		return affixAttr;
	}
	public void setAffixAttr(Map<String, String> affixAttr) {
		this.affixAttr = affixAttr;
	}
	public List<SalesProperty> getSalesProperty() {
		return salesProperty;
	}
	public void setSalesProperty(List<SalesProperty> salesProperty) {
		this.salesProperty = salesProperty;
	}
	
	
}
