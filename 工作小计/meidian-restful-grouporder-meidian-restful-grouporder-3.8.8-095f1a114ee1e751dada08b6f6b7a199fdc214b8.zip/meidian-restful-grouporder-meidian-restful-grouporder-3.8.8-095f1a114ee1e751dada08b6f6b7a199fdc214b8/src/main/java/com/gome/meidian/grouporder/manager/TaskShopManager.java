package com.gome.meidian.grouporder.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.gome.meidian.grouporder.manager.mshopUserManager.MshopUserManager;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.MobileUtils;
import com.gome.meidian.grouporder.utils.UserConstants;
import com.gome.meidian.grouporder.vo.register.CheckShopVo;
import com.gome.meidian.grouporder.vo.register.ShopInfoVo;
import com.gome.meidian.grouporder.vo.register.TaskCmsVo;
import com.gome.meidian.grouporder.vo.register.TaskRewardVo;
import com.gome.meidian.grouporder.vo.register.TaskShopVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.sso.model.UserInfoCache;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.entity.VshopInvitationRelation;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;
import com.gomeo2o.facade.vshop.service.VshopInvitationRelationFacade;
import com.gomeplus.bs.framework.dubbor.vo.PageCollection;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.Cashback;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.Menus;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.SecondPageMI;
import com.gomeplus.bs.interfaces.mshop.task.service.MshopTMemberService;
import com.gomeplus.bs.interfaces.mshop.task.service.MshopTaskInfoResource;
import com.gomeplus.bs.interfaces.mshop.task.service.TaskInfoStatusMonitorResource;
import com.gomeplus.bs.interfaces.mshop.task.service.VshopInvitationRelationResource;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskInfoVo;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskRewardDetailVo;

import cn.com.gome.user.service.QueryUserInfoFacade;
import cn.com.gome.user.v2.model.StaffInfoVo;
import redis.Gcache;

@SuppressWarnings({"unchecked","rawtypes"})
@Service
public class TaskShopManager {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private MshopTaskInfoResource mshopTaskInfoResource;
	@Autowired
	private TaskInfoStatusMonitorResource taskInfoStatusMonitorResource;
	@Autowired
	private PageInfoResource pageInfoResource;
	@Autowired
	private VshopInvitationRelationResource vshopInvitationRelationResource;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private VshopInvitationRelationFacade vshopInvitationRelationFacade;
	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	@Autowired
	private VshopInfoExternalFacade vshopInfoExternalFacade;
	@Autowired
	private VshopFacade vshopFacade;
	@Autowired
	private MshopTMemberService mshopTMemberServiceImpl;
	@Autowired
	private MshopUserManager mshopUserManager;
	@Resource(name = "gcache")
	private Gcache gcache;

	private final String MSHOPTASKSHOPCMS="mshop_task_shop_cms:";//店主首页CMS数据
	private final String MSHOPINVITEKEY="mshop_invite_page:";//拉新活动页
	private final String MSHOPINVITEDETAILKEY="mshop_invite_detail_page:";//邀请明细
	private final String MSHOPINVITEHISTORYDETAILKEY="mshop_invite_history_detail_page:";//历史邀请明细
	private final String MIDTASKRELATION="mid_task_relation:";//店主和拉新任务的数据

	/**
	 * 获取店主首页数据
	 * @param taskCmsVo
	 * @return
	 * @throws MeidianException
	 */
	public Map<String,Object> taskShopInfo(TaskCmsVo taskCmsVo) throws MeidianException {
		Map<String,Object> map = new HashMap<String, Object>();
		//获取当前累计Gmv活动信息-活动状态
		try{
			TaskInfoVo taskInfo = mshopTaskInfoResource.getTaskInfoByGmv();
			Map<String,Object> taskMap = new HashMap<String, Object>();
			if(taskInfo!=null){
				map.put("taskStatus", UserConstants.TASK_EXIT);
				taskMap.put("taskId", taskInfo.getId());
				//统计邀请人数
				Map<String,Long> countMap = vshopInvitationRelationResource.selectCountInvitors(taskInfo.getId(),taskCmsVo.getUserId(),taskInfo.getStartTime(),taskInfo.getEndTime());
				taskMap.put("initCount", countMap.get("userNum"));
				map.put("taskInfo", taskMap);
			}else{
				map.put("taskStatus", UserConstants.TASK_NOEXIT);
				//最近活动
				List<TaskInfoVo> taskReal = new ArrayList<>();
				TaskInfoVo param = new TaskInfoVo();
				param.setType(4);
				List<TaskInfoVo> taskMore = taskInfoStatusMonitorResource.selectTasksByParam(param);
				for (TaskInfoVo task : taskMore) {
					if(task.getStatus().equals(4)||task.getStatus().equals(5)||task.getStatus().equals(-3)||task.getStatus().equals(-4)){
						taskReal.add(task);
					}
				}
				Collections.reverse(taskReal);
				TaskInfoVo taskInfoVo = taskReal.get(0);
				if(taskInfoVo!=null){
					taskMap.put("taskId", taskInfoVo.getId());
					//统计邀请人数
					Map<String,Long> countMap = vshopInvitationRelationResource.selectCountInvitors(taskInfoVo.getId(),taskCmsVo.getUserId(),taskInfoVo.getStartTime(),taskInfoVo.getEndTime());
					taskMap.put("initCount", countMap.get("userNum"));
					map.put("taskInfo", taskMap);
				}
			}
		}catch (Exception e){
			logger.info("任务活动数据,获取异常{}",e);
			map.put("taskStatus", UserConstants.TASK_NOEXIT);
		}
		//CMS数据添加缓存
		Map<String,Object> cmsMap = new HashMap<>();
		String taskShopCmsKey = MSHOPTASKSHOPCMS + taskCmsVo.getUserId();
		String gacheTSCK = gcache.get(taskShopCmsKey);
		if(StringUtils.isBlank(gacheTSCK)){
			cmsMap = this.getTaskShopCms(taskCmsVo);
			try{
				String resultJson = JSON.toJSONString(cmsMap);
				gcache.setex(taskShopCmsKey, 60, resultJson);
			}catch (Exception e){
				logger.info("店主首页CMS数据,缓存异常{}",e);
			}
		}else{
			cmsMap = JSON.parseObject(gacheTSCK,HashMap.class);
		}
		map.put("cmsInfo", cmsMap);
		return map;
	}
	//获取cms数据信息
	@SuppressWarnings("deprecation")
	public Map<String,Object> getTaskShopCms(TaskCmsVo taskCmsVo){
		Map<String,Object> cmsMap = new HashMap<String, Object>();
		SecondPageMI secondPageMI = pageInfoResource.getSecondPageMI(taskCmsVo.getPageCode(),taskCmsVo.getMshopCode(),taskCmsVo.getPortType());
		PageInfo defaultPageInfo = secondPageMI.getDefaultPageInfo();
		Map<String, Object> moduleJsonMap = secondPageMI.getModuleJsonMap();
		List<Menus> moduleMenuList = secondPageMI.getModuleMenuList();
		cmsMap.put("defaultPageInfo", defaultPageInfo);
		cmsMap.put("moduleJsonMap", moduleJsonMap);
		cmsMap.put("moduleMenuList", moduleMenuList);
		//获取商品模块信息
		List<Menus> list = secondPageMI.getPrdMenuList();
		for (Menus menus : list) {
			if(menus.getModuleType().equals(10)){//超级返类型
				List<Cashback> cashbacks = pageInfoResource.moduleCashbackList(taskCmsVo.getMshopCode(),menus.getModuleCode(),menus.getPageCode(),taskCmsVo.getPageNo(),taskCmsVo.getPageSize());
				cmsMap.put("cashbacks", cashbacks);
			}
		}
		return cmsMap;
	}
	
	/**
	 * 获取店主拉新详情
	 * @param taskShopVo
	 * @return
	 * @throws MeidianException
	 */
	public Map<String,Object> taskShopDesc(TaskShopVo taskShopVo) throws MeidianException {
		Map<String,Object> map = new HashMap<String, Object>();
		//从缓存读  读不到执行下面方法
		String userKey=MSHOPINVITEKEY + taskShopVo.getTaskId() + taskShopVo.getUserId();
		String gacheRs = gcache.get(userKey);
		if(StringUtils.isEmpty(gacheRs) || null==gacheRs) {
			map = this.getInviteData(taskShopVo.getTaskId(),taskShopVo.getUserId());
			try {
				String resultJson = JSON.toJSONString(map);
				gcache.setex(userKey, 60, resultJson);
			}catch (Exception e){
				logger.error("拉新活动页,缓存异常{}",e);
			}
		}else{
			map = JSON.parseObject(gacheRs,HashMap.class);
		}
		return map;
	}
	//获取店主拉新详情
	public Map<String,Object> getInviteData(Long taskId,Long userId) throws MeidianException {
		Map<String,Object> map = new HashMap<String, Object>();
		long currentTime = DateUtils.currentTimeSecs();
		//获取活动信息
		TaskInfoVo taskInfo = mshopTaskInfoResource.doGet(taskId);
		if(taskInfo!=null){
			//活动奖励金额
			map.put("taskPrice", taskInfo.getPaymentOnce());
			Integer status = taskInfo.getStatus();
			int subDay = 0;
			int countDay = 0;
            if(status!=null&&status.equals(4)){
            	subDay = (int) Math.ceil(((taskInfo.getEndTime().getTime())-currentTime)*1.0/(60*60*24*1000));//向上取整
            	if(subDay<0){ subDay=0; }
            	countDay = (int) Math.floor(((taskInfo.getEndTime().getTime())-(taskInfo.getStartTime().getTime()))*1.0/(60*60*24*1000));//向下取整
            }
			//活动剩余天数
			map.put("subDay", subDay);
			//活动总天数
			map.put("countDay", countDay);
			//统计邀请人数
			Map<String,Long> countMap = vshopInvitationRelationResource.selectCountInvitors(taskId,userId,taskInfo.getStartTime(),taskInfo.getEndTime());
			//获取当前用户的邀请数据
			map.put("subUserNum", countMap.get("userNum"));
			//累计奖金
			map.put("subPrice", countMap.get("rewardCount"));
		}else{
			throw new ServiceException("base.shop.gmv.outAct");
		}
		return map;
	}

	/**
	 * 邀请明细
	 * @param vo
	 * @return
	 * @throws MeidianException
	 */
	public PageCollection<TaskRewardDetailVo> taskInviteDetail(TaskRewardVo taskRewardVo) throws MeidianException {
    	//获取明细
    	PageCollection<TaskRewardDetailVo> result = new PageCollection<>();
		String userKey = MSHOPINVITEDETAILKEY + taskRewardVo.getTaskId() + taskRewardVo.getInviterUserId() + String.valueOf(taskRewardVo.getPageNo()) + String.valueOf(taskRewardVo.getPageSize());
		String gacheRs = gcache.get(userKey);
		if(StringUtils.isEmpty(gacheRs) || null==gacheRs) {
			TaskRewardDetailVo taskRewardDetailVo = new TaskRewardDetailVo();
			BeanUtils.copyProperties(taskRewardVo, taskRewardDetailVo);
			result = vshopInvitationRelationResource.selectInvitorsDetail(taskRewardDetailVo);
			try {
				String resultJson = JSON.toJSONString(result);
				gcache.setex(userKey, 60, resultJson);
			}catch (Exception e){
				logger.error("邀请明细,缓存异常{}",e);
			}
		}else{
			result = JSON.parseObject(gacheRs,PageCollection.class);
		}
		return result;
    }
	
	/**
	 * 获取历史活动邀请明细
	 * @param userId
	 * @return
	 * @throws MeidianException
	 */
	public List<Map<String,Object>> historyInviteDetail(Long userId) throws MeidianException {
		List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
		String userKey = MSHOPINVITEHISTORYDETAILKEY + userId;
		String gacheRs = gcache.get(userKey);
		if(StringUtils.isEmpty(gacheRs) || null==gacheRs) {
			listMap = this.getHistoryInviteData(userId);
			try {
				String resultJson = JSON.toJSONString(listMap);
				gcache.setex(userKey, 60, resultJson);
			}catch (Exception e){
				logger.error("拉新活动页,缓存异常{}",e);
			}
		}else{
			listMap = JSON.parseObject(gacheRs,ArrayList.class);
		}
		return listMap;
    }
	//获取历史活动邀请明细
	public List<Map<String,Object>> getHistoryInviteData(Long userId) throws MeidianException {
		List<Map<String,Object>> listMap = new ArrayList<Map<String,Object>>();
		//获取有效活动信息
		List<TaskInfoVo> taskReal = new ArrayList<>();
		TaskInfoVo param = new TaskInfoVo();
		param.setType(4);
		List<TaskInfoVo> taskMore = taskInfoStatusMonitorResource.selectTasksByParam(param);
		for (TaskInfoVo task : taskMore) {
			if(task.getStatus().equals(4)||task.getStatus().equals(5)||task.getStatus().equals(-3)||task.getStatus().equals(-4)){
				taskReal.add(task);
			}
		}
		for (TaskInfoVo task : taskReal) {
			Map<String,Object> map = new HashMap<>();
			//统计邀请人数
			Map<String,Long> initMap = vshopInvitationRelationResource.selectCountInvitors(task.getId(),userId,task.getStartTime(),task.getEndTime());
			//邀请人数和奖励金额
			Long userNum = initMap.get("userNum");
			Long rewardAmount = initMap.get("rewardCount");
			//累计奖金
			map.put("rewardAmount", rewardAmount);
			if(task.getStatus().equals(4)){
				map.put("taskStatus", 1);
			}else{
				map.put("taskStatus", 0);
			}
			if(userNum.longValue()>0){
				map.put("partStatus", 1);
				map.put("userNum", userNum);
			}else{
				map.put("partStatus", 0);
			}
			map.put("taskId", task.getId());
			listMap.add(map);
		}
		Collections.reverse(listMap);
		return listMap;
	}
	
	/**
	 * 累计GMV任务邀请开店
	 * @param shopInfoVo
	 * @throws MeidianException
	 */
	@Transactional
	public ResponseJson savaInitTaskShop(ShopInfoVo shopInfoVo,String scn) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		//获取登录人信息
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		if (userInfo == null || userInfo.getId() == null || userInfo.getId().equals("")) {
			throw new ServiceException("group.operation.notLoggin");
		}
		Long inviteUserId = shopInfoVo.getInviteUserId();
		if (inviteUserId == null || inviteUserId.equals(0L)) {
			//没有邀请人不允许开店
			throw new ServiceException("mshop.user.authentication.illegal");
		}
		long userId = Long.parseLong(userInfo.getId());
		//验证店铺名称
		this.checkShopName(shopInfoVo.getName(), userId);
		logger.info("用户id:{},邀请人id:{},店铺名称:{}", userId, shopInfoVo.getInviteUserId(), shopInfoVo.getName());
		//手机号校验
		boolean checkStatus = MobileUtils.isPhone(shopInfoVo.getPhoneNo());
		if (!checkStatus) {
			throw new ServiceException("base.user.mobile.noCheck");
		}
		//判定登录人是否开店
		CommonResultEntity<VshopInfo> userShopInfo = vshopInfoExternalFacade.queryVshopInfoByUserId(userId);
		if (userShopInfo != null && userShopInfo.getCode() == 0) {
			VshopInfo vshopInfo = userShopInfo.getBusinessObj();
			if (vshopInfo != null && vshopInfo.getVshopId() != 0) {//已开通店铺
				throw new ServiceException("base.shop.user.exit");
			}
		} else {
			responseJson.setCode(userShopInfo.getCode());
			responseJson.setMsg(userShopInfo.getMessage());
			return responseJson;
		}
		//邀请开店 - 邀请人是否开通店铺
		Long initVShopId = null;
		CommonResultEntity<VshopInfo> initUserShopInfo = vshopInfoExternalFacade.queryVshopInfoByUserId(inviteUserId);
		if (initUserShopInfo != null && initUserShopInfo.getCode() == 0) {
			VshopInfo vshopInfo = initUserShopInfo.getBusinessObj();
			if (vshopInfo == null || vshopInfo.getVshopId() == 0) {//未开通
				throw new ServiceException("base.shop.initUser.noExit");
			} else {
				initVShopId = vshopInfo.getVshopId();
			}
		} else {
			responseJson.setCode(initUserShopInfo.getCode());
			responseJson.setMsg(initUserShopInfo.getMessage());
			return responseJson;
		}

		//记录邀请关系-创建店铺
		VshopInfo vshopInfo = this.assembleVshopInfo(shopInfoVo);
		vshopInfo.setUserId(userId);
		//创建店铺
		Long shopId = 0l;
		try {
			CommonResultEntity<String> commonResultEntity = vshopFacade.createVshop2(vshopInfo);
			if (commonResultEntity != null && commonResultEntity.getCode() == 0) {
				String shopIdStr = commonResultEntity.getBusinessObj();
				if (shopIdStr != null && !shopIdStr.equals("")) {
					shopId = Long.valueOf(shopIdStr);
					this.saveVshopInvitationRelation(userId, shopId, inviteUserId, initVShopId);
					mshopUserManager.synInvitateRelate(userId, shopId, inviteUserId);

				} else {
					throw new ServiceException("base.shop.sava.exception");
				}
			} else {
				//创建店铺失败
				responseJson.setCode(commonResultEntity.getCode());
				responseJson.setMsg(commonResultEntity.getMessage());
				return responseJson;
			}
		} catch (Exception e) {
			logger.info("保存店铺信息失败,用户id:{},手机号:{}", userId, vshopInfo.getPhoneNo());
			throw new ServiceException("base.shop.sava.exception");
		}
		//返回美店信息
		CommonResultEntity<VshopInfo> vshopInfoBak = vshopFacade.queryVshopById(shopId);
		VshopInfo businessObj = vshopInfoBak.getBusinessObj();
		responseJson.setData(businessObj);
		return responseJson;
	}
	
	/**
	 * 校验店铺名称和手机号是否存在
	 * @param checkShopVo
	 * @return
	 * @throws MeidianException
	 * @throws Exception
	 */
	public ResponseJson checkVshopNamePhoneNo(CheckShopVo checkShopVo) throws MeidianException,Exception {
		ResponseJson responseJson = new ResponseJson();
		//店铺名称校验
		VshopInfo vshopInfo1 = new VshopInfo();
		vshopInfo1.setVshopId(0);
		vshopInfo1.setVshopName(checkShopVo.getName());
		CommonResultEntity<Boolean> vshopName = vshopFacade.checkVshopName(vshopInfo1);
		if(vshopName.getCode()==0){
			Boolean vshopNameStatus = vshopName.getBusinessObj();
			if(vshopNameStatus){
				throw new ServiceException("base.shop.name.exit");
			}
		}else{
			responseJson.setCode(vshopName.getCode());
			responseJson.setMsg(vshopName.getMessage());
		}
		//手机号校验
		VshopInfo vshopInfo2 = new VshopInfo();
		vshopInfo2.setVshopId(0);
		vshopInfo2.setPhoneNo(checkShopVo.getPhoneNo());
		CommonResultEntity<Boolean> vshopPhoneNo = vshopFacade.checkVshopPhoneNo(vshopInfo2);
		if(vshopPhoneNo.getCode()==0){
			Boolean vshopPhoneNoStatus = vshopPhoneNo.getBusinessObj();
			if(vshopPhoneNoStatus){
				throw new ServiceException("base.shop.phoneNo.exit");
			}
		}else{
			responseJson.setCode(vshopPhoneNo.getCode());
			responseJson.setMsg(vshopPhoneNo.getMessage());
		}
		return responseJson;
	}
	
	//邀请开店 - 创建邀请关系
	@Transactional
	public void saveVshopInvitationRelation(long userId,Long shopId,Long inviteUserId,Long initVShopId) throws MeidianException {
		try{
			//创建美店邀请关系
			VshopInvitationRelation vshopInvitationRelation = new VshopInvitationRelation();
			vshopInvitationRelation.setReceiverUserId(userId);
			vshopInvitationRelation.setReceiverVshopId(shopId);
			vshopInvitationRelation.setInviterUserId(inviteUserId);
			vshopInvitationRelation.setInviterVshopId(initVShopId);
			//查询当前最新GMV活动
			TaskInfoVo taskInfo = mshopTaskInfoResource.getTaskInfoByGmv();
			if(taskInfo!=null){
				vshopInvitationRelation.setTaskId(taskInfo.getId());
				//获取开店时间
				long openTime = 0l;
				CommonResultEntity<VshopInfo> commonResultEntity = vshopInfoExternalFacade.queryVshopById(shopId);
				if(commonResultEntity != null && commonResultEntity.getCode()==0){
					VshopInfo vshopInfo = commonResultEntity.getBusinessObj();
					if(vshopInfo!=null){
						openTime = vshopInfo.getCreateTime().getTime();
					}
				}
				if(openTime==0l){
					openTime = DateUtils.currentTimeSecs();
				}
				//获取任务延长时间
				long orderTime = 0l;
				Integer orderDay = taskInfo.getOrderDay();
				if(orderDay!=null){
					long orderLongDay = (long) orderDay;
					orderTime = (orderLongDay*24*60*60*1000);
				}
				vshopInvitationRelation.setActiveTime(new Date(openTime+orderTime));
				//缓存mid对应拉新有效信息
				String midTask = MIDTASKRELATION + shopId;
				String resultJson = JSON.toJSONString(vshopInvitationRelation);
				gcache.setnx(midTask,resultJson);
			}
			logger.info("邀请开店活动信息中用户id:{},邀请人id:{},活动id:{}",userId,inviteUserId,vshopInvitationRelation.getTaskId());
			vshopInvitationRelationFacade.createVshopInvitationRelation(vshopInvitationRelation);
			//同步店主团长-被邀人和邀请人的mid
			mshopTMemberServiceImpl.queryOrInsertMember(shopId, initVShopId);
		}catch(Exception e){
			logger.info("邀请开店失败,用户id:{},邀请人id:{}",userId,inviteUserId);
			throw new ServiceException("base.shop.initRelation.exception");
		}
	}
	
	//封装店铺信息
	public VshopInfo assembleVshopInfo(ShopInfoVo shopInfoVo){
		VshopInfo vshopInfo = new VshopInfo();
		vshopInfo.setVshopType(1);
		vshopInfo.setVshopBgimage("1");
		String name = shopInfoVo.getName();
		if(StringUtils.isNotBlank(name)){
			vshopInfo.setVshopName(name);
		}
		String phoneNo = shopInfoVo.getPhoneNo();
		if(StringUtils.isNotBlank(phoneNo)){
			vshopInfo.setPhoneNo(phoneNo);
		}
		String weChat = shopInfoVo.getWeChat();
		if(StringUtils.isNotBlank(weChat)){
			vshopInfo.setWeChat(weChat);
		}
		Long provinceId = shopInfoVo.getProvinceId();
		if(provinceId!=null&&!provinceId.equals(0)){
			vshopInfo.setProvinceId(provinceId);
		}
		Long cityId = shopInfoVo.getCityId();
		if(cityId!=null&&!cityId.equals(0)){
			vshopInfo.setCityId(cityId);
		}
		Long countyId = shopInfoVo.getCountyId();
		if(countyId!=null&&!countyId.equals(0)){
			vshopInfo.setCountyId(countyId);
		}
		Integer userSex = shopInfoVo.getUserSex();
		if(userSex!=null&&!userSex.equals(0)){
			vshopInfo.setUserSex(userSex);
		}
		String userHobby = shopInfoVo.getUserHobby();
		if(StringUtils.isNotBlank(userHobby)){
			vshopInfo.setUserHobby(userHobby);
		}
		return vshopInfo;
	}
	
	//验证店铺名称
	public void checkShopName(String name,Long userId) throws MeidianException {
		//是否员工美店校验‘国美’敏感字
		CommonResultEntity<StaffInfoVo> res = queryUserInfoFacade.getStaffInfoByUserId(String.valueOf(userId));
		if (res != null && res.getCode() != 0) {
			logger.info("getStaffInfoByUserId happened error,userId: {}", userId);
		} else if (res != null) {
			if(name.indexOf("国美")!=-1){
				throw new ServiceException("base.shop.staff.name.exception");
			}
		}
	}
	
}
