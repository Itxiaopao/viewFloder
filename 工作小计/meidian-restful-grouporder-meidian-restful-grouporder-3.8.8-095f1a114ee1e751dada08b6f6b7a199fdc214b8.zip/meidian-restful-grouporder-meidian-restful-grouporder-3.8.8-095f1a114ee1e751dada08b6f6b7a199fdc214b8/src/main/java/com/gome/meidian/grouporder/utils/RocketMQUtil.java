package com.gome.meidian.grouporder.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.rocketmq.client.exception.MQBrokerException;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.common.message.Message;
import com.alibaba.rocketmq.remoting.exception.RemotingException;

@Component("rocketMQUtil")
public class RocketMQUtil {
	
	private static Logger logger = LoggerFactory.getLogger(RocketMQUtil.class);
	
	@Value("${rocketmq.producer.topic}")
    private String topic;
    @Value("${rocketmq.producer.tag}")
    private String tag;
    @Autowired
	private DefaultMQProducer producer;
    public void send(String messageSend) throws MQClientException, RemotingException, MQBrokerException, InterruptedException{
    	Message aliMessage = new Message(
				topic, tag, (messageSend).getBytes());
		producer.send(aliMessage);
		logger.info("成功发送一条消息为：{}",aliMessage);
    }

}
