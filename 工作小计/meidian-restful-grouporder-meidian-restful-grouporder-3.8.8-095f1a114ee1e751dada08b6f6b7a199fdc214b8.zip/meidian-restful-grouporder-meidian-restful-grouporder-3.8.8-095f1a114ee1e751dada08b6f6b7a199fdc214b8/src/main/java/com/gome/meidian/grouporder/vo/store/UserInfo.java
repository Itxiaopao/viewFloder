package com.gome.meidian.grouporder.vo.store;

import java.io.Serializable;

public class UserInfo implements Serializable{

	private static final long serialVersionUID = 6176394296982614261L;

	private Long userId;
	private String staffNo;				// 员工编号
	private String staffName;			// 员工姓名
	private String storeCode;			// 门店编码
	private String bigAreaCode;			// 大区
	private String stairDepartmentId;	// 一级分部
	private String secondDepartmentId;	// 二级分部
	
	public UserInfo() {
		super();
	}
	public UserInfo(Long userId, String staffNo, String storeCode, 
			String bigAreaCode, String stairDepartmentId, String secondDepartmentId,
			String staffName
			) {
		super();
		this.userId = userId;
		this.staffNo = staffNo;
		this.storeCode = storeCode;
		this.bigAreaCode = bigAreaCode;
		this.stairDepartmentId = stairDepartmentId;
		this.secondDepartmentId = secondDepartmentId;
		this.staffName = staffName;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getStaffNo() {
		return staffNo;
	}
	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}
	public String getStoreCode() {
		return storeCode;
	}
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}
	public String getBigAreaCode() {
		return bigAreaCode;
	}
	public void setBigAreaCode(String bigAreaCode) {
		this.bigAreaCode = bigAreaCode;
	}
	public String getStairDepartmentId() {
		return stairDepartmentId;
	}
	public void setStairDepartmentId(String stairDepartmentId) {
		this.stairDepartmentId = stairDepartmentId;
	}
	public String getSecondDepartmentId() {
		return secondDepartmentId;
	}
	public void setSecondDepartmentId(String secondDepartmentId) {
		this.secondDepartmentId = secondDepartmentId;
	}
	public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	
	
}
