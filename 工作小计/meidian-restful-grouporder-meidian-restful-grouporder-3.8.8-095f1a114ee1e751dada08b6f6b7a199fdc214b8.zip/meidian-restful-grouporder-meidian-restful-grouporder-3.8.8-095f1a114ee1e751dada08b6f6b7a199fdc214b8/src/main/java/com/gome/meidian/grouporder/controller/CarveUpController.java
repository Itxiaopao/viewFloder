package com.gome.meidian.grouporder.controller;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.CarveUpManager;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.carveUp.AttendCarveUpVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpActivity.CarveUpActivityInfoVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpDetail.CarveUpDetailVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpInfo.CarveUpBoardVo;
import com.gome.meidian.grouporder.vo.carveUp.carveUpInfo.CarveUpInfoVo;
import com.gome.meidian.grouporder.vo.carveUp.myCarveUpList.CarveUpGroupVo;
import com.gome.sso.model.UserInfoCache;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;

import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 瓜分团controller
 */
@RestController
@RequestMapping("/v1/carveUp")
public class CarveUpController {
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private CarveUpManager carveUpManager;


	@Value("${gome.defaultStoreCode}")
	private String defaultStoreCode; // 默认门店，西坝河

	/**
	 * 根据页面code和模块code获取瓜分团活动列表
	 * @param pageCode
	 * @param moduleCode
	 * @param storeCode
	 * @param pageNo
	 * @param pageSize
	 * @param ppi
	 * @param scn
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/carveUpActivityList")
	public ResponseJson carveUpActivityList(
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode", required = true) String pageCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "moduleCode", required = true) String moduleCode,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@RequestParam(value = "pageNo", defaultValue = "1") Long pageNo,
			@RequestParam(value = "pageSize", defaultValue = "10") Long pageSize,
			@CookieValue(value = "storeCode", required = false) String StoreCode,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "SCN", required = false) String scn,
			HttpServletRequest request
	) throws MeidianException {
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String userId = null;
		Map<String, Object> resultMap = new HashMap<>();
		if(null != userInfo && StringUtils.isNotBlank(userId = userInfo.getId())){
			// 获取设备
			Byte ua = ImageUtils.userAgentChannel(request);
			String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
			List<CarveUpActivityInfoVo> list = carveUpManager.carveUpActivityList(stoCode, moduleCode, pageCode, pageNo, pageSize, Long.parseLong(userId), ppi, ua);
			
			resultMap.put("carveUpGroups", list);
			resultMap.put("login", 1);   //登录态

		}else{
			resultMap.put("login", 0);
//			throw new ServiceException("group.operation.notLoggin");
		}
		response.setData(resultMap);
		return response;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/carveUpGroupDetail")
	public ResponseJson carveUpGroupDetail(
			@Min(message = "{param.error}", value = 1) @RequestParam(value = "carveId", required = true) Long carveId,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException {
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		Long userId = null;
		Map<String, Object> resultMap = new HashMap<>();
		if(null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
			CarveUpDetailVo carveDetail = carveUpManager.carveUpGroupDetail(carveId, userId);
			
			resultMap.put("carveDetail", carveDetail);
			resultMap.put("login", 1);
			
		}else {
			resultMap.put("login", 0);
		}
		response.setData(resultMap);
		return response;
	}
	/**
	 * 我的瓜分团列表
	 * @param state 瓜分团状态：0-全部，1-进行中，2-已完成，3-已结束
	 * @param pageNum 页码，默认1
	 * @param pageSize 条数，默认10
	 * @param scn 需要用户登录
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/myCarveUpGroupList")
	public ResponseJson myCarveUpGroupList(
			@Pattern(regexp="^[0-3]{1}$",message="{param.error}") @RequestParam(value = "state", required = true, defaultValue = "0") String state,
			@RequestParam(value = "pageNum", required = true, defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
			@CookieValue(required = false, value = "SCN") String scn
	) throws MeidianException {
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String userId = null;
		Map<String, Object> resultMap = new HashMap<>();
		if(null != userInfo && StringUtils.isNotBlank(userId = userInfo.getId())){
			List<CarveUpGroupVo> list = carveUpManager.myCarveUpGroupList(Long.parseLong(userId), Integer.parseInt(state), pageSize, pageNum);
			
			resultMap.put("myGroupList", list);
			resultMap.put("login", 1);

		}else{
			resultMap.put("login", 0);
//			throw new ServiceException("group.operation.notLoggin");
		}
		response.setData(resultMap);
		return response;
	}

	/**
	 * 瓜分团开团、参团
	 * @param attendCarveUpVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PostMapping("/attendCarveUpGroup")
	public ResponseJson attendCarveUpGroup(
			@RequestBody @Valid AttendCarveUpVo attendCarveUpVo,
			@CookieValue(required = false, value = "SCN") String scn
	) throws MeidianException {
			ResponseJson response = new ResponseJson();
			UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
			String userId = null;
			Map<String, Object> resultMap = new HashMap<>();
			if(null != userInfo && StringUtils.isNotBlank(userId = userInfo.getId())){
				resultMap = carveUpManager.attendCarveUpGroup(Long.parseLong(userId), attendCarveUpVo.getCarveId(), attendCarveUpVo.getGroupId());
				resultMap.put("login", 1);
				if(resultMap.containsKey("message")) {
					response.setMsg(resultMap.get("message").toString());
					resultMap.remove("message");
				}
			}else{
				resultMap.put("login", 0);
//				throw new ServiceException("group.operation.notLoggin");
			}
			response.setData(resultMap);
			return response;
	}

	/**
	 * 瓜分团详情
	 * @param groupId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/carveUpGroupInfo")
	public ResponseJson carveUpGroupInfo(
			@Min(message = "{param.error}", value = 1) @RequestParam(value = "groupId", required = true) Long groupId,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "SCN", required = false) String scn,
			HttpServletRequest request
	) throws MeidianException {
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String userId = null;
		Map<String, Object> resultMap = new HashMap<>();
		if(null != userInfo && StringUtils.isNotBlank(userId = userInfo.getId())){
			// 获取设备
			Byte ua = ImageUtils.userAgentChannel(request);
			CarveUpInfoVo carveInfo = carveUpManager.carveUpGroupInfo(Long.parseLong(userId), groupId, ppi, ua);
			resultMap.put("carveUpInfo", carveInfo);
			resultMap.put("login", 1);
		}else{
			resultMap.put("login", 0);
//			throw new ServiceException("group.operation.notLoggin");
		}
		response.setData(resultMap);
		return response;
	}

	/**
	 * 榜单列表
	 * @param groupId  团ID
	 * @param pageNum  页码
	 * @param pageSize  条数
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/rankGroupInfo")
	public ResponseJson rankGroupInfo(
			@Min(message = "{param.error}", value = 1) @RequestParam(value = "groupId", required = true) Long groupId,
			@RequestParam(value = "pageNum", required = true, defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", required = true, defaultValue = "10") Integer pageSize,
			@CookieValue(value = "SCN", required = false) String scn
	) throws MeidianException {
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String userId = null;
		Map<String, Object> resultMap = new HashMap<>();
		if(null != userInfo && StringUtils.isNotBlank(userId = userInfo.getId())){
			CarveUpBoardVo board = carveUpManager.rankGroupInfo(Long.parseLong(userId), groupId, pageNum, pageSize);
			resultMap.put("boardInfo", board);
			resultMap.put("login", 1);
		}else{
			resultMap.put("login", 0);
//			throw new ServiceException("group.operation.notLoggin");
		}
		response.setData(resultMap);
		return response;
	}

}
