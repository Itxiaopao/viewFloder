package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 618
 * 数字门店banner
 * @author shichangjian
 *
 */
public class BannerImage implements Serializable{

	private static final long serialVersionUID = 3560108593382399620L;
	
	private String image;
	private String productId;
	private String type;
	private String title;
	private String target;
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	
	

}
