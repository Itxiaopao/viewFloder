package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;

public class ImageElement implements Serializable{

	private static final long serialVersionUID = -8639570683089069120L;

	private String imageUrl;	// 图片
	private String target;		// 跳转地址
	private String title;		// 标题
	private String button;		// 按钮
	private String itemName;	//图片名称（跳转分享时后台配置用）

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getButton() {
		return button;
	}
	public void setButton(String button) {
		this.button = button;
	}
	
	
}
