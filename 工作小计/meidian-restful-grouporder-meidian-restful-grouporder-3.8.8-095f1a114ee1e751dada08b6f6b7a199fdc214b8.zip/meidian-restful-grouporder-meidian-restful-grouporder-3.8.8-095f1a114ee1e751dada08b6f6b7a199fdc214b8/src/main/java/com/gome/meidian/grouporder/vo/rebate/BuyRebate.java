package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.buyRebate;

/**
 * 购买返入参
 * @author shichangjian
 *
 */
public class BuyRebate implements Serializable{

	private static final long serialVersionUID = -646457128607518113L;

	@NotBlank(message = "{param.error}", groups = { buyRebate.class})
	private String productId;
	@NotBlank(message = "{param.error}", groups = { buyRebate.class})
	private String skuNo;
	@NotBlank(message = "{param.error}", groups = { buyRebate.class})
	private String salePrice;
	@NotNull(message = "{param.error}", groups = { buyRebate.class})
	private Integer selfJointRebate;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public String getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(String salePrice) {
		this.salePrice = salePrice;
	}
	public Integer getSelfJointRebate() {
		return selfJointRebate;
	}
	public void setSelfJointRebate(Integer selfJointRebate) {
		this.selfJointRebate = selfJointRebate;
	}
	
	
}
