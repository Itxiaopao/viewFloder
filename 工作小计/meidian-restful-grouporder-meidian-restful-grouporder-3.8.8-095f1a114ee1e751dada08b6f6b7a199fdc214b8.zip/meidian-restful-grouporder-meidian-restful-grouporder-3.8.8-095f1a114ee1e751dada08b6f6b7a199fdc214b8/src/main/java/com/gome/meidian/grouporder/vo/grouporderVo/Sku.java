package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.gome.frontSe.comm.FSImgBase;
import com.gome.meidian.grouporder.vo.coupon.Promotion;
import com.gome.meidian.grouporder.vo.product.AppreciationServeType;
import com.gome.stage.bean.item.Skution;

/**
 * sku基本信息
 * @author shichangjian
 *
 */
public class Sku implements Serializable{

	private static final long serialVersionUID = -7507386088258406809L;

	private String displayName;									// sku名称
	private String price;										// sku价格
	private String gomePrice;               					// 国美区域价格
	private String priceKey;									// 快速购，传购物车，促销id密文
	private String shopNo;										// 店铺id
	private String skuId;
	private String skuNo;
	private Integer state;										// 商品状态
	private List<FSImgBase> skuImgs;							// sku图片
	private Map<String, Skution> skutionmap;
	private SkuEnergyAllowanceVo skuEnergyAllowance;  			//节能补贴信息
	private List<AppreciationServeType> appreciationServeTypes;	// 增值服务
	private List<Promotion> promotions;							// 促销语
	private String priceType;	// 价格类型
	
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getShopNo() {
		return shopNo;
	}
	public void setShopNo(String shopNo) {
		this.shopNo = shopNo;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public Map<String, Skution> getSkutionmap() {
		return skutionmap;
	}
	public void setSkutionmap(Map<String, Skution> skutionmap) {
		this.skutionmap = skutionmap;
	}
	public List<FSImgBase> getSkuImgs() {
		return skuImgs;
	}
	public void setSkuImgs(List<FSImgBase> skuImgs) {
		this.skuImgs = skuImgs;
	}
	public String getPriceKey() {
		return priceKey;
	}
	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}

	public String getGomePrice() {
		return gomePrice;
	}
	public void setGomePrice(String gomePrice) {
		this.gomePrice = gomePrice;
	}


	public SkuEnergyAllowanceVo getSkuEnergyAllowance() {
		return skuEnergyAllowance;
	}
	public void setSkuEnergyAllowance(SkuEnergyAllowanceVo skuEnergyAllowance) {
		this.skuEnergyAllowance = skuEnergyAllowance;
	}
	public List<AppreciationServeType> getAppreciationServeTypes() {
		return appreciationServeTypes;
	}
	public void setAppreciationServeTypes(List<AppreciationServeType> appreciationServeTypes) {
		this.appreciationServeTypes = appreciationServeTypes;
	}
	public List<Promotion> getPromotions() {
		return promotions;
	}
	public void setPromotions(List<Promotion> promotions) {
		this.promotions = promotions;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}



}
