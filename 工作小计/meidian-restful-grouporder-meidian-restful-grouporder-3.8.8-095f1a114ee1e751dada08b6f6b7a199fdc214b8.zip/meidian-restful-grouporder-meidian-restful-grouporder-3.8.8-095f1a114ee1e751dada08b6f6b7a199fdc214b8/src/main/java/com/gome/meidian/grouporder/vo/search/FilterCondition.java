package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;
import java.util.List;

public class FilterCondition implements Serializable{
	
	private static final long serialVersionUID = -8035885742925545727L;
	private String filterConId;//过滤条件Id
	private String index;//位置
	//private String filterModel;
	private String filterConName;//条件名称
	private String sortByPinyin;//是否按拼音排序
	//private String isHot;
	//private String filterType;
	private List<FilterValInfo>  filterValList;
	public String getFilterConId() {
		return filterConId;
	}
	public void setFilterConId(String filterConId) {
		this.filterConId = filterConId;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getFilterConName() {
		return filterConName;
	}
	public void setFilterConName(String filterConName) {
		this.filterConName = filterConName;
	}
	public String getSortByPinyin() {
		return sortByPinyin;
	}
	public void setSortByPinyin(String sortByPinyin) {
		this.sortByPinyin = sortByPinyin;
	}
	public List<FilterValInfo> getFilterValList() {
		return filterValList;
	}
	public void setFilterValList(List<FilterValInfo> filterValList) {
		this.filterValList = filterValList;
	}
	

}
