package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;
import java.util.List;

/**
 * 根据producId-skuId，imageSize获取商品信息，没有价格
 * @author shichangjian
 *
 */
public class ProductCms implements Serializable{

	private static final long serialVersionUID = 4123218173139792142L;

	private String productId;
	private String skuId;
	private String skuNo;
	private String name;				// 商品名称
	private String siteId;				// 站点
	private String mainImage;			// 商品主图图片
	private List<String> goodsImgUrls;	// 商品所有图片
	private String detailHref;			// 商品详情页地址
    private String specialType;			// 特殊商品标识,0正常，1不可单卖
    private String skuMappingSuit;		// 真实skuId 对应的 虚拟skuId
    
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSiteId() {
		return siteId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public String getMainImage() {
		return mainImage;
	}
	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}
	public List<String> getGoodsImgUrls() {
		return goodsImgUrls;
	}
	public void setGoodsImgUrls(List<String> goodsImgUrls) {
		this.goodsImgUrls = goodsImgUrls;
	}
	public String getDetailHref() {
		return detailHref;
	}
	public void setDetailHref(String detailHref) {
		this.detailHref = detailHref;
	}
	public String getSpecialType() {
		return specialType;
	}
	public void setSpecialType(String specialType) {
		this.specialType = specialType;
	}
	public String getSkuMappingSuit() {
		return skuMappingSuit;
	}
	public void setSkuMappingSuit(String skuMappingSuit) {
		this.skuMappingSuit = skuMappingSuit;
	}
    
	
    
    
}
