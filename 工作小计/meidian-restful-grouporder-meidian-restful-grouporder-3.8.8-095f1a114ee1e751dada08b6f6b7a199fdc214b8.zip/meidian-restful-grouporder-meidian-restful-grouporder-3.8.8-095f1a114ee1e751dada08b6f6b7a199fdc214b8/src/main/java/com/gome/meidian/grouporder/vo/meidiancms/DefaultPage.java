package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;

public class DefaultPage implements Serializable{

	private static final long serialVersionUID = 3006329341189308860L;
	
	private String code;			// 唯一主键
	private String pageName;		// 名称
	private String pageTitle;		// 主题
	private String pageDesc;		// 描述
	private Integer pageType;		// 类型
	private String pageTypeStr;		// 类型
	private String shareUrl;		// 分享url
	private String imgUrl;			// 图片url
	private Integer pageLevel; 		// 页面等级
	private Integer isActivityTime;	// 是否是活动时间
	private String backColor;		// 底色
	private String backImgUrl;		// 低图片
	private String categeryCode;	// 绑定:分类code
	private String brandCode;		// 绑定:品牌code
	
	
}
