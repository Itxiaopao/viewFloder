package com.gome.meidian.grouporder.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.Gcache;
import redis.GcacheClient;

@Configuration
public class GCacheConfig {
	
	@Value("${dubbo.registry.gcache_address}")
	private String zk;
	@Value("${gome.redis.business}")
	private String business;
	@Value("${gome.redis.business-new}")
	private String businessNew;
	@Value("${gome.redis.zzbusiness}")
	private String zzbusiness;
	@Value("${gome.redis.venus-vshop}")
	private String venusVshop;

	@Value("${gome.redis.userCenter}")
	private String userCenter;

	@Value("${gome.redis.gomeOnline}")
	private String gomeOnline;
	
	@Bean(name = "gcache", destroyMethod = "close")
    public Gcache gcache(){
        Gcache gcache = new GcacheClient(zk, business);
        return gcache;
    }
	@Bean(name = "gcacheNew", destroyMethod = "close")
    public Gcache gcacheNew(){
        Gcache gcache = new GcacheClient(zk, businessNew);
        return gcache;
    }
	@Bean(name = "gcachezz", destroyMethod = "close")
	public Gcache gcache2(){
		Gcache gcache = new GcacheClient(zk, zzbusiness);
		return gcache;
	}
	
	@Bean(name = "venusVshop", destroyMethod = "close")
	public Gcache gcache3(){
		return new GcacheClient(zk, venusVshop);
	}



	@Bean(name = "userCenter", destroyMethod = "close")
	public Gcache gcache4(){
		return new GcacheClient(zk, userCenter);
	}
	
	@Bean(name = "gomeOnlineGcache", destroyMethod = "close")
    public Gcache gcache5(){
        Gcache gcache = new GcacheClient(zk, gomeOnline);
        return gcache;
    }
}
