package com.gome.meidian.grouporder.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.gome.meidian.grouporder.manager.WechatLoginManager;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.gome.meidian.common.exception.ServiceException;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.sso.facade.IUserSsoFacade;
import com.gome.sso.model.UserInfoCache;

@Component
public class AuthencationUtils {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private final static String COOKIE_KEY = "cookie";
    private final static String SCN_KEY = "SCN";
    String INVOKEFROM ="gomeShopApp";
	String APPID = "shop14f5s44a6s1d3g3h4p9k7y56";
	
	@Autowired
	private IUserSsoFacade iUserSsoFacade; //userSso
	
	public UserInfoCache getAuthencationInfo(HttpServletRequest request) throws ServiceException {		
    	String cookie = request.getHeader(COOKIE_KEY);
		String scn = null;
		if(StringUtils.isNotBlank(cookie)){
			scn = parseCookie(cookie);
		}
		
//		if(StringUtils.isBlank(scn)){
//			scn = request.getHeader(SCN_KEY);
//		}
		UserInfoCache userInfoCache;
		if(StringUtils.isBlank(scn)){
			return null;
		}else{
			// 校验不通过时给出异常信息
			UserResult<UserInfoCache> resultEntity = checkScnByDubbo(scn);
			userInfoCache = resultEntity.getBuessObj();
		}
		return userInfoCache;
	}
	
	/**
	 * 解析cookie 取得scn
	 * @param cookie
	 * @return
	 */
	private String parseCookie(String cookie){
		String scn = "";
		if(cookie == null || cookie.length() <=0 )
			return scn;
			String[] cookies = cookie.split(";");
			for (String item : cookies) {				
				if(item.indexOf("=") >=0 ){					
					String[] element = item.split("=");
					if(element.length == 2){
						String key = element[0];
						if(key != null){
							key = key.trim();
						}
						if(SCN_KEY.equals(key)){
							scn = element[1];
							return scn;
						}
					}				
				}				
			}
		return scn;		
	}
	
	/**
	 * 调用user封装的dubbo服务进行scn校验
	 * 
	 * @param userId
	 *            用户标识
	 * @param app
	 *            app标识
	 * @param scn
	 *            scn
	 * @return
	 * @throws ServiceException 
	 */
	public UserResult<UserInfoCache> checkScnByDubbo(String scn) throws ServiceException {
//		scn = scn.replace(' ','+');
//		scn = URLDecoder.decode(scn);
    	Map<String, Object> paraMap = new HashMap<String, Object>();
    	paraMap.put("appId", APPID);
    	UserResult<UserInfoCache>  result = null;
		try {
			result = iUserSsoFacade.checkLoginStatus(scn, INVOKEFROM, paraMap);
		} catch (Exception exp) {
			logger.error("SCN check exception ==> {} ", exp);
			throw new ServiceException("scn.check.exception");			
		}		
		return result;
	}


	public UserResult<UserInfoCache> loginOut(String scn) throws ServiceException {
		try {
			//scn = URLDecoder.decode(scn,"UTF-8");
			scn=scn.replace(" ","");
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String, Object> paraMap = new HashMap<String, Object>();
		paraMap.put("appId", APPID);
		UserResult<UserInfoCache>  result = null;
		try {
			result = iUserSsoFacade.delUserByIdFromCacheWithMap(scn, WechatLoginManager.INVOKE_FROM, paraMap);
		} catch (Exception exp) {
			logger.error("SCN check exception ==> {} ", exp);
			throw new ServiceException("scn.check.exception");
		}
		return result;
	}
	
	/**
	 * 校验登录
	 * @param scn
	 * @return
	 * @throws ServiceException
	 */
	public String authenticationLogin(String scn) throws ServiceException{
		String userId = null;
		if(null == scn || scn.equalsIgnoreCase("")) {
			return null;
		}
		UserResult<UserInfoCache> resultEntity = this.checkScnByDubbo(scn);
		UserInfoCache userInfo = resultEntity.getBuessObj();
		
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = userInfo.getId();
		}else {
			return null;
		}
		
		return userId;
	}
}
