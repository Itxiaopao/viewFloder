package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 活动页vo
 * @author shichangjian
 *
 */
public class ActivityPageVo implements Serializable{

	private static final long serialVersionUID = -154631617669642488L;
	
	private ActivityPage activityPage;

	public ActivityPage getAvtivityPage() {
		return activityPage;
	}

	public void setAvtivityPage(ActivityPage activityPage) {
		this.activityPage = activityPage;
	}
	
}
