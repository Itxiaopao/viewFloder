package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class UserRegistVo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "{base.user.mobile.notBlank}")
	private String mobile;//用户手机号
	@NotBlank(message = "{base.user.smsCode.notBlank}")
	private String smsCode;//短信验证码
	@NotBlank(message = "{base.user.password.notBlank}")
	private String password;
	@NotBlank(message = "{base.user.distinctId.notBlank}")
	private String distinctId;//灯塔埋码
	@NotBlank(message = "{base.user.registerSource.notBlank}")
	private String registerSource;//注册来源-微信环境:gomeShopWeChat 普通环境:gomeShopWap
	
	private String createType;//新增类型(签到/红包/领券)
	private String inviteUserId;//邀请人id
	private String inviteMobile;//邀请人手机号
	
	public String getInviteMobile() {
		return inviteMobile;
	}
	public void setInviteMobile(String inviteMobile) {
		this.inviteMobile = inviteMobile;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getSmsCode() {
		return smsCode;
	}
	public void setSmsCode(String smsCode) {
		this.smsCode = smsCode;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDistinctId() {
		return distinctId;
	}
	public void setDistinctId(String distinctId) {
		this.distinctId = distinctId;
	}
	public String getRegisterSource() {
		return registerSource;
	}
	public void setRegisterSource(String registerSource) {
		this.registerSource = registerSource;
	}
	public String getCreateType() {
		return createType;
	}
	public void setCreateType(String createType) {
		this.createType = createType;
	}
	public String getInviteUserId() {
		return inviteUserId;
	}
	public void setInviteUserId(String inviteUserId) {
		this.inviteUserId = inviteUserId;
	}
	
}
