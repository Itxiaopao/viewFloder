package com.gome.meidian.grouporder.vo.meidiancms;

import java.io.Serializable;

public class Icon implements Serializable{

	private static final long serialVersionUID = 4498251555901374387L;

	private String bsCode;		// 业务id	(not null)
	private String iconName;	// icon名称
	private String imgUrl;		// 图片地址
	private String skipUrl;		// 跳转路径
	private Integer showCount;	// 展示次数	(not null)
	private Integer iconLocal;	// icon位置	上 中 下	(not null)
	private String iconLocalStr;// icon位置	上 中 下	(not null)
	private Integer isMove;		// 是否移动 0;1	(not null)
	private Integer isShow;		// 是否展示 1:都可见, 2: 登录可见, 3:登录不可见, 4:都不展示	(not null)
	private String isShowStr;	// 是否展示 1:都可见, 2: 登录可见, 3:登录不可见, 4:都不展示	(not null)
	private Integer iconType;	// icon 类型 0:无类型, 1:弹窗	
	private String iconTypeStr;	// icon 类型 0:无类型, 1:弹窗	
	
	public String getBsCode() {
		return bsCode;
	}
	public void setBsCode(String bsCode) {
		this.bsCode = bsCode;
	}
	public String getIconName() {
		return iconName;
	}
	public void setIconName(String iconName) {
		this.iconName = iconName;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public String getSkipUrl() {
		return skipUrl;
	}
	public void setSkipUrl(String skipUrl) {
		this.skipUrl = skipUrl;
	}
	public Integer getShowCount() {
		return showCount;
	}
	public void setShowCount(Integer showCount) {
		this.showCount = showCount;
	}
	public Integer getIconLocal() {
		return iconLocal;
	}
	public void setIconLocal(Integer iconLocal) {
		this.iconLocal = iconLocal;
	}
	public String getIconLocalStr() {
		return iconLocalStr;
	}
	public void setIconLocalStr(String iconLocalStr) {
		this.iconLocalStr = iconLocalStr;
	}
	public Integer getIsMove() {
		return isMove;
	}
	public void setIsMove(Integer isMove) {
		this.isMove = isMove;
	}
	public Integer getIsShow() {
		return isShow;
	}
	public void setIsShow(Integer isShow) {
		this.isShow = isShow;
	}
	public String getIsShowStr() {
		return isShowStr;
	}
	public void setIsShowStr(String isShowStr) {
		this.isShowStr = isShowStr;
	}
	public Integer getIconType() {
		return iconType;
	}
	public void setIconType(Integer iconType) {
		this.iconType = iconType;
	}
	public String getIconTypeStr() {
		return iconTypeStr;
	}
	public void setIconTypeStr(String iconTypeStr) {
		this.iconTypeStr = iconTypeStr;
	}
	
	
	
}
