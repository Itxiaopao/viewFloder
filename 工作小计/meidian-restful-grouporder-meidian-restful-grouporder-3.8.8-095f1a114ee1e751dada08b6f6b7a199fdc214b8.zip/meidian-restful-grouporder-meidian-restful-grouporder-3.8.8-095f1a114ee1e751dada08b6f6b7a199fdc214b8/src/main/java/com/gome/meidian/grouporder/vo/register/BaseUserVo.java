package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class BaseUserVo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "{base.user.id.notBlank}")
	private String userId;//用户id

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
