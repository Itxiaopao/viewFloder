package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@ToString
public class MshopSolicitVo implements Serializable{

	private static final long serialVersionUID = -7841982197613504803L;

	//当前人微信号
	private String selfWeChartNum;

	//当前人二维码地址
	private String selfImag;

	//当前人头像地址
	private String selfUrl;

	//当前人头像昵称
	private String selfNickname;

	//当前顾问（导师）店主id(邀请码)
	private String higherMid;

	//当前顾问（导师）userID
	private String higherUserId;

	//当前顾问（导师）头像地址
	private String higherUrl;

	//当前顾问（导师）头像昵称
	private String higherNickname;

	//当前顾问（导师）微信号
	private String higherWeChartNum;

	//当前顾问（导师）二维码
	private String higherImag;

	//判断该邀请人是否和当前顾问（导师）是同一个人   true,是同一个人;false,不是同一个人;
	private Boolean isSamePerson;

	//邀请人头像地址
	private String invitationUrl;

	//邀请人头像昵称
	private String invitationNickname;


}
