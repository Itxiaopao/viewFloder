package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;
import javax.validation.constraints.NotNull;
import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.shareRebate;

/**
 * 分享返（佣金）
 * @author shichangjian
 *
 */
public class ShareRebate implements Serializable{

	private static final long serialVersionUID = 5999409050605914132L;
	
	@NotBlank(message = "{param.error}", groups = { shareRebate.class})
	private String productId; 
	@NotBlank(message = "{param.error}", groups = { shareRebate.class})
	private String skuNo;
	@NotNull(message = "{param.error}", groups = { shareRebate.class})
	private Long price;		// 单位：分
	private String shopId;
	private String brandCode;//add by lsx 
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getBrandCode() {
		return brandCode;
	}
	public void setBrandCode(String brandCode) {
		this.brandCode = brandCode;
	}
	
	
	
}
