package com.gome.meidian.grouporder.vo.meidiancms;


import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.ProductDetailVo;

import com.gome.meidian.grouporder.vo.carveUp.carveUpActivity.CarveUpActivityInfoVo;
import com.gome.meidian.grouporder.vo.grouporderVo.CommonProductVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.homePage.ThousandGroup;
import com.gome.meidian.grouporder.vo.homePage.WanrenGroupListVo;
import com.gome.meidian.grouporder.vo.product.HomeCouponProductRes;
import com.gome.meidian.grouporder.vo.product.ProductSurveyInfoVo;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;

import java.io.Serializable;
import java.util.List;

/**
 * 合并楼层
 * @author shichangjian
 *
 */
public class ModelMerge implements Serializable{

	private static final long serialVersionUID = -3687170850628223637L;

	private List<ProductGroupInfoVo> productGroupInfoVos;	// 组团列表
	private List<HomeCouponProductRes> homeCouponProductRes;// 立减列表
	private List<ProductBuyRebateVo> productBuyRebateVos;	// 超级返列表

	private List<ProductSurveyInfoVo> productSurveyInfoVos; // 热度调研商品列表

	private List<ThousandGroup> thousandGroups;				// 万人团
	private List<CarveUpActivityInfoVo> carveUpGroups;   //瓜分团
	private List<CommonProductVo> commonProducts;  //普通商品瀑布流

	private Integer type;									// 楼层类型
	private Integer rowCount;								// 每行显示条数,单列，双列，多商品轮播
	private String name;									// 名称
	private String moduleCode;								// 挂载的模块code
	private String pageCode;								// 挂载的页面Code
	
	public List<ProductGroupInfoVo> getProductGroupInfoVos() {
		return productGroupInfoVos;
	}
	public void setProductGroupInfoVos(List<ProductGroupInfoVo> productGroupInfoVos) {
		this.productGroupInfoVos = productGroupInfoVos;
	}
	public List<HomeCouponProductRes> getHomeCouponProductRes() {
		return homeCouponProductRes;
	}
	public void setHomeCouponProductRes(List<HomeCouponProductRes> homeCouponProductRes) {
		this.homeCouponProductRes = homeCouponProductRes;
	}
	public List<ProductBuyRebateVo> getProductBuyRebateVos() {
		return productBuyRebateVos;
	}
	public void setProductBuyRebateVos(List<ProductBuyRebateVo> productBuyRebateVos) {
		this.productBuyRebateVos = productBuyRebateVos;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModuleCode() {
		return moduleCode;
	}
	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}
	public String getPageCode() {
		return pageCode;
	}
	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}
	public Integer getRowCount() {
		return rowCount;
	}
	public void setRowCount(Integer rowCount) {
		this.rowCount = rowCount;
	}


	public List<ProductSurveyInfoVo> getProductSurveyInfoVos() {
		return productSurveyInfoVos;
	}

	public void setProductSurveyInfoVos(List<ProductSurveyInfoVo> productSurveyInfoVos) {
		this.productSurveyInfoVos = productSurveyInfoVos;
	}

	public List<ThousandGroup> getThousandGroups() {
		return thousandGroups;
	}
	public void setThousandGroups(List<ThousandGroup> thousandGroups) {
		this.thousandGroups = thousandGroups;
	}

	public List<CarveUpActivityInfoVo> getCarveUpGroups() {
		return carveUpGroups;
	}

	public void setCarveUpGroups(List<CarveUpActivityInfoVo> carveUpGroups) {
		this.carveUpGroups = carveUpGroups;
	}
	public List<CommonProductVo> getCommonProducts() {
		return commonProducts;
	}
	public void setCommonProducts(List<CommonProductVo> commonProducts) {
		this.commonProducts = commonProducts;
	}
}
