package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 618
 * 数字门店，推荐位tab
 * @author shichangjian
 *
 */
public class RecommendTabVo implements Serializable{
	
	private static final long serialVersionUID = -6715550446811651588L;
	
	private String image;
	private String sequence;
	private String week;
	private String name;
	private String activityDate;
	private String ukey;						//凑单
	private String hot_ukey;					//爆品
	private String super_ukey;					//超级返
	private Integer defaultDate = 0;			//是否默认
	private Integer tabLocation;				//tab位置
	private BannerProductIdVo bannerProductIdVo;//默认显示
	
	public String getSuper_ukey() {
		return super_ukey;
	}
	public void setSuper_ukey(String super_ukey) {
		this.super_ukey = super_ukey;
	}
	public String getHot_ukey() {
		return hot_ukey;
	}
	public void setHot_ukey(String hot_ukey) {
		this.hot_ukey = hot_ukey;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getSequence() {
		return sequence;
	}
	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	public String getWeek() {
		return week;
	}
	public void setWeek(String week) {
		this.week = week;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getActivityDate() {
		return activityDate;
	}
	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}
	public String getUkey() {
		return ukey;
	}
	public void setUkey(String ukey) {
		this.ukey = ukey;
	}
	public Integer getDefaultDate() {
		return defaultDate;
	}
	public void setDefaultDate(Integer defaultDate) {
		this.defaultDate = defaultDate;
	}
	public Integer getTabLocation() {
		return tabLocation;
	}
	public void setTabLocation(Integer tabLocation) {
		this.tabLocation = tabLocation;
	}
	public BannerProductIdVo getBannerProductIdVo() {
		return bannerProductIdVo;
	}
	public void setBannerProductIdVo(BannerProductIdVo bannerProductIdVo) {
		this.bannerProductIdVo = bannerProductIdVo;
	}
	
	
}
