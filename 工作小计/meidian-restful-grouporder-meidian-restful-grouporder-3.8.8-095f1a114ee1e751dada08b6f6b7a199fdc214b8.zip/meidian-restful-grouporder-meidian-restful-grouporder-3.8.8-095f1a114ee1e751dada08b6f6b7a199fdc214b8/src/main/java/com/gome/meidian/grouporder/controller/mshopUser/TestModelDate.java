package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.ArrayList;
import java.util.List;

import com.gome.meidian.grouporder.vo.mshopUserVo.OrderInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.RebateInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.ShopInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.SkuInfoVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.UserInfoVo;

public class TestModelDate {
	
	public static List<RebateInfoVo> getProfitList(){
		List<RebateInfoVo> resultList = new ArrayList<RebateInfoVo>();
		RebateInfoVo rebateInfoVo = new RebateInfoVo();
		rebateInfoVo.setPurchaserId("100036366295");
		rebateInfoVo.setRebateType(1);
		rebateInfoVo.setAmount(1L);
		rebateInfoVo.setInvalidReasonType(1);
		rebateInfoVo.setBusinessType(1);
		rebateInfoVo.setSkuId("pop8003760398");
		rebateInfoVo.setShopId("81012928");
		rebateInfoVo.setInviteeId("100036366295");
		rebateInfoVo.setTitle("邀请商家入驻分享返利");
		rebateInfoVo.setAdOriginal("广告来源");
		rebateInfoVo.setLevel(2);
		rebateInfoVo.setMicroId("100000");
		rebateInfoVo.setFlag(1);
		rebateInfoVo.setPurchaseTimeStr("2019-06-13 04:04:04");
		rebateInfoVo.setInvalidTimeStr("2019-06-13 04:06:04");
		rebateInfoVo.setRebateTimeStr("2019-06-13 04:08:04");
		UserInfoVo purchaser = new UserInfoVo ();
		purchaser.setNickName("这是接口样例数据");
		purchaser.setFacePicUrl("http://gfs11.atguat.net.cn/T1o4KTBTWQ1RCvBVdK.png");
		purchaser.setPurchaserId("100036366295");
		SkuInfoVo skuInfo  = new SkuInfoVo();
		skuInfo.setSkuId("pop8003760398");
		skuInfo.setPid("8003760398");
		skuInfo.setGoodsImgUrl("http://gfs12.atguat.net.cn/T1C.JTBQHR1RCvBVdK.jpg");
		skuInfo.setGoodsName("样例商品");
		UserInfoVo invitee = new UserInfoVo();
		invitee.setNickName("这是接口样例数据");
		invitee.setFacePicUrl("http://gfs11.atguat.net.cn/T1o4KTBTWQ1RCvBVdK.png");
		invitee.setPurchaserId("100036366295");
		ShopInfoVo shopInfo = new ShopInfoVo();
		shopInfo.setDescription("描述");
		shopInfo.setIcon("http://img10.atguat.net.cn/image/bbcimg/2017/02/22/4749/1420/1487767173735/810129388122.png");
		shopInfo.setName("娇娇的店铺哦10");
		shopInfo.setShopId("81012928");
		shopInfo.setStatus(0);
		shopInfo.setType("专营");
		rebateInfoVo.setPurchaser(purchaser);
		rebateInfoVo.setSkuInfo(skuInfo);
		rebateInfoVo.setInvitee(invitee);
		rebateInfoVo.setShopInfo(shopInfo);
		resultList.add(rebateInfoVo);
		return resultList;
	}
	
	
	
	public static List<OrderInfoVo> getOrderList(){
		List<OrderInfoVo> resultList = new ArrayList<OrderInfoVo>();
		OrderInfoVo orderInfoVo = new OrderInfoVo();
		orderInfoVo.setOrderId(11479981885L);
		//orderInfoVo.setCommerceId(3726568564L);
		orderInfoVo.setDeliveryId("2774125850");
		List<SkuInfoVo> goodsList =new ArrayList<SkuInfoVo>();
		SkuInfoVo skuInfoVo = new SkuInfoVo();
		skuInfoVo.setSkuId("pop8003760398");
		skuInfoVo.setPid("8003760398");
		skuInfoVo.setGoodsImgUrl("http://gfs12.atguat.net.cn/T1C.JTBQHR1RCvBVdK.jpg");
		skuInfoVo.setGoodsName("样例商品");
		skuInfoVo.setUnitPrice(50000L);
		skuInfoVo.setBuyNum(1);
		skuInfoVo.setProductTag(1);
		goodsList.add(skuInfoVo);
		orderInfoVo.setGoodsList(goodsList);
		orderInfoVo.setPriceTotal(50000L);
		orderInfoVo.setOrderStatus(0);
		orderInfoVo.setUserId(100036366295l);
		orderInfoVo.setOrderTimeStr("2019-06-13 04:04:04");
		orderInfoVo.setUserWeixin("O(∩_∩O哈哈~");
		orderInfoVo.setAwardMoney(2L);
		orderInfoVo.setCommMoney(3L);
		resultList.add(orderInfoVo);
		return resultList;
	}

}
