package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 活动页信息
 * @author shichangjian
 *
 */
public class ModelVo extends Coupon implements Serializable{

	private static final long serialVersionUID = 1394791259731283794L;

	private String type;
//	private String title;
	private String image;
	private String target;
	private String product_id;
	private String activity_id;			//活动id
//	private Integer operator_id;
//	private Integer user_id;
	private String skuId;
	private String sku_no;
//	private String rebateId;
	private String name;
//	private Integer rebateType;
	private ProductParamInfo productParamInfo;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
//	public String getTitle() {
//		return title;
//	}
//	public void setTitle(String title) {
//		this.title = title;
//	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
//	public Integer getOperator_id() {
//		return operator_id;
//	}
//	public void setOperator_id(Integer operator_id) {
//		this.operator_id = operator_id;
//	}
//	public Integer getUser_id() {
//		return user_id;
//	}
//	public void setUser_id(Integer user_id) {
//		this.user_id = user_id;
//	}
	public ProductParamInfo getProductParamInfo() {
		return productParamInfo;
	}
	public void setProductParamInfo(ProductParamInfo productParamInfo) {
		this.productParamInfo = productParamInfo;
	}
	public String getActivity_id() {
		return activity_id;
	}
	public void setActivity_id(String activity_id) {
		this.activity_id = activity_id;
	}
//	public String getRebateId() {
//		return rebateId;
//	}
//	public void setRebateId(String rebateId) {
//		this.rebateId = rebateId;
//	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
//	public Integer getRebateType() {
//		return rebateType;
//	}
//	public void setRebateType(Integer rebateType) {
//		this.rebateType = rebateType;
//	}
	public String getSku_no() {
		return sku_no;
	}
	public void setSku_no(String sku_no) {
		this.sku_no = sku_no;
	}
	
	
	
}
