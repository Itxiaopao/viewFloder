package com.gome.meidian.grouporder.vo.materialVo;

import java.io.Serializable;
import java.util.List;

/**
 * 活动素材
 * @author shichangjian
 *
 */
public class ActivityMaterialVo implements Serializable{

	private static final long serialVersionUID = 8516183158544610089L;

	private String activityCode;		// 活动code
	private String materialDes;			// 素材描述
	private List<String> materialImages;// 素材图片
	private Long materialShareNum;		// 素材分享次数
	private String proposal;			// 建议
	private int skipType;				//类型
	private String shareUrl;			// 落地页url
	
	public String getMaterialDes() {
		return materialDes;
	}
	public void setMaterialDes(String materialDes) {
		this.materialDes = materialDes;
	}
	public List<String> getMaterialImages() {
		return materialImages;
	}
	public void setMaterialImages(List<String> materialImages) {
		this.materialImages = materialImages;
	}
	
	public Long getMaterialShareNum() {
		return materialShareNum;
	}
	public void setMaterialShareNum(Long materialShareNum) {
		this.materialShareNum = materialShareNum;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getActivityCode() {
		return activityCode;
	}
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}
	public String getProposal() {
		return proposal;
	}
	public void setProposal(String proposal) {
		this.proposal = proposal;
	}
	public int getSkipType() {
		return skipType;
	}
	public void setSkipType(int skipType) {
		this.skipType = skipType;
	}
	public String getShareUrl() {
		return shareUrl;
	}
	public void setShareUrl(String shareUrl) {
		this.shareUrl = shareUrl;
	}

	
	
	
}
