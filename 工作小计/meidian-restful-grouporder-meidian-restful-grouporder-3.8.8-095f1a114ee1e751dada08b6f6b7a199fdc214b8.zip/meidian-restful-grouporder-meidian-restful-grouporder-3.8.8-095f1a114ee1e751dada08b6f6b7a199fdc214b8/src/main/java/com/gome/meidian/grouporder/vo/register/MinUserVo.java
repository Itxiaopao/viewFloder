package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class MinUserVo implements Serializable {

	private static final long serialVersionUID = -8154137763243235763L;
	
	@NotNull(message = "{meidian.min.message.userId.notNull}")
	private Long userId;
	private Long orderId;
	@NotBlank(message = "{meidian.min.message.formId.notBlank}")
	private String formId;
	@NotNull(message = "{meidian.min.message.formType.notNull}")
	private Integer formType;
	
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public Integer getFormType() {
		return formType;
	}
	public void setFormType(Integer formType) {
		this.formType = formType;
	}

}
