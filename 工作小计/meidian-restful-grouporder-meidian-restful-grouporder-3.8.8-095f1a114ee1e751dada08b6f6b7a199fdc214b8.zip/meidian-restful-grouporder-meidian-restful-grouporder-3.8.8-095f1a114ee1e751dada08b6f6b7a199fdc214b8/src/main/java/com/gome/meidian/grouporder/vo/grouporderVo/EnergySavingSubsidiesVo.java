package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.math.BigDecimal;

public class EnergySavingSubsidiesVo implements Serializable {

	private static final long serialVersionUID = 2180742615777867297L;
    /**
     * 活动ID
     */
    private String promotionId;
    /**
     * 优惠率
     */
    private BigDecimal rate;
    /**
     * 优惠封顶金额
     */
    private BigDecimal cappingAmount;
    /**
     * 可购买标识
     */
    private boolean purchaseFlag;
	public String getPromotionId() {
		return promotionId;
	}
	public void setPromotionId(String promotionId) {
		this.promotionId = promotionId;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
	public BigDecimal getCappingAmount() {
		return cappingAmount;
	}
	public void setCappingAmount(BigDecimal cappingAmount) {
		this.cappingAmount = cappingAmount;
	}
	public boolean isPurchaseFlag() {
		return purchaseFlag;
	}
	public void setPurchaseFlag(boolean purchaseFlag) {
		this.purchaseFlag = purchaseFlag;
	}
    
    
}
