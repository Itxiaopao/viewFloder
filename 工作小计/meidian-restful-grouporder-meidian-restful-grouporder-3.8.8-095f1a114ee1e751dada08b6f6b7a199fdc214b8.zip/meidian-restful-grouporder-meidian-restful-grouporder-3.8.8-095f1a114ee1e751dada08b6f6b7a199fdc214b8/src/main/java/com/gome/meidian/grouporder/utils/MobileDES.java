package com.gome.meidian.grouporder.utils;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;




public class MobileDES {
	
	 private static byte[] eniv = { 1, 2, 3, 4, 5, 6, 7, 8 }; 
     public static String encryptDES(String encryptString, String encryptKey)
            throws Exception { 
    	 IvParameterSpec zeroIv = new IvParameterSpec(eniv); 
    	 SecretKeySpec key = new SecretKeySpec(encryptKey.getBytes(), "DES"); 
    	 Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding"); 
    	 cipher.init(Cipher.ENCRYPT_MODE, key, zeroIv);         
    	 byte[] encryptedData = cipher.doFinal(encryptString.getBytes());
    	 return MobileBase64.encode(encryptedData);
     }
     
     private static byte[] deiv = { 1, 2, 3, 4, 5, 6, 7, 8 };    
     public static String decryptDES(String decryptString, String decryptKey)throws Exception {
    	 byte[] byteMi = MobileBase64.decode(decryptString);
    	 IvParameterSpec zeroIv = new IvParameterSpec(deiv);
    	 SecretKeySpec key = new SecretKeySpec(decryptKey.getBytes(), "DES");
    	 Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
    	 cipher.init(Cipher.DECRYPT_MODE, key, zeroIv);
    	 byte decryptedData[] = cipher.doFinal(byteMi);
    	 return new String(decryptedData);
     }

	/**
	 * unicode转中文
	 * @param unicode
	 * @return
	 */
	private static String unicodeToCn(String unicode) {
		/** 以 \ u 分割，因为java注释也能识别unicode，因此中间加了一个空格*/
		String[] strs = unicode.split("\\\\u");
		String returnStr = "";
		// 由于unicode字符串以 \ u 开头，因此分割出的第一个字符是""。
		for (int i = 1; i < strs.length; i++) {
			returnStr += (char) Integer.valueOf(strs[i], 16).intValue();
		}
		return returnStr;
	}

	/**
	 * 中文转unicode
	 * @param cn
	 * @return
	 */
	private static String cnToUnicode(String cn) {
		char[] chars = cn.toCharArray();
		String returnStr = "";
		for (int i = 0; i < chars.length; i++) {
			returnStr += "\\u" + Integer.toString(chars[i], 16);
		}
		return returnStr;
	}
     
}
