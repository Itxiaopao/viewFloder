package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class AchievementOrderParamVo implements Serializable{

	private static final long serialVersionUID = 565473873952596641L;
	private String filter;
	@NotBlank(message = "{param.error}")
	private String dateState;
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public String getDateState() {
		return dateState;
	}
	public void setDateState(String dateState) {
		this.dateState = dateState;
	}

	
	
	

}
