package com.gome.meidian.grouporder.manager.monitor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.monitor.MonitorVo;
import com.gome.meidian.grouporder.vo.store.UserInfo;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.service.IOrderShopService;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.sso.facade.IUserSsoFacade;
import com.gome.sso.model.UserInfoCache;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;

@Service
public class MonitorManager {

    String INVOKEFROM ="gomeShopApp";
	String APPID = "shop14f5s44a6s1d3g3h4p9k7y56";
	@Value("${spring.profiles.active}")
	private String currentEnv;
	
	@Autowired
	private PropertiesConfig propertiesConfig;
	@Autowired
	private IUserSsoFacade iUserSsoFacade;
	@Autowired
	private IOrderShopService iOrderShopService;
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	@Autowired
	private VshopFacade vshopFacade;
	
	
	
	/**
	 * 接口监控
	 * @param scn
	 * @return
	 * @throws ServiceException
	 */
	public Map<String, Object> monitor(String scn) throws ServiceException{
		Map<String, Object> loginMonitorMap = new HashMap<String, Object>();
		// 1.登录校验接口监控
		Map<String, Object> loMap = this.loginMonitor(scn);
		loginMonitorMap.put("authencationLoginDes", "登录校验接口监控");
		loginMonitorMap.put("authencationLogin", loMap);
		
		// 2.销售组织接口监控
		
		return loginMonitorMap;
	}
	
	/**
	 * 登录校验监控
	 * @param scn
	 * @return
	 * @throws ServiceException
	 */
	public Map<String, Object> loginMonitor(String scn) throws ServiceException{
		Map<String, Object> restMap = new HashMap<String, Object>();

	    // 登录选择
		MonitorVo loMonitorVo = new MonitorVo();
 		loMonitorVo.setInterfacePerson("周亚亮");
 		loMonitorVo.setInterfaceName("redis.Gcache");
	 	String loginChoice = null;
	 	boolean log = true;
	 	try{
	 		loginChoice = propertiesConfig.getGcache().get("loginChoice");
	 	}catch(Exception e){
	 		loMonitorVo.setInterfaceState("调用Gcache获取登录选择==》 false");
	 		log = false;
	 	}
	 	if(log){
	 		loMonitorVo.setInterfaceState("调用Gcache获取登录选择==> true");
	 		loMonitorVo.setInterfaceResponse(loginChoice);
	 		if(null == loginChoice){
	 			loMonitorVo.setInterfaceResponse("美店登录");
	 		}else if(loginChoice.equals("2")){
	 			loMonitorVo.setInterfaceResponse("国美登录");
	 		}
	 	}
	 	restMap.put("loginGcacheMonitorVo", loMonitorVo);
	 	
	 	// 获取userId
	 	MonitorVo uIdMonitorVo = new MonitorVo();
	 	uIdMonitorVo.setInterfacePerson("刘海明");
		uIdMonitorVo.setInterfaceName("com.gome.meidian.grouporder.manager.monitor.MonitorManager.iUserSsoFacade.checkLoginStatus()");
	 	if(null == scn || scn.equals("")) {
	 		scn = "aa";
	 	}
	 	Map<String, Object> paraMap = new HashMap<String, Object>();
    	paraMap.put("appId", APPID);
    	UserResult<UserInfoCache> result = null;
		try {
			result = iUserSsoFacade.checkLoginStatus(scn, INVOKEFROM, paraMap);
		} catch (Exception e) {
			uIdMonitorVo.setInterfaceState("会员登录校验接口==> false");
		}		
		String userId = null;
		if(scn.equals("aa")){
			if(currentEnv.equals("test")){
				userId = "100041721122";
				uIdMonitorVo.setInterfaceResponse(userId);
				uIdMonitorVo.setInterfaceState("没有传SCN，默认值时长建");
			}
			else if(currentEnv.equals("product")){
				userId = "72499798325";
				uIdMonitorVo.setInterfaceResponse(userId);
				uIdMonitorVo.setInterfaceState("没有传SCN，默认值时长建");
			}
		} else {
			if(null == result || result.equals("")
					|| null == result.getBuessObj()
					|| null == result.getBuessObj().getId()
					|| result.getBuessObj().getId().equals("")){
				
				uIdMonitorVo.setInterfaceResponse("会员登录校验接口返回null");
				uIdMonitorVo.setInterfaceState("会员登录校验接口==> fail");
				if(currentEnv.equals("test"))
					userId = "100041721122";
				else if(currentEnv.equals("product"))
					userId = "72499798325";
				
			}else {
				uIdMonitorVo.setInterfaceState("会员登录校验接口==> true");
				UserInfoCache userInfoCache = result.getBuessObj();
				userId = userInfoCache.getId();
				uIdMonitorVo.setInterfaceResponse("会员登录校验接口返回userId: " + userId);
			}
		}
		restMap.put("uIdMonitorVo", uIdMonitorVo);
		
		// 员工门店编码员工编号
		MonitorVo userStoreMonitorVo = new MonitorVo();
		userStoreMonitorVo.setInterfacePerson("陈晨");
		boolean user = true;
		userStoreMonitorVo.setInterfaceName("com.gome.meidian.grouporder.manager.monitor.MonitorManager.iOrderShopService.getStaffInfoByUserId()");
		ResultEntity resultEntity = null;
		try{
			resultEntity = iOrderShopService.getStaffInfoByUserId(Long.valueOf(userId));
		}catch(Exception e){
			userStoreMonitorVo.setInterfaceState("员工门店编码员工编号接口==> false");
			user = false;
		}
		if(user) {
			if(null == resultEntity || null == resultEntity.getBusinessObj()){
				userStoreMonitorVo.setInterfaceState("员工门店编码员工编号接口==> fail");
				userStoreMonitorVo.setInterfaceResponse(resultEntity.getMessage());
			}else{
				Object obj = resultEntity.getBusinessObj();
				// WriteMapNullValue:保留null值
				String re = JSONObject.toJSONString(obj, SerializerFeature.WriteMapNullValue);
				JSONObject jsOb = JSONObject.parseObject(re);
				JSONObject js = jsOb.getJSONObject("staffInfo");
				if(null == js) userStoreMonitorVo.setInterfaceState("员工门店编码员工编号接口==> fail");
				
				userStoreMonitorVo.setInterfaceResponse(js.getLong("zxUid") + "_" + js.getString("staffCode") + "_" + js.getString("storeCode"));
				userStoreMonitorVo.setInterfaceState("员工门店编码员工编号接口==> true");
			}
		}
		restMap.put("userStoreMonitorVo", userStoreMonitorVo);
		
		// 昵称
		MonitorVo nickNameMonitorVo = new MonitorVo();
		nickNameMonitorVo.setInterfacePerson("刘海明");
		nickNameMonitorVo.setInterfaceName("com.gome.meidian.grouporder.manager.monitor.MonitorManager.iUserInfoFacade.getItemByIdForGomeShop()");
		Map<String, Object> para = new HashMap<>();
		para.put("companyName", "gomeOnLine");
		boolean nickName = true;
		MapResult<UnifyUserInfoExt> res = null;
		try{
			res = iUserInfoFacade.getItemByIdForGomeShop(userId, "gomeShopMobile", para);
		}catch(Exception e){
			userStoreMonitorVo.setInterfaceState("获取昵称接口==> false");
			nickName = false;
		}
		if(nickName) {
			if(null == res || null == res.getBuessObj()){
				nickNameMonitorVo.setInterfaceState("获取昵称接口==> fail");
				nickNameMonitorVo.setInterfaceResponse(res.getMessage());
			}else {
				nickNameMonitorVo.setInterfaceResponse(res.getBuessObj().getNikename());
				nickNameMonitorVo.setInterfaceState("获取昵称接口==> true");
			}
		}
		restMap.put("nickNameMonitorVo", nickNameMonitorVo);
		
		// 美店主
		MonitorVo midMonitorVo = new MonitorVo();
		midMonitorVo.setInterfacePerson("陈晨");
		midMonitorVo.setInterfaceName("com.gome.meidian.grouporder.manager.monitor.MonitorManager.vshopFacade.queryVshopByuserId()");
		boolean mid = true;
		CommonResultEntity<VshopInfo> common = null;
		try{
			common = vshopFacade.queryVshopByuserId(userId);
		}catch(Exception e){
			midMonitorVo.setInterfaceState("获取美店主id接口==> false");
			mid = false;
		}
		if(mid) {
			if(null == common || null == common.getBusinessObj()){
				midMonitorVo.setInterfaceState("获取美店主id接口==> fail");
			}else {
				VshopInfo vshopInfo = common.getBusinessObj();
				midMonitorVo.setInterfaceResponse(String.valueOf(vshopInfo.getVshopId()));
				midMonitorVo.setInterfaceState("获取美店主id接口==> true");
			}
		}
		restMap.put("midMonitorVo", midMonitorVo);
		
		return restMap;
	}
}
