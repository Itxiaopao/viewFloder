package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupProduct;

/**
 * 主页活动信息入参
 * @author shichangjian
 *
 */
public class GroupInfoReq implements Serializable{

	private static final long serialVersionUID = -2193193359319580255L;

//	@NotBlank(message = "{param.error}", groups = { groupProduct.class})
	private String  productId;	//商品id
//	@NotNull(message = "{param.error}", groups = { groupProduct.class})
	private Long  activityId;	//活动id
	private String skuId;		// 参与组团活动最低价的skuId
	private String  activityUkey;	//活动ukey
	
	
	public GroupInfoReq() {
		super();
	}
	public GroupInfoReq(String productId, Long activityId, String skuId) {
		super();
		this.productId = productId;
		this.activityId = activityId;
		this.skuId = skuId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getActivityUkey() {
		return activityUkey;
	}
	public void setActivityUkey(String activityUkey) {
		this.activityUkey = activityUkey;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	
	
	

}
