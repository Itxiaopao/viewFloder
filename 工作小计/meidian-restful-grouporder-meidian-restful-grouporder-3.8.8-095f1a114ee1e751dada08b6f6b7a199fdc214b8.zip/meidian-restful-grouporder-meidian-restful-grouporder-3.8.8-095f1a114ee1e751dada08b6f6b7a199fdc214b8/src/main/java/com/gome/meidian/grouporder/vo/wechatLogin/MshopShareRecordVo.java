package com.gome.meidian.grouporder.vo.wechatLogin;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 */
public class MshopShareRecordVo implements Serializable {
    private static final long serialVersionUID = 4531890118803614371L;
    /**
     * 当前用户uniqueId
     */
    private String uniqueId;
    /**
     * 邀请用户的uniqueId
     */
    private String puniqueId;
    /**
     * 当前用户userId
     */
//    @NotNull(message="当前用户不能为空")
    private Long userId;
    /**
     * 邀请人的userId
     */
//    @NotNull(message="邀请人用户不能为空")
    private Long puserId;
    /**
     * 当前用户mid
     */
    private Long mid;
    /**
     * 邀请人的mid
     */
    private Long pmid;
    /**
     * 当前用户头像，加密头像url
     */
    private String image;
    /**
     * 当前用户昵称
     */
    private String nickname;
    /**
     * 用户隐私授权 0 未授权   1 授权
     */
    private Integer authorization;
    private Integer pType;
    /**
     * 1.新客， 2.游客，4.首单，5忠粉
     */
    private Integer type;
    /**
     * 0老用户 1新注册
     */
//    @NotNull(message="注册标记不能为空")
    private Integer newUser;
    private String insertTime;
    private String updateTime;
    private String userInfo;	// 密文，unid，昵称
    
    public String getUniqueId() {
        return uniqueId;
    }

    public void setUniqueId(String uniqueId) {
        this.uniqueId = uniqueId;
    }

    public String getPuniqueId() {
        return puniqueId;
    }

    public void setPuniqueId(String puniqueId) {
        this.puniqueId = puniqueId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPuserId() {
        return puserId;
    }

    public void setPuserId(Long puserId) {
        this.puserId = puserId;
    }

    public Long getPmid() {
        return pmid;
    }

    public void setPmid(Long pmid) {
        this.pmid = pmid;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public Integer getAuthorization() {
        return authorization;
    }

    public void setAuthorization(Integer authorization) {
        this.authorization = authorization;
    }

    public Long getMid() {
        return mid;
    }

    public void setMid(Long mid) {
        this.mid = mid;
    }

    public Integer getpType() {
        return pType;
    }

    public void setpType(Integer pType) {
        this.pType = pType;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getNewUser() {
        return newUser;
    }

    public void setNewUser(Integer newUser) {
        this.newUser = newUser;
    }

    public String getInsertTime() {
        return insertTime;
    }

    public void setInsertTime(String insertTime) {
        this.insertTime = insertTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

	public String getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(String userInfo) {
		this.userInfo = userInfo;
	}

    
}