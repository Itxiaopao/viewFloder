package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;
/**
 * sku信息
 * @author lishouxu-ds
 *
 */
public class SkuInfoVo implements Serializable{
	private static final long serialVersionUID = -7279061365244813426L;
	private String skuId;
	private String pid;
	private String goodsImgUrl;//商品图片地址
	private String goodsName;//商品名称	
	private Long unitPrice;//商品单价（分）
	private Integer buyNum;//购买数量
	private int productTag; 		// 1：自营 2：联营
	private Long commerceId;//子订单id
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getGoodsImgUrl() {
		return goodsImgUrl;
	}
	public void setGoodsImgUrl(String goodsImgUrl) {
		this.goodsImgUrl = goodsImgUrl;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public Long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public Integer getBuyNum() {
		return buyNum;
	}
	public void setBuyNum(Integer buyNum) {
		this.buyNum = buyNum;
	}
	public int getProductTag() {
		return productTag;
	}
	public void setProductTag(int productTag) {
		this.productTag = productTag;
	}
	public Long getCommerceId() {
		return commerceId;
	}
	public void setCommerceId(Long commerceId) {
		this.commerceId = commerceId;
	}
	
	
	
}
