
package com.gome.meidian.grouporder.mq;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.client.producer.DefaultMQProducer;
import com.alibaba.rocketmq.client.producer.MQProducer;
import com.alibaba.rocketmq.client.producer.SendResult;
import com.alibaba.rocketmq.common.message.Message;

/**
 * Created by lipengfei on 2019/07/10.
 */
@Component
public class HandlerEmployMQProducer {

	private static DefaultMQProducer producer;
	private static Logger logger = LoggerFactory.getLogger(MQProducer.class);

	@Value("${rocketmq.producer2.queues}")
	private int queueTmp;
	@Value("${rocketmq.producer.namesrvAddr}")
	private String serverAddressTmp;
	@Value("${rocketmq.producer2.groupName}")
	private String groupName;
	@Value("${rocketmq.producer2.instanceName}")
	private String instanceName;

	@PostConstruct
	public void init() {
		try {
			producer = new DefaultMQProducer(groupName);
			producer.setNamesrvAddr(serverAddressTmp);
			producer.setInstanceName(instanceName);
			producer.setDefaultTopicQueueNums(queueTmp);
			producer.start();
			logger.info("HandlerEmployMQProducer 初始化成功！.....");
		} catch (Exception ex) {
			logger.error("HandlerEmployMQProducer 初始化异常。", ex);
		}
	}

	public static SendResult sendMessageSelectQueue(String topic, String tag, String key, String bodyMessage, String selectorParam)
			throws MQClientException {
		try {
			Message message = new Message(topic,tag, key, bodyMessage.getBytes("UTF-8"));
			EmployMessageQueueSelector selector = new EmployMessageQueueSelector();
			return producer.send(message,selector,selectorParam);
		} catch (Exception e) {
			throw new MQClientException("rocketmq message send failed", e);
		}
	}



}
