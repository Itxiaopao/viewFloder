package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.ActivityPage;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.homePage.CouponCmsVo;

/**
 * 首页立减商品列表
 * @author shichangjian
 *
 */
public class HomeCouponProductRes implements Serializable{

	private static final long serialVersionUID = -3206976735396512502L;

	private Product product;								// 商品信息
	private HomeProductCouponVo homeProductCouponVo;		// 专题活动页信息
	private CouponCmsVo couponCmsVo;
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public HomeProductCouponVo getHomeProductCouponVo() {
		return homeProductCouponVo;
	}
	public void setHomeProductCouponVo(HomeProductCouponVo homeProductCouponVo) {
		this.homeProductCouponVo = homeProductCouponVo;
	}
	public CouponCmsVo getCouponCmsVo() {
		return couponCmsVo;
	}
	public void setCouponCmsVo(CouponCmsVo couponCmsVo) {
		this.couponCmsVo = couponCmsVo;
	}
	
	
}
