package com.gome.meidian.grouporder.manager.miniManager;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.gorder.service.GorderInfoForAppResourceMuti;
import com.gomeplus.bs.interfaces.gorder.vo.UserAttendGroupVo;

import redis.Gcache;

@Service
public class MoreProductGroupManager {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private GorderInfoForAppResourceMuti gorderInfoForAppResourceMuti;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Resource(name = "gcachezz")
	private Gcache gcachezz;
	
	/**
	 * 用户参与同一个团的次数
	 * @param userId
	 * @param mutiCollectionId
	 * @param groupId
	 * @return
	 */
	public Boolean userSameGroupRestrict(Long userId, String mutiCollectionId, Long groupId){
		CommonResultEntity<UserAttendGroupVo> commonResult = gorderInfoForAppResourceMuti.checkUserAttendOneGroupStatus(userId, mutiCollectionId, groupId);
		UserAttendGroupVo userAttendGroupVo = commonResult.getBusinessObj();
		if(null == userAttendGroupVo || null == userAttendGroupVo.getIsOpen()) return false;
		return userAttendGroupVo.getIsOpen();
	} 
}
