package com.gome.meidian.grouporder.vo.materialVo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.grouporderVo.HomePageActivity;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.product.ProductInfo;

/**
 * 商品素材
 * @author shichangjian
 *
 */
public class ProductMaterialVo implements Serializable{

	private static final long serialVersionUID = -5805136815178664428L;

	private ProductInfo productInfo;						// 商品信息
	private HomePageActivity homePageActivity;				// 活动信息
	private String materialDes;								// 素材描述
	private List<String> materialImages;					// 商品素材图片
	private Long materialShareNum;							// 商品素材分享次数
	private String proposal;								// 建议
	
	
	public ProductInfo getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(ProductInfo productInfo) {
		this.productInfo = productInfo;
	}
	public HomePageActivity getHomePageActivity() {
		return homePageActivity;
	}
	public void setHomePageActivity(HomePageActivity homePageActivity) {
		this.homePageActivity = homePageActivity;
	}
	public String getMaterialDes() {
		return materialDes;
	}
	public void setMaterialDes(String materialDes) {
		this.materialDes = materialDes;
	}
	
	public List<String> getMaterialImages() {
		return materialImages;
	}
	public void setMaterialImages(List<String> materialImages) {
		this.materialImages = materialImages;
	}
	public Long getMaterialShareNum() {
		return materialShareNum;
	}
	public void setMaterialShareNum(Long materialShareNum) {
		this.materialShareNum = materialShareNum;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getProposal() {
		return proposal;
	}
	public void setProposal(String proposal) {
		this.proposal = proposal;
	}
	
	
}
