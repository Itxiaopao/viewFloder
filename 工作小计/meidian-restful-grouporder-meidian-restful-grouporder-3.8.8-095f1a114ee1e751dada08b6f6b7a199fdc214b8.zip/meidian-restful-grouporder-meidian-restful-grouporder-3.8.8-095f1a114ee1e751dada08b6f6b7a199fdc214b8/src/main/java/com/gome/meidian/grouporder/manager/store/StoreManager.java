package com.gome.meidian.grouporder.manager.store;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gome.dragon.mds.client.dto.gcc.GomeStoreFull;
import com.gome.dragon.mds.client.dto.gomestore.GomeStore;
import com.gome.dragon.mds.client.gcc.GomeStoreFullClient;
import com.gome.dragon.mds.client.gomestore.GomeStoreClient;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.meidian.grouporder.vo.store.UserInfo;
import com.gome.meidian.service.IOrderShopService;
import com.gome.meidian.service.IcSmDqlStaffService;
import com.gomeo2o.facade.vshop.service.VshopChannelExternalFacade;

import redis.Gcache;

@Service
public class StoreManager {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private GomeStoreClient gomeStoreClient;
	@Autowired
	private GomeStoreFullClient gomeStoreFullClient;
	@Autowired
    private VshopChannelExternalFacade vshopChannelExternalFacade;
//	@Autowired
//	private ICmsService cmsService;
//	@Autowired
//	private GomeAreaSearch gomeAreaSearch;
	@Autowired
	private IOrderShopService iOrderShopService;
	@Autowired
	private PropertiesConfig propertiesConfig;
	
	private static double EARTH_RADIUS = 6378.137;
	// 全国门店
	private List<GomeStore> gomeStores = null;
	
	/**
	 * 每1小时更新全国门店
	 */
	@Scheduled(cron = "0 0 2 * * ?")
	public void updateStore() throws ServiceException {

		gomeStores = null;
		logger.info("updateStore => update store");
	}
	
    /**
     * 根据门店编码获取门店信息
     * @param storeCode
     * @param storeType（0：数字门店  、  1：渠道美店）
     * @return
     * @throws ServiceException
     */
    public Store getStoreInfo(String storeCode, Integer storeType, String lng, 
    		String lat) throws ServiceException{
    	if(null == storeType) return null;
    	Gcache gcache = propertiesConfig.getGcache();
    	
    	String key = "storeInfo_" + storeCode + "_" + storeType;
    	Store store = null;
    	// 1.数字门店
    	if(storeType == 0){
    		store = JSONObject.parseObject(gcache.get(key), Store.class);
    		if(null == store){
    			GomeStoreFull gomeStoreFull = null;
				try {
//					gomeStore = gomeStoreClient.getGomeStoreByCode(storeCode);
					gomeStoreFull = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus(storeCode);
					
					
				} catch (Exception e) {
					logger.error("getStoreInfo.error ==> e: {}", e);
					e.printStackTrace();
				}
				store = new Store();
    			if(null == gomeStoreFull) {
    				store.setStoreCode("2019");
    				gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
    				return null;
    			}
    			
    			BeanUtils.copyProperties(gomeStoreFull, store);
    			store.setStoreCode(gomeStoreFull.getStoreId());
    			Integer type = store.getStoreType();
    			if(null != type){
    				if(type == 1) 
    					store.setStoreType(0);
    				else if(type == 2)
    					store.setStoreType(1);
    			}
    			
    			gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
    		}else if(null != store.getStoreCode() && store.getStoreCode().equals("2019")){
    			logger.info("gomeStoreFull.gcache ==> storeCode: {} storeType: {}", store.getStoreCode(), storeType);
    			return null;
    		}
    		
    		// 门店品牌，logo
    		String storeBrand = store.getBrand();
    		if(null == storeBrand || storeBrand.equals("") 
        			|| storeBrand.equals("tengdadianqi")){
        		store.setBrand("guomeidianqi");
        	}
        	store.setLogo(propertiesConfig.getStoreBrandLogo().get(store.getBrand()));
    	}
    	
    	// 2.渠道门店
    	if(storeType == 1){
    		// 渠道门店
    		store = JSONObject.parseObject(gcache.get(key), Store.class);
    		if(null == store){
    			com.gomeo2o.facade.vshop.dto.GomeStore virtualStore = vshopChannelExternalFacade.getChannelShopByStoreCode(storeCode);
    			store = new Store();
    			if (null == virtualStore) {
    				store.setStoreCode("2019");
    				gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
    				return null;
    			}
    			
    			BeanUtils.copyProperties(virtualStore, store);
    			
    			gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
    		}else if(null != store.getStoreCode() && store.getStoreCode().equals("2019")){
    			logger.info("gomeStore.gcache ==> storeCode: {} storeType: {}", store.getStoreCode(), storeType);
    			return null;
    		}
    	
    	}
    	
    	// 营业时间
    	String businessHours = store.getBusinessHours();
    	if(null == businessHours || businessHours.equals("")){
    		store.setBusinessHours(propertiesConfig.getBusinessHours());
    	}
    	
    	// 根据当前经纬度计算门店的距离
    	if(null != lng && !lng.equals("") 
    			&& null != lat && !lat.equals("")
    			&& null != store.getLng() && !store.getLng().equals("")
    			&& null != store.getLat() && !store.getLat().equals("")){
    		double distance = this.getDistance(Double.parseDouble(lng), Double.parseDouble(lat), Double.parseDouble(store.getLng()),
    				Double.parseDouble(store.getLat()));
    		store.setDistance(distance);
    	}
    	return store;
    }
    
    /**
     * 根据门店编码获取门店信息，素材logo使用
     * @param storeCode
     * @param storeType（0：数字门店  、  1：渠道美店）
     * @return
     * @throws ServiceException
     */
    public Store getStoreInfo(String storeCode, Integer storeType) throws ServiceException{
    	if(null == storeType) return null;
    	Gcache gcache = propertiesConfig.getGcache();
    	
    	String key = "storeInfo_" + storeCode + "_" + storeType;
    	Store store = null;
    	// 1.数字门店
    	if(storeType == 0){
    		store = JSONObject.parseObject(gcache.get(key), Store.class);
    		if(null == store){
    			GomeStoreFull gomeStoreFull = null;
    			try {
//					gomeStore = gomeStoreClient.getGomeStoreByCode(storeCode);
    				gomeStoreFull = gomeStoreFullClient.getGomeStoreByStoreIdByAllStatus(storeCode);
    				
    				
    			} catch (Exception e) {
    				logger.error("getStoreInfo.error ==> e: {}", e);
    				e.printStackTrace();
    			}
    			store = new Store();
    			if(null == gomeStoreFull) {
    				store.setStoreCode("2019");
    				gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
    				return null;
    			}
    			
    			BeanUtils.copyProperties(gomeStoreFull, store);
    			store.setStoreCode(gomeStoreFull.getStoreId());
    			Integer type = store.getStoreType();
    			if(null != type){
    				if(type == 1) 
    					store.setStoreType(0);
    				else if(type == 2)
    					store.setStoreType(1);
    			}
    			
    			gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
    		}else if(null != store.getStoreCode() && store.getStoreCode().equals("2019")){
    			logger.info("gomeStoreFull.gcache ==> storeCode: {} storeType: {}", store.getStoreCode(), storeType);
    			return null;
    		}
    		
    		// 门店品牌，logo
    		String storeBrand = store.getBrand();
    		if(null == storeBrand || storeBrand.equals("") 
    				|| storeBrand.equals("tengdadianqi")){
    			store.setBrand("guomeidianqi");
    		}
    		store.setLogo(propertiesConfig.getMaterialBrandLogo().get(store.getBrand()));
    	}
    	
    	// 2.渠道门店
//    	if(storeType == 1){
//    		// 渠道门店
//    		store = JSONObject.parseObject(gcache.get(key), Store.class);
//    		if(null == store){
//    			com.gomeo2o.facade.vshop.dto.GomeStore virtualStore = vshopChannelExternalFacade.getChannelShopByStoreCode(storeCode);
//    			store = new Store();
//    			if (null == virtualStore) {
//    				store.setStoreCode("2019");
//    				gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
//    				return null;
//    			}
//    			
//    			BeanUtils.copyProperties(virtualStore, store);
//    			
//    			gcache.setex(key, 10 * 60, JSONObject.toJSONString(store).getBytes());
//    		}else if(null != store.getStoreCode() && store.getStoreCode().equals("2019")){
//    			logger.info("gomeStore.gcache ==> storeCode: {} storeType: {}", store.getStoreCode(), storeType);
//    			return null;
//    		}
//    		
//    	}
    	
    	// 营业时间
//    	String businessHours = store.getBusinessHours();
//    	if(null == businessHours || businessHours.equals("")){
//    		store.setBusinessHours(propertiesConfig.getBusinessHours());
//    	}
    	
    	// 根据当前经纬度计算门店的距离
//    	if(null != lng && !lng.equals("") 
//    			&& null != lat && !lat.equals("")
//    			&& null != store.getLng() && !store.getLng().equals("")
//    			&& null != store.getLat() && !store.getLat().equals("")){
//    		double distance = this.getDistance(Double.parseDouble(lng), Double.parseDouble(lat), Double.parseDouble(store.getLng()),
//    				Double.parseDouble(store.getLat()));
//    		store.setDistance(distance);
//    	}
    	return store;
    }
    
//    /**
//     * 根据门店code
//     * @param storeCode
//     * @param storeType
//     * @return
//     * @throws ServiceException
//     */
//    public GomeAddress getFourAreaCode(String storeCode, int storeType) throws ServiceException{
//    	Store store = this.getStoreInfo(storeCode, storeType, null, null);
//    	if(null == store) return null;
//    	Gcache gcache = propertiesConfig.getGcache();
//    	
//    	String key = "fourAreaCode_" + storeCode + "_" + storeType;
//    	GomeAddress gomeAddress = null;
//		if(null == gcache.get("gpsOnOff")){
//			gomeAddress = JSONObject.parseObject(gcache.get(key), GomeAddress.class);
//			if(null == gomeAddress){
//				gomeAddress = this.getGomeAreaSearch(store.getCityName(), store.getCountyName());
//				if(null != gomeAddress){
//					gcache.setex(key, 10 * 60, JSONObject.toJSONString(gomeAddress).getBytes());
//				}else{
//					gomeAddress.setDefaultFlag(true);
//					gomeAddress.setProvinceId("11000000");
//					gomeAddress.setCityId("11010000");
//					gomeAddress.setDistrictId("11010200");
//					gomeAddress.setTownId("110102002");
//					
//					gomeAddress.setProvinceName("北京");
//					gomeAddress.setCityName("北京市");
//					gomeAddress.setDistrictName("朝阳区");
//					gomeAddress.setTownName("全部区域");
//				}
//			}
//		}else{
//			gomeAddress.setDefaultFlag(true);
//			gomeAddress.setProvinceId("11000000");
//			gomeAddress.setCityId("11010000");
//			gomeAddress.setDistrictId("11010200");
//			gomeAddress.setTownId("110102002");
//			
//			gomeAddress.setProvinceName("北京");
//			gomeAddress.setCityName("北京市");
//			gomeAddress.setDistrictName("朝阳区");
//			gomeAddress.setTownName("全部区域");
//		}
//    	
//		return gomeAddress;
//    }
//    
//	public GomeAddress getGomeAreaSearch(String cityName, String districtName){
//		GomeAddress gomeAddress = new GomeAddress();
//		GomeAreaInfoDto gomeAreaInfoDto = gomeAreaSearch.queryAreaInfo(cityName, districtName);
//		if(null == gomeAreaInfoDto) return null;
//		gomeAddress.setProvinceId(gomeAreaInfoDto.getProvinceCode());
//		gomeAddress.setProvinceName(gomeAreaInfoDto.getProvinceName());
//		gomeAddress.setCityId(gomeAreaInfoDto.getCityCode());
//		gomeAddress.setCityName(gomeAreaInfoDto.getCityName());
//		gomeAddress.setDistrictId(gomeAreaInfoDto.getDistrictCode());
//		gomeAddress.setDistrictName(gomeAreaInfoDto.getDistrictName());
//		List<GomeAreaInfoDto> gomeAreaInfoDtos = gomeAreaInfoDto.getGaiList();
//		if(null == gomeAreaInfoDtos || gomeAreaInfoDtos.size() == 0){
//			return gomeAddress;
//		} 
//		GomeAreaInfoDto gomeAreaInfo = gomeAreaInfoDtos.get(0);
//		gomeAddress.setTownId(gomeAreaInfo.getStreetCode());
//		gomeAddress.setTownName(gomeAreaInfo.getStreetName());
//		
//		return gomeAddress;
//	}
	
	/**
	 * 根据userId获取用户信息
	 * @param userId
	 * @return
	 */
	public UserInfo getUserInfo(Long userId){
		ResultEntity resultEntity = iOrderShopService.getStaffInfoByUserId(userId);
		if(null == resultEntity) return null;
		Object obj = resultEntity.getBusinessObj();
		if(null == obj) return null;
		// WriteMapNullValue:保留null值
		String re = JSONObject.toJSONString(obj, SerializerFeature.WriteMapNullValue);
		JSONObject jsOb = JSONObject.parseObject(re);
		JSONObject js = jsOb.getJSONObject("staffInfo");
		if(null == js) return null;
		
		UserInfo userInfo = new UserInfo(js.getLong("zxUid"), js.getString("staffCode"), js.getString("storeCode"), 
				js.getString("regionCode"), js.getString("fDivisionCode"), js.getString("sDivisionCode"), 
				js.getString("staffName"));
		
		return userInfo;
	}
	
    public double getDistance(double lng, double lat, double destinationLng,
            double destinationLat) {
		double radLat = this.rad(lat);
		double radDestinationLat = this.rad(destinationLat);
		double a = radLat - radDestinationLat;
		double b = this.rad(lng) - this.rad(destinationLng);
		double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2)
		+ Math.cos(radLat) * Math.cos(radDestinationLat)
		* Math.pow(Math.sin(b / 2), 2)));
		s = s * EARTH_RADIUS;
		s = Math.round(s * 10000d) / 10000d;
		return s;
    }
    
    private double rad(double d) {
        return d * Math.PI / 180.0;
    }
    
    /**
     * 根据经纬度获取最近的门店
     * @param longitude
     * @param latitude
     * @param num
     * @return
     */
    public List<Store> storeDetail(String longitude, String latitude, int num){
    	List<Store> stores = new ArrayList<Store>();
    	if(num <= 0) {
    		// 返回默认门店
    		Store store = new Store();
    		store.setCityCode(propertiesConfig.getDefaultAreaCode());
    		store.setStoreCode(propertiesConfig.getDefaultStoreCode());
    		stores.add(store);
    		
    		return stores;
    	}
    	
    	if(null == gomeStores){
    		try {
    			gomeStores = gomeStoreClient.getAllGomeStores();
    		} catch (Exception e) {
    			// 返回默认门店
    			e.printStackTrace();
    			Store store = new Store();
    			store.setCityCode(propertiesConfig.getDefaultAreaCode());
    			store.setStoreCode(propertiesConfig.getDefaultStoreCode());
    			stores.add(store);
    			
    			return stores;
    		}
    		if(null == gomeStores){
    			// 如果为空返回默认门店
    			Store store = new Store();
    			store.setCityCode(propertiesConfig.getDefaultAreaCode());
    			store.setStoreCode(propertiesConfig.getDefaultStoreCode());
    			stores.add(store);
    			
    			return stores;
    		}
    	}
    	
    	// 利用简单选择排序算法,时间复杂度O(n*num)
    	int i, j, min;
    	int sort = 0;
    	for(i = 0; i < gomeStores.size(); i++){
    		// 将当前下标定义为最小值下标
    		min = i;
    		for(j = i + 1; j < gomeStores.size(); j++){
    			GomeStore minGomeStore = gomeStores.get(min);
    			GomeStore jGomeStore = gomeStores.get(j);
    	    	// 根据当前经纬度计算门店的距离
    	    	if(null != minGomeStore.getLng() && !minGomeStore.getLng().equals("")
    	    			&& null != minGomeStore.getLat() && !minGomeStore.getLat().equals("")
    	    			&& null != jGomeStore.getLng() && !jGomeStore.getLng().equals("")
    	    	    	&& null != jGomeStore.getLat() && !jGomeStore.getLat().equals("")
    	    			){
    	    		double minDistance = this.getDistance(Double.parseDouble(longitude), Double.parseDouble(latitude), Double.parseDouble(minGomeStore.getLng()),
    	    				Double.parseDouble(minGomeStore.getLat()));
    	    		double jDistance = this.getDistance(Double.parseDouble(longitude), Double.parseDouble(latitude), Double.parseDouble(jGomeStore.getLng()),
    	    				Double.parseDouble(jGomeStore.getLat()));
    	    		
    	    		if(minDistance > jDistance){
        				min = j;
        			}
    	    	}
    		}
    		if(i != min){
    			// 交换i,min
    			GomeStore gomeStore = gomeStores.get(min);
    			gomeStores.set(min, gomeStores.get(i));
    			gomeStores.set(i, gomeStore);
    		}
    		
    		// 控制要排序几个元素
    		sort++;
    		if(sort >= num) break;
    	}
    	for(int y = 0; y < num; y++){
    		Store store = new Store();
    		BeanUtils.copyProperties(gomeStores.get(y), store);
    		stores.add(store);
    	}
    	
    	return stores;
    }
}
