package com.gome.meidian.grouporder.manager.mshopUserManager;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.gome.meidian.user.dto.MShopShareBindingDto;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.rocketmq.client.exception.MQBrokerException;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.remoting.exception.RemotingException;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.RegisterManager;
import com.gome.meidian.grouporder.manager.TaskShopManager;
import com.gome.meidian.grouporder.utils.UserConstants;
import com.gome.meidian.grouporder.vo.register.MshopUserDepositVo;
import com.gome.meidian.grouporder.vo.register.MshopUserRegistVo;
import com.gome.meidian.grouporder.vo.register.UserRegistVo;
import com.gome.meidian.grouporder.vo.register.VshopInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.manager.IMShopShareRecordManager;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.sso.model.UserInfoCache;
import com.gome.userCenter.model.GomeUnifyRegisterUser;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;

@SuppressWarnings({"rawtypes","unchecked"})
@Service
public class MshopUserManager {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
    private VshopFacade vshopFacade;
    @Autowired
    private GroupOrderManager groupOrderManager;
    @Autowired
	private VshopInfoExternalFacade vshopInfoExternalFacade;
    @Autowired
    private RegisterManager registerManager;
    @Autowired
	private TaskShopManager taskShopManager;
    @Autowired
    private IUserShareBindingManager iMshopShareBindingManager;
    @Autowired
	private IMShopShareRecordManager iMShopShareRecordManager;

    /**
     * 店主认证开店
     * @param vShopInfoVo
     * @param scn
     * @return
     * @throws MeidianException
     */
	@Transactional
	public ResponseJson openVshopInfo(VshopInfoVo vshopInfoVo, String scn) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		//获取登录人消息
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		if(userInfo==null || userInfo.getId()==null || userInfo.getId().equals("")) {
			throw new ServiceException("group.operation.notLoggin");
		}
		long userId = Long.parseLong(userInfo.getId());
		//检验inviteMid、获取inviteUserId
		long inviteUserId = 0;
		CommonResultEntity<VshopInfo> inviteVshopInfo = vshopFacade.queryVshopById(vshopInfoVo.getInviteMId());
		if(inviteVshopInfo!=null && inviteVshopInfo.getCode()==0){
			VshopInfo vshopInfo = inviteVshopInfo.getBusinessObj();
			if(vshopInfo==null || vshopInfo.getVshopId()==0){//未开通
				throw new ServiceException("mshop.user.authentication.illegal");
			}else{
				inviteUserId = vshopInfo.getUserId();
			}
		}else{
			throw new ServiceException("mshop.user.authentication.illegal");
		}
		//校验当前用户开店信息
		CommonResultEntity<VshopInfo> userShopInfo = vshopInfoExternalFacade.queryVshopInfoByUserId(userId);
		if(userShopInfo!=null && userShopInfo.getCode()==0){
			VshopInfo vshopInfo = userShopInfo.getBusinessObj();
			if(vshopInfo!=null && vshopInfo.getVshopId()!=0){//已开通店铺
				throw new ServiceException("mshop.user.phone.has.shop");
			}
		}else{
			throw new ServiceException("mshop.user.authentication.illegal");
		}
		//封装店铺信息
		VshopInfo vshopInfo = this.assembleVshopInfo(vshopInfoVo.getPhoneNo(),userId);
		vshopInfo.setUserId(userId);
		//记录邀请关系信息日志
		logger.info("邀请开店关系信息,被邀请人:{},邀请人:{}",userId,inviteUserId);
		//创建店铺
		Long shopId = 0l;
		CommonResultEntity<String> commonResultEntity = vshopFacade.createVshop2(vshopInfo);
		if(commonResultEntity != null && commonResultEntity.getCode()==0){
			String shopIdStr = commonResultEntity.getBusinessObj();
			if(shopIdStr!=null && !shopIdStr.equals("")){
				shopId = Long.valueOf(shopIdStr);
				taskShopManager.saveVshopInvitationRelation(userId,shopId,inviteUserId,vshopInfoVo.getInviteMId());
				//同步邀请拉新数据
				this.synInvitateRelate(userId,shopId,inviteUserId);
			}else{
				throw new ServiceException("mshop.user.authentication.illegal");
			}
		}else{
			throw new ServiceException("mshop.user.phone.has.shop");
		}
		//返回店铺id
		CommonResultEntity<VshopInfo> vshopInfoBak = vshopFacade.queryVshopById(shopId);
		VshopInfo businessObj = vshopInfoBak.getBusinessObj();
		responseJson.setData(businessObj);
		return responseJson;
	}
    
	/**
	 * 检验用户是否开店
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	public ResponseJson checkUserVshop(String scn) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		//获取登录人信息
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		if(userInfo==null || userInfo.getId()==null || userInfo.getId().equals("")) {
			throw new ServiceException("group.operation.notLoggin");
		}
		//判定登录人是否开店
		Map<String,Object> map = new HashMap<>();
		CommonResultEntity<VshopInfo> userShopInfo = vshopInfoExternalFacade.queryVshopInfoByUserId(Long.parseLong(userInfo.getId()));
		if(userShopInfo!=null && userShopInfo.getCode()==0){
			VshopInfo vshopInfo = userShopInfo.getBusinessObj();
			if(vshopInfo!=null && vshopInfo.getVshopId()!=0){//已开通店铺
				map.put("vshopStatus", UserConstants.VSHOP_TRUE);
			}else{
				map.put("vshopStatus", UserConstants.VSHOP_FALSE);
			}
		}else{
			responseJson.setCode(userShopInfo.getCode());
			responseJson.setMsg(userShopInfo.getMessage());
			return responseJson;
		}
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 校验mid是否开店
	 * @param mid
	 * @return
	 * @throws MeidianException
	 */
	public ResponseJson checkMidVshop(Long mid) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		//获取登录人信息
		Map<String,Object> map = new HashMap<>();
		CommonResultEntity<VshopInfo> midVshopInfo = vshopFacade.queryVshopById(mid);
		if(midVshopInfo!=null && midVshopInfo.getCode()==0){
			VshopInfo vshopInfo = midVshopInfo.getBusinessObj();
			if(vshopInfo==null || vshopInfo.getVshopId()==0){//未开通
				map.put("vshopStatus", UserConstants.VSHOP_FALSE);
			}else{
				map.put("vshopStatus", UserConstants.VSHOP_TRUE);
			}
		}else{
			responseJson.setCode(midVshopInfo.getCode());
			responseJson.setMsg(midVshopInfo.getMessage());
			return responseJson;
		}
		responseJson.setData(map);
		return responseJson;
	}

	/**
	 * 邀请mid校验+注册风控+短信验证码校验+注册接口+登录返scn+异步同步信息
	 * @param mshopUserRegistVo
	 * @param request
	 * @param response
	 * @return
	 * @throws MeidianException
	 * @throws MQClientException
	 * @throws RemotingException
	 * @throws MQBrokerException
	 * @throws InterruptedException
	 */
	public ResponseJson registerUser(MshopUserRegistVo mshopUserRegistVo,HttpServletRequest request,HttpServletResponse response) throws MeidianException, MQClientException, RemotingException, MQBrokerException, InterruptedException {
		ResponseJson responseJson = new ResponseJson();
		//检验mid是否开通店铺
		long inviteUserId = 0;
		CommonResultEntity<VshopInfo> midVshopInfo = vshopFacade.queryVshopById(Long.valueOf(mshopUserRegistVo.getInviteMid()));
		if(midVshopInfo!=null && midVshopInfo.getCode()==0){
			VshopInfo vshopInfo = midVshopInfo.getBusinessObj();
			if(vshopInfo==null || vshopInfo.getVshopId()==0){//未开通
				throw new ServiceException("base.shop.initUser.noExit");
			}else{
				inviteUserId = vshopInfo.getUserId();
			}
		}else{
			responseJson.setCode(midVshopInfo.getCode());
			responseJson.setMsg(midVshopInfo.getMessage());
			return responseJson;
		}
		UserRegistVo userRegistVo = new UserRegistVo();
		BeanUtils.copyProperties(mshopUserRegistVo, userRegistVo);
		Map<String, Object> map = registerManager.registerUser(userRegistVo, request, response);
		responseJson.setData(map);
		GomeUnifyRegisterUser gomeUser = (GomeUnifyRegisterUser) map.get("buessObj");
		//开通店铺
		VshopInfo createVshopInfo = this.assembleVshopInfo(mshopUserRegistVo.getMobile(),Long.valueOf(gomeUser.getId()));
		createVshopInfo.setUserId(Long.parseLong(gomeUser.getId()));
		//创建店铺
		CommonResultEntity<String> commonResultEntity = vshopFacade.createVshop2(createVshopInfo);
		if(commonResultEntity != null && commonResultEntity.getCode()==0){
			String shopIdStr = commonResultEntity.getBusinessObj();
			if(shopIdStr!=null && !shopIdStr.equals("")){
				taskShopManager.saveVshopInvitationRelation(Long.parseLong(gomeUser.getId()),Long.valueOf(shopIdStr),inviteUserId,mshopUserRegistVo.getInviteMid());
				//同步邀请拉新数据
				this.synInvitateRelate(Long.parseLong(gomeUser.getId()),Long.valueOf(shopIdStr),inviteUserId);
			}else{
				throw new ServiceException("mshop.user.authentication.illegal");
			}
		}else{
			throw new ServiceException("mshop.user.authentication.illegal");
		}
		return responseJson;
	}
	
	/**
	 * 寄存用户信息数据
	 * @param mshopUserDepositVo
	 * @param scn
	 * @return
	 */
	public ResponseJson mshopUserDeposit(MshopUserDepositVo mshopUserDepositVo) throws MeidianException {
		logger.info("寄存用户信息数据,用户id:{},邀请人id:{},其他数据:{}", mshopUserDepositVo.getUserId(), mshopUserDepositVo.getInviteUserId(), mshopUserDepositVo.toString());
		ResponseJson responseJson = new ResponseJson();
		Map<String, Object> map = new HashMap<>();
		MapResults<MShopShareBindingDto> bindResult = iMshopShareBindingManager.queryShareBindingByUserId(mshopUserDepositVo.getUserId());
		if (bindResult != null && bindResult.getBuessObj() != null) {
			map.put("status", 2);
			responseJson.setData(map);
			return responseJson;
		}
		//保存用户信息
		MshopShareRecordDto mshopShareRecord = new MshopShareRecordDto();
		mshopShareRecord.setType(1);//1.新客,2.游客,4.首单,5忠粉
		//mshopShareRecord.setNewUser(1);//隐私授权（0老用户 1新注册）
		mshopShareRecord.setUserId(mshopUserDepositVo.getUserId());
		mshopShareRecord.setUniqueId(mshopUserDepositVo.getUniqueId());
		mshopShareRecord.setImage(mshopUserDepositVo.getImage());
		mshopShareRecord.setNickname(mshopUserDepositVo.getNickName());
		mshopShareRecord.setPuserId(mshopUserDepositVo.getInviteUserId());
		MapResults<MshopShareRecordDto> mapResults = iMShopShareRecordManager.logOnAddMshopShareRecord(mshopShareRecord);
		//status为0:不成功 1:成功
		if (mapResults == null || !mapResults.getSuccess() || mapResults.getBuessObj() == null || mapResults.getBuessObj().getUpuserId() == null) {
			map.put("status", 0);
		} else {
			map.put("status", 1);
		}
		responseJson.setData(map);
		return responseJson;
	}
	
	//封装店铺信息
	private VshopInfo assembleVshopInfo(String phoneNo,long userId) throws MeidianException{
		VshopInfo vshopInfo = new VshopInfo();
		vshopInfo.setVshopType(1);
		vshopInfo.setVshopBgimage("1");
//		if(StringUtils.isNotBlank(phoneNo)){
//			vshopInfo.setPhoneNo(phoneNo);
//		}
		//封装店铺名称 
		if(StringUtils.isBlank(phoneNo)){
			phoneNo = String.valueOf(userId);
		}
		ThreadLocalRandom random = ThreadLocalRandom.current();
		StringBuilder stringBuilder = new StringBuilder(3);
		for(int i = 0; i < 3; i++) {
			int randomInt = random.nextInt(26) + 1;
			stringBuilder.append(String.valueOf((char)(96+randomInt)));
		}
		vshopInfo.setVshopName(phoneNo+stringBuilder+"的美店");
		return vshopInfo;
	}
	
	//同步邀请拉新数据
	public void synInvitateRelate(long userId,long userMid,long inviteUserId) throws MeidianException{
		//同步邀请关系数据
		MshopShareRecordDto mshopShareRecord = new MshopShareRecordDto();
		mshopShareRecord.setUserId(userId);
		mshopShareRecord.setMid(userMid);
		mshopShareRecord.setUpuserId(inviteUserId);
		iMshopShareBindingManager.changeVShop(mshopShareRecord);
	}
	
}
