package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.coupon.Promotion;
import com.gome.meidian.grouporder.vo.grouporderVo.EnergySavingSubsidiesVo;
import com.gome.meidian.grouporder.vo.grouporderVo.SkuEnergyAllowanceVo;

/**
 * 商品详情页
 * @author shichangjian
 *
 */
public class ProductDetailPageVo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3654405333847003175L;

	private Product product;						// 商品基础信息
	private ProductInfoVo productInfoVo;			// 商品介绍，规格参数
	private SkuEnergyAllowanceVo skuEnergyAllowance; //节能补贴信息
	private EnergySavingSubsidiesVo energySavingSubsidies; //节能优惠信息
	private Integer warranty;						// 延保，1：有延保，0：没有延保
//	private List<Promotion> promotions;
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public ProductInfoVo getProductInfoVo() {
		return productInfoVo;
	}
	public void setProductInfoVo(ProductInfoVo productInfoVo) {
		this.productInfoVo = productInfoVo;
	}
	public SkuEnergyAllowanceVo getSkuEnergyAllowance() {
		return skuEnergyAllowance;
	}
	public void setSkuEnergyAllowance(SkuEnergyAllowanceVo skuEnergyAllowance) {
		this.skuEnergyAllowance = skuEnergyAllowance;
	}
	public Integer getWarranty() {
		return warranty;
	}
	public void setWarranty(Integer warranty) {
		this.warranty = warranty;
	}
	public EnergySavingSubsidiesVo getEnergySavingSubsidies() {
		return energySavingSubsidies;
	}
	public void setEnergySavingSubsidies(EnergySavingSubsidiesVo energySavingSubsidies) {
		this.energySavingSubsidies = energySavingSubsidies;
	}
//	public List<Promotion> getPromotions() {
//		return promotions;
//	}
//	public void setPromotions(List<Promotion> promotions) {
//		this.promotions = promotions;
//	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
