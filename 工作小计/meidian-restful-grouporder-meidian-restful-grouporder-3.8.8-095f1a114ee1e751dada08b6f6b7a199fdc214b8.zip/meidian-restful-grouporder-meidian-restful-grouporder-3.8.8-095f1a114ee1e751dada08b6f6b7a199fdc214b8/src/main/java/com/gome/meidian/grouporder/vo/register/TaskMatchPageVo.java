package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class TaskMatchPageVo implements Serializable {

	private static final long serialVersionUID = -6325467757071444489L;
	
	@NotNull(message = "{shop.task.info.taskId.notNull}")
	private Long taskId;
	@NotNull(message = "{shop.task.cms.pageSize.notNull}")
    private Integer pageSize;
	@NotNull(message = "{base.match.rank.type}")
    private Integer type;//1:当天销售排行 2:当天订单排行 3:活动区间销售排行 4:活动区间订单排行 5:累计天数销售排行 6:累计天数订单排行
	
	public Long getTaskId() {
		return taskId;
	}
	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}

}
