package com.gome.meidian.grouporder.controller.equities;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.user.manager.ILayerCmsConfigManager;
import com.gome.sso.model.UserInfoCache;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * cms弹层配置
 *
 * @author limenghui-ds
 * @create 2019-07-22 20:29
 */
@Slf4j
@RestController
@RequestMapping(value = "/equities/cmsLayer")
public class EquitiesCmsLayerController {

    @Autowired
    private ILayerCmsConfigManager layerCmsConfigManager;
    @Autowired
    private GroupOrderManager groupOrderManager;


    @GetMapping("/chooseCmsLayer")
    public ResponseJson chooseCmsLayer(
            @RequestParam(value = "visitor", required = true) String visitor,
            @RequestParam(value = "newClient", required = true) String newClient,
            @RequestParam(value = "oneOrder", required = true) String oneOrder,
            @RequestParam(value = "moreOrder", required = true) String moreOrder,
            @CookieValue(value = "SCN", required = true) String scn)throws MeidianException {
        log.info("EquitiesCmsLayerController.chooseCmsLayer visitor {},newCline {},oneOrder {},moreOrder {},scn {}",
                visitor, newClient, oneOrder, moreOrder, scn);

        ResponseJson response = new ResponseJson();
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        Long userId = null;
        if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
            userId = Long.parseLong(userInfo.getId());
        }else{
            throw new ServiceException("group.operation.notLoggin");
        }
        Map<String, Object> param = new HashMap<>();
        param.put("userId", userId);
        param.put("2", visitor);
        param.put("1", newClient);
        param.put("4",oneOrder );
        param.put("5",moreOrder );
        Map<String, String> result = layerCmsConfigManager.chooseCmsLayer(param);
        log.info("EquitiesCmsLayerController.chooseCmsLayer result {}", result);
        response.setData(result);
        return response;
    }

}
