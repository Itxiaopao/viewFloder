package com.gome.meidian.grouporder.manager;

import cn.com.gome.user.service.QueryUserInfoFacade;
import cn.com.gome.user.v2.model.StaffInfoVo;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.grouporder.controller.GroupOrderController;
import com.gome.meidian.grouporder.utils.*;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.wechatLogin.*;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.entity.UserRelation;
import com.gome.meidian.user.manager.IUserRelationManager;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.*;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import org.apache.catalina.User;
import org.slf4j.Logger;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.gome.architect.risk.dto.ExtKeyEnum;
import com.gome.architect.risk.dto.RequestV2;
import com.gome.architect.risk.dto.ResponseV2;
import com.gome.architect.risk.dto.ResultV2;
import com.gome.loom.model.TpModel;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.common.MeidianMemberService;
import com.gome.meidian.grouporder.common.MeidianRiskService;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.manager.IMShopShareRecordManager;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.meidian.user.manager.IUserRoleManager;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.GomeSNSUser;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.sso.model.UserInfoCache;
import com.gome.userCenter.common.constants.LoginConstants;
import com.gome.userCenter.facade.login.ISNSLoginFacade;
import com.gome.userCenter.facade.login.IUserLoginFacade;
import com.gome.userCenter.facade.register.IUserRegisterFacade;
import com.gome.userCenter.facade.userservice.profile.IUpdateProfileFacade;
import com.gome.userCenter.model.enu.RegisterSource;
import com.gome.userCenter.model.enu.RegisterType;
import redis.Gcache;
import javax.servlet.http.HttpServletResponse;


@Service
public class WechatLoginManager {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpClientUtil httpClientUtil;

	@Resource(name = "gcache")
	private Gcache gcache;

	@Resource(name = "userCenter")
	private Gcache userCenter;

	@Resource(name = "venusVshop")
	private Gcache venusVshopGcache;

	@Autowired
	private IUserInfoManager iUserInfoManager;

	@Autowired
	private IUserRoleManager iUserRoleManager;

	@Autowired
	private IUserRelationManager iUserRelationManager;


	@Value("${gome.gmsidValid.appId}")
	private String appId;

	//无线分配TOKEN
	public static  final  String   WX_TOKEN="tqn21am98krr0v8pc1grlaufm4q8pvbimzk";
	//无线分配Key
	public static  final  String   WX_KEY="wxMShop2018";
	//微信新用户登录绑定
	public static  final  String   LOGIN_BIND="loginBind";
	//微信新用户注册绑定
	public static  final  String   REGISTER_BIND="registerBind";
	//微信新用户手机号不可用
	public static  final  String   MOBILE_BIND="isBindMobile";
	//微信老用户没有绑定关系绑定国美账号失败
	public static  final  String   NO_BIND_TO_BIND_GOME_MOBILE="noBindToBindGomeMobile";


	//结果执行成功
	public static  final  String   RESULT_SUCCESS_YES="true";
	//结果执行失败
	public static  final  String   RESULT_SUCCESS_NO="false";

	//用户平台
	public static final  String   PLAT_FORM="ServiceMshop";
	//灯塔埋码值
	public static final  String   DSNSLOGIN_DISTINCTID="distinctId";

	//http请求逻辑

	@Autowired
	private ISNSLoginFacade iSNSLoginFacade;

	@Autowired
	private IUserRegisterFacade userRegisterFacade;


	@Autowired
	private IUpdateProfileFacade iUpdateProfileFacade;

	@Autowired
	private IUserLoginFacade iUserLoginFacade;

	@Autowired
	private MeidianRiskService meidianRiskService;

	@Autowired
	private MeidianMemberService meidianMemberService;

	@Autowired
	private GroupOrderManager groupOrderManager;


	@Autowired
	private UserAndRegisterRiskSwitchManager userAndRegisterRiskSwitchManager;


	//接口来源参数
	public  static final String INVOKE_FROM="gomeShop";

	public  static final String INVOKE_CHANNEL="gomeShopWeChat";
	//请求来源
	public  static final String  WHERE_FROM="wechat";
	//注册来源
	public  static final String REGISTER_FROM_WAP="gomeShopWap";
	//注册来源
	public  static final String REGISTER_FROM_WECHAT="gomeShopWeChat";
	//登录公司
	public  static final String LOGIN_COMPANY_NAME="gomeOnLine";


	@Value("${cookie.path}")
	private String path;

	@Value("${cookie.domain}")
	private String domain;

	@Value("${cookie.time}")
	private int time;


	@Value("${wechat.bindUser.url}")
	private String bindUserUrl;//http://wx.wireless.api/bind/user


	@Value("${wechat.bindUser.distance}")
	private long distance;

	@Value("${wechat.bindUser.shareUrl}")
	private String shareUrl;


	private final static byte USER_ALREADY_LOGIN = 1; // 用户已登录
	private final static byte USER_NOT_LOGIN = 0; // 用户未登录

	@Autowired
	private IUserInfoFacade iUserInfoFacade;

	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	@Autowired
	private IMShopShareRecordManager iMShopShareRecordManager;


	/**
	 * 校验手机号是否可用
	 * @param mobile
	 * @return
	 */
	public  Object  checkMobileIsCanUse(String mobile){
		MapResult<Void>  result= isBindMobile(mobile);
		Map<String,Object>  resultMap=new HashMap<String,Object>();
		resultMap.put("isSuccess",result.isSuccess());
		resultMap.put("code",result.getCode());
		resultMap.put("message",result.getMessage());
		return result;
	}


	/**
	 * 生成发起授权信息获取的令牌Token
	 * @return
	 */
	public  String   getToken() throws Exception {
		Long time=System.currentTimeMillis()/1000l;
		String md5=WxDES.md5(WX_TOKEN);
		String sign=md5+time.toString();
		String encodeSS = MobileDES.encryptDES(sign,WX_KEY.substring(0,8));
		encodeSS=encodeSS.replace(" ","");
		String urlEncode= null;
		try {
			urlEncode = URLEncoder.encode(encodeSS,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return urlEncode;
	}


	/**
	 * 兼容php和本地机器时间不一致问题，向前兼容60s
	 * @return
	 * @throws Exception
	 */
	public  String   getTokenForShare() throws Exception {
		Long time=System.currentTimeMillis()/1000l;
		//time=time-60l;
		String md5=WxDES.md5(WX_TOKEN);
		String sign=md5+time.toString();
		String encodeSS = MobileDES.encryptDES(sign,WX_KEY.substring(0,8));
		encodeSS=encodeSS.replace(" ","");
		String urlEncode= null;
		try {
			urlEncode = URLEncoder.encode(encodeSS,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return urlEncode;
	}

	/**
	 * 三方联合登录
	 * @param headImageUrl 用户头像
	 * @param userInfo    微信授权信息加密
	 * @param distinctId  灯塔埋码
	 * @param request
	 * @return
	 */
	public  DoSNSLoginVO   doSNSLogin(String headImageUrl, String userInfo, String distinctId,String createType,HttpServletRequest request,HttpServletResponse response) throws ServiceException {
		//1.解密微信授权信息
		String sNSUserName="";
		String sNSUserId="";
		String openId=null;
		WeChatUserInfo  weChatUserInfo=null;
		weChatUserInfo=decryptDESWeChatUserInfo(userInfo,headImageUrl);
		if(null!=weChatUserInfo){
			sNSUserName=weChatUserInfo.getNickname();
			sNSUserId=weChatUserInfo.getUnionid();
			openId=weChatUserInfo.getOpenid();
			headImageUrl=weChatUserInfo.getHeadImageUrl();
		}

		//2.会员接口三方登录调用判断是否是新老用户
		GomeSNSUser gomeSNSUser=new GomeSNSUser(null,WHERE_FROM,sNSUserId,sNSUserName,null,headImageUrl);
		RequestParams requestParams=new RequestParams();
		requestParams.setInvokeChannel(INVOKE_CHANNEL);
		String ip=meidianRiskService.getIP(request);
		String port=meidianRiskService.getPort(request);
		requestParams.setClientIp(ip);
		requestParams.setHostPort(port);
		Map map=new HashMap();
		map.put(LoginConstants.SNS_UNION_ID_KEY,sNSUserId);
		map.put(LoginConstants.SNSUSER_REGISTER,"false");
		String  gomeShopWeChat=RegisterSource.gomeShopWeChat.getName();
		map.put(LoginConstants.SNS_REGISTER_SOURCE_KEY,gomeShopWeChat);
		map.put(DSNSLOGIN_DISTINCTID,distinctId);
		UserLoginResult<UserInfo>  result=null;
		try{
			result=iSNSLoginFacade.doSNSLogin(gomeSNSUser,requestParams,map);
		}catch (Exception e){
			logger.error("WechatLoginManager-doSNSLogin-doSNSLogin-gomeSNSUser-{},error:{}",gomeSNSUser,e);
			throw new ServiceException("wechat.login.doSNSLogin.call.error");
		}
		//3.封装结果信息
		Map<String, Object>  extraInfoMap=result.getExtraInfoMap();
		String isMobileActived= "";
		String identifyLevel="";
		String SCN= null;
		String memberCode="";
		if(null!=extraInfoMap&&extraInfoMap.size()>0){
			isMobileActived= (String)extraInfoMap.get("isMobileActived");
			identifyLevel= (String)extraInfoMap.get("identifyLevel");
			SCN= (String)extraInfoMap.get("SCN");
			try {
				SCN=URLEncoder.encode(SCN,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				logger.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",SCN,e);
			}
		}

		UserInfo bussinessObject=result.getBuessObj();
		String userId=null;
		String bindUserId="";
		String nickName="";
		GomeSNSUser snsInfo=null;
		if(null!=bussinessObject){
			bindUserId=bussinessObject.getBindUserId();
			nickName=bussinessObject.getNikename();
			//snsInfo=bussinessObject.getSnsInfo();
			userId=bussinessObject.getId();

		}
		Boolean  success=result.isSuccess();
		String message=result.getMessage();
		Integer code=result.getCode();
		if(null!=code){
			memberCode=code.toString();
		}
		DoSNSLoginVO  vo=new DoSNSLoginVO();
		vo.setSuccess(success.toString());
		vo.setMessage(message);
		vo.setIsMobileActived(isMobileActived);
		vo.setIdentifyLevel(identifyLevel);
		vo.setBindUserId(bindUserId);
		vo.setScn(SCN);
		vo.setHeadImageUrl(headImageUrl);
		vo.setsNSUserName(sNSUserName);
		vo.setNickName(nickName);
		vo.setUserId(userId);
		vo.setMemberCode(memberCode);

		//4.登录用户信息记录
		recordUserToUserCenterByUserId(userId,createType,request);

		//5.绑定关系记录
		Boolean updateBind=false;

		//6.写COOKIE
		if(success&&StringUtils.isNotBlank(SCN)){
			updateBind=handleUserAndOpenId(userId,openId,sNSUserId,sNSUserName,new WeChatLoginResultVO());
			CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID,userId,path,domain,time);


		}

		vo.setUpdateBind(updateBind);

		//7.填充用户信息
		if(null!=userId&&StringUtils.isNotBlank(userId)){
			AuthencationVo  authencationVo=getAutencationVo(userId);
			if(null!=authencationVo&&null!=authencationVo.getUserId()){
				vo.setGomeNickName(authencationVo.getNickName());
				vo.setShopId(authencationVo.getShopId());
				vo.setStoreNo(authencationVo.getStoreNo());
				vo.setStaffNo(authencationVo.getStaffNo());
			}
		}
		return vo;
	}



	/**
	 * 获取绑定手机号验证码
	 * 微信新用户绑定国美账号
	 * 微信老用户没有绑定关系绑定国美账号
	 * @param mobile
	 * @param request
	 * @return
	 */
	public Object getNewWeChatSmsCode(String mobile,String ufpd, HttpServletRequest request) throws MeidianException {
		WeChatLoginResultVO vo=new WeChatLoginResultVO();
		//1.验证码风控
		boolean riskFlag=isSMSRiskCheck(mobile,ufpd,request,vo);
		if(riskFlag==false){
			return vo;
		}
		//2.手机号可用检查
		MapResult<Void> mobileResult=isBindMobile(mobile);
		if (mobileResult.isSuccess()) {
			vo.setMemberCode("200");
			// 说明用户不冲突，可以发送短信；
			// code为400时说明用户不存在，需要走注册流程
			// 直接走发送流程
		}else if(!mobileResult.isSuccess()&&mobileResult.getCode()==400){
			vo.setMemberCode("400");
		}else{
			logger.info("getNewWeChatSmsCode-error mobile:{} mobileResult:{}",mobile,mobileResult);
			//80002#微信新用户绑定手机号不可用
			vo.setSuccess(RESULT_SUCCESS_NO);
			Integer mobileResultCode=mobileResult.getCode();
			if(null!=mobileResultCode){
				vo.setMemberCode(mobileResultCode.toString());
			}else{
				vo.setMemberCode("80002");
			}
			vo.setMessage(mobileResult.getMessage());
			return vo;
			//throw new  ServiceException("wechat.login.getNewWeChatSmsCode.mobile.error");
		}
		//3.发送短信
		boolean sendSmsFlag=sendSms(MeidianMemberService.GOMESHOP_BIND_PHONE_BUSINESSNAME,MeidianMemberService.GOMESHOP_BIND_PHONE_BUSINESSNAME_ID,mobile,"",vo);
		if(sendSmsFlag==false){
			return vo;
		}
		vo.setSuccess(RESULT_SUCCESS_YES);
		return vo;
	}



	/**
	 * 新用户绑定国美账号
	 * @param mobile
	 * @param code
	 * @param userInfo
	 * @param request
	 * @throws MeidianException
	 */
	public WeChatLoginResultVO newWeChatBindGomeAccount(String mobile,String code,String headImageUrl,String userInfo,String createType,HttpServletRequest request,HttpServletResponse response) throws MeidianException {
		//1.微信授权信息解密
		String sNSUserName="";
		String sNSUserId="";
		String  openId="";
		WeChatUserInfo  weChatUserInfo=null;
		weChatUserInfo=decryptDESWeChatUserInfo(userInfo,headImageUrl);
		if(null!=weChatUserInfo){
			sNSUserName=weChatUserInfo.getNickname();
			sNSUserId=weChatUserInfo.getUnionid();
			openId=weChatUserInfo.getOpenid();
			headImageUrl=weChatUserInfo.getHeadImageUrl();
		}
		//2.校验验证码
		checkSmsCode(MeidianMemberService.GOMESHOP_BIND_PHONE_BUSINESSNAME,mobile,code,true,"新用户绑定手机号");
		//3.手机号是否可用校验
		MapResult<Void> mobileResult=isBindMobile(mobile);
		int bindMobileCode = mobileResult.getCode();
		String scn=null;
		String  success="";//成功为true，失败false失败原因看code字段
		String  memberCode=null;//会员code  6001是新用户
		String  userType=null;//loginBind or registerBind
		String  message=null;
		String  userId=null;//用户ID
		String nickName=null;
		if (!mobileResult.isSuccess() && bindMobileCode == 400) {
			// 注册登录  说明用户不冲突，可以发送短信；
			UserRegisterResult<GomeRegisterUser>  registerResult=regUser(mobile, sNSUserId,sNSUserName,request);
			if (registerResult.isSuccess()) {
			    // 调用成功  获取SCN
				success=WechatLoginManager.RESULT_SUCCESS_YES;
			    scn= (String)registerResult.getExtMap().get("SCN");
				GomeRegisterUser gomeRegisterUser=registerResult.getBuessObj();
				if(null!=gomeRegisterUser){
					userId=gomeRegisterUser.getId();
				}
				Integer codeResult=registerResult.getCode();
				if(null!=codeResult){
					memberCode=code.toString();
				}
				message=registerResult.getMessage();
			}else{
				//1005,"用户注册失败"
				success=WechatLoginManager.RESULT_SUCCESS_NO;
				memberCode="80005";//80005#微信新用户注册失败
				message=registerResult.getMessage();
				logger.info("WeChatLoginManager-newWeChatBindGomeAccount-register-error:{}",registerResult);
			}
			userType=WechatLoginManager.REGISTER_BIND;

		}else if(mobileResult.isSuccess()){
			//登录绑定
			//1004,"用户为弱密码"
			//1003,"用户关联失败"
			UserLoginResult<UserInfo> mobileLogin=mobileLogin(mobile,sNSUserId, sNSUserName,headImageUrl, request);
			if (mobileLogin.isSuccess()) {
				success=WechatLoginManager.RESULT_SUCCESS_YES;
				//登录并绑定成功
				//获取SCN
				 scn =(String)mobileLogin.getExtraInfoMap().get("SCN");
				UserInfo userInfoMobileLogin=mobileLogin.getBuessObj();
				if(null!=userInfoMobileLogin){
					userId=userInfoMobileLogin.getId();
				}
				message=mobileLogin.getMessage();
				Integer mobileLoginCode=mobileLogin.getCode();
				if(null!=mobileLoginCode){
					memberCode=mobileLoginCode.toString();
				}

			}else{
				success=WechatLoginManager.RESULT_SUCCESS_NO;
				memberCode="80006";//80006#微信新用户登录绑定失败
				message=mobileLogin.getMessage();
				logger.info("WeChatLoginManager-newWeChatBindGomeAccount-loginBind-error:{}",mobileLogin);
				//throw new ServiceException("wechat.login.newWeChatBindGomeAccount.loginBind.error");
			}
			//1004,"用户为弱密码"  1003,"用户关联失败"
			userType=WechatLoginManager.LOGIN_BIND;
		}else{
			//1005,"用户注册失败"
			success=RESULT_SUCCESS_NO;
			userType=MOBILE_BIND;
			message=mobileResult.getMessage();
			Integer mobileCodeResult=mobileResult.getCode();
			if(null!=mobileCodeResult){
				memberCode=mobileCodeResult.toString();
			}
		}

		//4.登录信息记录
		if(null!=scn&&null!=userId){
			recordUserToUserCenterByUserId(userId,createType,request);
		}


		WeChatLoginResultVO vo=new WeChatLoginResultVO();
		vo.setSuccess(success);
		vo.setMemberCode(memberCode);
		vo.setMessage(message);

		vo.setHeadImageUrl(headImageUrl);
		vo.setsNSUserName(sNSUserName);
		vo.setScn(scn);
		vo.setUserType(userType);
		vo.setUserId(userId);


		//5. 绑定关系记录
		Boolean updateBind=false;

		//6. 写COOKIE
		if(RESULT_SUCCESS_YES.equals(success)&&StringUtils.isNotBlank(scn)){
			try {
				scn=URLEncoder.encode(scn,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				logger.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",scn,e);
			}
			updateBind=handleUserAndOpenId(userId,openId,sNSUserId,sNSUserName,vo);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,scn,path,domain,time);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID,userId,path,domain,time);
		}

		vo.setUpdateBind(updateBind);


		//7.填充用户信息
		if(null!=userId&&StringUtils.isNotBlank(userId)){
			AuthencationVo  authencationVo=getAutencationVo(userId);
			if(null!=authencationVo&&null!=authencationVo.getUserId()){
				vo.setGomeNickName(authencationVo.getNickName());
				vo.setShopId(authencationVo.getShopId());
				vo.setStoreNo(authencationVo.getStoreNo());
				vo.setStaffNo(authencationVo.getStaffNo());
			}
		}
		return vo;
	}


	/**
	 * 新注册账号做默认绑定微信账号逻辑
	 * @param mobile
	 * @param headImageUrl
	 * @param userInfo
	 * @param createType
	 * @param request
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	public WeChatLoginResultVO weChatBindNewRegisterGomeAccount(String mobile,String headImageUrl,String userInfo,String createType,HttpServletRequest request,HttpServletResponse response) throws MeidianException {
		//1.微信授权信息解密
		String sNSUserName="";
		String sNSUserId="";
		String  openId="";
		String  code="";
		WeChatUserInfo  weChatUserInfo=null;
		weChatUserInfo=decryptDESWeChatUserInfo(userInfo,headImageUrl);
		if(null!=weChatUserInfo){
			sNSUserName=weChatUserInfo.getNickname();
			sNSUserId=weChatUserInfo.getUnionid();
			openId=weChatUserInfo.getOpenid();
			headImageUrl=weChatUserInfo.getHeadImageUrl();
		}
		//2.手机号是否可用校验
		MapResult<Void> mobileResult=isBindMobile(mobile);
		int bindMobileCode = mobileResult.getCode();
		String scn=null;
		String  success="";//成功为true，失败false失败原因看code字段
		String  memberCode=null;//会员code  6001是新用户
		String  userType=null;//loginBind or registerBind
		String  message=null;
		String  userId=null;//用户ID
		String nickName=null;
		if (!mobileResult.isSuccess() && bindMobileCode == 400) {
			// 说明用户不冲突，可以发送短信； 注册登录
			UserRegisterResult<GomeRegisterUser>  registerResult=regUser(mobile, sNSUserId,sNSUserName,request);
			if (registerResult.isSuccess()) {
				// 调用成功  获取SCN
				success=WechatLoginManager.RESULT_SUCCESS_YES;
				scn= (String)registerResult.getExtMap().get("SCN");
				GomeRegisterUser gomeRegisterUser=registerResult.getBuessObj();
				if(null!=gomeRegisterUser){
					userId=gomeRegisterUser.getId();
				}
				Integer codeResult=registerResult.getCode();
				if(null!=codeResult){
					memberCode=code.toString();
				}
				message=registerResult.getMessage();
			}else{
				success=WechatLoginManager.RESULT_SUCCESS_NO;
				memberCode="80005";//80005#微信新用户注册失败
				message=registerResult.getMessage();

				//1005,"用户注册失败"
				logger.info("WeChatLoginManager-weChatBindNewRegisterGomeAccount-register-error:{}",registerResult);
				//throw new ServiceException("wechat.login.newWeChatBindGomeAccount.reg.error");
			}
			userType=WechatLoginManager.REGISTER_BIND;

		}else if(mobileResult.isSuccess()){
			//1004,"用户为弱密码"
			//1003,"用户关联失败"
			UserLoginResult<UserInfo> mobileLogin=mobileLogin(mobile,sNSUserId, sNSUserName,headImageUrl, request);
			if (mobileLogin.isSuccess()) {
				success=WechatLoginManager.RESULT_SUCCESS_YES;
				//登录并绑定成功 获取SCN
				scn =(String)mobileLogin.getExtraInfoMap().get("SCN");
				UserInfo userInfoMobileLogin=mobileLogin.getBuessObj();
				if(null!=userInfoMobileLogin){
					userId=userInfoMobileLogin.getId();
				}
				message=mobileLogin.getMessage();
				Integer mobileLoginCode=mobileLogin.getCode();
				if(null!=mobileLoginCode){
					memberCode=mobileLoginCode.toString();
				}

			}else{
				success=WechatLoginManager.RESULT_SUCCESS_NO;
				memberCode="80006";//80006#微信新用户登录绑定失败
				message=mobileLogin.getMessage();
				logger.info("WeChatLoginManager-weChatBindNewRegisterGomeAccount-loginBind-error:{}",mobileLogin);
				//throw new ServiceException("wechat.login.newWeChatBindGomeAccount.loginBind.error");
			}
			//1004,"用户为弱密码"  1003,"用户关联失败"
			userType=WechatLoginManager.LOGIN_BIND;
		}else{
			//1005,"用户注册失败"
			success=RESULT_SUCCESS_NO;
			userType=MOBILE_BIND;
			message=mobileResult.getMessage();
			Integer mobileCodeResult=mobileResult.getCode();
			if(null!=mobileCodeResult){
				memberCode=mobileCodeResult.toString();
			}
		}

		if(null!=scn&&null!=userId){
			recordUserToUserCenterByUserId(userId,createType,request);
		}

		WeChatLoginResultVO vo=new WeChatLoginResultVO();
		vo.setSuccess(success);
		vo.setMemberCode(memberCode);
		vo.setMessage(message);

		vo.setHeadImageUrl(headImageUrl);
		vo.setsNSUserName(sNSUserName);
		vo.setScn(scn);
		vo.setUserType(userType);
		vo.setUserId(userId);


		Boolean updateBind=false;

		//3.写COOKIE
		if(RESULT_SUCCESS_YES.equals(success)&&StringUtils.isNotBlank(scn)){
			try {
				scn=URLEncoder.encode(scn,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				logger.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",scn,e);
			}
			updateBind=handleUserAndOpenId(userId,openId,sNSUserId,sNSUserName,vo);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,scn,path,domain,time);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID,userId,path,domain,time);

		}

		vo.setUpdateBind(updateBind);


		//7.填充用户信息
		if(null!=userId&&StringUtils.isNotBlank(userId)){
			AuthencationVo  authencationVo=getAutencationVo(userId);
			if(null!=authencationVo&&null!=authencationVo.getUserId()){
				vo.setGomeNickName(authencationVo.getNickName());
				vo.setShopId(authencationVo.getShopId());
				vo.setStoreNo(authencationVo.getStoreNo());
				vo.setStaffNo(authencationVo.getStaffNo());
			}
		}
		return vo;
	}

	/**
	 * 微信老用户没有绑定关系--绑定国美账号
	 * 校验验证码
	 * 第三方绑定
	 * 登录信息记录
	 * 绑定关系存储，记录
	 * @param mobile
	 * @param code
	 * @param headImageUrl
	 * @param userInfo
	 * @param createType
	 * @param request
	 * @throws MeidianException
	 */
	public WeChatLoginResultVO oldWeChatNoRelationToBindGomeAccount(String scn,String mobile,String code,String headImageUrl, String userInfo,String createType,HttpServletRequest request,HttpServletResponse response) throws MeidianException {
		//1.微信授权信息解密
		String sNSUserName="";
		String sNSUserId="";
		String  openId=null;
		String userId=null;
		UserInfoCache userInfoCache= null;
		try {
			userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		} catch (ServiceException e) {
			logger.info("WeChatLoginManager-checkScnByDubbo-scn:{}  e-{}",scn,e);
		}
		if(null==userInfoCache){
			WeChatLoginResultVO  vo=new WeChatLoginResultVO();
			vo.setSuccess(RESULT_SUCCESS_NO);
			vo.setMessage("SCN过期");
			vo.setMemberCode("1301");
			return vo;
		}
		userId=userInfoCache.getId();
		WeChatUserInfo  weChatUserInfo=null;
		weChatUserInfo=decryptDESWeChatUserInfo(userInfo,headImageUrl);
		if(null!=weChatUserInfo){
			sNSUserName=weChatUserInfo.getNickname();
			sNSUserId=weChatUserInfo.getUnionid();
			openId=weChatUserInfo.getOpenid();
			headImageUrl=weChatUserInfo.getHeadImageUrl();
		}


		//2.校验验证码
		checkSmsCode(MeidianMemberService.GOMESHOP_BIND_PHONE_BUSINESSNAME,mobile,code,true,"微信老用户绑定国美账号");
		//3.第三方绑定
		GomeSNSUser gomeUser=new GomeSNSUser(userId,WHERE_FROM,sNSUserId,sNSUserName,null,headImageUrl);

		MapResult<Void>  bindResult=userRegisterFacade.bindSnsUserMobile(gomeUser,mobile,INVOKE_CHANNEL);
		String  success="";//成功为true，失败false失败原因看code字段
		String  memberCode=null;//会员code  6001是新用户
		String  message=null;
		if(bindResult.isSuccess()){
			success=RESULT_SUCCESS_YES;
			Integer bindResultCode=bindResult.getCode();
			if(null!=bindResultCode){
				memberCode=bindResultCode.toString();
			}
			message=bindResult.getMessage();
			Map  extParam =bindResult.getExtParams();
			if(null!=extParam){
				scn=(String)extParam.get("SCN");
				userId=(String)extParam.get("userId");
				if(null!=scn&& StringUtils.isNotBlank(scn)){
					try {
						scn=URLEncoder.encode(scn,"UTF-8");
					} catch (UnsupportedEncodingException e) {
						logger.info("WeChatLoginManager-oldWeChatNoRelationToBindGomeAccount-scn-Encode-error SCN:{} ,userId:{}",scn,userId);
					}
				}
			}
		}else{
			success=RESULT_SUCCESS_NO;
			memberCode="80009";//#微信老用户无绑定关系绑定国美账号失败
			message=bindResult.getMessage();
		}

		//登录信息记录
		if(null!=bindResult){
			recordUserToUserCenterByUserId(userId,createType,request);
		}
		WeChatLoginResultVO  vo=new WeChatLoginResultVO();
		vo.setSuccess(success);
		vo.setMessage(message);
		vo.setMemberCode(memberCode);
		vo.setScn(scn);
		vo.setUserId(userId);
		vo.setNickName(null);
		vo.setHeadImageUrl(headImageUrl);
		vo.setsNSUserName(sNSUserName);
		vo.setUserType(NO_BIND_TO_BIND_GOME_MOBILE);

		//4.绑定关系记录
		Boolean updateBind=false;

		//5.写COOKIE
		if(RESULT_SUCCESS_YES.equals(success)&&StringUtils.isNotBlank(scn)){
			updateBind=handleUserAndOpenId(userId,openId,sNSUserId,sNSUserName,vo);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,scn,path,domain,time);
			CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID,userId,path,domain,time);
		}

		vo.setUpdateBind(updateBind);


		//7.填充用户信息
		if(null!=userId&&StringUtils.isNotBlank(userId)){
			AuthencationVo  authencationVo=getAutencationVo(userId);
			if(null!=authencationVo&&null!=authencationVo.getUserId()){
				vo.setGomeNickName(authencationVo.getNickName());
				vo.setShopId(authencationVo.getShopId());
				vo.setStoreNo(authencationVo.getStoreNo());
				vo.setStaffNo(authencationVo.getStaffNo());
			}
		}
		return  vo;

	}



	/**
	 * 微信老用户有绑定关系-完善国美账号
	 * @param mobile
	 * @param ufpd
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	public Object getCompleteMobileSmsCode(String mobile,String ufpd, HttpServletRequest request) throws MeidianException {
		WeChatLoginResultVO vo=new WeChatLoginResultVO();
		//1.验证码风控
		boolean riskFlag=isSMSRiskCheck(mobile,ufpd,request,vo);
		if(riskFlag==false){
			return vo;
		}
		//2.手机号可用检查
		MapResult<Void> mobileResult=isBindMobile(mobile);
		if (!mobileResult.isSuccess()&&mobileResult.getCode()==400) {
			// 说明用户不冲突，可以发送短信；
			// code为400时说明用户不存在，需要走注册流程
			// 直接走发送流程
			vo.setMemberCode("400");
		}else{
			//80007#完善手机号手机号已经存在
			vo.setSuccess(RESULT_SUCCESS_NO);
			vo.setMemberCode("80007");
			vo.setMessage("完善手机号手机号已经存在");
			return vo;
		}
		//3.发送手机验证码
		boolean sendSmsFlag=sendSms(MeidianMemberService.GOMESHOP_COMPLETA_PHONE_BUSINESSNAME,MeidianMemberService.GOMESHOP_COMPLETA_PHONE_BUSINESSNAME_ID,mobile,"",vo);
		if(sendSmsFlag==false){
			return vo;
		}
		vo.setSuccess(RESULT_SUCCESS_YES);
		return vo;
	}

	/**
	 * 激活手机号
	 * @param scn
	 * @param newMobile
	 * @param request
	 * @throws MeidianException
	 */
	public Object updateMobileAndIsActived(String scn,String newMobile,String code,HttpServletRequest request) throws MeidianException {
		//1.校验手机号是否正确
		checkSmsCode(MeidianMemberService.GOMESHOP_COMPLETA_PHONE_BUSINESSNAME,newMobile,code,true,"老用户完善手机号校验验证码");
		UserInfoCache userInfoCache= null;
		try {
			userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		} catch (ServiceException e) {
			logger.info("WeChatLoginManager-checkScnByDubbo-scn:{}  e-{}",scn,e);
		}
		//2.第三方绑定关系
		if(null==userInfoCache){
			throw new ServiceException("wechat.login.scn.expire.error");
		}
		String userId=userInfoCache.getId();

		UserResult<Integer> updateResult=iUpdateProfileFacade.updateMobileAndIsActived(userId,newMobile,"Y",INVOKE_CHANNEL);

		return  updateResult;

	}


	/**
	 * 验证码风控检查
	 * @param mobile
	 * @param ufpd
	 * @param request
	 * @return
	 * @throws ServiceException
	 */
	public  boolean  isSMSRiskCheck(String mobile,String ufpd, HttpServletRequest request,WeChatLoginResultVO vo) throws ServiceException {

		String riskStatus=userCenter.get(UserAndRegisterRiskSwitchManager.RISK_SWITCH_WAP_MEIDIAN_MOBILE_SMS);
		if(null!=riskStatus&&RESULT_SUCCESS_NO.equals(riskStatus)){
			//当标识是null 或者 false的时候,风控降级
			return true;
		}
		RequestV2 requestV2 = new RequestV2();
		requestV2.setPhone(mobile);
		String ip = meidianRiskService.getIP(request);
		requestV2.setUserId(mobile);
		//修正IP
		requestV2.setIp(ip);
		requestV2.setUfpd(ufpd);
		requestV2.setBizNo(MeidianRiskService.BIZNO_SMS_MOBILE);
		String cookie=request.getHeader(MeidianRiskService.REQUEST_HEADER_COOKIE);
		String refer=request.getHeader(MeidianRiskService.REQUEST_HEADER_REFER);
		String ua=request.getHeader(MeidianRiskService.REQUEST_HEADER_UA);
		Map<ExtKeyEnum, String> extensionField = new HashMap<>();
		extensionField.put(ExtKeyEnum.COOKIE, cookie);
		extensionField.put(ExtKeyEnum.REFER, refer);
		extensionField.put(ExtKeyEnum.UA, ua);
		requestV2.setExtensionField(extensionField);
		ResultV2<ResponseV2> riskResult=null;
		try {
			riskResult=meidianRiskService.predict(requestV2);
		} catch (MeidianException e) {
			vo.setSuccess(RESULT_SUCCESS_NO);
			vo.setMemberCode("80014");
			vo.setMessage("风控服务调用失败");
			logger.error("meidianRiskService-predict:request-{},riskResult-{}, e-{}",requestV2,riskResult,e);
			return false;
		}
		//400  参数错误，正常应该是联调阶段可能会出现
		//200  预测无风险或者风险小，通过
		//201  风险大 拦截
		//500  风控服务内部异常
		if (riskResult != null) {
			switch (riskResult.getCode()) {
				case 200:
					logger.info("风控验证通过--"+mobile);
					break;
				case 400:
					logger.error("meidianRiskService-predict:风控验证参数错误request-{},riskResult-{}",requestV2,riskResult);
					vo.setSuccess(RESULT_SUCCESS_NO);
					vo.setMemberCode("80010");
					vo.setMessage("参数错误，正常应该是联调阶段可能会出现");
					return false;
				case 201:
					logger.error("meidianRiskService-predict:风险大拦截 request-{},riskResult-{}",requestV2,riskResult);
					vo.setSuccess(RESULT_SUCCESS_NO);
					vo.setMemberCode("80011");
					vo.setMessage("风险大拦截");
					return false;
				case 500:
					logger.error("meidianRiskService-predict:风控服务内部异常request-{},riskResult-{}",requestV2,riskResult);
					vo.setSuccess(RESULT_SUCCESS_NO);
					vo.setMemberCode("80012");
					vo.setMessage("风控服务内部异常");
					return false;
			}
		}

		return true ;

	}
	/**
	 * 判断手机号是否可用
	 * @param mobile
	 * @return
	 */
	public  MapResult<Void>  isBindMobile(String mobile){
		Map extMap=new HashMap();
		extMap.put(LoginConstants.COMPANYNAME, "gomeOnLine");
		extMap.put(LoginConstants.UNIFY_WHERE_FROM,WHERE_FROM);
		MapResult<Void> result= userRegisterFacade.isBindMobile(mobile,INVOKE_CHANNEL,extMap);
		return result;
	}


	/**
	 * TpModel的参数对应申请的BusinessName,模板Id
	 * TpModel smsModel = new TpModel("businessName","111");
	 * smsModel.setPhone("1810XXXXX"); //发送的手机号
	 * smsModel.setIntervalTime(1); //是否延迟发送如果延迟发送需要设置,单位:小时. 实时发送丌需要设置，默认0）
	 * smsModel.putTempParams("code", "234567");//模板要替换的参数,对接短信模板里的#code# （有多个参数，调用此方法多次，注意：这里的参数对应模板里的#code#, 其他参数类似，都是带#号，比如参数abc对应模板里#abc#）
	 * dubbo调用发送短信(result一定会返回，丌用做null判断)
	 * @param mobile
	 */
	public boolean  sendSms(String businessName,String templateId,String mobile,String code,WeChatLoginResultVO vo) throws MeidianException {
		TpModel  tpModel=new TpModel(businessName,templateId);
		tpModel.setPhone(mobile);
		tpModel.setIntervalTime(0);
		//tpModel.putTempParams("code", code);
		boolean smsFlag=meidianMemberService.sendSms(tpModel);
		if(false==smsFlag){
			logger.error("meidianMemberService-sendSms-mobile-fail:{} ",mobile);
			//80013#验证码发送失败
			vo.setSuccess(RESULT_SUCCESS_NO);
			vo.setMemberCode("80013");
			vo.setMessage("验证码发送失败");
			return false;
		}

		return true;


	}


	/**
	 *
	 * @param businessName  业务
	 * @param mobile        手机号
	 * @param smsCode       code
	 * @param flag          校验完是否清掉验证码，分为比较和验证
	 * @param source
	 * @throws MeidianException
	 */
	public void checkSmsCode(String businessName,String mobile,String smsCode,boolean flag,String source) throws MeidianException {
		boolean smsResult = meidianMemberService.checkVcode(businessName,mobile,smsCode,flag);
		if(smsResult){
			logger.info("meidianMemberService-checkVcode-mobile-success:{}",mobile);
		}else{
			throw new ServiceException("wechat.login.newWeChatBindGomeAccount.checkCode.error");
		}
	}

	/**
	 * 登录绑定用户获取SCN
	 * @param mobile
	 * @param sNSUserId
	 * @param sNSUserName
	 * @param headImageUrl
	 * @param request
	 * @return
	 */
	public  UserLoginResult<UserInfo>   mobileLogin(String mobile, String  sNSUserId,String sNSUserName,String headImageUrl,HttpServletRequest request){
		// 1.填充请求信息
		GomeSNSUser gomeSNSUser=new GomeSNSUser(null,WHERE_FROM,sNSUserId,sNSUserName,null,headImageUrl);

		RequestParams requestParams=new RequestParams();
		String ip=meidianRiskService.getIP(request);
		String port=meidianRiskService.getPort(request);
		requestParams.setInvokeChannel(INVOKE_CHANNEL);
		requestParams.setClientIp(ip);
		requestParams.setHostPort(port);
		//扩展map
		Map<String, Object> map=new HashMap<String, Object>();
		map.put(LoginConstants.COMPANYNAME,LOGIN_COMPANY_NAME);
		map.put(LoginConstants.ISBINDSNSUSER,true);
		map.put(LoginConstants.GOMESNSUSER,gomeSNSUser);
		map.put(LoginConstants.SNS_UNION_ID_KEY,sNSUserId);
		map.put(LoginConstants.SNS_REGISTER_SOURCE_KEY,REGISTER_FROM_WECHAT);
		// whereFrom为第三方用户来源，如qq、wechat等；
		// snsUserId为第三方接口交互拿到的openId
		// snsUserName为第三方接口交互拿到的昵称
		UserLoginResult<UserInfo> mobileLogin = iUserLoginFacade.mobileLogin(mobile, requestParams, map);
		return mobileLogin;


	}


	/**
	 * 新用户注册
	 * @param mobile
	 * @param sNSUserId
	 * @param request
	 * @return
	 */
	public  UserRegisterResult<GomeRegisterUser>   regUser(String mobile, String  sNSUserId,String snsUserName,HttpServletRequest request){
		//填充请求信息
		GomeRegisterUser gomeRegisterUser=new GomeRegisterUser();
		//注册类型	业务	N	registerType
		//commonReg：普通注册
		//mobileReg：手机注册
		//emailReg：邮箱注册
		//mobileQuickReg：手机快速注册"
		//注册ip	业务	N	registerIp	string		用户的ip地址
		//注册来源	业务	N	registerSource	string		找会员组申请
		//用户名	业务	Y	login	string
		//密码	业务	N	password	string		无密码默认传SNS_GOME_PWD
		//手机号	业务	N	mobile	string
		gomeRegisterUser.setRegisterType(RegisterType.mobileReg);
		String ip=meidianRiskService.getIP(request);
		gomeRegisterUser.setRegisterIp(ip);
		//注册来源
		gomeRegisterUser.setRegisterSource(RegisterSource.gomeShopWeChat);
		gomeRegisterUser.setLogin(null);
		gomeRegisterUser.setPassword("SNS_GOME_PWD");
		gomeRegisterUser.setMobile(mobile);

		GomeSNSUser snsUser = new GomeSNSUser(null, WHERE_FROM, sNSUserId, snsUserName);
		//扩展map
		Map<String, Object> map=new HashMap<String, Object>();
		map.put(LoginConstants.ISBINDSNSUSER,true);
		map.put(LoginConstants.GOMESNSUSER,snsUser);
		map.put(LoginConstants.ISAUTHORIZED,"Y");//授权码传Y
		map.put(LoginConstants.SNS_USER_ID_KEY,sNSUserId);
		map.put(LoginConstants.SNS_UNION_ID_KEY,sNSUserId);
		// registerSource跟为你分配的值保持一致，传unmannedShopApp
		map.put(LoginConstants.SNS_REGISTER_SOURCE_KEY,REGISTER_FROM_WECHAT);
		map.put(LoginConstants.COMPANYNAME,LOGIN_COMPANY_NAME);
		UserRegisterResult<GomeRegisterUser> registerResult= userRegisterFacade.regUser(gomeRegisterUser, map);
		logger.info("weChatLoginManager-newWechat-regUser  mobile:{},sNSUserId:{},snsUserName:{},registerResult:{}",mobile,sNSUserId,snsUserName,registerResult);
		return registerResult;
	}

	/**
	 * 记录登录用户信息到用户池中
	 * @param scn
	 * @param createType
	 * @param request
	 */
	public  void   recordUserToUserCenterByScn(String scn,String createType,HttpServletRequest request){
		UserInfoCache userInfoCache= null;
		try {
			userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		} catch (ServiceException e) {
			logger.info("WeChatLoginManager-recordUserToUserCenter-scn:{}  e-{}",scn,e);
		}

		if(null!=userInfoCache){
			String userId=userInfoCache.getId();
			LoginRecordThread thread=new  LoginRecordThread(userId,createType,"2",userCenter,venusVshopGcache,iUserInfoManager,iUserRoleManager);
			logger.info("WeChatLoginManager-recordUserToUserCenter-to-Thread useId:{}",userId);
			ThreadPoolManager.newInstance().addExecuteTask(thread);
		}
	}

	/**
	 * 记录用户信息到用户池
	 * @param userId
	 * @param createType
	 * @param request
	 */
	public  void   recordUserToUserCenterByUserId(String userId,String createType,HttpServletRequest request){

		if(null!=userId){
			LoginRecordThread thread=new  LoginRecordThread(userId,createType,"2",userCenter,venusVshopGcache,iUserInfoManager,iUserRoleManager);
			ThreadPoolManager.newInstance().addExecuteTask(thread);
		}
	}


	/**
	 * openId和UserId 绑定关系处理 true 需要弹出更新绑定，否则默认绑定
	 * @param userId
	 * @param openId
	 * @param unionId
	 */
	public  Boolean   handleUserAndOpenId(String userId,String openId,String unionId,String sNsUserName,WeChatLoginResultVO vo){
		Boolean  flag=false;//默认不弹出变更绑定关系确认弹窗
		String key = BindInfoUpdateThread.USER_OPENID_ID_SET + ":" + RedisKeyUtils.getHKey(openId);
		String relationStr=userCenter.hget(key,openId);
		if(null!=userId&&null!=openId) {

			if(StringUtils.isNotBlank(relationStr)){
				List<UserRelation> userRelations = JSONObject.parseArray(relationStr, UserRelation.class);
				if(null!=userRelations&&userRelations.size()>0){

					for (UserRelation userRelation:userRelations) {
						Long userRelationId=userRelation.getId();
						String  dbOpenId=userRelation.getOpenId();
						String  dbUserId=userRelation.getUserId();
						if(openId.equals(dbOpenId)){
							Date uptime=userRelation.getUtime();
							long  time1=uptime.getTime();
							long  time2=new Date().getTime();
							long days=getDistanceDays(time2,time1);
							if(days>distance&&!dbUserId.equals(userId)){
								//唯一需要变更绑定关系
								flag=true;
								vo.setUpdateBindOpenId(userRelationId);
								break;
							}
						}
					}


				}
			}else{
				//用户绑定关系不存在
				WeChatOpenIdAndUserIdVO  weChatOpenIdAndUserIdVO=new WeChatOpenIdAndUserIdVO();
				weChatOpenIdAndUserIdVO.setOpenid(openId);
				weChatOpenIdAndUserIdVO.setUnionid(unionId);
				weChatOpenIdAndUserIdVO.setUser_id(userId);
				weChatOpenIdAndUserIdVO.setUser_name(sNsUserName);
				if(StringUtils.isNotBlank(userId)){
					try {
						weChatOpenIdAndUserIdVO.setDyn_user_id(Long.parseLong(userId));
					}catch(Exception e){
						weChatOpenIdAndUserIdVO.setDyn_user_id(-1l);
					}
				}
				weChatOpenIdAndUserIdVO.setPlatForm(PLAT_FORM);
				BindInfoUpdateThread  bindInfoUpdateThread=new  BindInfoUpdateThread(true,null,userId,openId,unionId, userCenter,iUserRelationManager,weChatOpenIdAndUserIdVO,httpClientUtil,bindUserUrl);
				ThreadPoolManager.newInstance().addExecuteTask(bindInfoUpdateThread);

			}

		}

		return flag;

	}

	/**
	 * 调用会员接口更新绑定关系
	 * @param userOpenId
	 * @param userInfo
	 */
	public  void  updateBindOpenId(String scn,Long userOpenId,String userInfo){
		String  sNSUserId="";
		String  sNsUserName="";
		String  openId="";
		String  userId=null;
		UserInfoCache userInfoCache= null;
		try {
			userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		} catch (ServiceException e) {
			logger.info("WeChatLoginManager-updateBindOpenId-scn:{}  e-{}",scn,e);
		}
		userId=userInfoCache.getId();
		if(null==userId){
			return ;
		}
		WeChatUserInfo  weChatUserInfo=null;
		try {
			userInfo=URLDecoder.decode(userInfo,"UTF-8");
			userInfo=MobileDES.decryptDES(userInfo,WX_TOKEN.substring(0,8));
			weChatUserInfo=com.alibaba.fastjson.JSON.parseObject(userInfo, WeChatUserInfo.class);
			sNSUserId=weChatUserInfo.getUnionid();
			openId=weChatUserInfo.getOpenid();
			sNsUserName=weChatUserInfo.getNickname();

		} catch (Exception e) {
			logger.info("WechatLoginManager-updateBindOpenId-decrypt-fail:-userInfo:{}  e：{}",userInfo,e);
		}

		WeChatOpenIdAndUserIdVO  weChatOpenIdAndUserIdVO=new WeChatOpenIdAndUserIdVO();
		weChatOpenIdAndUserIdVO.setOpenid(openId);
		weChatOpenIdAndUserIdVO.setUnionid(sNSUserId);
		weChatOpenIdAndUserIdVO.setUser_id(userId);
		weChatOpenIdAndUserIdVO.setUser_name(sNsUserName);
		if(StringUtils.isNotBlank(userId)){
			try {
				weChatOpenIdAndUserIdVO.setDyn_user_id(Long.parseLong(userId));
			}catch(Exception e){
				weChatOpenIdAndUserIdVO.setDyn_user_id(-1l);
			}
		}
		weChatOpenIdAndUserIdVO.setPlatForm(PLAT_FORM);
		BindInfoUpdateThread  bindInfoUpdateThread=new  BindInfoUpdateThread(false,userOpenId,userId,openId,sNSUserId, userCenter,iUserRelationManager,weChatOpenIdAndUserIdVO,httpClientUtil,bindUserUrl);
		ThreadPoolManager.newInstance().addExecuteTask(bindInfoUpdateThread);


	}

	/**
	 * 两个时间之间相差距离多少天
	 * @param time1 时间参数 1：
	 * @param time2 时间参数 2：
	 * @return 相差天数
	 */
	public static long getDistanceDays(long time1, long time2) {
		long days=0;
		long diff ;
		if(time1<time2) {
			diff = time2 - time1;
		} else {
			diff = time1 - time2;
		}
		days = diff / (1000 * 60 * 60 * 24);
		return days;
	}


	/**
	 * 解密token
	 * @return
	 * @throws Exception
	 */
	public  String   decodeToken(String token)  {
		String urlEncode= null;
		try {
			urlEncode = URLDecoder.decode(token,"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		String decryptDES = null;
		try {
			decryptDES = MobileDES.decryptDES(urlEncode,WX_KEY.substring(0,8));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return decryptDES;
	}


	/**
	 *  微信信息解密
	 * @param userInfo
	 * @param headImageUrl
	 * @return
	 * @throws ServiceException
	 */
	public  WeChatUserInfo  decryptDESWeChatUserInfo(String userInfo,String headImageUrl) throws ServiceException {
		WeChatUserInfo  weChatUserInfo=null;
		try {
			if(StringUtils.isNotBlank(headImageUrl)){
				headImageUrl=URLDecoder.decode(headImageUrl,"UTF-8");
			}
			userInfo=URLDecoder.decode(userInfo,"UTF-8");
			userInfo=MobileDES.decryptDES(userInfo, WX_TOKEN.substring(0,8));
			weChatUserInfo=com.alibaba.fastjson.JSON.parseObject(userInfo, WeChatUserInfo.class);
			weChatUserInfo.setHeadImageUrl(headImageUrl);
		} catch (Exception e) {
			logger.error("decryptDESWeChatUserInfo ==> userInfo=={} e=={} ", userInfo, e);
		}
		return weChatUserInfo;
	}


	/**
	 *
	 * @param url
	 * @return
	 */
	public  Object    handleShareToken(String url){
		String token= null;
		try {
			token =getTokenForShare();
		} catch (Exception e) {
			e.printStackTrace();
		}
		String base64Url=MobileBase64.encode(url.getBytes());
		try {
			url=URLEncoder.encode(base64Url,"UTf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		Map map=new HashMap();
		map.put("url",url);
		//map.put("body",jsonObject.toJSONString());
		//map.put("url",base64Url);
		String postUrl=shareUrl+token;
		Object object= null;
		String result=null;
		Map<String,Object>  resultMap=new HashMap<String,Object>();
		Integer code=null;
		String  message=null;
		JSONObject resultArray=null;
		Object  appid=null;
		Object  noncestr=null;
		Object  timestamp=null;
		Object  weChatUrl=null;
		Object  signature=null;
		try {
			 logger.info("shareUrl-request-postUrl:{},url:{}",postUrl,url);
			 result = httpClientUtil.doFromPost(postUrl,map);
			 if(null!=result){
			 logger.info("shareUrl-response-result:{}",result);

				 Map<String,Object>  jsonArray= JSONObject.parseObject(result,Map.class);
				 code=(Integer)jsonArray.get("code");
				 message=(String)jsonArray.get("message");
				 resultArray=(JSONObject)jsonArray.get("result");
				 if(null!=resultArray){
					 appid=resultArray.get("appid");
					 noncestr=resultArray.get("noncestr");
					 timestamp=resultArray.get("timestamp");
					 weChatUrl=resultArray.get("url");
					 signature=resultArray.get("signature");
				 }
			 }
		} catch (Exception e) {
			logger.info("wechatLoginManager  doFromPost-error result:{}  e:{}",result,e);
		}
		resultMap.put("wxShareCode",code);
		resultMap.put("wxShareMessage",message);
		resultMap.put("appid",appid);
		resultMap.put("noncestr",noncestr);
		resultMap.put("timestamp",timestamp);
		resultMap.put("weChatUrl",weChatUrl);
		resultMap.put("signature",signature);
		object=resultMap;
		return object;
	}


	/**
	 * 根据userId 填充用户相关的信息
	 * @param userId
	 * @return
	 */
	public AuthencationVo getAutencationVo(String  userId){

		AuthencationVo authencationVo = new AuthencationVo();
		if (null == userId || org.apache.commons.lang.StringUtils.isBlank(userId)) {
			logger.info("wechatLoginManager getAutencationVo  no login");
			// 未登录，返回主站登录页链接
			authencationVo.setLogin(USER_NOT_LOGIN);
		} else {
			// 登录，返回userId
			logger.info("wechatLoginManager getAutencationVo userId ==> {} ", userId);
			authencationVo = JSONObject.parseObject(gcache.get("checkUserId_" + userId), AuthencationVo.class);
			if(authencationVo == null){
				authencationVo = new AuthencationVo();
				authencationVo.setLogin(USER_ALREADY_LOGIN);
				authencationVo.setUserId(userId);
				// 根据userId获取stId
				CommonResultEntity<StaffInfoVo> commonResultEntity = queryUserInfoFacade.getStaffInfoByUserId(userId);
				logger.debug("wechatLoginManager getAutencationVo  commonResultEntity ==> {} ", JSONUtils.toJSONString(commonResultEntity));

				StaffInfoVo staffInfoVo = commonResultEntity.getBusinessObj();
				String stId = null;
				if (null != staffInfoVo) {
					stId = staffInfoVo.getStoreNo();
					authencationVo.setStoreNo(stId);
					authencationVo.setStaffNo(staffInfoVo.getStaffNo());
				}
				Map<String, Object> paraMap = new HashMap<>();
				paraMap.put("companyName", "gomeOnLine");
				MapResult<UnifyUserInfoExt> result = iUserInfoFacade.getItemByIdForGomeShop(userId, "gomeShopMobile", paraMap);
				if(result != null && result.isSuccess()){
					UnifyUserInfoExt userVo = result.getBuessObj();
					String nickName = null;
					if (null != userVo)
						nickName = userVo.getNikename();
					authencationVo.setNickName(nickName);
				}
				gcache.setex("checkUserId_" + userId, 10 * 60, JSONObject.toJSONString(authencationVo));
			}
			String vshopKey = "vshop:vshopInfo_userId:" + userId;
			VshopInfo shopInfo = JSONObject.parseObject(venusVshopGcache.get(vshopKey), VshopInfo.class);
			if(shopInfo != null){
				authencationVo.setShopId(shopInfo.getVshopId());
			}
		}
		logger.info("wechatLoginManager getAutencationVo userId ==> {}  end", userId);
		return authencationVo;

	}


	/**
	 * 国美wap分享授权信息处理
	 *
	 * @param vo
	 * @return
	 */
	public byte handleAuthorizationInfo(MshopShareRecordVo vo) throws ServiceException {
		MapResults result = null;
		String uniqueId = vo.getUniqueId();
		String puniqueId = vo.getPuniqueId();//邀请人的uniqueId
		String image = null;
		String nickname = null;
		try {
			if(StringUtils.isNotBlank(vo.getImage())){
				image = URLDecoder.decode(vo.getImage(), "UTF-8");
			}
			if(StringUtils.isNotBlank(vo.getNickname())){
				nickname = URLDecoder.decode(vo.getNickname(), "UTF-8");
			}
//			image = URLDecoder.decode(vo.getImage(), "UTF-8");
//			nickname = URLDecoder.decode(vo.getNickname(), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error("handleAuthorizationInfo 2 ==> e=={} ", e);
			return 2;
		}
		MshopShareRecordDto dto = new MshopShareRecordDto();
		
		logger.info("handleMDAuthorizationInfo ==> puniqueId=={} puserId=={} uniqueId=={}", puniqueId, vo.getPuserId(), vo.getUniqueId());
		
		//if (null != uniqueId && null != image && null != nickname) {陈晨让去掉校验
		if (null != uniqueId) {
			//国美wap美店主分享链信息保存
			BeanUtils.copyProperties(vo, dto);
			dto.setImage(image);
			dto.setNickname(nickname);
			MapResults mapResults = iMShopShareRecordManager.addMshopShareRecord(dto);
			// 测试环境
			logger.debug("handleMDAuthorizationInfo requestParam ==> {}", JSONUtils.toJSONString(dto));
			if(null == mapResults || !mapResults.getSuccess()) {
				logger.error("handleMDAuthorizationInfo 1 ==> puniqueId=={} puserId=={} uniqueId=={} userId=={} ", puniqueId, vo.getPuserId(), vo.getUniqueId(), vo.getUserId());
				logger.debug("handleMDAuthorizationInfo error responseParam ==> {}", JSONUtils.toJSONString(mapResults));
				return 1;
			}
		}else
			// 测试环境
			logger.debug("handleMDAuthorizationInfo null==> {}", JSONUtils.toJSONString(dto));
		
		return 0;
	}

	/**
	 * 三端注册登录绑定信息处理
	 *
	 * @param recordVo
	 * @return
	 */
	public Map<String, Object> handleRegisterLoginBindInfo(MshopShareRecordVo recordVo) throws ServiceException{
		Map<String, Object> restMap = new HashMap<String, Object>();
		restMap.put("upuserId", null);
		
		MshopShareRecordDto dto = new MshopShareRecordDto();
		BeanUtils.copyProperties(recordVo, dto);
		String Strimage = null;
		String nickname = null;
		try {
			if(StringUtils.isNotBlank(recordVo.getImage())){
			   Strimage = URLDecoder.decode(dto.getImage(), "UTF-8");
			}
			if(StringUtils.isNotBlank(recordVo.getNickname())){
			   nickname = URLDecoder.decode(dto.getNickname(), "UTF-8");
			}
		} catch (UnsupportedEncodingException e) {
			restMap.put("type", 2);
			return restMap;
		}
		dto.setImage(Strimage);
		dto.setNickname(nickname);
		MapResults<MshopShareRecordDto> mapResults = iMShopShareRecordManager.addMshopShareRecord(dto);
		
		// 测试环境
		logger.debug("handleMDAuthorizationInfo requestParam ==> {}", JSONUtils.toJSONString(dto));
		
		if(null == mapResults || !mapResults.getSuccess()) {
			logger.error("handleMDAuthorizationInfo ==> puniqueId=={} puserId=={} uniqueId=={} userId=={} newUser=={} ", recordVo.getPuniqueId(), recordVo.getPuserId(), recordVo.getUniqueId(), recordVo.getUserId(), recordVo.getNewUser());
			logger.debug("handleMDAuthorizationInfo error responseParam ==> {}", JSONUtils.toJSONString(mapResults));
			restMap.put("type", 1);
			return restMap;
		}
		MshopShareRecordDto mshopShareRecordDto = mapResults.getBuessObj();
		
		logger.info("handleMDAuthorizationInfo Dto responseParam ==> {}", JSONUtils.toJSONString(mshopShareRecordDto));
		
		if(null != mshopShareRecordDto){
			Long upuserId = mshopShareRecordDto.getUpuserId();
			restMap.put("upuserId", upuserId);
			if(null == upuserId)
				logger.error("handleMDAuthorizationInfo upuserId null ==> puniqueId=={} puserId=={} uniqueId=={} userId=={} newUser=={} ", recordVo.getPuniqueId(), recordVo.getPuserId(), recordVo.getUniqueId(), recordVo.getUserId(), recordVo.getNewUser());
		}else 
			logger.error("handleMDAuthorizationInfo mshopShareRecordDto null ==> puniqueId=={} puserId=={} uniqueId=={} userId=={} newUser=={} ", recordVo.getPuniqueId(), recordVo.getPuserId(), recordVo.getUniqueId(), recordVo.getUserId(), recordVo.getNewUser());
		
		restMap.put("type", 0);
		
		return restMap;
	}

	/**
	 * 美店微信授权分享信息处理
	 *
	 * @param mshopShareRecordo
	 * @return
	 */
	public Map<String, String> handleMDAuthorizationInfo(MshopShareRecordVo mshopShareRecordVo) throws ServiceException {
		Map<String, String> resultVo = new HashMap<String, String>();
		WeChatUserInfo weChatUserInfo = null;
		
		String userInfo = mshopShareRecordVo.getUserInfo();
		String image = mshopShareRecordVo.getImage();
		if(null != userInfo)
			weChatUserInfo = this.decryptDESWeChatUserInfo(userInfo, image);
		
		MshopShareRecordDto dto = new MshopShareRecordDto();
		String unionId = null;
		if (null != weChatUserInfo) {
			resultVo.put("image", weChatUserInfo.getHeadImageUrl());
			resultVo.put("nickname", weChatUserInfo.getNickname());
			resultVo.put("uniqueId", weChatUserInfo.getUnionid());
			resultVo.put("openid", weChatUserInfo.getOpenid());
			dto.setImage(weChatUserInfo.getHeadImageUrl());
			dto.setNickname(weChatUserInfo.getNickname());
			unionId = weChatUserInfo.getUnionid();
			dto.setUniqueId(unionId);
			dto.setPuniqueId(mshopShareRecordVo.getPuniqueId());
			dto.setPuserId(mshopShareRecordVo.getPuserId());
			dto.setNewUser(0);
			dto.setMid(mshopShareRecordVo.getMid());
		}
		
		logger.info("handleMDAuthorizationInfo requestParam ==> puniqueId=={} puserId=={} uniqueId=={} userId=={} ", mshopShareRecordVo.getPuniqueId(), mshopShareRecordVo.getPuserId(), unionId, mshopShareRecordVo.getUserId());
		
		// 测试环境
		logger.debug("handleMDAuthorizationInfo requestParam ==> {}", JSONUtils.toJSONString(dto));
		
		// 美店授权分享链信息保存
		MapResults mapResults = iMShopShareRecordManager.addMshopShareRecord(dto);
		if(null == mapResults || !mapResults.getSuccess()) {
			logger.error("handleMDAuthorizationInfo ==> puniqueId=={} puserId=={} uniqueId=={} userId=={} ", mshopShareRecordVo.getPuniqueId(), mshopShareRecordVo.getPuserId(), unionId, mshopShareRecordVo.getUserId());
			logger.debug("handleMDAuthorizationInfo error responseParam ==> {}", JSONUtils.toJSONString(mapResults));
		}
		
		return resultVo;
	}

}
