package com.gome.meidian.grouporder.manager;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.gome.search.dubbo.domain.AppContent;
import org.gome.search.dubbo.domain.AppRequest;
import org.gome.search.dubbo.domain.AppResponse;
import org.gome.search.dubbo.domain.ServerInfo;
import org.gome.search.dubbo.idl.AppService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.utils.SearchInfoUtil;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.advanceSale.GomePromPresellVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupInfoReq;
import com.gome.meidian.grouporder.vo.grouporderVo.HomePageActivity;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupTotal;
import com.gome.meidian.grouporder.vo.product.ProductInfo;
import com.gome.meidian.grouporder.vo.product.ProductRequestParam;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebate;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;
import com.gome.meidian.grouporder.vo.rebate.ShareRebate;
import com.gome.meidian.grouporder.vo.rebate.ShareRebateResponse;
import com.gome.meidian.grouporder.vo.search.Category;
import com.gome.meidian.grouporder.vo.search.CommonInfo;
import com.gome.meidian.grouporder.vo.search.FilterCondition;
import com.gome.meidian.grouporder.vo.search.FilterValListVO;
import com.gome.meidian.grouporder.vo.search.FilterValVo;
import com.gome.meidian.grouporder.vo.search.PageBar;
import com.gome.meidian.grouporder.vo.search.QueryCatVo;
import com.gome.meidian.grouporder.vo.search.SearchInfoReqVo;
import com.gome.meidian.grouporder.vo.search.SearchProInfo;
import com.gome.meidian.grouporder.vo.search.SearchProductInfoVo;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.GroupInfoVo;

import jodd.util.StringUtil;
import redis.Gcache;

@Service
public class SearchInfoManager {
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private HttpClientUtil httpClientUtil;
	
//	@Value("${gome.search.suggestUrl}")
//	private String suggestUrl;
//	@Value("${gome.search.from}")
//	private String from;
	@Autowired
	private AppService  appService;
	@Autowired
	private HomeProductsManager homeProductsManager;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Autowired
	private GroupOrderManager groupOrderManager;
	
	@Value("${gome.search.suggestUrl}")
	private String suggestUrl;
	@Autowired
	private SearchInfoUtil searchInfoUtil;
	@Value("${gome.search.depositGroup}")
	private int depositGroup; //定金团值
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	
	
	@Autowired
	private AdvanceSaleManager advanceSaleManager;
	
	/**
	 * 联想词搜索接口
	 * @param query
	 * @return
	 * @throws ServiceException
	 */
	public Map<String,Object> suggestInfo(String query,String siteModule) throws ServiceException{
		Map<String,Object> resultMap=new HashMap<String, Object>();
		Map<String, Object> map = new HashMap<String, Object>();
		
		String from = "mshopWapSearch";
		if(siteModule.equals("app")){
			from="shopSearch";
		}else if(siteModule.equals("wxProgram")){
			from="mshopXcxSearch";
		}
		
		map.put("from", from);
		map.put("query", query);
		String result = null;
		try {
			result = httpClientUtil.doGet(suggestUrl, map);
			List<Map<String,Object>> list=searchInfoUtil.explain(result);
			resultMap.put("keywordsList", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * 搜索主接口
	 * @param searchInfoReqVo
	 * @param ua
	 * @return
	 * @throws ServiceException
	 */
	public  Map<String,Object> searchInfo(SearchInfoReqVo searchInfoReqVo,Byte ua,Integer ppi,String userId,String ctx)throws ServiceException{
        Map<String,Object> resultMap=new HashMap<String,Object>();
        resultMap.put("searchId", null);//搜索Id
        resultMap.put("remain", null);
        resultMap.put("pageBar", null);
        resultMap.put("goodsList", null);
		Map<String,SearchProductInfoVo> searchProductInfoVoMap=null;
		AppRequest paramAppRequest = new AppRequest();
		
		//拼接筛选的品牌信息
		List<FilterValListVO> filterConList = searchInfoReqVo.getFilterConList();
		StringBuffer facets = null;
		if(filterConList != null){
			facets = new StringBuffer("");
			for(FilterValListVO FilterValListVO : filterConList){
				List<FilterValVo> filterValList = FilterValListVO.getFilterValList();
				if(filterValList != null){
					for(FilterValVo filterValVo : filterValList){
						if(filterValVo!=null){
							facets.append(filterValVo.getFilterVal());
						}
					}
				}
			} 
			paramAppRequest.setFacets(facets.toString());
		}
		
		//拼接类目信息
		List<QueryCatVo> queryCatList = searchInfoReqVo.getQueryCatList();
		if(queryCatList != null ){
			List<String> navbarFirstCat = new ArrayList<String>();
			List<String> navbarSecCat = new ArrayList<String>();
			List<String> navbarThirdCat = new ArrayList<String>();
			for(QueryCatVo queryCatVo : queryCatList){
				if(queryCatVo != null){
					String catId = queryCatVo.getCatId();
					String level = queryCatVo.getCatLevel();
					if(StringUtils.isNotEmpty(level) && StringUtils.isNotEmpty(catId)){
						if(level.equals("1")){
							navbarFirstCat.add(catId);
						}else if(level.equals("2")){
							navbarSecCat.add(catId);
						}else if(level.equals("3")){
							navbarThirdCat.add(catId);
						}
					}
				}
				paramAppRequest.setNavbarFirstCat(navbarFirstCat);
				paramAppRequest.setNavbarSecCat(navbarSecCat);
				paramAppRequest.setNavbarThirdCat(navbarThirdCat);
			}
			
		}
		
		
		paramAppRequest.setRegionId(searchInfoReqVo.getThreeRegionId());
		paramAppRequest.setCatId(searchInfoReqVo.getCatId());;
		paramAppRequest.setQuestion(searchInfoReqVo.getKeyWord());
		paramAppRequest.setSale(searchInfoReqVo.getSale()==null?"0":searchInfoReqVo.getSale().toString());
		paramAppRequest.setPageSize(searchInfoReqVo.getPageSize());
		paramAppRequest.setPageNumber(searchInfoReqVo.getCurrentPage());
		paramAppRequest.setSort(switchSort(searchInfoReqVo.getSortBy()));
		String from = "mshopWapSearch";
		String siteModule="meidianWapSite";
		if(StringUtils.isNotBlank(searchInfoReqVo.getSiteModule()) && searchInfoReqVo.getSiteModule().equals("app")){
			siteModule="meidianMobileSite";
			from="shopSearch";
		}else if(StringUtils.isNotBlank(searchInfoReqVo.getSiteModule()) &&  searchInfoReqVo.getSiteModule().equals("wxProgram")){
			siteModule="meidianprogramSite";
			from="mshopXcxSearch";
			//2020.02.05 begin 修改区域地址
			
	        MeidianEnvironment.put("priceReqAreaCode", searchInfoReqVo.getAreaCode());
			
			//2020.02.05 end 修改区域地址
		}
		paramAppRequest.setFrom(from);
		paramAppRequest.setSiteModule(siteModule);
		paramAppRequest.setInstock(1);
		//ctx透传 2020.02.17 begin
		JSONObject other = new JSONObject();
		other.put("ctx", ctx);
		paramAppRequest.setOther(other);
		//ctx透传 2020.02.17 end
		//wap站处理门店code 及区域码
//		if(siteModule.equals("meidianWapSite")){
//			searchInfoReqVo.setAreaCode(MeidianEnvironment.getKey("priceReqAreaCode"));
//			searchInfoReqVo.setStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"));
//		}
//		System.out.println("#####入参#######"+JSON.toJSONString(paramAppRequest));
		AppResponse  appResponse=appService.gomeShopSearch(paramAppRequest);
//		System.out.println("++++++++接口返回的信息+++++++++"+JSON.toJSONString(appResponse));
//		System.out.println("++++++++接口返回的商品信息+++++++++"+JSON.toJSONString(appResponse.getContent().getProdInfo()));
//		System.out.println("$$$$$$$$接口返回类目$$$$$$$$$"+JSON.toJSONString(appResponse.getContent().getSelectData()));
		if(appResponse.getStatus() != 200){
            return resultMap;
		}
		ServerInfo serverInfo = appResponse.getServerInfo();
		if(serverInfo != null && serverInfo.getSearchId() !=null){
			resultMap.put("searchId", serverInfo.getSearchId());
		}
		//超级返集合
		List<ProductBuyRebate> proRebates=null;
		//组团集合
		List<GroupInfoReq> groupInfoReqs=null;
		//佣金
		List<ShareRebate> shareRebates=null;
		Map<String,ShareRebate> shareRebatesMap = null;
		Map<String,String> yongJinMap = null;
		//普通商品
		List<ProductRequestParam> productRequestParams=null;
		List<String> totalBuyNumString=null;
		
		searchProductInfoVoMap=new LinkedHashMap<String,SearchProductInfoVo>();
		PageBar pageBar=null;
		AppContent appContent=appResponse.getContent();
		
		//获取分类目录
		if(appContent!=null && appContent.getCategory()!=null){
			List<Category> list=searchInfoUtil.getCategory(appContent.getCategory());
//			System.err.println("Category&&&&&&&&&&&&&&"+JSONObject.toJSONString(list));
			resultMap.put("filterCatList", list);
		}
		
		//获取品牌
		if(appContent!=null && appContent.getFacets()!=null){
			List<FilterCondition> list=searchInfoUtil.getFilterCondition(appContent.getFacets());
//			System.err.println("brand$$$$$$$$$"+JSONObject.toJSONString(list));
			resultMap.put("filterConList", list);
		}
		
		
		if(appContent!=null && appContent.getCommonInfo()!=null){
			JSONObject commonInfoJsion = appContent.getCommonInfo();
		    String commonInfoStr = JSONObject.toJSONString(commonInfoJsion, SerializerFeature.WriteMapNullValue);
		    CommonInfo commonInfo = JSONObject.parseObject(commonInfoStr, CommonInfo.class);
		    resultMap.put("remain", commonInfo.getRemain());
		}
		
		if(appContent!=null && appContent.getPageBar()!=null){
			JSONObject pageBarJson=appContent.getPageBar();
		    String pageBarStr = JSONObject.toJSONString(pageBarJson, SerializerFeature.WriteMapNullValue);
		    pageBar = JSONObject.parseObject(pageBarStr, PageBar.class);
		    resultMap.put("pageBar", pageBar);
		}
		if(appContent!=null && appContent.getProdInfo()!=null){
			JSONArray promoInfo=appContent.getProdInfo();
			proRebates=new ArrayList<ProductBuyRebate>();
			groupInfoReqs=new ArrayList<GroupInfoReq>();
			productRequestParams = new ArrayList<ProductRequestParam>();
			totalBuyNumString= new ArrayList<String>();
			//shareRebates=new ArrayList<ShareRebate>();
			shareRebatesMap =new HashMap<String,ShareRebate>();
		    yongJinMap = new HashMap<String,String>();
			for (int j = 0; j < promoInfo.size(); j++) {
				JSONObject js = promoInfo.getJSONObject(j);
				if(js == null){
					continue;
				}
				String searchProInfoStr = JSONObject.toJSONString(js, SerializerFeature.WriteMapNullValue);
				SearchProInfo searchProInfo = js.parseObject(searchProInfoStr, SearchProInfo.class);
				if(searchProInfo == null){
					continue;
				}
				SearchProductInfoVo searchProductInfoVo=new SearchProductInfoVo();
				searchProductInfoVo.setUnit("¥");
				searchProductInfoVo.setStock(searchProInfo.getStock());
				searchProductInfoVo.setRebate("0");
				searchProductInfoVo.setPresale(searchProInfo.getPresale());
				
				
				if(searchProInfo.getMshopTag()!=null&&searchProInfo.getMshopTag()){
					
						//组团
						if(searchProInfo.getMgroupState() == 1 &&(searchInfoReqVo.getSale()== 0 || searchInfoReqVo.getSale()== 400)){
							searchProductInfoVo.setGoodsId(searchProInfo.getPid());
							searchProductInfoVo.setSkuID(searchProInfo.getSkuid());
							searchProductInfoVo.setSkuNo(searchProInfo.getSkuNo());
							searchProductInfoVoMap.put(searchProInfo.getPid()+"||"+searchProInfo.getSkuid(), searchProductInfoVo);
							GroupInfoReq groupInfoReq=new GroupInfoReq();
							groupInfoReq.setActivityId(Long.valueOf(searchProInfo.getMgroupActivityId()));
							groupInfoReq.setProductId(searchProInfo.getPid());
							groupInfoReq.setSkuId(searchProInfo.getSkuid());
							groupInfoReqs.add(groupInfoReq);
							totalBuyNumString.add(searchProInfo.getPid());
							
							//ShareRebate shareRebate=new ShareRebate();
							//shareRebate.setProductId(searchProInfo.getPid());
							//shareRebate.setSkuNo(searchProInfo.getSkuNo());
							//shareRebates.add(shareRebate);
							continue;
						}
						
						//超级返
						else if(searchProInfo.getMrebateState() ==1 && (searchInfoReqVo.getSale()== 0 || searchInfoReqVo.getSale()== 500)){
							searchProductInfoVo.setGoodsId(searchProInfo.getPid());
							searchProductInfoVo.setSkuID(searchProInfo.getSkuid());
							searchProductInfoVo.setSkuNo(searchProInfo.getSkuNo());
							searchProductInfoVoMap.put(searchProInfo.getPid()+"fan"+searchProInfo.getSkuid(), searchProductInfoVo);
							ProductBuyRebate productBuyRebate=new ProductBuyRebate();
							productBuyRebate.setProductId(searchProInfo.getPid());
							productBuyRebate.setSkuNo(searchProInfo.getSkuNo());
							productBuyRebate.setSkuId(searchProInfo.getSkuid());
							proRebates.add(productBuyRebate);
							
							//ShareRebate shareRebate=new ShareRebate();
							//shareRebate.setProductId(searchProInfo.getPid());
							//shareRebate.setSkuNo(searchProInfo.getSkuNo());
							//shareRebates.add(shareRebate);
							continue;
						}
						
						
						else if(searchProInfo.getPresale() != 0){
							searchProductInfoVo.setGoodsId(searchProInfo.getPid());
							searchProductInfoVoMap.put(searchProInfo.getPid()+"main"+searchProInfo.getSkuid(), searchProductInfoVo);
							ProductRequestParam productRequestParam=new ProductRequestParam();
							productRequestParam.setProductId(searchProInfo.getPid());
							productRequestParam.setSkuId(searchProInfo.getSkuid());
							productRequestParams.add(productRequestParam);
						}
				}else{
					searchProductInfoVo.setGoodsId(searchProInfo.getPid());
					searchProductInfoVoMap.put(searchProInfo.getPid()+"main"+searchProInfo.getSkuid(), searchProductInfoVo);
					ProductRequestParam productRequestParam=new ProductRequestParam();
					productRequestParam.setProductId(searchProInfo.getPid());
					productRequestParam.setSkuId(searchProInfo.getSkuid());
					productRequestParams.add(productRequestParam);
				}
				
			}
		}
		
		
		// 1.获取基础商品列表
		if(!CollectionUtils.isEmpty(productRequestParams)){
			//shareRebates.clear();
			//Map<String,String> yongJinMap = new HashMap<String,String>();
			List<Product> products = groupOrderManager.getPros(productRequestParams, searchInfoReqVo.getAreaCode(), ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE, ua, searchInfoReqVo.getStoreCode(),  GroupOrderConstants.PRICE_POLICYID, GroupOrderConstants.MEIDIANPRICE_CHANNEL );
		    for(Product product:products){
		    	SearchProductInfoVo searchProductInfoVo = searchProductInfoVoMap.get(product.getId()+"main"+product.getSkuId());
		    	  if(searchProductInfoVo != null){	
		    		    searchProductInfoVo.setPriceType(product.getPriceType());
						searchProductInfoVo.setSkuID(product.getSkuId());
						searchProductInfoVo.setSkuNo(product.getSkuNo());
				    	searchProductInfoVo.setProductType("3");
				    	searchProductInfoVo.setShopId(product.getShopId());
				    	searchProductInfoVo.setProductImgURL(product.getMainImage());
				    	searchProductInfoVo.setGoodsName(product.getName());
				    	//searchProductInfoVo.setSalePrice(String.valueOf(BigDecimalUtils.div(product.getSalePrice(), 100d, 2)));
				    	searchProductInfoVo.setSalePrice(BigDecimal.valueOf(Long.valueOf(product.getSalePrice())).divide(new BigDecimal(100)).toString());
				    	searchProductInfoVo.setMeidianPrice(searchProductInfoVo.getSalePrice());
				    	searchProductInfoVo.setStatus(product.getStatus());
				    	searchProductInfoVo.setProductTag(product.getProductTag());
				    	searchProductInfoVoMap.put(product.getId()+"main"+product.getSkuId(), searchProductInfoVo);
				    	
				    	//佣金查询
						String meidianPrice = searchProductInfoVo.getMeidianPrice();
						Long mdPrice = 0L;
						if(meidianPrice !=null && !meidianPrice.equals("")){
							mdPrice = (BigDecimal.valueOf(Double.valueOf(meidianPrice)).multiply(new BigDecimal(100))).longValue();
						}
						if(mdPrice > 0L){
							ShareRebate shareRebate=new ShareRebate();
							shareRebate.setProductId(searchProductInfoVo.getGoodsId());
							shareRebate.setSkuNo(searchProductInfoVo.getSkuNo());
							shareRebate.setShopId(searchProductInfoVo.getShopId());
							shareRebate.setPrice(mdPrice);
							shareRebatesMap.put(shareRebate.getProductId()+"rebate"+shareRebate.getSkuNo(), shareRebate);
							//shareRebates.add(shareRebate);
					    	yongJinMap.put(searchProductInfoVo.getGoodsId()+"main"+searchProductInfoVo.getSkuNo(), product.getId()+"main"+product.getSkuId());

						}
		    	  }
		    }

		    
		    
		}
		//组团
		if(!CollectionUtils.isEmpty(groupInfoReqs)){
			//shareRebates.clear();
			//Map<String,String> yongJinMap = new HashMap<String,String>();
			List<ProductGroupInfoVo> productGroupInfoVos = homeProductsManager.groupInfo(groupInfoReqs, searchInfoReqVo.getAreaCode(), ppi, ua, searchInfoReqVo.getStoreCode()); //110
		    for(ProductGroupInfoVo productGroupInfoVo:productGroupInfoVos){
		    	ProductInfo productInfo=productGroupInfoVo.getProductInfo();
		    	SearchProductInfoVo searchProductInfoVo=searchProductInfoVoMap.get(productInfo.getProductId()+"||"+productInfo.getSkuId());
		    	searchProductInfoVo.setProductType("1");
		    	searchProductInfoVo.setGoodsName(productInfo.getName());
		    	searchProductInfoVo.setSalePrice(productInfo.getPrice());
		    	searchProductInfoVo.setShopId(productInfo.getShopId());
		    	searchProductInfoVo.setProductImgURL(productInfo.getProductImage());
		    	searchProductInfoVo.setProductTag(productInfo.getProductTag());
		    	searchProductInfoVo.setStatus(productInfo.getProductStatus());
		    	searchProductInfoVo.setMeidianPrice(productInfo.getMeidianPrice());
		    	searchProductInfoVo.setPriceKey(productInfo.getPriceKey());
		    	searchProductInfoVo.setPriceType(productInfo.getPriceType());
		    	
		    	searchProductInfoVo.setHelpMinTotalNum(productInfo.getHelpMinTotalNum());
		    	searchProductInfoVo.setHelpMinNewNum(productInfo.getHelpMinNewNum());
		    	searchProductInfoVo.setAttendFixMoney(productInfo.getAttendFixMoney());
		    	searchProductInfoVo.setInitialFixMoney(productInfo.getInitialFixMoney());
		    	searchProductInfoVo.setHelpAllow(productInfo.getHelpAllow());
		    	
		    	
		    	HomePageActivity homePageActivity=productGroupInfoVo.getHomePageActivity();
		    	if(homePageActivity!=null){
		    		Float maxDiscount=homePageActivity.getMaxDiscount();
		    		if(maxDiscount!=null && maxDiscount!=10f){
		    			searchProductInfoVo.setSalePrice(productInfo.getMeidianPrice());
		    		}
		    		Integer groupBusType = homePageActivity.getGroupBusType();
		    		//如果是定金团，查询对应的团信息
		    		if(groupBusType != null && groupBusType.intValue() == depositGroup){
		    			CommonResultEntity<GroupInfoVo> groupInfoResult = gorderInfoForAppNewResource.getGroupInfo(homePageActivity.getActivityId(), searchInfoReqVo.getAreaCode(), searchProductInfoVo.getSkuID());
		    			if (groupInfoResult != null) {
		    				GroupInfoVo groupInfo = groupInfoResult.getBusinessObj();
		    				if(groupInfo != null){
		    					homePageActivity.setGroupId(groupInfo.getId());//设置团id
		    				}
		    			}
		    		}
		    	}
		    	//searchProductInfoVo.setHomePageActivity(productGroupInfoVo.getHomePageActivity());
		    	searchProductInfoVo.setHomePageActivity(homePageActivity);
		    	searchProductInfoVoMap.put(productInfo.getProductId()+"||"+productInfo.getSkuId(), searchProductInfoVo);		    	
		    	//佣金查询
				String meidianPrice = searchProductInfoVo.getMeidianPrice();
				Long mdPrice = 0L;
				if(meidianPrice !=null && !meidianPrice.equals("")){
					mdPrice = (BigDecimal.valueOf(Double.valueOf(meidianPrice)).multiply(new BigDecimal(100))).longValue();
				}
				if(mdPrice > 0L){
					ShareRebate shareRebate=new ShareRebate();
					shareRebate.setProductId(searchProductInfoVo.getGoodsId());
					shareRebate.setSkuNo(searchProductInfoVo.getSkuNo());
					shareRebate.setShopId(searchProductInfoVo.getShopId());
					shareRebate.setPrice(mdPrice);
					shareRebatesMap.put(shareRebate.getProductId()+"rebate"+shareRebate.getSkuNo(), shareRebate);
					//shareRebates.add(shareRebate);
			    	yongJinMap.put(searchProductInfoVo.getGoodsId()+"||"+searchProductInfoVo.getSkuNo(), productInfo.getProductId()+"||"+productInfo.getSkuId());

				}
		    }

	    	
		}
		//超级返
		if(!CollectionUtils.isEmpty(proRebates)){
			    //shareRebates.clear();
			    //Map<String,String> yongJinMap = new HashMap<String,String>();
				//取超级返信息
				List<ProductBuyRebateVo> productBuyRebateVos=homeProductsManager.getProductBuyRebates(proRebates, searchInfoReqVo.getAreaCode(), ppi, ua, searchInfoReqVo.getStoreCode(), GroupOrderConstants.PRICE_POLICYID );//424
				for(ProductBuyRebateVo productBuyRebateVo:productBuyRebateVos){
			    	Product product=productBuyRebateVo.getProduct();
			    	if (product != null) { 
			    		SearchProductInfoVo searchProductInfoVo = searchProductInfoVoMap.get(product.getId()+"fan"+product.getSkuId());
			    		if(searchProductInfoVo !=null ){
			    			searchProductInfoVo.setPriceType(product.getPriceType());
				    	    searchProductInfoVo.setSkuID(product.getSkuId());
				    	    searchProductInfoVo.setSkuNo(product.getSkuNo());
					    	searchProductInfoVo.setProductType("2");
					    	searchProductInfoVo.setBuyRebate(productBuyRebateVo.getBuyRebate());
					    	searchProductInfoVo.setShopId(product.getShopId());
					    	searchProductInfoVo.setProductImgURL(product.getMainImage());
					    	searchProductInfoVo.setGoodsName(product.getName());
					    	searchProductInfoVo.setSalePrice(BigDecimal.valueOf(Long.valueOf(product.getSalePrice())).divide(new BigDecimal(100)).toString());
					    	searchProductInfoVo.setMeidianPrice(searchProductInfoVo.getSalePrice());
					    	searchProductInfoVo.setStatus(product.getStatus());
					    	searchProductInfoVo.setProductTag(product.getProductTag());
					    	searchProductInfoVoMap.put(product.getId()+"fan"+product.getSkuId(), searchProductInfoVo);
					    	//佣金查询
							String meidianPrice = searchProductInfoVo.getMeidianPrice();
							Long mdPrice = 0L;
							if(meidianPrice !=null && !meidianPrice.equals("")){
								mdPrice = (BigDecimal.valueOf(Double.valueOf(meidianPrice)).multiply(new BigDecimal(100))).longValue();
							}
							if(mdPrice > 0L){
								ShareRebate shareRebate=new ShareRebate();
								shareRebate.setProductId(searchProductInfoVo.getGoodsId());
								shareRebate.setSkuNo(searchProductInfoVo.getSkuNo());
								shareRebate.setShopId(searchProductInfoVo.getShopId());
								shareRebate.setPrice(mdPrice);
								shareRebatesMap.put(shareRebate.getProductId()+"rebate"+shareRebate.getSkuNo(), shareRebate);
								//shareRebates.add(shareRebate);
								yongJinMap.put(searchProductInfoVo.getGoodsId()+"fan"+searchProductInfoVo.getSkuNo(), product.getId()+"fan"+product.getSkuId());
							}
			    		}
			    	}
			    	
			    }

				
		  }

		
		
		if(!CollectionUtils.isEmpty(totalBuyNumString)){
			//购买数量
			List<ProductGroupTotal> productGroupTotals = groupOrderManager.getProductBuyNum(totalBuyNumString);
			//渲染
			if(!CollectionUtils.isEmpty(productGroupTotals)){
				for(ProductGroupTotal productGroupTotal:productGroupTotals){
					if(!StringUtil.isBlank(productGroupTotal.getProductId()) && productGroupTotal.getTotalBuyNumbers() != null){
						
						Iterator<String> it = searchProductInfoVoMap.keySet().iterator();
						while (it.hasNext()) {
							String key = it.next().toString();
							SearchProductInfoVo  searchProductInfoVo=searchProductInfoVoMap.get(key);
							if(null == searchProductInfoVo.getProductType()){
//								System.err.println(JSONUtils.toJSONString(searchProductInfoVo));
//								System.err.println(JSONUtils.toJSONString(productGroupTotal));
								continue;
							}
							if(searchProductInfoVo.getGoodsId().equals(productGroupTotal.getProductId())&&searchProductInfoVo.getProductType().equals("1")){
								Integer salesVolume = productGroupTotal.getTotalBuyNumbers()*searchProductInfoVo.getHomePageActivity().getIrrigationNumber();
								searchProductInfoVo.getHomePageActivity().setTotalBuyNum(salesVolume);
								searchProductInfoVoMap.put(key, searchProductInfoVo);
							}
						}
					}
					
				}
			}
		}
		
		//佣金查询
		// 佣金开关
		String onOff = gcache.get("shareRebateOnOff");
		//if(null == onOff && siteModule.equals("meidianMobileSite") && shareRebatesMap != null ){
		if(null == onOff && !StringUtils.isEmpty(userId) && shareRebatesMap != null ){
			//佣金Map转list
			shareRebates=new ArrayList<ShareRebate>();
			Iterator<String> it = shareRebatesMap.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next().toString();
				ShareRebate  shareRebate=shareRebatesMap.get(key);
				if(shareRebate !=null){
					shareRebates.add(shareRebate);
				}
				
			}
			//!CollectionUtils.isEmpty(shareRebates)
			if(!CollectionUtils.isEmpty(shareRebates)){
				List<ShareRebateResponse> shareRebateResponses = homeProductsManager.shareRebate(shareRebates, searchInfoReqVo.getOrganizationId() , userId);
			    if(shareRebateResponses != null && shareRebateResponses.size()>0){
			    	for(ShareRebateResponse shareRebateResponse : shareRebateResponses){
			    		if(shareRebateResponse !=null){
			    			//返利
			    			String fanliKey = yongJinMap.get(shareRebateResponse.getProductId()+"fan"+shareRebateResponse.getSkuNo());
			    			SearchProductInfoVo searchProductInfoVo = searchProductInfoVoMap.get(fanliKey);
			    			if(searchProductInfoVo != null ){
				    			searchProductInfoVo.setRebate(shareRebateResponse.getRebate());
				    			searchProductInfoVoMap.put(fanliKey, searchProductInfoVo);
			    			}
			    			//组团
			    			String zuTuanKey = yongJinMap.get(shareRebateResponse.getProductId()+"||"+shareRebateResponse.getSkuNo());
			    			SearchProductInfoVo searchProductInfoVoZuTuan = searchProductInfoVoMap.get(zuTuanKey);
			    			if(searchProductInfoVoZuTuan != null){
				    			searchProductInfoVoZuTuan.setRebate(shareRebateResponse.getRebate());
				    			searchProductInfoVoMap.put(zuTuanKey, searchProductInfoVoZuTuan);
			    			}
			    			//普通商品
			    			String mainKey = yongJinMap.get(shareRebateResponse.getProductId()+"main"+shareRebateResponse.getSkuNo());
			    			SearchProductInfoVo searchProductInfoVoMain = searchProductInfoVoMap.get(mainKey);
			    			if(searchProductInfoVoMain != null){
			    				searchProductInfoVoMain.setRebate(shareRebateResponse.getRebate());
				    			searchProductInfoVoMap.put(mainKey, searchProductInfoVoMain);
			    			}

			    		}
			    		
			    	}
			    }
			}

		}
		
		
	     String storeCode = searchInfoReqVo.getStoreCode();
		
		//转list
		List<SearchProductInfoVo> goodsList=null;
		if(searchProductInfoVoMap!=null){
			goodsList=new ArrayList<SearchProductInfoVo>();
			Iterator<String> it = searchProductInfoVoMap.keySet().iterator();
			while (it.hasNext()) {
				String key = it.next().toString();
				SearchProductInfoVo  searchProductInfoVo=searchProductInfoVoMap.get(key);
				if(searchProductInfoVo !=null && searchProductInfoVo.getProductType()!=null){
					//// 1：自营   false 2：联营 true
					Boolean isShop = null;
					if(searchProductInfoVo.getProductTag() != null){
						if(searchProductInfoVo.getProductTag() == 2){
							isShop = true;
						}else if(searchProductInfoVo.getProductTag() == 1){
							isShop = false;
						}
					}
					
					//1 预售 2盲售   //没有skuNo降级处理
					if(searchProductInfoVo.getPresale() == 1 ){
						if(!StringUtils.isEmpty(searchProductInfoVo.getSkuNo())){
							//查询预售信息
							GomePromPresellVo  gomePromPresellVo = advanceSaleManager.queryOnePresellInfoByParam(searchProductInfoVo.getSkuNo(),searchInfoReqVo.getStoreCode(),isShop,searchInfoReqVo.getThreeRegionId(),searchInfoReqVo.getFourRegionId());
							if(gomePromPresellVo != null){
								Double deposit = gomePromPresellVo.getDeposit();
								Double presellPrice = gomePromPresellVo.getPresellPrice();//预售价
								if(deposit == null){
									//没查到预售金 降级处理  改为普通品
									searchProductInfoVo.setPresale(0);
								}else{
									searchProductInfoVo.setDeposit(deposit.toString());
									searchProductInfoVo.setDeductibleDeposit(gomePromPresellVo.getDeductibleDeposit() == null ? "0" : gomePromPresellVo.getDeductibleDeposit());
									searchProductInfoVo.setDepositExpand(gomePromPresellVo.getDepositExpand() == null ? "0" : gomePromPresellVo.getDepositExpand());
									if(presellPrice != null){
										searchProductInfoVo.setSalePrice(presellPrice.toString());
									}else{
										searchProductInfoVo.setSalePrice("0");
									}
									
								}
							}else{
								//没查到预售金 降级处理  改为普通品
								searchProductInfoVo.setPresale(0);
							}
							
						}else{
							//没查到预售金 降级处理  改为普通品
							searchProductInfoVo.setPresale(0);
						}
						goodsList.add(searchProductInfoVo);
					}else if(searchProductInfoVo.getPresale() == 2 ){
						//盲售
							//判断站点如果是wap站显示 敬请期待... 小程序隐藏
							if(siteModule.equals("meidianWapSite")){
								searchProductInfoVo.setDeposit("敬请期待...");
								goodsList.add(searchProductInfoVo);
							}

					}else {
						
						goodsList.add(searchProductInfoVo);
						
					}

				}
				
			}
			resultMap.put("goodsList", goodsList);
		}


		 return resultMap;
	
	}
	
	/**
	 * 切换排序字段
	 * @param sortBy
	 * @return
	 */
	private String switchSort(int sortBy){
		String sort="00";
        switch(sortBy){
        case 1:
        	sort="20";break;
        case 2:
        	sort="21";break;
        case 3:
        	sort="10";break;
        case 6:
        	sort="00";break;
        default:
        	sort="00";break;
        }
        return sort;
	}
}
