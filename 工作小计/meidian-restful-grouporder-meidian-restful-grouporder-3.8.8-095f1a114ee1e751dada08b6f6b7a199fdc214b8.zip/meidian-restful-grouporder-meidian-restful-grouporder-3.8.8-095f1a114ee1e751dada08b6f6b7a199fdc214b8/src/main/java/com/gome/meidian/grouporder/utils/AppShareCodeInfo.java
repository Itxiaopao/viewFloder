package com.gome.meidian.grouporder.utils;

public class AppShareCodeInfo {
	private String wapUrl;
	private String minUrl;
	private String wapParams;
	private String minParams;
	public AppShareCodeInfo(String wapUrl, String minUrl, String wapParams, String minParams) {
		this.wapUrl = wapUrl;
		this.minUrl = minUrl;
		this.wapParams = wapParams;
		this.minParams = minParams;
	}
	public String getWapUrl() {
		return wapUrl;
	}
	public void setWapUrl(String wapUrl) {
		this.wapUrl = wapUrl;
	}
	public String getMinUrl() {
		return minUrl;
	}
	public void setMinUrl(String minUrl) {
		this.minUrl = minUrl;
	}
	public String getWapParams() {
		return wapParams;
	}
	public void setWapParams(String wapParams) {
		this.wapParams = wapParams;
	}
	public String getMinParams() {
		return minParams;
	}
	public void setMinParams(String minParams) {
		this.minParams = minParams;
	}
	

}
