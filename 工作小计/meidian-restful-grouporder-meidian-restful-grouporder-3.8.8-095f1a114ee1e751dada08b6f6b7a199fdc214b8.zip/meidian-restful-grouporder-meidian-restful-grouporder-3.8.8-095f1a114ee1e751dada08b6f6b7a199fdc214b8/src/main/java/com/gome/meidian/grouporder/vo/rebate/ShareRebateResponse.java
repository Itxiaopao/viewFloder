package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;

/**
 * 分享返（佣金）返参
 * @author shichangjian
 *
 */
public class ShareRebateResponse implements Serializable{

	private static final long serialVersionUID = 876687650299167527L;

	private String productId; 
	private String skuNo; 
	private String rebate;
	
	public ShareRebateResponse() {
		super();
	}
	public ShareRebateResponse(String productId, String skuNo, String rebate) {
		super();
		this.productId = productId;
		this.skuNo = skuNo;
		this.rebate = rebate;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getRebate() {
		return rebate;
	}
	public void setRebate(String rebate) {
		this.rebate = rebate;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	} 
	
	
}


