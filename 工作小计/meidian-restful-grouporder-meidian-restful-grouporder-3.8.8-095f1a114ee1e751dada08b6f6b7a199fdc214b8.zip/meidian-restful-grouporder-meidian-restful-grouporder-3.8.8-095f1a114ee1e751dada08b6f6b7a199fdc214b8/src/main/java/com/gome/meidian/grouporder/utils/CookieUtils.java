package com.gome.meidian.grouporder.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/8 20:12
 * @Description
 */
public class CookieUtils {

    //SCN写入数据
    public  static  final String  COOKIE_SCN="SCN";
    public  static  final String  COOKIE_MSHOP_USER_ID="MSHOP_USER_ID";


    public static Cookie getCookieByName(HttpServletRequest request, String name) {
        Map<String, Cookie> cookieMap = readCookieMap(request);
        if (cookieMap.containsKey(name)) {
            Cookie cookie = (Cookie) cookieMap.get(name);
            return cookie;
        } else {
            return null;
        }
    }

    /**
     * 将cookie封装到Map里面
     * @param request
     * @return
     */
    private static Map<String, Cookie> readCookieMap(HttpServletRequest request) {
        Map<String, Cookie> cookieMap = new HashMap<String, Cookie>();
        Cookie[] cookies = request.getCookies();
        if (null != cookies) {
            for (Cookie cookie : cookies) {
                cookieMap.put(cookie.getName(), cookie);
            }
        }
        return cookieMap;
    }

    /**
     * 保存Cookies
     * @param response
     * @param name
     * @param value
     * @param path
     * @param domain
     * @param time
     * @return
     */
    public static HttpServletResponse setCookie(HttpServletResponse response, String name, String value,String path,String domain, int time) {
        // new一个Cookie对象,键值对为参数
        Cookie cookie = new Cookie(name, value);
        // tomcat下多应用共享
        cookie.setPath(path);
        // 如果cookie的值中含有中文时，需要对cookie进行编码，不然会产生乱码
        cookie.setMaxAge(time);
        cookie.setDomain(domain);
        // 将Cookie添加到Response中,使之生效
        response.addCookie(cookie); // addCookie后，如果已经存在相同名字的cookie，则最新的覆盖旧的cookie
        return response;
    }
    
	/**
	 * 构建requestHeader
	 * @param request
	 * @return
	 */
	public static Map<String, String> buildRequestHeader(String ctx){
		Map<String, String> requestHeader = new HashMap<String, String>();
		if(ctx != null && !ctx.equals("")){
			String[] values = ctx.split("\\|");
			for (int i = 0; values != null && i < values.length; i++) {
				String value = values[i];
				int indexOf = value.indexOf("-");
				if (indexOf <= 0) {
					continue;
				}

				String key = value.substring(0, indexOf);
				String tmpval = value.substring(indexOf + 1);
				if(tmpval != null && !tmpval.equals("") && tmpval.length()>1000){
					tmpval = tmpval.substring(0, 1000);
				}
				requestHeader.put(key, tmpval);
			}
		}
		return requestHeader;
	}
}
