package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.Product;

public class FlowGroup implements Serializable{

	private static final long serialVersionUID = 8084594504392500057L;

	private String flowActivityId; 	// 集客id
	private String staffId; 		// 集客发起者员工id
	private String userId; 			// 用户id
	private String storeCode; 		// 门店code
	private String orderId; 		// 订单ID
	private String deliveryOrderId; // 配送单id
	private Product product;		// 商品信息
	private Group group;			// 团信息
	private Activity activity;		// 活动信息
	private byte failGroupRefund; 	// 不成团退款,0:否,1:是
	private String pageCode; 		// 集客活动页分享带着pageCode

	
	public FlowGroup() {
		super();
	}
	public FlowGroup(String flowActivityId, String staffId, String userId, 
			String storeCode, String orderId, String deliveryOrderId, 
			Product product, Group group, Activity activity,
			byte failGroupRefund, String pageCode) {
		super();
		this.flowActivityId = flowActivityId;
		this.staffId = staffId;
		this.userId = userId;
		this.storeCode = storeCode;
		this.orderId = orderId;
		this.deliveryOrderId = deliveryOrderId;
		this.product = product;
		this.group = group;
		this.activity = activity;
		this.failGroupRefund = failGroupRefund;
		this.pageCode = pageCode;
	}
	public String getFlowActivityId() {
		return flowActivityId;
	}
	public void setFlowActivityId(String flowActivityId) {
		this.flowActivityId = flowActivityId;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStoreCode() {
		return storeCode;
	}
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getDeliveryOrderId() {
		return deliveryOrderId;
	}
	public void setDeliveryOrderId(String deliveryOrderId) {
		this.deliveryOrderId = deliveryOrderId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Group getGroup() {
		return group;
	}
	public void setGroup(Group group) {
		this.group = group;
	}
	public byte getFailGroupRefund() {
		return failGroupRefund;
	}
	public void setFailGroupRefund(byte failGroupRefund) {
		this.failGroupRefund = failGroupRefund;
	}
	public String getPageCode() {
		return pageCode;
	}
	public void setPageCode(String pageCode) {
		this.pageCode = pageCode;
	}
	public Activity getActivity() {
		return activity;
	}
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
	
	
	
	
	
	
	
	
}
