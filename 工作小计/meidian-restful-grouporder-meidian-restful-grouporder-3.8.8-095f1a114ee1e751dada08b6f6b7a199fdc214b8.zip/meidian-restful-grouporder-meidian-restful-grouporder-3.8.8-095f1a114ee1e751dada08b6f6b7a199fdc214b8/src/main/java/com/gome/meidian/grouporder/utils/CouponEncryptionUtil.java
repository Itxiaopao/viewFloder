package com.gome.meidian.grouporder.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.gome.mobile.coupon.CouponInfo;
import com.gome.mobile.utils.CouponUtil;

public class CouponEncryptionUtil {
	
	private static Logger logger = LoggerFactory.getLogger(CouponEncryptionUtil.class);
	
	/**
	 * 美，红，蓝，营销劵加密
	 * @param planId
	 * @param type
	 * @return
	 */
	public static String beautifulCouponEncryption(String planId, String type){
		
		if(null == planId || planId.equals("")) return null;
		CouponInfo couponInfo = new CouponInfo();
    	couponInfo.setCouponId(planId);
    	// 0：红券，1: 蓝券, 3:店铺券,5:购物券, 8:理财券,10:美券, 11:营销券
    	if(type.equals(GroupOrderConstants.COUPON_TYPE_MEI)){
    		// 美劵
    		couponInfo.setCouponType(10);
    		String id = CouponUtil.getEncryptCoupon(couponInfo);
            logger.info("beautifulCouponEencryption ==> type: {} planId: {} encryptionId: {}", GroupOrderConstants.COUPON_TYPE_MEI, planId, id);
            return id;
    	}else if(type.equals(GroupOrderConstants.COUPON_TYPE_BLUE)){
    		// 蓝劵
    		couponInfo.setCouponType(1);
    		String id = CouponUtil.getEncryptCoupon(couponInfo);
            logger.info("beautifulCouponEencryption ==> type: {} planId: {} encryptionId: {}", GroupOrderConstants.COUPON_TYPE_BLUE, planId, id);
            return id;
    	}else if(type.equals(GroupOrderConstants.COUPON_TYPE_RED)){
    		// 红劵
    		couponInfo.setCouponType(0);
    		String id = CouponUtil.getEncryptCoupon(couponInfo);
            logger.info("beautifulCouponEencryption ==> type: {} planId: {} encryptionId: {}", GroupOrderConstants.COUPON_TYPE_RED, planId, id);
            return id;
    	}else if(type.equals(GroupOrderConstants.COUPON_TYPE_MARKETING)){
    		// 营销劵
    		couponInfo.setCouponType(11);
    		String id = CouponUtil.getEncryptCoupon(couponInfo);
            logger.info("beautifulCouponEencryption ==> type: {} planId: {} encryptionId: {}", GroupOrderConstants.COUPON_TYPE_MARKETING, planId, id);
            return id;
    	}
    	
        return planId;
	}
	
	/**
	 * pop劵加密
	 * @param couponId
	 * @param type
	 * @param shopId
	 * @param activityId
	 * @return
	 */
	public static String popCouponEncryption(String couponId, String type, String shopId, String activityId){
		
		CouponInfo couponInfo = new CouponInfo();
		couponInfo.setCouponId(couponId);
		couponInfo.setShopId(shopId);
		couponInfo.setActiveId(activityId);
		
		// 0：红券，1: 蓝券, 3:店铺券,5:购物券, 8:理财券,10:美券, 11:营销券
		if(type.equals(GroupOrderConstants.COUPON_TYPE_POP_SHOP)){
			// 店铺劵
			couponInfo.setCouponType(3);
			String id = CouponUtil.getEncryptCoupon(couponInfo);
			logger.info("popCouponEncryption ==> type: {} couponId: {} shopId: {} activityId:{} encryptionId: {}", GroupOrderConstants.COUPON_TYPE_POP_SHOP, couponId, shopId, activityId, id);
			return id;
		}else if(type.equals(GroupOrderConstants.COUPON_TYPE_POP_PLATFORM)){
			// 平台劵
			couponInfo.setCouponType(5);
			String id = CouponUtil.getEncryptCoupon(couponInfo);
			logger.info("popCouponEncryption ==> type: {} couponId: {} shopId: {} activityId:{} encryptionId: {}", GroupOrderConstants.COUPON_TYPE_POP_PLATFORM, couponId, shopId, activityId, id);
			return id;
		}else if(type.equals(GroupOrderConstants.COUPON_TYPE_POP_PRODUCT)){
			// 商品劵
			couponInfo.setCouponType(3);
			String id = CouponUtil.getEncryptCoupon(couponInfo);
			logger.info("popCouponEncryption ==> type: {} couponId: {} shopId: {} activityId:{} encryptionId: {} ", GroupOrderConstants.COUPON_TYPE_POP_PRODUCT, couponId, shopId, activityId, id);
			return id;
		}
		
		return couponId;
	}
}
