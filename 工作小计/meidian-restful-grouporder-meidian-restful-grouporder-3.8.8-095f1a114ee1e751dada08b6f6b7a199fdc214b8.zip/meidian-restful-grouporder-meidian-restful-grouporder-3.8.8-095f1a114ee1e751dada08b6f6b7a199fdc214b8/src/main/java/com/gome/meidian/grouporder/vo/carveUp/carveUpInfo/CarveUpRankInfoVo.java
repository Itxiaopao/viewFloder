package com.gome.meidian.grouporder.vo.carveUp.carveUpInfo;

import com.gome.meidian.grouporder.vo.Coupon;
import com.gomeplus.bs.interfaces.gorder.vo.carve.CarveRankAwardVo;

import java.util.List;

/**
 * 排名团详情信息
 */
public class CarveUpRankInfoVo extends CarveUpBaseInfoVo {

	private static final long serialVersionUID = 4064189434535275689L;

//	private Integer rankGroupRewardNum; //排名团，额外奖励的团数',--商品集
	private Integer groupFinalSort;//团当前排名
//	private Integer isReward;//团是否获得排名额外奖励 0 未获得  1 已获得
//	private Integer rankMaxPeopleNum; //排名团，最多人数限制',--团
//	private Double rankFixMoney; //排名团额外每人固定国美币
//	private Double rankTotalMoney; //排名团额外总国美币
	private List<Coupon> rankCoupons;  //排名团券信息
	private Double rankBondTotalNum; //排名奖励劵面值总和（元）
	
	private Double totalCarveMoney;//共同瓜分金额(元、小数最多2位)
	private Double leaderMoney;//排名团胜出奖励 -- 团长
	private Double rankUserReward;//排名团胜出奖励 -- 团员

	private Integer rankActivityMinPeopleNum; //活动最少参与人数
	private Integer activityAttendNum;//当前活动参与人数
	private Integer rankActivityMaxPeopleNum; //排名团活动最多参与人数
	private Integer rankMaxPeopleNum; //排名团最多参与人数
	

	private Integer userNum;//距离上一名/下一名差几人
	private Integer userFlag;//需要的是新客还是老客  0:老人 、1：新人
	private List<CarveRankAwardVo> carveRankAwardList;//排名团奖励配置
	
	private Integer needNewNum; //还需助力新人数
	private Integer needTotalNum; //还需助力总人数
	private Integer rankingNum;//榜单排名数（已有多少个团进入排行）


//	public Integer getRankGroupRewardNum() {
//		return rankGroupRewardNum;
//	}
//
//	public void setRankGroupRewardNum(Integer rankGroupRewardNum) {
//		this.rankGroupRewardNum = rankGroupRewardNum;
//	}
//
//	public Integer getRankMaxPeopleNum() {
//		return rankMaxPeopleNum;
//	}
//
//	public void setRankMaxPeopleNum(Integer rankMaxPeopleNum) {
//		this.rankMaxPeopleNum = rankMaxPeopleNum;
//	}
//
//	public Double getRankFixMoney() {
//		return rankFixMoney;
//	}
//
//	public void setRankFixMoney(Double rankFixMoney) {
//		this.rankFixMoney = rankFixMoney;
//	}
//
//	public Double getRankTotalMoney() {
//		return rankTotalMoney;
//	}
//
//	public void setRankTotalMoney(Double rankTotalMoney) {
//		this.rankTotalMoney = rankTotalMoney;
//	}
	public Integer getGroupFinalSort() {
		return groupFinalSort;
	}

	public void setGroupFinalSort(Integer groupFinalSort) {
		this.groupFinalSort = groupFinalSort;
	}

//	public Integer getIsReward() {
//		return isReward;
//	}
//
//	public void setIsReward(Integer isReward) {
//		this.isReward = isReward;
//	}

	public List<Coupon> getRankCoupons() {
		return rankCoupons;
	}

	public void setRankCoupons(List<Coupon> rankCoupons) {
		this.rankCoupons = rankCoupons;
	}

	public Double getTotalCarveMoney() {
		return totalCarveMoney;
	}

	public void setTotalCarveMoney(Double totalCarveMoney) {
		this.totalCarveMoney = totalCarveMoney;
	}

	public Double getLeaderMoney() {
		return leaderMoney;
	}

	public void setLeaderMoney(Double leaderMoney) {
		this.leaderMoney = leaderMoney;
	}

	public Double getRankUserReward() {
		return rankUserReward;
	}

	public void setRankUserReward(Double rankUserReward) {
		this.rankUserReward = rankUserReward;
	}

	public Integer getRankActivityMinPeopleNum() {
		return rankActivityMinPeopleNum;
	}

	public void setRankActivityMinPeopleNum(Integer rankActivityMinPeopleNum) {
		this.rankActivityMinPeopleNum = rankActivityMinPeopleNum;
	}

	public Integer getActivityAttendNum() {
		return activityAttendNum;
	}

	public void setActivityAttendNum(Integer activityAttendNum) {
		this.activityAttendNum = activityAttendNum;
	}

	public Integer getRankActivityMaxPeopleNum() {
		return rankActivityMaxPeopleNum;
	}

	public void setRankActivityMaxPeopleNum(Integer rankActivityMaxPeopleNum) {
		this.rankActivityMaxPeopleNum = rankActivityMaxPeopleNum;
	}

	public Integer getRankMaxPeopleNum() {
		return rankMaxPeopleNum;
	}

	public void setRankMaxPeopleNum(Integer rankMaxPeopleNum) {
		this.rankMaxPeopleNum = rankMaxPeopleNum;
	}

	public Integer getUserNum() {
		return userNum;
	}

	public void setUserNum(Integer userNum) {
		this.userNum = userNum;
	}

	public Integer getUserFlag() {
		return userFlag;
	}

	public void setUserFlag(Integer userFlag) {
		this.userFlag = userFlag;
	}

	public List<CarveRankAwardVo> getCarveRankAwardList() {
		return carveRankAwardList;
	}

	public void setCarveRankAwardList(List<CarveRankAwardVo> carveRankAwardList) {
		this.carveRankAwardList = carveRankAwardList;
	}

	public Double getRankBondTotalNum() {
		return rankBondTotalNum;
	}

	public void setRankBondTotalNum(Double rankBondTotalNum) {
		this.rankBondTotalNum = rankBondTotalNum;
	}

	public Integer getNeedNewNum() {
		return needNewNum;
	}

	public void setNeedNewNum(Integer needNewNum) {
		this.needNewNum = needNewNum;
	}

	public Integer getNeedTotalNum() {
		return needTotalNum;
	}

	public void setNeedTotalNum(Integer needTotalNum) {
		this.needTotalNum = needTotalNum;
	}

	public Integer getRankingNum() {
		return rankingNum;
	}

	public void setRankingNum(Integer rankingNum) {
		this.rankingNum = rankingNum;
	}
	
}
