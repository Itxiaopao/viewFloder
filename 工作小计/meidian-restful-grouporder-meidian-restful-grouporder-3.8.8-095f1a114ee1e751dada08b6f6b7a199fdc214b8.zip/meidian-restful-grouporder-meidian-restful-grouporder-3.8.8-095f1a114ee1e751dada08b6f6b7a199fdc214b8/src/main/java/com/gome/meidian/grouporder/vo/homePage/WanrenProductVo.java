package com.gome.meidian.grouporder.vo.homePage;

import java.util.List;

import com.gome.meidian.grouporder.vo.ProductVo;

//万人团商品详情页商品信息类
public class WanrenProductVo extends ProductVo {

	private static final long serialVersionUID = 8068291201624877242L;
	
	private String bgImage;		// 背景图
	private String bgVideo;		// 背景视频
	private String serviceUrl;	// 客服URL
	private String brandId;		// 品牌ID
	private String brandName;	// 品牌名
	private String brandImage;	// 品牌图
	private String desc;		// 商品描述
	private List<String> images; 
	
	public String getBgImage() {
		return bgImage;
	}
	public void setBgImage(String bgImage) {
		this.bgImage = bgImage;
	}
	public String getBgVideo() {
		return bgVideo;
	}
	public void setBgVideo(String bgVideo) {
		this.bgVideo = bgVideo;
	}
	public String getServiceUrl() {
		return serviceUrl;
	}
	public void setServiceUrl(String serviceUrl) {
		this.serviceUrl = serviceUrl;
	}
	public String getBrandId() {
		return brandId;
	}
	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getBrandImage() {
		return brandImage;
	}
	public void setBrandImage(String brandImage) {
		this.brandImage = brandImage;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public List<String> getImages() {
		return images;
	}
	public void setImages(List<String> images) {
		this.images = images;
	}
	
}
