package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

public class StoreVo implements Serializable{

	private static final long serialVersionUID = -1793006582020356527L;

	private String name;
	private String color;
	private String type;
	private List<ModelVo> model;
	private Integer operator_id;
	private Integer user_id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<ModelVo> getModel() {
		return model;
	}
	public void setModel(List<ModelVo> model) {
		this.model = model;
	}
	public Integer getOperator_id() {
		return operator_id;
	}
	public void setOperator_id(Integer operator_id) {
		this.operator_id = operator_id;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	
	
}
