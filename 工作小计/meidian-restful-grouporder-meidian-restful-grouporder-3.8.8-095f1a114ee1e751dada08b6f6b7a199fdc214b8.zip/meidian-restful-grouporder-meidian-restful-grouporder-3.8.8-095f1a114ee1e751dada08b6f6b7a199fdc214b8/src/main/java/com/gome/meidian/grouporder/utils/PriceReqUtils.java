package com.gome.meidian.grouporder.utils;

import java.io.Serializable;

/**
 * 价格入参
 * @author Administrator
 *
 */
public class PriceReqUtils implements Serializable{

	private static final long serialVersionUID = 8775975838969286439L;
	private String storeCode;	// 传给商品组取价格的门店编码
	private String areaCode;	// 传给商品组取价格的二级区域码
	
	
	public PriceReqUtils() {
		super();
	}

	public PriceReqUtils(String storeCode, String areaCode) {
		super();
		this.storeCode = storeCode;
		this.areaCode = areaCode;
	}



	public String getStoreCode() {
		return storeCode;
	}


	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}


	public String getAreaCode() {
		return areaCode;
	}


	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	
}