package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

public class StepsVo implements Serializable{
//	[{\"step\":\"1\",\"peopleNum\":\"2\",\"discount\":\"9\"},{\"step\":\"2\",\"peopleNum\":\"4\",\"discount\":\"8\"}]",

	private static final long serialVersionUID = 6097244625163752412L;
	
	private List<CurrentStepsVo> currentStepsVos;	// 当前阶梯
	private Integer stepsNum;   					// 阶梯总数量 
	
	public List<CurrentStepsVo> getCurrentStepsVos() {
		return currentStepsVos;
	}
	public void setCurrentStepsVos(List<CurrentStepsVo> currentStepsVos) {
		this.currentStepsVos = currentStepsVos;
	}
	public Integer getStepsNum() {
		return stepsNum;
	}
	public void setStepsNum(Integer stepsNum) {
		this.stepsNum = stepsNum;
	}
	
	
}
