package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.coupon.Promotion;
import com.gome.meidian.grouporder.vo.grouporderVo.EnergySavingSubsidiesVo;
import com.gome.meidian.grouporder.vo.grouporderVo.SkuEnergyAllowanceVo;
import com.gomeplus.bs.interfaces.gorder.vo.GroupInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.GroupMemberListVo;

public class ProductDetailVo implements Serializable {

	private static final long serialVersionUID = -1417013036780951702L;
	private ProductVo product;							// 商品，商品集信息
	private GroupInfomationVo groupInfo;				// 团信息	
	private Integer operationStatus;					// 用户对团的操作状态，1-只能参团 2-只能开团 3-已参过此团 4-团已完成或失效
	private ProductInfoVo productInfo;					// 售后，包装，规格参数
	private SkuEnergyAllowanceVo skuEnergyAllowance;  	// 节能补贴信息
	private EnergySavingSubsidiesVo energySavingSubsidies; //节能优惠信息
	private Integer warranty;							// 1: 有延保，0：没有延保
//	private List<Promotion> promotions;					// 促销语
	
	public ProductVo getProduct() {
		return product;
	}
	public void setProduct(ProductVo product) {
		this.product = product;
	}
	public GroupInfomationVo getGroupInfo() {
		return groupInfo;
	}
	public void setGroupInfo(GroupInfomationVo groupInfo) {
		this.groupInfo = groupInfo;
	}
	public Integer getOperationStatus() {
		return operationStatus;
	}
	public void setOperationStatus(Integer operationStatus) {
		this.operationStatus = operationStatus;
	}
	public ProductInfoVo getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(ProductInfoVo productInfo) {
		this.productInfo = productInfo;
	}
	public SkuEnergyAllowanceVo getSkuEnergyAllowance() {
		return skuEnergyAllowance;
	}
	public void setSkuEnergyAllowance(SkuEnergyAllowanceVo skuEnergyAllowance) {
		this.skuEnergyAllowance = skuEnergyAllowance;
	}
	public Integer getWarranty() {
		return warranty;
	}
	public void setWarranty(Integer warranty) {
		this.warranty = warranty;
	}
	public EnergySavingSubsidiesVo getEnergySavingSubsidies() {
		return energySavingSubsidies;
	}
	public void setEnergySavingSubsidies(EnergySavingSubsidiesVo energySavingSubsidies) {
		this.energySavingSubsidies = energySavingSubsidies;
	}
//	public List<Promotion> getPromotions() {
//		return promotions;
//	}
//	public void setPromotions(List<Promotion> promotions) {
//		this.promotions = promotions;
//	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
