package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;

/**
 * 客服信息
 * 
 * @author libinbin-ds
 *
 */
public class GuestInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7904350669872954985L;
	private Long userId;	// userId
    private String weiXinNickName;//微信昵称
    private String weixinNum;//微信号
    private String imagePath;//头像
    private String nickNameOfInvitation;//邀请人微信昵称
    private String imagePathOfInvitation; //邀请人图片 
    private String phone;//手机号
    private Integer userType;//用户类型 1新客 2游客 4首单 5忠粉
    private Integer userIdentity;//店主身份 1.店主2.店总3.片总
    private String browsLatestDate;	// 最近浏览时间
    private String registrationTime;//注册时间
    private Long orderNum;	// 订单数量
    private Long saleAmounts;	// 累计销售金额
    private Long firstOrderPrice;	// 首单金额
    private String firstOrderDate;	// 首单时间
    private String uniqueId;	// uniqueId 游客id
    private Integer authorization;//0 未授权   1 授权
    
    public String getUniqueId() {
    	return uniqueId;
    }
	

	
	public GuestInfo(Long userId, String weiXinNickName, String weixinNum, String imagePath,
			String nickNameOfInvitation, String imagePathOfInvitation, String phone, Integer userType,
			Integer userIdentity, String browsLatestDate, String registrationTime, Long orderNum, Long saleAmounts,
			Long firstOrderPrice, String firstOrderDate, String uniqueId) {
		this.userId = userId;
		this.weiXinNickName = weiXinNickName;
		this.weixinNum = weixinNum;
		this.imagePath = imagePath;
		this.nickNameOfInvitation = nickNameOfInvitation;
		this.imagePathOfInvitation = imagePathOfInvitation;
		this.phone = phone;
		this.userType = userType;
		this.userIdentity = userIdentity;
		this.browsLatestDate = browsLatestDate;
		this.registrationTime = registrationTime;
		this.orderNum = orderNum;
		this.saleAmounts = saleAmounts;
		this.firstOrderPrice = firstOrderPrice;
		this.firstOrderDate = firstOrderDate;
		this.uniqueId = uniqueId;
	}
	

	public GuestInfo(Long userId, String weiXinNickName, String weixinNum, String imagePath,
			String nickNameOfInvitation, String imagePathOfInvitation, String phone, Integer userType,
			Integer userIdentity, String browsLatestDate, String registrationTime, Long orderNum, Long saleAmounts,
			Long firstOrderPrice, String firstOrderDate, String uniqueId, Integer authorization) {
		this.userId = userId;
		this.weiXinNickName = weiXinNickName;
		this.weixinNum = weixinNum;
		this.imagePath = imagePath;
		this.nickNameOfInvitation = nickNameOfInvitation;
		this.imagePathOfInvitation = imagePathOfInvitation;
		this.phone = phone;
		this.userType = userType;
		this.userIdentity = userIdentity;
		this.browsLatestDate = browsLatestDate;
		this.registrationTime = registrationTime;
		this.orderNum = orderNum;
		this.saleAmounts = saleAmounts;
		this.firstOrderPrice = firstOrderPrice;
		this.firstOrderDate = firstOrderDate;
		this.uniqueId = uniqueId;
		this.authorization = authorization;
	}



	public Integer getAuthorization() {
		return authorization;
	}



	public void setAuthorization(Integer authorization) {
		this.authorization = authorization;
	}



	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Integer getUserIdentity() {
		return userIdentity;
	}

	public void setUserIdentity(Integer userIdentity) {
		this.userIdentity = userIdentity;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public GuestInfo(String weiXinNickName, String weixinNum, String nickNameOfInvitation, String imagePathOfInvitation,
			String phone, String browsLatestDate, String registrationTime, Long orderNum, Long saleAmounts,
			Long firstOrderPrice, String firstOrderDate) {
		this.weiXinNickName = weiXinNickName;
		this.weixinNum = weixinNum;
		this.nickNameOfInvitation = nickNameOfInvitation;
		this.imagePathOfInvitation = imagePathOfInvitation;
		this.phone = phone;
		this.browsLatestDate = browsLatestDate;
		this.registrationTime = registrationTime;
		this.orderNum = orderNum;
		this.saleAmounts = saleAmounts;
		this.firstOrderPrice = firstOrderPrice;
		this.firstOrderDate = firstOrderDate;
	}

	public String getWeiXinNickName() {
		return weiXinNickName;
	}

	public void setWeiXinNickName(String weiXinNickName) {
		this.weiXinNickName = weiXinNickName;
	}

	public String getWeixinNum() {
		return weixinNum;
	}

	public void setWeixinNum(String weixinNum) {
		this.weixinNum = weixinNum;
	}

	public String getNickNameOfInvitation() {
		return nickNameOfInvitation;
	}

	public void setNickNameOfInvitation(String nickNameOfInvitation) {
		this.nickNameOfInvitation = nickNameOfInvitation;
	}

	public String getImagePathOfInvitation() {
		return imagePathOfInvitation;
	}

	public void setImagePathOfInvitation(String imagePathOfInvitation) {
		this.imagePathOfInvitation = imagePathOfInvitation;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getRegistrationTime() {
		return registrationTime;
	}

	public void setRegistrationTime(String registrationTime) {
		this.registrationTime = registrationTime;
	}

	public GuestInfo() {
		super();
	}
	
	public GuestInfo(Long orderNum, Long saleAmounts, Long firstOrderPrice, String firstOrderDate) {
		this.orderNum = orderNum;
		this.saleAmounts = saleAmounts;
		this.firstOrderPrice = firstOrderPrice;
		this.firstOrderDate = firstOrderDate;
	}
	
	
	public String getBrowsLatestDate() {
		return browsLatestDate;
	}

	public void setBrowsLatestDate(String browsLatestDate) {
		this.browsLatestDate = browsLatestDate;
	}

	public Long getOrderNum() {
		return orderNum;
	}
	public void setOrderNum(Long orderNum) {
		this.orderNum = orderNum;
	}
	public Long getSaleAmounts() {
		return saleAmounts;
	}
	public void setSaleAmounts(Long saleAmounts) {
		this.saleAmounts = saleAmounts;
	}
	public Long getFirstOrderPrice() {
		return firstOrderPrice;
	}
	public void setFirstOrderPrice(Long firstOrderPrice) {
		this.firstOrderPrice = firstOrderPrice;
	}
	public String getFirstOrderDate() {
		return firstOrderDate;
	}
	public void setFirstOrderDate(String firstOrderDate) {
		this.firstOrderDate = firstOrderDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
