package com.gome.meidian.grouporder.vo.store;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.gome.dragon.mds.client.dto.gcc.GomeStoreFullImg;

/**
 * 门店信息
 * @author shichangjian
 *
 */
public class Store implements Serializable{

	private static final long serialVersionUID = -6499913899536141245L;

	private String storeCode;					// 门店编码
	private String storeId;						// 门店id
	private String companyId;					// 公司id
	private String provinceCode;				// 省编码
	private String provinceName;				// 省名称
	private String cityCode;					// 市编码
	private String cityName;					// 市名称
	private String countyCode;					// 县(区)编码
	private String countyName;					// 县(区)名称
	private String storeName;					// 门店名称
	private String storeAddress;				// 门店详细地址
	private String storeHQCode;					// 集团门店编码
	private String storePhone;					// 门店电话
	private String enabled;						// 门店是否支持自提 
	private String zoneCode;					// 区号
	private String shopNo;						// 店铺号
	private Integer selfPickupType;				// 自提类型 1 配送自提 2 立即自提(门店直接提货) 3 全部支持 默认值是1
	private String storeZonePhone;				// 区号+固定电话组装
	private String brand;						// 品牌类型
	private String businessHours;				// 营业时间
	private String lng;							// 经度
	private String lat;							// 纬度
	private String invoiceType;					// 是否开通电子发票业务（0 未开通  1开通）
	private String organizationId;				// 销售组织id
	private String branchId1;					// 一级分部代码
	private String branchId2;					// 二级分部代码
	private Integer poolFlag;					// 0: 自营，1: 联营，2: 加盟
	private double distance;					// 距门店的距离
	private String logo;						// 门店logo
	private String branchLevel;					// 分部级别
	private String organizationName;			// 销售组织名
	private String branchName1;					//一级分部名 
	private String branchName2;					//二级分部名
//	private Integer brandFlag;					//转品牌销售标记
	private Integer storeType;					//1-实体门店,2-虚拟门店
	private Integer status;						//状态 1-有效,-1无效
	private String regioneId;					//大区ID
	private String regioneName;					//大区名称
//	private String aftermarketOrganizationId;	//售后销售组织代码
//	private String aftermarketOrganizationName;	//售后销售组织名称
//	private String aftermarketStore;			//售后门店
//	private String aftermarketStoreName;		//售后门店名称
//	private String insertBy;
//	private Date insertDate;
//	private String modifiedBy;
//	private Date modifiedDate;
//	private String divisionCode;
//	private Integer agencyFundStatus;			//代收款业务（1：启用，0：停用）
//	private Integer storeHome;
//	private String storeIntroduce;
//	private List<GomeStoreFullImg> gsi = new ArrayList<>();
//	private String companyName;					//公司名称
//	private String branchLevel1;				//分部级别 A+ A B
//	private String brandName;					//所属品牌 国美 大中
//	private String storeTypeCode;				//门店类型 编码：1 2 3
//	private String storeLevel;					//门店等级 编码：A B C D
//	private String storeTypeCodeDesc;			//门店类型描述 名称：旗舰店 标准店…
//	private String storeLevelDesc;				//门店等级描述 名称：A B C D
//	private String storePayMethod;				//门店收款方式 独立收款，第三方收款（联营 加盟）
//	private Date trialOpenTime;					//试营业时间
//	private Date openTime;						//开业时间
//	private Date resetTime;						//重装时间
//	private String market;						//所属市场 一级组 二级组
//	private String storeOneOrTwoLevel;			//门店所属一二级 数字
//	private String city;						//所在城市
//	private String postcode;					//邮编
//	private String storeAttribute;				//门店属性 上市 非上市
//	private String storeContact;				//门店联系人
//	private String rentArea;					//计租面积
	
	public String getStoreCode() {
		return storeCode;
	}
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
	public String getProvinceName() {
		return provinceName;
	}
	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	public String getCountyName() {
		return countyName;
	}
	public void setCountyName(String countyName) {
		this.countyName = countyName;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getStoreAddress() {
		return storeAddress;
	}
	public void setStoreAddress(String storeAddress) {
		this.storeAddress = storeAddress;
	}
	public String getStoreHQCode() {
		return storeHQCode;
	}
	public void setStoreHQCode(String storeHQCode) {
		this.storeHQCode = storeHQCode;
	}
	public String getStorePhone() {
		return storePhone;
	}
	public void setStorePhone(String storePhone) {
		this.storePhone = storePhone;
	}
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}
	public String getZoneCode() {
		return zoneCode;
	}
	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}
	public String getShopNo() {
		return shopNo;
	}
	public void setShopNo(String shopNo) {
		this.shopNo = shopNo;
	}
	public Integer getSelfPickupType() {
		return selfPickupType;
	}
	public void setSelfPickupType(Integer selfPickupType) {
		this.selfPickupType = selfPickupType;
	}
	public String getStoreZonePhone() {
		return storeZonePhone;
	}
	public void setStoreZonePhone(String storeZonePhone) {
		this.storeZonePhone = storeZonePhone;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getBusinessHours() {
		return businessHours;
	}
	public void setBusinessHours(String businessHours) {
		this.businessHours = businessHours;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getInvoiceType() {
		return invoiceType;
	}
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}
	public String getOrganizationId() {
		return organizationId;
	}
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	public String getBranchId1() {
		return branchId1;
	}
	public void setBranchId1(String branchId1) {
		this.branchId1 = branchId1;
	}
	public String getBranchId2() {
		return branchId2;
	}
	public void setBranchId2(String branchId2) {
		this.branchId2 = branchId2;
	}
	public Integer getPoolFlag() {
		return poolFlag;
	}
	public void setPoolFlag(Integer poolFlag) {
		this.poolFlag = poolFlag;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	public String getBranchLevel() {
		return branchLevel;
	}
	public void setBranchLevel(String branchLevel) {
		this.branchLevel = branchLevel;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public String getBranchName1() {
		return branchName1;
	}
	public void setBranchName1(String branchName1) {
		this.branchName1 = branchName1;
	}
	public String getBranchName2() {
		return branchName2;
	}
	public void setBranchName2(String branchName2) {
		this.branchName2 = branchName2;
	}
	public Integer getStoreType() {
		return storeType;
	}
	public void setStoreType(Integer storeType) {
		this.storeType = storeType;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getRegioneId() {
		return regioneId;
	}
	public void setRegioneId(String regioneId) {
		this.regioneId = regioneId;
	}
	public String getRegioneName() {
		return regioneName;
	}
	public void setRegioneName(String regioneName) {
		this.regioneName = regioneName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}


