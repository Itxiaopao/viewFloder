package com.gome.meidian.grouporder.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.grouporder.manager.GroupOrderStatusManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@RequestMapping("/gdStatus")
public class GroupOrderStatusController {
	
	@Autowired
	private GroupOrderStatusManager groupOrderStatusManager;
	
	private final static List<String> riskCouponStatus = Arrays.asList("0", "1", "2");  //领券风控开关  0-关闭  1-开启   2-取消
	/**
	 * 领券风控开关
	 * @param status
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value = "/switchRiskCouponStatus", method = RequestMethod.GET)
	public ResponseJson switchRiskCouponStatus(
			@NotNull(message = "{param.error}") @RequestParam("status") String status,
			HttpServletRequest request){
		ResponseJson response = new ResponseJson();
		if(riskCouponStatus.contains(status)){
			status = groupOrderStatusManager.riskCouponSwitch(status, request);
			response.setData(status);
		}else{
			response.setData("风控开关状态错误:0-关闭风控验证; 1-开启风控验证; 2-取消风控验证开关");
		}
		return response;
	}
	
}
