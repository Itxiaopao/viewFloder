package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class AttendGroupVo implements Serializable {

	private static final long serialVersionUID = 4471750917227891384L;
	
	@NotNull(message = "{param.error}")
	private Long activityId;			// 活动id
	private Long groupId;				// 团id
	@NotBlank(message = "{param.error}")
	private String skuId;				// skuId
	@NotBlank(message = "{param.error}")
	private String productId;			// 商品productId
	@NotNull(message = "{param.error}")
	private Integer buyNumber;			// 购买件数
	private String areaCode;			// 三级区域码
	@NotNull(message = "{param.error}")
	private String kid;					// 标识组团订单kid
//	@NotNull(message = "{param.error}")
//	private Boolean singleBuy;			// 是否单独购买,true:单独购买 false:凑单
	@NotNull(message = "{param.error}")
	private Integer modeType;			// 开团，参团模式，0:参团,1:开团
	private String flowActivityId;		// 集客活动id
	private String pagecode;			// 集客活动页code
	private String staffId; 			// 发起者userId
	private String storeCode; 			// 发起者的门店编码
	
	
	public String getKid() {
		return kid;
	}
	public void setKid(String kid) {
		this.kid = kid;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Integer getBuyNumber() {
		return buyNumber;
	}
	public void setBuyNumber(Integer buyNumber) {
		this.buyNumber = buyNumber;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	public Integer getModeType() {
		return modeType;
	}
	public void setModeType(Integer modeType) {
		this.modeType = modeType;
	}
	public String getFlowActivityId() {
		return flowActivityId;
	}
	public void setFlowActivityId(String flowActivityId) {
		this.flowActivityId = flowActivityId;
	}
	public String getPagecode() {
		return pagecode;
	}
	public void setPagecode(String pagecode) {
		this.pagecode = pagecode;
	}
	public String getStaffId() {
		return staffId;
	}
	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}
	public String getStoreCode() {
		return storeCode;
	}
	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	
	
}
