package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import com.gome.meidian.grouporder.vo.mshopUserVo.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.mshopUserManager.MshopHomePageManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.OrderListPageManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@Validated
@RequestMapping("/mshopUser/listPage")
public class OrderListPageController {
	
	private Logger logger = LoggerFactory.getLogger(getClass()); 
	@Autowired
	private AuthencationUtils authencationUtils;
	@Autowired
	private OrderListPageManager orderListPageManager;
	@Autowired
	private MshopHomePageManager mshopHomePageManager;
	/**
	 * 收益列表页，总体收益信息
	 * @param scn
	 * @param statusType
	 * @param beginTime
	 * @param endTime
	 * @param dimension
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getProfitInfo", method = RequestMethod.GET)
	public ResponseJson<Map<String,Long>> getProfitInfo(
			@CookieValue(value = "SCN", required = false) String scn, 
			@NotNull(message = "{param.error}") @RequestParam(value = "statusType", required = true) Integer statusType,
            @RequestParam(value = "dimension", required = false) String dimension,
			HttpServletRequest request
			)throws MeidianException{
		ResponseJson<Map<String,Long>> response = new ResponseJson<Map<String,Long>>();
		Map<String,Long> map = new HashMap<String,Long>();
		map.put("amount", 0L);	
		map.put("login", 1L);
		
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(userId == null){
			map.put("login", 0L); 
			response.setData(map);
			return response;
		}
		map = orderListPageManager.getProfitInfo(userId, statusType,  dimension);
		map.put("login", 1L);
		response.setData(map);
		return response;
	}
	/**
	 * 收益列表页
	 * @param scn
	 * @param statusType
	 * @param beginTime
	 * @param endTime
	 * @param dimension
	 * @return
	 */
	@RequestMapping(value = "/getProfitList", method = RequestMethod.POST)
	public ResponseJson<Map<String,Object>> getProfitList(
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@RequestBody @Validated GetProfitListParamVo getProfitListParamVo,
			HttpServletRequest request
			)throws MeidianException{
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		ResponseJson<Map<String,Object>> response = new ResponseJson<Map<String,Object>>();
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("rebateDetails", null);
		map.put("login", 1L); 
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(userId == null){
			map.put("login", 0L); 
			response.setData(map);
			return response;
		}
		List<RebateInfoVo> list = orderListPageManager.getProfitList(userId, getProfitListParamVo.getStatusType(), getProfitListParamVo.getPageNum(), getProfitListParamVo.getPageSize(), getProfitListParamVo.getDimension(),ua,ppi);
		map.put("rebateDetails", list);
		
//		List<RebateInfoVo> list = TestModelDate.getProfitList();
//		map.put("rebateDetails", list);
		
		response.setData(map);
		return response;
	}
	/**
	 * 销售订单列表
	 * @param scn
	 * @param filter
	 * @param orderStatus
	 * @return
	 */
	@RequestMapping(value = "/saleOrderList", method = RequestMethod.POST)
	public ResponseJson<Map<String,Object>> saleOrderList(
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@RequestBody @Validated SaleOrderListParamVo saleOrderListParamVo,
			HttpServletRequest request
			)throws MeidianException{
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		ResponseJson<Map<String, Object>> response = new ResponseJson<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("orderList", null);
		map.put("login", 1L); 
		String userId = authencationUtils.authenticationLogin(scn);
		if (userId == null) {
			map.put("login", 0L); 
			response.setData(map);
			return response;
		}
		List<OrderInfoVo> resultList = orderListPageManager.getOrderList(
				Long.valueOf(userId),
				Long.valueOf(userId), 
				saleOrderListParamVo.getFilter(),
				saleOrderListParamVo.getOrderStatus(),
				null, saleOrderListParamVo.getPageNo(),
				saleOrderListParamVo.getPageSize(),null,null,ua,ppi,"3");
		map.put("orderList", resultList);
		
//		List<OrderInfoVo> resultList = TestModelDate.getOrderList();
//		map.put("orderList", resultList);
		response.setData(map);
		return response;
	} 
	/**
	 * 业绩销售额查询
	 * @param scn
	 * @param filter
	 * @param dateState
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getAchievementInfo", method = RequestMethod.POST)
	public ResponseJson<Map<String,Long>> getAchievementInfo(
			@CookieValue(value = "SCN", required = false) String scn, 
			@RequestBody @Validated  AchievementOrderParamVo achievementOrderParamVo
			)throws MeidianException{
		
        String dateState = achievementOrderParamVo.getDateState();
		if(dateState.equals("1")){
			achievementOrderParamVo.setDateState("2");
		}else if(dateState.equals("2")){
			achievementOrderParamVo.setDateState("1");
		}
		
		ResponseJson<Map<String,Long>> response = new ResponseJson<Map<String,Long>>();
		Map<String,Long> map = new HashMap<String,Long>();
		map.put("amount", 0L);	
		map.put("login", 1L); 
		String userId = authencationUtils.authenticationLogin(scn);
		if(userId == null){
			map.put("login", 0L); 
			response.setData(map);
			return response;
		}
		Long  amount = orderListPageManager.getAchievementInfo(Long.valueOf(userId), achievementOrderParamVo.getFilter(),900,achievementOrderParamVo.getDateState());
		map.put("amount", amount);	
		
		response.setData(map);
		return response;
	}
	
	/**
	 * 业绩订单列表
	 * @param scn
	 * @param filter
	 * @param orderStatus
	 * @return
	 */
	@RequestMapping(value = "/achievementOrderList", method = RequestMethod.POST)
	public ResponseJson<Map<String,Object>> achievementOrderList(
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@RequestBody @Validated  AchievementOrderListParamVo achievementOrderListParamVo,
			HttpServletRequest request
			)throws MeidianException{
        String dateState = achievementOrderListParamVo.getDateState();
		if(dateState.equals("1")){
			achievementOrderListParamVo.setDateState("2");
		}else if(dateState.equals("2")){
			achievementOrderListParamVo.setDateState("1");
		}
		
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		ResponseJson<Map<String, Object>> response = new ResponseJson<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("orderList", null);
		map.put("login", 1L); 
		
		String userId = authencationUtils.authenticationLogin(scn);
		if (userId == null) {
			map.put("login", 0L); 
			response.setData(map);
			return response;
		}
		List<OrderInfoVo> resultList = orderListPageManager.getOrderList(
				Long.valueOf(userId),
				Long.valueOf(userId), 
				achievementOrderListParamVo.getFilter(), 
				900,achievementOrderListParamVo.getDateState(),
				achievementOrderListParamVo.getPageNo(), 
				achievementOrderListParamVo.getPageSize(),
				null, null,ua,ppi,"2");
		map.put("orderList", resultList);
		
//		List<OrderInfoVo> resultList = TestModelDate.getOrderList();
//		map.put("orderList", resultList);
		response.setData(map);
		return response;
	} 
	
	/**
	 * 提奖订单列表
	 * @param scn
	 * @param filter
	 * @param orderStatus
	 * @return
	 */
	@RequestMapping(value = "/awardOrderList", method = RequestMethod.POST)
	public ResponseJson<Map<String,Object>> awardOrderList(
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@RequestBody @Validated  AwardOrderListParamVo awardOrderListParamVo,
			HttpServletRequest request
			)throws MeidianException{
		String year = null;
		String month = null;
		if(awardOrderListParamVo.getYearMonth().length() != 6){
			throw new ServiceException("base.match.yearMonth.length");
		}
		year = awardOrderListParamVo.getYearMonth().substring(0, 4);
		month = awardOrderListParamVo.getYearMonth().substring(4);
		ResponseJson<Map<String, Object>> response = new ResponseJson<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("orderList", null);
		map.put("login", 1L); 
		String userId = authencationUtils.authenticationLogin(scn);
		if (userId == null) {
			map.put("login", 0L); 
			response.setData(map);
			return response;
		}
		
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);


		List<OrderInfoVo> resultList = orderListPageManager.getOrderList(
				Long.valueOf(userId),
				Long.valueOf(awardOrderListParamVo.getUserId()), 
				null, awardOrderListParamVo.getOrderStatus(),null,
				awardOrderListParamVo.getPageNo(), 
				awardOrderListParamVo.getPageSize(),
				year,month,ua,ppi,"1");
		map.put("orderList", resultList);
		
		
//		List<OrderInfoVo> resultList = TestModelDate.getOrderList();
//		map.put("orderList", resultList);
		response.setData(map);
		return response;
	} 
    /**
     * 客户订单记录
     * @param saleOrderListParamVo
     * @return
     */
	@RequestMapping(value = "/customerOrderRecord", method = RequestMethod.POST)
	public ResponseJson<Map<String,Object>> customerOrderRecord(
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@RequestBody @Validated  CustomerOrderRecordParamVo customerOrderRecordParamVo,
			HttpServletRequest request
			){
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		ResponseJson<Map<String, Object>> response = new ResponseJson<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		List<OrderInfoVo> resultList = orderListPageManager.getUserOrderList(
				Long.valueOf(customerOrderRecordParamVo.getUserId()),
				customerOrderRecordParamVo.getDateState(),
				customerOrderRecordParamVo.getPageNo(), 
				customerOrderRecordParamVo.getPageSize(), ua, ppi);
		map.put("orderList", resultList);
		
		
		
		
//		List<OrderInfoVo> resultList = TestModelDate.getOrderList();
//		map.put("orderList", resultList);
		response.setData(map);
		return response;
		
	}

	/**
	 * 百货店主确认提货
	 * @param scn 用户登录scn
	 * @param pickGoodsParamVo 提货入参
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/savePickGoods", method = RequestMethod.POST)
	public ResponseJson<Map<String,Object>> savePickGoods( @CookieValue(value = "SCN", required = false) String scn,
														   @RequestBody @Validated PickGoodsParamVo pickGoodsParamVo) throws MeidianException{
		ResponseJson<Map<String, Object>> response = new ResponseJson<>();
		Map<String,Object> map = new HashMap<>();
		String userId = authencationUtils.authenticationLogin(scn);
		if (userId == null) {
			map.put("login", 0L);
			response.setData(map);
			return response;
		}
		Boolean result = orderListPageManager.savePickGoods(pickGoodsParamVo.getDeliveryId(), Long.valueOf(userId), pickGoodsParamVo.getIsPickGoods());
		map.put("success",result);
		map.put("login", 1L);
		response.setData(map);
		return response;

	}
	
	public static void main(String[] args) {
		String year = null;
		String month = null;

		year = "201907".substring(0, 4);
		month = "201907".substring(4);
		System.out.println(year);
		System.out.println(month);
	}
}
