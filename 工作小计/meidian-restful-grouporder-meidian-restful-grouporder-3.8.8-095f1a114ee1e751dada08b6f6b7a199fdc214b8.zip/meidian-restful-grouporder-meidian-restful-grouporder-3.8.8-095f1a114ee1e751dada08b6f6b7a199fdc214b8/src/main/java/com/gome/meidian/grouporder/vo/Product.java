package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 商品信息
 * 
 * @author shichangjian
 *
 */
public class Product implements Serializable {

	private static final long serialVersionUID = -3779974385048163698L;

	private String id; 				// 商品productId
	private String shopId; 			// 联营pop商铺id
	private String mainImage; 		// 商品图
	private String name; 			// 商品名称
	private long salePrice; 		// 商品价格
	private int status; 			// 上下价状态1：上架，-1：下架
	private String skuId; 			// skuId
	private String itemId;
	private int productTag; 		// 1：自营 2：联营
	private String skuNo;
	private String priceKey; 		// 下单带着，区分美店价
	private Integer allowanceFlag;	//节能补贴标识，1为有节能补贴
	private String priceType;  //价格类型

	public Product() {
		super();
	}

	public Product(String id, String shopId, String mainImage, 
					String name, long salePrice, int status, 
					String skuId, String itemId, int productTag, 
					String skuNo, String priceKey, Integer allowanceFlag) {
		super();
		this.id = id;
		this.shopId = shopId;
		this.mainImage = mainImage;
		this.name = name;
		this.salePrice = salePrice;
		this.status = status;
		this.skuId = skuId;
		this.itemId = itemId;
		this.productTag = productTag;
		this.skuNo = skuNo;
		this.priceKey = priceKey;
		this.allowanceFlag = allowanceFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public String getMainImage() {
		return mainImage;
	}

	public void setMainImage(String mainImage) {
		this.mainImage = mainImage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getSalePrice() {
		return salePrice;
	}

	public void setSalePrice(long salePrice) {
		this.salePrice = salePrice;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public int getProductTag() {
		return productTag;
	}

	public void setProductTag(int productTag) {
		this.productTag = productTag;
	}

	public String getSkuNo() {
		return skuNo;
	}

	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}

	public Integer getAllowanceFlag() {
		return allowanceFlag;
	}
	public void setAllowanceFlag(Integer allowanceFlag) {
		this.allowanceFlag = allowanceFlag;
	}
	
	public String getPriceKey() {
		return priceKey;
	}

	public void setPriceKey(String priceKey) {
		this.priceKey = priceKey;
	}

	public String getPriceType() {
		return priceType;
	}

	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}

}
