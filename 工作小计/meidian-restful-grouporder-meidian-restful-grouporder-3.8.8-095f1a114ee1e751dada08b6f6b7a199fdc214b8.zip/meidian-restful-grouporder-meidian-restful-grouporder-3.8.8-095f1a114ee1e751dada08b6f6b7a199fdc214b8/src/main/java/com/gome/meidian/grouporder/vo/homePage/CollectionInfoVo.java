package com.gome.meidian.grouporder.vo.homePage;

import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;

public class CollectionInfoVo extends ProductGroupInfoVo {

	private static final long serialVersionUID = -5075027963755769478L;

	//是否收藏过,0-未收藏  1-已收藏
	private Integer collected;
	
	private Long collectionId;
	
	//收藏的活动是否过期   1-过期   0-未过期
	private Integer activityExpired;

	public Integer getCollected() {
		return collected;
	}

	public void setCollected(Integer collected) {
		this.collected = collected;
	}

	public Long getCollectionId() {
		return collectionId;
	}

	public void setCollectionId(Long collectionId) {
		this.collectionId = collectionId;
	}

	public Integer getActivityExpired() {
		return activityExpired;
	}

	public void setActivityExpired(Integer activityExpired) {
		this.activityExpired = activityExpired;
	}
	
	
}
