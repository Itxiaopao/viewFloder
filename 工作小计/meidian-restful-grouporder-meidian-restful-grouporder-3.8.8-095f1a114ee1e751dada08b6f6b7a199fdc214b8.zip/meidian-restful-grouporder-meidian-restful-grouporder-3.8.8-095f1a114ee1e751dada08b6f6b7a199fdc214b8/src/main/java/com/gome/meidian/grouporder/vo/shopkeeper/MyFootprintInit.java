package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.List;

/**
 * 用户足迹初始化
 * 
 * @author libinbin-ds
 *
 */
public class MyFootprintInit implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = -3213758505710080448L;
	
	private GuestInfo guestInfo;	// 店主用户
	private List<MyFootprintVo> footPrints;	// 我的用户足迹
	
	
	public GuestInfo getGuestInfo() {
		return guestInfo;
	}
	public void setGuestInfo(GuestInfo guestInfo) {
		this.guestInfo = guestInfo;
	}
	public List<MyFootprintVo> getFootPrints() {
		return footPrints;
	}
	public void setFootPrints(List<MyFootprintVo> footPrints) {
		this.footPrints = footPrints;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
