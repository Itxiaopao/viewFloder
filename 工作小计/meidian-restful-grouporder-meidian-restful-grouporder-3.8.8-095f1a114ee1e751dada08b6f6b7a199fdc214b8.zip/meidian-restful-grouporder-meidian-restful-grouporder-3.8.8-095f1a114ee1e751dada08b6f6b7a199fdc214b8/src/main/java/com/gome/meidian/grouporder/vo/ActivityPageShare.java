package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

public class ActivityPageShare implements Serializable{

	private static final long serialVersionUID = 4014830715344451278L;

	private String unique_key;
	private String title;
	private String image;
	private String description;
	
	public String getUnique_key() {
		return unique_key;
	}
	public void setUnique_key(String unique_key) {
		this.unique_key = unique_key;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
