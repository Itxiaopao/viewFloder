package com.gome.meidian.grouporder.vo.product;

import com.gome.meidian.grouporder.vo.Product;

import java.io.Serializable;

/**
 * 热度调研列表商品信息
 * @author shigaopeng
 *
 */
public class ProductSurveyInfoVo implements Serializable {

    private static final long serialVersionUID = 1021502700669897271L;
    private Product product;    // 商品信息
    private String  expanded1;  // 扩展字段（广告语，佣金，组团价...）

    public ProductSurveyInfoVo() {
        super();
    }

    public Product getProduct() {
        return product;
    }
    public void setProduct(Product product) {
        this.product = product;
    }

    public String getExpanded1() {
        return expanded1;
    }

    public void setExpanded1(String expanded1) {
        this.expanded1 = expanded1;
    }
}
