package com.gome.meidian.grouporder.vo.grouporderVo;

import com.gome.meidian.grouporder.vo.Coupon;

public class HelpGroupCouponVo extends Coupon {

	private static final long serialVersionUID = -9162248059657423984L;
	private String couponPageCode;  //与券对应的活动页pageCode
	public String getCouponPageCode() {
		return couponPageCode;
	}
	public void setCouponPageCode(String couponPageCode) {
		this.couponPageCode = couponPageCode;
	}
	
}
