package com.gome.meidian.grouporder.vo;

import java.io.Serializable;


public class ProductParamInfo extends ProductVo implements Serializable{

	private static final long serialVersionUID = 5054924765490192877L;

	private Double brokerage;			// 佣金
	private Double couponPrice;			// 券后价
	private Coupon coupon;				// 优惠券信息
	private Double buyRebate = 0d;  	// 购买返
	private String rebateId;   			// 返利计划id
	private Integer selfJointRebate;  	// 2：自营返:1：联营返
	private String skuNo;				
	
	public Double getBrokerage() {
		return brokerage;
	}
	public void setBrokerage(Double brokerage) {
		this.brokerage = brokerage;
	}
	public Double getCouponPrice() {
		return couponPrice;
	}
	public void setCouponPrice(Double couponPrice) {
		if(couponPrice != null && couponPrice < 0){
			this.couponPrice = 0D;
		}else{
			this.couponPrice = couponPrice;
		}
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}
	public Double getBuyRebate() {
		return buyRebate;
	}
	public void setBuyRebate(Double buyRebate) {
		this.buyRebate = buyRebate;
	}
	public String getRebateId() {
		return rebateId;
	}
	public void setRebateId(String rebateId) {
		this.rebateId = rebateId;
	}
	public Integer getSelfJointRebate() {
		return selfJointRebate;
	}
	public void setSelfJointRebate(Integer selfJointRebate) {
		this.selfJointRebate = selfJointRebate;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	
	
}
