package com.gome.meidian.grouporder.manager.app;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.coupon.model.cartBean.CouponBatchResult;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.utils.AppGomeShareCodeConstants;
import com.gome.meidian.grouporder.utils.AppShareCodeInfo;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.MD5Util;
import com.gome.meidian.grouporder.utils.QRCodeUtil;
import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.ProductDetailVo;
import com.gome.meidian.grouporder.vo.ProductVo;
import com.gome.meidian.grouporder.vo.app.ShareCardParamVo;
import com.gome.meidian.grouporder.vo.app.ShareCardVo;
import com.gome.meidian.grouporder.vo.product.ProductRequestParam;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebate;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.meidian.grouporder.vo.store.UserInfo;
import com.gome.mobile.common.utils.math.BigDecimalUtils;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gome.stage.interfaces.item.IProductInfoService;
import com.gome.stage.item.GoodsInfo;
import com.gome.sum.client.ShortUrlDubboService;
import com.gome.sum.client.dto.BindShortUrlData;
import com.gome.sum.client.dto.BindShortUrlParam;
import com.gome.sum.client.dto.BindShortUrlResult;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopFacade;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppCarveResource;
import com.gomeplus.bs.interfaces.gorder.vo.carve.CarveShareInfoVo;
import redis.Gcache;



@Service
public class ShareCardManager {
	private Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
    private PageInfoResource pageInfoResource;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Autowired
	private MinTokenManager minTokenManager;
	@Autowired
	private ShortUrlDubboService shortUrlDubboService;
	@Value("${meidian.MinProgram.wxacodeUrl}")
	private String wxacodeUrl;
	@Autowired
	private HttpClientUtil httpClientUtil;
	@Autowired
	private IProductInfoService productInfoService;
	@Autowired
	private GroupOrderManager groupOrderManager;
    @Autowired
    private HomeProductsManager homeProductsManager;
	@Autowired
	private StoreManager storeManager;
	@Autowired
	private GorderInfoForAppCarveResource orderInfoForAppCarveResource;
	@Autowired
	private VshopFacade vshopFacade; 
    /**
     * 获取分享卡片信息
     * @param shareCardParamVo
     * @return
     */
	public ShareCardVo getShareCard(ShareCardParamVo shareCardParamVo,String userId,Integer ppi, Byte ua)throws ServiceException{
		logger.info("shareCardParamVo>>>>>>>>>>>"+JSON.toJSONString(shareCardParamVo)+"#userId:"+userId+"#");
		ShareCardVo  shareCardVo = new ShareCardVo();
		shareCardVo.setPageType(0);
		if(shareCardParamVo !=null){
		  if(!shareCardParamVo.getPageType().equals("2") && !shareCardParamVo.getPageType().equals("11") && (shareCardParamVo.getSkuId() == null || shareCardParamVo.getSkuId().equals(""))){
			  return shareCardVo;
		  }
          if(shareCardParamVo.getPageType().equals("2")){
        	  //活动页2
        	  if(StringUtils.isEmpty(shareCardParamVo.getLandingPage())){
        		  if(StringUtils.isNotEmpty(shareCardParamVo.getPagecode())){
                	  shareCardVo.setPageType(2);
                	  huoDongPage(shareCardVo,shareCardParamVo,userId);
                	  return shareCardVo;
        		  }
        	  }else{
	  			    //更改落地页
	  			  shareCardVo.setShareUrl(shareCardParamVo.getMaterialImages());
	  			  
	  			  getShareCardChangeLandingPage(shareCardVo, shareCardParamVo, userId, ppi,  ua); 
	  			  
	  			  shareCardVo.setPageType(2);
	  			  return shareCardVo;

        	  }
        	  
          }else if(shareCardParamVo.getPageType().equals("3")){
        	  
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getCouponType()) && StringUtils.isNotEmpty(shareCardParamVo.getCouponId()) && StringUtils.isNotEmpty(shareCardParamVo.getPlan_Id())){
        		  //领券中间页 3
        		  shareCardVo.setPageType(3);
        		  this.lingQuanPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }

          }else if(shareCardParamVo.getPageType().equals("4")){
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getCouponType()) && StringUtils.isNotEmpty(shareCardParamVo.getCouponId())){
        		  //领券商品详情4
        		  shareCardVo.setPageType(4);
        		  this.lingQuanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }

          }else if(shareCardParamVo.getPageType().equals("5")){
           	  //超级返商品详情 5
        	  shareCardVo.setPageType(5);
        	  this.chaoJiFanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        	  return shareCardVo;
          }else if(shareCardParamVo.getPageType().equals("6")){
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
        		  //未开团-组团商品详情6
        		  shareCardVo.setPageType(6);
        		  this.zutuanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }
        	  
          }else if(shareCardParamVo.getPageType().equals("7") && StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getGroupId())&&StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
        		  //开团-组团商品详情7
        		  shareCardVo.setPageType(7);
        		  this.zutuanDetailOpenPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }
        	 
          }else if (shareCardParamVo.getPageType().equals("9") ){
    		  //助力团（开团）
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
        		  shareCardVo.setPageType(9);
        		  this.zutuanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }

          }else if (shareCardParamVo.getPageType().equals("10") ){
    		  //万人团（）
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getGroupId())&&StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
        		  shareCardVo.setPageType(7);
        		  this.zutuanDetailOpenPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }

          }else if(shareCardParamVo.getPageType().equals("11") ){
        	  //瓜分团
        	  if(StringUtils.isNotEmpty(shareCardParamVo.getGroupId())&&StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
        		  shareCardVo.setPageType(2);
        		  this.guaFenTuanOpenPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
        		  return shareCardVo;
        	  }
          }
          
          
		}
		return shareCardVo;
	}
	
	/**
	 * 活动页
	 * @param ShareCardVo
	 */
	public void huoDongPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId) throws ServiceException{
		//mid、stid、areaCode、pageCode
		StringBuilder shareCodeParam = new StringBuilder("");
		
		 if(StringUtils.isEmpty(shareCardParamVo.getLandingPage())){
				PageInfo pageInfo = pageInfoResource.selectPageInfo(shareCardParamVo.getPagecode());
				if(pageInfo != null){
					shareCardVo.setShareUrl(pageInfo.getWxShareImg());
				}
		 }else{
			 shareCardVo.setShareUrl(shareCardParamVo.getMaterialImages());
		 }
		shareCodeParam.append("pageCode="+shareCardParamVo.getPagecode());
		shareCodeParam.append("&areaCode="+shareCardParamVo.getAreacode());
		byte[]  shareCodedata = getShareCode(shareCardVo.getPageType().toString(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
	}
	
	/**
	 * 领券中间页
	 * @param ShareCardVo
	 * @param shareCardParamVo
	 * @param userId
	 * @throws ServiceException
	 */
	public void lingQuanPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId, Integer ppi, Byte ua) throws ServiceException{
		//入参areacode ; skuId ; couponId ; plan_Id ; couponType ; 
		//拼参 areaCode、productId、skuId、skuNo、couponId、couponType、plan_id
		StringBuilder shareCodeParam = new StringBuilder("");
		
		if(StringUtils.isNotEmpty(shareCardParamVo.getSkuId()) 
			&& StringUtils.isNotEmpty(shareCardParamVo.getCouponId())
			&& StringUtils.isNotEmpty(shareCardParamVo.getPlan_Id())
			&& StringUtils.isNotEmpty(shareCardParamVo.getCouponType())
				){
			List<String> paramList = new ArrayList<String>();
			paramList.add(shareCardParamVo.getSkuId());
			GoodsInfo goodsInfo = getGoodInfoBySku(paramList);
			// 商品信息
			List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
			ProductRequestParam productRequestParam = new ProductRequestParam(goodsInfo.getProductId(), goodsInfo.getSkuId());
			productRequestParams.add(productRequestParam);
			List<Product> products = groupOrderManager.getPros(productRequestParams, shareCardParamVo.getAreacode(), ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE, ua, null, GroupOrderConstants.PRICE_POLICYID, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
			if(null != products && products.size() > 0){
				Product product = products.get(0);
				shareCardVo.setImgUrl(product.getMainImage());
				shareCardVo.setDesc(product.getName());
				shareCardVo.setProductTag(String.valueOf(product.getProductTag()));
				shareCardVo.setMeidianPrice(getPrice(product.getSalePrice()));
				shareCodeParam.append("areaCode="+shareCardParamVo.getAreacode());
				shareCodeParam.append("&productId="+(product.getId()==null?"":product.getId()));
				shareCodeParam.append("&skuId="+(product.getSkuId()==null?"":product.getSkuId()));
				shareCodeParam.append("&skuNo="+(product.getSkuNo()==null?"":product.getSkuNo()));
				shareCodeParam.append("&couponId="+shareCardParamVo.getCouponId());
				shareCodeParam.append("&couponType="+shareCardParamVo.getCouponType());
				shareCodeParam.append("&plan_id="+shareCardParamVo.getPlan_Id());
			} 
			Coupon cp = new Coupon();
			if (shareCardParamVo.getCouponType().equals(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
				// 根据批次号查询pop劵信息
                CouponBatchResult couponBatchResult = groupOrderManager.getPopCoupon(shareCardParamVo.getCouponId());
				if (null != couponBatchResult) {
					shareCardVo.setCouponNum(couponBatchResult.getDenomination()); // 面额
				}
			} else {
				// 根据券规则ID获取美劵，红蓝券信息
				CouponRuleInfo blueCoupon = groupOrderManager.getCoupon(shareCardParamVo.getCouponId());
				if (null != blueCoupon) {
					shareCardVo.setCouponNum(blueCoupon.getAmount());
				}
			}
			// 劵后价
			double couPrice = DoubleUtils.sub(shareCardVo.getMeidianPrice(), cp.getCoupon_num() == null ? 0 : cp.getCoupon_num());
			if(couPrice < 0)
				couPrice = 0;
			shareCardVo.setCouponPrice(couPrice);
		}else{
			shareCardVo.setPageType(0);
		}
		
		byte[]  shareCodedata = getShareCode(shareCardVo.getPageType().toString(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
		
	}
	
	
	
	/**
	 * 领券商品详情
	 * @param shareCardVo
	 * @param shareCardParamVo
	 * @param userId
	 * @param ppi
	 * @param ua
	 * @throws ServiceException
	 */
	public void lingQuanDetailPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId, Integer ppi, Byte ua) throws ServiceException{
		//入参areacode   skuId ; couponId ; couponType  ; 
		//拼参mid、stid、areaCode、productId、skuId、skuNo、couponPrice、key=couponNum
		StringBuilder shareCodeParam = new StringBuilder("");
		
		if(StringUtils.isNotEmpty(shareCardParamVo.getSkuId()) 
			&& StringUtils.isNotEmpty(shareCardParamVo.getCouponId())
			&& StringUtils.isNotEmpty(shareCardParamVo.getCouponType())
				){
			List<String> paramList = new ArrayList<String>();
			paramList.add(shareCardParamVo.getSkuId());
			GoodsInfo goodsInfo = getGoodInfoBySku(paramList);
			// 商品信息
			List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
			ProductRequestParam productRequestParam = new ProductRequestParam(goodsInfo.getProductId(), goodsInfo.getSkuId());
			productRequestParams.add(productRequestParam);
			List<Product> products = groupOrderManager.getPros(productRequestParams, shareCardParamVo.getAreacode(), ppi, GroupOrderConstants.DETAILS_PRODUCT_IMAGE, ua, null, GroupOrderConstants.PRICE_POLICYID, GroupOrderConstants.MEIDIANPRICE_CHANNEL);
			if(null != products && products.size() > 0){
				Product product = products.get(0);
				shareCardVo.setImgUrl(product.getMainImage());
				shareCardVo.setDesc(product.getName());
				shareCardVo.setProductTag(String.valueOf(product.getProductTag()));
				shareCardVo.setMeidianPrice(getPrice(product.getSalePrice()));
				shareCodeParam.append("areaCode="+shareCardParamVo.getAreacode());
				shareCodeParam.append("&productId="+(product.getId()==null?"":product.getId()));
				shareCodeParam.append("&skuId="+(product.getSkuId()==null?"":product.getSkuId()));
				shareCodeParam.append("&skuNo="+(product.getSkuNo()==null?"":product.getSkuNo()));
				
			} 
			Coupon cp = new Coupon();
			if (shareCardParamVo.getCouponType().equals(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
				// 根据批次号查询pop劵信息
                CouponBatchResult couponBatchResult = groupOrderManager.getPopCoupon(shareCardParamVo.getCouponId());
				if (null != couponBatchResult) {
					shareCardVo.setCouponNum(couponBatchResult.getDenomination()); // 面额
					shareCodeParam.append("&couponPrice="+couponBatchResult.getDenomination());
				}
			} else {
				// 根据券规则ID获取美劵，红蓝券信息
				CouponRuleInfo blueCoupon = groupOrderManager.getCoupon(shareCardParamVo.getCouponId());
				if (null != blueCoupon) {
					shareCardVo.setCouponNum(blueCoupon.getAmount());
					shareCodeParam.append("&couponPrice="+blueCoupon.getAmount());
				}
			}
			// 劵后价
			double couPrice = DoubleUtils.sub(shareCardVo.getMeidianPrice(), cp.getCoupon_num() == null ? 0 : cp.getCoupon_num());
			if(couPrice < 0)
				couPrice = 0;
			shareCardVo.setCouponPrice(couPrice);
		}else{
			shareCardVo.setPageType(0);
		}
		
		byte[]  shareCodedata = getShareCode(shareCardVo.getPageType().toString(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
		
	}
	
	
	/**
	 * 超级返详情页
	 * @param shareCardVo
	 * @param shareCardParamVo
	 * @param userId
	 * @param ppi
	 * @param ua
	 * @throws ServiceException
	 */
	public void chaoJiFanDetailPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId, Integer ppi, Byte ua) throws ServiceException{
		//入参areacode ; skuId   ; 
		//拼参mid、stid、areaCode、skuNo、buyRebate、productId、skuId
		StringBuilder shareCodeParam = new StringBuilder("");
		
		if(StringUtils.isNotEmpty(shareCardParamVo.getSkuId())){
			List<String> paramList = new ArrayList<String>();
			paramList.add(shareCardParamVo.getSkuId());
			GoodsInfo goodsInfo = getGoodInfoBySku(paramList);
			if(goodsInfo != null){
		        //组装数据
		        List<ProductBuyRebate> pList = new ArrayList<>();
		        ProductBuyRebate rebateVo = new ProductBuyRebate(goodsInfo.getProductId(), goodsInfo.getSkuNo(), goodsInfo.getSkuId());
                pList.add(rebateVo);
		        //获取超级返列表信息
		        List<ProductBuyRebateVo> result = homeProductsManager.getProductBuyRebates(pList, shareCardParamVo.getAreacode(), ppi, ua, null, GroupOrderConstants.PRICE_POLICYID);
		        if(result != null && result.size()>0){
		        	ProductBuyRebateVo productBuyRebateVo = result.get(0);
		        	if(productBuyRebateVo != null){
		        		Product product = productBuyRebateVo.getProduct();
		        		if(product != null){
		        			shareCodeParam.append("areaCode="+shareCardParamVo.getAreacode());
		        			shareCodeParam.append("&skuNo="+(product.getSkuNo()==null?"":product.getSkuNo()));
		        			shareCodeParam.append("&buyRebate="+(productBuyRebateVo.getBuyRebate() == null ? "":productBuyRebateVo.getBuyRebate()));
		        			shareCodeParam.append("&productId="+(product.getId()==null?"":product.getId()));
		        			shareCodeParam.append("&skuId="+(product.getSkuId()==null?"":product.getSkuId()));
		        			shareCardVo.setDesc(product.getName());
		        			shareCardVo.setImgUrl(product.getMainImage());
		        			shareCardVo.setProductTag(String.valueOf(product.getProductTag()));
		        			shareCardVo.setMeidianPrice(getPrice(product.getSalePrice()));
		        		}
		        		shareCardVo.setBuyRebate(productBuyRebateVo.getBuyRebate() == null ? 0d : Double.valueOf(productBuyRebateVo.getBuyRebate()));
		        		
		        	}
		        }
			}
		}else{
			shareCardVo.setPageType(0);
		}
		
		byte[]  shareCodedata = getShareCode(shareCardVo.getPageType().toString(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
		
	}
	
	/**
	 * 组团详情(助力、未开团)
	 * @param shareCardVo
	 * @param shareCardParamVo
	 * @param userId
	 * @param ppi
	 * @param ua
	 * @throws ServiceException
	 */
	public void zutuanDetailPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId, Integer ppi, Byte ua) throws ServiceException{
		//入参areacode ; skuId ; activityId ; 
		//拼参mid、stid、areaCode、activityId、skuNo、productId、skuId
		StringBuilder shareCodeParam = new StringBuilder("");
		
		if(StringUtils.isNotEmpty(shareCardParamVo.getSkuId())
				&& StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
			shareCodeParam.append("areaCode="+shareCardParamVo.getAreacode());
			shareCodeParam.append("&activityId="+shareCardParamVo.getActivityId());
			List<String> paramList = new ArrayList<String>();
			paramList.add(shareCardParamVo.getSkuId());
			GoodsInfo goodsInfo = getGoodInfoBySku(paramList);
			if(goodsInfo != null){
				Map<String, Object> map =  groupOrderManager.getProductInfo(Long.valueOf(shareCardParamVo.getActivityId()), null, Long.valueOf(userId), 
						goodsInfo.getProductId(), goodsInfo.getSkuId(), shareCardParamVo.getAreacode(), 
						null, null, ppi, 
						ua, null, null, null);
				ProductDetailVo productDetail = (ProductDetailVo)map.get("data");
				if(productDetail != null){
					ProductVo product = productDetail.getProduct();
					shareCardVo.setDesc(product.getName());
					shareCardVo.setImgUrl(product.getProductImage());
					shareCardVo.setProductTag(product.getProductTag()  == null ? "0" : String.valueOf(product.getProductTag()));
					shareCardVo.setTotalBuyNum(product.getAlreadyGroupOrderNumber() == null ? 0: Long.valueOf(product.getAlreadyGroupOrderNumber().intValue()));
					shareCardVo.setPrice(product.getPrice());
					shareCardVo.setMeidianPrice(product.getMeidianPrice()==null ? 0 :Double.valueOf(product.getMeidianPrice()));
					shareCardVo.setMaxDiscountPeopleNum(product.getMaxDiscountNeedPeopleNum() == null ? 0:Long.valueOf(product.getMaxDiscountNeedPeopleNum().intValue()));
					shareCardVo.setBuyRebate(product.getRebateAmount());
					//助力团取另外字段
					if(product.getHelpAllow() != null && product.getHelpAllow().intValue() == 1){
						if(product.getInitialMaxMoney() != null && !product.getInitialMaxMoney().equals("")){
							shareCardVo.setBuyRebate(Double.valueOf(product.getInitialMaxMoney()));
						}else{
							shareCardVo.setBuyRebate(0d);
						}
						//如果美店价取不到，两个价格 都是 国美价，如果取到 两个价格都是美店价   2019.12.10
						if(product.getMeidianPrice()==null){
							shareCardVo.setPrice(product.getPrice());
							shareCardVo.setMeidianPrice(product.getPrice());
						}else{
							shareCardVo.setPrice(Double.valueOf(product.getMeidianPrice()));
							shareCardVo.setMeidianPrice(Double.valueOf(product.getMeidianPrice()));
						}
						
					}

					shareCodeParam.append("&skuNo="+product.getSkuNo());
					shareCodeParam.append("&productId="+product.getProductId());
					shareCodeParam.append("&skuId="+product.getSkuId());
				}
				
			}
		}else{
			shareCardVo.setPageType(0);
		}
		
		byte[]  shareCodedata = getShareCode(shareCardVo.getPageType().toString(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
		
	}
	
	
	/**
	 * 组团详情(助力、未开团)
	 * @param shareCardVo
	 * @param shareCardParamVo
	 * @param userId
	 * @param ppi
	 * @param ua
	 * @throws ServiceException
	 */
	public void zutuanDetailOpenPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId, Integer ppi, Byte ua) throws ServiceException{
		//入参areaCode ; skuId ; activityId ; groupId; 
		//拼参mid、stid、areaCode、productId、skuNo、skuId、activityId、tuanId、groupId
		StringBuilder shareCodeParam = new StringBuilder("");
		
		if(StringUtils.isNotEmpty(shareCardParamVo.getSkuId())
				&& StringUtils.isNotEmpty(shareCardParamVo.getActivityId())
				//&& StringUtils.isNotEmpty(shareCardParamVo.getGroupId())
				){
			shareCodeParam.append("areaCode="+shareCardParamVo.getAreacode());
			shareCodeParam.append("&activityId="+shareCardParamVo.getActivityId());
			List<String> paramList = new ArrayList<String>();
			paramList.add(shareCardParamVo.getSkuId());
			GoodsInfo goodsInfo = getGoodInfoBySku(paramList);
			if(goodsInfo != null){
				Map<String, Object> map =  groupOrderManager.getProductInfo(Long.valueOf(shareCardParamVo.getActivityId()), null, Long.valueOf(userId), 
						goodsInfo.getProductId(), goodsInfo.getSkuId(), shareCardParamVo.getAreacode(), 
						null, null, ppi, 
						ua, null, null, null);
				ProductDetailVo productDetail = (ProductDetailVo)map.get("data");
				if(productDetail != null){
					ProductVo product = productDetail.getProduct();
					shareCardVo.setDesc(product.getName());
					shareCardVo.setImgUrl(product.getProductImage());
					shareCardVo.setProductTag(product.getProductTag()  == null ? "0" : String.valueOf(product.getProductTag()));
					shareCardVo.setTotalBuyNum(product.getAlreadyGroupOrderNumber() == null ? 0: Long.valueOf(product.getAlreadyGroupOrderNumber().intValue()));
					shareCardVo.setPrice(product.getPrice());
					shareCardVo.setMeidianPrice(product.getMeidianPrice()==null ? 0 :Double.valueOf(product.getMeidianPrice()));
					shareCardVo.setMaxDiscountPeopleNum(product.getMaxDiscountNeedPeopleNum() == null ? 0:Long.valueOf(product.getMaxDiscountNeedPeopleNum().intValue()));
					shareCardVo.setBuyRebate(product.getRebateAmount());
					shareCodeParam.append("&skuNo="+product.getSkuNo());
					shareCodeParam.append("&productId="+product.getProductId());
					shareCodeParam.append("&skuId="+product.getSkuId());
					shareCodeParam.append("&groupId="+(shareCardParamVo.getGroupId() == null ? "" : shareCardParamVo.getGroupId()));
					String kid = "TUAN_" + shareCardParamVo.getGroupId() + "_" + "isPay" + "_skuId" + "_" + product.getSkuId();
					shareCodeParam.append("&tuanId="+kid);
				}
				
			}
		}else{
			shareCardVo.setPageType(0);
		}
		
		byte[]  shareCodedata = getShareCode(shareCardVo.getPageType().toString(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
		
	}
	
	
	/**
	 * 瓜分团
	 * @param shareCardVo
	 * @param shareCardParamVo
	 * @param userId
	 * @param ppi
	 * @param ua
	 * @throws ServiceException
	 */
	public void guaFenTuanOpenPage(ShareCardVo shareCardVo, ShareCardParamVo shareCardParamVo,String userId, Integer ppi, Byte ua) throws ServiceException{
		//入参areaCode ; activityId ; groupId; 
		//拼参areaCode#groupId#zlUserId
		StringBuilder shareCodeParam = new StringBuilder("");
		
		if(StringUtils.isNotEmpty(shareCardParamVo.getActivityId())
				&& StringUtils.isNotEmpty(shareCardParamVo.getGroupId())){
			shareCodeParam.append("areaCode="+shareCardParamVo.getAreacode());
			shareCodeParam.append("&groupId="+shareCardParamVo.getGroupId());
				CommonResultEntity<CarveShareInfoVo> commonResultEntity = orderInfoForAppCarveResource.getCarveShareInfo(Long.valueOf(shareCardParamVo.getGroupId()),Long.valueOf(shareCardParamVo.getActivityId()));
				
				if(commonResultEntity != null && commonResultEntity.getCode() == 0){
					CarveShareInfoVo carveShareInfoVo = commonResultEntity.getBusinessObj();
					if(carveShareInfoVo != null){
						shareCardVo.setShareUrl(carveShareInfoVo.getFriendImageUrl());
						shareCardVo.setFriendSubImageUrl(carveShareInfoVo.getFriendSubImageUrl());
						Long headerUserId = carveShareInfoVo.getHeaderUserId();
						if(headerUserId != null ){
							shareCodeParam.append("&zlUserId="+carveShareInfoVo.getHeaderUserId().toString());
						}else{
							shareCodeParam.append("&zlUserId=");
						}
						
					}
					shareCardVo.setPageType(2);
				}else{
					shareCardVo.setPageType(0);
				}
		}else{
			shareCardVo.setPageType(0);
		}
		
		byte[]  shareCodedata = getShareCode(shareCardParamVo.getPageType(),shareCodeParam.toString(),userId,shareCardVo,shareCardParamVo);
		if(shareCodedata != null){
	    	Base64.Encoder encoder = Base64.getEncoder();
	    	try {
				String newParams = new String(encoder.encode(shareCodedata),"UTF-8");
				shareCardVo.setShareCodedata(newParams);
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Base64.encode error");;
			}
		}
		
	}
	
	
	
	/**
	 * 商品信息
	 * @param skuId
	 * @return
	 */
	public GoodsInfo getGoodInfoBySku(List<String> paramList){
		GoodsInfo goodsInfo = null;
		List<GoodsInfo>  list = productInfoService.getGoodsInfos(paramList,"210");
		if(list != null && list.size()>0){
			goodsInfo = list.get(0);
		}
		return goodsInfo;
	}
	
	/**
	 * 获取分享码
	 * @param pageCode
	 * @param params
	 * @return
	 * @throws ServiceException 
	 */
	public byte[] getShareCode(String pageCode,String newParams,String s_userId,ShareCardVo shareCardVo,ShareCardParamVo shareCardParamVo) throws ServiceException{
		byte[] data = null;
		//取生成分享码的类型
		String shareCodeType = GroupOrderConstants.CHANNEL_MINI;
		
		AppShareCodeInfo appShareCodeInfo = AppGomeShareCodeConstants.pageUrlMap.get("sharePage"+pageCode);
		//取不到配置信息
		if(appShareCodeInfo == null){
			pageCode = "1";//首页
			appShareCodeInfo = AppGomeShareCodeConstants.pageUrlMap.get("sharePage"+pageCode);
		}
		String wapPageUrl = appShareCodeInfo.getWapUrl();
		String minPageUrl = appShareCodeInfo.getMinUrl();

		//1、判断生成的分享码类型  //2、获取url//3、拼接参数 //4、生成分享码
		if(shareCodeType.equals(GroupOrderConstants.CHANNEL_WAP)){
			SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat s1=new SimpleDateFormat("yyyyMMdd");
			//取时间戳
			Calendar c = Calendar.getInstance();
			String str1=s1.format(c.getTime());
			//计算失效时间
			c.add(Calendar.DATE, 60);//计算60天后的时间 生产
			//c.add(Calendar.MINUTE, 5);//计算五分钟后的时间
			String str2=s.format(c.getTime());
			//System.out.println("60天后的时间是："+str2);
			
			StringBuilder sb = new StringBuilder("");
			sb.append(wapPageUrl).append("?").append("ex=").append(str1);
			//拼接分享参数
			Map<String,String> paramMap = getUseparam(newParams,appShareCodeInfo.getWapParams());
			newParams = paramMap.get("useParam");
			String mid = paramMap.get("mid");
			if(newParams !=null && !newParams.equals("")){
				sb.append("&").append(newParams);
			}
			sb.append("&").append("mid="+mid);

			String longUrl = sb.toString();
			String shortUrl = getShortUrl(longUrl,str2);
			data = getWapCode(shortUrl,null);
		}else if(shareCodeType.equals(GroupOrderConstants.CHANNEL_MINI)){
						
			//s_userId分享人Id
			// 美店主id，（mid）
			String mid = "";
			if(!StringUtils.isEmpty(s_userId)){
				try{
					CommonResultEntity<VshopInfo> common = vshopFacade.queryVshopByuserId(s_userId);
					VshopInfo vshopInfo = common.getBusinessObj();
					if(null != vshopInfo){
						mid = String.valueOf(vshopInfo.getVshopId());
					}
				}catch(Exception e){
					logger.error("getShareCode error  == >> vshopFacade.queryVshopByuserId !userId=" + s_userId, e);
					mid = "";
				}

			}
			

			//获取门店信息
			String stid = "";
			UserInfo userInfo = storeManager.getUserInfo(Long.valueOf(s_userId));
			if(null != userInfo){
				if(userInfo.getStoreCode() != null){
					stid = userInfo.getStoreCode();
					
					if(shareCardParamVo.getPageType().equals("2")){  //模板为 2
						Store store = storeManager.getStoreInfo(stid, 0);
						if(store != null && !StringUtils.isEmpty(store.getLogo())){
							shareCardVo.setFriendSubImageUrl(store.getLogo());
						}
					}
					
				}
			}
			//拼接分享参数
			Map<String,String> paramMap = getUseparam(newParams,appShareCodeInfo.getMinParams());
			newParams=paramMap.get("useParam");
			String key = "";
			if(!StringUtils.isEmpty(newParams)){
				//System.err.println("newParams>>>>>>>>>>>>>>>>>"+newParams);
				newParams = newParams + "&uid=" + s_userId + "&stid=" + stid + "&mid=" +mid;
				key = MD5Util.getMD5(newParams, false, 16);
				//gcache.setex("minShareCodeKey_"+key, 60 * 24 * 3600, newParams);//生产
				gcache.setex("minShareCodeKey_"+key, 60 * 24 * 3600, newParams);//测试
				//gcache.setex("minShareCodeKey_"+key, 5 * 60, newParams);
			}
			//System.err.println("小程序参数>>>>>>>>>>>>>>>>>"+"param="+key);
			shareCardVo.setKey(key);
			//data = getMinProgramCode("p="+key,minPageUrl,minTokenManager.getToken());	
			data = getMinProgramCode(key,minPageUrl,minTokenManager.getToken());	
			
			
		}
		return data;
	}
	
	
	
	/**
	 * 根据入参和定义的参数 生成有效的分享参数
	 * @param urlParam
	 * @param shareParam
	 * @return
	 */
	private Map<String,String> getUseparam(String urlParam,String shareParam){
		Map<String,String> map = new HashMap<String,String>();
		map.put("useParam", "");
		map.put("mid", "");
		if(urlParam == null || urlParam.equals("")){
			return map;
		}
		if(shareParam == null || shareParam.equals("")){
			return map;
		}
		
		String [] urlParams = urlParam.split("&");
		Map<String,String> paramMap = new HashMap<String,String>();
			for(String param : urlParams ){
				String[] keyValues = param.trim().split("=");
				if(keyValues != null && keyValues.length>0){
					String key = keyValues[0];
					String value= keyValues.length > 1 ? keyValues[1] : null;
					if(!StringUtils.isEmpty(key.trim())){
						paramMap.put(key, value);
					}
					
				}
			}
		StringBuilder sb = new StringBuilder("");	
		String [] shareParams = shareParam.split("#");
		for(String sharePa : shareParams){
			String value = paramMap.get(sharePa);
			if(value != null && sharePa.equals("mid")){
				if(!StringUtils.isEmpty(value)){
					map.put("mid", value);
				}
			}else{
				sb.append(sharePa).append("=");
				if(!StringUtils.isEmpty(value)){
					sb.append(value);
				}
				sb.append("&");
			}

		}
		if(sb.length()>0){
			sb.deleteCharAt(sb.length()-1);
		}
		
		map.put("useParam", sb.toString());
		return map;
	}
	
	/**
	 * 生成短链接
	 * @param longUrl
	 * @param expireDate
	 * @return
	 */
	public String getShortUrl(String longUrl, String expireDate) {
		String shortUrl = null;
		// 1:需要二维码，2：不需要二维码
		BindShortUrlData bindShortUrlData = urlSwitch(longUrl, DateUtils.strDate(expireDate), null);
		if (null != bindShortUrlData) {
			shortUrl = bindShortUrlData.getShortUrl();
		}
		return shortUrl;
	}

	
	/**
	 * 生成美店wap分享码
	 * @param text 短域名
	 * @param logoImgPath
	 * @return
	 */
	public byte[] getWapCode(String text,String logoImgPath){
		BufferedImage image = null;
		byte[] data = null;
		try {
			image = QRCodeUtil.createImage(text, logoImgPath, true);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			boolean flag = ImageIO.write(image, "gif", out);
			if(!flag){
				return null;
			}
			data = out.toByteArray();
		} catch (Exception e) {
			logger.error("getWapCode ==> text=={}", text);
			e.printStackTrace();
		}
        return data;
	}
	
	/**
	 * 生成短链接
	 * @param longUrl
	 * @param expireDate
	 * @param codeFlag
	 * @return
	 */
	public BindShortUrlData urlSwitch(String longUrl, Date expireDate, String codeFlag){
		BindShortUrlParam shortUrlParam = new BindShortUrlParam();
		shortUrlParam.setLongUrl(longUrl);
		shortUrlParam.setExpireDate(expireDate);
		shortUrlParam.setQrCodeFlag(codeFlag);
		BindShortUrlResult<BindShortUrlData> result = shortUrlDubboService.bindShortUrl(shortUrlParam);
		if(null == result) return null;
		if(!result.getSuccess()){
			logger.error("urlSwitch ==> errorMsg=={}", result.getErrMsg());
			return null;
		}
		
		return result.getData();
	}
	
    /**
     * 生成美店小程序分享码
     * @param sceneStr
     * @param pageUrl
     * @param accessToken
     * @return
     * @throws ServiceException
     */
	public byte[] getMinProgramCode(String sceneStr,String pageUrl, String accessToken) throws ServiceException{
		if(accessToken == null){
			return null;
		}
		String url = wxacodeUrl+"?access_token=" + accessToken;
		com.alibaba.fastjson.JSONObject paramJson = new com.alibaba.fastjson.JSONObject();
		paramJson.put("scene", sceneStr);
		//paramJson.put("page", "pages/index/index");//pageUrl
		paramJson.put("page", pageUrl);//pageUrl
		paramJson.put("width", 200);
		paramJson.put("auto_color", true);
		byte[] inputStream =null;
		inputStream = httpClientUtil.doPostStream(url, paramJson);
//		saveToImgByInputStream(inputStream, "D:", "1.png");
		return inputStream;
	}
	
	/**
	 * 价格单位转换
	 * 
	 * @param price
	 * @return
	 */
	public double getPrice(Long price) {
		if (price == null) {
			price = 0L;
		}

		return BigDecimalUtils.div(price.doubleValue(), 100d, 2);
	}
	
	/**
	 * 根据前端传来的落地页参数更改落地页参数
	 * @param shareCardParamVo
	 * @param userId
	 * @param ppi
	 * @param ua
	 * @return
	 * @throws ServiceException
	 */
	public ShareCardVo getShareCardChangeLandingPage(ShareCardVo  shareCardVo, ShareCardParamVo shareCardParamVo,String userId,Integer ppi, Byte ua)throws ServiceException{
	    //更改落地页参数
		shareCardVo.setPageType(Integer.valueOf(shareCardParamVo.getLandingPage()));
		if(shareCardParamVo.getLandingPage().equals("2")){
	    	
	    	if(StringUtils.isNotEmpty(shareCardParamVo.getPagecode())){
		    	huoDongPage(shareCardVo,shareCardParamVo,userId);
		    	 return shareCardVo;
	    	}

	    	
	    }else if(shareCardParamVo.getLandingPage().equals("3")){
      	  
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getCouponType()) && StringUtils.isNotEmpty(shareCardParamVo.getCouponId()) && StringUtils.isNotEmpty(shareCardParamVo.getPlan_Id())){
      		  //领券中间页 3
      		  this.lingQuanPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		  return shareCardVo;
      	  }

        }else if(shareCardParamVo.getLandingPage().equals("4")){
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getCouponType()) && StringUtils.isNotEmpty(shareCardParamVo.getCouponId())){
      		  //领券商品详情4
      		  this.lingQuanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		  return shareCardVo;
      	  }

        }else if(shareCardParamVo.getLandingPage().equals("5")){
         	  //超级返商品详情 5
      	  this.chaoJiFanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      	  return shareCardVo;
        }else if(shareCardParamVo.getLandingPage().equals("6")){
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
      		  //未开团-组团商品详情6
      		  this.zutuanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		return shareCardVo;
      	  }
      	  
        }else if(shareCardParamVo.getLandingPage().equals("7") && StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getGroupId())&&StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
      		  //开团-组团商品详情7
      		  this.zutuanDetailOpenPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		  return shareCardVo;
      	  }
      	 
        }else if (shareCardParamVo.getLandingPage().equals("9") ){
  		  //助力团（开团）
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
      		  this.zutuanDetailPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		  return shareCardVo;
      	  }

        }else if (shareCardParamVo.getLandingPage().equals("10") ){
  		  //万人团（）
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
      		  this.zutuanDetailOpenPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		  return shareCardVo;
      	  }

        }else if(shareCardParamVo.getLandingPage().equals("11") ){
      	  //瓜分团
      	  if(StringUtils.isNotEmpty(shareCardParamVo.getGroupId())&&StringUtils.isNotEmpty(shareCardParamVo.getActivityId())){
      		  this.guaFenTuanOpenPage(shareCardVo, shareCardParamVo, userId, ppi, ua);
      		  return shareCardVo;
      	  }
        }
		
		return null;
	}
	
	
}
