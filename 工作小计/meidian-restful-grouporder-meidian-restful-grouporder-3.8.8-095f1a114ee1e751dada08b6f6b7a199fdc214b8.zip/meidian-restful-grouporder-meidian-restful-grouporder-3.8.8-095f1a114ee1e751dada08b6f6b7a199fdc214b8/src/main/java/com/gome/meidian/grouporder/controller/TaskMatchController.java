package com.gome.meidian.grouporder.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.TaskMatchManager;
import com.gome.meidian.grouporder.vo.register.TaskMatchPageVo;
import com.gome.meidian.grouporder.vo.register.TaskMatchVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@Validated
@RequestMapping("/taskMatch")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class TaskMatchController {
	
	@Autowired
	private TaskMatchManager taskMatchManager;
	
	/**
	 * 获取奖赛活动信息
	 * @param taskMatchVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/getTaskMatchInfo")
	public ResponseJson getTaskMatchInfo(@Valid @RequestBody TaskMatchVo taskMatchVo) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		Map<String, Object> map = taskMatchManager.getTaskMatchInfo(taskMatchVo);
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 用户是否已经报名该活动
	 * @param taskMatchVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/checkUserSignUp")
	public ResponseJson checkUserSignUp(@Valid @RequestBody TaskMatchVo taskMatchVo,@CookieValue(value="SCN",required=true) String scn) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		Map<String, Object> map = taskMatchManager.checkUserSignUp(taskMatchVo,scn);
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 店主奖赛活动报名
	 * @param taskMatchVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/signUpTaskMatch")
	public ResponseJson signUpTaskMatch(@Valid @RequestBody TaskMatchVo taskMatchVo,@CookieValue(value="SCN",required=true) String scn) throws MeidianException {
		return taskMatchManager.signUpTaskMatch(taskMatchVo,scn);
	}
	
	/**
	 * 个人销售额排行数据
	 * @param taskMatchVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/getOwnTaskPaySort")
	public ResponseJson getOwnTaskPaySort(@Valid @RequestBody TaskMatchVo taskMatchVo,@CookieValue(value="SCN",required=true) String scn) throws MeidianException {
		return taskMatchManager.getOwnTaskPaySort(taskMatchVo,scn);
	}
	
	/**
	 * 获取各类型奖赛排行数据
	 * @param taskMatchPageVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/getTaskSortData")
	public ResponseJson getTaskSortData(@Valid @RequestBody TaskMatchPageVo taskMatchPageVo) throws MeidianException {
		return taskMatchManager.getTaskSortData(taskMatchPageVo);
	}
	
}
