package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
/**
 * 推荐商品信息
 * @author lishouxu-ds
 *
 */
public class RecProductInfoVo implements Serializable{
	private static final long serialVersionUID = 3324377587034891841L;
	private Long activityId; //活动id
	private Integer irrigationNumbe; //灌水倍数
	private Float maxDiscount;//最大折扣
	private Integer maxDiscountNeedPeopleNum;//最大折扣需要的人数
	private String productId;//商品Id
	private String skuId;//skuId
	private String name;//商品名称
	private String shopId;//门店Id
	private String productImage;//图片url
	private Integer productTag;// 0自营 1联营
	private Double price;//价格
	private Integer productStatus; //商品状态
	private Integer salesVolume; //销量(已团多少件)
	private Double rebateAmount;//折扣金额
	private String skuNo;//skuNo
	private String priceType;	// 价格类型
	
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public Integer getMaxDiscountNeedPeopleNum() {
		return maxDiscountNeedPeopleNum;
	}
	public void setMaxDiscountNeedPeopleNum(Integer maxDiscountNeedPeopleNum) {
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Integer getProductTag() {
		return productTag;
	}
	public void setProductTag(Integer productTag) {
		this.productTag = productTag;
	}
	public Integer getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(Integer productStatus) {
		this.productStatus = productStatus;
	}
	public Integer getSalesVolume() {
		return salesVolume;
	}
	public void setSalesVolume(Integer salesVolume) {
		this.salesVolume = salesVolume;
	}
	public Double getRebateAmount() {
		return rebateAmount;
	}
	public void setRebateAmount(Double rebateAmount) {
		this.rebateAmount = rebateAmount;
	}
	public Integer getIrrigationNumbe() {
		return irrigationNumbe;
	}
	public void setIrrigationNumbe(Integer irrigationNumbe) {
		this.irrigationNumbe = irrigationNumbe;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public Float getMaxDiscount() {
		return maxDiscount;
	}
	public void setMaxDiscount(Float maxDiscount) {
		this.maxDiscount = maxDiscount;
	}
	public String getPriceType() {
		return priceType;
	}
	public void setPriceType(String priceType) {
		this.priceType = priceType;
	}
	
	

}
