package com.gome.meidian.grouporder.manager.mshopUserManager;

import com.gome.architect.risk.dto.RequestV2;
import com.gome.loom.facade.ISendSmsFacade;
import com.gome.loom.model.TpModel;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.common.MeidianMemberService;
import com.gome.meidian.grouporder.common.MeidianRiskService;
import com.gome.meidian.grouporder.manager.UserAndRegisterRiskSwitchManager;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.utils.*;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.CommonVariableVo;
import com.gome.meidian.grouporder.vo.mshopUserVo.QuickLoginVo;
import com.gome.meidian.grouporder.vo.register.UserInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.manager.IUserInfoManager;
import com.gome.meidian.user.manager.IUserRoleManager;
import com.gome.userCenter.facade.login.IQuickLoginFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gome.userCenter.model.UserLoginResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sunxueyan-ds
 * @Title: QuickLoginManager
 * @ProjectName meidian-restful-grouporder
 * @Description: TODO
 * @date 2018/11/29 17:20
 */
@Slf4j
@Service
public class QuickLoginManager {

    @Autowired
    private ISendSmsFacade sendFacade;
    @Autowired
    private IQuickLoginFacade iQuickLoginFacade;
    @Autowired
    private MeidianRiskService meidianRiskService;
    @Autowired
    private MeidianMemberService meidianMemberService;

    @Resource(name = "userCenter")
    private Gcache userCenter;

    @Resource(name = "venusVshop")
    private Gcache venusVshopGcache;

    @Autowired
    private IUserInfoManager iUserInfoManager;

    @Autowired
    private IUserRoleManager iUserRoleManager;
    @Autowired
    private WechatLoginManager wechatLoginManager;

    @Value("${cookie.path}")
    private String path;

    @Value("${cookie.domain}")
    private String domain;

    @Value("${cookie.time}")
    private int time;

    /**
     * 检查手机号是否存在
     * @param userInfoVo
     * @return
     */
    public void checkMobile(UserInfoVo userInfoVo) throws MeidianException {
        log.info("检验手机号是否注册,检验手机号为:", userInfoVo.getMobile());
        //手机号合法校验
        boolean checkStatus = MobileUtils.isPhone(userInfoVo.getMobile());
        if(!checkStatus){
            throw new ServiceException("base.user.mobile.noCheck");
        }else{
            //手机号是否存在
            boolean status = meidianMemberService.existUser(userInfoVo.getMobile());
            if(!status){
                throw new ServiceException("base.user.mobile.isNotExit");
            }
        }
    }

    /**
     * 检查手机号是否存在 + 注册
     * @param userInfoVo
     * @return
     */
    public boolean checkMobileAndRegist(UserInfoVo userInfoVo) throws MeidianException {
        log.info("检验手机号是否注册,检验手机号为:", userInfoVo.getMobile());
        //手机号合法校验
        boolean checkStatus = MobileUtils.isPhone(userInfoVo.getMobile());
        if(!checkStatus){
            throw new ServiceException("base.user.mobile.noCheck");
        }else{
            //手机号是否存在
            boolean status = meidianMemberService.existUser(userInfoVo.getMobile());
            return status;
        }
    }


    public ResponseJson quickLogin(QuickLoginVo quickLoginVo, String invokeFrom, RequestParams requestParams, Map<String,Object> map, HttpServletResponse response) {
        ResponseJson responseJson = new ResponseJson();
        String SCN = null;
        String id = null;
        UserLoginResult<UnifyUserInfoExt> unifyUserInfoExtUserLoginResult = iQuickLoginFacade.quickLogin(quickLoginVo.getMobile(), invokeFrom, requestParams, map);

        if (unifyUserInfoExtUserLoginResult != null && unifyUserInfoExtUserLoginResult.isSuccess()) {
            Map<String, Object> resultMap = new HashMap<>();
            if (unifyUserInfoExtUserLoginResult.getBuessObj() != null)
                resultMap.put("UnifyUserInfoExt", unifyUserInfoExtUserLoginResult.getBuessObj());
            if(null != unifyUserInfoExtUserLoginResult.getExtraInfoMap() && unifyUserInfoExtUserLoginResult.getExtraInfoMap().size()>0){
                SCN = (String)unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("SCN");
                try {
                    SCN = URLEncoder.encode(SCN,"UTF-8");
                } catch (UnsupportedEncodingException e) {
                    log.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",SCN,e);
                }
            }
            resultMap.put("isMobileActived", unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("isMobileActived"));
            resultMap.put("identifyLevel", unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("identifyLevel"));
            resultMap.put("SCN", SCN);
            
            String userId = unifyUserInfoExtUserLoginResult.getBuessObj().getId();

            AuthencationVo userInfo = wechatLoginManager.getAutencationVo(userId);
            resultMap.put("userInfo", userInfo);
            
            //写COOKIE
            if(StringUtils.isNotBlank(SCN)){
                CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
                CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID, id,path,domain,time);
            }
            //添加用户记录
            if(null != unifyUserInfoExtUserLoginResult.getBuessObj().getId()){
                LoginRecordThread thread= new LoginRecordThread(unifyUserInfoExtUserLoginResult.getBuessObj().getId(), quickLoginVo.getCreateType(),"2", userCenter, venusVshopGcache, iUserInfoManager, iUserRoleManager);
                ThreadPoolManager.newInstance().addExecuteTask(thread);
            }

            responseJson.setData(resultMap);
            responseJson.setCode(0);
            responseJson.setMsg(unifyUserInfoExtUserLoginResult.getMessage());
        } else if (unifyUserInfoExtUserLoginResult != null && !unifyUserInfoExtUserLoginResult.isSuccess()) {
            responseJson.setCode(-2);
            responseJson.setMsg(unifyUserInfoExtUserLoginResult.getMessage());
            Map<String, Object> resultMap = new HashMap<>();
            if(null != unifyUserInfoExtUserLoginResult.getExtraInfoMap() && unifyUserInfoExtUserLoginResult.getExtraInfoMap().size()>0){
                SCN = (String)unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("SCN");
                try {
                    SCN = URLEncoder.encode(SCN,"UTF-8");
                } catch (UnsupportedEncodingException e) {
                    log.error("doSNSLogin-URLEncoder  SCN：{} ,e:{}",SCN,e);
                }
            }
            if (unifyUserInfoExtUserLoginResult.getBuessObj() != null)
                resultMap.put("UnifyUserInfoExt", unifyUserInfoExtUserLoginResult.getBuessObj());
            resultMap.put("isMobileActived", unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("isMobileActived"));
            resultMap.put("identifyLevel", unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("identifyLevel"));
            resultMap.put("SCN", unifyUserInfoExtUserLoginResult.getExtraInfoMap().get("SCN"));
            //写COOKIE
            if(StringUtils.isNotBlank(SCN)){
                CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,SCN,path,domain,time);
                CookieUtils.setCookie(response,CookieUtils.COOKIE_MSHOP_USER_ID, id,path,domain,time);
            }
            responseJson.setData(resultMap);
        } else {
            responseJson.setCode(-1);
            responseJson.setMsg("手机号快登请求异常!");
        }
        return responseJson;
    }


    /**
     *  发送短信验证码
     * @param mobile
     */
    public boolean sendSms(String mobile, HttpServletRequest request) throws MeidianException {

        //短信风控

        String riskStatus=userCenter.get(UserAndRegisterRiskSwitchManager.RISK_SWITCH_WAP_MEIDIAN_LOGIN_SMS);
        if(null!=riskStatus&& WechatLoginManager.RESULT_SUCCESS_NO.equals(riskStatus)){
            //当标识不是null 或者 false的时候,风控降级
        }else{
            //null or true 使用短信风控
            RequestV2 requestV2 = new RequestV2();
            requestV2.setBizNo(CommonVariableVo.sms_login_bizNo);//美店短信防刷风控
            requestV2.setUserId(mobile);
            requestV2.setPhone(mobile);
            meidianRiskService.predict(requestV2,request);

        }

        TpModel tpModel = new TpModel(CommonVariableVo.BusinessName_quick, CommonVariableVo.BusinessId_quick);
        tpModel.setPhone(mobile);
        return meidianMemberService.sendSms(tpModel);
    }
    /**
     *  校验短信验证码
     * @param quickLoginVo
     */
    public boolean checkCode(QuickLoginVo quickLoginVo) throws MeidianException{

        return meidianMemberService.checkVcode(CommonVariableVo.BusinessName_quick, quickLoginVo.getMobile(), quickLoginVo.getCode(), Boolean.TRUE);
    }


    /**
     * 短信防刷
     * @param quickLoginVo
     * @param request
     * @throws MeidianException
     */
    public void smsPredict(QuickLoginVo quickLoginVo, HttpServletRequest request) throws MeidianException{
        //短信风控
        RequestV2 requestV2 = new RequestV2();
        requestV2.setBizNo(CommonVariableVo.sms_login_bizNo);//美店短信防刷风控
        requestV2.setUserId(quickLoginVo.getMobile());
        requestV2.setPhone(quickLoginVo.getMobile());
        meidianRiskService.predict(requestV2,request);
    }

}
