package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.ActivityPage;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.product.ProductInfo;

/**
 * 首页组团列表
 * @author shichangjian
 *
 */
public class ProductGroupInfoVo implements Serializable{

	private static final long serialVersionUID = 5460793352791020772L;

	private ProductInfo productInfo;			// 商品信息
	private HomePageActivity homePageActivity;	// 活动信息
	private HomeGroupProductActivityPage homeGroupProductActivityPage; // 专题活动页信息
	
	public ProductInfo getProductInfo() {
		return productInfo;
	}
	public void setProductInfo(ProductInfo productInfo) {
		this.productInfo = productInfo;
	}
	public HomePageActivity getHomePageActivity() {
		return homePageActivity;
	}
	public void setHomePageActivity(HomePageActivity homePageActivity) {
		this.homePageActivity = homePageActivity;
	}
	public HomeGroupProductActivityPage getHomeGroupProductActivityPage() {
		return homeGroupProductActivityPage;
	}
	public void setHomeGroupProductActivityPage(HomeGroupProductActivityPage homeGroupProductActivityPage) {
		this.homeGroupProductActivityPage = homeGroupProductActivityPage;
	}
	
	
	
	
	
	
	
}
