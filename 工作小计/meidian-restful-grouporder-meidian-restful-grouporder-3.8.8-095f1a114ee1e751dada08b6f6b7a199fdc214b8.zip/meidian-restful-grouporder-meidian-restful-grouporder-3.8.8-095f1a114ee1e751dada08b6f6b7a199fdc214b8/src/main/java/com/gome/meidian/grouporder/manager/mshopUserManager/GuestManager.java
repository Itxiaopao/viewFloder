package com.gome.meidian.grouporder.manager.mshopUserManager;

import java.awt.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gome.meidian.grouporder.utils.ImageUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.coo8.common.util.date.DateUtils;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.entity.AwardVo;
import com.gome.meidian.entity.MyGradesVo;
import com.gome.meidian.entity.OrderInfo;
import com.gome.meidian.entity.OrderListParam;
import com.gome.meidian.entity.ResultEntity;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.vo.shopkeeper.AwardInfo;
import com.gome.meidian.grouporder.vo.shopkeeper.ChannelUserInfo;
import com.gome.meidian.grouporder.vo.shopkeeper.GuestCount;
import com.gome.meidian.grouporder.vo.shopkeeper.GuestInfo;
import com.gome.meidian.grouporder.vo.shopkeeper.MyAwardInit;
import com.gome.meidian.grouporder.vo.shopkeeper.MyFootprintVo;
import com.gome.meidian.grouporder.vo.shopkeeper.MyGuestInit;
import com.gome.meidian.grouporder.vo.shopkeeper.UserFootprintInfo;
import com.gome.meidian.grouporder.vo.shopkeeper.UserFootprintInit;
import com.gome.meidian.grouporder.vo.shopkeeper.UserSimpleInfo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.service.INewOrderService;
import com.gome.meidian.user.dto.MShopOwnerInfoDto;
import com.gome.meidian.user.dto.MShopPerformanceDto;
import com.gome.meidian.user.dto.MShopWeChatInfo;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MeidianVshopSummaryDto;
import com.gome.meidian.user.dto.UserAuthDto;
import com.gome.meidian.user.manager.IMShopOwnerInfoManager;
import com.gome.meidian.user.manager.IMShopShareRecordManager;
import com.gome.meidian.user.manager.IMshopWeChatInfoManager;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.meidian.vo.Pagination;
import com.gome.rec.footprint.entity.PageEntity;
import com.gome.rec.footprint.entity.UserFootprintEntity;
import com.gome.rec.footprint.entity.UserViewBehaviorEntity;
import com.gome.rec.footprint.service.FootprintService;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import com.gomeplus.bs.interfaces.gorder.service.SelectGroupInfoResource;
import com.gomeplus.bs.interfaces.gorder.vo.GroupExtInfoVo;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import redis.Gcache;

@Slf4j
@Service
public class GuestManager {
	
	@Autowired
	private IMShopOwnerInfoManager imShopOwnerInfoManager; // 店主
	@Autowired
	private IMShopShareRecordManager imShopShareRecordManager;
	@Autowired
	private IMshopWeChatInfoManager iMshopWeChatInfoManager;
	@Autowired
	private IUserShareBindingManager iUserShareBindingManager;
	@Autowired
	private FootprintService footprintService; // 查询用户浏览记录
	@Autowired
	private INewOrderService iNewOrderService; // 订单业绩
	@Autowired
	private AuthencationUtils authencationUtils;
	@Autowired
	private Gcache gcache;
	@Autowired
	private PageInfoResource pageInfoResource;
	@Autowired
	private SelectGroupInfoResource selectGroupInfoResource;
	@Value("${meidian.image.userImage}")
	private String userImage;			// 用户头像分辨率
	@Value("${meidian.image.agreement}")
	private String agreement;			// http协议
	
	
	public void copyProperties (MShopOwnerInfoDto source, GuestInfo target) {
		BeanUtils.copyProperties(source, target);
	}
	
	public String getUserIdByScn(String scn) {
		String userId = "";
		try {
			userId = authencationUtils.authenticationLogin(scn);
		} catch (ServiceException e) {
			log.error("check scn msg is NOT_LOGGED_ON, scn:" + scn, e.getMessage());
		}
		return userId;
	}
	
	
	/**
	 * 
	 */
	public static List<GuestCount> guestReduceCount(Map<Integer, Integer> ret) {
		List<GuestCount> list = new ArrayList<>();
		list.add(new GuestCount(1, 0));
		list.add(new GuestCount(2, 0));
		list.add(new GuestCount(4, 0));
		list.add(new GuestCount(5, 0));
		for (GuestCount guestCount : list) {
			Integer integer = ret.get(guestCount.getType());
			if(integer == null) {
				integer = 0;
			}
			guestCount.setCount(integer);
		}
		return list;
	}
	
	/**
	 * 
	 * @param type
	 * @param currentUser
	 * @param pageNo
	 * @return
	 */
	public List<MShopOwnerInfoDto> getGuestListType (int type, Long currentUser, int pageNo) {
		List<MShopOwnerInfoDto> list = null;
		if (type == 1 || type == 4 || type == 5) {
			MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
					.queryOfflineInfoOfOtherType(currentUser, type + "", 10, pageNo);
			if (dto != null) {
				list = dto.getBuessObj();
			}
		} else {
			MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
					.queryOfflineInfoOfVisitor(currentUser, type + "", 10, pageNo);
			if (dto != null) {
				list = dto.getBuessObj();
			}
		}
		if (org.apache.commons.collections.CollectionUtils.isNotEmpty(list)) {
			for (MShopOwnerInfoDto mShopOwnerInfoDto : list) {
				String imagePath = ImageUtils.userImageUrlInfo2(mShopOwnerInfoDto.getImagePath(), userImage, agreement);
				String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(mShopOwnerInfoDto.getImagePathOfInvitation(), userImage, agreement);
				mShopOwnerInfoDto.setImagePath(imagePath);
				mShopOwnerInfoDto.setImagePathOfInvitation(imagePathOfInvitation);
			}
		}
		return list;
	}
	
	
	public List<GuestInfo> getGuestListType1 (int type, Long currentUser, int pageNo) {
		List<GuestInfo> retList = new ArrayList<>();
		List<MShopOwnerInfoDto> list = null;
		if (type == 1 || type == 4 || type == 5) {
			MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
					.queryOfflineInfoOfOtherType(currentUser, type + "", 10, pageNo);
			if (dto != null) {
				list = dto.getBuessObj();
			}
		} else {
			MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
					.queryOfflineInfoOfVisitor(currentUser, type + "", 10, pageNo);
			if (dto != null) {
				list = dto.getBuessObj();
			}
		}
		if (list != null && list.size() > 0) {
			for (MShopOwnerInfoDto infoDto : list) {
				GuestInfo gi = new GuestInfo();
				BeanUtils.copyProperties(infoDto, gi);
				gi.setUserType(type);	// 设置类型
				this.fullFilterGuestInfo(gi, gi.getUserId(), type, infoDto.getMid());

				String imagePath = ImageUtils.userImageUrlInfo2(gi.getImagePath(), userImage, agreement);
				String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(gi.getImagePathOfInvitation(), userImage, agreement);
				gi.setImagePath(imagePath);
				gi.setImagePathOfInvitation(imagePathOfInvitation);

				retList.add(gi);
			}
		}
		return retList;
	}
	
	/**
	 * 
	 * @param type
	 * @param currentUser
	 * @param pageNo
	 * @return
	 */
	@Deprecated
	public List<GuestInfo> getGuestInfoListType1 (int type, Long currentUser, int pageNo) {
		List<GuestInfo> ret = new ArrayList<>();
		if (type == 1 || type == 4 || type == 5) {
			MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
					.queryOfflineInfoOfOtherType(currentUser, type + "", 10, pageNo);
			List<MShopOwnerInfoDto> list = dto.getBuessObj();
			if (list != null && list.size() > 0) {
				for (MShopOwnerInfoDto infoDto : list) {
					GuestInfo gi = new GuestInfo();
					BeanUtils.copyProperties(infoDto, gi);
					this.fullFilterGuestInfo(gi, gi.getUserId(), type, infoDto.getMid());

					String imagePath = ImageUtils.userImageUrlInfo2(gi.getImagePath(), userImage, agreement);
					String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(gi.getImagePathOfInvitation(), userImage, agreement);
					gi.setImagePath(imagePath);
					gi.setImagePathOfInvitation(imagePathOfInvitation);

					ret.add(gi);
				}
			}
		} else {
			// 游客数据
			PageEntity<List<UserFootprintEntity>> rankedVisitors = null;
			List<String> guestList =  this.guestUnionIdList(currentUser);
			List<String> haveGuestList = new ArrayList<>();
			if(guestList != null && guestList.size() > 0) {
				rankedVisitors = footprintService.getRankedVisitors(currentUser.toString(), guestList, pageNo, 10);
				List<UserFootprintEntity> data = rankedVisitors.getData();
				if(data != null) {
					for (UserFootprintEntity userFootprintEntity : data) {
						List<MShopWeChatInfo> unuser = iMshopWeChatInfoManager.queryWeChatInfoByUniqueId(userFootprintEntity.getUserId());
						MShopWeChatInfo mshop = unuser.get(0);
						GuestInfo gi = new GuestInfo();
						gi.setWeiXinNickName(mshop.getNickname());
						gi.setWeixinNum(mshop.getWechatNum());
						gi.setBrowsLatestDate(userFootprintEntity.getVisitDate());
						gi.setUniqueId(mshop.getUniqueId());
						gi.setUserType(2);	// 添加类型
						gi.setAuthorization(0);	// 无权限

						String imagePath = ImageUtils.userImageUrlInfo2(mshop.getImage(), userImage, agreement);
						gi.setImagePath(imagePath);
						if(imagePath != null && imagePath.indexOf("http://") == 0) {
							imagePath = imagePath.replaceAll("http://", "https://");
							gi.setImagePath(imagePath);
						}

						haveGuestList.add(userFootprintEntity.getUserId());
						ret.add(gi);
					}
				}
			}
		}
		return ret;
	}
	/**
	 * 
	 * @param type
	 * @param currentUser
	 * @param pageNo
	 * @return
	 */
	public List<GuestInfo> getGuestInfoListType (int type, Long currentUser, int pageNo) {
		List<GuestInfo> ret = new ArrayList<>();
		if (type == 1 || type == 4 || type == 5) {
			MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
					.queryOfflineInfoOfOtherType(currentUser, type + "", 10, pageNo);
			List<MShopOwnerInfoDto> list = dto.getBuessObj();
			if (list != null && list.size() > 0) {
				for (MShopOwnerInfoDto infoDto : list) {
					GuestInfo gi = new GuestInfo();
					BeanUtils.copyProperties(infoDto, gi);
					this.fullFilterGuestInfo(gi, gi.getUserId(), type, infoDto.getMid());

					String imagePath = ImageUtils.userImageUrlInfo2(gi.getImagePath(), userImage, agreement);
					String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(gi.getImagePathOfInvitation(), userImage, agreement);
					gi.setImagePath(imagePath);
					gi.setImagePathOfInvitation(imagePathOfInvitation);

					ret.add(gi);

				}
			}
		} else {
			ret = this.userFootPointFull2BigData(currentUser, pageNo);
		}
		return ret;
	}
	
	/**
	 * 
	 * @param currentUser
	 * @param pageNo
	 * @return
	 */
	public List<GuestInfo> userFootPointFull2BigData(Long currentUser, int pageNo) {
		List<GuestInfo> ret = new ArrayList<>();
		List<MShopOwnerInfoDto> list = null;
		MapResults<List<MShopOwnerInfoDto>> dto = imShopOwnerInfoManager
				.queryOfflineInfoOfVisitor(currentUser, "2", 10, pageNo);
		if (dto != null) {
			list = dto.getBuessObj();
		}
		List<String> guestList = new ArrayList<>();
		
		if(dto.getBuessObj() == null) {
			return ret;
		}
		for (MShopOwnerInfoDto mShopOwnerInfoDto : list) {
			GuestInfo gi = new GuestInfo();
			BeanUtils.copyProperties(mShopOwnerInfoDto, gi);
			guestList.add(mShopOwnerInfoDto.getUniqueId());

			String imagePath = ImageUtils.userImageUrlInfo2(gi.getImagePath(), userImage, agreement);
			String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(gi.getImagePathOfInvitation(), userImage, agreement);
			gi.setImagePath(imagePath);
			gi.setImagePathOfInvitation(imagePathOfInvitation);

			ret.add(gi);
		}
		
		Map<String, String> visitMap = new HashMap<>();
		// 	游客数据
		PageEntity<List<UserFootprintEntity>> rankedVisitors = footprintService.getRankedVisitors(currentUser.toString(), guestList, pageNo, 10);
		List<UserFootprintEntity> data = rankedVisitors.getData();
		if(data != null && data.size() > 0) {
			for (UserFootprintEntity userFootprintEntity : data) {
				visitMap.put(userFootprintEntity.getUserId(), userFootprintEntity.getVisitDate());
			}
		}
		for(GuestInfo info : ret) {
			String uniqueId = info.getUniqueId();
			String stepTime = visitMap.get(uniqueId);
			if(StringUtils.isNotBlank(stepTime)) {
				info.setBrowsLatestDate(stepTime);
			}
			this.fullFilterGuestInfo(info, info.getUserId(), 2, null);
		}
		return ret;
	}
	
	/**
	 *	内部 - 拼接数据
	 * @param guestInfo
	 * @param userId
	 * @param type
	 * @param mid
	 * @return 
	 */
	public GuestInfo fullFilterGuestInfo (GuestInfo guestInfo, Long userId, int type, Long mid) {
		Integer authorization = guestInfo.getAuthorization();	
		// 添加权限 
		this.updateGuestInfoAuthr(authorization, type, guestInfo);
		// 更新双协议img
		this.updateGuestImgIndex2Https(guestInfo);
		if(userId == null || userId == 0L) 
			return guestInfo;
		// 新客查询首单信息, 忠粉最近订单时间
		if (type == 4 || type == 5) {
			this.updateGuestFirstOrder(guestInfo, userId);
		}
		// 订单累积金额数量
		if (type == 5) {
			this.updateOrderInfo(guestInfo, mid, Long.valueOf(userId));
		}
		return guestInfo;	// 返回
	}
	
	
	
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
//		String index = "http://";
		//		index = index.replaceAll("http://", "https://");
		//		System.out.println(index);
		//
		//		String str = "12314324";
		//		System.out.println(str.substring(0, 3));

		String s = ImageUtils.userImageUrlInfo2("//gfs15.gomein.net.cn/T1LOAXB4LT1RCvBVdK.jpg", "_100_100", "https:");
		System.err.println("结果是:" + s);
	}
	
	/**
	 * 更新新客老客下单时间
	 * @param guestInfo
	 * @param userId
	 */
	public void updateGuestFirstOrder(GuestInfo guestInfo, Long userId) {
		OrderListParam orderListParam = new OrderListParam();
		orderListParam.setUserId(userId);
		orderListParam.setPageNo(1);
		orderListParam.setPageSize(1);
		ResultEntity<Pagination<OrderInfo>> orderRes = iNewOrderService.getUserOrderList(userId, "4", 1, 1);
		Pagination<OrderInfo> orderRage = orderRes.getBusinessObj();
		List<OrderInfo> orderList = orderRage.getList();
		if (orderList != null && orderList.size() > 0) {
			OrderInfo orderInfo = orderList.get(0);
			Date orderTime = orderInfo.getOrderTime();
			guestInfo.setFirstOrderDate(DateUtils.dateFormatToString(orderTime, "yyyy-MM-dd"));
			guestInfo.setFirstOrderPrice(orderInfo.getPriceTotal());
		}
	}
	
	/**
	 * 获取订单数, 订单销售额
	 * @param owner
	 * @param mid
	 * @param searchUserId
	 */
	public void updateOrderInfo (GuestInfo owner, Long mid, Long searchUserId) {
		ResultEntity<MyGradesVo> myGrades = null;
		if (mid == null) {
			myGrades = iNewOrderService.getUserAccumAmount(searchUserId,"4");
		} else {
			myGrades = iNewOrderService.getMyGrades(searchUserId, "4");
		}
		MyGradesVo res = myGrades.getBusinessObj();
		if (res != null) {
			owner.setOrderNum(res.getOrderNums());
			owner.setSaleAmounts(res.getOrderGmv());
		}
	}

	/**
	 * 更新授权展示字段
	 * @param authorization
	 * @param type
	 * @param guestInfo
	 */
	public void updateGuestInfoAuthr(Integer authorization, int type, GuestInfo guestInfo) {
		if(authorization == null) {
			authorization = 0;
			guestInfo.setAuthorization(0);
		}
		if(authorization == 0 || type == 2) {	// 对微信号, 手机号码, 用户类型游客类型
			String weixinNum = guestInfo.getWeixinNum();
			if(StringUtils.isNotBlank(weixinNum)) {
				guestInfo.setWeixinNum(weixinNum.substring(0, 1)+"****" +weixinNum.substring(weixinNum.length()-1));
			}
			String phone = guestInfo.getPhone();
			if(StringUtils.isNotBlank(phone)) {
				guestInfo.setPhone(phone.substring(0, 3)+"****" +phone.substring(8));
			}
		}
	}
	
	/**
	 * 更新双协议图片地址
	 * @param info
	 */
	public void updateGuestImgIndex2Https (GuestInfo info) {
		String imagePath = info.getImagePath();
		if(imagePath != null && imagePath.indexOf("http://") == 0) {
			imagePath = imagePath.replaceAll("http://", "https://");
			info.setImagePath(imagePath);
		}
		String imagePath2 = info.getImagePathOfInvitation();
		if(imagePath2 != null && imagePath2.indexOf("http://") == 0) {
			imagePath2 = imagePath2.replaceAll("http://", "https://");
			info.setImagePathOfInvitation(imagePath2);
		}
	}
	/**
	 * 搜索
	 * @param currentUser
	 * @param phone
	 * @param wechartNick
	 * @param type
	 * @return
	 */
	public ResponseJson<Map<String, Object>> searchByPhoneAndWeNick(String currentUser, String phone, String wechartNick, int type) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}
		List<GuestInfo> newList = new ArrayList<>();
		if (StringUtils.isNotBlank(phone)) {
			MapResults<MShopOwnerInfoDto> phoneUser = imShopOwnerInfoManager
					.queryOfflineInfoByPhone(Long.valueOf(currentUser), phone);
			if (phoneUser != null) {
//				iUserShareBindingManager.getUserAuth(userId)
				MShopOwnerInfoDto userdto = phoneUser.getBuessObj();
				if (userdto != null && userdto.getUserId() != null) {
					Integer userType = userdto.getUserType();
					if (userType.equals(type)) {
						GuestInfo target = new GuestInfo();
						BeanUtils.copyProperties(userdto, target);

						String imagePath = ImageUtils.userImageUrlInfo2(userdto.getImagePath(), userImage, agreement);
						String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(userdto.getImagePathOfInvitation(), userImage, agreement);
						target.setImagePath(imagePath);
						target.setImagePathOfInvitation(imagePathOfInvitation);

						this.fullFilterGuestInfo(target, target.getUserId(), type, userdto.getMid());
						newList.add(target);
					}
				}
			}
		}
		if (StringUtils.isNotBlank(wechartNick)) {
			MapResults<List<MShopOwnerInfoDto>> nickList = imShopOwnerInfoManager
					.queryOfflineInfoByWeiXinNickName(Long.valueOf(currentUser), wechartNick);
			if (nickList != null) {
				List<MShopOwnerInfoDto> list = nickList.getBuessObj();
				if (list != null && !list.isEmpty()) {
//					iUserShareBindingManager.getUserAuth(userId)
					for (MShopOwnerInfoDto shop : list) {
						if(shop == null) continue;
						Integer userType = shop.getUserType();
						if (userType.equals(type)) {
							GuestInfo target = new GuestInfo();
							BeanUtils.copyProperties(shop, target);

							String imagePath = ImageUtils.userImageUrlInfo2(shop.getImagePath(), userImage, agreement);
							String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(shop.getImagePathOfInvitation(), userImage, agreement);
							target.setImagePath(imagePath);
							target.setImagePathOfInvitation(imagePathOfInvitation);

							this.fullFilterGuestInfo(target, shop.getUserId(), type, shop.getMid());
							newList.add(target);
						}
					}
				}
			}
		}
		resMap.put("result", newList);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 客户管理数
	 * 
	 * @param scn
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myGuestTypeCount(String currentUser) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}

		MapResults<Map<Integer, Integer>> queryOfflineCount = imShopOwnerInfoManager
				.queryOfflineCount(Long.valueOf(currentUser));
		resMap.put("result", GuestManager.guestReduceCount(queryOfflineCount.getBuessObj()));
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 
	 * @param scn
	 * @param type
	 * @param pageNo
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myGuestListByType(String currentUser, int type, int pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}
		List<GuestInfo> newList = new ArrayList<>();
		String key = "GuestController:" + "myGuestListByType:" + currentUser + "-" + type + "-" + pageNo;
		String val = gcache.get(key);
		if(StringUtils.isNotBlank(val)) {
			newList = JSONArray.parseArray(val, GuestInfo.class);
		}else {
			newList = getGuestInfoListType(type, Long.valueOf(currentUser), pageNo);
			gcache.setex(key, 10, JSONObject.toJSONString(newList));
		}
		resMap.put("result", newList);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 我的店主
	 * @param currentUser
	 * @param searchUserId
	 * @return
	 */
	public ResponseJson<Map<String, Object>> getMshopOwner(String currentUser, Long searchUserId) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}
		MapResults<MShopOwnerInfoDto> one = imShopOwnerInfoManager.queryMShopBasicInfoByUserId(searchUserId);
		MShopOwnerInfoDto buessObj = one.getBuessObj();
		GuestInfo owner = new GuestInfo();
		if (one != null && buessObj != null && buessObj.getUserId() != null) {
			BeanUtils.copyProperties(buessObj, owner);

			String imagePath = ImageUtils.userImageUrlInfo2(buessObj.getImagePath(), userImage, agreement);
			String imagePathOfInvitation = ImageUtils.userImageUrlInfo2(buessObj.getImagePathOfInvitation(), userImage, agreement);
			owner.setImagePath(imagePath);
			owner.setImagePathOfInvitation(imagePathOfInvitation);

		}
		resMap.put("result", owner);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 用户足迹 分页
	 * @param currentUser
	 * @param searchUserId
	 * @param pageNo
	 * @return
	 */
	public ResponseJson<Map<String, Object>> userFootPoint(String currentUser, String searchUserId, String pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}

		if (!StringUtils.isNotBlank(pageNo)) {
			pageNo = "1"; // 默认1
		}
		List<UserFootprintInfo> retList = new ArrayList<>();
		String key = "GuestController:" + "userFootPoint:" + currentUser + "-"+ pageNo + "-" + searchUserId;
		String val = gcache.get(key);
		if(StringUtils.isNotBlank(val)) {
			retList = JSONArray.parseArray(val, UserFootprintInfo.class);
		}else {
			// 用户足迹逻辑
			retList = this.userFootprintPage(searchUserId, pageNo);
			gcache.setex(key, 10, JSONArray.toJSONString(retList));
		}
		resMap.put("result", retList);
		responseJson.setData(resMap);

		return responseJson;
	}
	
	/**
	 * 其他用户足迹
	 * @param currentUser
	 * @param searchUserId
	 * @return
	 */
	public ResponseJson<Map<String, Object>> userFootPointInit(String currentUser, String searchUserId) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();

		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}
		MapResults<MShopOwnerInfoDto> dto = null;
		UserFootprintInit init = new UserFootprintInit();
		GuestInfo owner = new GuestInfo();
		Integer authorization = 0;
		if(StringUtils.isNoneBlank(searchUserId)) {
			if(searchUserId.length() <= 13) {	// 字符串长度小于13 为userId
				// 非游客
				dto = imShopOwnerInfoManager.queryMShopBasicInfoByUserId(Long.valueOf(searchUserId));
				MShopOwnerInfoDto oinfo = dto.getBuessObj();
				if (dto != null && oinfo != null) {
					BeanUtils.copyProperties(oinfo, owner);
					Long mid = oinfo.getMid();
					this.updateOrderInfo(owner, mid, Long.valueOf(searchUserId));
					this.updateGuestImgIndex2Https(owner);
					MapResults<UserAuthDto> userAuth = iUserShareBindingManager.getUserAuth(Long.valueOf(searchUserId));
					UserAuthDto authDtoBo = userAuth.getBuessObj();
					if(authDtoBo != null) {
						authorization = authDtoBo.getAuthorization();	// 默认赋值
					}
					owner.setAuthorization(authorization);

					owner.setImagePath(ImageUtils.userImageUrlInfo2(owner.getImagePath(), userImage, agreement));
					owner.setImagePathOfInvitation(ImageUtils.userImageUrlInfo2(owner.getImagePathOfInvitation(), userImage, agreement));

					init.setGuestInfo(owner);
				}
			}else {
				// 游客用户可以查看浏览记录
				authorization = 1;
			}
		}
		if(authorization > 0) {
			// 足迹分页
			List<UserFootprintInfo> retList = this.userFootprintPage(searchUserId, "1");
			init.setFootPrints(retList);
		}
		resMap.put("authorization", authorization);	// 赋值权限
		resMap.put("result", init);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	public List<UserFootprintInfo> userFootprintPage (String searchUserId, String pageNo) {
//		searchUserId = "80750206521"; // ********
		List<UserFootprintInfo> retList = new ArrayList<>();
		if(StringUtils.isNoneBlank(searchUserId)) {
//			PageEntity<List<UserFootprintEntity>> page = new PageEntity<>();
			PageEntity<List<UserViewBehaviorEntity>> page = new PageEntity<>();
			if(searchUserId.length() <= 12) {
				// 新老客
				page = footprintService.getUserViewsByPage(searchUserId, null, null, pageNo, "10", "MEIDIAN");
//				page = footprintService.getUserFootprintsByPage(searchUserId, null, null, pageNo, "10", "MEIDIAN");
			}else {
				// 游客
				page = footprintService.getAnonymViewsByPage(searchUserId, null, null, pageNo, "10", "MEIDIAN");
//				page = footprintService.getAnonymFootprintsByPage(searchUserId, null, null, pageNo, "10", "MEIDIAN");
			}
//			List<UserFootprintEntity> data = page.getData();
			if(page != null) {
				List<UserViewBehaviorEntity> data = page.getData();
				if (data != null && !data.isEmpty()) {
					List<Long> gfCodeList = new ArrayList<>();
					List<Long> zlCodeList = new ArrayList<>();
					List<String> pageCodeList = new ArrayList<>();
//				for (UserFootprintEntity en : data) {
					for (UserViewBehaviorEntity en : data) {
						if(en == null) continue;
						// 封装数据
						int viewBehaviorType = en.getViewBehaviorType();
						if(viewBehaviorType > 0) {
							// 1. 普通活动, 2.瓜分, 3. 助力
							String activityType = en.getActivityType();
							String activityId = en.getActivityId();
							if("1".equals(activityType)) {
								pageCodeList.add(activityId);
							}else if("2".equals(activityType)){
								gfCodeList.add(Long.valueOf(activityId));
							}else if("3".equals(activityType)){
								zlCodeList.add(Long.valueOf(activityId));
							}
						}
					}
					
					// 瓜分
					Map<Long, GroupExtInfoVo> selectCarveGroup = new HashMap<>();
					if(gfCodeList.size() > 0) {
						selectCarveGroup = selectGroupInfoResource.selectCarveGroup(gfCodeList);
					}
					// 助力
					Map<Long, GroupExtInfoVo> selectHelpGroup = new HashMap<>();
					if(zlCodeList.size() > 0) {
						selectHelpGroup = selectGroupInfoResource.selectHelpGroup(zlCodeList);
					}
					
					
					for (UserViewBehaviorEntity en : data) {
						if(en == null) continue;
						// 排除错误数据
						if(en.getViewBehaviorType() == 1) {
							String activityType = en.getActivityType();
							if("2".equals(activityType)) {
								GroupExtInfoVo groupExtInfoVo = selectCarveGroup.get(Long.valueOf(en.getActivityId()));
								if(groupExtInfoVo == null) continue;
							}else if("3".equals(activityType)) {
								GroupExtInfoVo groupExtInfoVo = selectHelpGroup.get(Long.valueOf(en.getActivityId()));
								if(groupExtInfoVo == null) continue;
							}
						}
						UserFootprintInfo target = new UserFootprintInfo();
						BeanUtils.copyProperties(en, target);
						this.copyProperties(target, en, selectCarveGroup, selectHelpGroup);
						String imagePath = ImageUtils.userImageUrlInfo2(target.getUserImg(), userImage, agreement);
						target.setUserImg(imagePath);

						if(imagePath != null && imagePath.indexOf("http://") == 0) {
							imagePath = imagePath.replaceAll("http://", "https://");
							target.setUserImg(imagePath);
						}
						String imagePath2 = target.getImgUrl();
						if(imagePath2 != null && imagePath2.indexOf("http://") == 0) {
							imagePath2 = imagePath2.replaceAll("http://", "https://");
							target.setImgUrl(imagePath2);
						}
						retList.add(target);
					}
				}
			}
		}
		return retList;
	}
	
	/**
	 * copy userFoot
	 * @param target
	 * @param en
	 * @param selectCarveGroup
	 * @param selectHelpGroup
	 */
	private void copyProperties (UserFootprintInfo target, UserViewBehaviorEntity en, Map<Long, GroupExtInfoVo> selectCarveGroup, Map<Long, GroupExtInfoVo> selectHelpGroup) {
		// 封装数据
		int viewBehaviorType = en.getViewBehaviorType();
		if(viewBehaviorType > 0) {
			// 1. 普通活动, 2.瓜分, 3. 助力
			GroupExtInfoVo groupExtInfoVo = null;
			String activityType = en.getActivityType();
			String activityId = en.getActivityId();
			if("1".equals(activityType)) {
				PageInfo selectPageInfo = pageInfoResource.selectPageInfo(activityId);
				if(selectPageInfo != null) {
					String pageName = selectPageInfo.getPageTitle();
					target.setActivityName(pageName);
					target.setImgUrl(selectPageInfo.getImgUrl());
					target.setActivityStatus((int)selectPageInfo.getStatus());
				}
			}else if("2".equals(activityType)){
				if(selectCarveGroup != null) {
					groupExtInfoVo = selectCarveGroup.get(Long.valueOf(activityId));
				}
				if(groupExtInfoVo != null) {
					String shopImageUrl = groupExtInfoVo.getShopImageUrl();
					target.setImgUrl(shopImageUrl);
					Double headBondTotalNum = groupExtInfoVo.getHeadBondTotalNum();
					Double headAwardMoney = groupExtInfoVo.getHeadAwardMoney();
					if(headAwardMoney == null) {
						headAwardMoney = 0D;
					}
					String actName = "集齐"+groupExtInfoVo.getStandardNum() + "人独享" 
							+ headAwardMoney + "元国美币";
					
					if(headBondTotalNum != null) {
						actName += ", "+headBondTotalNum + "元优惠券";
					}
					target.setActivityName(actName);
					long time = groupExtInfoVo.getEndTime().getTime();
					long currentTimeMillis = System.currentTimeMillis();
					target.setActivityStatus(currentTimeMillis - time > 0?0:1);
						
				}
			}else if("3".equals(activityType)){
				if(selectHelpGroup != null) {
					groupExtInfoVo = selectHelpGroup.get(Long.valueOf(activityId));
				}
				if(groupExtInfoVo != null) {
					String shopImageUrl = groupExtInfoVo.getShopImageUrl();
					target.setImgUrl(shopImageUrl);
					Double headAwardMoney = groupExtInfoVo.getHeadAwardMoney();
					if(headAwardMoney == null) {
						headAwardMoney = 0D;
					}
					String actName = "集齐"+groupExtInfoVo.getStandardNum() + "人独享" 
							+ headAwardMoney + "元国美币, ";
					target.setActivityName(actName);
					long time = groupExtInfoVo.getEndTime().getTime();
					long currentTimeMillis = System.currentTimeMillis();
					target.setActivityStatus(currentTimeMillis - time > 0?0:1);
				}
			}
			if(groupExtInfoVo != null) {
				target.setActivityId(groupExtInfoVo.getActivityId().toString());
				target.setGroupId(groupExtInfoVo.getGroupId());
				target.setIsSuccessGroup(groupExtInfoVo.getIsSuccess() ? 1 : 0);
				target.setIsSuccessGroupStr(groupExtInfoVo.getIsSuccess() ? "已成团" : "未成团");
				target.setAttendDate(DateUtils.dateFormatToString(groupExtInfoVo.getParticipationTime(), "yyyy-MM-dd hh:mm:ss"));
				target.setHeadUserId(groupExtInfoVo.getHeadUserId());
				target.setHeadNickname(groupExtInfoVo.getHeadNickname());
				target.setGroupType(groupExtInfoVo.getGroupType());
				target.setGroupOrderId(groupExtInfoVo.getOrderId());
				target.setSkuId(groupExtInfoVo.getSkuId());
			}
		}
	}
	
	/**
	 * 我的足迹 分页
	 * @param currentUser
	 * @param pageNo
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myFootPoint(String currentUser, String pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}
		if (!StringUtils.isNotBlank(pageNo)) {
			pageNo = "1"; // 默认1
		}
		List<MyFootprintVo> retList = new ArrayList<>();
		String key = "GuestController:" + "myFootPoint:" + currentUser + "-" + pageNo;
		String val = gcache.get(key);
		if(StringUtils.isNotBlank(val)) {
			retList = JSONArray.parseArray(val, MyFootprintVo.class);
			resMap.put("result", retList);
			responseJson.setData(resMap);
			return responseJson;
		}
		List<String> visitUserIdList = new ArrayList<>();
//		visitUserIdList.add("80750206521");	// **********
		List<String> guestUnionIdList = new ArrayList<>();
		if(pageNo.equals("1")) {
			// 大数据快照逻辑, 2页以上不穿即可
			guestUnionIdList = this.guestUnionIdList(Long.valueOf(currentUser));
			if(guestUnionIdList == null) {	// 给出条件
				guestUnionIdList = new ArrayList<>();
			}
			// 客户列表数据
			MapResults<List<String>> queryUserIdList = imShopOwnerInfoManager.queryUserIdList(Long.valueOf(currentUser));
			List<String> _visitUserIdList = queryUserIdList.getBuessObj();
			if(_visitUserIdList != null && _visitUserIdList.size() > 0) {
				Set<Long> idLongList = new HashSet<Long>();
				for (String id : _visitUserIdList) {
					idLongList.add(Long.valueOf(id));
				}
				MapResults<List<UserAuthDto>> userAuthList = iUserShareBindingManager.getUserAuthList(idLongList);
				if(userAuthList != null) {
					List<UserAuthDto> buessObj = userAuthList.getBuessObj();
					if(buessObj != null && buessObj.size() > 0) {
						// 取认证的用户数据作展示
						for (UserAuthDto userAuthDto : buessObj) {
							if(userAuthDto.getAuthorization() > 0) {
								visitUserIdList.add(userAuthDto.getUserId().toString());
							}
						}
					}
				}
			}
		}
		
//		PageEntity<List<UserFootprintEntity>> page = new PageEntity<>();
		PageEntity<List<UserViewBehaviorEntity>> page = new PageEntity<>();
		if(pageNo.equals("1") && (visitUserIdList.size() > 0 || guestUnionIdList.size() > 0)) {
			page = footprintService.getUsersViews(currentUser, guestUnionIdList, visitUserIdList, Integer.valueOf(pageNo), 20);
//			page = footprintService.getUsersFootprints(currentUser, guestUnionIdList, visitUserIdList, Integer.valueOf(pageNo), 20);
		} else if(!pageNo.equals("1")){
			page = footprintService.getUsersViews(currentUser, null, null, Integer.valueOf(pageNo), 20);
		}
//		List<UserFootprintEntity> foos = page.getData();
		List<UserViewBehaviorEntity> foos = page.getData();
		if (foos != null && !foos.isEmpty()) {
			List<String> pageCodeList = new ArrayList<>();
			List<Long> zlCodeList = new ArrayList<>();	// 助力
			List<Long> gfCodeList = new ArrayList<>();	// 瓜分
			List<String> userIdList = new ArrayList<>();	
			for (UserViewBehaviorEntity en : foos) {
				// 封装数据
				int viewBehaviorType = en.getViewBehaviorType();
				if(viewBehaviorType > 0) {
					// 1. 普通活动, 2.瓜分, 3. 助力
					String activityType = en.getActivityType();
					String activityId = en.getActivityId();
					if("1".equals(activityType)) {
						pageCodeList.add(activityId);
					}else if("2".equals(activityType)){
						gfCodeList.add(Long.valueOf(activityId));
					}else if("3".equals(activityType)){
						zlCodeList.add(Long.valueOf(activityId));
					}
				}
				String userId = en.getUserId();
				if(!userIdList.contains(userId)) {
					userIdList.add(userId);
				}
			}
			
			// 瓜分
			Map<Long, GroupExtInfoVo> selectCarveGroup = new HashMap<>();
			if(gfCodeList.size() > 0) {
				selectCarveGroup = selectGroupInfoResource.selectCarveGroup(gfCodeList);
			}
			// 助力
			Map<Long, GroupExtInfoVo> selectHelpGroup = new HashMap<>();
			if(zlCodeList.size() > 0) {
				selectHelpGroup = selectGroupInfoResource.selectHelpGroup(zlCodeList);
			}
			
			Map<String, List<UserFootprintInfo>> infoMap = new HashMap<>();
			for (UserViewBehaviorEntity en : foos) {
				if(en == null) continue;
				// 排除错误数据
				if(en.getViewBehaviorType() == 1) {
					String activityType = en.getActivityType();
					if("2".equals(activityType)) {
						GroupExtInfoVo groupExtInfoVo = selectCarveGroup.get(Long.valueOf(en.getActivityId()));
						if(groupExtInfoVo == null) continue;
					}else if("3".equals(activityType)) {
						GroupExtInfoVo groupExtInfoVo = selectHelpGroup.get(Long.valueOf(en.getActivityId()));
						if(groupExtInfoVo == null) continue;
					}
				}
				
				String userId = en.getUserId();
				if (StringUtils.isBlank(userId)) {
					continue;
				}
				UserFootprintInfo target = new UserFootprintInfo();
				BeanUtils.copyProperties(en, target);
				this.copyProperties(target, en, selectCarveGroup, selectHelpGroup);

				String imagePath = ImageUtils.userImageUrlInfo2(target.getUserImg(), userImage, agreement);
				target.setUserImg(imagePath);

				if(imagePath != null && imagePath.indexOf("http://") == 0) {
					imagePath = imagePath.replaceAll("http://", "https://");
					target.setUserImg(imagePath);
				}
				String imagePath2 = target.getImgUrl();
				if(imagePath2 != null && imagePath2.indexOf("http://") == 0) {
					imagePath2 = imagePath2.replaceAll("http://", "https://");
					target.setImgUrl(imagePath2);
				}
				
				List<UserFootprintInfo> list = infoMap.get(en.getUserId());
				if (list == null) {
					list = new ArrayList<>();
					list.add(target);
					infoMap.put(target.getUserId(), list);
				} else {
					list.add(target);
					infoMap.put(target.getUserId(), list);
				}
				
			}
			// 用户排序
			for (String id : userIdList) {
				MyFootprintVo vo = new MyFootprintVo();
				UserSimpleInfo in = new UserSimpleInfo();
				if(id.length() <= 12) {
					MapResults<MShopOwnerInfoDto> baseInfo = imShopOwnerInfoManager.queryMShopBasicInfoByUserId(Long.valueOf(id));
					if(baseInfo != null) {
						MShopOwnerInfoDto baseInfoDto = baseInfo.getBuessObj();
						in.setImagePath(ImageUtils.userImageUrlInfo2(baseInfoDto.getImagePath(), userImage, agreement));
						in.setUserId(id);
						in.setWeiXinNickName(baseInfoDto.getWeiXinNickName());
						in.setWeixinNum(baseInfoDto.getWeixinNum());
					}
				}else {
					List<MShopWeChatInfo> wechart = iMshopWeChatInfoManager.queryWeChatInfoByUniqueId(id);
					if(wechart != null && wechart.size() > 0) {
						MShopWeChatInfo wechInfo = wechart.get(0);
						in.setImagePath(ImageUtils.userImageUrlInfo2(wechInfo.getImage(), userImage, agreement));
						in.setUniqueId(id);
						in.setWeiXinNickName(wechInfo.getNickname());
						in.setWeixinNum(wechInfo.getWechatNum());
					}
				}
				String imagePath = in.getImagePath();
				if(imagePath != null && imagePath.indexOf("http://") == 0) {
					imagePath = imagePath.replaceAll("http://", "https://");
					in.setImagePath(imagePath);
				}
				vo.setUser(in);
				List<UserFootprintInfo> list = infoMap.get(id);
				vo.setFootsPoints(list);
				retList.add(vo);
			}
			// 加入gcache
		}
		gcache.setex(key, 10 , JSONArray.toJSONString(retList));
		resMap.put("result", retList);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 获取游客用户id集合
	 * 
	 * @param currentUser
	 * @return
	 */
	public List<String> guestUnionIdList (long currentUser) {
		List<String> guestList = imShopShareRecordManager.queryUniqueIdListByUpUserId(currentUser);
		return guestList;
	}
	
	
	/**
	 * 
	 * @param scn
	 * @param type
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myGuestInit(String currentUser, int type ) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if (null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		} else {
			resMap.put("login", 1);
		}
		MapResults<Map<Integer, Integer>> queryOfflineCount = imShopOwnerInfoManager
				.queryOfflineCount(Long.valueOf(currentUser));
		List<GuestCount> guestReduceCount = GuestManager.guestReduceCount(queryOfflineCount.getBuessObj());
		MyGuestInit init = new MyGuestInit();
		init.setGuestReduces(guestReduceCount); // 封装
		List<GuestInfo> newList = getGuestInfoListType(type, Long.valueOf(currentUser), 1);
		init.setGuestInfos(newList); // 封装
		resMap.put("result", init);

		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 
	 * @param scn
	 * @return
	 * @throws ServiceException
	 */
	public ResponseJson<Map<String, Object>> getWeiXinNickName ( String currentUser )throws ServiceException{
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("weixinNickName", "");
		
		if (null == currentUser) {
			map.put("login", 0);
			responseJson.setData(map);
			return responseJson;
		} else {
			map.put("login", 1);
		}
		MapResults<MShopOwnerInfoDto> mapResults = imShopOwnerInfoManager.queryMShopBasicInfoByUserId(Long.valueOf(currentUser));
		if(mapResults != null){
			MShopOwnerInfoDto  mShopOwnerInfoDto  = mapResults.getBuessObj();
			if(mShopOwnerInfoDto != null ){
				map.put("weixinNickName", mShopOwnerInfoDto.getWeiXinNickName() == null ? "":mShopOwnerInfoDto.getWeiXinNickName());
			}
		}
		responseJson.setData(map);
		return responseJson;
	}
	
	
	/**
	 * 渠道店主完整信息. 渠道信息, 店主数, 客户数
	 * 
	 * @param scn
	 * @CookieValue(value = "SCN", required = false)
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myChannelMshopOwner(String currentUser) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		}else {
			resMap.put("login", 1);
		}
		Long currentUserID = Long.valueOf(currentUser);
		MapResults<MShopOwnerInfoDto> dto = imShopOwnerInfoManager.queryMshopOwnerIndexByUserId(currentUserID);
		MShopOwnerInfoDto mShopOwnerInfoDto = dto.getBuessObj();
		ChannelUserInfo owner = new ChannelUserInfo();
		if (dto != null && mShopOwnerInfoDto != null) {
			BeanUtils.copyProperties(mShopOwnerInfoDto, owner);
			String imagePath = ImageUtils.userImageUrlInfo2(owner.getImagePath(), userImage, agreement);
			owner.setImagePath(imagePath);
			if(imagePath != null && imagePath.indexOf("http://") == 0) {
				imagePath = imagePath.replaceAll("http://", "https://");
				owner.setImagePath(imagePath);
			}
			// 店主数, 客户数
			MapResults<MeidianVshopSummaryDto> shopSummaryDto = imShopOwnerInfoManager.selectByUserId(currentUserID);
			MeidianVshopSummaryDto buessObj = shopSummaryDto.getBuessObj();
			if(buessObj != null) {
				owner.setMshopOwnerCount(buessObj.getShopNum().intValue());
				owner.setConsumerCount(buessObj.getCustomNum().intValue());
			}
			ResultEntity<MyGradesVo> myGrades = iNewOrderService.getMyGrades(mShopOwnerInfoDto.getUserId(), "4");
			MyGradesVo grades = myGrades.getBusinessObj();
			if (grades != null) {
				owner.setSaleAmount(grades.getOrderGmv());
			}
		}
		resMap.put("result", owner);
		responseJson.setData(resMap);

		return responseJson;
	}

	/**
	 * @CookieValue(value = "SCN", required = false)
	 * @param scn
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myChannelPerformances(String currentUser,int pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();

		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		}else {
			resMap.put("login", 1);
		}
		List<ChannelUserInfo> infoList = new ArrayList<>();
		String key = "ChannelController:" + "myPerformances:" + currentUser + "-" +pageNo;
		String val = gcache.get(key);
		if(StringUtils.isNotBlank(val)) {
			infoList = JSONArray.parseArray(val, ChannelUserInfo.class);
			resMap.put("result", infoList);
			responseJson.setData(resMap);
			return responseJson;
		}
		MapResults<List<MShopPerformanceDto>> dto = imShopOwnerInfoManager.getInviteList(Long.valueOf(currentUser), 10,
				pageNo);
		if (dto != null && dto.getBuessObj() != null) {
			List<MShopPerformanceDto> list = dto.getBuessObj();
			for (MShopPerformanceDto d : list) {
				MShopOwnerInfoDto owner = d.getMShopOwnerInfoDto();
				Long userId = owner.getUserId();
				if (userId == null)
					continue;
				ChannelUserInfo info = new ChannelUserInfo();
				BeanUtils.copyProperties(owner, info);
				String imagePath = ImageUtils.userImageUrlInfo2(info.getImagePath(), userImage, agreement);
				info.setImagePath(imagePath);
				if(imagePath != null && imagePath.indexOf("http://") == 0) {
					imagePath = imagePath.replaceAll("http://", "https://");
					info.setImagePath(imagePath);
				}
				info.setMshopOwnerCount(d.getMshopOwnerCount());
				info.setConsumerCount(d.getConsumerCount());
				ResultEntity<MyGradesVo> myGrades = iNewOrderService.getMyGrades(info.getUserId(), "4");
				MyGradesVo grades = myGrades.getBusinessObj();
				info.setSaleAmount(grades.getOrderGmv());
				infoList.add(info);
			}
		}
		gcache.setex(key, 10, JSONArray.toJSONString(infoList));
//		parseArray(val, ChannelUserInfo.class)
		resMap.put("result", infoList);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 开始页面
	 * 
	 * @param scn
	 * @param startDate
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myAwardInit(String currentUser, int state, int startDate) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();

		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		}else {
			resMap.put("login", 1);
		}
		MyAwardInit init = new MyAwardInit();
		Date start = getThisMonthFirstDay(startDate);
		Date end = getNextMonthFirstDay(startDate);
		Long awary = getAwaryTotal(startDate, state, currentUser, start, end);
		init.setMyAwardTotalMoney(awary);
		AwardInfo info = getAwardInfo(currentUser,state, start, end);
		init.setMyAward(info);
		List<AwardInfo> newList = awardMasList(currentUser, 1, state, start, end);
		init.setMyMasAwards(newList);
		resMap.put("result", init);
		responseJson.setData(resMap);

		return responseJson;
	}
	


	/**
	 * 返利预算 -> 我的累计提奖金额
	 * 
	 * @param scn
	 *            当前用户
	 * @param state
	 *            提奖奖金状态 900.有效,901失效
	 * @param startDate
	 *            开始时间 201806
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myAwardTotalMoney(String currentUser, int state, int startDate) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		}else {
			resMap.put("login", 1);
		}
		Date start = getThisMonthFirstDay(startDate);
		Date end = getNextMonthFirstDay(startDate);
		Long awary = getAwaryTotal(startDate, state, currentUser, start, end);
		resMap.put("result", awary);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 返利预算 -> 我的提奖金额信息
	 * 
	 * @param scn
	 * @param state
	 * @param startDate
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myAward(String currentUser, int state, int startDate) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();

		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		}else {
			resMap.put("login", 1);
		}
		Date start = getThisMonthFirstDay(startDate);
		Date end = getNextMonthFirstDay(startDate);
		AwardInfo info = getAwardInfo(currentUser, state, start, end);
		resMap.put("result", info);
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 返利 -> 当前用户user下获取美店主集提奖金额集合
	 * 
	 * @param scn
	 * @param state
	 * @param startDate
	 * @param pageNo
	 * @return
	 */
	public ResponseJson<Map<String, Object>> myMasAward(String currentUser, int state, int startDate, int pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();

		Map<String, Object> resMap = new HashMap<String, Object>();
		if(null == currentUser) {
			resMap.put("login", 0);
			responseJson.setData(resMap);
			return responseJson;
		}else {
			resMap.put("login", 1);
		}
		// 缓存
		List<AwardInfo> newList = new ArrayList<>();
		String key = "PrizeController:" + "myMasAward:" + currentUser + "-" +state + "-" + startDate + "-" + pageNo;
		String val = gcache.get(key);
		if(StringUtils.isNotBlank(val)) {
			newList = JSONArray.parseArray(val, AwardInfo.class);
		}else {
			// 用户足迹逻辑
			Date start = getThisMonthFirstDay(startDate);
			Date end = getNextMonthFirstDay(startDate);
			newList = awardMasList(currentUser, pageNo, state, start, end);
			gcache.setex(key, 10, JSONObject.toJSONString(newList));
		}
		resMap.put("result", newList);
		responseJson.setData(resMap);
		return responseJson;
	}

	/**
	 * 这个月一号
	 * @param startDate
	 * @return
	 */
	public static Date getThisMonthFirstDay(int startDate) {
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
			Date parse = simpleDateFormat.parse(startDate + "01 00:00:00");
			Date start = com.gome.meidian.grouporder.utils.DateUtils.getThisMonthFirstDay(parse);
			return start;
		} catch (ParseException e) {
			log.error("PrizeController.getUserPrize(){...}, time format is error, ", e.getMessage());
			return null;
		}
	}

	/**
	 * 下个月一号
	 * @param startDate
	 * @return
	 */
	public static Date getNextMonthFirstDay(int startDate) {
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
			Date end = com.gome.meidian.grouporder.utils.DateUtils.getNextMonthFirstDay(simpleDateFormat.parse(startDate + "01 00:00:00"));
			return end;
		} catch (ParseException e) {
			log.error("PrizeController.getUserPrize(){...}, time format is error, ", e.getMessage());
			return null;
		}
	}

	
	/**
	 * 用户提奖额
	 * @param startDate
	 * @param state
	 * @param currentUser
	 * @param start
	 * @param end
	 * @return
	 */
	public Long getAwaryTotal(int startDate, int state, String currentUser, Date start, Date end) {
		ResultEntity<Long> awardMoney = iNewOrderService.getAwardTotalMoney(Long.valueOf(currentUser), state, start,
				end);
		Long awary = 0L;
		awary = awardMoney.getBusinessObj();
		if (awary == null) {
			awary = 0L;
		}
		return awary;
	}
	
	/**
	 * 用户提奖 + 销售信息
	 * @param currentUser
	 * @param state
	 * @param start
	 * @param end
	 * @return
	 */
	public AwardInfo getAwardInfo(String currentUser, int state, Date start, Date end) {
		MapResults<MShopOwnerInfoDto> user = imShopOwnerInfoManager
				.queryMShopBasicInfoByUserId(Long.valueOf(currentUser));
		AwardInfo info = new AwardInfo();
		BeanUtils.copyProperties(user.getBuessObj(), info);
		String imagePath = ImageUtils.userImageUrlInfo2(info.getImagePath(), userImage, agreement);
		info.setImagePath(imagePath);
		if(imagePath != null && imagePath.indexOf("http://") == 0) {
			imagePath = imagePath.replaceAll("http://", "https://");
			info.setImagePath(imagePath);
		}
		ResultEntity<AwardVo> myAward = iNewOrderService.getMyAward(Long.valueOf(currentUser), state, start, end);
		info.setSaleAmount(myAward.getBusinessObj().getSaleAmount());
		info.setAwardAmout(myAward.getBusinessObj().getAward());
		return info;
	}
	
	/**
	 * 列表
	 * @param currentUser
	 * @param pageNo
	 * @param state
	 * @param start
	 * @param end
	 * @return
	 */
	public List<AwardInfo> awardMasList(String currentUser, int pageNo, int state, Date start, Date end) {
		ResultEntity<Pagination<AwardVo>> masAward = iNewOrderService.getMasAward(Long.valueOf(currentUser), state,
				start, end, pageNo, 10);
		Pagination<AwardVo> page = masAward.getBusinessObj();
		List<AwardVo> list = page.getList();
		Map<Long, AwardVo> awarMap = new HashMap<>();
		List<Long> userList = new ArrayList<>();
		for (AwardVo awardVo : list) {
			userList.add(awardVo.getUserId());
			awarMap.put(awardVo.getUserId(), awardVo);
		}
		List<AwardInfo> newList = new ArrayList<>();
		MapResults<List<MShopOwnerInfoDto>> batchUser = imShopOwnerInfoManager
				.queryMShopBasicInfoByUserIdBatch(userList);
		if (batchUser != null && batchUser.getBuessObj() != null) {
			List<MShopOwnerInfoDto> batchBo = batchUser.getBuessObj();
			for (MShopOwnerInfoDto dto : batchBo) {
				AwardInfo ai = new AwardInfo();
				BeanUtils.copyProperties(dto, ai);
				String imagePath = ImageUtils.userImageUrlInfo2(ai.getImagePath(), userImage, agreement);
				ai.setImagePath(imagePath);
				if(imagePath != null && imagePath.indexOf("http://") == 0) {
					imagePath = imagePath.replaceAll("http://", "https://");
					ai.setImagePath(imagePath);
				}
				ai.setAwardAmout(awarMap.get(ai.getUserId()).getAward());
				ai.setSaleAmount(awarMap.get(ai.getUserId()).getSaleAmount());
				newList.add(ai);
			}
		}
		return newList;
	}
	
	
	public List<String> uidListTest() {
		List<String> uidList = new ArrayList<>();
		uidList.add("o0zUGt9Uk5sYLY1RgPIhTcwQBv0c");
		uidList.add("o0zUGt6VdH9g_D4U9HGATM1dVaF8");
		uidList.add("o0zUGt_Vv8GtKPEEB2Y4SFQ4FsAo");
		uidList.add("o0zUGt71m7AAGzN3Wgqjd8Wfly-A");
		uidList.add("o0zUGtx5hjssPP-dDPOXNOKuAmcU");
		uidList.add("o0zUGt8XUYp5H0J715G1nkEUFxH8");
		uidList.add("o0zUGt-OZRCzlXSihfQY7MBNU0Qk");
		uidList.add("o0zUGt-OZRCzlXSihfQY7MBNU0Qk");
		uidList.add("o0zUGt-OZRCzlXSihfQY7MBNU0Qk");
		uidList.add("o0zUGt6BxeiROM1Kh_TLtKq0ekAo");
		uidList.add("o0zUGtxzGxW8rRQpRxZMPhar9lWs");
		uidList.add("o0zUGt-yyY3Pdqd65lNQwI26ncoI");
		uidList.add("o0zUGt610d8iYj8Hv-ZDha61CAvg");
		uidList.add("o0zUGt2L9sx3W1SKcQt-fMl4RqHk");
		uidList.add("o0zUGt2L9sx3W1SKcQt-fMl4RqHk");
		uidList.add("o0zUGt7J6YqjLsJ4lv1DGn6KU9ws");
		uidList.add("o0zUGt6wSzmbX9YnSvYkXyYmmDyQ");
		uidList.add("o0zUGtyFzoRIXEdGZ3dAuLcg22rU");
		uidList.add("o0zUGt6wSzmbX9YnSvYkXyYmmDyQ");
		uidList.add("o0zUGtyiB56Z_n2Cbw_IM1PcgCok");
		uidList.add("o0zUGtyiB56Z_n2Cbw_IM1PcgCok");
		uidList.add("o0zUGt6FtyKVARCCuwHZJTqiGmrE");
		uidList.add("o0zUGt-OZRCzlXSihfQY7MBNU0Qk");
		uidList.add("o0zUGt_m_YlyyHh9LiQLnjq-Emxk");
		uidList.add("o0zUGt-OZRCzlXSihfQY7MBNU0Qk");
		uidList.add("o0zUGt34QmozRWX9x28kuOR5z2h0");
		uidList.add("o0zUGt_Vv8GtKPEEB2Y4SFQ4FsAo");
		uidList.add("o0zUGt9iTntpR9ipP4FxPmOTmpKQ");
		uidList.add("o0zUGt9iTntpR9ipP4FxPmOTmpKQ");
		return uidList;
	}
	
	public List<String> userIdListTest() {
		List<String> list = new ArrayList<>();
		list.add("72088600495");
		list.add("77430457046");
		list.add("72202215440");
		list.add("76957528193");
		list.add("75771511507");
		list.add("78164114400");
		list.add("73284461751");
		list.add("73284461751");
		list.add("73284461751");
		list.add("79099495502");
		list.add("72111962829");
		list.add("75853938433");
		list.add("76617968594");
		list.add("72740928491");
		list.add("72740928491");
		list.add("75754948238");
		list.add("78078938497");
		list.add("73631939619");
		list.add("78078938497");
		list.add("72003777615");
		list.add("72003777615");
		list.add("72840346035");
		list.add("73284461751");
		list.add("72836049311");
		list.add("73284461751");
		list.add("77768477570");
		list.add("72202215440");
		list.add("71564390533");
		list.add("71564390533");
		return list;
		
		
	}

	
}
