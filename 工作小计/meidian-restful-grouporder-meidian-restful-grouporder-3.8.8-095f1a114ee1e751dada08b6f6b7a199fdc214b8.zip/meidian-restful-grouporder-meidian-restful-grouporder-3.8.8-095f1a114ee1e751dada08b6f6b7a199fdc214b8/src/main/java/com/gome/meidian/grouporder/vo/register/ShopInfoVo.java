package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

public class ShopInfoVo implements Serializable {

	private static final long serialVersionUID = -8287763396408998743L;
	
	@NotNull(message = "{shop.task.param.initUserId.notNull}")
	private Long inviteUserId;
	@NotBlank(message = "{shop.task.param.name.notBlank}")
	@Size(min=2,max=30,message="店铺名称长度必须在2-20之间")
	private String name;
	@NotBlank(message = "{base.user.mobile.notBlank}")
	private String phoneNo;
	
	private String weChat;
	private Long provinceId;
	private Long cityId;
	private Long countyId;
	private Integer userSex;
	private String userHobby;
	
	public Long getInviteUserId() {
		return inviteUserId;
	}
	public void setInviteUserId(Long inviteUserId) {
		this.inviteUserId = inviteUserId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getWeChat() {
		return weChat;
	}
	public void setWeChat(String weChat) {
		this.weChat = weChat;
	}
	public Long getProvinceId() {
		return provinceId;
	}
	public void setProvinceId(Long provinceId) {
		this.provinceId = provinceId;
	}
	public Long getCityId() {
		return cityId;
	}
	public void setCityId(Long cityId) {
		this.cityId = cityId;
	}
	public Long getCountyId() {
		return countyId;
	}
	public void setCountyId(Long countyId) {
		this.countyId = countyId;
	}
	public Integer getUserSex() {
		return userSex;
	}
	public void setUserSex(Integer userSex) {
		this.userSex = userSex;
	}
	public String getUserHobby() {
		return userHobby;
	}
	public void setUserHobby(String userHobby) {
		this.userHobby = userHobby;
	}

}
