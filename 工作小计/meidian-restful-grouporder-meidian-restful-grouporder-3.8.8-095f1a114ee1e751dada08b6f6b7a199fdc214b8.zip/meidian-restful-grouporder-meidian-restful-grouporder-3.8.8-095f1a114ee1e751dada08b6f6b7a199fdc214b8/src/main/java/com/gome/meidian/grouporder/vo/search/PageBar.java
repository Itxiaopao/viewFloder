package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;

public class PageBar implements Serializable{
	private static final long serialVersionUID = 7372568317126199856L;
	private String totalCount;
	private String totalPage;
	private String pageNumber;
	private String pageSize;
	public String getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}
	public String getTotalPage() {
		return totalPage;
	}
	public void setTotalPage(String totalPage) {
		this.totalPage = totalPage;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getPageSize() {
		return pageSize;
	}
	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}
	

}
