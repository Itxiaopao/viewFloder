package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotBlank;

/**
 * 搜索入参
 * @author lishouxu-ds
 *
 */
public class SearchInfoReqVo implements Serializable{

	private static final long serialVersionUID = 7041729329055779780L;
	//@NotBlank(message = "{param.error}")
	private String keyWord; //关键字  必填
	
	private Integer sale;//促销  400: 组团  500:超级返
	
	private Integer currentPage;//当前页码
	
	private Integer pageSize;//每页多少条
	
	private Integer sortBy;//排序
	
	private String siteModule;//站点
	
	private String areaCode;
	
	private String organizationId;
	@NotBlank(message = "{param.error}")
	private String threeRegionId;  //必填
	
	private String mid;
	
	private String remain;// 纠错词
	
	private String catId;//分类Id
	
	private List<FilterValListVO> filterConList;//筛选参数
	
	private List<QueryCatVo> queryCatList;//类目集合
	
	private String fourRegionId; //四级区域码  定金查询
	
	private String storeCode; //门店编码 定金查询

	public List<FilterValListVO> getFilterConList() {
		return filterConList;
	}

	public void setFilterConList(List<FilterValListVO> filterConList) {
		this.filterConList = filterConList;
	}

	public String getCatId() {
		return catId;
	}

	public void setCatId(String catId) {
		this.catId = catId;
	}

	public String getRemain() {
		return remain;
	}

	public void setRemain(String remain) {
		this.remain = remain;
	}

	public Integer getSale() {
		return sale;
	}

	public void setSale(Integer sale) {
		this.sale = sale;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}



	public String getSiteModule() {
		return siteModule;
	}

	public void setSiteModule(String siteModule) {
		this.siteModule = siteModule;
	}

	public String getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}


	public String getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public String getKeyWord() {
		return keyWord;
	}

	public void setKeyWord(String keyWord) {
		this.keyWord = keyWord;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public Integer getSortBy() {
		return sortBy;
	}

	public void setSortBy(Integer sortBy) {
		this.sortBy = sortBy;
	}

	public String getThreeRegionId() {
		return threeRegionId;
	}

	public void setThreeRegionId(String threeRegionId) {
		this.threeRegionId = threeRegionId;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public List<QueryCatVo> getQueryCatList() {
		return queryCatList;
	}

	public void setQueryCatList(List<QueryCatVo> queryCatList) {
		this.queryCatList = queryCatList;
	}

	public String getFourRegionId() {
		return fourRegionId;
	}

	public void setFourRegionId(String fourRegionId) {
		this.fourRegionId = fourRegionId;
	}

	public String getStoreCode() {
		return storeCode;
	}

	public void setStoreCode(String storeCode) {
		this.storeCode = storeCode;
	}

	


	
	
	
	
}
