package com.gome.meidian.grouporder.controller;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.UserAndRegisterRiskSwitchManager;
import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.utils.*;
import com.gome.meidian.grouporder.vo.wechatLogin.DoSNSLoginVO;
import com.gome.meidian.grouporder.vo.wechatLogin.WeChatOpenIdAndUserIdVO;
import com.gome.meidian.grouporder.vo.wechatLogin.WeChatUserInfo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;
import com.gome.meidian.user.entity.UserRelation;
import com.gome.memberCore.lang.model.GomeSNSUser;
import com.gome.userCenter.common.constants.LoginConstants;
import com.gome.userCenter.facade.login.ISNSLoginFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UserInfo;
import com.gome.userCenter.model.UserLoginResult;
import com.gome.userCenter.model.enu.CompanyNameEnum;
import org.hibernate.validator.constraints.NotBlank;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.constraints.Pattern;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * 第三方登录接口
 *
 */
@RestController
@Validated
@RequestMapping("/v1/wechatLogin")
public class WechatLoginController {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource(name = "gcache")
	private Gcache gcache;

	@Resource(name = "userCenter")
	private Gcache userCenter;


	//缓存中登录回跳地址前缀
	public static  final  String  BACK_URL="callBackUrl_";
	//用户授权请求接口TOKEN参数
	public static  final  String  TOKEN_KEY="wxChat_User_Token";

	@Autowired
	private WechatLoginManager wechatLoginManager;

	@Autowired
	ISNSLoginFacade snsLoginFacade;

	@Autowired
	private HttpClientUtil httpClientUtil;


	@Autowired
	AuthencationUtils authencationUtils;

	@Autowired
	UserAndRegisterRiskSwitchManager userAndRegisterRiskSwitchManager;

	@Value("${cookie.path}")
	private String path;
	@Value("${cookie.domain}")
	private String domain;
	@Value("${cookie.time}")
	private int time;


	/**
	 * 设置登录回跳地址
	 * @param uuid
	 * @param callBackUrl
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/setCallBackUrl", method = RequestMethod.POST)
	public ResponseJson setCallBackUrl(
			@NotBlank(message = "{param.error}") @RequestParam("uuid") String uuid,
			@NotBlank(message = "{param.error}") @RequestParam("callBackUrl") String callBackUrl,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		String key = BACK_URL+uuid;
		userCenter.setex(key,3600,callBackUrl);
		return response;
	}

	/**
	 * 获取登录回跳地址
	 * @param uuid
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getCallBackUrl", method = RequestMethod.GET)
	public ResponseJson getCallBackUrl(
			@NotBlank(message = "{param.error}") @RequestParam("uuid") String uuid,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		String key = BACK_URL+uuid;
		String callBackUrl=userCenter.get(key);
		response.setData(callBackUrl);
		return response;
	}



	/**
	 * 校验手机号是否可用
	 * @param mobile
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/checkMobileIsCanUse", method = RequestMethod.GET)
	public ResponseJson  checkMobileIsCanUse(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		Object object=wechatLoginManager.checkMobileIsCanUse(mobile);
		response.setData(object);

		return response;
	}

	/**
	 * 授权信息获取UnionId  OpenId  微信昵称  微信头像
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/authorize/user/getToken", method = RequestMethod.GET)
	public ResponseJson getAuthUserToken(String time,HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		String token;
		try {
			token = wechatLoginManager.getToken();
		} catch (Exception e) {
			logger.info("WechatLoginManager-getToken 生成失败");
			throw new ServiceException("wechat.login.auth.token.error");
		}
		/*String token=userCenter.get(TOKEN_KEY);
		if(null==token){
			try {
				token = wechatLoginManager.getToken();
			} catch (Exception e) {
				logger.info("WechatLoginManager-getToken 生成失败");
				throw new ServiceException("wechat.login.auth.token.error");
			}
			userCenter.setex(TOKEN_KEY,250,token);
		}*/
		response.setData(token);
		return response;
	}



	/**
	 * 三方登录
	 * @param userInfo     用户信息密文
	 * @param userImgUrl   用户头像
	 * @param distinctId   灯塔埋码
	 * @param createType   新增类型
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/doSNSLogin", method = RequestMethod.POST)
	public ResponseJson doSNSLogin(
			@NotBlank(message = "{param.error}") @RequestParam("userInfo") String userInfo,
			String userImgUrl,
			@NotBlank(message = "{param.error}") @RequestParam("distinctId") String distinctId,
			String createType,
			HttpServletResponse response,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		DoSNSLoginVO vo=wechatLoginManager.doSNSLogin(userImgUrl,userInfo,distinctId,createType,request, response);
		result.setData(vo);
		return result;
	}




	/**
	 * 微信新用户获取验证码
	 * @param mobile
	 * @param ufpd
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/newWeChat/getSmsCode", method = RequestMethod.POST)
	public ResponseJson getNewWeChatSmsCode(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			@CookieValue(value = "ufpd", required = true) String ufpd,
			HttpServletRequest request)
			throws MeidianException {
		//^(13\\d{9}|14\\d{9}|15\\d{9}|16\\d{9}|17\\d{9}|18\\d{9}|19\\d{9})$
		ResponseJson response = new ResponseJson();
		Object object=wechatLoginManager.getNewWeChatSmsCode(mobile,ufpd,request);
		response.setData(object);
		return response;
	}


	/**
	 * 微信新用户绑定国美账号
	 * @param mobile 手机号
	 * @param code   验证码
	 * @param userInfo   微信信息密文
	 * @param headImageUrl 微信头像
	 * @param response
	 * @param createType  新增渠道 签到红包等
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/newWeChat/bindGomeAccount", method = RequestMethod.POST)
	public ResponseJson newWeChatBindGomeAccount(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			@NotBlank(message = "{param.error}") @RequestParam("code") String code,
			@NotBlank(message = "{param.error}") @RequestParam("userInfo") String userInfo,
			String headImageUrl,
			HttpServletResponse response,
			String createType,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=wechatLoginManager.newWeChatBindGomeAccount(mobile,code,headImageUrl,userInfo,createType,request,response);
		result.setData(object);
		return result;
	}


	/**
	 * 新注册用户微信环境下做默认绑定微信号动作
	 * @param mobile
	 * @param userInfo
	 * @param headImageUrl
	 * @param response
	 * @param createType
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/newWeChat/newRegisterAccountBindWeChat", method = RequestMethod.POST)
	public ResponseJson newRegisterAccountBindWeChat(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			@NotBlank(message = "{param.error}") @RequestParam("userInfo") String userInfo,
			String headImageUrl,
			@CookieValue(value = "SCN", required = false) String scn,
			HttpServletResponse response,
			String createType,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		logger.info("newRegisterAccountBindWeChat-userInfo:{} headImageUrl:{}",userInfo,headImageUrl);
		Object object=wechatLoginManager.weChatBindNewRegisterGomeAccount(mobile,headImageUrl,userInfo,createType,request,response);
		result.setData(object);
		return result;
	}

	/**
	 * 微信老用户没有绑定关系-绑定国美账号
	 * @param mobile
	 * @param ufpd
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/oldWeChat/getOldWeChatSmsCode", method = RequestMethod.POST)
	public ResponseJson getOldWeChatSmsCode(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			@CookieValue(value = "ufpd", required = true) String ufpd,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		Object object=wechatLoginManager.getNewWeChatSmsCode(mobile,ufpd,request);
		response.setData(object);
		return response;
	}


	/**
	 * 第三方账号绑定
	 * @param mobile
	 * @param code
	 * @param headImageUrl
	 * @param createType
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/oldWeChat/noRelationToBindGomeAccount", method = RequestMethod.POST)
	public ResponseJson oldWeChatNoRelationToBindGomeAccount(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			@NotBlank(message = "{param.error}") @RequestParam("code") String code,
			String headImageUrl,
			@NotBlank(message = "{param.error}") @RequestParam("userInfo") String userInfo,
			@CookieValue(value = "SCN", required = false) String scn,
			HttpServletResponse response,
			String createType,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object  object=wechatLoginManager.oldWeChatNoRelationToBindGomeAccount(scn,mobile,code,headImageUrl,userInfo,createType,request,response);
		result.setData(object);
		return result;
	}


	/**
	 * 微信老用户完善手机号获取验证码
	 * @param mobile
	 * @param ufpd
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/oldWeChat/getCompleteMobileSmsCode", method = RequestMethod.POST)
	public ResponseJson getCompleteMobileSmsCode(
			@NotBlank(message = "{param.error}") @RequestParam("mobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String mobile,
			@CookieValue(value = "ufpd", required = true) String ufpd,
			@CookieValue(value = "SCN", required = false) String scn,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		Object object=wechatLoginManager.getCompleteMobileSmsCode(mobile,ufpd,request);
		response.setData(object);
		return response;
	}


	/**
	 * 微信老用户完善手机号激活手机号
	 * @param newMobile
	 * @param scn
	 * @param code
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/oldWeChat/updateMobileAndIsActived", method = RequestMethod.POST)
	public ResponseJson updateMobileAndIsActived(
			@NotBlank(message = "{param.error}") @RequestParam("newMobile")
			@Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")String newMobile,
			@CookieValue(value = "SCN", required = true) String scn,
			@NotBlank(message = "{param.error}") @RequestParam("code") String code,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		Object object=wechatLoginManager.updateMobileAndIsActived(scn,newMobile,code,request);
		response.setData(object);
		return response;
	}


	/**
	 * 用户池记录用户登录信息
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/user/recordInfoToUserCenter", method = RequestMethod.POST)
	public ResponseJson recordUserToAll(
			@CookieValue(value = "SCN", required = false) String scn,
			String createType,
			@CookieValue(value = "Channel", required = false) String Channel,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson result=new ResponseJson();
		
		if(null != Channel && !Channel.equals("")){
			if(Channel.equals(GroupOrderConstants.CHANNEL_IOS_APP) 
					|| Channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP))
				return result;
		}
		
		wechatLoginManager.recordUserToUserCenterByScn(scn,createType,request);
		return result;
	}


	/**
	 * 更新用户绑定关系
	 * @param scn
	 * @param userInfo
	 * @param userOpenId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/user/updateBindOpenId", method = RequestMethod.POST)
	public ResponseJson updateBindOpenId(
			@CookieValue(value = "SCN", required = false) String scn,
			@NotBlank(message = "{param.error}") @RequestParam("userInfo") String userInfo,
			@RequestParam("userOpenId") Long userOpenId)
			throws MeidianException {
		ResponseJson result=new ResponseJson();
		wechatLoginManager.updateBindOpenId(scn,userOpenId,userInfo);
		return result;
	}



	/**
	 * 退出登录
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/loginOut", method = { RequestMethod.POST, RequestMethod.GET })
	public ResponseJson loginOut(
			@CookieValue(value = "SCN", required = true) String scn,
			@NotBlank(message = "{param.error}") @RequestParam("time") String time,
			HttpServletRequest request,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object scnResult=authencationUtils.loginOut(scn);
		CookieUtils.setCookie(response,CookieUtils.COOKIE_SCN,null,path,domain,0);
		result.setData(scnResult);
		return result;
	}


	/**
	 * 新增老用户
	 * @param userInfo
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/oldWeChat/activateUserToOldWeChat", method = RequestMethod.GET)
	public ResponseJson activateUserToOldWeChat(
			@NotBlank(message = "{param.error}") @RequestParam("userInfo") String userInfo,
			HttpServletRequest request)
			throws MeidianException {
		String sNSUserName="";
		String sNSUserId="";
		WeChatUserInfo weChatUserInfo=null;
		try {
			//userInfo=URLDecoder.decode(userInfo,"UTF-8");
			userInfo=MobileDES.decryptDES(userInfo,WechatLoginManager.WX_TOKEN.substring(0,8));
			weChatUserInfo=com.alibaba.fastjson.JSON.parseObject(userInfo, WeChatUserInfo.class);
			sNSUserName=weChatUserInfo.getNickname();
			sNSUserId=weChatUserInfo.getUnionid();

		} catch (Exception e) {
			logger.info("WechatLoginManager-doSNSLogin-decrypt-fail:-userInfo:{}  e：{}",userInfo,e);
			throw new ServiceException("wechat.login.doSNSLogin.des.error");
		}

		ResponseJson response = new ResponseJson();
		RequestParams requestParams = new RequestParams("gomeShopWap", "10.57.29.216", "52232", null, null, null);// 第一个参数管家可以传“gomegjWap”或者“gomegjMobile”
		HashMap<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put(LoginConstants.SNS_UNION_ID_KEY, sNSUserId); // 微信的unionID 必传参数
		paramsMap.put(LoginConstants.SNS_REGISTER_SOURCE_KEY, "wechat"); // 微信来源，固定传“wechat”
		GomeSNSUser gomeSNSUser = new GomeSNSUser(null, "wechat", sNSUserId, sNSUserName); // 第二个参数固定传“wechat” 昵称必传
		// 参数描述：第三方用户对象、请求参数、特殊参数
		paramsMap.put(LoginConstants.COMPANYNAME, CompanyNameEnum.gomeOnLine.name());// 登录时固定传递该字符串“gomeOnLine”
		UserLoginResult<UserInfo> result = snsLoginFacade.doSNSLogin(gomeSNSUser, requestParams, paramsMap);
		int code = result.getCode();// 登录成功失败代码
		String message = result.getMessage();// 登录成功失败信息
		response.setData(result);
		return response;
	}


	/**
	 * 风控开关开启和关闭
	 * @param riskKey
	 * @param status
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/userRiskSwitchHandle", method = RequestMethod.GET)
	public ResponseJson userRiskSwitchHandle(
			String riskKey,
			String  status,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		String  statusResult =userAndRegisterRiskSwitchManager.riskSwitchOnOrOff(riskKey,status,request);
		response.setData(statusResult);
		return response;
	}


	/**
	 * 测试提供接口
	 * @param userId
	 * @param openId
	 * @param time
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/updateOpenUserRelationUpdateTime", method = RequestMethod.GET)
	public ResponseJson updateOpenUserRelationUpdateTime(
			String userId,
			String openId,
			String  time,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		//String  userId="100049397501";
		//String  openId="oJ5y11BoPMEEEkr3tOjdi3Xd-bEM";
		//String  time="2018-12-14 00:00:00";
		Boolean flag=false;
		String  key = BindInfoUpdateThread.USER_OPENID_ID_SET + ":" + RedisKeyUtils.getHKey(openId);
		String  relationStr=userCenter.hget(key,openId);
		try {
			List<UserRelation> list = null;
			if(org.apache.commons.lang3.StringUtils.isNotBlank(relationStr)) {
				list = JSONObject.parseArray(relationStr, UserRelation.class);
			}
			List<UserRelation>  newList=new ArrayList<>();
			for (UserRelation userRelation:list) {
				SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date1=format.parse(time);//str表示yyyy年MM月dd HH:mm:ss格式字符串
				userRelation.setCtime(date1);
				userRelation.setUtime(date1);
				newList.add(userRelation);
			}
			if(list != null && list.size() > 0) {
				userCenter.hset(key, openId, JSONObject.toJSONString(newList));
			}
		}catch(Exception e) {
			e.printStackTrace();

		}
		if(null!=userId&&null!=openId) {
			if(StringUtils.isNotBlank(relationStr)){
				List<UserRelation> userRelations = JSONObject.parseArray(relationStr, UserRelation.class);
				if(null!=userRelations&&userRelations.size()>0){
					for (UserRelation userRelation:userRelations) {
						String  dbOpenId=userRelation.getOpenId();
						String  dbUserId=userRelation.getUserId();
						if(openId.equals(dbOpenId)){
							Date uptime=userRelation.getUtime();
							long  time1=uptime.getTime();
							long  time2=new Date().getTime();
							long days=WechatLoginManager.getDistanceDays(time2,time1);
							if(days>1&&dbUserId.equals(userId)){
								//唯一需要变更绑定关系
								flag=true;
								break;
							}
						}
					}
				}
			}
		}
		response.setData(flag);
		return response;
	}




	/**
	 * 测试 清除SCN
	 * @param httpServletRequest
	 * @param httpServletResponse
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/refreshSCNValue", method = RequestMethod.GET)
	public ResponseJson refreshSCNValue(String value,String path,String domain,Integer time,
			HttpServletRequest  httpServletRequest,
			HttpServletResponse  httpServletResponse)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		if(null==path){
			path=this.path;
		}
		if(null==domain){
			domain=this.domain;
		}
		if(null==time){
			time=this.time;
		}
		if(null==value){
			value="测试SetCookie";
		}
		logger.info("scn-refreshSCNValue setCookie scn:{} path:{},domain:{} time:{}",null,path,domain,time);
		CookieUtils.setCookie(httpServletResponse,CookieUtils.COOKIE_SCN,value,path,domain,time);
		//拦截器会自动拦截，延长SCN时间
		return response;
	}


	/**
	 * 通过过滤器刷新Cookies时间
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/refreshCookieFilter", method = RequestMethod.GET)
	public ResponseJson refreshCookieFilter()
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		return response;
	}


	/**
	 * 通过过滤器刷新Cookies时间
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/redirectUrl", method = RequestMethod.GET)
	public void redirectUrl(HttpServletResponse httpServletResponse,
							String value)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		try {
			if(null==value){
				value="http://www.baidu.com";
			}
			httpServletResponse.sendRedirect(value);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	/**
	 * 测试使用-解密token 查看时间戳
	 * @param token
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/decodeToken", method = RequestMethod.POST)
	public ResponseJson decodeToken(
			@NotBlank(message = "{param.error}") @RequestParam("token") String token,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		String token1=wechatLoginManager.decodeToken(token);
		result.setData(token1);
		return result;
	}



	/**
	 * 测试使用保存关系到无线数据库
	 * @param
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/user/saveBindOpenId", method = RequestMethod.POST)
	public ResponseJson updateBindOpenId(@RequestBody WeChatOpenIdAndUserIdVO  weChatOpenIdAndUserIdVO)
			throws MeidianException {
		String reponse="";
		if(null!=weChatOpenIdAndUserIdVO){
			String  request=com.alibaba.fastjson.JSON.toJSONString(weChatOpenIdAndUserIdVO);
			Map map=new  HashMap<>();
			map.put("body",request);
			reponse=httpClientUtil.doFromPost("http://wx.wireless.api/bind/user",map);
		}

		ResponseJson result=new ResponseJson();
		result.setData(reponse);

		return result;
	}

	/**
	 * 测试使用制造微信老用户
	 * @param unionId
	 * @param nickname
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/oldWeChat/activateUnionIdToOldGomeUserNoRelation", method = RequestMethod.POST)
	public ResponseJson activateUser(
			@NotBlank(message = "{param.error}") @RequestParam("unionId") String unionId,
			@NotBlank(message = "{param.error}") @RequestParam("nickname") String nickname,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		String  unionID=unionId;
		RequestParams requestParams = new RequestParams("gomeShopWap", "10.57.29.216", "52232", null, null, null);// 第一个参数管家可以传“gomegjWap”或者“gomegjMobile”
		HashMap<String, Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put(LoginConstants.SNS_UNION_ID_KEY, unionID); // 微信的unionID 必传参数
		paramsMap.put(LoginConstants.SNS_REGISTER_SOURCE_KEY, "wechat"); // 微信来源，固定传“wechat”
		GomeSNSUser gomeSNSUser = new GomeSNSUser(null, "wechat", unionID, nickname); // 第二个参数固定传“wechat” 昵称必传
		// 参数描述：第三方用户对象、请求参数、特殊参数
		paramsMap.put(LoginConstants.COMPANYNAME, CompanyNameEnum.gomeOnLine.name());// 登录时固定传递该字符串“gomeOnLine”
		UserLoginResult<UserInfo> result = snsLoginFacade.doSNSLogin(gomeSNSUser, requestParams, paramsMap);
		int code = result.getCode();// 登录成功失败代码
		String message = result.getMessage();// 登录成功失败信息
		response.setData(result);
		return response;
	}


	/**
	 * 分享链接处理
	 * @param url
	 * @param response
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/shareGet", method = RequestMethod.POST)
	public ResponseJson shareGet(
			@NotBlank(message = "{param.error}") @RequestParam("url") String url,
			HttpServletResponse response)
			throws MeidianException {
		ResponseJson result = new ResponseJson();
		Object object=wechatLoginManager.handleShareToken(url);
		result.setData(object);
		return result;
	}


}
