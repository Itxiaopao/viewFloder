package com.gome.meidian.grouporder.vo.app;

import java.io.Serializable;
/**
 * 分享卡片信息入参
 * @author lishouxu-ds
 *
 */
public class ShareCardParamVo implements Serializable{
	private static final long serialVersionUID = 8363688205121809316L;
	private String areacode;//	二级区域码	string	N	
	private String pagecode;//	活动页编码	string	Y	
	private String skuId;//	skuid	string	Y	
	private String couponId;//	券id	string	Y	
	private String plan_Id;//	计划id	string	Y	
	private String couponType;//	券类型	string	Y	
	private String activityId;//	活动id	string	Y	
	private String groupId;//	组团id	string	Y	
	private String pageType;//要分享的页面
	private String activityShareImage;//活动分享图
	private String landingPage;//落地页
	private String materialImages;//活动素材页分享的海报图片
	private String extend;//扩展字段
	private String cmpid;
	public String getAreacode() {
		return areacode;
	}
	public void setAreacode(String areacode) {
		this.areacode = areacode;
	}
	public String getPagecode() {
		return pagecode;
	}
	public void setPagecode(String pagecode) {
		this.pagecode = pagecode;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getCouponId() {
		return couponId;
	}
	public void setCouponId(String couponId) {
		this.couponId = couponId;
	}
	public String getPlan_Id() {
		return plan_Id;
	}
	public void setPlan_Id(String plan_Id) {
		this.plan_Id = plan_Id;
	}
	public String getCouponType() {
		return couponType;
	}
	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getPageType() {
		return pageType;
	}
	public void setPageType(String pageType) {
		this.pageType = pageType;
	}
	public String getActivityShareImage() {
		return activityShareImage;
	}
	public void setActivityShareImage(String activityShareImage) {
		this.activityShareImage = activityShareImage;
	}
	public String getLandingPage() {
		return landingPage;
	}
	public void setLandingPage(String landingPage) {
		this.landingPage = landingPage;
	}
	public String getMaterialImages() {
		return materialImages;
	}
	public void setMaterialImages(String materialImages) {
		this.materialImages = materialImages;
	}
	public String getExtend() {
		return extend;
	}
	public void setExtend(String extend) {
		this.extend = extend;
	}
	public String getCmpid() {
		return cmpid;
	}
	public void setCmpid(String cmpid) {
		this.cmpid = cmpid;
	}
	
	
	
	

}
