package com.gome.meidian.grouporder.manager;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.gome.meidian.grouporder.utils.RequestUtils;

import redis.Gcache;

@Service
public class GroupOrderStatusManager {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Resource(name = "gcache")
	private Gcache gcache;
	
	/**
	 * 领券风控开关
	 * @param status
	 * @return
	 */
	@SuppressWarnings("deprecation")
	public String riskCouponSwitch(String status, HttpServletRequest request){
		String key = "meidian-coupon-risk-switch";
		String ip = RequestUtils.getIP(request);
		String statusStr = gcache.get(key);
		
		//取消开关
		if(statusStr != null && status.equals("2")){
			logger.info("领券风控开关取消------时间：" + new Date().toLocaleString() + ", IP：" + ip + ", 原值：" + statusStr);
			gcache.del(key);
			return status;
		}
		
		if(statusStr == null || !statusStr.equals(status)){
			logger.info("领券风控开关状态变更------时间：" + new Date().toLocaleString() + ", IP：" + ip + ", 原值：" + statusStr + ", 现值：" + status);
			gcache.set(key, status);
		}
		return status;
	}
}
