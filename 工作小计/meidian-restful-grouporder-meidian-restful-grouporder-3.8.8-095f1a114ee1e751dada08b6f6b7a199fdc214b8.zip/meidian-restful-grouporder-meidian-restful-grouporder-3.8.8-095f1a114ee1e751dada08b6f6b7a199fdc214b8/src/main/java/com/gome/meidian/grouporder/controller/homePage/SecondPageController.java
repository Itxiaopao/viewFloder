package com.gome.meidian.grouporder.controller.homePage;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.homePageManager.HomePageManager;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.homePage.SecondPageVo;
import com.gome.meidian.grouporder.vo.meidiancms.Model;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.sso.model.UserInfoCache;

import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import com.gomeplus.bs.interfaces.cms2.vo.business.pm.page.PageSecondI;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;


/**
 * 2019-01-11 APP 二级活动页接口
 *
 */
@RestController
@Validated
@RequestMapping("/v1/secondPage")
public class SecondPageController {


	@Resource(name = "gcache")
	private Gcache gcache;

	@Resource(name = "userCenter")
	private Gcache userCenter;

	@Value("${gcache.expireTime}")
	private  Integer expireTime;//40秒
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	@Value("${gome.defaultStoreCode}")
	private String defaultStoreCode; // 默认门店，西坝河
	
	@Autowired
	private HomePageManager  homePageManager;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private PropertiesConfig propertiesConfig;

	/**
	 * 获取二级页面信息
	 * @param storeCode
	 * @param areaCode
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getSecondPageInfo")
	public ResponseJson getHomePageInfo(
			@RequestParam(value = "pageCode") String  pageCode,
			@RequestParam(value = "storeCode") String storeCode,
			@RequestParam(value = "areaCode") String  areaCode)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		StringBuilder sb=new StringBuilder();
		sb.append(storeCode).append("_").append(pageCode);
		sb.append("_").append(areaCode);
		String value=null;
		value=gcache.get("secondPage:getSecondPageInfo:store_page_area:"+sb.toString());
		SecondPageVo secondPageVo=null;
		if(null==value){
			secondPageVo=homePageManager.getSecondDetailInfo(storeCode,pageCode,areaCode);
			gcache.setex("secondPage:getSecondPageInfo:store_page_area:"+sb.toString(),expireTime, JSONUtils.toJSONString(secondPageVo));
		}else{
			secondPageVo= JSONObject.parseObject(value,SecondPageVo.class);
		}
		response.setData(secondPageVo);
		return response;
	}

	/**
	 * 获取二级页面信息
	 * @param pageCode
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	@GetMapping("/getSecondPageInfoList")
	public ResponseJson getSecondPageInfoList(
			@RequestParam(value = "pageCode") String  pageCode)
			 {
		ResponseJson response = new ResponseJson();
		StringBuilder sb=new StringBuilder();
                 PageInfo pageInfo=null;
                 pageInfo =homePageManager.getSecondInfo(pageCode);
		response.setData(pageInfo);
		return response;
	}
	
	/**
	 * 活动页
	 * @param StoreCode
	 * @param Channel
	 * @param storeCode
	 * @param channel
	 * @param pageCode
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getActivityPageInfo", method = RequestMethod.GET)
	public ResponseJson getActivityPageInfo(
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
			@CookieValue(value = "SCN", required = false) String scn,
			@RequestParam(value = "storeCode", required = false) String storeCode,
			@RequestParam(value = "townCode", required = false) String townCode,
			@RequestParam(value = "channel", required = false) String channel,
			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request
			)throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		
//		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
		int chan = ChannelUtils.getCmsChannel(MeidianEnvironment.getChannel(), channel);

		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);
//		String arCode = null;
//		if (null == AreaCode || AreaCode.equalsIgnoreCase("")){
//			if(null == areaCode || areaCode.equalsIgnoreCase("")){
//				arCode = defaultAreaCode;
//			}else {
//				arCode = areaCode;
//			}
//		}else {
//			arCode = AreaCode;
//		}
		//是否登录
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		Long userId = null;
		if(null != userInfo && StringUtils.isNotEmpty(userInfo.getId())){
			userId = Long.parseLong(userInfo.getId());
		}
		
		Model model = null;
		if(null == propertiesConfig.getGcacheNew().get("meidianActivityPageOnOff")){
			model = homePageManager.getActivityPageInfo(userId, stoCode, pageCode, MeidianEnvironment.getKey("priceReqAreaCode"), townCode, chan, ua, MeidianEnvironment.getPPI());
		}else{
			String key = "meidianActivityPage_" + userId + "_" + pageCode + "_" + stoCode + "_" + MeidianEnvironment.getKey("priceReqAreaCode") + "_" + townCode + "_" + MeidianEnvironment.getKey("priceReqStoreCode") + "_" + chan;
			model = JSONObject.parseObject(propertiesConfig.getGcacheNew().get(key), Model.class);
			if(null == model){
				model = homePageManager.getActivityPageInfo(userId, stoCode, pageCode, MeidianEnvironment.getKey("priceReqAreaCode"), townCode, chan, ua, MeidianEnvironment.getPPI());
				propertiesConfig.getGcacheNew().setex(key, 10 * 60, JSONUtils.toJSONString(model).getBytes());
			}
		}
		
		response.setData(model);
		return response;
	}
	
	/**
	 * 素材
	 * @param StoreCode
	 * @param Channel
	 * @param ppi
	 * @param AreaCode
	 * @param scn
	 * @param storeCode
	 * @param channel
	 * @param pageCode
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
//	@RequestMapping(value = "/material", method = RequestMethod.GET)
//	public ResponseJson material(
//			@CookieValue(value = "storeCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "SCN", required = false) String scn,
//			@RequestParam(value = "storeCode", required = false) String storeCode,
//			@RequestParam(value = "channel", required = false) String channel,
//			@NotBlank(message = "{param.error}") @RequestParam(value = "pageCode") String pageCode,
//			@RequestParam(value = "areaCode", required = false) String areaCode,
//			HttpServletRequest request
//			)throws MeidianException {
//		ResponseJson response = new ResponseJson();
//		// 获取设备
//		Byte ua = ImageUtils.userAgentChannel(request);
//		
//		String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
//		int chan = ChannelUtils.getCmsChannel(Channel, channel);
//		
//		String arCode = null;
//		if (null == AreaCode || AreaCode.equalsIgnoreCase("")){
//			if(null == areaCode || areaCode.equalsIgnoreCase("")){
//				arCode = defaultAreaCode;
//			}else {
//				arCode = areaCode;
//			}
//		}else {
//			arCode = AreaCode;
//		}
//		//是否登录
//		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
//		Long userId = null;
////		if(null != userInfo && StringUtils.isNotEmpty(userInfo.getId())){
////			userId = Long.parseLong(userInfo.getId());
////		}
//		response.setData(homePageManager.material(userId, stoCode, pageCode, arCode, chan, ua, ppi));
//		return response;
//	}




}
