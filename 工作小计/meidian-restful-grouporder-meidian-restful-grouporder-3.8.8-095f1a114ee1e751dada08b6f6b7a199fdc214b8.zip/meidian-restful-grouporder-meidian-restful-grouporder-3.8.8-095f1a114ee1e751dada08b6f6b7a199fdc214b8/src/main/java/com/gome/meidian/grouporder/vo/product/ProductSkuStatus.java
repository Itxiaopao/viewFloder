package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;
import java.util.List;

public class ProductSkuStatus implements Serializable{

	private static final long serialVersionUID = 3805608735160135275L;

	private String productId;
	private List<SkuStatus> skuStatus;
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public List<SkuStatus> getSkuStatus() {
		return skuStatus;
	}
	public void setSkuStatus(List<SkuStatus> skuStatus) {
		this.skuStatus = skuStatus;
	}
	
	
}
