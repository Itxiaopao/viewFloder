package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.List;

/**
 * 用户足迹初始化
 * 
 * @author libinbin-ds
 *
 */
public class MyFootprintVo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1086152413476616113L;
	
	private UserSimpleInfo user;
	private List<UserFootprintInfo> footsPoints;
	
	
	public MyFootprintVo(UserSimpleInfo user, List<UserFootprintInfo> footsPoints) {
		this.user = user;
		this.footsPoints = footsPoints;
	}

	public UserSimpleInfo getUser() {
		return user;
	}

	public void setUser(UserSimpleInfo user) {
		this.user = user;
	}

	public List<UserFootprintInfo> getFootsPoints() {
		return footsPoints;
	}

	public void setFootsPoints(List<UserFootprintInfo> footsPoints) {
		this.footsPoints = footsPoints;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public MyFootprintVo() {
		super();
	}

	
}
