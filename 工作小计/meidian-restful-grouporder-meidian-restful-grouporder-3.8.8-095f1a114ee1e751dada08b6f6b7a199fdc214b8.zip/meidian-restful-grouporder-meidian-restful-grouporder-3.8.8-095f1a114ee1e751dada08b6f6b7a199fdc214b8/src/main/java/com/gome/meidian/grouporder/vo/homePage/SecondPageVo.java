package com.gome.meidian.grouporder.vo.homePage;

import com.gomeplus.bs.interfaces.cms2.vo.business.base.Menus;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageHeadMenu;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 首页信息集合
 */
@Setter
@Getter
@ToString
public class SecondPageVo implements Serializable {

	private static final long serialVersionUID = -1222539836535848354L;

	private PageInfo defaultPageInfo; // 默认也面信息

	private List<Menus> moduleMenuList = null; // 模块排序id

	private Map<String, Object> moduleJsonMap = null;// 模块详细数据json值

	private List<Menus> prdMenuList = null; // 瀑布流菜单


	public SecondPageVo() {

	}


	@Override
	public String toString() {
		return "HomePageVo{" +
				", defaultPageInfo=" + defaultPageInfo +
				", moduleMenuList=" + moduleMenuList +
				", moduleJsonMap=" + moduleJsonMap +
				", prdMenuList=" + prdMenuList +
				'}';
	}
}
