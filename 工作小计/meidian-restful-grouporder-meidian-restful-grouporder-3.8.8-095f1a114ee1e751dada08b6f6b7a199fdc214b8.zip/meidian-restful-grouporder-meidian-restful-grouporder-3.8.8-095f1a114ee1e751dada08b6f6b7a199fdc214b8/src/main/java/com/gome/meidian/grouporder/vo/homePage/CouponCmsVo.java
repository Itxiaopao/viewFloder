package com.gome.meidian.grouporder.vo.homePage;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @Author yuliang-ds1
 * @Date 2019/1/12 15:13
 * @Description
 */
@Setter
@Getter
@ToString
public class CouponCmsVo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7907507229757492657L;


    private String  productId; 		// productId
    private String skuNo;
    private String skuId;
    private Integer couponType; 	// 券类型1:美券, 2:pop券
    private String  couponRuleId; 	// 券id
    private Double  couponNum; 		// 面额
    private String  planId; 		// 美劵有，pop劵没有，有批次号
    
	public CouponCmsVo(String productId, String skuNo, String skuId, Integer couponType, 
						String couponRuleId, Double couponNum, String planId) {
		super();
		this.productId = productId;
		this.skuNo = skuNo;
		this.skuId = skuId;
		this.couponType = couponType;
		this.couponRuleId = couponRuleId;
		this.couponNum = couponNum;
		this.planId = planId;
	}

	public CouponCmsVo() {
		super();
	}

    

}
