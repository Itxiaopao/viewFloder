package com.gome.meidian.grouporder.vo.homePage;

import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

public class UnCollectionProductVo extends CollectionProductVo {

	private static final long serialVersionUID = 1301204175872018101L;
//	@NotBlank(message = "{param.error}")
	private String collectionId;
	//取消点赞来源页面 1-万人团列表  2-万人团商详页  3-我的收藏
	@NotBlank(message = "{param.error}")
	@Pattern(regexp="^[1-3]{1}$",message="{param.error}")
	private String fromSource;
	public String getCollectionId() {
		return collectionId;
	}
	public void setCollectionId(String collectionId) {
		this.collectionId = collectionId;
	}
	public String getFromSource() {
		return fromSource;
	}
	public void setFromSource(String fromSource) {
		this.fromSource = fromSource;
	}
	
}
