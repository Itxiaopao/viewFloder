package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;

public class CommonInfo implements Serializable{
	private static final long serialVersionUID = 8520596186403581261L;
	private String remain;
	public String getRemain() {
		return remain;
	}
	public void setRemain(String remain) {
		this.remain = remain;
	}

}
