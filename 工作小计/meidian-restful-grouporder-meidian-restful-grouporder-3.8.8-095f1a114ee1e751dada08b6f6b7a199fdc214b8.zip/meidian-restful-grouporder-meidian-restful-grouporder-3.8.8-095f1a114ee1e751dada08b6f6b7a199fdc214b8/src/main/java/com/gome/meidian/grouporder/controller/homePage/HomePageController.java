package com.gome.meidian.grouporder.controller.homePage;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.homePageManager.HomePageManager;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.grouporderVo.ProductGroupInfoVo;
import com.gome.meidian.grouporder.vo.homePage.*;
import com.gome.meidian.grouporder.vo.product.HomeCouponProductRes;
import com.gome.meidian.grouporder.vo.product.ProductSurveyInfoVo;
import com.gome.meidian.grouporder.vo.rebate.ProductBuyRebateVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.sso.model.UserInfoCache;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import redis.Gcache;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 2019-01-10 APP首页接口
 */
@RestController
@Validated
@RequestMapping("/v1/homePage")
public class HomePageController {


    @Resource(name = "gcache")
    private Gcache gcache;

    @Resource(name = "userCenter")
    private Gcache userCenter;

    @Value("${gcache.expireTime}")
    private Integer expireTime;//40秒
    @Value("${gome.defaultAreaCode}")
    private String defaultAreaCode; // 默认二级区域，朝阳，全国价

    @Autowired
    private HomePageManager homePageManager;
    @Autowired
    private GroupOrderManager groupOrderManager;

    @Value("${gome.defaultStoreCode}")
    private String defaultStoreCode; // 默认门店，西坝河

//    /**
//     * 获取首页信息（美店app首页已下线）
//     *
//     * @param storeCode
//     * @param areaCode
//     * @return
//     * @throws MeidianException
//     */
//    @SuppressWarnings({"rawtypes", "unchecked"})
//    @GetMapping("/getHomePageInfo")
//    public ResponseJson getHomePageInfo(
//            @RequestParam(value = "pageCode") String pageCode,
//            @RequestParam(value = "storeCode") String storeCode,
//            @CookieValue(value = "storeCode", required = false) String StoreCode,
//            @CookieValue(value = "Channel", required = false) String Channel,
//            @RequestParam(value = "channel", required = false) String channel,
//            @RequestParam(value = "areaCode") String areaCode
//    ) throws MeidianException {
//        ResponseJson response = new ResponseJson();
//
//        int chan = ChannelUtils.getCmsChannel(Channel, channel);
//
//        String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);
//
//        StringBuilder sb = new StringBuilder();
//        sb.append(storeCode).append("_").append(pageCode);
//        sb.append("_").append(areaCode);
//        String value = null;
//        value = gcache.get("homePage:getHomePageInfo:store_page_area:" + sb.toString());
//        HomePageVo homePageVo = null;
//        if (null == value) {
//            homePageVo = homePageManager.getHomePageDetailInfo(stoCode, pageCode, areaCode, chan);
//            if (null != homePageVo.getDefaultPageInfo()) {
//                gcache.setex("homePage:getHomePageInfo:store_page_area:" + sb.toString(), expireTime, JSONUtils.toJSONString(homePageVo));
//            }
//        } else {
//            homePageVo = JSONObject.parseObject(value, HomePageVo.class);
//        }
//        response.setData(homePageVo);
//        return response;
//    }

    /**
     * 查询组团列表信息
     *
     * @param pageCode
     * @param storeCode
     * @param moduleCode
     * @param areaCode
     * @param pageNo
     * @param pageSize
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @GetMapping("/getHomePageMenuGroupIds")
    public ResponseJson getHomePageMenuGroupIds(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize)
            throws MeidianException {
        ResponseJson response = new ResponseJson();
        StringBuilder sb = new StringBuilder();
        sb.append(pageCode).append("_");
        sb.append(storeCode).append("_");
        sb.append(areaCode).append("_");
        sb.append(moduleCode).append("_");
        sb.append(pageNo).append("_");
        sb.append(pageSize);
        String value = null;
        value = gcache.get("homePage:getHomePageMenuGroupIds:p_s_a_m_p_p:" + sb.toString());
        List<ZutuanCmsVo> list = null;
        if (null == value) {
            list = homePageManager.getMenuGroupInfoList(storeCode, pageCode, moduleCode, areaCode, pageNo, pageSize);
            gcache.setex("homePage:getHomePageMenuGroupIds:p_s_a_m_p_p:" + sb.toString(), expireTime, JSONUtils.toJSONString(list));
        } else {
            list = JSONObject.parseArray(value, ZutuanCmsVo.class);
        }
        response.setData(list);
        return response;
    }


    /**
     * 查询返利信息
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param pageNo
     * @param pageSize
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getHomePageMenuRebateIds")
    public ResponseJson getHomePageMenuRebateIds(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize)
            throws MeidianException {
        ResponseJson response = new ResponseJson();
        StringBuilder sb = new StringBuilder();
        sb.append(pageCode).append("_");
        sb.append(storeCode).append("_");
        sb.append(areaCode).append("_");
        sb.append(moduleCode).append("_");
        sb.append(pageNo).append("_");
        sb.append(pageSize);
        String value = null;
        value = gcache.get("homePage:getHomePageMenuRebateIds:p_s_a_m_p_p:" + sb.toString());
        List<RebateCmsVo> list = null;
        if (null == value) {
            list = homePageManager.getMenuRebateInfoList(storeCode, pageCode, moduleCode, areaCode, pageNo, pageSize);
            gcache.setex("homePage:getHomePageMenuRebateIds:p_s_a_m_p_p:" + sb.toString(), expireTime, JSONUtils.toJSONString(list));
        } else {
            list = JSONObject.parseArray(value, RebateCmsVo.class);
        }
        response.setData(list);
        return response;
    }

    /**
     * 超级返商品集列表
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param ppi
     * @param pageNo
     * @param pageSize
     * @param request
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
	@MDStorePriceAnnotation
    @GetMapping("/getRebateMenuDetailInfoList")
    public ResponseJson getRebateMenuDetailInfoList(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            HttpServletRequest request
    ) throws MeidianException {
        ResponseJson response = new ResponseJson();
        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);


		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);
        List<ProductBuyRebateVo> list = null;

        list = homePageManager.getRebateDetailInfoList(pageCode, stoCode, MeidianEnvironment.getKey("priceReqAreaCode"), moduleCode, MeidianEnvironment.getPPI(), pageSize, pageNo, ua, GroupOrderConstants.PRICE_POLICYID);

        Map<String, Object> resMap = new HashMap<String, Object>();
        
        // 分页是否到底0：结束，1：未结束
        byte pageEnd = 0;
        if(null != list && null != pageSize){
        	if(list.size() == pageSize.intValue()) pageEnd = 1;
        }
        
        resMap.put("pageEnd", pageEnd);
        resMap.put("productBuyRebateVos", list);

        response.setData(resMap);
        return response;
    }


    /**
     * 查询立减集合信息
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param pageNo
     * @param pageSize
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getHomePageMenuCouponIds")
    public ResponseJson getHomePageMenuCouponIds(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize)
            throws MeidianException {
        ResponseJson response = new ResponseJson();
        StringBuilder sb = new StringBuilder();
        sb.append(pageCode).append("_");
        sb.append(storeCode).append("_");
        sb.append(areaCode).append("_");
        sb.append(moduleCode).append("_");
        sb.append(pageNo).append("_");
        sb.append(pageSize);
        String value = null;
        value = gcache.get("homePage:getHomePageMenuCouponIds:p_s_a_m_p_p:" + sb.toString());
        List<CouponCmsVo> list = null;
        if (null == value) {
            list = homePageManager.getMenuCouponInfoList(storeCode, pageCode, moduleCode, areaCode, pageNo, pageSize);
            gcache.setex("homePage:getHomePageMenuCouponIds:p_s_a_m_p_p:" + sb.toString(), expireTime, JSONUtils.toJSONString(list));
        } else {
            list = JSONObject.parseArray(value, CouponCmsVo.class);
        }
        response.setData(list);
        return response;
    }

    /**
     * 立减商品列表
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param ppi
     * @param pageNo
     * @param pageSize
     * @param request
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
	@MDStorePriceAnnotation
    @GetMapping("/getCouponMenuDetailInfoList")
    public ResponseJson getCouponMenuDetailInfoList(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            HttpServletRequest request
    )
            throws MeidianException {
        ResponseJson response = new ResponseJson();
        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);

		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);

        List<HomeCouponProductRes> list = null;
        
        list = homePageManager.getCouponDetailInfoList(pageCode, stoCode, moduleCode, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), pageSize, pageNo, ua, GroupOrderConstants.PRICE_POLICYID);


        Map<String, Object> productsMap = new HashMap<String, Object>();
        
        // 分页是否到底0：结束，1：未结束
        byte pageEnd = 0;
        if(null != list && null != pageSize){
        	if(list.size() == pageSize.intValue()) pageEnd = 1;
        }
        
        productsMap.put("pageEnd", pageEnd);
        productsMap.put("products", list);

        response.setData(productsMap);
        return response;
    }


    /**
     * 万人团首页列表
     *
     * @param pageCode
     * @param moduleCode
     * @param storeCode
     * @param pageNo
     * @param pageSize
     * @param areaCode
     * @param areaCode
     * @param scn
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @MDStorePriceAnnotation
    @GetMapping("/getCollMenuDetailInfoList")
    public ResponseJson getCollMenuDetailInfoList(
            @RequestParam(value = "pageCode", required = true) String pageCode,
            @RequestParam(value = "moduleCode", required = true) String moduleCode,
            @RequestParam(value = "storeCode", required = false) String storeCode,
            @RequestParam(value = "pageNo", defaultValue = "1") Long pageNo,
            @RequestParam(value = "pageSize", defaultValue = "10") Long pageSize,
            @RequestParam(value = "areaCode", required = false) String areaCode,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
            @CookieValue(value = "SCN", required = false) String scn,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            HttpServletRequest request
    ) throws MeidianException {
        ResponseJson response = new ResponseJson();
        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);
        // 默认区域码
//        if (null == areaCode || areaCode.equalsIgnoreCase("")) {
//            areaCode = defaultAreaCode;
//        }

		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);
        //是否登录
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        Long userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = Long.parseLong(userInfo.getId());
        }
        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("thousandGroups", homePageManager.getWanrenGroupListByPage(stoCode, moduleCode, pageCode, pageNo, pageSize, userId, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua));
        response.setData(resultMap);
        return response;
    }

    /**
     * 查询组团详情列表
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param pageNo
     * @param pageSize
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @MDStorePriceAnnotation
    @GetMapping("/getGroupDetailInfoList")
    public ResponseJson getGroupMenuDetailInfoList(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            HttpServletRequest request)
            throws MeidianException {
        ResponseJson response = new ResponseJson();
        Map<String, Object> resMap = new HashMap<String, Object>();
        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);

		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);

        List<ProductGroupInfoVo> list = null;

        list = homePageManager.getGroupDetailInfoList(stoCode, pageCode, moduleCode, MeidianEnvironment.getKey("priceReqAreaCode"), pageNo, pageSize, MeidianEnvironment.getPPI(), ua);
        
        // 分页是否到底0：结束，1：未结束
        byte pageEnd = 0;
        if(null != list && null != pageSize){
        	if(list.size() == pageSize.intValue()) pageEnd = 1;
        } 
        
        resMap.put("pageEnd", pageEnd);
        resMap.put("productGroupInfoVos", list);
        response.setData(resMap);
        return response;
    }

    /**
     * 查询热度调研商品列表信息
     *
     * @param pageCode
     * @param storeCode
     * @param areaCode
     * @param moduleCode
     * @param pageNo
     * @param pageSize
     * @param ppi
     * @param Channel
     * @param request
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	@MDStorePriceAnnotation
    @GetMapping("/getSurveyDetailInfoList")
    public ResponseJson getSurveyMenuDetailInfoList(
            @RequestParam(value = "pageCode") String pageCode,
            @RequestParam(value = "storeCode") String storeCode,
            @CookieValue(value = "storeCode", required = false) String StoreCode,
            @RequestParam(value = "areaCode") String areaCode,
            @RequestParam(value = "moduleCode") String moduleCode,
            @RequestParam(value = "pageNo") Long pageNo,
            @RequestParam(value = "pageSize") Long pageSize,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            HttpServletRequest request)
            throws MeidianException {
        ResponseJson response = new ResponseJson();
        Map<String, Object> resMap = new HashMap<String, Object>();
        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);
        // 兼容获取storeCode
//        String stoCode = ChannelUtils.getStoreCode(StoreCode, storeCode, defaultStoreCode);

		String stoCode = ChannelUtils.getStoreCode(MeidianEnvironment.getKey("priceReqStoreCode"), storeCode, defaultStoreCode);

        List<ProductSurveyInfoVo> list = null;

        list = homePageManager.getProductDetailInfoList(pageCode, stoCode, MeidianEnvironment.getKey("priceReqAreaCode"), moduleCode, MeidianEnvironment.getPPI(), pageSize, pageNo, ua);
        byte pageEnd = 0;
        if(null != list && null != pageSize){
        	if(list.size() == pageSize.intValue()) pageEnd = 1;
        }
        
        resMap.put("pageEnd", pageEnd);
        resMap.put("productSurveyInfoVos", list);
        response.setData(resMap);
        return response;
    }


    /**
     * 万人团商详页
     *
     * @return
     * @throws ServiceException
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    @MDStorePriceAnnotation
    @GetMapping("/groupDetail")
    public ResponseJson groupDetail(
            @NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
            @NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId,
            @NotBlank(message = "{param.error}") @RequestParam(value = "activityId", required = true) String activityId,
            @RequestParam(value = "groupId", required = false) Long groupId,
            @RequestParam(value = "areaCode", required = false) String areaCode,
            @RequestParam(value = "orgCode", required = false) String orgCode,
//            @CookieValue(value = "m_s_stid", required = false) String storeCode,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
            @CookieValue(value = "SCN", required = false) String scn,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            HttpServletRequest request) throws ServiceException {
        ResponseJson response = new ResponseJson();

        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);
        
        // 默认区域码
//        if (null == areaCode || areaCode.equalsIgnoreCase("")) {
//            areaCode = defaultAreaCode;
//        }

        //是否登录
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        Long userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = Long.parseLong(userInfo.getId());
        }
        response.setData(homePageManager.groupDetail(userId, productId, skuId, Long.valueOf(activityId), groupId, "", MeidianEnvironment.getKey("priceReqAreaCode"), orgCode, MeidianEnvironment.getKey("priceReqStoreCode"), MeidianEnvironment.getPPI(), ua));
        return response;
    }

    /**
     * 分享商品
     *
     * @param productId
     * @param scn
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings("rawtypes")
    @PostMapping("/shareProduct")
    public ResponseJson shareProduct(
            @RequestBody ShareProductInfoVo shareInfo,
            @CookieValue(value = "SCN", required = false) String scn) throws MeidianException {
        ResponseJson response = new ResponseJson();

        // 验证是否登陆，未登陆强制登陆
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        if (null == userInfo || StringUtils.isEmpty(userInfo.getId())) {
            throw new ServiceException("group.operation.notLoggin");
        }

        homePageManager.shareProduct(shareInfo.getProductId());

        return response;
    }

    /**
     * 点赞或取消点赞商品
     *
     * @param productId
     * @param scn
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings("rawtypes")
    @PostMapping("/thumbsUpProduct")
    public ResponseJson thumbsUpProduct(
            @Valid @RequestBody ThumbsUpProductVo thumbsUpProductVo,
            @CookieValue(value = "SCN", required = false) String scn) throws MeidianException {
        ResponseJson response = new ResponseJson();

        // 验证是否登陆，未登陆强制登陆
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        String userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = userInfo.getId();
        } else {
            throw new ServiceException("group.operation.notLoggin");
        }

        homePageManager.thumbsUpProduct(userId, thumbsUpProductVo);

        return response;
    }

    /**
     * 收藏商品
     *
     * @param collectionProduct
     * @param scn
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings("rawtypes")
    @PostMapping("/collectionProduct")
    public ResponseJson collectionProduct(
            @Valid @RequestBody CollectionProductVo collectionProduct,
            @CookieValue(value = "SCN", required = false) String scn) throws MeidianException {
        ResponseJson response = new ResponseJson();

        // 验证是否登陆，未登陆强制登陆
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        String userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = userInfo.getId();
        } else {
            throw new ServiceException("group.operation.notLoggin");
        }

        homePageManager.collectionProduct(userId, collectionProduct);

        return response;
    }

    /**
     * 取消收藏商品
     *
     * @param collectionProduct
     * @param scn
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings("rawtypes")
    @PostMapping("/unCollectionProduct")
    public ResponseJson unCollectionProduct(
            @Valid @RequestBody UnCollectionProductVo collectionProduct,
            @CookieValue(value = "SCN", required = false) String scn) throws MeidianException {
        ResponseJson response = new ResponseJson();

        // 验证是否登陆，未登陆强制登陆
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        String userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = userInfo.getId();
        } else {
            throw new ServiceException("group.operation.notLoggin");
        }
        homePageManager.unCollectionProduct(userId, collectionProduct);

        return response;
    }

    /**
     * 评价商品
     *
     * @param appraiseProduct
     * @param scn
     * @return
     * @throws ServiceException
     */
    @SuppressWarnings("rawtypes")
	@PostMapping("/appraiseProduct")
    public ResponseJson appraiseProduct(
            @Valid @RequestBody AppraiseProductVo appraiseProduct,
            @CookieValue(value = "SCN", required = false) String scn) throws ServiceException {
        ResponseJson response = new ResponseJson();
        // 验证是否登陆，未登陆强制登陆
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        String userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = userInfo.getId();
        } else {
            throw new ServiceException("group.operation.notLoggin");
        }
        homePageManager.appraiseProduct(userId, appraiseProduct);
        return response;
    }

    /**
     * 获取更多评论
     *
     * @param productId
     * @param pageNo
     * @param pageSize
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @GetMapping("/getMoreAppraise")
    public ResponseJson getMoreAppraise(
            @NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
            @RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
            @RequestParam(value = "pageSize", defaultValue = "20") Integer pageSize
    ) {
        ResponseJson response = new ResponseJson();
        response.setData(homePageManager.getAppraise(productId, pageNo, pageSize));
        return response;

    }

    /**
     * 获取收藏列表
     *
     * @param scn
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @MDStorePriceAnnotation
    @GetMapping("/getCollectionProductList")
    public ResponseJson getCollectionProductList(
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
            @RequestParam("areaCode") String areaCode,
//            @CookieValue(value = "PPI", required = false) Integer ppi,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
            @CookieValue(value = "SCN", required = false) String scn,
            HttpServletRequest request) throws MeidianException {
        ResponseJson response = new ResponseJson();
        // 获取设备
        Byte ua = ImageUtils.userAgentChannel(request);
        // 默认区域码
//        if (null == areaCode || areaCode.equalsIgnoreCase("")) {
//            areaCode = defaultAreaCode;
//        }

        // 验证是否登陆，未登陆强制登陆
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        String userId = null;
        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getId())) {
            userId = userInfo.getId();
        } else {
            throw new ServiceException("group.operation.notLoggin");
        }
//		userId = "100049475502";
        Map<String, Object> map = new HashMap<>();

        map.put("collectionList", homePageManager.getCollectionProductList(userId, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode")));
        response.setData(map);
        return response;
    }

    /**
     * 判断租户下是否配置客服接口
     *
     * @param productId
     * @param skuId
     * @param brandId
     * @param shopId
     * @return
     * @throws MeidianException
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    @GetMapping("/checkagent")
    public ResponseJson checkagent(
            @NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
            @NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId,
            @NotBlank(message = "{param.error}") @RequestParam(value = "brandId", required = true) String brandId,
            @RequestParam(value = "shopId", required = false) String shopId
    ) throws MeidianException {
        ResponseJson response = new ResponseJson();
        response.setData(homePageManager.checkagent(productId, skuId, brandId, shopId));
        return response;
    }
}
