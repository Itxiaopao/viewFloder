package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class VshopInfoVo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotNull(message = "{base.mshop.inviteMid.notBlank}")
	private Long inviteMId;
	private String phoneNo;
	
	public Long getInviteMId() {
		return inviteMId;
	}
	public void setInviteMId(Long inviteMId) {
		this.inviteMId = inviteMId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
}
