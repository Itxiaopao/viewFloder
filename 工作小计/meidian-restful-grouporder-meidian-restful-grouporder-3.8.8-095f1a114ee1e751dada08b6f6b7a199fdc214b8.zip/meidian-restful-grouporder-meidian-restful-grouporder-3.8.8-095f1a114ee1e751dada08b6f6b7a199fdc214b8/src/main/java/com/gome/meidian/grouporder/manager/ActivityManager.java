package com.gome.meidian.grouporder.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.gome.coupon.model.cartBean.CouponBatchResult;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.ActivityPage;
import com.gome.meidian.grouporder.vo.CmsActivityPageVo;
import com.gome.meidian.grouporder.vo.CmsModel;
import com.gome.meidian.grouporder.vo.CmsStoreVo;
import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.ModelVo;
import com.gome.meidian.grouporder.vo.PriceConditionVo;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.ProductParamInfo;
import com.gome.meidian.grouporder.vo.ProductVo;
import com.gome.meidian.grouporder.vo.Slot;
import com.gome.meidian.grouporder.vo.StoreVo;
import com.gome.meidian.grouporder.vo.product.ProductRequestParam;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.mobile.common.utils.math.BigDecimalUtils;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gome.stage.bean.price.GomeUnifiedPrice;
import com.gome.stage.interfaces.item.IGomeVipPriceService;
import com.gome.stage.item.GomeVipPriceItem;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.ProductInfoListVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductManagementConciseVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductManagementVo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductsVo;

import cn.com.gome.rebate.dubbo.service.app.IDubboSellersService;
import cn.com.gome.rebate.model.seller.CommonGoodsReqDto;
import redis.Gcache;

@Service
public class ActivityManager {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private HttpClientUtil httpClientUtil;
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private IDubboSellersService iDubboSellersService;
	@Autowired
	private IGomeVipPriceService iGomeVipPriceService;
	@Autowired
	private PriceManager priceManager;

	@Value("${cms.productIdsUrl}")
	private String productIdsUrl; // http://shark-cms.pre.video.api/v1/slot/store/getStoreSlot?unique_key=A017entitystorecontent661217
	@Resource(name = "gcache")
	private Gcache gcache;
	@Value("${meidian.image.agreement}")
	private String agreement; // http协议

	/**
	 * 获取组团活动页信息
	 * 
	 * @return
	 */
	public ActivityPage getGroupActivityPage(String ukey, String areaCode, Integer ppi, Byte ua)
			throws ServiceException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("unique_key", ukey);
		String result = null;
		try {
			result = httpClientUtil.doGet(productIdsUrl, map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ActivityPage activityPage = new ActivityPage();
		activityPage.setUkey(ukey);
		JSONObject obj = JSONObject.parseObject(result);

		JSONObject data = null;
		try {
			data = obj.getJSONObject("data");
		} catch (Exception e) {
			// TODO: handle exception
		}
		if (null == data)
			return activityPage;

		// set cms返回值
		CmsActivityPageVo cmsActivityPageVo = JSONObject.parseObject(
				result.replaceAll("sku_id", "skuId").replace("rebate_id", "rebateId")
						.replace("rebate_type", "rebateType").replaceAll("coupon_type", "couponType"),
				CmsActivityPageVo.class);

		Slot slot = new Slot();
		BeanUtils.copyProperties(cmsActivityPageVo.getData().getSlot(), slot);
		activityPage.setSlot(slot);

		List<StoreVo> storeVos = new ArrayList<StoreVo>();

		for (CmsStoreVo cmsStoreVo : cmsActivityPageVo.getData().getList()) {
			List<ModelVo> models = new ArrayList<ModelVo>();
			StoreVo storeVo = new StoreVo();

			if (null != cmsStoreVo.getModel()) {
				for (CmsModel cmsModel : cmsStoreVo.getModel()) {
					ModelVo modelVo = new ModelVo();
					BeanUtils.copyProperties(cmsModel, modelVo);
					models.add(modelVo);
				}
				storeVo.setModel(models);
				storeVo.setColor(cmsStoreVo.getColor());
				storeVo.setName(cmsStoreVo.getName());
				// storeVo.setOperator_id(cmsStoreVo.getOperator_id());
				storeVo.setType(cmsStoreVo.getType());
				// storeVo.setUser_id(cmsStoreVo.getUser_id());
				storeVos.add(storeVo);
			}
		}
		activityPage.setStoreVos(storeVos);

		// 获取商品信息
		List<ProductsVo> productIds = new ArrayList<ProductsVo>();
		List<StoreVo> stores = activityPage.getStoreVos();
		for (StoreVo storeVo : stores) {
			// 如果为图片，不用添加商品信息
			String type = storeVo.getType();
			if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

				List<ModelVo> models = storeVo.getModel();
				for (ModelVo modelVo : models) {
					ProductsVo productsVo = new ProductsVo();
					productsVo.setProductId(modelVo.getProduct_id());
					productsVo.setActivityId(Long.valueOf(modelVo.getActivity_id()));
					productsVo.setSkuId(modelVo.getSkuId());
					productIds.add(productsVo);
				}
			}
		}

		// 获取商品信息
		List<ProductManagementConciseVo> productManagementConciseVos = this.getGroupProducts(productIds, areaCode);

		// set商品信息
		for (StoreVo storeVo : storeVos) {
			Iterator<ModelVo> itModel = storeVo.getModel().iterator();
			while (itModel.hasNext()) {
				ModelVo modelVo = itModel.next();
				// 如果为图片，不用添加商品信息
				String type = storeVo.getType();
				if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

					for (ProductManagementConciseVo productVo : productManagementConciseVos) {
						if (productVo.getProductId().equals(modelVo.getProduct_id())) {
							ProductParamInfo productParamInfo = new ProductParamInfo();
							BeanUtils.copyProperties(productVo, productParamInfo);
							productParamInfo.setPrice(groupOrderManager.getPrice(productVo.getPrice()));
							modelVo.setProductParamInfo(productParamInfo);
							break;
						}
					}
				} else if (type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE_SKIP)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.TWO_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_COUPON)
						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_COUPON)
						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_THREE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.FOUR_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_FIVE_IMAGE)) {
					// 为图片，更改http协议
					if (modelVo.getImage().contains("http:")) {
						modelVo.setImage(modelVo.getImage().replace("http:", agreement));
					}

					// 域名切换
					String target = modelVo.getTarget();
					if (null != target && !target.equalsIgnoreCase("") && !target.equalsIgnoreCase("3")) {
						modelVo.setTarget(ImageUtils.domainInfo(target));
					}
				}
			}
		}

		return activityPage;
	}

	/**
	 * 获取立减活动页信息
	 * 
	 * @return
	 */
	public ActivityPage getCouponActivityPage(String ukey, String areaCode, Integer ppi, Byte ua, String mOrg,
			String policyId) throws ServiceException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("unique_key", ukey);
		String result = null;
		try {
			result = httpClientUtil.doGet(productIdsUrl, map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ActivityPage activityPage = new ActivityPage();
		activityPage.setUkey(ukey);
		JSONObject obj = JSONObject.parseObject(result);

		JSONObject data = null;
		try {
			data = obj.getJSONObject("data");
		} catch (Exception e) {
			// TODO: handle exception
		}
		if (null == data)
			return activityPage;

		// set cms返回值
		CmsActivityPageVo cmsActivityPageVo = JSONObject.parseObject(
				result.replaceAll("sku_id", "skuId").replace("rebate_id", "rebateId")
						.replace("rebate_type", "rebateType").replaceAll("coupon_type", "couponType"),
				CmsActivityPageVo.class);

		Slot slot = new Slot();
		BeanUtils.copyProperties(cmsActivityPageVo.getData().getSlot(), slot);
		activityPage.setSlot(slot);

		List<StoreVo> storeVos = new ArrayList<StoreVo>();

		for (CmsStoreVo cmsStoreVo : cmsActivityPageVo.getData().getList()) {
			List<ModelVo> models = new ArrayList<ModelVo>();
			StoreVo storeVo = new StoreVo();

			if (null != cmsStoreVo.getModel()) {
				for (CmsModel cmsModel : cmsStoreVo.getModel()) {
					ModelVo modelVo = new ModelVo();
					BeanUtils.copyProperties(cmsModel, modelVo);
					models.add(modelVo);
				}
				storeVo.setModel(models);
				storeVo.setColor(cmsStoreVo.getColor());
				storeVo.setName(cmsStoreVo.getName());
				// storeVo.setOperator_id(cmsStoreVo.getOperator_id());
				storeVo.setType(cmsStoreVo.getType());
				// storeVo.setUser_id(cmsStoreVo.getUser_id());
				storeVos.add(storeVo);
			}
		}
		activityPage.setStoreVos(storeVos);

		// 获取商品信息
		List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
		List<StoreVo> stores = activityPage.getStoreVos();
		for (StoreVo storeVo : stores) {
			// 如果为图片，不用添加商品信息
			String type = storeVo.getType();
			if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

				List<ModelVo> models = storeVo.getModel();
				for (ModelVo modelVo : models) {
					ProductRequestParam productRequestParam = new ProductRequestParam(modelVo.getProduct_id(),
							modelVo.getSkuId());
					productRequestParams.add(productRequestParam);
				}
			}
		}

		// 获取商品列表
		// List<Product> products = groupOrderManager.getBatchProducts(productIds,
		// areaCode, null, null, null);
		List<Product> products = groupOrderManager.getPros(productRequestParams, areaCode, null, null, null, mOrg,
				policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);

		for (StoreVo storeVo : storeVos) {
			Iterator<ModelVo> itModel = storeVo.getModel().iterator();
			while (itModel.hasNext()) {
				ModelVo modelVo = itModel.next();
				// 如果为图片，不用添加商品信息
				String type = storeVo.getType();
				if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

					if (null == products)
						continue;
					for (Product product : products) {
						if (product.getId().equals(modelVo.getProduct_id())) {
							ProductParamInfo productParamInfo = new ProductParamInfo();
							BeanUtils.copyProperties(product, productParamInfo);
							productParamInfo.setPrice(groupOrderManager.getPrice(product.getSalePrice()));
							productParamInfo.setProductId(product.getId());
							productParamInfo.setProductImage(product.getMainImage());
							productParamInfo.setProductStatus(product.getStatus());
							modelVo.setProductParamInfo(productParamInfo);
							break;
						}
					}
				} else if (type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE_SKIP)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.TWO_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_THREE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.FOUR_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_FIVE_IMAGE)) {
					// 为图片，更改http协议
					if (modelVo.getImage().contains("http:")) {
						modelVo.setImage(modelVo.getImage().replace("http:", agreement));
					}

					// 域名切换
					String target = modelVo.getTarget();
					if (null != target && !target.equalsIgnoreCase("") && !target.equalsIgnoreCase("3")) {
						modelVo.setTarget(ImageUtils.domainInfo(target));
					}

				} else if (type.equalsIgnoreCase(GroupOrderConstants.MORE_COUPON)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_COUPON)) {
					// 为图片，更改http协议
					if (modelVo.getImage().contains("http:")) {
						modelVo.setImage(modelVo.getImage().replace("http:", agreement));
					}

					// 多劵轮播
					if (modelVo.getType().equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_BEAUTY)) {
						// 美劵
						CouponRuleInfo couponRuleInfo = groupOrderManager.getCoupon(modelVo.getCoupon_id());
						if (null != couponRuleInfo) {
							Coupon coupon = new Coupon();
							coupon.setCoupon_id(couponRuleInfo.getRuleId());
							coupon.setCoupon_num(couponRuleInfo.getAmount());
							coupon.setFullAmount(couponRuleInfo.getLimitAmount());
							coupon.setDescription(couponRuleInfo.getDescription());
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							coupon.setShow_start_time(sdf.format(couponRuleInfo.getCouponStartDate()));
							coupon.setShow_end_time(sdf.format(couponRuleInfo.getCouponEndDate()));
							coupon.setCouponType(couponRuleInfo.getType());
							coupon.setPlan_id(modelVo.getPlan_id());

							ProductParamInfo productParamInfo = new ProductParamInfo();
							productParamInfo.setCoupon(coupon);
							modelVo.setProductParamInfo(productParamInfo);
						}
					} else if (modelVo.getType().equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
						// pop劵
						CouponBatchResult couponBatchResult = groupOrderManager.getPopCoupon(modelVo.getCoupon_id());
						if (null != couponBatchResult) {
							Coupon coupon = new Coupon();
							coupon.setCoupon_num(couponBatchResult.getDenomination()); // 面额
							coupon.setDescription(couponBatchResult.getDescription());
							coupon.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
							coupon.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券, 2:平台券，3：商品劵
							coupon.setCoupon_id(modelVo.getCoupon_id()); // pop劵批次号
							coupon.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
							SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
							coupon.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
							coupon.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));

							ProductParamInfo productParamInfo = new ProductParamInfo();
							productParamInfo.setCoupon(coupon);
							modelVo.setProductParamInfo(productParamInfo);
						}
					}
				}
			}
		}

		return activityPage;
	}

	/**
	 * 获取超级返活动页信息
	 * 
	 * @return
	 */
	public ActivityPage getBuyRebateActivityPage(String ukey, String areaCode, Integer ppi, Byte ua, String mOrg,
			String policyId) throws ServiceException {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("unique_key", ukey);
		String result = null;
		try {
			result = httpClientUtil.doGet(productIdsUrl, map);
		} catch (Exception e) {
			e.printStackTrace();
		}

		ActivityPage activityPage = new ActivityPage();
		activityPage.setUkey(ukey);
		JSONObject obj = JSONObject.parseObject(result);

		JSONObject data = null;
		try {
			data = obj.getJSONObject("data");
		} catch (Exception e) {
			// TODO: handle exception
		}
		if (null == data)
			return activityPage;

		// 购买返开关
		String buyOnOff = gcache.get("buyRebateOnOff");

		// set cms返回值
		CmsActivityPageVo cmsActivityPageVo = JSONObject.parseObject(
				result.replaceAll("sku_id", "skuId").replace("rebate_id", "rebateId")
						.replace("rebate_type", "rebateType").replaceAll("coupon_type", "couponType"),
				CmsActivityPageVo.class);

		Slot slot = new Slot();
		BeanUtils.copyProperties(cmsActivityPageVo.getData().getSlot(), slot);
		activityPage.setSlot(slot);

		List<StoreVo> storeVos = new ArrayList<StoreVo>();

		for (CmsStoreVo cmsStoreVo : cmsActivityPageVo.getData().getList()) {
			List<ModelVo> models = new ArrayList<ModelVo>();
			StoreVo storeVo = new StoreVo();

			if (null != cmsStoreVo.getModel()) {
				for (CmsModel cmsModel : cmsStoreVo.getModel()) {
					ModelVo modelVo = new ModelVo();
					BeanUtils.copyProperties(cmsModel, modelVo);
					models.add(modelVo);
				}
				storeVo.setModel(models);
				storeVo.setColor(cmsStoreVo.getColor());
				storeVo.setName(cmsStoreVo.getName());
				storeVo.setType(cmsStoreVo.getType());
				storeVos.add(storeVo);
			}
		}
		activityPage.setStoreVos(storeVos);

		// 获取商品信息
		List<ProductRequestParam> productRequestParams = new ArrayList<ProductRequestParam>();
		List<StoreVo> stores = activityPage.getStoreVos();
		for (StoreVo storeVo : stores) {
			// 如果为图片，不用添加商品信息
			String type = storeVo.getType();
			if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

				List<ModelVo> models = storeVo.getModel();
				for (ModelVo modelVo : models) {
					ProductRequestParam productRequestParam = new ProductRequestParam(modelVo.getProduct_id(),
							modelVo.getSkuId());
					productRequestParams.add(productRequestParam);
				}
			}
		}

		// 获取商品信息
		// List<Product> products = groupOrderManager.getBatchProducts(productIds,
		// areaCode, null, null, null);
		List<Product> products = groupOrderManager.getPros(productRequestParams, areaCode, null, null, null, mOrg,
				policyId, GroupOrderConstants.MEIDIANPRICE_CHANNEL);

		// 超级返入参
		List<CommonGoodsReqDto> commonGoodsReqDtos = new ArrayList<CommonGoodsReqDto>();
		// 记住缓存中购买返的商品
		Map<String, String> buyRebateSubscriptMap = new HashMap<String, String>();
		for (StoreVo storeVo : storeVos) {
			Iterator<ModelVo> itModel = storeVo.getModel().iterator();
			while (itModel.hasNext()) {
				ModelVo modelVo = itModel.next();
				// 如果为图片，不用添加商品信息
				String type = storeVo.getType();
				if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

					if (null == products)
						continue;
					for (Product product : products) {
						if (product.getId().equals(modelVo.getProduct_id())) {
							ProductParamInfo productParamInfo = new ProductParamInfo();
							BeanUtils.copyProperties(product, productParamInfo);
							productParamInfo.setPrice(groupOrderManager.getPrice(product.getSalePrice()));
							String pId = product.getId();
							String skId = productParamInfo.getSkuId();
							productParamInfo.setProductId(pId);
							productParamInfo.setProductImage(product.getMainImage());
							productParamInfo.setProductStatus(product.getStatus());
							modelVo.setProductParamInfo(productParamInfo);

							// 超级返入参
							if (null == buyOnOff) {
								Integer re = JSONObject.parseObject(
										gcache.hget("meidian-restful-grouporder-buyRebate", pId + "_" + skId),
										Integer.class);
								// Integer re = JSONObject.parseObject(gcache.get("activityPageBuyRebate_" +
								// productParamInfo.getProductId() + "_" + productParamInfo.getSkuId()),
								// Integer.class);
								if (null == re) {
									CommonGoodsReqDto commonGoodsReqDto = new CommonGoodsReqDto();
									// 返利key，自定义，作为返回多个值的区分,以productId,skuNo作为key
									commonGoodsReqDto.setKey(pId + "_" + skId);
									// 商品productId
									commonGoodsReqDto.setItemId(modelVo.getProduct_id());
									// skuNo
									commonGoodsReqDto.setSkuId(modelVo.getSku_no());
									// 商户id
									commonGoodsReqDto.setMerchantId(modelVo.getProductParamInfo().getShopId() == null
											|| modelVo.getProductParamInfo().getShopId().equalsIgnoreCase("")
													? GroupOrderConstants.PRODUCT_SELF_DEFAULT_SHOPID_REBATE
													: modelVo.getProductParamInfo().getShopId());
									commonGoodsReqDtos.add(commonGoodsReqDto);
								} else {
									Double rebate = BigDecimalUtils.round(DoubleUtils
											.mul(modelVo.getProductParamInfo().getPrice(), Double.valueOf(re)) / 10000,
											2);
									modelVo.getProductParamInfo().setBuyRebate(rebate);
									buyRebateSubscriptMap.put(pId + "_" + skId, "1");
								}
							}

							break;
						}
					}
				} else if (type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE_SKIP)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.TWO_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.ONE_COUPON)
						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_COUPON)
						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_THREE_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.FOUR_IMAGE)
						|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_FIVE_IMAGE)) {
					// 为图片，更改http协议
					if (modelVo.getImage().contains("http:")) {
						modelVo.setImage(modelVo.getImage().replace("http:", agreement));
					}

					// 域名切换
					String target = modelVo.getTarget();
					if (null != target && !target.equalsIgnoreCase("") && !target.equalsIgnoreCase("3")) {
						modelVo.setTarget(ImageUtils.domainInfo(target));
					}
				}
			}
		}

		// 处理购买返
		if (null == buyOnOff) {
			if (commonGoodsReqDtos.size() > 0)
				this.getActivityPageBuyRebate(activityPage, commonGoodsReqDtos, buyRebateSubscriptMap);
		}

		return activityPage;
	}

	/**
	 * 获取组团商品信息
	 * 
	 * @return
	 * @throws ServiceException
	 */
	public List<ProductManagementConciseVo> getGroupProducts(List<ProductsVo> productIds, String areaCode) {

		List<ProductsVo> prodIds = new ArrayList<ProductsVo>();
		List<ProductManagementConciseVo> resultList = new ArrayList<ProductManagementConciseVo>();
		if (null == productIds || productIds.size() == 0)
			return resultList;
		// 记住下标位
		int i = 0;
		Map<Integer, String> subscriptMap = new LinkedHashMap<Integer, String>();
		for (ProductsVo productsVo : productIds) {
			// ProductManagementConciseVo productVo =
			// JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-group-activitypage",
			// productsVo.getProductId() + "_" + productsVo.getSkuId() + "_" +
			// productsVo.getActivityId() + "_" + areaCode),
			// ProductManagementConciseVo.class);
			ProductManagementConciseVo productVo = JSONObject
					.parseObject(
							gcache.get("groupActivitypageProduct_" + productsVo.getProductId() + "_"
									+ productsVo.getSkuId() + "_" + productsVo.getActivityId() + "_" + areaCode),
							ProductManagementConciseVo.class);
			if (null == productVo) {
				i++;
				subscriptMap.put(i - 1, productsVo.getProductId());
				ProductsVo prod = new ProductsVo();
				prod.setActivityId(productsVo.getActivityId());
				prod.setProductId(productsVo.getProductId());
				prod.setSkuId(productsVo.getSkuId());
				prodIds.add(prod);
			} else {
				resultList.add(productVo);
			}
		}

		int listSize = prodIds.size();
		int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;

		List<ProductsVo> paramList = new ArrayList<>();
		for (int a = 1; a <= selectCount; a++) {
			paramList.clear();
			if (selectCount == 1) {
				paramList = prodIds;
			} else {
				if (a != selectCount) {
					paramList.addAll(prodIds.subList(30 * (a - 1), 30 * a));
				} else {
					paramList.addAll(prodIds.subList(30 * (a - 1), listSize));
				}
			}

			CommonResultEntity<ProductInfoListVo> resultVo = gorderInfoForAppNewResource.getProductInfoByIds(paramList,
					areaCode);
			ProductInfoListVo tVo = resultVo.getBusinessObj();
			if (null == tVo)
				continue;
			List<ProductManagementConciseVo> productManagementConciseVos = tVo.getProductInfo();
			if (null == productManagementConciseVos || productManagementConciseVos.size() == 0)
				continue;
			for (ProductManagementConciseVo productManagementConciseVo : productManagementConciseVos) {
				if (null == productManagementConciseVo)
					continue;
				// 插入相应的下标
				for (Map.Entry<Integer, String> entry : subscriptMap.entrySet()) {
					if (entry.getValue().equalsIgnoreCase(productManagementConciseVo.getProductId())) {
						if (resultList.size() <= entry.getKey())
							resultList.add(productManagementConciseVo);
						else
							resultList.add(entry.getKey(), productManagementConciseVo);

						// 添加到缓存
						// gcache.hset("meidian-restful-grouporder-group-activitypage",
						// productManagementConciseVo.getProductId() + "_" +
						// productManagementConciseVo.getSkuId() + "_" +
						// productManagementConciseVo.getActivityId() + "_" + areaCode,
						// JSONUtils.toJSONString(productManagementConciseVo).getBytes());
						gcache.setex(
								"groupActivitypageProduct_" + productManagementConciseVo.getProductId() + "_"
										+ productManagementConciseVo.getSkuId() + "_"
										+ productManagementConciseVo.getActivityId() + "_" + areaCode,
								3 * 60, JSONUtils.toJSONString(productManagementConciseVo).getBytes());
						break;
					}
				}
			}
		}

		return resultList;
	}

	// /**
	// * 获取劵商品信息
	// *
	// * @return
	// * @throws ServiceException
	// */
	// public List<ProductVo> getCouponProducts(List<ProductsVo> productIds, String
	// areaCode) {
	//
	// List<ProductsVo> prodIds = new ArrayList<ProductsVo>();
	// List<ProductVo> resultList = new ArrayList<ProductVo>();
	// if (productIds != null && productIds.size() > 0) {
	//
	// // 记住下标位
	// int i = 0;
	// Map<Integer, String> subscriptMap = new LinkedHashMap<Integer, String>();
	// for (ProductsVo productsVo : productIds) {
	// ProductVo productVo =
	// JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-product-couponactivity",
	// productsVo.getProductId() + "_" + areaCode), ProductVo.class);
	// if(null == productVo){
	// i ++;
	// subscriptMap.put(i - 1, productsVo.getProductId());
	// ProductsVo prod = new ProductsVo();
	// prod.setProductId(productsVo.getProductId());
	// prodIds.add(prod);
	// }else{
	// resultList.add(productVo);
	// }
	// }
	//
	// int listSize = prodIds.size();
	// int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
	//
	// List<ProductsVo> paramList = new ArrayList<>();
	// for (int a = 1; a <= selectCount; a++) {
	// paramList.clear();
	// if (selectCount == 1) {
	// paramList = prodIds;
	// } else {
	// if (a != selectCount) {
	// paramList.addAll(prodIds.subList(30 * (a - 1), 30 * a));
	// } else {
	// paramList.addAll(prodIds.subList(30 * (a - 1), listSize));
	// }
	// }
	//
	// CommonResultEntity<ProductInfoListVo> resultVo =
	// gorderInfoForAppResource.getProductInfoByIds(paramList,
	// areaCode);
	// logger.debug("getProductsByIds resultVo ==> {} ", resultVo);
	// logger.info("getProductsByIds areaCode ==> {} ", areaCode);
	// if (resultVo.getBusinessObj() != null) {
	// ProductInfoListVo tVo = resultVo.getBusinessObj();
	// if (tVo != null) {
	// List<ProductManagementVo> tList = tVo.getProductInfo();
	// if (tList != null && tList.size() > 0) {
	// for (ProductManagementVo productManagementVo : tList) {
	// if (null != productManagementVo) {
	// ProductVo productVo = groupOrderManager.copyProduct(productManagementVo);
	//
	// // 插入相应的下标
	// for (Map.Entry<Integer, String> entry : subscriptMap.entrySet()) {
	// if(entry.getValue().equalsIgnoreCase(productVo.getProductId())){
	// if(resultList.size() <= entry.getKey())
	// resultList.add(productVo);
	// else
	// resultList.add(entry.getKey(), productVo);
	//
	// // 添加到缓存
	// gcache.hset("meidian-restful-grouporder-product-couponactivity",
	// productVo.getProductId() + "_" + areaCode,
	// JSONUtils.toJSONString(productVo).getBytes());
	// break;
	// }
	// }
	// }
	// }
	// }
	// }
	// }
	// }
	//
	// }
	// return resultList;
	// }

	// /**
	// * 获取购买返商品信息
	// *
	// * @return
	// * @throws ServiceException
	// */
	// public List<ProductVo> getBuyRebateProducts(List<ProductsVo> productIds,
	// String areaCode) {
	//
	// List<ProductsVo> prodIds = new ArrayList<ProductsVo>();
	// List<ProductVo> resultList = new ArrayList<ProductVo>();
	// if (productIds != null && productIds.size() > 0) {
	//
	// // 记住下标位
	// int i = 0;
	// Map<Integer, String> subscriptMap = new LinkedHashMap<Integer, String>();
	// for (ProductsVo productsVo : productIds) {
	// ProductVo productVo =
	// JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-product-couponactivity",
	// productsVo.getProductId() + "_" + areaCode), ProductVo.class);
	// if(null == productVo){
	// i ++;
	// subscriptMap.put(i - 1, productsVo.getProductId());
	// ProductsVo prod = new ProductsVo();
	// prod.setProductId(productsVo.getProductId());
	// prodIds.add(prod);
	// }else{
	// resultList.add(productVo);
	// }
	// }
	//
	// int listSize = prodIds.size();
	// int selectCount = listSize % 30 == 0 ? listSize / 30 : listSize / 30 + 1;
	//
	// List<ProductsVo> paramList = new ArrayList<>();
	// for (int a = 1; a <= selectCount; a++) {
	// paramList.clear();
	// if (selectCount == 1) {
	// paramList = prodIds;
	// } else {
	// if (a != selectCount) {
	// paramList.addAll(prodIds.subList(30 * (a - 1), 30 * a));
	// } else {
	// paramList.addAll(prodIds.subList(30 * (a - 1), listSize));
	// }
	// }
	//
	// CommonResultEntity<ProductInfoListVo> resultVo =
	// gorderInfoForAppResource.getProductInfoByIds(paramList,
	// areaCode);
	// logger.debug("getProductsByIds resultVo ==> {} ", resultVo);
	// logger.info("getProductsByIds areaCode ==> {} ", areaCode);
	// if (resultVo.getBusinessObj() != null) {
	// ProductInfoListVo tVo = resultVo.getBusinessObj();
	// if (tVo != null) {
	// List<ProductManagementVo> tList = tVo.getProductInfo();
	// if (tList != null && tList.size() > 0) {
	// for (ProductManagementVo productManagementVo : tList) {
	// if (null != productManagementVo) {
	// ProductVo productVo = groupOrderManager.copyProduct(productManagementVo);
	//
	// // 插入相应的下标
	// for (Map.Entry<Integer, String> entry : subscriptMap.entrySet()) {
	// if(entry.getValue().equalsIgnoreCase(productVo.getProductId())){
	// if(resultList.size() <= entry.getKey())
	// resultList.add(productVo);
	// else
	// resultList.add(entry.getKey(), productVo);
	//
	// // 添加到缓存
	// gcache.hset("meidian-restful-grouporder-product-couponactivity",
	// productVo.getProductId() + "_" + areaCode,
	// JSONUtils.toJSONString(productVo).getBytes());
	// break;
	// }
	// }
	// }
	// }
	// }
	// }
	// }
	// }
	//
	// }
	// return resultList;
	// }

	/**
	 * 处理专题活动页购买返
	 * 
	 * @param activityPage
	 * @param commonGoodsReqDtos
	 * @param buyRebateSubscriptMap
	 */
	public void getActivityPageBuyRebate(ActivityPage activityPage, List<CommonGoodsReqDto> commonGoodsReqDtos,
			Map<String, String> buyRebateSubscriptMap) {
		Map<String, Integer> rebatePlanDtoMap = iDubboSellersService.getRebatePlanAmountToBsShop(commonGoodsReqDtos);
		List<StoreVo> storeVos = activityPage.getStoreVos();
		for (StoreVo storeVo : storeVos) {
			String type = storeVo.getType();
			if (type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE_SKIP)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_IMAGE)
					|| type.equalsIgnoreCase(GroupOrderConstants.TWO_IMAGE)
					|| type.equalsIgnoreCase(GroupOrderConstants.THREE_IMAGE)
					|| type.equalsIgnoreCase(GroupOrderConstants.ONE_COUPON)
					|| type.equalsIgnoreCase(GroupOrderConstants.MORE_COUPON)
					|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_THREE_IMAGE)
					|| type.equalsIgnoreCase(GroupOrderConstants.FOUR_IMAGE)
					|| type.equalsIgnoreCase(GroupOrderConstants.SIZE_FIVE_IMAGE)
					|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_NAVIGATION)) {
				continue;
			}

			List<ModelVo> modelVos = storeVo.getModel();
			for (ModelVo modelVo : modelVos) {
				ProductParamInfo productParamInfo = modelVo.getProductParamInfo();
				String proId = productParamInfo.getProductId();
				if (buyRebateSubscriptMap.containsKey(proId))
					continue;

				String skuId = productParamInfo.getSkuId();
				String psKey = proId + "_" + skuId;
				Integer rebatePlanDto = rebatePlanDtoMap.get(psKey);
				if (null == rebatePlanDto || rebatePlanDto == 0) {
					// 添加缓存
					gcache.hset("meidian-restful-grouporder-buyRebate", psKey, JSONUtils.toJSONString(0).getBytes());
					// gcache.setex("activityPageBuyRebate_" + productParamInfo.getProductId() + "_"
					// + productParamInfo.getSkuId(), 3 * 60, JSONUtils.toJSONString(0).getBytes());
					continue;
				}

				Double rebate = BigDecimalUtils
						.round(DoubleUtils.mul(productParamInfo.getPrice(), Double.valueOf(rebatePlanDto)) / 10000, 2);

				productParamInfo.setBuyRebate(rebate);

				// 添加缓存
				gcache.hset("meidian-restful-grouporder-buyRebate", psKey,
						JSONUtils.toJSONString(rebatePlanDto).getBytes());
				// gcache.setex("activityPageBuyRebate_" + productParamInfo.getProductId() + "_"
				// + productParamInfo.getSkuId(), 3 * 60,
				// JSONUtils.toJSONString(rebatePlanDto).getBytes());
			}
		}
	}

	/**
	 * 处理专题活动页图片
	 * 
	 * @param activityPage
	 * @param ppi
	 * @param ua
	 */
	public List<Map<String, String>> groupActivityPage(ActivityPage activityPage, Integer ppi, Byte ua) {

		// 处理美店价入参
		// Map<String, List<String>> proSkuMap = new HashMap<String, List<String>>();
		// List<String> pros = new ArrayList<String>();
		// List<String> skus = new ArrayList<String>();
		List<Map<String, String>> conditionList = new ArrayList<>();
		Map<String, String> priceMap = null;
		int num = 1;
		// 获取分辨率
		String ratioOneProduct = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.ONE_LIST_PRODUCT_IMAGE);
		String ratioTwoProduct = ImageUtils.imagePpiInfo(ppi, GroupOrderConstants.TWO_LIST_PRODUCT_IMAGE);
		List<StoreVo> storeVos = activityPage.getStoreVos();
		if (null != storeVos) {
			for (StoreVo storeVo : storeVos) {
				if (null == storeVo)
					continue;
				List<ModelVo> modelVos = storeVo.getModel();
				if (null == modelVos)
					continue;
				String type = storeVo.getType();
				if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)) {

					for (ModelVo modelVo : modelVos) {
						if (null == modelVo)
							continue;
						// 处理组团专题活动页图片分辨率
						String image = ImageUtils.imageUrlInfo(modelVo.getProductParamInfo().getProductImage(),
								ratioTwoProduct, ua);
						modelVo.getProductParamInfo().setProductImage(image);

						// 美店价格入参
						String skId = modelVo.getProductParamInfo().getSkuId();
						if (num % 12 == 1) {
							priceMap = new HashMap<>();
							conditionList.add(priceMap);
						}
						if (null != skId && !skId.equalsIgnoreCase("")) {
							priceMap.put(skId, modelVo.getProductParamInfo().getProductId());
							num++;
							// pros.add(modelVo.getProductParamInfo().getProductId());
							// skus.add(skId);
						}
					}
				} else if (type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
						|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

					for (ModelVo modelVo : modelVos) {
						if (null == modelVo)
							continue;
						// 处理组团专题活动页图片分辨率
						String image = ImageUtils.imageUrlInfo(modelVo.getProductParamInfo().getProductImage(),
								ratioOneProduct, ua);
						modelVo.getProductParamInfo().setProductImage(image);

						// 美店价格入参
						String skuId = modelVo.getProductParamInfo().getSkuId();
						if (num % 12 == 1) {
							priceMap = new HashMap<>();
							conditionList.add(priceMap);
						}
						if (null != skuId && !skuId.equalsIgnoreCase("")) {
							priceMap.put(modelVo.getProductParamInfo().getSkuId(),
									modelVo.getProductParamInfo().getProductId());
							num++;
							// pros.add(modelVo.getProductParamInfo().getProductId());
							// skus.add(modelVo.getProductParamInfo().getSkuId());
						}
					}
				}
			}
		}

		// proSkuMap.put("pros", pros);
		// proSkuMap.put("skus", skus);

		return conditionList;
	}

	/**
	 * 组团活动美店价处理
	 * 
	 * @param activityPage
	 * @param proSkuMap
	 * @param areaCode
	 */
	public void activityMeidianPrice(ActivityPage activityPage, List<Map<String, String>> proSkuMap, String areaCode,
			String storeCode) {

		List<GomeUnifiedPrice> meidianPrices = new ArrayList<GomeUnifiedPrice>();
		// List<String> proIds = proSkuMap.get("pros");
		// List<String> skuIds = proSkuMap.get("skus");

		// int listSize = proIds.size();
		// int selectCount = listSize % 12 == 0 ? listSize / 12 : listSize / 12 + 1;
		//
		// List<String> proParamIds = new ArrayList<String>();
		// List<String> skuParamIds = new ArrayList<String>();
		// for (int a = 1; a <= selectCount; a++) {
		// proParamIds.clear();
		// skuParamIds.clear();
		// if (selectCount == 1) {
		// proParamIds = proIds;
		// skuParamIds = skuIds;
		// } else {
		// if (a != selectCount) {
		// proParamIds.addAll(proIds.subList(12 * (a - 1), 12 * a));
		// skuParamIds.addAll(skuIds.subList(12 * (a - 1), 12 * a));
		// } else {
		// proParamIds.addAll(proIds.subList(12 * (a - 1), listSize));
		// skuParamIds.addAll(skuIds.subList(12 * (a - 1), listSize));
		// }
		// }

		List<PriceConditionVo> priceConditionRequestList = new ArrayList<>();
		PriceConditionVo pcVo = null;
		Map<String, String> conditionMap = null;
		for (int i = 0; i < proSkuMap.size(); i++) {

			conditionMap = proSkuMap.get(i);
			if (null != conditionMap && !conditionMap.isEmpty()) {
				for (Map.Entry<String, String> mm : conditionMap.entrySet()) {
					pcVo = new PriceConditionVo();
					pcVo.setChannel(GroupOrderConstants.MEIDIANPRICE_CHANNEL);
					pcVo.setPolicyId(GroupOrderConstants.PRICE_POLICYID);
					pcVo.setProductId(mm.getValue());
					pcVo.setSkuId(mm.getKey());

					priceConditionRequestList.add(pcVo);
				}

				List<GomeUnifiedPrice> priceRes = priceManager.getPrice(priceConditionRequestList);
				if (null != priceRes && !priceRes.isEmpty()) {
					for (GomeUnifiedPrice gup : priceRes) {
						if (gup != null) {
							meidianPrices.add(gup);
						}
					}
				}
				priceConditionRequestList.clear();
				// List<GomeVipPriceItem> gomeVipPriceItems =
				// iGomeVipPriceService.getVipPrices(proParamIds, skuParamIds, areaCode,
				// GroupOrderConstants.MEIDIANPRICE_CHANNEL);
				// if(null == gomeVipPriceItems || gomeVipPriceItems.size() == 0) continue;
				// meidianPrices.addAll(gomeVipPriceItems);
			}

			List<StoreVo> storeVos = activityPage.getStoreVos();
			if (null != storeVos) {
				for (StoreVo storeVo : storeVos) {
					if (null == storeVo)
						continue;
					List<ModelVo> modelVos = storeVo.getModel();
					if (null == modelVos)
						continue;
					String type = storeVo.getType();
					if (type.equalsIgnoreCase(GroupOrderConstants.TWO_LINE_PRODUCT)
							|| type.equalsIgnoreCase(GroupOrderConstants.THREE_LINE_PRODUCT)
							|| type.equalsIgnoreCase(GroupOrderConstants.TAG_TWO_LINE_PRODUCT)
							|| type.equalsIgnoreCase(GroupOrderConstants.TAG_THREE_LINE_PRODUCT)
							|| type.equalsIgnoreCase(GroupOrderConstants.ONE_LINE_PRODUCT)
							|| type.equalsIgnoreCase(GroupOrderConstants.MORE_PRODUCT)
							|| type.equalsIgnoreCase(GroupOrderConstants.TYPE_LINE_PRODUCT_BACKGROUND)) {

						for (ModelVo modelVo : modelVos) {
							if (null == modelVo)
								continue;
							for (GomeUnifiedPrice gomeVipPriceItem : meidianPrices) {
								if (gomeVipPriceItem.getSkuId()
										.equalsIgnoreCase(modelVo.getProductParamInfo().getSkuId())) {

									ProductParamInfo productParamInfo = modelVo.getProductParamInfo();
									// 美店价
									Double mPrice = gomeVipPriceItem.getPrice();
									productParamInfo.setMeidianPrice(DoubleUtils.switchScientificCalculate(mPrice));

									// 组团折扣返
									// 单位转换，元变分
									Double price = DoubleUtils.mul(mPrice, 100d);
									double rebatePrice = groupOrderManager.getRebateAmount(price.longValue(),
											productParamInfo.getMaxDiscount());
									productParamInfo.setRebateAmount(rebatePrice);

									// 处理美店价，国美价，当美店价大于国美价时，把美店价赋值给国美价
									if (mPrice.doubleValue() > productParamInfo.getPrice().doubleValue())
										productParamInfo.setPrice(mPrice);

									break;
								}
							}
						}
					}
				}
			}
		}
	}
}
