package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

public class CurrentStepsVo implements Serializable{
	
	private static final long serialVersionUID = -3957948103367993551L;
	
	private Byte step;			// 当前梯级
	private Integer peopleNum;	// 当前梯级人数
	private Float discount;		// 当前梯级折扣
	
	public Byte getStep() {
		return step;
	}
	public void setStep(Byte step) {
		this.step = step;
	}
	public Integer getPeopleNum() {
		return peopleNum;
	}
	public void setPeopleNum(Integer peopleNum) {
		this.peopleNum = peopleNum;
	}
	public Float getDiscount() {
		return discount;
	}
	public void setDiscount(Float discount) {
		this.discount = discount;
	}
	
	
}
