package com.gome.meidian.grouporder.utils;

public class UserConstants {
	
	//渠道标识
	public static final String CHANNEL_FLAG = "gomeOnLine";
	//调用会员组公共参数  invokeFrom
	public static final String INVOKE_FROM = "gomeShop";
	
	//用户注册-失败
	public static final int REGIST_FAILS = 0;
	//用户注册-成功
	public static final int REGIST_SUCCESS = 1;
	
	//类型-注册
	public static final String REGISTE = "1";
	//类型-激活
	public static final String ACTIVATE = "2";
	
	//wap美店登录
	public static final String BIZNO_LOGIN="WapMeidianLogin";
	//wap美店注册
	public static final String BIZNO_REGISTER="WapMeidianRegister";
	//wap美店登录短信防刷
	public static final String BIZNO_LOGIN_SMS="WapMeidianLoginSms";
	//wap美店注册短信防刷
	public static final String BIZNO_REGISTER_SMS="WapMeidianRegisterSms";
	//wap美店手机号绑定短信防刷
	public static final String BIZNO_MOBILE_SMS="WapMeidianMobileSms";
	
	//注册类型-普通注册
	public static String REGISTER_TYPE_COMMONREG="commonReg";
	//注册类型-手机注册
	public static String REGISTER_TYPE_MOBILEREG="mobileReg";
	//注册类型-邮箱注册
	public static String REGISTER_TYPE_EMAILREG="emailReg";
	//注册类型-手机快速注册
	public static String REGISTER_TYPE_MOBILEQUICKREG="mobileQuickReg";
	
	//美店wap-完善手机号
	public static String GOMESHOP_COMPLETA_PHONE_BUSINESSNAME="gomeShop_complete_phone";
	public static String GOMESHOP_COMPLETA_PHONE_BUSINESSNAME_ID="1087";
	//美店wap-绑定账号
	public static String GOMESHOP_BIND_PHONE_BUSINESSNAME="gomeShop_bind_phone";
	public static String GOMESHOP_BIND_PHONE_BUSINESSNAME_ID="1088";
	//美店wap-注册账号
	public static String GOMESHOP_REG_PHONE_BUSINESSNAME="gomeShop_reg_phone";
	public static String GOMESHOP_REG_PHONE_BUSINESSNAME_ID="1089";
	//美店wap-手机号登录
	public static String GOMESHOP_QUICK_PHONE_BUSINESSNAME="gomeShop_quick_login";
	public static String GOMESHOP_QUICK_PHONE_BUSINESSNAME_ID="1091";
	//店主认证服务短信配置
	public static String GOMESHOP_PHONE_AUTH_BUSINESSNAME="gomeShop_phone_auth";
	public static String GOMESHOP_PHONE_AUTH_BUSINESSNAME_ID="1108";
	
	//店主订单累计GMV活动-存在
	public static final int TASK_EXIT = 1;
	//店主订单累计GMV活动-不存在
	public static final int TASK_NOEXIT = 0;
	
	//店主奖赛活动-已结束
	public static final int RANK_NOEXIT = 0;
	//店主奖赛活动-进行中
	public static final int RANK_INGEXIT = 1;
	//店主奖赛活动-未开始
	public static final int RANK_EXIT = 2;
	
	//店主奖赛活动-已报名
	public static final int RANK_TRUE = 1;
	//店主奖赛活动-未报名
	public static final int RANK_FALSE = 0;
	
	//排序类型-销售额排序
	public static final int SORT_PAY = 0;
	//排序类型-订单量排序
	public static final int SORT_ORDER = 1;
	
	//1:当天销售排行 2:当天订单排行 3:活动区间销售排行 4:活动区间订单排行 5:历史天数销售排行 6:历史天数订单排行
	public static final int DAY_SORT_PAY = 1;
	public static final int DAY_SORT_ORDER = 2;
	public static final int TASK_SORT_PAY = 3;
	public static final int TASK_SORT_ORDER = 4;
	public static final int CUM_SORT_PAY = 5;
	public static final int CUM_SORT_ORDER = 6;
	
	//开通店铺状态-已开店
	public static final int VSHOP_TRUE = 1;
	//开通店铺状态-未开店
	public static final int VSHOP_FALSE = 0;
	
}
