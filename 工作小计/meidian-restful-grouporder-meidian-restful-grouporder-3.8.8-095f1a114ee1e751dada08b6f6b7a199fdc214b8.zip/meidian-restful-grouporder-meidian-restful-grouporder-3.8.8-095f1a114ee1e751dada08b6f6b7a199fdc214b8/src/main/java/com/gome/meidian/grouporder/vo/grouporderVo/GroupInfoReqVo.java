package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupProduct;

/**
 * 组团列表入参
 * @author shichangjian
 *
 */
public class GroupInfoReqVo implements Serializable{

	private static final long serialVersionUID = 7041729329055779780L;
//	@Valid
	private List<GroupInfoReq> groupInfoReqs;	// 商品id活动id
	
	public List<GroupInfoReq> getGroupInfoReqs() {
		return groupInfoReqs;
	}
	public void setGroupInfoReqs(List<GroupInfoReq> groupInfoReqs) {
		this.groupInfoReqs = groupInfoReqs;
	}
	
	
}
