package com.gome.meidian.grouporder.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import com.gome.meidian.grouporder.manager.WechatLoginManager;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.vo.wechatLogin.MshopShareRecordVo;

import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.gome.coupon.model.cartBean.CouponBatchResult;
import com.gome.framework.base.ResultDTO;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.memberCore.lang.MapResult;
import com.gome.mobile.common.business.promcms.service.cms.PromJsonCacheService;
import com.gome.mobile.datainfo.model.DataTempletListResponse;
import com.gome.pangu.promotiondata.client.EnergySavingSubsidiesClient;
import com.gome.pangu.promotiondata.client.dto.energysavingsubsidies.EnergySavingSubsidiesParamDTO;
import com.gome.pangu.promotiondata.client.dto.energysavingsubsidies.EnergySavingSubsidiesResultDTO;
import com.gome.pangu.promotiondata.client.dto.energysavingsubsidies.PromotionScopeDTO;
import com.gome.promotion.handle.client.dto.couponrule.CouponRuleInfo;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.aop.StorePriceAOP;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.ChannelUtils;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.CouponEncryptionUtil;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupOrderVerify;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.LogUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.AttendGroupVo;
import com.gome.meidian.grouporder.vo.AuthencationVo;
import com.gome.meidian.grouporder.vo.BannerProductIdVo;
import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.CurrentStepsVo;
import com.gome.meidian.grouporder.vo.GroupOrderDetails;
import com.gome.meidian.grouporder.vo.GroupOrderRegionCMSVo;
import com.gome.meidian.grouporder.vo.ProductDetailPageVo;
import com.gome.meidian.grouporder.vo.ProductParamInfo;
import com.gome.meidian.grouporder.vo.RecommendTabVo;
import com.gome.meidian.grouporder.vo.ShareKidVo;
import com.gome.meidian.grouporder.vo.StepsVo;
import com.gome.meidian.grouporder.vo.coupon.TransitionCoupon;
import com.gome.meidian.grouporder.vo.grouporderVo.Activity;
import com.gome.meidian.grouporder.vo.grouporderVo.Group;
import com.gome.meidian.grouporder.vo.grouporderVo.EnergySavingSubsidiesVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupActivityInfo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupVo;
import com.gome.meidian.grouporder.vo.grouporderVo.HelpGroupVo;
import com.gome.meidian.grouporder.vo.grouporderVo.SkuEnergyAllowanceVo;
import com.gome.meidian.grouporder.vo.product.MeidianPrice;
import com.gome.meidian.grouporder.vo.product.ProductInfo;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.sso.model.UserInfoCache;
import com.gome.stage.interfaces.item.ISkuEnergyAllowanceService;
import com.gome.stage.item.SkuEnergyAllowance;
import com.gome.stage.item.SkuItem;
import com.gome.userCenter.facade.userservice.profile.IUserInfoFacade;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.dto.GomeStore;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopChannelExternalFacade;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.GroupInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.StepsConfigVo;

import cn.com.gome.user.service.QueryUserInfoFacade;
import cn.com.gome.user.v2.model.StaffInfoVo;
import redis.Gcache;

@RestController
@Validated
@RequestMapping("/v1")
public class GroupOrderController {

	private Logger logger = LoggerFactory.getLogger(getClass());
	private final static int USER_GROUPSTATUS_PARTICIPATION = 1; // 用户对团的操作状态,一键参与凑单
	private final static int USER_GROUPSTATUS_OPEN = 2; // 用户对团的操作状态,开团
	private final static int USER_GROUPSTATUS_INVITE = 3; // 用户对团的操作状态,邀请别人凑单
	private final static int USER_GROUPSTATUS_STROLL = 4; // 用户对团的操作状态,去逛逛
	private final static int USER_GROUPSTATUS_NOPOWER = 5; // 用户对团的操作状态,老用户已满
	private final static byte USER_ALREADY_LOGIN = 1; // 用户已登录
	private final static byte USER_NOT_LOGIN = 0; // 用户未登录

	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	@Autowired
	private PromJsonCacheService promJsonCacheService;
//	@Autowired
//	private ICmsService cmsService;
	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	@Autowired
	private VshopChannelExternalFacade vshopChannelExternalFacade;
	@Autowired
	private IUserInfoFacade iUserInfoFacade;
	@Autowired
	private HomeProductsManager homeProductsManager;
	@Autowired
	private ISkuEnergyAllowanceService iSkuEnergyAllowanceService;
	@Autowired
	private AuthencationUtils authencationUtils;
	@Autowired
	private EnergySavingSubsidiesClient energySavingSubsidiesClient;
	@Autowired
	private HttpClientUtil httpClientUtil;
	@Autowired
	private WechatLoginManager wechatLoginManager;
	@Autowired
	private StoreManager storeManager;

    @Value("${gome.defaultStoreCode}")
    private String defaultStoreCode;
	@Value("${gome.loginUrl}")
	private String loginUrl;
	@Value("${cms.recommendTabUrl}")
	private String recommendTabUrl; // http://shark-cms.pre.video.api/v1/slot/store/getStorePage?store_code=A017&page=entity
	@Value("${spring.profiles.active}")
	private String currentEnv;
//	@Value("${gome.shoppingCartUrl}")
//	private String shoppingCartUrl;
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	@Resource(name = "gcache")
	private Gcache gcache;
	@Resource(name = "userCenter")
    private Gcache userCenter;
	@Resource(name = "venusVshop")
	private Gcache venusVshopGcache;
	private String user_id = "user.center.userInfo.manager";
	@Autowired
	private PropertiesConfig propertiesConfig;
//	/**
//	 * 获取热门爆款/精选商品列表
//	 * 
//	 * @param type
//	 *            查询类型：热门爆款-1 精选-2
//	 * @param areaCode
//	 *            区域码
//	 * @param pageNum
//	 *            页码
//	 * @param pageSize
//	 *            条数
//	 * @return
//	 * @throws MeidianException
//	 */
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	@GetMapping("/getRecommendProducts")
//	public ResponseJson getRecommendProducts(@RequestParam(value = "type", defaultValue = "1") Integer type,
//			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
//			@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize, HttpServletRequest request)
//			throws MeidianException {
//		ResponseJson response = new ResponseJson();
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
//		// 热门爆款不需要分页
//		if (type == 1) {
//			pageNum = 1;
//			pageSize = 6;
//		}
//
//		Map<String, Object> resultMap = groupOrderManager.getRecommendProductList(type, areaCode, pageNum, pageSize,
//				request);
//
//		response.setCode((int) resultMap.get("code"));
//		response.setMsg(resultMap.get("message").toString());
//		response.setData(resultMap.get("data"));
//
//		return response;
//	}

	/**
	 * 获取一级分类列表
	 * 
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("getFirstClassifications")
	public ResponseJson getFirstClassifications() {
		ResponseJson response = new ResponseJson();

		Map<String, Object> resultMap = groupOrderManager.getFirstClassificationList();

		response.setCode((int) resultMap.get("code"));
		response.setMsg(resultMap.get("message").toString());
		response.setData(resultMap.get("data"));

		return response;
	}

	/**
	 * 根据一级分类获取商品列表
	 * 
	 * @param firstClassificationId
	 *            一级分类ID
	 * @param areaCode
	 *            区域码
	 * @param pageSize
	 *            条数
	 * @param pageNum
	 *            页码
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getProductsByFirstClassification")
	public ResponseJson getProductsByFirstClassification(
			@NotBlank(message = "{param.error}") @RequestParam(value = "firstClassificationId", required = true) String firstClassificationId,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
			@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum, HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		if (null == areaCode || areaCode.equalsIgnoreCase(""))
			areaCode = defaultAreaCode;
		Map<String, Object> resultMap = groupOrderManager.getProductsByFirstClassification(firstClassificationId,
				areaCode, pageSize, pageNum, request);

		response.setCode((int) resultMap.get("code"));
		response.setMsg(resultMap.get("message").toString());
		response.setData(resultMap.get("data"));

		return response;
	}

//	/**
//	 * 根据商品ID、活动ID列表，区域码查询商品列表（过期）
//	 * 
//	 * @param productIds
//	 * @param areaCode
//	 * @param request
//	 * @return
//	 */
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	@RequestMapping(value = "/getProductGroupOrders", method = RequestMethod.POST)
//	public ResponseJson getProducts(
//			@RequestBody @Validated({ groupOrderVerify.class }) ProductsRequestVo productsRequestVo,
//			HttpServletRequest request) throws MeidianException {
//
//		ResponseJson response = new ResponseJson();
//
//		Map<String, Object> resultMap = new HashMap<>();
//		List<GrouppOrderProductsVo> grouppOrderProductsVo = null;
//		
//		// 整个接口缓存
//		String key = productsRequestVo.getStoreCode() + "_" + productsRequestVo.getUkey() + "_" + ChineseUtils.toHanyuPinyin(productsRequestVo.getTypeName()) + "_" + "oldProducts"; 
//		
////		grouppOrderProductsVo = JSONObject.parseArray(gcache.hget("meidian-restful-grouporder", key), GrouppOrderProductsVo.class);
//		grouppOrderProductsVo = JSONObject.parseArray(gcache.get(key), GrouppOrderProductsVo.class);
//		if(null == grouppOrderProductsVo){
//			grouppOrderProductsVo = groupOrderManager.getProductsByIds(productsRequestVo, request);
//			// 缓存
////			gcache.hset("meidian-restful-grouporder", key, JSONUtils.toJSONString(grouppOrderProductsVo).getBytes());
//			gcache.setex(key, 5 * 60, JSONObject.toJSONString(grouppOrderProductsVo).getBytes());
//		}else{
//			resultMap.put("productInfos", grouppOrderProductsVo);
//		}
//		
//		resultMap.put("productInfos", grouppOrderProductsVo);
//		response.setData(resultMap);
//
//		return response;
//	}

	/**
	 * 商品详情
	 * 
	 * @param productId
	 *            商品ID
	 * @param skuId
	 *            商品SKUID
	 * @param activityId
	 *            活动ID
	 * @param groupId
	 *            团ID，可为空
	 * @param areaCode
	 *            区域码
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getProductInfo")
	public ResponseJson getProductInfo(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId,
			@NotNull(message = "{param.error}") @RequestParam(value = "activityId", required = true) Long activityId,
			@RequestParam(value = "groupId") Long groupId,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "orgCode", required = false) String orgCode,
			@RequestParam(value = "stid", required = false) String storeCode,
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "Channel", required = false) String Channel,
			@CookieValue(value = "g_latitude", required = false) String lat,
			@CookieValue(value = "g_longitude", required = false) String lng,
			String channel,
			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			/*加盟店价格参数end*/
			HttpServletRequest request)
			throws MeidianException {
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
		if (null == areaCode || areaCode.equalsIgnoreCase(""))
			areaCode = defaultAreaCode;
		
		// 站点
		String site = ChannelUtils.site(Channel, channel);
		
		
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		// 如果用户已登录，将获取用户的团状态
		Long userId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		}

		//加盟店逻辑begin
//		if(StringUtils.isNotBlank(Channel) && GroupOrderConstants.CHANNEL_WAP.equals(Channel)){
//			areaCode = MeidianEnvironment.getKey("priceReqAreaCode");
//			storeCode = MeidianEnvironment.getKey("priceReqStoreCode");
//		}
		//加盟店逻辑end
		
		ResponseJson response = new ResponseJson();
		response.setData(groupOrderManager.getProductInfo(activityId, groupId, userId, 
				productId, skuId, areaCode, 
				orgCode, storeCode, ppi, 
				ua, site, lat, lng).get("data"));
		
		return response;
	}

	/**
	 * 获取地址四级联动
	 * 
	 * @param code
	 *            父级code
	 * @param level
	 *            父级级别
	 * @param type
	 *            业务类型
	 * @param gpsLongitude
	 *            经度
	 * @param gpsLatitude
	 *            纬度
	 * @param coordinateName
	 *            坐标类型
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/getAreas")
	public ResponseJson getAreas(@RequestParam("code") String code,
			@RequestParam(value = "level", defaultValue = "0") Integer level,
			@RequestParam(value = "type", defaultValue = "0") Integer type,
			@RequestParam(value = "gpsLongitude") String gpsLongitude,
			@RequestParam(value = "gpsLatitude") String gpsLatitude,
			@RequestParam(value = "coordinateName") String coordinateName) {
		ResponseJson response = new ResponseJson();
		response.setData(groupOrderManager.getAreas(code, level, type, gpsLongitude, gpsLatitude, coordinateName));
		return response;
	}

	/**
	 * 开团/参团
	 * 
	 * @param activityId
	 *            活动ID
	 * @param groupId
	 *            团ID
	 * @param skuId
	 *            SKUID
	 * @param productId
	 *            商品ID
	 * @param buyNumber
	 *            购买件数
	 * @param areaCode
	 *            区域码
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping("/attendGroup")
	public ResponseJson attendGroup(
			@Valid @RequestBody AttendGroupVo attendGroupVo,
			@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "Channel", required = false) String channel,
			HttpServletRequest request) throws MeidianException {

		if(StringUtils.isBlank(channel)) {
			channel = GroupOrderConstants.CHANNEL_MINI;
		}
		if (null == attendGroupVo.getAreaCode() || attendGroupVo.getAreaCode().equalsIgnoreCase("")){
			attendGroupVo.setAreaCode(defaultAreaCode);
		}
		
		// 验证是否登陆，未登陆强制登陆
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		Long userId = null;
		if (null != userInfo && null != userInfo.getId() && !userInfo.getId().equalsIgnoreCase("")) 
			userId = Long.parseLong(userInfo.getId());
		else 
			throw new ServiceException("group.operation.notLoggin");
		

		// 判断限制件数
		GroupActivityInfo groupActivityInfo = groupOrderManager.getActivityInfo(attendGroupVo.getSkuId());
		if (null == groupActivityInfo || null == groupActivityInfo.getPurchaseLimitNum()) 
			throw new ServiceException("activity.is.null");
		if (attendGroupVo.getBuyNumber().intValue() > groupActivityInfo.getPurchaseLimitNum())
			throw new ServiceException("buyNumber.over");
			
		//取用户是否为新老客户
		boolean newUser = groupOrderManager.checkoutNewOldUser(userInfo.getId());
		// 判断是否已参团
		if (null != attendGroupVo.getGroupId() && attendGroupVo.getGroupId().longValue() > 0) {

			int status = groupOrderManager.getStatusToGroup(attendGroupVo.getActivityId(), attendGroupVo.getGroupId(), userId);
			// 3-已参团只能分享 4-团失效
			if (status == 3 || status == 4) {
				throw new ServiceException("attendGroup.status");
			}
			
			if(!newUser){
				//老客户，调取团详情接口			
				// 默认区域码
				String regionCode = attendGroupVo.getAreaCode();
				CommonResultEntity<GroupInfoVo> commonResultEntity = gorderInfoForAppNewResource.getGroupInfoById(attendGroupVo.getGroupId(), regionCode, attendGroupVo.getSkuId(), userId, null);
				if (commonResultEntity.getCode() != GroupOrderConstants.SUCCESS_CODE)
					logger.error("getGroupInfoById groupId: {} commonResultEntity ==> {} ", attendGroupVo.getGroupId(),
							JSONUtils.toJSONString(commonResultEntity));
				GroupInfoVo groupInfoVo = commonResultEntity.getBusinessObj();
				if (null != groupInfoVo) {
					GroupOrderDetails groupOrderDetails = new GroupOrderDetails();
					BeanUtils.copyProperties(groupInfoVo, groupOrderDetails);
					//老用户，如果老客户参团人员已达上线，无法参团，否则一键参与凑单 
					Integer oldUserMaxNum = groupOrderDetails.getOldUserMaxNum();//最大参团人数
					Integer oldUserNum = groupOrderDetails.getOldUserNum() == null ? 0 : groupOrderDetails.getOldUserNum();//已参团人数
					if(oldUserMaxNum != null && oldUserNum.intValue() >= oldUserMaxNum.intValue()){
						throw new ServiceException("attendGroup.status.alreadyMax");//没有权限参团，人数已达上限
					}
				}

				
			}
		}else if ( null == attendGroupVo.getGroupId() ){
			//开团处理
			//老客户, 取商品集 ,判断老客户阈值
			if(!newUser){
				Integer oldUserMaxNum = groupActivityInfo.getOldUserMaxNum() ;//最大参团人数
				if(oldUserMaxNum != null && 0 == oldUserMaxNum){
					throw new ServiceException("attendGroup.status.alreadyMax");//没有权限参团，人数已达上限
				}
			}

		}
		

		

		// 根据用户注册时间判断是否参0折团,暂时下线
//		if(null != groupId && groupId > 0){
//			if(productResult.getGroupBusType() == 3){
//				String usId = String.valueOf(userId);
//				String key = user_id + ":" + RedisKeyUtils.getHKey(usId);
//				String userInfoCache = userCenter.hget(key,usId);
//				UserInfo user = JSONObject.parseObject(userInfoCache, UserInfo.class);
//				if(null != user && null != user.getRegisterTime()){
//					long systemTime = System.currentTimeMillis();
//					if((systemTime - user.getRegisterTime().getTime()) > 1000 * 60 * 60 * 24)
//						throw new ServiceException("old.user.notGroup");
//				}
//			}
//		}
		
		// 将生成的团Id、sku等信息返回
		ResponseJson response = new ResponseJson();
		Map<String, Object> resultMap = groupOrderManager.attendGroup(
				userId, attendGroupVo.getGroupId(),attendGroupVo.getActivityId(), 
				attendGroupVo.getProductId(), attendGroupVo.getBuyNumber(), attendGroupVo.getSkuId(), 
				attendGroupVo.getAreaCode(), attendGroupVo.getKid(), attendGroupVo.getModeType(),
				attendGroupVo.getFlowActivityId(), attendGroupVo.getPagecode(), attendGroupVo.getStaffId(), 
				attendGroupVo.getStoreCode(), channel
				);

		response.setCode((int) resultMap.get("code"));
		response.setMsg(resultMap.get("message").toString());
		response.setData(resultMap.get("data"));

		return response;
	}

	/**
	 * 我的凑单列表----小程序
	 * TODO  可通过从cookie中获取渠道等参数区分端与“我的凑单列表”接口优化合并
	 * @param status
	 * @param pageNum
	 * @param pageSize
	 * @param scn
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/getMyGroupOrderListForMini")
	public ResponseJson getMyGroupOrderListForMini(@RequestParam(value = "status", defaultValue = "0") Integer status,
			@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
			@CookieValue(value = "SCN", required = false) String scn, HttpServletRequest request) throws MeidianException {

		ResponseJson response = new ResponseJson();
		Map<String, Object> resultMap = this.getMyGroupOrderListByChannel(status, pageNum, pageSize, "MINI", scn, request);
		response.setCode((int) resultMap.get("code"));
		response.setMsg(resultMap.get("message").toString());
		response.setData(resultMap.get("data"));

		return response;
	}
	
	/**
	 * 我的凑单列表
	 * 
	 * @param status
	 *            状态
	 * @param pageNum
	 *            页码
	 * @param pageSize
	 *            条数
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@GetMapping("/getMyGroupOrderList")
	public ResponseJson getMyGroupOrderList(@RequestParam(value = "status", defaultValue = "0") Integer status,
			@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "Channel", required = false) String Channel,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		
		if(null != Channel && !Channel.equals("")){
			if(Channel.equals(GroupOrderConstants.CHANNEL_IOS_APP) 
					|| Channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP))
				return response;
		}
		
		Map<String, Object> resultMap = this.getMyGroupOrderListByChannel(status, pageNum, pageSize, null, scn, request);
		response.setCode((int) resultMap.get("code"));
		response.setMsg(resultMap.get("message").toString());
		response.setData(resultMap.get("data"));

		return response;
	}

	private Map<String, Object> getMyGroupOrderListByChannel(Integer status, Integer pageNum, Integer pageSize, String reqChannel,String scn, HttpServletRequest request) throws ServiceException{
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		Long userId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		} else {
			throw new ServiceException("group.operation.notLoggin");
		}

		Map<String, Object> resultMap = groupOrderManager.getMyGroupOrderList(userId, status, pageNum, pageSize, reqChannel, 
				request);
		resultMap.put("login", 1);
		return resultMap;
	}
	/**
	 * 根据团id，区域码，查询团详情（凑单详情）信息
	 * 
	 * @param groupId
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getGroupInfoById", method = RequestMethod.GET)
	public ResponseJson getGroupInfoById(
			@NotNull(message = "{param.error}") @RequestParam(value = "groupId") Long groupId,
			@RequestParam(value = "orderId", required = false) String orderId,
			@RequestParam(value = "regionCode", required = false) String regionCode,
			@NotBlank(message = "{param.error}") @RequestParam(value = "skuId") String skuId,
			@RequestParam(value = "orgCode", required = false) String orgCode,
			@RequestParam(value = "stid", required = false) String storeCode,
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "g_latitude", required = false) String lat,
			@CookieValue(value = "g_longitude", required = false) String lng,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
		if (null == regionCode || regionCode.equalsIgnoreCase(""))
			regionCode = defaultAreaCode;

		// 1.根据scn获取userId
		UserInfoCache userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		String id = null;
		if (null != userInfoCache)
			id = userInfoCache.getId();
		
		// 根据团id，区域码，获取凑单详情
		CommonResultEntity<GroupInfoVo> commonResultEntity = gorderInfoForAppNewResource.getGroupInfoById(groupId, regionCode, skuId, id == null ? null : Long.valueOf(id), orderId);
		if (commonResultEntity.getCode() != GroupOrderConstants.SUCCESS_CODE)
			logger.error("getGroupInfoById groupId: {} commonResultEntity ==> {} ", groupId,
					JSONUtils.toJSONString(commonResultEntity));

		GroupInfoVo groupInfoVo = commonResultEntity.getBusinessObj();
		if (null != groupInfoVo) {
			GroupOrderDetails groupOrderDetails = new GroupOrderDetails();
			BeanUtils.copyProperties(groupInfoVo, groupOrderDetails);
			
			//根据助力团标识、用户id、参团情况判断能否跳转到助力团详情
			//只有助力团进行此逻辑判断
			if(null != groupInfoVo.getHelpAllow() && 1 == groupInfoVo.getHelpAllow()) {
				
				if(id == null) {
					groupOrderDetails.setHelpAllow(0);
				}else {
					//团长默认跳转
					if(groupOrderDetails.getHeaderUserId() != null && !id.equals(groupOrderDetails.getHeaderUserId().toString())) {
						groupOrderDetails.setHelpAllow(0);
						List<GroupUserInfo> groupUserList = groupOrderDetails.getGroupUser();
						if(null != groupUserList && groupUserList.size() > 0) {
							for(GroupUserInfo info: groupUserList) {
								//非团长，参团克跳转
								if(null != info && null != info.getUserId() && id.equals(info.getUserId().toString())) {
									groupOrderDetails.setHelpAllow(1);
									break;
								}
							}
						}
					}
				}
			}
			
			// 获取团状态
			Integer status = groupOrderDetails.getStatus();
			long curTime = System.currentTimeMillis();
			// 团进行中
			if (null != status) {
				if (status == 1 || status == 0) {
					if (null != id) {
						boolean userStatus = false;
						// 取出团成员
						List<GroupUserInfo> groupUserInfos = groupOrderDetails.getGroupUser();
						for (GroupUserInfo groupUserInfo : groupUserInfos) {
							if (String.valueOf(groupUserInfo.getUserId()).equalsIgnoreCase(id)) {
								userStatus = true;
								break;
							}
						}
						if (userStatus) {
							// 邀请好友凑单
							groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_INVITE);
						} else {
							// 校验新老用户,新用户参团
							boolean newUser = groupOrderManager.checkoutNewOldUser(id);
							if(newUser){
								// 一键参与凑单 新用户
								groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_PARTICIPATION);
							}else{
								//老用户，如果老客户参团人员已达上线，无法参团，否则一键参与凑单 
								Integer oldUserMaxNum = groupOrderDetails.getOldUserMaxNum() ;//最大参团人数
								Integer oldUserNum = groupOrderDetails.getOldUserNum() == null ? 0 : groupOrderDetails.getOldUserNum();//已参团人数
								if(oldUserMaxNum != null && oldUserNum.intValue() >= oldUserMaxNum.intValue()){
									// 0折团老用户满  老用户只能开团
//									if(groupOrderDetails.getGroupBusType() == 3) {
//										groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_OPEN);
//									}else {
										groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_NOPOWER);//没有权限
//									}
								}else{
									groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_PARTICIPATION);//一键参团
								}
							}
						}
					} else {
						// 一键参与凑单
						groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_PARTICIPATION);
					}

				} else if (status == 2) {
					// 团结束
					// 去逛逛
					groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_STROLL);
				}
			}

			if (null != id && id.equals(groupOrderDetails.getHeaderUserId().toString())) {
				if (groupOrderDetails.getStartTime().getTime() <= curTime
						&& groupOrderDetails.getEndTime().getTime() > curTime) {
					groupOrderDetails.setUserGroupStatus(USER_GROUPSTATUS_INVITE);
				}
			}

			// 获取当前活动中正在进行中的团数量
//			groupOrderDetails.setGroupNum(groupOrderManager.getGroupNum(groupInfoVo.getActivityId()));

			// 转换阶梯信息
			List<CurrentStepsVo> currentStepsVos = JSONObject.parseArray(groupOrderDetails.getStepsConfig(),
					CurrentStepsVo.class);
			groupOrderDetails.setCurrentStepsVos(currentStepsVos);

			// 团倒计时
			long groupCountdown = groupOrderDetails.getEndTime().getTime() - System.currentTimeMillis();
			if (groupCountdown <= 0)
				groupCountdown = 0;
			groupOrderDetails.setGroupCountdown(groupCountdown);

			// 处理头像大小
			groupOrderManager.imageSizeInfo(groupOrderDetails, MeidianEnvironment.getPPI(), ua);
			
			// 美店价
			ProductInfoVo productInfo = groupOrderDetails.getProductInfo();
			MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(groupOrderDetails.getProductId(), productInfo.getSkuId(), MeidianEnvironment.getKey("priceReqAreaCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL);
			if(null != meidianPrice){
				String mPrice = meidianPrice.getMeidianPrice();
				if(null == mPrice){
					Double price = DoubleUtils.divide(Double.valueOf(productInfo.getPrice()), 100d, 2);
					groupOrderDetails.setMeidianPrice(DoubleUtils.switchScientificCalculate(price));
					groupOrderDetails.setPriceKey(null);
				}else{
					groupOrderDetails.setMeidianPrice(meidianPrice.getMeidianPrice());
					groupOrderDetails.setPriceKey(meidianPrice.getPriceKey());
				}
			}else{
				Double price = DoubleUtils.divide(Double.valueOf(productInfo.getPrice()), 100d, 2);
				groupOrderDetails.setMeidianPrice(DoubleUtils.switchScientificCalculate(price));
				groupOrderDetails.setPriceKey(null);
			}
			
			// 处理美店价，国美价，美店价大于国美价时，把美店价赋值给国美价
			long mPri = DoubleUtils.mul(Double.valueOf(groupOrderDetails.getMeidianPrice()), 100D).longValue();
			if(mPri > productInfo.getPrice().longValue())
				productInfo.setPrice(mPri);
						
			//获取节能补贴（政府）或者节能优惠（国美）
			//北京地区使用节能补贴，非北京地区使用节能优惠
			SkuItem sku = groupOrderManager.getSkuInfo(groupOrderDetails.getProductId(), productInfo.getSkuId());
			String skuNo = sku.getSkuNo();
			if(meidianPrice !=null && meidianPrice.getPriceType() != null && !meidianPrice.getPriceType().equals("SHOP_PRICE")){
				if(regionCode.startsWith("110")){
					if(null != groupInfoVo.getProductInfo() && null != groupInfoVo.getProductInfo().getAllowanceFlag() && 1 == groupInfoVo.getProductInfo().getAllowanceFlag()){
//						SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceById(skuId, regionCode);

//	                    SkuEnergyAllowance skuEnergyAllowance = null;
//						if(StringUtils.isNotBlank(storeCode) && storeCode.length() == 4 && !storeCode.startsWith("QDMD")){
		            	if(StringUtils.isNotBlank(storeCode)){
		            		Store store = storeManager.getStoreInfo(storeCode, GroupOrderConstants.GET_ORGCODE_BY_STORECODE_STORETYPE, lng, lat);
		            		if(null != store){
		            			orgCode = store.getOrganizationId();
		            		}
		            	}
							SkuEnergyAllowance skuEnergyAllowance = iSkuEnergyAllowanceService.getSkuEnergyAllowanceByNo(skuNo, orgCode);
//						}
						if(null != skuEnergyAllowance){
							//显示价大于报备价，则不展示节能补贴信息
							if(null != skuEnergyAllowance.getRecordPrice() && groupOrderDetails.getProductInfo().getPrice().longValue() <= (skuEnergyAllowance.getRecordPrice().doubleValue() * 100)){
								SkuEnergyAllowanceVo skuEnergyAllowanceVo = new SkuEnergyAllowanceVo();
								BeanUtils.copyProperties(skuEnergyAllowance, skuEnergyAllowanceVo);
								groupOrderDetails.setSkuEnergyAllowance(skuEnergyAllowanceVo);
							}
						}
					}
				}else{
					
					EnergySavingSubsidiesParamDTO param = new EnergySavingSubsidiesParamDTO();
					param.setSkuNo(skuNo);
					PromotionScopeDTO scope = new PromotionScopeDTO();
					scope.setAreaCode(regionCode);
					scope.setStoreCode(storeCode);
					scope.setSite(GroupOrderConstants.ENERGY_SAVING_SUBSIDIES_MEIDIAN_SITE);
					
					String uId = null == id ? null : id.toString();
					ResultDTO<EnergySavingSubsidiesResultDTO> resultDto = energySavingSubsidiesClient.getEnergySavingSubsidiesBySkuNo(uId, param, scope, "detail");
					if(null != resultDto && resultDto.isSuccess()){
						EnergySavingSubsidiesResultDTO dto = resultDto.getData();
						if(null != dto){
							EnergySavingSubsidiesVo dtoVo = new EnergySavingSubsidiesVo();
							BeanUtils.copyProperties(dto, dtoVo);
							groupOrderDetails.setEnergySavingSubsidies(dtoVo);
						}
					}	
				}
			}

			// 延保
			if((groupOrderDetails.getGroupBusType() == null ? 3 : groupOrderDetails.getGroupBusType().intValue()) != GroupOrderConstants.free_group){
				Integer warranty = groupOrderManager.appreciationServeCheckout(productInfo.getSkuNo(), meidianPrice.getMeidianPrice(), orgCode);
				groupOrderDetails.setWarranty(warranty);
			}
			
			//当前用户是否新用户
			groupOrderDetails.setCurrentUserFlag(groupOrderManager.checkoutNewOldUser(id) ? 1 : 0);
			responseJson.setData(groupOrderDetails);
		}

		return responseJson;
	}

//	/**
//	 * 更多推荐接口 剔除当前详情页中的商品id（剔除最上面的凑单商品）
//	 * 
//	 * @param firstClassificationId
//	 *            一级分类id
//	 * @param productId
//	 * @return
//	 * @throws MeidianException
//	 */
//	@RequestMapping(value = "/getMoreProducts", method = RequestMethod.GET)
//	public ResponseJson getMoreProducts(
//			@NotNull(message = "{param.error}") @RequestParam(value = "activityId") Long activityId,
//			@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
//			@RequestParam(value = "pageSize", defaultValue = "12") Integer pageSize,
//			@NotBlank(message = "{param.error}") @RequestParam(value = "firstClassificationId") String firstClassificationId,
//			@NotBlank(message = "{param.error}") @RequestParam(value = "productId") String productId,
//			@RequestParam(value = "regionCode", required = false) String regionCode) throws MeidianException {
//		ResponseJson responseJson = new ResponseJson();
//		if (null == regionCode || regionCode.equalsIgnoreCase(""))
//			regionCode = defaultAreaCode;
//		CommonResultEntity<FirstClassificationProductsVo> commonResultEntity = gorderInfoForAppResource
//				.getMoreProducts(activityId, regionCode, firstClassificationId, productId, pageNum, pageSize);
//
//		logger.debug("getMoreProducts ==> {} ", JSONUtils.toJSONString(commonResultEntity));
//
//		if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
//			logger.info("getMoreProducts productId ==> {} ", productId);
//
//			FirstClassificationProductsVo firstClassificationProductsVo = new FirstClassificationProductsVo();
//			firstClassificationProductsVo.setTotalNum(commonResultEntity.getBusinessObj().getTotalNum());
//			// 过滤下架商品,1：上架，-1：下架
//			firstClassificationProductsVo.setProductInfo(commonResultEntity.getBusinessObj().getProductInfo().stream()
//					.filter(f -> null != f.getProductStatus() && f.getProductStatus() == 1)
//					.collect(Collectors.toList()));
//			responseJson.setData(firstClassificationProductsVo);
//		} else {
//			logger.error("getMoreProducts productId: {} commonResultEntity ==> {} ", productId,
//					JSONUtils.toJSONString(commonResultEntity));
//		}
//
//		return responseJson;
//	}

//	/**
//	 * 当前活动中正在进行中的团活动数量
//	 * 
//	 * @param activityId
//	 * @return
//	 * @throws MeidianException
//	 */
//	@RequestMapping(value = "/getActivationGroupNum", method = RequestMethod.GET)
//	public ResponseJson getActivationGroupNum(
//			@NotNull(message = "{param.error}") @RequestParam(value = "activityId") Long activityId)
//			throws MeidianException {
//		ResponseJson responseJson = new ResponseJson();
//
//		CommonResultEntity<ActivationGroupVo> commonResultEntity = gorderInfoForAppResource
//				.getActivationGroupNum(activityId);
//
//		logger.debug("getActivationGroupNum ==> {} ", JSONUtils.toJSONString(commonResultEntity));
//
//		if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
//			logger.info("getActivationGroupNum ==> {}", commonResultEntity.getBusinessObj());
//			responseJson.setData(commonResultEntity.getBusinessObj());
//		} else {
//			logger.error("getActivationGroupNum activityId: {} commonResultEntity ==> {} ", activityId,
//					JSONUtils.toJSONString(commonResultEntity));
//		}
//
//		return responseJson;
//	}

	/**
	 * 根据活动id获取阶梯信息
	 * 
	 * @param activityId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getStepsConfig", method = RequestMethod.GET)
	public ResponseJson getStepsConfig(
			@NotNull(message = "{param.error}") @RequestParam(value = "activityId") Long activityId)
			throws MeidianException {
		ResponseJson responseJson = new ResponseJson();

		CommonResultEntity<StepsConfigVo> commonResultEntity = gorderInfoForAppNewResource.getStepsConfig(activityId);

		logger.debug("getStepsConfig ==> {}", JSONUtils.toJSONString(commonResultEntity));

		if (commonResultEntity.getCode() == GroupOrderConstants.SUCCESS_CODE) {
			logger.info("getStepsConfig ==> {} ", activityId);
			StepsConfigVo stepsConfigVo = commonResultEntity.getBusinessObj();
			StepsVo stepsVo = new StepsVo();
			stepsVo.setStepsNum(stepsConfigVo.getStepsNum());
			List<CurrentStepsVo> currentStepsVos = JSONObject.parseArray(stepsConfigVo.getStepsConfigStr(),
					CurrentStepsVo.class);
			stepsVo.setCurrentStepsVos(currentStepsVos);
			responseJson.setData(stepsVo);
		} else {
			logger.error("getStepsConfig activityId: {} commonResultEntity ==> {} ", activityId,
					JSONUtils.toJSONString(commonResultEntity));
		}

		return responseJson;
	}

	/**
	 * CMS 活动入口，凑单玩法说明
	 * 
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getGroupOrderPrefectureCMS", method = RequestMethod.GET)
	public ResponseJson getGroupOrderPrefectureCMS(
			@NotBlank(message = "{param.error}") @RequestParam("cmsKey") String cmsKey) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();

		logger.info("getGroupOrderPrefectureCMS cmsKey ==> {} ", cmsKey);

		DataTempletListResponse dataTempletListResponse = null;
		try {
			dataTempletListResponse = promJsonCacheService.getAllDataTempletListResponse(cmsKey);
		} catch (Exception e) {
			logger.error("getGroupOrderPrefectureCMS dataTempletListResponse: {} failed ==> {} ",
					dataTempletListResponse, e);
			return responseJson;
		}

		logger.debug("getGroupOrderPrefectureCMS ==> {} ", JSONUtils.toJSONString(dataTempletListResponse));

		GroupOrderRegionCMSVo groupOrderRegionCMSVo = null;

		if (null != dataTempletListResponse) {
			groupOrderRegionCMSVo = new GroupOrderRegionCMSVo();
			groupOrderRegionCMSVo.setServerTime(dataTempletListResponse.getServerTime());
			groupOrderRegionCMSVo.setDataTempletInfos(dataTempletListResponse.getTempletList());
		}
		// 改名，把list改成负数s,WriteMapNullValue:保留null值
		String result = JSONObject.toJSONString(groupOrderRegionCMSVo, SerializerFeature.WriteMapNullValue);
		String newResult = result.replaceAll("templetList", "templets").replaceAll("dataList", "datas")
				.replaceAll("imgUrlList", "imgUrls");
		JSONObject obj = JSONObject.parseObject(newResult);

		responseJson.setData(obj);

		return responseJson;
	}

//	/**
//	 * 获取地区码(无需登录)
//	 * 
//	 * @param gpsLongitude
//	 * @param gpsLatitude
//	 * @return
//	 * @throws MeidianException
//	 */
//	@RequestMapping(value = "/getGpsArea", method = RequestMethod.GET)
//	public ResponseJson getGpsArea(@RequestParam("gpsLongitude") Object gpsLongitude,
//			@RequestParam("gpsLatitude") Object gpsLatitude) throws MeidianException {
//
//		ResponseJson responseJson = new ResponseJson();
//		GomeAddress gomeAddress = new GomeAddress();
//		if(null == gcache.get("gpsOnOff"))
//			gomeAddress = cmsService.getGpsArea(gpsLongitude, gpsLatitude);
//		else{
//			gomeAddress.setDefaultFlag(true);
//			gomeAddress.setProvinceId("11000000");
//			gomeAddress.setCityId("11010000");
//			gomeAddress.setDistrictId("11010200");
//			gomeAddress.setTownId("110102001");
//			gomeAddress.setCityName("北京市");
//			gomeAddress.setDistrictName("朝阳区(五环里)");
//			gomeAddress.setTownName("全部区域");
//		}
//				
//			
//		responseJson.setData(gomeAddress);
//		return responseJson;
//	}
	
	/**
	 * 校验登录
	 * 
	 * @param scn
	 * @return
	 */
	@RequestMapping(value = "/authencationLogin", method = RequestMethod.GET)
	public ResponseJson authencationLogin(
			@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "Channel", required = false) String Channel)
			throws MeidianException {
		ResponseJson responseJson = new ResponseJson();

		LogUtils.logInfo(GroupOrderController.class, "登录校验SCN:" + scn);
		if(null != Channel && !Channel.equals("")){
			if(Channel.equals(GroupOrderConstants.CHANNEL_IOS_APP) 
					|| Channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP))
				return responseJson;
		}
		responseJson.setData(groupOrderManager.authenticationLogin(scn));
		return responseJson;
	}


	/**
	 * 获取kid
	 * 
	 * @param urlReqDto
	 * @return
	 */
	@RequestMapping(value = "/shareUrlByKid", method = RequestMethod.POST)
	public ResponseJson shareUrlByKid(@RequestBody @Validated({ groupOrderVerify.class }) ShareKidVo shareKidVo) {
		ResponseJson responseJson = new ResponseJson();

		Map<String, String> map = groupOrderManager.shareUrlByKid(shareKidVo);

		String mid = shareKidVo.getMid();
		String stid = shareKidVo.getStid();
		String userId = shareKidVo.getUserId();
		String pgid = shareKidVo.getPgid();
		String chid = shareKidVo.getChid();
		String back = shareKidVo.getBack();

		if (null == mid || mid.equalsIgnoreCase("")) {
			mid = "0";
		}
		if (null == stid || stid.equalsIgnoreCase("")) {
			stid = "0";
		}
		if (null == userId || userId.equalsIgnoreCase("")) {
			userId = "0";
		}
		if (null == pgid || pgid.equalsIgnoreCase("")) {
			pgid = "0";
		}
		if (null == chid || chid.equalsIgnoreCase("")) {
			chid = "0";
		}
		if (null == back || back.equalsIgnoreCase("")) {
			back = "0";
		}
		Map<String, String> valueMap = new HashMap<>();
		valueMap.put("mid", mid);
		valueMap.put("stid", stid);
		valueMap.put("userId", userId);
		valueMap.put("pgId", pgid);
		valueMap.put("chId", chid);
		valueMap.put("back", back);

		gcache.hmsetex(map.get("kid"), valueMap, 3600 * 24 * 7);

		// gcache.setex(map.get("kid"), 3600*24*7, mid + "_" + stid + "_" +
		// userId + "_" + pgid + "_" + chid + "_" + back);

		responseJson.setData(map);
		return responseJson;
	}

	/**
	 * 提供楼上cms后台使用
	 * 618 根据三级地址查询渠道美店及数字门店信息集合 number：0-代表全部, 其他数字代表返回条数
	 * 
	 * @param areaId
	 *            三级区域id
	 * @param number
	 * @return
	 */
	@RequestMapping(value = "/shopInformation", method = RequestMethod.GET)
	public ResponseJson shopInformation(@NotBlank(message = "{param.error}") @RequestParam("areaId") String areaId,
			@NotNull(message = "{param.error}") @RequestParam("number") Integer number) {
		ResponseJson responseJson = new ResponseJson();

		CommonResultEntity<List<GomeStore>> commonResultEntity = vshopChannelExternalFacade
				.getChannelAndStoreByArea(areaId, number);

		logger.debug("shopInformation commonResultEntity ==> {} ", JSONUtils.toJSONString(commonResultEntity));
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("gomeStores", commonResultEntity.getBusinessObj());

		logger.info("shopInformation areaId ==> {} ", areaId);

		responseJson.setData(map);
		return responseJson;
	}

	/**
	 * 618 获取推荐位tab
	 * 
	 * @param storeCode
	 *            国美店铺code
	 * @param assignPage
	 *            index 首页；topsaler 爆款；hotsaler 热销；entity 实体门店首页，即凑单首页
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/recommendTab", method = RequestMethod.GET)
	public ResponseJson recommendTab(
			@NotBlank(message = "{param.error}") @RequestParam("storeCode") String storeCode,
			@NotBlank(message = "{param.error}") @RequestParam("assignPage") String assignPage,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			HttpServletRequest request) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		Map<String, Object> resultMap = new HashMap<String, Object>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("store_code", storeCode);
		map.put("page", assignPage);
		String result = null;
		
		List<RecommendTabVo> recommendTabVo = null;
		recommendTabVo = JSONObject.parseArray(gcache.get("recommendTab" + "_" + storeCode + "_" + assignPage), RecommendTabVo.class);
		if(null == recommendTabVo){
			try {
				result = httpClientUtil.doGet(recommendTabUrl, map);
			} catch (Exception e) {
				e.printStackTrace();
			}
			JSONObject obj = null;
			try {
				obj = JSONObject.parseObject(result);
			} catch (Exception e) {
				responseJson.setData(resultMap);
				return responseJson;
			}
			
			JSONObject data = null;
			Object list = null;
			try {
				data = (JSONObject) obj.get("data");
				if (null == data) {
					responseJson.setData(resultMap);
					return responseJson;
				}
				list = data.get("list");
				if (null == list) {
					responseJson.setData(resultMap);
					return responseJson;
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			// WriteMapNullValue:保留null值
			String re = JSONObject.toJSONString(list, SerializerFeature.WriteMapNullValue);
			// 改字段名
			String newResult = re.replaceAll("activity_date", "activityDate");
			recommendTabVo = JSONObject.parseArray(newResult, RecommendTabVo.class);
			
			// 添加缓存20秒
			gcache.setex("recommendTab" + "_" + storeCode + "_" + assignPage, 20, JSONObject.toJSONString(recommendTabVo));
		}
		
		int weekDay = DateUtils.getWeekDay();
		for (RecommendTabVo recommendTab : recommendTabVo) {
			String date = recommendTab.getActivityDate();

			// 当前时间,默认
			if (StringUtils.contains(date, String.valueOf(weekDay))) {
				recommendTab.setDefaultDate(1);
				// 根据ukey请求banner，一级分类id，及productId，avtivityId
				BannerProductIdVo bannerProductIdVo = groupOrderManager.getProductIds(recommendTab.getUkey(), ppi, ua, request);
				recommendTab.setBannerProductIdVo(bannerProductIdVo);
			}

			// 获取显示位置
			String tab = recommendTab.getActivityDate();
			switch (weekDay) {

			case 1:
				// tab位置，当前是周一，上周六日，位置是1
				// 周一周二是2
				// 周三周四是3
				// 周五是4
				// 如果tab是6,7， 位置是1
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是1,2， 位置是2
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是3,4， 位置是3
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是5， 位置是4
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			case 2:
				// tab位置，当前是周二，上周六日，位置是1
				// 周一周二是2
				// 周三周四是3
				// 周五是4
				// 如果tab是6,7， 位置是1
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是1,2， 位置是2
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是3,4， 位置是3
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是5， 位置是4
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			case 3:
				// tab位置，当前是周三，周一周二，位置是1
				// 周三周四是2
				// 周五是3
				// 周六周日是4
				// 如果tab是1,2， 位置是1
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是3,4， 位置是2
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是5， 位置是3
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是6,7， 位置是4
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			case 4:
				// tab位置，当前是周四，周一周二，位置是1
				// 周三周四是2
				// 周五是3
				// 周六周日是4
				// 如果tab是1,2， 位置是1
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是3,4， 位置是2
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是5， 位置是3
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是6,7， 位置是4
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			case 5:
				// tab位置，当前是周五，周三周四，位置是1
				// 周五是2
				// 周六周日是3
				// 下周一周二是4
				// 如果tab是3,4， 位置是1
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是5， 位置是2
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是6,7， 位置是3
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是1,2， 位置是4
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			case 6:
				// tab位置，当前是周六，周五，位置是1
				// 周六周日是2
				// 下周一周二是3
				// 下周三周四是4
				// 如果tab是5， 位置是1
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是6,7， 位置是2
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是1,2， 位置是3
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是3,4， 位置是4
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			case 7:
				// tab位置，当前是周日，周五，位置是1
				// 周六周日是2
				// 下周一周二是3
				// 下周三周四是4
				// 如果tab是5， 位置是1
				if (tab.equalsIgnoreCase("5")) {
					recommendTab.setTabLocation(1);
					continue;
				}
				// 如果tab是6,7， 位置是2
				if (tab.equalsIgnoreCase("6,7")) {
					recommendTab.setTabLocation(2);
					continue;
				}
				// 如果tab是1,2， 位置是3
				if (tab.equalsIgnoreCase("1,2")) {
					recommendTab.setTabLocation(3);
					continue;
				}
				// 如果tab是3,4， 位置是4
				if (tab.equalsIgnoreCase("3,4")) {
					recommendTab.setTabLocation(4);
					continue;
				}
			}
		}

		resultMap.put("recommendTabVo", recommendTabVo);
		responseJson.setData(resultMap);
		
		
		
//		end1 = System.currentTimeMillis();
//		sum1 = end1 - start1;
//		second1 = (int) (sum1 / 1000);
//		logger.info("tab interface second1 ==> {} millisecond1 ==> {}", second1, sum1);
//		if(second1 > 1 && second1 < 2){
//			logger.info("1-2 interfaceSecond1");
//		}else if(second1 > 2 && second1 < 3){
//			logger.info("2-3 interfaceSecond1");
//		}else if(second1 > 3 && second1 < 10){
//			logger.info("3-10 interfaceSecond1");
//		}else if(second1 > 10){
//			logger.info("10 interfaceSecond1");
//		}
		
		
		
		
		
		
		
		
		return responseJson;
	}

	/**
	 * 618 通过uniqueKey获取banner图，商品id和活动id，优惠劵，活动页ukey
	 * 
	 * @param uniqueKey
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getProductIds", method = RequestMethod.GET)
	public ResponseJson getProductIds(
			@NotBlank(message = "{param.error}") @RequestParam("uniqueKey") String uniqueKey,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			HttpServletRequest request) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		
		BannerProductIdVo bannerProductIdVo = groupOrderManager.getProductIds(uniqueKey, ppi, ua, request);
		
		responseJson.setData(bannerProductIdVo);
		return responseJson;
	}

//	/**
//	 * 获取购物车url
//	 * 
//	 * @return
//	 * @throws MeidianException
//	 */
//	@RequestMapping(value = "/shoppingCartUrl", method = RequestMethod.GET)
//	public ResponseJson shoppingCartUrl() throws MeidianException {
//		ResponseJson responseJson = new ResponseJson();
//
//		Map<String, String> map = new HashMap<String, String>();
//		map.put("shoppingCartUrl", shoppingCartUrl);
//
//		responseJson.setData(map);
//		return responseJson;
//	}

//	/**
//	 * 获取活动页(过期)
//	 * 
//	 * @return
//	 * @throws MeidianException
//	 */
//	@RequestMapping(value = "/getActivityPageInfo", method = RequestMethod.GET)
//	public ResponseJson getActivityPageInfo(@NotBlank(message = "{param.error}") @RequestParam("uniqueKey") String ukey,
//			@RequestParam(value = "areaCode", required = false) String areaCode,
//			@RequestParam(value = "organizationId", required = false) String organizationId, HttpServletRequest request)
//			throws MeidianException {
//		ResponseJson responseJson = new ResponseJson();
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
//		
//		String key = ukey + "_" + "activityPage";
//		
//		// 拉取缓存
//		ActivityPage activityPage = JSONObject.parseObject(gcache.hget("meidian-restful-grouporder-interface", key), ActivityPage.class);
//		if(null == activityPage){
//			activityPage = groupOrderManager.getActivityPageInfo(ukey, areaCode, organizationId, request);
//			// 添加到缓存
//			gcache.hset("meidian-restful-grouporder-interface", key, JSONUtils.toJSONString(activityPage).getBytes());
//		}
//		
//		responseJson.setData(activityPage);
//		return responseJson;
//	}

	/**
	 * 领劵中间页
	 * 
	 * @param productId
	 * @param couponId
	 * @param areaCode
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@MDStorePriceAnnotation
	@GetMapping("/getCouponProductView")
	public ResponseJson getCouponProductView(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "couponId", required = true) String couponId,
			@RequestParam(value = "planId", required = false) String planId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "couponType", required = true) String couponType,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "skuId", required = false) String skuId,
			@RequestParam(value = "organizationId", required = false) String organizationId, 
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;

		response.setData(groupOrderManager.getCouponProductView(productId, skuId, couponId, couponType, MeidianEnvironment.getKey("priceReqAreaCode"), organizationId, MeidianEnvironment.getPPI(), ua, planId, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID));
		return response;
	}

	/**
	 * 单券领劵中间页更多推荐
	 * 
	 * @param areaCode
	 * @param organizationId
	 * @param request
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@MDStorePriceAnnotation
	@GetMapping("/getMoreCouponProductView")
	public ResponseJson getMoreCouponProductView(@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "organizationId", required = false) String organizationId,
//			@CookieValue(value = "PPI", required = false) Integer ppi,
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			HttpServletRequest request) throws MeidianException{
		ResponseJson response = new ResponseJson();
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
//		if (null == areaCode || areaCode.equalsIgnoreCase(""))
//			areaCode = defaultAreaCode;
		
		List<ProductParamInfo> productParamInfos = groupOrderManager
				.getMoreCouponProductView(GroupOrderConstants.MORE_PRODUCT_UKEY, MeidianEnvironment.getKey("priceReqAreaCode"), MeidianEnvironment.getPPI(), ua, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.PRICE_POLICYID);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("productParamInfos", productParamInfos);

		response.setData(map);
		return response;
	}

//	/**
//	 * 领劵
//	 * @param promoId 劵方案id或批次号
//	 * @param couponId 劵规则id，风控使用
//	 * @param scn
//	 * @param request
//	 * @return
//	 * @throws MeidianException
//	 */
//	@SuppressWarnings("rawtypes")
//	@GetMapping("/fetchCoupon")
//	public ResponseJson fetchCoupon(
//			@NotBlank(message = "{param.error}") @RequestParam(value = "promoId", required = true) String promoId,
//			@NotBlank(message = "{param.error}") @RequestParam(value = "couponType", required = true) String couponType,
//			@RequestParam(value = "activeId", required = false) String activeId,
//			@RequestParam(value = "couponId", required = false)	String couponId,
//			@CookieValue(value = "Channel", required = false) String channel,
//			@CookieValue(value = "SCN", required = false) String scn, HttpServletRequest request)
//			throws MeidianException {
//		ResponseJson response = new ResponseJson();
//		Map<String, Object> resMap = new HashMap<String, Object>();
//		if(null == channel) channel = GroupOrderConstants.CHANNEL_WAP;
//		String userId = authencationUtils.authenticationLogin(scn);
//		if(null == userId) {
//			resMap.put("login", 0);
//			response.setData(resMap);
//			return response;
//		}
//		resMap.put("login", 1);
//
//		resMap.put("status", groupOrderManager.fetchCoupon(couponType, promoId, userId, activeId, couponId, channel, request));
//
//		response.setData(resMap);
//		return response;
//	}

	/**
	 * 获取评论
	 * 
	 * @param productId
	 * @param page
	 * @param appraiseType
	 * @return
	 */
	// @GetMapping("/getAppraise")
	// public ResponseJson getAppraise(
	// @NotBlank(message = "{param.error}") @RequestParam(value = "productId",
	// required = true) String productId,
	// @NotNull(message = "{param.error}") @RequestParam(value = "pageNum",
	// defaultValue = "1") Integer pageNum,
	// @NotBlank(message = "{}param.error") @RequestParam(value =
	// "appraiseType", defaultValue = "all") String appraiseType){
	// ResponseJson response = new ResponseJson();
	// response.setData(groupOrderManager.getAppraise(productId, pageNum,
	// appraiseType));
	// return response;
	// }

	/**
	 * 红蓝券详情信息
	 * 
	 * @param ruleId
	 * @return
	 */
	// @GetMapping("/getFuseCoupon")
	// public ResponseJson getFuseCoupon(
	// @NotBlank(message = "{param.error}") @RequestParam(value = "ruleId",
	// required = true) String ruleId){
	// ResponseJson response = new ResponseJson();
	// response.setData(groupOrderManager.getCoupon(ruleId));
	// return response;
	// }

	/**
	 * 领红蓝券
	 * 
	 * @param promoId
	 * @param scn
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	// @GetMapping("/fetchRedBlueCoupon")
	// public ResponseJson fetchRedBlueCoupon(
	// @NotBlank(message = "{param.error}") @RequestParam(value = "promoId",
	// required = true) String promoId,
	// @CookieValue(value = "SCN", required = false) String scn,
	// HttpServletRequest request) throws MeidianException{
	// ResponseJson response = new ResponseJson();
	// UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
	// String userId = null;
	// if(userInfo != null && StringUtils.isNotBlank(userInfo.getId())){
	// userId = userInfo.getId();
	// }else{
	// throw new ServiceException("group.operation.notLoggin");
	// }
	//
	// Map<String, Object> resultMap = new HashMap<>();
	// resultMap.put("status", groupOrderManager.fetchRedBlueCoupon(promoId,
	// userId, request));
	// response.setData(resultMap);
	// return response;
	// }

	/**
	 * sku是否有货
	 * 
	 * @param daId
	 * @param daId2
	 * @param skuNo
	 * @return
	 */
	// @GetMapping("/getSkuCount")
	// public ResponseJson getSkuCount(
	// @NotBlank(message = "{param.error}") @RequestParam(value = "daId",
	// required = true) String daId,
	// @RequestParam(value = "daId2") String daId2,
	// @NotBlank(message = "{param.error}") @RequestParam(value = "skuNo",
	// required = true) String skuNo){
	// ResponseJson response = new ResponseJson();
	// response.setData(groupOrderManager.getSkuCount(daId, daId2, skuNo));
	// return response;
	// }

	/**
	 * sku列表
	 * 
	 * @param productId
	 * @param skuId
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getSkuAttr")
	public ResponseJson getSkuAttr(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("skuAttr", groupOrderManager.getSkuAttr(productId, skuId));
		response.setData(resultMap);
		return response;
	}

	/**
	 * 获取sku列表信息（sku详情）
	 * 
	 * @param productId
	 * @param skuId
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getSkuItem")
	public ResponseJson getSkuItem(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId)
			throws MeidianException {
		ResponseJson response = new ResponseJson();
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("skuItem", groupOrderManager.getSkuInfo(productId, skuId));
		response.setData(resultMap);
		return response;
	}

	/**
	 * 专题活动页分享
	 * 
	 * @param uniqueKey
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getMdtShare")
	public ResponseJson getMdtShare(
			@NotBlank(message = "{param.error}") @RequestParam(value = "uniqueKey") String uniqueKey)
			throws MeidianException {
		ResponseJson response = new ResponseJson();

		response.setData(groupOrderManager.getMdtShare(uniqueKey));
		return response;
	}

	/**
	 * 商品基础详情页
	 * 
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @param scn
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@GetMapping("/getProductDetail")
	public ResponseJson getProductDetail(
			@NotBlank(message = "{param.error}") @RequestParam(value = "productId", required = true) String productId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "orgCode", required = false) String orgCode,
			@RequestParam(value = "stid", required = false) String storeCode,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "Channel", required = false) String Channel,
			@CookieValue(value = "g_latitude", required = false) String lat,
			@CookieValue(value = "g_longitude", required = false) String lng,
			String channel,
			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			/*加盟店价格参数end*/
			HttpServletRequest request) throws MeidianException {
		// 获取设备
		Byte ua = ImageUtils.userAgentChannel(request);
		// 默认区域码
		if (null == areaCode || areaCode.equalsIgnoreCase(""))
			areaCode = defaultAreaCode;

		// 站点
		String site = ChannelUtils.site(Channel, channel);
		
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String userId = null;
		if (userInfo != null && StringUtils.isNotBlank(userInfo.getId())) {
			userId = userInfo.getId();
		}

		// 加盟店逻辑begin
//		if(StringUtils.isNotBlank(Channel) && GroupOrderConstants.CHANNEL_WAP.equals(Channel)){
//			areaCode = MeidianEnvironment.getKey("priceReqAreaCode");
//			storeCode = MeidianEnvironment.getKey("priceReqStoreCode");
//		}
		// 加盟店逻辑end
		
		ProductDetailPageVo productDetailPageVo = groupOrderManager.productDetail(userId, productId, skuId, 
				areaCode, orgCode, storeCode, 
				ppi, ua, site, lat, lng);

		response.setData(productDetailPageVo);
		return response;
	}
	
	/**
	 * 查询劵信息
	 * 
	 * @param couponId
	 * @param couponType
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getCoupon")
	public ResponseJson getCoupon(
			@NotBlank(message = "{param.error}") @RequestParam(value = "couponId", required = true) String couponId,
			@RequestParam(value = "planId", required = false) String planId,
			@NotBlank(message = "{param.error}") @RequestParam(value = "couponType", required = true) String couponType)
			throws MeidianException {

		Coupon coupon = new Coupon();
		if (couponType.equalsIgnoreCase(GroupOrderConstants.COUPON_TYPE_CMS_POP)) {
			// pop劵
			CouponBatchResult couponBatchResult = groupOrderManager.getPopCoupon(couponId);
			if (null != couponBatchResult) {
				coupon.setCoupon_num(couponBatchResult.getDenomination()); // 面额
				coupon.setDescription(couponBatchResult.getDescription());
				coupon.setFullAmount(couponBatchResult.getLimitPrice()); // 满多少元可用
				coupon.setCouponType(String.valueOf(couponBatchResult.getType())); // 0:店铺券, 2:平台券，3：商品劵
				coupon.setCoupon_id(couponId); // pop劵批次号
				coupon.setActiveId(couponBatchResult.getActiveId()); // 领取标识，劵活动id
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				coupon.setShow_start_time(sdf.format(couponBatchResult.getStartDate()));
				coupon.setShow_end_time(sdf.format(couponBatchResult.getEndDate()));
				
				// pop劵加密
                String id = CouponEncryptionUtil.popCouponEncryption(couponId, coupon.getCouponType(), couponBatchResult.getShopNo(), couponBatchResult.getActiveId());
                coupon.setEncryptionId(id);
			}
		} else {
			// 美劵
			CouponRuleInfo couponRuleInfo = groupOrderManager.getCoupon(couponId);
			if (null != couponRuleInfo) {
				coupon.setCoupon_id(couponRuleInfo.getRuleId());
				coupon.setCoupon_num(couponRuleInfo.getAmount());
				coupon.setFullAmount(couponRuleInfo.getLimitAmount() == null ? 0D : couponRuleInfo.getLimitAmount());
				coupon.setDescription(couponRuleInfo.getDescription());
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				coupon.setShow_start_time(sdf.format(couponRuleInfo.getCouponStartDate()));
				coupon.setShow_end_time(sdf.format(couponRuleInfo.getCouponEndDate()));
				coupon.setCouponType(couponRuleInfo.getType());
				coupon.setPlan_id(planId);
				
				// 美红蓝营销劵加密
                String id = CouponEncryptionUtil.beautifulCouponEncryption(planId, couponRuleInfo.getType());
                coupon.setEncryptionId(id);
			}
		}
		ResponseJson response = new ResponseJson();

		response.setData(coupon);
		return response;
	}
	
	/**
	 * 根据商品编码查询券信息
	 * 
	 * @param couponId
	 * @param couponType
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/getCouponBySkuId")
	public ResponseJson getCouponBySkuId(
			@RequestParam(value = "shopNo", required = false) String shopNo,
			@NotBlank(message = "{param.error}") @RequestParam(value = "skuId", required = true) String skuId,
			@RequestParam(value = "productId", required = false) String productId,
			@RequestParam(value = "price", required = false) String price,
			@CookieValue(value = "SCN", required = false) String scn,
			@RequestParam(value = "areaCode", required = false) String areaCode)
			throws MeidianException {
		
		String userId = authencationUtils.authenticationLogin(scn);
		
		// 二级区域处理
		if(null == areaCode || areaCode.equals(""))
			areaCode = propertiesConfig.getDefaultAreaCode();
		
		List<Coupon> couponList = groupOrderManager.getCouponBySkuId(productId, skuId, userId, 
				areaCode);
		ResponseJson response = new ResponseJson();
		response.setData(couponList);
		return response;
	}
	
	/**
	 * 用户参与活动次数限制
	 * @param activityId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getUserGroupNumCheck", method = RequestMethod.GET)
	public ResponseJson getUserGroupNumCheck(
			@NotNull(message = "{param.error}") @RequestParam("activityId") Long activityId,
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
		
//		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
//		Long userId = null;
//		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
//			userId = Long.parseLong(userInfo.getId());
//		} else {
//			throw new ServiceException("group.operation.notLoggin");
//		}
		
//		Map<String, Object> resMap = new HashMap<String, Object>();
		
		resMap.put("userGroupNumCheck", groupOrderManager.getUserGroupNumCheck(Long.valueOf(userId), activityId));
		response.setData(resMap);
		return response;
	}
	
	/**
	 * 商品开团次数限制
	 * @param activityId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getProductGroupNumCheck", method = RequestMethod.GET)
	public ResponseJson getProductGroupNumCheck(
			@NotNull(message = "{param.error}") @RequestParam("productId") String productId,
			@NotNull(message = "{param.error}") @RequestParam("activityId") Long activityId
			)throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		resMap.put("productGroupNumCheck", groupOrderManager.getProductGroupNumCheck(productId, activityId));
		
		response.setData(resMap);
		return response;
	}
	
	/**
	 * sku级别的上下架状态
	 * @param productSkus
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getProductSkuStatus", method = RequestMethod.GET)
	public ResponseJson getProductSkuStatus(
			@NotEmpty(message = "{param.error}") @RequestParam("skus") List<String> skus,
			@NotBlank(message = "{param.error}") @RequestParam("productId") String productId
			)throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		resMap.put("productSkuStatus", groupOrderManager.getProductSkuStatus(productId, skus));
		
		response.setData(resMap);
		return response;
	}

	/**
	 * 为php单独提供的接口
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/authencationLoginForPhp", method = RequestMethod.GET)
	public ResponseJson authencationLoginForPhp(String scn)
			throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		UserInfoCache userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		AuthencationVo authencationVo = new AuthencationVo();
		if (null == userInfoCache || StringUtils.isBlank(userInfoCache.getId())) {
			logger.info("scn:{}  no login",scn);
			// 未登录，返回主站登录页链接
			authencationVo.setLogin(USER_NOT_LOGIN);
			authencationVo.setLoginUrl(loginUrl);
		} else {
			// 登录，返回userId
			String userId = userInfoCache.getId();
			logger.info("scn:{}  userId ==> {} ",scn, userId);
			authencationVo = JSONObject.parseObject(gcache.get("checkUserId_" + userId), AuthencationVo.class);

			if(authencationVo == null){
				authencationVo = new AuthencationVo();
				authencationVo.setLogin(USER_ALREADY_LOGIN);
				authencationVo.setUserId(userId);

				// 根据userId获取stId
				CommonResultEntity<StaffInfoVo> commonResultEntity = queryUserInfoFacade.getStaffInfoByUserId(userId);

				logger.debug("authencationLogin commonResultEntity ==> {} ", JSONUtils.toJSONString(commonResultEntity));

				StaffInfoVo staffInfoVo = commonResultEntity.getBusinessObj();
				String stId = null;
				if (null != staffInfoVo)
					stId = staffInfoVo.getStoreNo();
				// logger.info("authencationLogin stId ==> {} ", stId);
				authencationVo.setStoreNo(stId);

				// 根据userId获取用户昵称
				Map<String, Object> paraMap = new HashMap<>();
				paraMap.put("companyName", "gomeOnLine");
				MapResult<UnifyUserInfoExt> result = iUserInfoFacade.getItemByIdForGomeShop(userId, "gomeShopMobile", paraMap);
				if(result != null && result.isSuccess()){
					UnifyUserInfoExt userVo = result.getBuessObj();
					String nickName = null;
					if (null != userVo)
						nickName = userVo.getNikename();
					// logger.info("authencationLogin nickName ==> {} ", nickName);
					authencationVo.setNickName(nickName);
				}

				gcache.setex("checkUserId_" + userId, 10 * 60, JSONObject.toJSONString(authencationVo));
			}
			String vshopKey = "vshop:vshopInfo_userId:" + userId;
			VshopInfo shopInfo = JSONObject.parseObject(venusVshopGcache.get(vshopKey), VshopInfo.class);
			if(shopInfo != null){
				authencationVo.setShopId(shopInfo.getVshopId());
			}
		}
		authencationVo.setCurrentEnv(currentEnv);
		responseJson.setData(authencationVo);
		return responseJson;
	}
	
	/**
	 * 根据skuId获取组团活动信息
	 * @param productId
	 * @param skuId
	 * @return
	 */
	@RequestMapping(value = "/getGroupActivity", method = RequestMethod.GET)
	public ResponseJson getGroupActivity(
			@NotBlank(message = "{param.error}") @RequestParam("skuId") String skuId
			) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		
		responseJson.setData(groupOrderManager.getActivityInfo(skuId));
		return responseJson;
	}

	/**
	 * 组团sku详情
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getGroupSku", method = RequestMethod.GET)
	public ResponseJson getGroupSku(
			@NotBlank(message = "{param.error}") @RequestParam("productId") String productId,
			@NotBlank(message = "{param.error}") @RequestParam("skuId") String skuId,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "orgCode", required = false) String orgCode,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			String storeCode,
			Integer storeType,
			@CookieValue(value = "Channel", required = false) String Channel,
			String channel,
			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			/*加盟店价格参数end*/
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		// 默认区域码
		if (null == areaCode || areaCode.equalsIgnoreCase(""))
			areaCode = defaultAreaCode;
		Byte ua = ImageUtils.userAgentChannel(request);
				
		// 站点
		String site = ChannelUtils.site(Channel, channel);
		
		//加盟店逻辑begin
//		if(StringUtils.isNotBlank(Channel) && GroupOrderConstants.CHANNEL_WAP.equals(Channel)){
//			areaCode = MeidianEnvironment.getKey("priceReqAreaCode");
//			storeCode = MeidianEnvironment.getKey("priceReqStoreCode");
//		}
		//加盟店逻辑end
		
		responseJson.setData(groupOrderManager.getGroupSku(productId, skuId, areaCode, 
	    		orgCode, ppi, ua,
	    		site, storeCode, storeType));
		return responseJson;
	}
	
	/**
	 * 获取sku详情
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getSkuDetail", method = RequestMethod.GET)
	public ResponseJson getSkuDetail(
			@NotBlank(message = "{param.error}") @RequestParam("productId") String productId,
			@NotBlank(message = "{param.error}") @RequestParam("skuId") String skuId,
			@RequestParam(value = "areaCode", required = false) String areaCode,
			@RequestParam(value = "orgCode", required = false) String orgCode,
			@CookieValue(value = "PPI", required = false) Integer ppi,
			String storeCode,
			Integer storeType,
			@CookieValue(value = "Channel", required = false) String Channel,
			String channel,
			
			/*加盟店价格参数begin*/
//			@CookieValue(value = "StoreCode", required = false) String StoreCode,
//			@CookieValue(value = "AreaCode", required = false) String AreaCode,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "switchingStore", required = false) String switchingStore,
//			@CookieValue(value = "countyAreaCode", required = false) String countyAreaCode,
//			@CookieValue(value = "longitude", required = false) String longitude,
//			@CookieValue(value = "latitude", required = false) String latitude,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			/*加盟店价格参数end*/
			
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		// 默认区域码
		if (null == areaCode || areaCode.equalsIgnoreCase(""))
			areaCode = defaultAreaCode;
		// 站点
		String site = ChannelUtils.site(Channel, channel);
		Byte ua = ImageUtils.userAgentChannel(request);
		
		//加盟店逻辑begin
//		if(StringUtils.isNotBlank(Channel) && GroupOrderConstants.CHANNEL_WAP.equals(Channel)){
//			areaCode = MeidianEnvironment.getKey("priceReqAreaCode");
//			storeCode = MeidianEnvironment.getKey("priceReqStoreCode");
//		}
		//加盟店逻辑end
		
		responseJson.setData(groupOrderManager.getSkuDetail(productId, skuId, areaCode, 
	    		orgCode, site, storeCode, 
	    		storeType, ppi, ua));
		return responseJson;
	}

	/**
	 * 获取团id
	 * @param activityId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/getGroupId", method = RequestMethod.GET)
	public ResponseJson getGroupId(
			@NotNull(message = "{param.error}") @RequestParam("activityId") Long activityId,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		// 如果用户已登录，将获取用户的团状态
		Long userId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		}
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		if(null == userId){
			resMap.put("groupId", null);
			responseJson.setData(resMap);
			return responseJson;			
		}
		
		resMap = groupOrderManager.getGroupId(userId, activityId);
		
		responseJson.setData(resMap);
		return responseJson;
	}
	
	/**
	 * 团详情-新（暂时 集客被分享人使用）
	 * @param groupId
	 * @param areaCode
	 * @param skuId
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getGroupInfo", method = RequestMethod.GET)
	public ResponseJson getGroupInfo(
			@NotNull(message = "{param.error}") @RequestParam("groupId") Long groupId,
			@RequestParam(value = "orderId") String orderId,
			@NotBlank(message = "{param.error}") @RequestParam("areaCode") String areaCode,
			@NotBlank(message = "{param.error}") @RequestParam("skuId") String skuId,
			@RequestParam(value = "organizationId", required = false) String organizationId,
//			@RequestParam(value = "shareStoreCode", required = false) String shareStoreCode,
//			@RequestParam(value = "type", required = false) String type,
//			@CookieValue(value = "ShareUserId", required = false) String shareUserId,
//			@CookieValue(value = "Channel", required = false) String Channel,
//			@CookieValue(value = "m_u_areaCode", required = false) String AreaCode,
//			@RequestParam(value = "switching_store", required = false) String switchingStore,
//			@RequestBody(required = false) PriceReqUtils priceReqUtils,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException{
		
		ResponseJson response = new ResponseJson();
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) 
			resMap.put("login", 0);
		else
			resMap.put("login", 1);
		
		// 根据团id，区域码，获取凑单详情
		CommonResultEntity<GroupInfoVo> commonResultEntity = gorderInfoForAppNewResource.getGroupInfoById(groupId, areaCode, skuId, null, orderId);
		if (commonResultEntity.getCode() != GroupOrderConstants.SUCCESS_CODE)
			logger.error("getGroupInfoById ==> groupId=={} ", groupId);
		
		GroupInfoVo groupInfoVo = commonResultEntity.getBusinessObj();
		Integer status = null;
		if (null != groupInfoVo) {
			// 获取团状态
			status = groupInfoVo.getStatus();
			// 团进行中
			if (null != status) {
				if (status.intValue() == 1 || status.intValue() == 0) {
					boolean userStatus = false;
					// 取出团成员
					List<GroupUserInfo> groupUserInfos = groupInfoVo.getGroupUser();
					for (GroupUserInfo groupUserInfo : groupUserInfos) {
						if (String.valueOf(groupUserInfo.getUserId()).equalsIgnoreCase(userId)) {
							userStatus = true;
							break;
						}
					}
					if (userStatus) {
						// 邀请好友凑单
						status = USER_GROUPSTATUS_INVITE;
					} else {
						// 一键参与凑单
						status = USER_GROUPSTATUS_PARTICIPATION;
					}

				} else if (status.intValue() == 2) {
					// 团结束
					// 去逛逛
					status = USER_GROUPSTATUS_STROLL;
				}
			}
		}
		
		resMap.put("status", status);
		
		GroupVo groupVo = new GroupVo();
		
		ProductInfoVo productInfoVo = groupInfoVo.getProductInfo();
		// 商品信息
		ProductInfo productInfo = new ProductInfo(groupInfoVo.getProductId(), productInfoVo.getSkuId(), productInfoVo.getSkuNo(), 
				productInfoVo.getProductName(), productInfoVo.getShopId(), productInfoVo.getProductImage(),
				productInfoVo.getProductTag(), DoubleUtils.switchScientificCalculate(DoubleUtils.divide(Double.valueOf(productInfoVo.getPrice()), 100d, 2)), productInfoVo.getProductStatus(), 
				null, null);
		
		// 活动信息
		Activity activity = new Activity();
		activity.setMaxDiscountNeedPeopleNum(groupInfoVo.getMaxDiscountNeedPeopleNum());
		activity.setActivityId(groupInfoVo.getActivityId());
		activity.setBuyNumber(groupInfoVo.getBuyNumber());
		activity.setMaxDiscount(groupInfoVo.getMaxDiscount());
		
		// 团信息
		Group group = new Group(groupId, groupInfoVo.getCurrentMemberNum(), null, 
				null, null);
		
		// 美店价
		MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(productInfo.getProductId(), productInfo.getSkuId(), MeidianEnvironment.getKey("priceReqAreaCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL, MeidianEnvironment.getKey("priceReqStoreCode"), GroupOrderConstants.MEIDIANPRICE_CHANNEL);
		if(null != meidianPrice){
			String mPrice = meidianPrice.getMeidianPrice();
			if(null == mPrice){
				productInfo.setMeidianPrice(productInfo.getPrice());
			}else{
				productInfo.setMeidianPrice(meidianPrice.getMeidianPrice());
				productInfo.setPriceKey(meidianPrice.getPriceKey());
			}
		}else{
			productInfo.setMeidianPrice(productInfo.getPrice());
		}
		
		// 处理美店价，国美价，美店价大于国美价时，把美店价赋值给国美价
		long mPri = DoubleUtils.mul(Double.valueOf(productInfo.getMeidianPrice()), 100D).longValue();
		if(Double.valueOf(productInfo.getMeidianPrice()).doubleValue() > Double.valueOf(productInfo.getPrice()).doubleValue())
			productInfo.setPrice(productInfo.getMeidianPrice());
		
		// 折扣返
		Double meiPrice = Double.valueOf(productInfo.getMeidianPrice());
		Double pr = DoubleUtils.mul(meiPrice, 100d);
		activity.setRebateAmount(groupOrderManager.getRebateAmount(pr.longValue(), groupInfoVo.getMaxDiscount()));
		
		groupVo.setProductInfo(productInfo);
		groupVo.setGroup(group);
		groupVo.setActivity(activity);
		groupVo.setStatus(status);
		
		resMap.put("groupVo", groupVo);
		
		response.setData(resMap);
		return response;
	}

	/**
	 * 国美wap微信授权信息保存
	 *
	 * @param mshopShareRecordVo
	 * @param request
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/gomeWap/weChatAuthorizationInfo", method = RequestMethod.POST)
	public ResponseJson getWapWeChatUserInfo(
			@Valid @RequestBody MshopShareRecordVo mshopShareRecordVo,
			HttpServletRequest request) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		logger.info("getWapWeChatUserInfo ==> controller requestParam={} ", JSONUtils.toJSONString(mshopShareRecordVo));
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("type", wechatLoginManager.handleAuthorizationInfo(mshopShareRecordVo));
		
		responseJson.setData(resultMap);
		return responseJson;
	}

	/**
	 * 国美wap 美店wap 小程序注册登录公用接口（绑定关系）
	 *
	 * @param mshopShareRecordVo
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/registerLoginBindInfo", method = RequestMethod.POST)
	public ResponseJson responseJson(@Valid @RequestBody MshopShareRecordVo mshopShareRecordVo) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		logger.info("registerLoginBindInfo ==> controller requestParam={} ", JSONUtils.toJSONString(mshopShareRecordVo));
		
		resultMap = wechatLoginManager.handleRegisterLoginBindInfo(mshopShareRecordVo);
		
		logger.info("registerLoginBindInfo ==> controller responseParam={} ", JSONUtils.toJSONString(resultMap));
		
		responseJson.setData(resultMap);
		return responseJson;
	}

	/**
	 * 美店分享授权信息保存
	 *
	 * @param mshopShareRecordo
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/meiDian/WeChatAuthorizationInfo", method = RequestMethod.POST)
	public ResponseJson getMDWeChatUserInfo(
			@Valid @RequestBody MshopShareRecordVo mshopShareRecordVo) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		logger.info("getMDWeChatUserInfo ==> controller requestParam={} ", JSONUtils.toJSONString(mshopShareRecordVo));
		responseJson.setData(wechatLoginManager.handleMDAuthorizationInfo(mshopShareRecordVo));
		return responseJson;
	}
	
	/**
	 * 店主转劵
	 * @return
	 */
	@RequestMapping(value = "/transitionCoupon", method = RequestMethod.GET)
	public ResponseJson transitionCoupon(
		@NotBlank(message = "{param.error}") @RequestParam("couponType") String couponType, 
		@NotBlank(message = "{param.error}") @RequestParam("couponId") String couponId, 
		@NotBlank(message = "{param.error}") @RequestParam("oldUserId") String oldUserId, 
		@CookieValue(value = "SCN", required = false) String scn
		) throws MeidianException {
		
		ResponseJson response = new ResponseJson();	
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		//是否登录
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
				
		// 红劵转赠
		Byte type = null;
		
		// 美，蓝劵，神
		if(couponType.equals("101")
				|| couponType.equals("1")
				|| couponType.equals("102")){
			
			type = homeProductsManager.transitionBeautifulCoupon(couponType, couponId, oldUserId, userId);
		}else if(couponType.equals("0") || couponType.equals("7")){
			
			// 红劵
			type = groupOrderManager.transitionRedCoupon(couponType, couponId, oldUserId, userId);
		}
		
		resMap.put("type", type);
		
		response.setData(resMap);
	    return response;
	}
	
	/**
	 * 查询用户和劵的状态
	 * @return
	 */
	@RequestMapping(value = "/findUserCoupons", method = RequestMethod.GET)
	public ResponseJson findUserCoupons(
			@NotBlank(message = "{param.error}") @RequestParam("couponType") String couponType, 
			@NotEmpty(message = "{param.error}") @RequestParam("couponIds") List<String> couponIds, 
			@RequestParam("oldUserId") String oldUserId,
			@CookieValue(value = "SCN", required = false) String scn
			) throws MeidianException {
		
		ResponseJson response = new ResponseJson();	
		
		Map<String, Object> resMap = new HashMap<String, Object>();
		//是否登录
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) 
			resMap.put("login", 0);
		else 
			resMap.put("login", 1);
		
		List<TransitionCoupon> transitionCoupons = groupOrderManager.findUserCoupons(couponType, oldUserId, userId, couponIds);
		resMap.put("transitionCoupons", transitionCoupons);
		
		response.setData(resMap);
		return response;
	}
	
	
	
	/**
	 * 图片处理
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/testImage", method = RequestMethod.GET)
	public void testImage(
			HttpServletRequest request,
			HttpServletResponse response
			) throws IOException {
		
//	    OutputStream os = null;
//    	try {
//    	    BufferedImage logo = ImageLoadUtil.getImageByPath("2018-07-13_163918.png");
//    	    BufferedImage qrCode = ImageLoadUtil.getImageByPath("2019-02-23_171445.png");
//    	    String name = "商品标题商品标题商品标题商品标题商品标题商品标题";
//    	    List<String> desc = Arrays.asList("我是一灰灰，一匹不吃羊的狼", "专注码农技术分享");
//
//    	    int w = QrCodeCardTemplate.w, h = QrCodeCardTemplate.h;
//    	    List<IMergeCell> list = QrCodeCardTemplateBuilder.build(logo, name, desc, qrCode, "微 信 公 众 号");
//
//    	    BufferedImage bg = ImgMergeWrapper.merge(list, w, h);
////    	    ImageIO.write(bg, "jpg", new File("E:/merge.jpg"));
//    		
//    	    ByteArrayOutputStream out = new ByteArrayOutputStream();
//			boolean flag = ImageIO.write(bg, "gif", out);
//    		
//    	    
//			byte[] data = out.toByteArray();
//    	    
//			response.setContentType("image/png");
//	        os = response.getOutputStream();
//	        os.write(data);
//	        os.flush();
//    	}catch(IOException e){
//    		
//    	} 
    	    
	}
	
	/**
	 * 校验店主是否能看此订单详情
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/authencationMid", method = RequestMethod.GET)
	public ResponseJson authencationMid(
			@NotBlank(message = "{param.error}") @RequestParam("orderId") String orderId,
			@CookieValue(value = "SCN", required = false) String scn
			)throws MeidianException{
	    ResponseJson response = new ResponseJson();
	    Map<String, Object> resMap = new HashMap<String, Object>();
		String userId = authencationUtils.authenticationLogin(scn);
		if(null == userId) {
			resMap.put("login", 0);
			resMap.put("type", 0);
			response.setData(resMap);
			return response;
		}
		resMap.put("login", 1);
	    
		// 校验店主是否能看此订单详情
		resMap.put("type", groupOrderManager.authencationMid(orderId, userId));
		response.setData(resMap);
	    
	    return response;
	}	
	
//	/**
//	 * 获取分享时的默认助力团订单信息
//	 * @param groupId
//	 * @param scn
//	 * @return
//	 * @throws ServiceException
//	 */
////	@GetMapping("/getHelpOrderInfo")
//	@Deprecated
//	public ResponseJson getHelpOrderInfo(
//			@Min(message = "{param.error}", value = 1) @RequestParam(name = "groupId", required = true) Long groupId,
//			@CookieValue(name = "SCN", required = false) String scn) throws ServiceException{
//		ResponseJson response = new ResponseJson();
//		// 验证是否登陆，未登陆强制登陆
//		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
//		String userId = null;
//		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
//			userId = userInfo.getId();
//		}
//		else {
//			throw new ServiceException("group.operation.notLoggin");
//		}
//		
//		Map<String, String> resultMap = new HashMap<>();
//		resultMap.put("shareOrderId", groupOrderManager.getHelpGroupUserInfo(groupId, userId));
//		response.setData(resultMap);
//		return response;
//	}
	
	/**
	 * 助力信息
	 * @param groupId  团ID
	 * @param orderid  订单ID
	 * @param userId   被助力者、发起者
	 * @return
	 * @throws MeidianException 
	 */
	@GetMapping("/helpGroupUserInfo")
	public ResponseJson helpGroupUserInfo(
			@Min(message = "{param.error}", value = 1) @RequestParam(name = "groupId", required = true) Long groupId,
			@NotBlank(message = "{param.error}") @RequestParam(name = "userId", required = true) String userId,
			@NotBlank(message = "{param.error}") @RequestParam(name = "orderId", required = true) String orderId,
			@CookieValue(name = "SCN", required = false) String scn) throws MeidianException{
		ResponseJson response = new ResponseJson();
		// 验证是否登陆，未登陆强制登陆
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String currentUserId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			currentUserId = userInfo.getId();
		}
		else {
			throw new ServiceException("group.operation.notLoggin");
		}
		response.setData(groupOrderManager.helpGroupUserInfo(groupId, userId, currentUserId, orderId));
		return response;
	}
	
//	/**
//	 * 助力榜单列表
//	 * @param groupId
//	 * @param pageSize
//	 * @param pageNo
//	 * @return
//	 */
//	@GetMapping("/helpGroupMemberList")
//	public ResponseJson helpGroupMemberList(
//			@Min(message = "{param.error}", value = 1) @RequestParam(name = "groupId", required = true) Long groupId,
//			@RequestParam(name = "pageSize", defaultValue = "10") Integer pageSize,
//			@RequestParam(name = "pageNum", defaultValue = "1") Integer pageNum){
//		ResponseJson response = new ResponseJson();
//		response.setData(groupOrderManager.helpGroupMemberList(groupId, pageSize, pageNum));
//		return response;
//	}
	
	/**
	 * 好友助力
	 * @param attendGroup
	 * @param scn
	 * @return
	 * @throws ServiceException
	 */
	@PostMapping("/helpGroup")
	public ResponseJson helpGroup(
			@Valid @RequestBody HelpGroupVo attendGroup,
			@CookieValue(value = "Channel", required = false) String channel,
			@CookieValue(value = "ctx", required = false) String ctx,
			@CookieValue(name = "SCN", required = false) String scn,HttpServletRequest request) throws MeidianException{
		ResponseJson response = new ResponseJson();
		if(null == channel) channel = GroupOrderConstants.CHANNEL_WAP; 
		// 验证是否登陆，未登陆强制登陆
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		String helpUserId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			helpUserId = userInfo.getId();
		}
		else {
			throw new ServiceException("group.operation.notLoggin");
		}
		
		if(StringUtils.isBlank(ctx)){
			Cookie ctxCookie = CookieUtils.getCookieByName(request, "ctx");
			if(null != ctxCookie) {
				ctx = ctxCookie.getValue();
			}
		}
		
		Map<String, String> ctxMap = CookieUtils.buildRequestHeader(ctx);
		
		Map<String, Object> resultMap = groupOrderManager.helpGroup(attendGroup.getOrderId(), attendGroup.getGroupId(), helpUserId, attendGroup.getUserId(), channel, request, ctxMap);
		Map<String, Object> map = new HashMap<>();
		map.put("result", resultMap.get("result"));
		//map.put("bondMessage",resultMap.get("bondMessage"));
		map.put("status",resultMap.get("status"));
		Object msg = resultMap.get("message");
		if(null != msg){
			response.setMsg(msg.toString());
		}
		response.setData(map);
		return response;
	}

	/**
	 * 我的助力列表信息
	 *
	 * @param pageNo
	 * @param pageSize
	 * @param scn
	 * @return
	 * @throws ServiceException
	 */
	@GetMapping(value = "/myHelpList")
	public ResponseJson getHelpList(@RequestParam(value = "pageNo", required = true) Integer pageNo,
									@RequestParam(value = "pageSize", required = true) Integer pageSize,
									@CookieValue(value = "SCN", required = false) String scn) throws ServiceException {
		ResponseJson response = new ResponseJson();
		String userId = null;
		UserInfoCache userInfoCache = groupOrderManager.checkScnByDubbo(scn);
		if (null != userInfoCache && StringUtils.isNotBlank(userInfoCache.getId())) {
			userId = userInfoCache.getId();
		} else {
			throw new ServiceException("group.operation.notLoggin");
		}
		response.setData(groupOrderManager.myHelpList(userId, pageNo, pageSize));
		return response;
	}
	
	/**
	 * 我发起的助力团列表
	 * @param pageNo
	 * @param pageSize
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping("/sponsoredHelpList")
	public ResponseJson sponsoredHelpList(
			@RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
			@RequestParam(value = "pageSize", defaultValue = "10") Integer pageSize,
			@CookieValue(value = "SCN", required = false) String scn) throws MeidianException {
		ResponseJson response = new ResponseJson();
		Long userId = null;
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		if(null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		}else {
			throw new ServiceException("group.operation.notLoggin");
		}
		
		Map<String, Object> map = new HashMap<>();
		map.put("myHelpList", groupOrderManager.sponsoredHelpList(pageNo, pageSize, userId));
		response.setData(map);
		return response;
	}
	
	/**
	 * 商品介绍处理协议
	 * @param url
	 * @return
	 */
	@RequestMapping(value = "/proDes", method = RequestMethod.GET)
	public String proDes(@NotBlank(message = "{param.error}") @RequestParam(value = "url") String url) throws MeidianException{
		
//		url = "https://desc.gome.com.cn/html/bbchtml/productDesc/descHtml201810/desc04/A0006508577_mobile.html";
		return groupOrderManager.proDes(url);
	}
	
	


	/**
	 * 组团sku详情(美店小程序与国美小程序融合使用)
	 * @param productId
	 * @param skuId
	 * @param areaCode
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/getGroupInfoBySkuId", method = RequestMethod.GET)
	public ResponseJson getGroupInfoBySku(
			@NotBlank(message = "{param.error}") @RequestParam("skuId") String skuId,
			HttpServletRequest request
			) throws MeidianException{
		ResponseJson responseJson = new ResponseJson();
		responseJson.setData(groupOrderManager.getGroupInfoBySkuId(skuId));
		return responseJson;
	}

	
	/**
	 * 测试用
	 * @param request
	 * @param return_url
	 * @param userId
	 * @return
	 * @throws MeidianException
	 */
	@MDStorePriceAnnotation
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public ResponseJson test(HttpServletRequest request, 
			String return_url,
			@NotBlank(message = "{param.error}") @RequestParam(name = "userId", required = true) String userId
			) throws MeidianException{
		ResponseJson response = new ResponseJson();
		
		JSONUtils.toJSONString(return_url);
		System.err.println(JSONUtils.toJSONString(return_url));
		String ch = MDC.get("Channel");
		int a = 1;
		if(a == 1){
			
//			throw new ServiceException("coupon.fetchCoupon.fail");
		}
		
		
		response.setData("<a>sssssssssss</a>");
		return response;
	}
}
