package com.gome.meidian.grouporder.controller.app;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.aop.MDStorePriceAnnotation;
import com.gome.meidian.grouporder.manager.app.GomeShareCardManager;
import com.gome.meidian.grouporder.manager.app.ShareCardManager;
import com.gome.meidian.grouporder.utils.AuthencationUtils;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.vo.app.AppResponseJson;
import com.gome.meidian.grouporder.vo.app.ShareCardParamVo;
import com.gome.meidian.grouporder.vo.app.ShareCardVo;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;

import cn.com.gome.gis.dto.GisResultDto;
import cn.com.gome.gis.dubbo.CommonUploadService;
import net.sf.json.JSONObject;


@Controller
@Validated
@RequestMapping("/app")
public class ShareCardController {
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private AuthencationUtils authencationUtils;
	
	@Autowired
	private ShareCardManager shareCardManager;
	
	@Value("${meidian.image.agreement}")
	private String agreement;			// http协议
	
	@Value("${gome.defaultAreaCode}")
	private String defaultAreaCode; // 默认二级区域，朝阳，全国价
	
	// GFS上传图片服务和对应token  date:2019-10-31 by zfj
	@Autowired
	private CommonUploadService commonUploadService;
	
	@Value("${gome.md_share_gfs_token}")
	private String token; // GFS上传图片token
	
	@Autowired
	private GomeShareCardManager gomeShareCardManager;


	@MDStorePriceAnnotation
    @ResponseBody
    @RequestMapping( value = "/v1/gomeBtoCshareCode", method = RequestMethod.POST )
    public AppResponseJson<Map<String,Object>> gomeBtoCshareCode(
			@CookieValue(value = "SCN", required = false) String scn, 
			@CookieValue(value = "PPI", required = false) Integer ppi, 
			@RequestParam Map<String, Object> params ,
    		HttpServletRequest request
    		) throws MeidianException{
    	AppResponseJson<Map<String,Object>> response = new AppResponseJson<Map<String,Object>>();
    	response.setIsSessionExpired("N");
    	Map<String,Object> map = new HashMap<String,Object>();
    	map.put("login", 1L);
		String userId = authencationUtils.authenticationLogin(scn);
		if(userId == null){
			map.put("login", 0L); 
			response.setData(map);
			response.setIsSessionExpired("Y");
			return response;
		}
    	Byte ua = ImageUtils.userAgentChannel(request);
    	String  body = params.get("body").toString();
    	ShareCardVo shareCardVo = new ShareCardVo ();
    	if(body != null && !body.equals("")){
            JSONObject jsonObject=JSONObject.fromObject(body);
            ShareCardParamVo shareCardParamVo=(ShareCardParamVo)JSONObject.toBean(jsonObject, ShareCardParamVo.class);
            if(StringUtils.isEmpty(shareCardParamVo.getPageType())){
            	shareCardVo.setPageType(0);
            }else{
                if(shareCardParamVo.getAreacode() == null || shareCardParamVo.getAreacode().equals("")){
            		//shareCardVo.setPageType(0);
                	shareCardParamVo.setAreacode(defaultAreaCode);
                	
                }
                    MeidianEnvironment.put("priceReqAreaCode", shareCardParamVo.getAreacode());
                	// shareCardVo = shareCardManager.getShareCard(shareCardParamVo, userId, ppi, ua);
                     shareCardVo = gomeShareCardManager.getShareCard(shareCardParamVo, userId, ppi, ua);
             		//商品图片协议处理,后缀
                    shareCardVo.setShareUrl(switchImageUrl(shareCardVo.getShareUrl(),ua)); 
                    shareCardVo.setFriendSubImageUrl(switchImageUrl(shareCardVo.getFriendSubImageUrl(),ua)); 
            }
    	}else{
    		shareCardVo.setPageType(0);
    	}
    	map.put("shareCard", shareCardVo);
    	response.setData(map);
    	return response;
    }
    
    /**
     * 美店小程序发版信息
     * @author zfj
     * @date 2019-10-31
     * @param scn
     * @param ppi
     * @param params
     * @param request
     * @return
     * @throws MeidianException
     */
	@ResponseBody
	@RequestMapping(value = "/v1/mdShareCode", method = RequestMethod.POST)
	public AppResponseJson<Map<String, Object>> mdShareCode(@CookieValue(value = "SCN", required = false) String scn,
			@CookieValue(value = "PPI", required = false) Integer ppi, @RequestParam Map<String, Object> params,
			HttpServletRequest request) throws MeidianException {
		AppResponseJson<Map<String, Object>> response = new AppResponseJson<Map<String, Object>>();
		response.setIsSessionExpired("N");
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("login", 1L);
		String userId = authencationUtils.authenticationLogin(scn);
		if (userId == null) {
			map.put("login", 0L);
			response.setData(map);
			response.setIsSessionExpired("Y");
			return response;
		}
		Byte ua = ImageUtils.userAgentChannel(request);
		String body = params.get("body").toString();
		ShareCardVo shareCardVo = new ShareCardVo();
		if (body != null && !body.equals("")) {
			JSONObject jsonObject = JSONObject.fromObject(body);
			ShareCardParamVo shareCardParamVo = (ShareCardParamVo) JSONObject.toBean(jsonObject,
					ShareCardParamVo.class);
			if (StringUtils.isEmpty(shareCardParamVo.getPageType())) {
				shareCardVo.setPageType(0);
			} else {
				if (shareCardParamVo.getAreacode() == null || shareCardParamVo.getAreacode().equals("")) {
					shareCardParamVo.setAreacode(defaultAreaCode);
				}
				shareCardVo = shareCardManager.getShareCard(shareCardParamVo, userId, ppi, ua);
				// 商品图片协议处理,后缀
				shareCardVo.setShareUrl(switchImageUrl(shareCardVo.getShareUrl(), ua));
				shareCardVo.setFriendSubImageUrl(switchImageUrl(shareCardVo.getFriendSubImageUrl(), ua));
			}
		} else {
			shareCardVo.setPageType(0);
		}
		map.put("shareCard", shareCardVo);
		// gfs对应的url
		String gfsUrl = createGfsUrl(shareCardVo.getShareCodedata());
		if (org.apache.commons.lang3.StringUtils.isNotBlank(gfsUrl)) {
			//map.put("gfsUrl", gfsUrl);
			((ShareCardVo)(map.get("shareCard"))).setShareCodedata(gfsUrl);
		}
		response.setData(map);
		return response;
	}
    
    /**
     * 构建gfs地址
     * @author zfj
     * @date 2019-10-31
     * @param shareCodedata 分项码对应的Base64
     * @return
     * @throws ServiceException 
     */
    private String createGfsUrl(String shareCodedata) throws ServiceException {
    	Base64.Decoder decoder = Base64.getDecoder();
    	byte[] codes = decoder.decode(shareCodedata);
		GisResultDto uploadImage = commonUploadService.uploadImage(codes, token);
		if ("Y".equals(uploadImage.getResult()) && "ok".equals(uploadImage.getMsg()) && org.apache.commons.lang3.StringUtils.isBlank(uploadImage.getErrorCode())) {
			return uploadImage.getUrl();
		}
		logger.error("构建gfs地址,返解析Base64  Base64.decoder error ");
		throw new ServiceException("构建gfs地址,反解析Base64");
    }
    
    /**
     * 协议转换
     * @param imageInfo
     * @return
     */
	private String switchImageUrl(String imageInfo ,Byte ua) {
		if (StringUtils.isEmpty(imageInfo)) {
			return imageInfo;
		}
        // 处理图片后缀
//        imageInfo = ImageUtils.imageUrlInfo(imageInfo, ua);
		
		if (!imageInfo.startsWith("http")) {
			imageInfo = agreement + imageInfo;
		}

		if (imageInfo.contains("http:"))
			return imageInfo.replace("http:", agreement);
		else
			return imageInfo;
	}
	
}
