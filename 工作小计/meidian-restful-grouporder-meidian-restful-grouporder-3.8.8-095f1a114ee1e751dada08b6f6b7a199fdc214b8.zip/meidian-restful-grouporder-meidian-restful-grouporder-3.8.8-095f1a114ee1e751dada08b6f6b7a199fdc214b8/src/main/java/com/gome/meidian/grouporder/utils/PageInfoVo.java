package com.gome.meidian.grouporder.utils;

public class PageInfoVo {

	private int totalPageCount = 1;// 总页数
	private int pageSize = 0; // 每页显示的记录数
	private long totalCount = 0; // 记录总数
	private int currPageNo = 1; // 当前页码
	
	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		if (pageSize > 0)
			this.pageSize = pageSize;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		if (totalCount > 0) {
			this.totalCount = totalCount;
			// 计算总页数
			this.totalPageCount = (int) (this.totalCount % pageSize == 0 ? (this.totalCount / pageSize)
					: this.totalCount / pageSize + 1);
		}
	}

	public int getTotalPageCount() {
		return totalPageCount;
	}

	public int getCurrPageNo() {
		if (totalPageCount == 0)
			return 0;
		return currPageNo;
	}

	public void setCurrPageNo(int currPageNo) {
		if (this.currPageNo > 0)
			this.currPageNo = currPageNo;
	}

}
