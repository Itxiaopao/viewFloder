package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
@Data
public class GomeHelpAddBindingVo implements Serializable {
    private static final long serialVersionUID = 8144896826771935768L;
    @NotNull(message = "{param.error}")
    private Long puserId;
    @NotNull(message = "{param.error}")
    private Long userId;
    @NotBlank(message = "{param.error}")
    private String invokeFrom;
    @NotBlank(message = "{param.error}")
    private String channel;
}
