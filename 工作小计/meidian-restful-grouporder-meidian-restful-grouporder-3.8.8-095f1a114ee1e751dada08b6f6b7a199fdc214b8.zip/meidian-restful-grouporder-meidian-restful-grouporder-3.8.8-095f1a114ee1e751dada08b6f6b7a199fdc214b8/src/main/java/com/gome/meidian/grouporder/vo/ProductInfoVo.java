package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

public class ProductInfoVo implements Serializable{

	private static final long serialVersionUID = 2586841813150860060L;
//	//商品标题
//	private String productTitle;
//	//是否自营
//	private boolean self;
//	//当前售价
//	private Double price;
//	//主图URL
//	private String imageUrl;
//	//轮播图
//	private List<String> images;
	
	private String productId;
	
	private String skuId;
	//商品详情
	private String productDesc;
	//售后服务
	private String afterSaleService;
	//包装清单
	private String packings;
	//规格参数
	private List<String[]> specifications;
	// 商品介绍
	private String proDes;
	
	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getAfterSaleService() {
		return afterSaleService;
	}

	public void setAfterSaleService(String afterSaleService) {
		this.afterSaleService = afterSaleService;
	}

	public String getPackings() {
		return packings;
	}

	public void setPackings(String packings) {
		this.packings = packings;
	}

	public List<String[]> getSpecifications() {
		return specifications;
	}

	public void setSpecifications(List<String[]> specifications) {
		this.specifications = specifications;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSkuId() {
		return skuId;
	}

	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}

	public String getProDes() {
		return proDes;
	}

	public void setProDes(String proDes) {
		this.proDes = proDes;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
