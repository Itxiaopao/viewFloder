package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

/**
 * cms返参处理
 * @author shichangjian
 *
 */
public class CmsStoreVo implements Serializable{

	private static final long serialVersionUID = 2986384569212287934L;

	private Integer create_time;
	private String name;
	private String color;
	private String type;
	private List<CmsModel> model;
	private String salt;
	private Integer update_time;
	private Integer sequence;
	private Integer operator_id;
	private Integer user_id;
	
	public Integer getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Integer create_time) {
		this.create_time = create_time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public List<CmsModel> getModel() {
		return model;
	}
	public void setModel(List<CmsModel> model) {
		this.model = model;
	}
	public String getSalt() {
		return salt;
	}
	public void setSalt(String salt) {
		this.salt = salt;
	}
	public Integer getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Integer update_time) {
		this.update_time = update_time;
	}
	public Integer getSequence() {
		return sequence;
	}
	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}
	public Integer getOperator_id() {
		return operator_id;
	}
	public void setOperator_id(Integer operator_id) {
		this.operator_id = operator_id;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	
	
}
