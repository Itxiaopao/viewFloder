package com.gome.meidian.grouporder.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.vo.register.MinUserVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.entity.UserMessage;
import com.gome.meidian.user.manager.IUserFormIdManager;

@SuppressWarnings({"rawtypes"})
@Service
public class MinMessageManager {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private IUserFormIdManager userFormIdManager;

	/**
	 * 获取店主首页数据
	 * @param taskCmsVo
	 * @return
	 * @throws MeidianException
	 */
	public ResponseJson pushUserMinFormId(MinUserVo minUserVo) throws MeidianException {
		logger.info("推送参数,userId:{},formId:{},formType:{}",minUserVo.getUserId(),minUserVo.getFormId(),minUserVo.getFormType());
		ResponseJson responseJson = new ResponseJson();
		if(!minUserVo.getFormType().equals(0)){
			if(minUserVo.getOrderId()==null){
				responseJson.setCode(95002);
				responseJson.setMsg("支付消息订单号不能为空");
				return responseJson;
			}
		}
		//参数封装
		UserMessage userMessage = new UserMessage();
		userMessage.setUserId(minUserVo.getUserId());
		userMessage.setFormId(minUserVo.getFormId());
		userMessage.setFormType(minUserVo.getFormType());
		userMessage.setOrderId(minUserVo.getOrderId());
		MapResults mapResults = userFormIdManager.pushUserMinFormId(userMessage);
		if(mapResults.getCode()!=0){
			responseJson.setCode(mapResults.getCode());
			responseJson.setMsg(mapResults.getMessage());
			return responseJson;
		}
		return ResponseJson.getSuccessResponse();
	}
	
}
