package com.gome.meidian.grouporder.vo.carveUp.myCarveUpList;

import com.gome.meidian.grouporder.vo.Coupon;

import java.util.List;

/**
 * 基础瓜分团信息
 */
public class CarveUpBaseGroupVo extends CarveUpGroupVo {

	private static final long serialVersionUID = -8862122720906239813L;

//	private List<Coupon> initCoupons;  //开团人券信息
	private Double initialFixMoney;  //开团人固定国美币奖励
//	private List<Coupon> attendCoupons;  //参团人券信息
	private Double attendFixMoney; //参团人固定国美币奖励
	private Double attendBondTotalNum; //参与者劵面值总和（元）
	private Double initialBondTotalNum; //开团者劵面值总和（元）
//	public List<Coupon> getInitCoupons() {
//		return initCoupons;
//	}
//	public void setInitCoupons(List<Coupon> initCoupons) {
//		this.initCoupons = initCoupons;
//	}
//	public List<Coupon> getAttendCoupons() {
//		return attendCoupons;
//	}
//	public void setAttendCoupons(List<Coupon> attendCoupons) {
//		this.attendCoupons = attendCoupons;
//	}

	public Double getInitialFixMoney() {
		return initialFixMoney;
	}

	public void setInitialFixMoney(Double initialFixMoney) {
		this.initialFixMoney = initialFixMoney;
	}

	public Double getAttendFixMoney() {
		return attendFixMoney;
	}

	public void setAttendFixMoney(Double attendFixMoney) {
		this.attendFixMoney = attendFixMoney;
	}

	public Double getAttendBondTotalNum() {
		return attendBondTotalNum;
	}

	public void setAttendBondTotalNum(Double attendBondTotalNum) {
		this.attendBondTotalNum = attendBondTotalNum;
	}

	public Double getInitialBondTotalNum() {
		return initialBondTotalNum;
	}

	public void setInitialBondTotalNum(Double initialBondTotalNum) {
		this.initialBondTotalNum = initialBondTotalNum;
	}
	
}
