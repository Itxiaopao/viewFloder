package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.activity;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupProduct;

/**
 * 活动信息批量
 * @author shichangjian
 *
 */
public class ActivitiesReq implements Serializable{

	private static final long serialVersionUID = 1403363016405109186L;
	
	@NotEmpty(message = "{param.error}", groups = { activity.class})
	private List<Long> activityIds;

	public List<Long> getActivityIds() {
		return activityIds;
	}

	public void setActivityIds(List<Long> activityIds) {
		this.activityIds = activityIds;
	}
	
	
}
