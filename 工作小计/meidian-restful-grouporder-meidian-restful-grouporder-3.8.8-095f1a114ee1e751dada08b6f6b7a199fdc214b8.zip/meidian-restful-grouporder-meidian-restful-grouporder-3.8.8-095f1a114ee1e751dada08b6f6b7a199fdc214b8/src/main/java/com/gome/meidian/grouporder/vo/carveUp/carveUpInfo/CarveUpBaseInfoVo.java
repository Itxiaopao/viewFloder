package com.gome.meidian.grouporder.vo.carveUp.carveUpInfo;

import java.util.List;

import com.gome.meidian.grouporder.vo.Coupon;

/**
 * 基础瓜分团详情信息
 */
public class CarveUpBaseInfoVo extends CarveUpInfoVo {

	private static final long serialVersionUID = -7689544911520628288L;

	private List<Coupon> initCoupon;  //开团人券信息
	private Double initialFixMoney;  //开团人固定国美币奖励
	private List<Coupon> attendCoupon;  //参团人券信息
	private Double attendFixMoney; //参团人固定国美币奖励
	private Double attendBondTotalNum; //参与者劵面值总和（元）
	private Double initialBondTotalNum; //开团者劵面值总和（元）
	public List<Coupon> getInitCoupon() {
		return initCoupon;
	}
	public void setInitCoupon(List<Coupon> initCoupon) {
		this.initCoupon = initCoupon;
	}
	public List<Coupon> getAttendCoupon() {
		return attendCoupon;
	}
	public void setAttendCoupon(List<Coupon> attendCoupon) {
		this.attendCoupon = attendCoupon;
	}

	public Double getInitialFixMoney() {
		return initialFixMoney;
	}

	public void setInitialFixMoney(Double initialFixMoney) {
		this.initialFixMoney = initialFixMoney;
	}

	public Double getAttendFixMoney() {
		return attendFixMoney;
	}

	public void setAttendFixMoney(Double attendFixMoney) {
		this.attendFixMoney = attendFixMoney;
	}
	public Double getAttendBondTotalNum() {
		return attendBondTotalNum;
	}
	public void setAttendBondTotalNum(Double attendBondTotalNum) {
		this.attendBondTotalNum = attendBondTotalNum;
	}
	public Double getInitialBondTotalNum() {
		return initialBondTotalNum;
	}
	public void setInitialBondTotalNum(Double initialBondTotalNum) {
		this.initialBondTotalNum = initialBondTotalNum;
	}
	
}
