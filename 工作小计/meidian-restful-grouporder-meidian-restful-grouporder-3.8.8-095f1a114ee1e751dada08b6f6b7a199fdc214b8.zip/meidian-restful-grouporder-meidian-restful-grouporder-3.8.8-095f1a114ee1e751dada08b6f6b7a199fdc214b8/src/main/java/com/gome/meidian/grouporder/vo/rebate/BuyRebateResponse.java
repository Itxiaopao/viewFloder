package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;

/**
 * 购买返返参
 * @author shichangjian
 *
 */
public class BuyRebateResponse implements Serializable{

	private static final long serialVersionUID = -1536969925905270546L;

	private String prouductId;
	private String buyRebate;
	
	public String getProuductId() {
		return prouductId;
	}
	public void setProuductId(String prouductId) {
		this.prouductId = prouductId;
	}
	public String getBuyRebate() {
		return buyRebate;
	}
	public void setBuyRebate(String buyRebate) {
		this.buyRebate = buyRebate;
	}
	
	
}
