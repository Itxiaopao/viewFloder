package com.gome.meidian.grouporder.controller.mshopUser;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.UserBasicInfoManager;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.vo.UserInfoDto;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.user.dto.MapResults;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.sso.facade.IUserSsoFacade;
import com.gome.sso.model.UserInfoCache;

@RestController
@RequestMapping("/mshopUser/login")
public class UserLoginAuthController{
	private static Logger logger = LoggerFactory.getLogger(UserLoginAuthController.class);
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private UserBasicInfoManager userBasicInfoManager;
	
	/**
	 * 根据SCN获取用户基本信息
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@PostMapping("/getUserBasicInfo")
	public ResponseJson getUserBasicInfo(
			@CookieValue(value = "SCN", required = false) String scn) throws MeidianException{
		ResponseJson response = new ResponseJson();
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		// 如果用户已登录，将获取用户的团状态
		Long userId = null;
		if (null != userInfo && StringUtils.isNotBlank(userInfo.getId())) {
			userId = Long.parseLong(userInfo.getId());
		}else{
			throw new ServiceException("group.operation.notLoggin");
		}
		
		UserInfoDto dto = userBasicInfoManager.getUserBasicInfo(userId.toString());
		response.setData(dto);
		return response;
	}
}
