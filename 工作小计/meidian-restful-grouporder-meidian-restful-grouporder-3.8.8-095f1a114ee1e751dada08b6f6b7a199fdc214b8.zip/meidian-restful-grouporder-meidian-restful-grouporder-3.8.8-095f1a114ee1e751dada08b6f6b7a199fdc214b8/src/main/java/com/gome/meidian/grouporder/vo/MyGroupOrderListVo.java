package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

public class MyGroupOrderListVo implements Serializable {

	private static final long serialVersionUID = -3763525154486048732L;
	
	private List<MyGroupOrderInfoVo> groupOrderList;

	public List<MyGroupOrderInfoVo> getGroupOrderList() {
		return groupOrderList;
	}

	public void setGroupOrderList(List<MyGroupOrderInfoVo> groupOrderList) {
		this.groupOrderList = groupOrderList;
	}
	
}
