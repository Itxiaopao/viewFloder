package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;
import java.util.List;

import com.gome.meidian.grouporder.vo.product.ProductInfo;
import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;

/**
 * 万人团列表
 * @author shichangjian
 *
 */
public class ThousandGroup implements Serializable{

	private static final long serialVersionUID = -6949263166012360349L;

	private Long groupId;										// 团id
	private Integer currentMemberNum; 							// 团成员人数
	private Long startCountdown;								// 距活动开始时间
	private Long endCountdown;									// 距活动结束时间
	private List<GroupUserInfo> groupUser;						// 用户信息
	private CollectionProductInfoVo collectionProductInfoVo;	// 分享，点赞
	private WanrenProductVo wanrenProductVo;					// 商品，品牌
	
	public Long getStartCountdown() {
		return startCountdown;
	}
	public void setStartCountdown(Long startCountdown) {
		this.startCountdown = startCountdown;
	}
	public Long getEndCountdown() {
		return endCountdown;
	}
	public void setEndCountdown(Long endCountdown) {
		this.endCountdown = endCountdown;
	}
	public CollectionProductInfoVo getCollectionProductInfoVo() {
		return collectionProductInfoVo;
	}
	public void setCollectionProductInfoVo(CollectionProductInfoVo collectionProductInfoVo) {
		this.collectionProductInfoVo = collectionProductInfoVo;
	}
	public WanrenProductVo getWanrenProductVo() {
		return wanrenProductVo;
	}
	public void setWanrenProductVo(WanrenProductVo wanrenProductVo) {
		this.wanrenProductVo = wanrenProductVo;
	}
	public List<GroupUserInfo> getGroupUser() {
		return groupUser;
	}
	public void setGroupUser(List<GroupUserInfo> groupUser) {
		this.groupUser = groupUser;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Integer getCurrentMemberNum() {
		return currentMemberNum;
	}
	public void setCurrentMemberNum(Integer currentMemberNum) {
		this.currentMemberNum = currentMemberNum;
	}
	
	
	
}
