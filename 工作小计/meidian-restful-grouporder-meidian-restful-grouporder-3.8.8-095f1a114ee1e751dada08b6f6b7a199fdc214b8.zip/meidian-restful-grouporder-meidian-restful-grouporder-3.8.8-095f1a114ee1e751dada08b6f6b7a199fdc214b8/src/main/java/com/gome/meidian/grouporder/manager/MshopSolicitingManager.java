package com.gome.meidian.grouporder.manager;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.UserConstants;
import com.gome.meidian.grouporder.vo.mshopUserVo.MshopSolicitVo;
import com.gome.meidian.grouporder.vo.register.TaskMatchPageVo;
import com.gome.meidian.grouporder.vo.register.TaskMatchVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.user.dto.MShopShareBindingDto;
import com.gome.meidian.user.dto.MapResults;
import com.gome.meidian.user.dto.MshopShareRecordDto;
import com.gome.meidian.user.dto.MshopSolicitingVo;
import com.gome.meidian.user.manager.IMShopOwnerInfoManager;
import com.gome.meidian.user.manager.IUserShareBindingManager;
import com.gome.sso.model.UserInfoCache;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;
import com.gomeplus.bs.interfaces.mshop.task.entity.MshopRaceOrderData;
import com.gomeplus.bs.interfaces.mshop.task.entity.ResponseApiDto;
import com.gomeplus.bs.interfaces.mshop.task.service.MshopRaceOrderDataService;
import com.gomeplus.bs.interfaces.mshop.task.service.MshopTaskInfoResource;
import com.gomeplus.bs.interfaces.mshop.task.service.TaskJoinResource;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskInfoVo;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskJoinVo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import redis.Gcache;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.*;

@SuppressWarnings({"rawtypes","unchecked"})
@Service
public class MshopSolicitingManager {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private GroupOrderManager groupOrderManager;

    @Autowired
    private IMShopOwnerInfoManager iMShopOwnerInfoManager;

    @Autowired
    private IUserShareBindingManager iUserShareBindingManager;

    //scn获取用户信息
    public long getUserToScn(String scn) throws MeidianException {
        //获取登录人信息
        UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
        if(userInfo==null || userInfo.getId()==null || userInfo.getId().equals("")) {
            throw new ServiceException("group.operation.notLoggin");
        }
        return Long.parseLong(userInfo.getId());
    }

    //获取当前人/顾问/导师/邀请人 信息
    public MshopSolicitVo getUserRefInfo(Long userId,Long invitationId) throws MeidianException {
        MshopSolicitVo mshopSolicitVo = new MshopSolicitVo();
        long start = System.currentTimeMillis();
        try {
            MapResults<MshopSolicitingVo> mshopSolicitingVoMapResults = iMShopOwnerInfoManager.queryMshopSolicitingInfo(userId, invitationId);
            if(null != mshopSolicitingVoMapResults && null != mshopSolicitingVoMapResults.getBuessObj()){
                BeanUtils.copyProperties(mshopSolicitingVoMapResults.getBuessObj(),mshopSolicitVo);
            }
        } catch (Exception e) {
            logger.error("getUserRefInfo error!userId="+userId+"invitationId="+invitationId,e);
        }
        return mshopSolicitVo;
    }

    //存储当前人信息
    public Boolean addUserInfo(MShopShareBindingDto mShopShareBindingDto) throws MeidianException {
        try {
            MapResults mapResults = iUserShareBindingManager.uploadQrCode(mShopShareBindingDto);
            if(null != mapResults && null != mapResults.getSuccess()){
                return mapResults.getSuccess();
            }
            return false;
        } catch (Exception e) {
            logger.error("dubbo-addUserInfo error!"+JSONObject.toJSONString(mShopShareBindingDto));
        }
        return false;
    }

    //切换邀请人
    public MapResults switchUser(MshopShareRecordDto mshopShareRecordDto) throws MeidianException {
        MapResults mapResults = new MapResults();
        try {
            mapResults = iUserShareBindingManager.changeMLeader(mshopShareRecordDto);
            if(null != mapResults && null != mapResults.getSuccess()){
                return mapResults;
            }
        } catch (Exception e) {
            logger.error("dubbo-switchUser error!"+JSONObject.toJSONString(mshopShareRecordDto));
        }
        return mapResults;
    }
}
