package com.gome.meidian.grouporder.common;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.loom.facade.ISendSmsFacade;
import com.gome.loom.facade.IVcodeFacade;
import com.gome.loom.model.SmsModel;
import com.gome.loom.model.TpModel;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.memberCore.lang.model.Result;
import com.gome.userCenter.facade.register.IUserRegisterFacade;
import com.gome.userCenter.model.GomeUnifyRegisterUser;
import com.gome.userCenter.model.UserRegisterResult;

/**
 * 会员相关
 */
@Service
public class MeidianMemberService {

    private Logger logger = LoggerFactory.getLogger(getClass());


    @Autowired
	private IUserRegisterFacade userRegisterFacade;
	@Autowired
	private ISendSmsFacade sendSmsFacade;
	@Autowired
	private IVcodeFacade vcodeFacade;

	//美店wap-完善手机号
	public static String GOMESHOP_COMPLETA_PHONE_BUSINESSNAME="gomeShop_complete_phone";
	public static String GOMESHOP_COMPLETA_PHONE_BUSINESSNAME_ID="1087";
	//美店wap-绑定账号
	public static String GOMESHOP_BIND_PHONE_BUSINESSNAME="gomeShop_bind_phone";
	public static String GOMESHOP_BIND_PHONE_BUSINESSNAME_ID="1088";
	//美店wap-注册账号
	public static String GOMESHOP_REG_PHONE_BUSINESSNAME="gomeShop_reg_phone";
	public static String GOMESHOP_REG_PHONE_BUSINESSNAME_ID="1089";
	//美店wap-手机号登录
	public static String GOMESHOP_QUICK_PHONE_BUSINESSNAME="gomeShop_quick_login";
	public static String GOMESHOP_QUICK_PHONE_BUSINESSNAME_ID="1091";


	//校验手机是否存在
	public boolean existUser(String mobile) throws MeidianException {
		return userRegisterFacade.existUser(mobile);
	}

    /**
     * @param tpModel
     * @return
     * @throws MeidianException TpModel的参数对应申请的BusinessName,模板Id
     *                          TpModel smsModel = new TpModel("businessName","111");
     *                          smsModel.setPhone("1810XXXXX"); //发送的手机号
     *                          smsModel.setIntervalTime(1); //是否延迟发送如果延迟发送需要设置,单位:小时. 实时发送丌需要设置，默认0）
     *                          smsModel.putTempParams("code", "234567");//模板要替换的参数,对接短信模板里的#code# （有多个参数，调用此方法多次，注意：这里的参数对应模板里的#code#, 其他参数类似，都是带#号，比如参数abc对应模板里#abc#）
     *                          dubbo调用发送短信(result一定会返回，丌用做null判断)
     */
    public boolean sendSms(TpModel tpModel) throws MeidianException {
        Result<SmsModel> result = sendSmsFacade.sendSms(tpModel);
        if (result.isSuccess()) {
            return true;
        } else {
            logger.error("MeidianMemberService-sendSms-result:{}",result);
            return false;
        }
    }


    /**
     * 校验手机验证码
     *
     * @param businessName 短信平台申请的businessName
     * @param mobile       需要验证的手机号
     * @param smsCode      验证码
     * @param flag         校验完是否清掉验证码，分为比较和验证；比较：比较多次丌删除验证码信息；验证：只能校验一次，丌论成功，失败都会删除验证码
     * @return
     * @throws MeidianException
     */
    public boolean checkVcode(String businessName, String mobile, String smsCode, boolean flag) throws MeidianException {
        Result<Boolean> result = vcodeFacade.checkVcode(businessName, mobile, smsCode, flag);
        if (result.isSuccess()) {
            return true;
        } else {
            logger.error("MeidianMemberService-checkVcode-result:{}",result);
            return false;
        }
    }

    /**
     * 注册接口
     * @param gomeUser
     * @param extMap
     * @return
     * @throws MeidianException
     */
    public UserRegisterResult<GomeUnifyRegisterUser> registerUnifyUser(GomeUnifyRegisterUser gomeUser, Map<String, Object> extMap) throws MeidianException {
        return userRegisterFacade.registerUnifyUser(gomeUser, extMap);
    }

}
