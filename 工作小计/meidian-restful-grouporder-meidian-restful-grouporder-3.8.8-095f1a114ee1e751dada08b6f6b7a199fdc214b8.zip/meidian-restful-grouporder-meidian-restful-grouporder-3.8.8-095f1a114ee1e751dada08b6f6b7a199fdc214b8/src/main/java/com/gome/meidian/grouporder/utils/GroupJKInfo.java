//package com.gome.meidian.grouporder.utils;
//
//
//import java.util.Date;
//
//import lombok.Getter;
//import lombok.Setter;
//import lombok.ToString;
//
///**
// * 集客表
// * @author sunhaitao-ds
// *
// */
//@Getter
//@Setter
//@ToString
//public class GroupJKInfo {
//
//	private Long id; //id
//	private String jkId; //集客id
//	private String pagecode; //pagecode
//	private Long jkUserId; //集客发起者userid
//	private String jkUserName; //集客发起者名字
//	private Long guestUserId; //被集者的userid
//	private String guestPhone; //被集客的手机号
//	private String guestUserName; //被集客姓名
//	private Integer guestAttendNum; //被集者参与百人团的次数
//	private Date createTime; //创建时间
//	private Date updateTime; //更新时间
//	private Integer isDelete; //删除标识,0:未删除,1:已删除
//
//
//}
