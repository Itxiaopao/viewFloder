package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
/**
 * 商品详情页-店铺信息
 * @author lishouxu-ds
 *
 */
public class ShopInfoVo implements Serializable{
	private static final long serialVersionUID = 2738178222295097071L;
	private String shopId;//店铺编码
	private String shopLogoUrl;//店铺logo地址
	private String shopName;//店铺名称
	private Double avgScore;//评分=(商品描述评分+商家服务态度+商家发货速度)/3  [保留一位小数,四舍五入]
	private Double goodsMatch;//商品描述评分
	private Double serviceScore;//商家服务态度
	private Double deliverySpeed;//商家发货速度
	private Double starNumber;//显示的星级
	private String shopHotLine;//店铺热线
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public String getShopLogoUrl() {
		return shopLogoUrl;
	}
	public void setShopLogoUrl(String shopLogoUrl) {
		this.shopLogoUrl = shopLogoUrl;
	}
	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public Double getAvgScore() {
		return avgScore;
	}
	public void setAvgScore(Double avgScore) {
		this.avgScore = avgScore;
	}
	public Double getGoodsMatch() {
		return goodsMatch;
	}
	public void setGoodsMatch(Double goodsMatch) {
		this.goodsMatch = goodsMatch;
	}
	public Double getServiceScore() {
		return serviceScore;
	}
	public void setServiceScore(Double serviceScore) {
		this.serviceScore = serviceScore;
	}
	public Double getDeliverySpeed() {
		return deliverySpeed;
	}
	public void setDeliverySpeed(Double deliverySpeed) {
		this.deliverySpeed = deliverySpeed;
	}
	public Double getStarNumber() {
		return starNumber;
	}
	public void setStarNumber(Double starNumber) {
		this.starNumber = starNumber;
	}
	public String getShopHotLine() {
		return shopHotLine;
	}
	public void setShopHotLine(String shopHotLine) {
		this.shopHotLine = shopHotLine;
	}
	
	
	

}
