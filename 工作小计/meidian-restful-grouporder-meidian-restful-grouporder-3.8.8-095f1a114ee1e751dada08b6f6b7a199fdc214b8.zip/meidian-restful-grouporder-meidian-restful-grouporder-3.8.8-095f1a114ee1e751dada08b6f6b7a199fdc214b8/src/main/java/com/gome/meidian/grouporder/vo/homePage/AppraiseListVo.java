package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;
import java.util.List;

public class AppraiseListVo implements Serializable{
	
	private static final long serialVersionUID = -4205774521219252504L;
	private Integer totalPageNum;
	private Integer totalNum;
	private Integer currentPageNo;
	private Integer pageSize;
	private List<AppraiseVo> appraises;
	public Integer getTotalPageNum() {
		return totalPageNum;
	}
	public void setTotalPageNum(Integer totalPageNum) {
		this.totalPageNum = totalPageNum;
	}
	public Integer getTotalNum() {
		return totalNum;
	}
	public void setTotalNum(Integer totalNum) {
		this.totalNum = totalNum;
	}
	public Integer getCurrentPageNo() {
		return currentPageNo;
	}
	public void setCurrentPageNo(Integer currentPageNo) {
		this.currentPageNo = currentPageNo;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public List<AppraiseVo> getAppraises() {
		return appraises;
	}
	public void setAppraises(List<AppraiseVo> appraises) {
		this.appraises = appraises;
	}
	
}
