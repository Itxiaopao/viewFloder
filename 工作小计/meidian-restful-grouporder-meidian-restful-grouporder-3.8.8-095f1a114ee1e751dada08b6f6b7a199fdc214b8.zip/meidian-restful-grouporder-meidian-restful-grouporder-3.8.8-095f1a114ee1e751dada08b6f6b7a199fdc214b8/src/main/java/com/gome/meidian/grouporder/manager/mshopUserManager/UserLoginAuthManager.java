package com.gome.meidian.grouporder.manager.mshopUserManager;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PostMapping;

import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.sso.facade.IUserSsoFacade;

@Component
public class UserLoginAuthManager{
	private static Logger logger = LoggerFactory.getLogger(UserLoginAuthManager.class);
	@Autowired
	private IUserSsoFacade iUserSsoFacade;
	
	/**
	 * 延长SCN过期时间
	 * @param scn
	 * @param seconds
	 * @return status -1：失败  0：成功  1：异常  2：参数为空
	 */
	@SuppressWarnings("rawtypes")
	public Integer extendLoginAuth(String scn, int seconds) {
		Integer status= null;
		if(StringUtils.isBlank(scn)) {
			status = 2;
		}
		try {

			if(seconds <= 0) {
				seconds = GroupOrderConstants.GOME_SHOP_WECHAT_SCN_TIMEOUT;
			}
			
			UserResult results = iUserSsoFacade.extendLoginAuthWithMap(scn, GroupOrderConstants.GOME_SHOP_WECHAT_SCN_TIMEOUT, GroupOrderConstants.GOME_SHOP_INVOKE_FROM, null);
			if(null != results && results.isSuccess()) {
				// && results.getCode() == 204
				status = 0;
			}else{
				status = -1;
			}
		}catch(Exception e) {
			logger.error("延长SCN异常，SCN信息：{}, 异常信息：{}", scn, e.getMessage());
			status = 1;
		}
		return status;
	}
}
