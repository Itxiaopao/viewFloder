package com.gome.meidian.grouporder.controller.mshopUser;

import java.util.Map;

import javax.annotation.Resource;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.grouporder.manager.mshopUserManager.GuestManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

import redis.Gcache;

/**
 * 
 * @author libinbin-ds
 *
 */
@RestController
@Validated
@RequestMapping("/awary")
public class PrizeController {

	@Autowired
	private GuestManager guestManager;
	@Resource(name = "gcache")
    private Gcache gcache;
	/**
	 * 开始页面
	 * 
	 * @param scn
	 * @param startDate
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/myAwardInit")
	public Object myAwardInit(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("state") int state,
			@NotNull(message = "{param.error}") @RequestParam("startDate") int startDate) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		String key = "PrizeController:" + "myAwardInit:" + currentUser + "-" +state + "-" + startDate;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.myAwardInit(currentUser, state, startDate);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	


	/**
	 * 返利预算 -> 我的累计提奖金额
	 * 
	 * @param scn
	 *            当前用户
	 * @param state
	 *            提奖奖金状态 900.有效,901失效
	 * @param startDate
	 *            开始时间 201806
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/myAwardTotalMoney")
	public Object myAwardTotalMoney(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("state") int state,
			@NotNull(message = "{param.error}") @RequestParam("startDate") int startDate) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		
		String key = "PrizeController:" + "myAwardTotalMoney:" + currentUser + "-" +state + "-" + startDate;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.myAwardTotalMoney(currentUser, state, startDate);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	
	/**
	 * 返利预算 -> 我的提奖金额信息
	 * 
	 * @param scn
	 * @param state
	 * @param startDate
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@GetMapping(value = "/myAward")
	public Object myAward(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("state") int state,
			@NotNull(message = "{param.error}") @RequestParam("startDate") int startDate) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		
		String key = "PrizeController:" + "myAward:" + currentUser + "-" +state + "-" + startDate;
		String resultJson = gcache.get(key);
		if(StringUtils.isNotBlank(resultJson)) {
			responseJson = JSONObject.parseObject(resultJson, ResponseJson.class);
		}else {
			responseJson = guestManager.myAward(currentUser, state, startDate);
			resultJson = JSONObject.toJSONString(responseJson);
			gcache.set(key, resultJson);
			gcache.expire(key, 10);
		}
		return responseJson;
	}
	
	/**
	 * 返利 -> 当前用户user下获取美店主集提奖金额集合 分页
	 * 
	 * @param scn
	 * @param state
	 * @param startDate
	 * @param pageNo
	 * @return
	 */
	@GetMapping(value = "/myMasAward")
	public Object myMasAward(@CookieValue(value = "SCN", required = false) String scn,
			@NotNull(message = "{param.error}") @RequestParam("state") int state,
			@NotNull(message = "{param.error}") @RequestParam("startDate") int startDate,
			@NotNull(message = "{param.error}") @RequestParam("pageNo") int pageNo) {
		ResponseJson<Map<String, Object>> responseJson = new ResponseJson<>();
		String currentUser = guestManager.getUserIdByScn(scn);
		responseJson = guestManager.myMasAward(currentUser, state, startDate, pageNo);
		return responseJson;
	}


}
