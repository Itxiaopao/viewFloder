package com.gome.meidian.grouporder.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.rocketmq.client.exception.MQBrokerException;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.remoting.exception.RemotingException;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.RegisterManager;
import com.gome.meidian.grouporder.vo.register.BaseUserVo;
import com.gome.meidian.grouporder.vo.register.ShopSmsCodeVo;
import com.gome.meidian.grouporder.vo.register.SlideInfoVo;
import com.gome.meidian.grouporder.vo.register.UserInfoVo;
import com.gome.meidian.grouporder.vo.register.UserRegistVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@Validated
@RequestMapping("/register")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class RegisterController {
	
	@Autowired
	private RegisterManager registerManager;
	
	/**
	 * 检查手机号是否存在
	 * @param userInfoVo
	 * @return
	 */
	@PostMapping(value = "/checkMobile")
	public ResponseJson checkMobile(@Valid @RequestBody UserInfoVo userInfoVo) throws MeidianException {
		//检验手机号是否存在
		registerManager.checkMobile(userInfoVo);
		return ResponseJson.getSuccessResponse();
	}
	
	/**
	 * 发送短信验证码+短信风控
	 * @param userInfoVo
	 * @return
	 */
	@PostMapping(value = "/sendSmsCode")
	public ResponseJson sendSmsCode(@Valid @RequestBody UserInfoVo userInfoVo,HttpServletRequest request) throws MeidianException {
		//发送短信验证码+短信风控
		registerManager.sendSmsCode(userInfoVo,request);
		return ResponseJson.getSuccessResponse();
	}
	
	/**
	 * 校验滑块
	 * @param userInfoVo
	 * @return
	 */
	@PostMapping(value = "/checkSlide")
	public ResponseJson checkSlide(@Valid @RequestBody SlideInfoVo slideInfoVo) throws MeidianException {
		//校验滑块
		return registerManager.checkSlide(slideInfoVo);
	}
	
	/**
	 * 注册风控+短信验证码校验+注册接口+登录返scn+异步同步信息
	 * @param userInfoVo
	 * @return
	 */
	@PostMapping(value = "/registerUser")
	public ResponseJson registerUser(@Valid @RequestBody UserRegistVo userRegistVo,HttpServletRequest request,HttpServletResponse response) throws MeidianException, MQClientException, RemotingException, MQBrokerException, InterruptedException {
		ResponseJson responseJson = new ResponseJson();
		//注册风控+短信验证码校验+注册接口+登录返scn+异步同步信息
		Map<String,Object> map = registerManager.registerUser(userRegistVo,request,response);
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 获取用户头像昵称
	 * @param baseUserVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/queryUserInfo")
	public ResponseJson queryUserInfo(@Valid @RequestBody BaseUserVo baseUserVo) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		//获取用户头像昵称
		Map<String, Object> map = registerManager.queryUserInfo(baseUserVo);
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 发送短信验证码(非风控)
	 * @param userInfoVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/sendSmsCodeShop")
	public ResponseJson sendSmsCodeShop(@Valid @RequestBody UserInfoVo userInfoVo) throws MeidianException {
		//发送短信验证码
		registerManager.sendSmsCodeShop(userInfoVo);
		return ResponseJson.getSuccessResponse();
	}
	
	/**
	 * 校验短信验证码
	 * @param shopSmsCodeVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/checkSmsCodeShop")
	public ResponseJson checkSmsCodeShop(@Valid @RequestBody ShopSmsCodeVo shopSmsCodeVo) throws MeidianException {
		//验证短信验证码
		registerManager.checkSmsCodeShop(shopSmsCodeVo);
		return ResponseJson.getSuccessResponse();
	}
	
}
