package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

public class FirstClassInfoVo implements Serializable {

	private static final long serialVersionUID = 3366634642962651757L;
	private String firstClassificationId;//商品一级分类ID
	private String name; //一级分类名称
	private String alias; //别名
	private Integer sortNum; //排序值
	
	public FirstClassInfoVo() {
		super();
	}
	public FirstClassInfoVo(String firstClassificationId, String name, String alias, Integer sortNum) {
		super();
		this.firstClassificationId = firstClassificationId;
		this.name = name;
		this.alias = alias;
		this.sortNum = sortNum;
	}
	public String getFirstClassificationId() {
		return firstClassificationId;
	}
	public void setFirstClassificationId(String firstClassificationId) {
		this.firstClassificationId = firstClassificationId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public Integer getSortNum() {
		return sortNum;
	}
	public void setSortNum(Integer sortNum) {
		this.sortNum = sortNum;
	}
	
	
}
