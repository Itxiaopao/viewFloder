package com.gome.meidian.grouporder.manager.app;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.collectFlow.CollectFlowManager;
import com.gome.meidian.grouporder.utils.AppShareCodeConstants;
import com.gome.meidian.grouporder.utils.AppShareCodeInfo;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.MD5Util;
import com.gome.meidian.grouporder.utils.QRCodeUtil;
import com.gome.meidian.grouporder.vo.app.ShareCardParamVo;
import com.gome.meidian.grouporder.vo.app.ShareCardVo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupActivityInfo;
import com.gome.meidian.grouporder.vo.grouporderVo.GroupActivityTimeInfo;
import com.gome.sum.client.ShortUrlDubboService;
import com.gome.sum.client.dto.BindShortUrlData;
import com.gome.sum.client.dto.BindShortUrlParam;
import com.gome.sum.client.dto.BindShortUrlResult;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.cms2.service.business.PageInfoResource;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.GorderActivityInfoConciseVo;

import redis.Gcache;
/**
 * add by lsx
 */
@Service
public class MinProgramManager {
	private Logger logger = LoggerFactory.getLogger(getClass());
	@Value("${meidian.MinProgram.wxacodeUrl}")
	private String wxacodeUrl;
	@Autowired
	private HttpClientUtil httpClientUtil;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Autowired
	private MinTokenManager minTokenManager;
	
	@Autowired
	private CollectFlowManager collectFlowManager;
	
	@Autowired
	private ShortUrlDubboService shortUrlDubboService;
	
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	
	
	@Resource(name = "gomeOnlineGcache")
	private Gcache gomeOnlineGcache;

	
	/**
	 * 获取分享码
	 * @param pageCode
	 * @param params
	 * @return
	 * @throws ServiceException 
	 */
	public byte[] getShareCode(String pageCode,String params) throws ServiceException{
		
		//给测试用的key
		String testKey =  pageCode+"_"+params;
		
		String newParams = null;
		if(params !=null && !params.equals("")){
			// base64解码,java 8
			Base64.Decoder decoder = Base64.getDecoder();
			try {
				newParams = new String(decoder.decode(params), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				logger.error("getShareCode decoder error");
				return null;
			}
		}
		byte[] data = null;
		//取生成分享码的类型
		String shareCodeType = gcache.get("sharePage"+pageCode);
		if( shareCodeType == null || shareCodeType.equals("")){
			shareCodeType = GroupOrderConstants.CHANNEL_WAP;
			//shareCodeType = GroupOrderConstants.CHANNEL_MINI;
		}
		
		AppShareCodeInfo appShareCodeInfo = AppShareCodeConstants.pageUrlMap.get("sharePage"+pageCode);
		//取不到配置信息
		if(appShareCodeInfo == null){
			pageCode = "1";//首页
			appShareCodeInfo = AppShareCodeConstants.pageUrlMap.get("sharePage"+pageCode);
		}
		String wapPageUrl = appShareCodeInfo.getWapUrl();
		String minPageUrl = appShareCodeInfo.getMinUrl();

		//1、判断生成的分享码类型  //2、获取url//3、拼接参数 //4、生成分享码
		if(shareCodeType.equals(GroupOrderConstants.CHANNEL_WAP)){
			SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat s1=new SimpleDateFormat("yyyyMMdd");
			//取时间戳
			Calendar c = Calendar.getInstance();
			String str1=s1.format(c.getTime());
			//计算失效时间
			c.add(Calendar.DATE, 60);//计算60天后的时间 生产
			//c.add(Calendar.MINUTE, 5);//计算五分钟后的时间
			String str2=s.format(c.getTime());
			//System.out.println("60天后的时间是："+str2);
			
			StringBuilder sb = new StringBuilder("");
			sb.append(wapPageUrl).append("?").append("ex=").append(str1);
			//拼接分享参数
			Map<String,String> paramMap = getUseparam(newParams,appShareCodeInfo.getWapParams());
			newParams = paramMap.get("useParam");
			String mid = paramMap.get("mid");
			if(newParams !=null && !newParams.equals("")){
				sb.append("&").append(newParams);
			}
			sb.append("&").append("mid="+mid);

			String longUrl = sb.toString();
			String shortUrl = getShortUrl(longUrl,str2);
			data = getWapCode(shortUrl,null);
		}else if(shareCodeType.equals(GroupOrderConstants.CHANNEL_MINI)){
			//拼接分享参数
			Map<String,String> paramMap = getUseparam(newParams,appShareCodeInfo.getMinParams());
			newParams=paramMap.get("useParam");
			String mid = paramMap.get("mid");
			String key = "";
			if(!StringUtils.isEmpty(newParams)){
				key = MD5Util.getMD5(newParams, false, 16);
				//gcache.setex("minShareCodeKey_"+key, 60 * 24 * 3600, newParams);//生产
				gcache.setex("minShareCodeKey_"+key, 60 * 24 * 3600, newParams);//测试
				gcache.setex("zhubingtestKey_"+testKey, 25 * 3600, "param="+key+"_"+mid);//给测试
				//gcache.setex("minShareCodeKey_"+key, 5 * 60, newParams);
			}
			data = getMinProgramCode("param="+key+"_"+mid,minPageUrl,minTokenManager.getToken());	
			
			
		}
		return data;
	}
	

	
	
	
	
    /**
     * 生成美店小程序分享码
     * @param sceneStr
     * @param pageUrl
     * @param accessToken
     * @return
     * @throws ServiceException
     */
	public byte[] getMinProgramCode(String sceneStr,String pageUrl, String accessToken) throws ServiceException{
		if(accessToken == null){
			return null;
		}
		String url = wxacodeUrl+"?access_token=" + accessToken;
		com.alibaba.fastjson.JSONObject paramJson = new com.alibaba.fastjson.JSONObject();
		paramJson.put("scene", sceneStr);
		//paramJson.put("page", "pages/index/index");//pageUrl
		paramJson.put("page", pageUrl);//pageUrl
		paramJson.put("width", 200);
		paramJson.put("auto_color", true);
		byte[] inputStream =null;
		inputStream = httpClientUtil.doPostStream(url, paramJson);
//		saveToImgByInputStream(inputStream, "D:", "1.png");
		return inputStream;
	}
	/**
	 * 生成美店wap分享码
	 * @param text 短域名
	 * @param logoImgPath
	 * @return
	 */
	public byte[] getWapCode(String text,String logoImgPath){
		BufferedImage image = null;
		byte[] data = null;
		try {
			image = QRCodeUtil.createImage(text, logoImgPath, true);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			boolean flag = ImageIO.write(image, "gif", out);
			if(!flag){
				return null;
			}
			data = out.toByteArray();
		} catch (Exception e) {
			logger.error("getWapCode ==> text=={}", text);
			e.printStackTrace();
		}
        return data;
	}
	
	/**
	 * 生成短链接
	 * @param longUrl
	 * @param expireDate
	 * @return
	 */
	public String getShortUrl(String longUrl, String expireDate) {
		String shortUrl = null;
		// 1:需要二维码，2：不需要二维码
		BindShortUrlData bindShortUrlData = urlSwitch(longUrl, DateUtils.strDate(expireDate), null);
		if (null != bindShortUrlData) {
			shortUrl = bindShortUrlData.getShortUrl();
		}
		return shortUrl;
	}
	/**
	 * 生成短链接
	 * @param longUrl
	 * @param expireDate
	 * @param codeFlag
	 * @return
	 */
	public BindShortUrlData urlSwitch(String longUrl, Date expireDate, String codeFlag){
		BindShortUrlParam shortUrlParam = new BindShortUrlParam();
		shortUrlParam.setLongUrl(longUrl);
		shortUrlParam.setExpireDate(expireDate);
		shortUrlParam.setQrCodeFlag(codeFlag);
		BindShortUrlResult<BindShortUrlData> result = shortUrlDubboService.bindShortUrl(shortUrlParam);
		if(null == result) return null;
		if(!result.getSuccess()){
			logger.error("urlSwitch ==> errorMsg=={}", result.getErrMsg());
			return null;
		}
		
		return result.getData();
	}
	
	
	/**
	 * 本地生成小程序码
	 * @param instreams
	 * @param imgPath
	 * @param imgName
	 * @return
	 */
	public int saveToImgByInputStream(InputStream instreams, String imgPath, String imgName) {
		int stateInt = 1;
		ByteArrayOutputStream outStream = null;
		FileOutputStream fos = null;
		if (instreams != null) {
			try {
				outStream = new ByteArrayOutputStream();// 创建一个Buffer字符串
				byte[] buffer = new byte[1024];// 每次读取的字符串长度，如果为-1，代表全部读取完毕 
				int len = 0;// 使用一个输入流从buffer里把数据读取出来 
				while ((len = instreams.read(buffer)) != -1) {// 用输出流往buffer里写入数据，中间参数代表从哪个位置开始读，len代表读取的长度 
					outStream.write(buffer, 0, len);
				}
				byte[] data = outStream.toByteArray();
				File file = new File(imgPath + imgName);// 可以是任何图片格式.jpg,.png等
				fos = new FileOutputStream(file);
				fos.write(data);
				fos.flush();
			} catch (Exception e) {
				stateInt = 0;
				e.printStackTrace();
			} finally {
				try {
					if (fos != null) {
						fos.close();
					}
					if (outStream != null) {
						outStream.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return stateInt;
	}

	public static void main(String[] args) {
//		Date date=new Date();
//		SimpleDateFormat s=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		System.out.println(s.format(date));
//		Calendar c = Calendar.getInstance();
//		c.add(Calendar.DATE, 60);//计算60天后的时间
//		String str2=s.format(c.getTime());
//		System.out.println("60天后的时间是："+str2);
//		String aaa="www.baidu.com";
//		String b[]= aaa.split("#");
//		System.out.println(b[0]+">>>");
//		
//		System.out.println(60 * 24 * 3600);
//		
		
		SimpleDateFormat s1=new SimpleDateFormat("yyyyMMdd");
		//取时间戳
		Calendar c1 = Calendar.getInstance();
		System.out.println(s1.format(c1.getTime()));
	}

	
	/**
	 * 获取活动时间
	 * @param skuId
	 * @return
	 */
//	public GroupActivityTimeInfo getActivityTimeInfo(String skuId){
//		
//		CommonResultEntity<GorderActivityInfoConciseVo> commonResultEntity = gorderInfoForAppNewResource.getActivityInfoBySkuId(skuId);
//		GorderActivityInfoConciseVo gorderActivityInfoConciseVo = commonResultEntity.getBusinessObj();
//		if(null == gorderActivityInfoConciseVo) return null;
//		GroupActivityTimeInfo  groupActivityTimeInfo = new GroupActivityTimeInfo();
//		SimpleDateFormat s=new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
//		if(gorderActivityInfoConciseVo.getStartTime() != null){
//			groupActivityTimeInfo.setStartTime(s.format(gorderActivityInfoConciseVo.getStartTime()));
//		}
//		if(gorderActivityInfoConciseVo.getEndTime() != null){
//			groupActivityTimeInfo.setEndTime(s.format(gorderActivityInfoConciseVo.getEndTime()));
//			
//		}
//		return groupActivityTimeInfo;
//
//	}
	/**
	 * 根据入参和定义的参数 生成有效的分享参数
	 * @param urlParam
	 * @param shareParam
	 * @return
	 */
	private Map<String,String> getUseparam(String urlParam,String shareParam){
		Map<String,String> map = new HashMap<String,String>();
		map.put("useParam", "");
		map.put("mid", "");
		if(urlParam == null || urlParam.equals("")){
			return map;
		}
		if(shareParam == null || shareParam.equals("")){
			return map;
		}
		
		String [] urlParams = urlParam.split("&");
		Map<String,String> paramMap = new HashMap<String,String>();
			for(String param : urlParams ){
				String[] keyValues = param.trim().split("=");
				if(keyValues != null && keyValues.length>0){
					String key = keyValues[0];
					String value= keyValues.length > 1 ? keyValues[1] : null;
					if(!StringUtils.isEmpty(key.trim())){
						paramMap.put(key, value);
					}
					
				}
			}
		StringBuilder sb = new StringBuilder("");	
		String [] shareParams = shareParam.split("#");
		for(String sharePa : shareParams){
			String value = paramMap.get(sharePa);
			if(value != null && sharePa.equals("mid")){
				if(!StringUtils.isEmpty(value)){
					map.put("mid", value);
				}
			}else{
				sb.append(sharePa).append("=");
				if(!StringUtils.isEmpty(value)){
					sb.append(value);
				}
				sb.append("&");
			}

		}
		if(sb.length()>0){
			sb.deleteCharAt(sb.length()-1);
		}
		
		map.put("useParam", sb.toString());
		return map;
	}
	
	
	
	/**
	 * 获取小程序吗对应的参数
	 * @param paramKey
	 * @return
	 */
	public String getShareParamValue(String paramKey){
		String paramVal = gcache.get("minShareCodeKey_"+paramKey);
		return paramVal;
	}
	
	
	/**
	 * 获取国美小程序吗对应的参数
	 * @param paramKey
	 * @return
	 */
	public String getGomeShareParamValue(String paramKey){
		String paramVal = gomeOnlineGcache.get("mini_program_share_"+paramKey);
		return paramVal;
	}

}
