package com.gome.meidian.grouporder.vo.homePage;

import com.gomeplus.bs.interfaces.cms2.vo.business.base.Menus;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageHeadMenu;
import com.gomeplus.bs.interfaces.cms2.vo.business.base.PageInfo;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 首页信息集合
 */
@Setter
@Getter
@ToString
public class HomePageVo implements Serializable {
	
	private static final long serialVersionUID = -1222539836535848354L;

	private List<PageHeadMenu> headMenuList = null;	// 头部导航

	private PageInfo defaultPageInfo;	// 默认也面信息

	private List<Menus> moduleMenuList = null;	// 模块排序id 对应moduleJsonMap对象内部的数据

	private Map<String, Object>  moduleJsonMap = null;	// 模块详细数据json值

	private List<Menus> prdMenuList = null;	// 瀑布流菜单

	public HomePageVo() {

	}


	@Override
	public String toString() {
		return "HomePageVo{" +
				"headMenuList=" + headMenuList +
				", defaultPageInfo=" + defaultPageInfo +
				", moduleMenuList=" + moduleMenuList +
				", moduleJsonMap=" + moduleJsonMap +
				", prdMenuList=" + prdMenuList +
				'}';
	}
}
