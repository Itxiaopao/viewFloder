package com.gome.meidian.grouporder.vo.register;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

public class SlideInfoVo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@NotBlank(message = "{base.user.token.notBlank}")
	private String token;//滑块token

	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
}
