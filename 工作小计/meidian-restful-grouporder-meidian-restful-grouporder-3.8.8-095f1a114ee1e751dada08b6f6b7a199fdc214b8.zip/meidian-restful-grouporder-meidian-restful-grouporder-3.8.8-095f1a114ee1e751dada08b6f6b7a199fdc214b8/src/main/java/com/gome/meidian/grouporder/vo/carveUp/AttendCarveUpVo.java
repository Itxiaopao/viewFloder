package com.gome.meidian.grouporder.vo.carveUp;

import javax.validation.constraints.Min;
import java.io.Serializable;

/**
 * 开团、参团接口请求参数封装类
 */
public class AttendCarveUpVo implements Serializable {

	private static final long serialVersionUID = -6558143076451166389L;
	//瓜分团活动ID
    @Min(message = "{param.error}", value = 1)
    private Long carveId;
    //瓜分团ID，开团为空，参团必填
    private Long groupId;

    public Long getCarveId() {
        return carveId;
    }

    public void setCarveId(Long carveId) {
        this.carveId = carveId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }
}
