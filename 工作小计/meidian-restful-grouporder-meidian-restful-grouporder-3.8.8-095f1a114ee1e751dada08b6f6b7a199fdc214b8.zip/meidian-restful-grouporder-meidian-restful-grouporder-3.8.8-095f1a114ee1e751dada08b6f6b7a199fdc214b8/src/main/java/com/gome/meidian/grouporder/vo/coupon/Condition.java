package com.gome.meidian.grouporder.vo.coupon;

import java.io.Serializable;
import java.util.List;

/**
 * 条件（满*件）
 * @author shichangjian
 *
 */
public class Condition implements Serializable{

	private static final long serialVersionUID = -4930743446450248911L;
	
	private String upLimit;			// 阶梯条件上限
	private String lowerLimit;		// 阶梯条件下限,(满2件)
	private Integer conditionType;	// 条件类型,按数量1 按金额2
	private List<Gift> gift;		// 赠品
	
	
	public Condition() {
		super();
	}
	public Condition(String upLimit, String lowerLimit, Integer conditionType, 
			List<Gift> gift) {
		super();
		this.upLimit = upLimit;
		this.lowerLimit = lowerLimit;
		this.conditionType = conditionType;
		this.gift = gift;
	}
	public String getUpLimit() {
		return upLimit;
	}
	public void setUpLimit(String upLimit) {
		this.upLimit = upLimit;
	}
	public String getLowerLimit() {
		return lowerLimit;
	}
	public void setLowerLimit(String lowerLimit) {
		this.lowerLimit = lowerLimit;
	}
	public Integer getConditionType() {
		return conditionType;
	}
	public void setConditionType(Integer conditionType) {
		this.conditionType = conditionType;
	}
	public List<Gift> getGift() {
		return gift;
	}
	public void setGift(List<Gift> gift) {
		this.gift = gift;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
