package com.gome.meidian.grouporder.utils;

import java.io.Serializable;
/**
 * 券信息转换
 * @author jiaochunxiao
 * 2019年10月2日 下午5:01:51
 */
public enum CouponEnum implements Serializable {
    MEI("3001", "mei","美券"),
    BLUE("3002", "blue","蓝券"),
    RED("3003", "red","红券"),
    MARKET("3005", "market","神券");
   

    private String id;
    private String code;
    private String name;


    public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getCode() {
		return code;
	}


	public void setCode(String code) {
		this.code = code;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	CouponEnum(String id, String code, String name) {
        this.id = id;
        this.code = code;
        this.name = name;
    }

	/**
	 * 通过id获得对应的枚举类
	 *
	 * @param code
	 * @return
	 */
	public static CouponEnum parseId(String id) {
		for (CouponEnum m : CouponEnum.values()) {
			if (m.getId().equals(id) ) {
				return m;
			}
		}
		return null;
	}
	/**
	 * 通过code获得对应的枚举类
	 *
	 * @param code
	 * @return
	 */
	public static CouponEnum parseCode(String code) {
		for (CouponEnum m : CouponEnum.values()) {
			if (m.getCode().equals(code)) {
				return m;
			}
		}
		return null;
	}
}
