package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

public class PriceConditionVo implements Serializable {

	private static final long serialVersionUID = 3132897721768521503L;
	
	
	private String skuId;
	//策略ID 
	private String policyId;
	//非必填
	private String productId;
	//渠道  非必填
	private String channel;
	//请求数量  默认1
	private Integer num;
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getPolicyId() {
		return policyId;
	}
	public void setPolicyId(String policyId) {
		this.policyId = policyId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	
	
}
