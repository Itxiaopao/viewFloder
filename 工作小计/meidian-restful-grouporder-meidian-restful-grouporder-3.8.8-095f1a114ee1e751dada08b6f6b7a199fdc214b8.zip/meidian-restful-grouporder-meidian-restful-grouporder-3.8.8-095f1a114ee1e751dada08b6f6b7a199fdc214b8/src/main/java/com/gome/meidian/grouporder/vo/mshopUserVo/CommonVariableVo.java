package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

/**
 * @author sunxueyan-ds
 * @Title: CommonVariableVo
 * @ProjectName meidian-restful-grouporder
 * @Description: TODO
 * @date 2018/11/29 15:22
 */
public class CommonVariableVo implements Serializable {
    private static final long serialVersionUID = 9198863029921507536L;

    public static final String invokeFrom = "gomeShop";
    public static final String invokeChannel = "gomeShopWap";//登录来源 美店wap
    public static final String companyName = "gomeOnLine";
    public static final String quick_login_bizNo = "WapMeidianSmsLogin";//wap短信验证码登录 场景号
    public static final String account_login_bizNo = "WapMeidianLogin";//wap 账号密码登录 场景号
    public static final String register_bizNo = "WapMeidianRegister";//注册 场景号
    public static final String sms_login_bizNo = "WapMeidianLoginSms";//短信验证码登录短信防刷 场景号
    public static final String sms_register_bizNo = "WapMeidianRegisterSms";// 注册短信防刷 场景号
    public static final String sms_bind_bizNo = "WapMeidianMobileSms";// 手机号绑定短信防刷 场景号
    public static final String appid = "88065054626c0d3dc918afb75ea026a2";//appId和前端验证码的appId保持一致，appId可公开
    public static final String appsecret = "0cdbddd334410b75f3aff97ec6e05fd4";//appSecret为秘钥，请勿公开
    public static final String BusinessName_perfect = "gomeShop_complete_phone";//短息模板  完善手机号场景
    public static final String BusinessId_perfect = "1087";//短息模板Id
    public static final String BusinessName_quick = "gomeShop_quick_login";//短息模板  手机快登
    public static final String BusinessId_quick = "1091";//短息模板Id

}
