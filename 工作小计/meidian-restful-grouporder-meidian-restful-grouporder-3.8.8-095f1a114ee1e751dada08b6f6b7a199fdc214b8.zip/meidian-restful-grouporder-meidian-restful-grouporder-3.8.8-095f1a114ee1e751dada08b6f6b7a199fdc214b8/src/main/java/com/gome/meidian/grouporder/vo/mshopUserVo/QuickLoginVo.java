package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author sunxueyan-ds
 * @Title: QuickLoginVo
 * @ProjectName meidian-restful-grouporder
 * @Description: TODO
 * @date 2018/12/3 17:50
 */
@Data
public class QuickLoginVo implements Serializable {
    private static final long serialVersionUID = -2681888600870066977L;

    private String mobile;                     //手机号
    private String code;                     //验证码
    private String invokeFrom;                     //调用来源
    private String requestParams;                     //初始化信息
    private String invokeChannel;                     //请求来源
    private String clientIp;                     //用户登录的ip地址
    private String remotePort;                     //用户访问网络的端口号
    private String map;                     //扩展字段
    private String appId;                     //互踢业务号
    private String companyName;                     //渠道标识
    private String isAutoLogin;                     //是否自动登录
    private String businessName;                     //短信平台分配的业务key
    private String templateId;                     //短信模板id
    private String msgCode;                     //短信验证码
    private String distinctId;                     //灯塔埋码
    private String userId;                          //userid 用户名
    private String userName;                          //用户名
    private String token;                           //滑块 前端生成
    private String password;                           //滑块 前端生成
    private String createType;                           //渠道来源：描述红包  签到  等等的业务埋的参数


}
