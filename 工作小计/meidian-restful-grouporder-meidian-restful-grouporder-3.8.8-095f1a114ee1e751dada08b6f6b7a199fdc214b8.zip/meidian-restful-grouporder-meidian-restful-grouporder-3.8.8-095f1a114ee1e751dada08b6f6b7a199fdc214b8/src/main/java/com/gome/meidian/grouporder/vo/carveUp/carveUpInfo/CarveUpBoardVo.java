package com.gome.meidian.grouporder.vo.carveUp.carveUpInfo;


import java.io.Serializable;
import java.util.List;

public class CarveUpBoardVo implements Serializable {
	private static final long serialVersionUID = -610274032680358333L;
	private Long id; //id
    private Long carveId; //瓜分活动id
    private Integer status; //瓜分团状态： 0：初始值；1：已开始；2：已结束
//    private Integer carveGroupType; //瓜分团类型：1：基础团，2：排名团--奖励定额，3：排名团--奖励瓜分
//    private Long startTime; //开始时间
//    private Long endTime; //结束时间
//    private Integer rankHelpMaxPeopleNum; //排名团，最多人数限制',--团
//    private Double rankFixMoney; //排名团额外每人固定国美币
//    private Double rankTotalMoney; //排名团额外总国美币
//    private Integer carveGroupRewardNum; //排名团，额外奖励的团数',--商品集
//    private Integer groupFinalSort;//团当前排名
//    private Integer isReward;//团是否获得排名额外奖励 0 未获得  1 已获得
//    private List<Coupon> rankCoupons;  //排名团券信息

	private String appletImageUrl; //小程序card图片
	private String friendImageUrl; //好友朋友圈图片
	private String friendSubImageUrl; //好友朋友圈配图
    
    private List<MyCarveUpGroupVo> initGroups;  //发起的团
    private List<MyCarveUpGroupVo> attendGroups; //参与的团
    private List<CarveUpGroupRankingVo> groups;  //榜单列表

//    public Integer getIsReward() {
//        return isReward;
//    }
//
//    public void setIsReward(Integer isReward) {
//        this.isReward = isReward;
//    }

    public List<MyCarveUpGroupVo> getInitGroups() {
        return initGroups;
    }

    public void setInitGroups(List<MyCarveUpGroupVo> initGroups) {
        this.initGroups = initGroups;
    }

    public List<MyCarveUpGroupVo> getAttendGroups() {
        return attendGroups;
    }

    public void setAttendGroups(List<MyCarveUpGroupVo> attendGroups) {
        this.attendGroups = attendGroups;
    }

 

    public List<CarveUpGroupRankingVo> getGroups() {
		return groups;
	}

	public void setGroups(List<CarveUpGroupRankingVo> groups) {
		this.groups = groups;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCarveId() {
        return carveId;
    }

    public void setCarveId(Long carveId) {
        this.carveId = carveId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

	public String getAppletImageUrl() {
		return appletImageUrl;
	}

	public void setAppletImageUrl(String appletImageUrl) {
		this.appletImageUrl = appletImageUrl;
	}

	public String getFriendImageUrl() {
		return friendImageUrl;
	}

	public void setFriendImageUrl(String friendImageUrl) {
		this.friendImageUrl = friendImageUrl;
	}

	public String getFriendSubImageUrl() {
		return friendSubImageUrl;
	}

	public void setFriendSubImageUrl(String friendSubImageUrl) {
		this.friendSubImageUrl = friendSubImageUrl;
	}

//    public Integer getCarveGroupType() {
//        return carveGroupType;
//    }
//
//    public void setCarveGroupType(Integer carveGroupType) {
//        this.carveGroupType = carveGroupType;
//    }
//
//    public Long getStartTime() {
//        return startTime;
//    }
//
//    public void setStartTime(Long startTime) {
//        this.startTime = startTime;
//    }
//
//    public Long getEndTime() {
//        return endTime;
//    }

//    public void setEndTime(Long endTime) {
//        this.endTime = endTime;
//    }
//
//    public Integer getRankHelpMaxPeopleNum() {
//        return rankHelpMaxPeopleNum;
//    }
//
//    public void setRankHelpMaxPeopleNum(Integer rankHelpMaxPeopleNum) {
//        this.rankHelpMaxPeopleNum = rankHelpMaxPeopleNum;
//    }
//
//    public Double getRankFixMoney() {
//        return rankFixMoney;
//    }
//
//    public void setRankFixMoney(Double rankFixMoney) {
//        this.rankFixMoney = rankFixMoney;
//    }
//
//    public Double getRankTotalMoney() {
//        return rankTotalMoney;
//    }
//
//    public void setRankTotalMoney(Double rankTotalMoney) {
//        this.rankTotalMoney = rankTotalMoney;
//    }

//    public Integer getCarveGroupRewardNum() {
//        return carveGroupRewardNum;
//    }
//
//    public void setCarveGroupRewardNum(Integer carveGroupRewardNum) {
//        this.carveGroupRewardNum = carveGroupRewardNum;
//    }

//    public List<Coupon> getRankCoupons() {
//        return rankCoupons;
//    }
//
//    public void setRankCoupons(List<Coupon> rankCoupons) {
//        this.rankCoupons = rankCoupons;
//    }

//	public Integer getGroupFinalSort() {
//		return groupFinalSort;
//	}
//
//	public void setGroupFinalSort(Integer groupFinalSort) {
//		this.groupFinalSort = groupFinalSort;
//	}
    
    
}
