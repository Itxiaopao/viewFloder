package com.gome.meidian.grouporder.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.TaskShopManager;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.vo.register.CheckShopVo;
import com.gome.meidian.grouporder.vo.register.ShopInfoVo;
import com.gome.meidian.grouporder.vo.register.TaskCmsVo;
import com.gome.meidian.grouporder.vo.register.TaskRewardVo;
import com.gome.meidian.grouporder.vo.register.TaskShopVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gomeplus.bs.framework.dubbor.vo.PageCollection;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskRewardDetailVo;

@RestController
@Validated
@RequestMapping("/taskShop")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class TaskShopController {
	
	@Autowired
	private TaskShopManager taskShopManager;
	
	/**
	 * 获取店主首页数据
	 * @param taskCmsVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/taskShopInfo")
	public ResponseJson taskShopInfo(
			@Valid @RequestBody TaskCmsVo taskCmsVo,
			@CookieValue(value = "Channel", required = false) String Channel
			) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		if(null != Channel && !Channel.equals("")){
			if(Channel.equals(GroupOrderConstants.CHANNEL_IOS_APP) 
					|| Channel.equals(GroupOrderConstants.CHANNEL_ANDROID_APP))
				return responseJson;
		}
		
		Map<String, Object> map = taskShopManager.taskShopInfo(taskCmsVo);
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 获取店主拉新详情
	 * @param taskShopVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/taskShopDesc")
	public ResponseJson taskShopDesc(@Valid @RequestBody TaskShopVo taskShopVo) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		Map<String, Object> map = taskShopManager.taskShopDesc(taskShopVo);
		responseJson.setData(map);
		return responseJson;
	}
	
	/**
	 * 获取邀请明细
	 * @param vo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/taskShopBakDesc")
	public ResponseJson taskShopBakDesc(@Valid @RequestBody TaskRewardVo taskRewardVo) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		PageCollection<TaskRewardDetailVo> result= taskShopManager.taskInviteDetail(taskRewardVo);
		responseJson.setData(result);
		return responseJson;
	}
	
	/**
	 * 获取历史活动邀请明细
	 * @param userId
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/historyInviteDetail", method = RequestMethod.GET)
	public ResponseJson historyInviteDetail(@NotNull(message="{shop.task.user.userId.notNull}") @RequestParam Long userId) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		List<Map<String, Object>> listMap = taskShopManager.historyInviteDetail(userId);
		responseJson.setData(listMap);
		return responseJson;
	}
	
	/**
	 * 累计GMV任务邀请开店
	 * @param shopInfoVo
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/savaInitTaskShop", method = RequestMethod.POST)
	public ResponseJson savaInitTaskShop(@Valid @RequestBody ShopInfoVo shopInfoVo,@CookieValue(value="SCN",required=true) String scn) throws MeidianException {
		ResponseJson responseJson = taskShopManager.savaInitTaskShop(shopInfoVo,scn);
		return responseJson;
	}
	
	/**
	 * 校验店铺名称和手机号是否存在
	 * @param shopInfoVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@RequestMapping(value = "/checkVshopNamePhoneNo", method = RequestMethod.POST)
	public ResponseJson checkVshopNamePhoneNo(@Valid @RequestBody CheckShopVo checkShopVo) throws Exception {
		ResponseJson responseJson = taskShopManager.checkVshopNamePhoneNo(checkShopVo);
		return responseJson;
	}
	
}
