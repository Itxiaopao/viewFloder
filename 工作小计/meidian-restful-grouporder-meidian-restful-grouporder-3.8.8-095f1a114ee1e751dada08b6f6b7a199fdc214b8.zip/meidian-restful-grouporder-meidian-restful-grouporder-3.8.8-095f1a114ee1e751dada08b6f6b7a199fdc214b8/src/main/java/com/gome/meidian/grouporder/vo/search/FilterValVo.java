package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;

public class FilterValVo implements Serializable{

	private static final long serialVersionUID = 1236111864121541307L;
	private String filterVal;
	public String getFilterVal() {
		return filterVal;
	}
	public void setFilterVal(String filterVal) {
		this.filterVal = filterVal;
	}

}
