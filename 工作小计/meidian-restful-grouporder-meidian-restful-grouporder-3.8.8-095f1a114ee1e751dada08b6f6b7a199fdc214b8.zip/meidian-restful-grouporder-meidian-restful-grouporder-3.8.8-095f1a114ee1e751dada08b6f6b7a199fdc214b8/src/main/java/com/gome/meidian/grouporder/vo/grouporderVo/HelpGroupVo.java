package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotBlank;

public class HelpGroupVo implements Serializable {
	
	private static final long serialVersionUID = -8773556073146785158L;
	@Min(message = "{param.error}", value = 1) 
	private Long groupId;
	@NotBlank(message = "{param.error}")
	private String orderId;
	@NotBlank(message = "{param.error}")
	private String userId;
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
}
