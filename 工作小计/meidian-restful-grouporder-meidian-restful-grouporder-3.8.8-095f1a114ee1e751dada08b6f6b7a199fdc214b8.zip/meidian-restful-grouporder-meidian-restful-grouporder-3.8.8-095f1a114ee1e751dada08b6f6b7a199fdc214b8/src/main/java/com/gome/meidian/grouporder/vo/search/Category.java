package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;
import java.util.List;

public class Category implements Serializable, Comparable<Category>{

	private static final long serialVersionUID = 1326484752607797253L;
	
	private String defaultHot; //是否热门词
	
	private Long count;//数量
	
	private String catName;//名称
	
	private String catId;//id
	
	private List<Category> catList;

	@Override
    public int compareTo(Category category) {  
        Long i = category.getCount() - this.getCount();  
        return i.intValue();  
    }

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public String getDefaultHot() {
		return defaultHot;
	}

	public void setDefaultHot(String defaultHot) {
		this.defaultHot = defaultHot;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}

	public String getCatId() {
		return catId;
	}

	public void setCatId(String catId) {
		this.catId = catId;
	}

	public List<Category> getCatList() {
		return catList;
	}

	public void setCatList(List<Category> catList) {
		this.catList = catList;
	}



	
	

}
