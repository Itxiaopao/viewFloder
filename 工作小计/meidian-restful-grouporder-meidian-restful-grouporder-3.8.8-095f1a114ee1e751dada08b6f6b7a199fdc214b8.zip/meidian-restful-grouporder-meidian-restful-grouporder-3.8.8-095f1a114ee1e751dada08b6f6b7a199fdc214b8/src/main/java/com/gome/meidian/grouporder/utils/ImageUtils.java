package com.gome.meidian.grouporder.utils;

import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public class ImageUtils {
	/**
	 * 
	 * @Description 替换URL协议
	 * @version 
	 *
	 * @param url
	 * @return
	 */
	public static String replaceUrlProtocol(String url, String protocol) {
		if(StringUtils.isBlank(url) || StringUtils.isBlank(protocol)) {
			return null;
		}
		
		if(url.startsWith("http:")) {
			if("https:".equals(protocol)) {
				url = url.replace("http:", protocol);
			}
		}else if(url.startsWith("https:")) {
			if("http:".equals(protocol)) {
				url = url.replace("https:", protocol);
			}
		}else {
			if(!url.startsWith("//")) {
				url = "//" + url;
			}
			url = protocol + url;
		}
		
		return url;
		
	}

	/**
	 * 微信头像分辨率处理
	 * @param orgImage 原始头像连接
	 * @param userImage 分辨率
	 * @param agreement 协议http/https
	 * @param userImage
	 */
	public static String  userImageUrlInfo2(String orgImage, String userImage, String agreement){
		// 查找“.”最后一次出现的索引
		if(StringUtils.isEmpty(orgImage)) {
			return orgImage;
		}
		int index = orgImage.lastIndexOf(".");
		if(index < 0) {
			return orgImage;
		}
		StringBuffer imageInfo = new StringBuffer(orgImage);
		imageInfo.insert(index, userImage);
		// 处理http协议
		String image = new String(imageInfo);
		if(image.contains("http:")){
			image = image.replace("http:", agreement);
		}
		return image;
	}

	
	/**
	 * 用户头像分辨率处理
	 * @param groupUserInfos
	 * @param userImage
	 */
	public static void userImageUrlInfo(List<GroupUserInfo> groupUserInfos, String userImage, String agreement){
		for (GroupUserInfo groupUserInfo : groupUserInfos) {
			// 查找“.”最后一次出现的索引
			if(null == groupUserInfo.getImage()) continue;
			int index = groupUserInfo.getImage().lastIndexOf(".");
			if(index < 0) continue;
			StringBuffer imageInfo = new StringBuffer(groupUserInfo.getImage()); 
			imageInfo.insert(index, userImage);
			// 处理http协议
			String image = new String(imageInfo);
			if(image.contains("http:"))
				image = image.replace("http:", agreement);
			
			groupUserInfo.setImage(image);
		}
	}
	public static Byte userAgentChannel(HttpServletRequest request){
		String userAgent = request.getHeader("User-Agent");
		if(null == userAgent) return 0;
		if(null == userAgent.toLowerCase()) return 0;
//		if(userAgent.indexOf("Micromessenger") != -1){
//			//微信
//		}else if(userAgent.indexOf("iPhone") != -1 || userAgent.indexOf("iPad") != -1 || userAgent.indexOf("iPod") != -1){
			//苹果
//			return 2;
//		}
		
		if(userAgent.indexOf("Android") != -1){
			//安卓
			return 1;
		}
		
		return 0;
	}
	
	
	public static String imageUrlInfo(String image, String ratio, Byte ua){
		// 查找“.”最后一次出现的索引
		if(null == image) return null;
		int index = image.lastIndexOf(".");
		if(index < 0) return null;
		
		String subUrl = image.substring(0, index);
		String subLast = image.substring(index);
		
		if(subLast.equals(".gif")){
			return image;
		}
		
		StringBuffer imageInfo = new StringBuffer(subUrl);
		if(ua == 1){
			// 安卓
			imageInfo.append(ratio + ".webp");
		}else{
			imageInfo.append(ratio + subLast);
		}

		return new String(imageInfo);
	}
	
	/**
	 * 处理安卓图片后缀
	 * @param image
	 * @param ua
	 * @return
	 */
	public static String imageUrlInfo(String image, Byte ua){
		if(ua == 1){
			
			// 查找“.”最后一次出现的索引
			if(null == image) return null;
			int index = image.lastIndexOf(".");
			if(index < 0) return image;
			
			String subUrl = image.substring(0, index);
			String subLast = image.substring(index);
			
			if(subLast.equals(".gif")){
				return image;
			}
			
			StringBuffer imageInfo = new StringBuffer(subUrl);
			imageInfo.append(".webp");
			return new String(imageInfo);
		}
		
		return image;
	}
	
	/**
	 * 根据像素匹配分辨率
	 * @param ppi
	 * @param imageChannel
	 * @return
	 */
	public static String imagePpiInfo(Integer ppi, byte imageChannel){
		switch(imageChannel) {
			case 1:
				// 首页banner图
				if(null == ppi || ppi <= 0){
					// 默认
					return "_750_280";
				}else if(ppi <= 2527200){
//					return "_375_140";
					return "_750_280";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_750_280";
				}else if(ppi > 4492800){
					return "_1125_420";
				}
			case 2:
				// 单列商品图
				if(null == ppi || ppi <= 0){
					// 默认
					return "_200_200";
				}else if(ppi <= 2527200){
					return "_200_200";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_200_200";
				}else if(ppi > 4492800){
					return "_300_300";
				}
			case 3:
				// 双列商品图
				if(null == ppi || ppi <= 0){
					// 默认
					return "_340_340";
				}else if(ppi <= 2527200){
					return "_240_240";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_240_240";
				}else if(ppi > 4492800){
					return "_510_510";
				}
			case 4:
				// 商详页主图
				if(null == ppi || ppi <= 0){
					// 默认
					return "_600_600";
				}else if(ppi <= 2527200){
					return "_400_400";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_600_600";
				}else if(ppi > 4492800){
					return "_720_720";
				}
			case 5:
				// 单劵商品详情页
				if(null == ppi || ppi <= 0){
					// 默认
					return "_260_280";
				}else if(ppi <= 2527200){
					return "_260_280";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_260_280";
				}else if(ppi > 4492800){
					return "_390_420";
				}
			case 6:
				// 主页列表中的专题活动页
				if(null == ppi || ppi <= 0){
					// 默认
					return "_180_180";
				}else if(ppi <= 2527200){
					return "_180_180";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_180_180";
				}else if(ppi > 4492800){
					return "_270_270";
				}
			case 7:
				// 
				if(null == ppi || ppi <= 0){
					// 默认
					return "_200_200";
				}else if(ppi <= 2527200){
					return "_150_150";
				}else if(ppi > 2527200 && ppi <= 4492800){
					return "_200_200";
				}else if(ppi > 4492800){
					return "_300_300";
				}
		}
		return null;
	}
	
	/**
	 * 域名切换
	 * @param target
	 * @return
	 */
	public static String domainInfo(String target){
		// 默认第一套
		
		String tar = null;
		
		// 第二套域名
//		if(target.contains("d.m.gome.com.cn")){
//			tar = target.replaceAll("d.m.gome.com.cn", "groupbuy.m.gome.com.cn");
//		}else if(target.contains("gorder.m.gome.com.cn")){
//			tar = target.replaceAll("gorder.m.gome.com.cn", "order.m.gome.com.cn");
//		}else if(target.contains("mshop.m.gome.com.cn")){
//			tar = target.replaceAll("mshop.m.gome.com.cn", "store.m.gome.com.cn");
//		}
		
		// 第三套域名
//		if(target.contains("d.m.gome.com.cn")){
//			tar = target.replaceAll("d.m.gome.com.cn", "groupbuy1.m.gome.com.cn");
//		}else if(target.contains("gorder.m.gome.com.cn")){
//			tar = target.replaceAll("gorder.m.gome.com.cn", "order1.m.gome.com.cn");
//		}else if(target.contains("mshop.m.gome.com.cn")){
//			tar = target.replaceAll("mshop.m.gome.com.cn", "store1.m.gome.com.cn");
//		}
		
		if(null == tar) return target;
		return tar;
	}
}
