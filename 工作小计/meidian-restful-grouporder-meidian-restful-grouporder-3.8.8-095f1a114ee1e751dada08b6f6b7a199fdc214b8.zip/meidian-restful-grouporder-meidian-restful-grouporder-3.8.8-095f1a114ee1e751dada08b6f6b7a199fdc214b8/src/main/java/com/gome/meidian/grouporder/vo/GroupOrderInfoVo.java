package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

public class GroupOrderInfoVo implements Serializable {

	private static final long serialVersionUID = 8492278454503312159L;

	private Long groupId;		// 团id
	private Long activityId;	// 活动id
	private String businessType;// 操作类型（1：普通，2：团抢，3：抢购，4：预售，5：线上微信店，6：送礼物，7：海外购，8：快速购
	private String productId;	// 商品productId
	private String skuId;		// skuId
	private Integer buyNumber;
	private Long userId;
	private String productName;
	private Long price;
	private String image;
	private String orderUrl;
	private String kid;
	private String returnUrl;
	private Object buyGoods ;
	public GroupOrderInfoVo() {
		super();
	}
	public GroupOrderInfoVo(Long groupId, Long activityId, String businessType, String productId, String skuId, Integer buyNumber,
			Long userId, String productName, Long price, String image, String orderUrl, String kid, String returnUrl) {
		super();
		this.groupId = groupId;
		this.activityId = activityId;
		this.businessType = businessType;
		this.productId = productId;
		this.skuId = skuId;
		this.buyNumber = buyNumber;
		this.userId = userId;
		this.productName = productName;
		this.price = price;
		this.image = image;
		this.orderUrl = orderUrl;
		this.kid = kid;
		this.returnUrl = returnUrl;
	}
	public Long getGroupId() {
		return groupId;
	}
	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public Integer getBuyNumber() {
		return buyNumber;
	}
	public void setBuyNumber(Integer buyNumber) {
		this.buyNumber = buyNumber;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Long getPrice() {
		return price;
	}
	public void setPrice(Long price) {
		this.price = price;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getOrderUrl() {
		return orderUrl;
	}
	public void setOrderUrl(String orderUrl) {
		this.orderUrl = orderUrl;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getKid() {
		return kid;
	}
	public void setKid(String kid) {
		this.kid = kid;
	}
	public Object getBuyGoods() {
		return buyGoods;
	}
	public void setBuyGoods(Object buyGoods) {
		this.buyGoods = buyGoods;
	}
	public String getReturnUrl() {
		return returnUrl;
	}
	public void setReturnUrl(String returnUrl) {
		this.returnUrl = returnUrl;
	}

}
