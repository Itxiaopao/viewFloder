package com.gome.meidian.grouporder.vo.homePage;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * @Author yuliang-ds1
 * @Date 2019/1/12 15:13
 * @Description
 */
@Setter
@Getter
@ToString
public class ZutuanCmsVo implements Serializable {

    private static final long serialVersionUID = 4441741920923559422L;

    private Long id;
    private String code; // code

    private String activityId;	// 组团id
    private String productId;	// 品类id
    private String skuId;	//skuId

    private String skuNo;	//skuId
    private String shopId;	//skuId


}
