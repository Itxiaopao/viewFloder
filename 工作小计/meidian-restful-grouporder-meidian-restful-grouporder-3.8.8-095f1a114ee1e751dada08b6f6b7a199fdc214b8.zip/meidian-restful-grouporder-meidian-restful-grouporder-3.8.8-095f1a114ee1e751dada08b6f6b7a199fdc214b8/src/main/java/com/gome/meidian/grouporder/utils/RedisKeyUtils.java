package com.gome.meidian.grouporder.utils;

import com.gome.spring.compents.util.MD5Util;
import org.apache.commons.lang.StringUtils;

public class RedisKeyUtils {
    private final static int partition = 30;

    /**
     * 根据userId获取hmap的存储key
     * @param userId
     * @return
     */
    public static String getHKey(String userId){
        return RedisKeyUtils.getHKeyByPartition(userId, partition);
    }

    /**
     * 根据field关键字和partition分区获取key
     * @param field
     * @param partition
     * @return
     */
    public static String getHKeyByPartition(String field, int partition){
        if(StringUtils.isBlank(field)){
            return null;
        }

        if(partition <= 0){
            partition = 1;
        }

        int key = MD5Util.toMD5(field).hashCode() % partition;
        return key + "";
    }
}
