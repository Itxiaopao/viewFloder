package com.gome.meidian.grouporder.vo.coupon;

import com.gome.meidian.grouporder.vo.Coupon;

public class TransitionCoupon extends Coupon{

	private String transitionCouponId;	// 劵id，和劵规则id，方案id，不一样
	private String userId;				// 领劵人的userId
	private Byte cashing;				// 是否领取
	private String refPromotionId;		// 劵关联的促销

	public TransitionCoupon(String coupon_id, String plan_id, Double coupon_num, 
			String description, Double fullAmount, String get_start_time, 
			String get_end_time, String show_start_time, String show_end_time, 
			String couponType, String activeId, String transitionCouponId,
			String userId, Byte cashing, String refPromotionId,Integer validity) {
		
		super(coupon_id, plan_id, coupon_num, 
				description, fullAmount, get_start_time, 
				get_end_time, show_start_time, show_end_time, 
				couponType, activeId,validity);
		
		this.transitionCouponId = transitionCouponId;
		this.userId = userId;
		this.cashing = cashing;
		this.refPromotionId = refPromotionId;
	}

	public String getTransitionCouponId() {
		return transitionCouponId;
	}

	public void setTransitionCouponId(String transitionCouponId) {
		this.transitionCouponId = transitionCouponId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Byte getCashing() {
		return cashing;
	}

	public void setCashing(Byte cashing) {
		this.cashing = cashing;
	}

	public String getRefPromotionId() {
		return refPromotionId;
	}

	public void setRefPromotionId(String refPromotionId) {
		this.refPromotionId = refPromotionId;
	}

	
	
}
