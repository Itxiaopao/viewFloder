package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.buyRebate;
import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupProduct;

/**
 * 首页商品购买返入参
 * @author shichangjian
 *
 */
public class ProductBuyRebate implements Serializable{

	private static final long serialVersionUID = -7697649341292561820L;

	@NotBlank(message = "{param.error}", groups = { buyRebate.class})
	private String productId;
	@NotBlank(message = "{param.error}", groups = { buyRebate.class})
	private String skuNo;
	private String skuId;
//	@NotNull(message = "{param.error}", groups = { buyRebate.class})
//	private Integer selfJointRebate;	// 自营联营购买返类型
//	private String shopId;				// 商户id
	
	public ProductBuyRebate() {
		super();
	}
	public ProductBuyRebate(String productId, String skuNo, String skuId) {
		super();
		this.productId = productId;
		this.skuNo = skuNo;
		this.skuId = skuId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
//	public Integer getSelfJointRebate() {
//		return selfJointRebate;
//	}
//	public void setSelfJointRebate(Integer selfJointRebate) {
//		this.selfJointRebate = selfJointRebate;
//	}
//	public String getShopId() {
//		return shopId;
//	}
//	public void setShopId(String shopId) {
//		this.shopId = shopId;
//	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	
	
}
