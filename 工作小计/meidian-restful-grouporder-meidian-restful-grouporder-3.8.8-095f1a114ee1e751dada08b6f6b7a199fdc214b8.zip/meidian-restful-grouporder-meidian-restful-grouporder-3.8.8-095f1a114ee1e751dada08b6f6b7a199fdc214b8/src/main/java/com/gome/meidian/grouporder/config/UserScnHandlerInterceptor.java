package com.gome.meidian.grouporder.config;

import java.net.URLDecoder;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.gome.meidian.grouporder.manager.mshopUserManager.UserLoginAuthManager;
import com.gome.meidian.grouporder.utils.CookieUtils;
import com.gome.meidian.grouporder.utils.MD5Util;

import redis.Gcache;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/12 11:02
 * @Description 每个用户每天一次延长SCN
 */
//@Component
public class UserScnHandlerInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(UserScnHandlerInterceptor.class);

    @Resource(name = "userCenter")
    private Gcache userCenter;

    @Autowired
    private UserLoginAuthManager userLoginAuthManager;

    @Value("${cookie.delayTime}")
    private int delayTime;

    @Value("${cookie.path}")
    private String path;

    @Value("${cookie.domain}")
    private String domain;


    /**
     * 进入controller层之前拦截请求
     * @param httpServletRequest
     * @param httpServletResponse
     * @param o
     * @return
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        Cookie cookie=CookieUtils.getCookieByName(httpServletRequest,CookieUtils.COOKIE_SCN);
        if(null!=cookie){
            String scn=cookie.getValue();
            String scnKey=MD5Util.encode(scn);
            //缓存中SCN存在说明当天延长过SCN，并放入过缓存，否则当天延长过
            String redisScn=userCenter.get(scnKey);
            if(null==redisScn){
                String decodeSCN= URLDecoder.decode(scn,"UTF-8");
                int status=userLoginAuthManager.extendLoginAuth(decodeSCN,delayTime);
                if(status==0){
                    //1.延长SCN,重新设置COOKIE时间
                    log.info("scn-extendLoginAuth success after extendCookieTime scn:{} path:{},domain:{} time:{}",scn,path,domain,delayTime);
                    CookieUtils.setCookie(httpServletResponse,CookieUtils.COOKIE_SCN,scn,path,domain,delayTime);
                    userCenter.setex(scnKey,delayTime,scn);
                    //2.设置延长COOKIE_MSHOP_USER_ID
                    Cookie mshopCookie=CookieUtils.getCookieByName(httpServletRequest,CookieUtils.COOKIE_MSHOP_USER_ID);
                    if(null!=mshopCookie){
                        String mshop_userId=mshopCookie.getValue();
                        CookieUtils.setCookie(httpServletResponse,CookieUtils.COOKIE_MSHOP_USER_ID,mshop_userId,path,domain,delayTime);
                    }
                }
            }

        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
        //log.info("--------------处理请求完成后视图渲染之前的处理操作---------------");
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        //log.info("---------------视图渲染之后的操作-------------------------0");
       /* Cookie cookie=CookieUtils.getCookieByName(httpServletRequest,CookieUtils.COOKIE_SCN);
        if(null!=cookie){
            String scn=cookie.getValue();
            log.info("scn-extendLoginAuth after setCookie scn:{} path:{},domain:{} time:{}",scn,path,domain,delayTime);
            CookieUtils.setCookie(httpServletResponse,CookieUtils.COOKIE_SCN,scn,path,domain,delayTime);

        }
        Cookie mshopCookie=CookieUtils.getCookieByName(httpServletRequest,CookieUtils.COOKIE_MSHOP_USER_ID);
        if(null!=cookie){
            String mshop_userId=mshopCookie.getValue();
            CookieUtils.setCookie(httpServletResponse,CookieUtils.COOKIE_MSHOP_USER_ID,mshop_userId,path,domain,delayTime);
        }*/
    }




}
