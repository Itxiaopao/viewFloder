package com.gome.meidian.grouporder.manager.app;
import java.net.URI;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.http.client.methods.HttpGet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.toolkit.StringUtils;
import com.gome.meidian.grouporder.utils.HttpClientUtil;
import com.gome.meidian.grouporder.utils.WeiXinMobileDES;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import redis.Gcache;
/**
 * add by lsx
 * 美店小程序获取token类
 */
@Service
public class MinTokenManager {
	private Logger logger = LoggerFactory.getLogger(getClass());
	private static final String GRANT_TYPE = "client_credential"; // 获取access_token填写client_credential
	@Value("${meidian.MinProgram.appId}")
	private String appId;
	@Value("${meidian.MinProgram.secret}")
	private String secret;
	@Value("${meidian.MinProgram.tokenUrl}")
	private String tokenUrl;
	@Resource(name = "gcache")
	private Gcache gcache;
	@Autowired
	private HttpClientUtil httpClientUtil;
	@Value("${meidian.MinProgram.gzNo}")
	private String gzNo;
	@Value("${meidian.MinProgram.gomeAppId}")
	private String gomeAppId;
	@Value("${meidian.MinProgram.gomeSecret}")
	private String gomeSecret;
	@Value("${meidian.MinProgram.gomeGzNo}")
	private String gomeGzNo;
	/**
	 * 获取token
	 * 
	 * @return
	 */
	public String getToken() {
//		String token = gcache.get("meidian.MinProgram.Token1");
//		if (token == null) {
//				token = gcache.get("meidian.MinProgram.Token2");
//				if(token != null ){
//					gcache.set("meidian.MinProgram.Token1", token);
//				}
//				String newToken = createToken();
//				if (newToken != null) {
//					token = newToken;
//					gcache.set("meidian.MinProgram.Token1", token);
//					gcache.set("meidian.MinProgram.Token2", token);
//				} 
//		}
//		String appid = "wxMShop2018";
//		String appSercet = "tqn21am98krr0v8pc1grlaufm4q8pvbimzk";
		String gzNo = "ServiceMiniprogramMshop";
		String token = WeiXinMobileDES.createToken(appId, secret);
		String url = tokenUrl+gzNo+"/token/get?appid="+appId+"&token="+token;
		String wxToken = null;
		try {
			String result = httpClientUtil.doGet(url);
			logger.info("getToken>>>>>>>"+result);
			if(StringUtils.isNotEmpty(result)){
				JSONObject jsonObject = JSONObject.fromObject(result);
				if(jsonObject !=null){
					Object code=jsonObject.get("code");
					if(code != null && code.toString().equals("200")){
						Object tokenResult=jsonObject.get("result");
						if(tokenResult != null){
							wxToken= tokenResult.toString();
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			return wxToken;
		}
	}

	/**
	 * 获取美店小程序的token
	 * 
	 * @return
	 */
	private String createToken() {
		HttpGet httpGet = new HttpGet();
		String params = tokenUrl + "?grant_type=" + GRANT_TYPE + "&secret=" + secret + "&appid=" + appId;
		httpGet.setURI(URI.create(params));
		String result = httpClientUtil.doGet(httpGet);
		if(result == null){
			logger.error("createToken result=={}",result);
			return null;
		}
		JSONObject resultObject = JSONObject.fromObject(result);
		// 拿到accesstoken
		Object jsonToken = resultObject.get("access_token");
		if(jsonToken == null){
			logger.error("createToken resultObject=={}",resultObject);
			return null;
		}
		String token = jsonToken.toString();
		return token;
	}
	
	/**
	 * 由节点创建token
	 */
	public void getMustToken() {
		//System.err.println(gcache.get("meidian.MinProgram.Token.flag"));
		Long flag = gcache.setnxex("meidian.MinProgram.Token.flag", 3,UUID.randomUUID().toString());
		//System.err.println(flag);
		if (flag != null && flag.longValue() == 1) {
				String newToken = createToken();
				if (newToken != null) {
					gcache.set("meidian.MinProgram.Token1", newToken);
					gcache.set("meidian.MinProgram.Token2", newToken);
				} 
		}
	}
	
	
	/**
	 * 获取国美小程序token
	 * @return
	 */
	public String getGomeToken() {
		//String gomeGzNo = "ServiceMiniprogramGome";
		String token = WeiXinMobileDES.createToken(gomeAppId, gomeSecret);
		String url = tokenUrl+gomeGzNo+"/token/get?appid="+gomeAppId+"&token="+token;
		String wxToken = null;
		try {
			String result = httpClientUtil.doGet(url);
			logger.info("getGomeToken>>>>>>>"+result);
			if(StringUtils.isNotEmpty(result)){
				JSONObject jsonObject = JSONObject.fromObject(result);
				if(jsonObject !=null){
					Object code=jsonObject.get("code");
					if(code != null && code.toString().equals("200")){
						Object tokenResult=jsonObject.get("result");
						if(tokenResult != null){
							wxToken= tokenResult.toString();
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			return wxToken;
		}
	}

}
