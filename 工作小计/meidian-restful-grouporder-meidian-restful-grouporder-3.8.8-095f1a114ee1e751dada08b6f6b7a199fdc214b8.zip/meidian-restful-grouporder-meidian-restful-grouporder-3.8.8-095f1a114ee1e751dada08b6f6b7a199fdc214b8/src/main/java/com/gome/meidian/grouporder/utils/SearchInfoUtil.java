package com.gome.meidian.grouporder.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.grouporder.vo.search.Category;
import com.gome.meidian.grouporder.vo.search.FilterCondition;
import com.gome.meidian.grouporder.vo.search.FilterValInfo;

import jodd.util.StringUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
@Component("searchInfoUtil")
public class SearchInfoUtil {
	/**
	 * 解析联想词
	 * @param result
	 * @return
	 */
	public  List<Map<String,Object>>  explain(String result){
		List<Map<String,Object>> list=null;
		if(!StringUtils.isEmpty(result)){
			list = new ArrayList<Map<String,Object>>();
			JSONArray jsonArry = JSONArray.fromObject(result);
			for (int i=0;i<jsonArry.size();i++){
				if(jsonArry.get(i)!=null){
					Map<String,Object> map=new LinkedHashMap<String,Object>();
					String oneStr=jsonArry.get(i).toString();
					//System.err.println( "==============="+jsonArry.get(i).toString());
					map.put("index", i+"");
					explain2(oneStr,map);
					list.add(map);
				}
			}
		}
		return list;
	}
	
	public  void explain2(String oneStr,Map<String,Object> map){
		if(!StringUtils.isEmpty(oneStr)){
			JSONArray jsonArryOne = JSONArray.fromObject(oneStr);
			int flag=0;
			for(int s=0;s<jsonArryOne.size();s++){
				
				if(s==0){
					map.put("keyword",jsonArryOne.get(s).toString());
					 continue;
				}else if(s==1){
					map.put("count",jsonArryOne.get(s).toString());
					 continue;
				}else if(s==2){
					if(jsonArryOne.get(s).toString().equals("0")){
						flag=0;
						 continue;
					}else if(jsonArryOne.get(s).toString().equals("1")){
						flag=1;
						 continue;
					}
				}else if(s==3){			
						if(flag==0){
							explain2_1(jsonArryOne.get(s).toString(),map);
							 continue;
						}
						if(flag==1){
							explain2_2(jsonArryOne.get(s).toString(),map);
							 continue;
						}						
				}
			}
		}
	}
	
	public  void explain2_1(String twoStr,Map<String,Object> map){
		if(!StringUtils.isEmpty(twoStr)){
			List<Map<String,String>> list= new ArrayList<Map<String,String>>();
			JSONArray jsonArryTwo = JSONArray.fromObject(twoStr);
			for(int s=0;s<jsonArryTwo.size();s++){
				Map<String,String> tagMap=new LinkedHashMap<String,String>();
				JSONArray jsonArryThree = JSONArray.fromObject(jsonArryTwo.get(s));
			   for(int n=0;n<jsonArryThree.size();n++){
				   if(n==0){
					   tagMap.put("tagName", jsonArryThree.get(n).toString());
					   continue;
				   }else if(n==2){
					   Long flag= Long.valueOf(jsonArryThree.get(n).toString());
					   if(flag!=null && flag>0){
						   tagMap.put("location", "after"); 
						   continue;
					   }else if(flag!=null && flag<0){
						   tagMap.put("location", "before"); 
						   continue;
					   }
					   
				   }
			   }
			   list.add(tagMap);
			}
			map.put("tagList", list);
		}
	}
	
	public  void explain2_2(String twoStr,Map<String,Object> map){
		if(!StringUtils.isEmpty(twoStr)){
		    Map maps = (Map)JSON.parse(twoStr);  
			if(maps!=null){
				String str=maps.get("cat").toString();
				if(!StringUtils.isEmpty(str)){
					Map<String,String> tagMap=new LinkedHashMap<String,String>();
					JSONArray jsonArryThree = JSONArray.fromObject(str);
					   String catName="";
					   for(int n=0;n<jsonArryThree.size();n++){
						   if(n==0){
							   catName=catName+jsonArryThree.get(n).toString();
							   continue;
						   }else if(n==1){
							   tagMap.put("catID", jsonArryThree.get(n).toString());
							   continue;
						   }else if(n==3){
							   catName=jsonArryThree.get(n).toString()+" > "+catName;
							   continue;
						   }
						   
					   }
					   tagMap.put("catName", catName);
						map.put("catList", tagMap);
				}
			}
		}
	}
	/**
	 * 解析类树
	 * @param category
	 * @return
	 */
	public  List<Category> getCategory(com.alibaba.fastjson.JSONObject category) {
		if (category != null) {
			Object treeObject = category.get("categoryTree");
			if (treeObject != null) {
				String categoryTree = treeObject.toString();
				if (!StringUtil.isEmpty(categoryTree)) {
					JSONArray jsonArryOne = JSONArray.fromObject(categoryTree);
					List<Category> categoryList = new ArrayList<Category>();
					for (int i = 0; i < jsonArryOne.size(); i++) {
						JSONObject one = jsonArryOne.getJSONObject(i);// 遍历一级节点
						//System.out.println(one.get("childs"));// 获取二级节点
						Object twoObject = one.get("childs");
						if (twoObject != null) {
							String twoStr = twoObject.toString();
							JSONArray jsonArryTwo = JSONArray.fromObject(twoStr);
							for(int n = 0; n < jsonArryTwo.size(); n++){
								JSONObject two = jsonArryTwo.getJSONObject(n);// 遍历二级级节点
								Category categoryTwo = new Category();
								categoryTwo.setDefaultHot(getJsonVlue(two,"default"));
								categoryTwo.setCount(getJsonVlueLong(two,"count"));
								categoryTwo.setCatName(getJsonVlue(two,"name"));
								categoryTwo.setCatId(getJsonVlue(two,"id"));

								//System.out.println(two.get("childs"));// 获取三级节点
								Object threeObject = two.get("childs");
							    if(threeObject != null){
							    	List<Category> categoryThreeList = new ArrayList<Category>();
							    	String threeStr = threeObject.toString();
							    	JSONArray jsonArryThree = JSONArray.fromObject(threeStr);
									for(int m = 0; m < jsonArryThree.size(); m++){
										JSONObject three = jsonArryThree.getJSONObject(m);// 遍历三级级节点
										Category categoryThree = new Category();
										categoryThree.setDefaultHot(getJsonVlue(three,"default"));
										categoryThree.setCount(getJsonVlueLong(three,"count"));
										categoryThree.setCatName(getJsonVlue(three,"name"));
										categoryThree.setCatId(getJsonVlue(three,"id"));
										categoryThreeList.add(categoryThree);
									}
									Collections.sort(categoryThreeList);
									categoryTwo.setCatList(categoryThreeList);
							    }
							    categoryList.add(categoryTwo);
							}
						}

					}
					 Collections.sort(categoryList);
					 return categoryList;
				}
			}

		}
		return null;
	}
	
    /**
     * 取筛选条件
     * @param facets
     * @return
     */
	public  List<FilterCondition> getFilterCondition(com.alibaba.fastjson.JSONObject facets) {
		if (facets != null) {
			List<FilterCondition> list=new ArrayList<FilterCondition>();
			Object brandObject = facets.get("brand");
			if(brandObject!=null){
				JSONObject barndJsonObject = JSONObject.fromObject(brandObject.toString());
				FilterCondition filterCondition = new FilterCondition();
				filterCondition.setFilterConId(getJsonVlue(barndJsonObject,"id"));
				filterCondition.setFilterConName(getJsonVlue(barndJsonObject,"label"));
				filterCondition.setIndex(getJsonVlue(barndJsonObject,"index"));
				filterCondition.setSortByPinyin("Y");
				Object items = barndJsonObject.get("items");
				if(items!=null){
			    	JSONArray jsonArryItem = JSONArray.fromObject(items.toString());
			    	List<FilterValInfo> filterValList = new ArrayList<FilterValInfo>();
					for(int m = 0; m < jsonArryItem.size(); m++){
						JSONObject item = jsonArryItem.getJSONObject(m);// 遍历三级级节点
						FilterValInfo filterValInfo = new FilterValInfo();
						filterValInfo.setCount(getJsonVlue(item,"count"));
						filterValInfo.setFilterVal(getJsonVlue(item,"id"));
						filterValInfo.setFilterValName(getJsonVlue(item,"value"));
						filterValInfo.setIndex(getJsonVlue(item,"index"));
						filterValInfo.setPinyin(getJsonVlue(item,"prefix"));
						filterValList.add(filterValInfo);
					}
					filterCondition.setFilterValList(filterValList);
				}
				list.add(filterCondition);
				return list;
			}
		}
		return null;
	} 
	
	
	
	private  String getJsonVlue(JSONObject jSONObject,String keyName){
		Object value=jSONObject.get(keyName);
		if(value !=null){
			return value.toString();
		}else{
			return null;
		}
	}
	
	private  Long getJsonVlueLong(JSONObject jSONObject,String keyName){
		Object value=jSONObject.get(keyName);
		Long returnValue=0L;
		if(value !=null){
			try{
				returnValue =Long.valueOf(value.toString());
			}catch(Exception e ){
				e.getStackTrace();
			}finally{
				return returnValue;
			}
		}else{
			return returnValue;
		}
	}

}
