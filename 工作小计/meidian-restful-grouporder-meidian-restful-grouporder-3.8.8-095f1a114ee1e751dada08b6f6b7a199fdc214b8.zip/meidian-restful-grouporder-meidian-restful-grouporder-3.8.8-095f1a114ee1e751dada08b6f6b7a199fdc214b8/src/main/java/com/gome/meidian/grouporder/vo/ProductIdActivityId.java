package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

import com.gome.meidian.grouporder.utils.GroupOrderVerifyGroup.groupOrderVerify;

/**
 * 618
 * 数字门店商品列表
 * @author shichangjian
 *
 */
public class ProductIdActivityId  implements Serializable{

	private static final long serialVersionUID = -605387383430764913L;
	
	private String productId;			//商品productId
	private String activityId;			//活动id
	private String ukey;				//凑单活动页ukey
	private String coupon_id;			//优惠劵规则id
	private String plan_id;				//优惠劵方案id
	private Double coupon_num;			//优惠劵面额
	private String name;				//首页-活动标题名	
	private String link_name;			//首页-副标题名
	private String skuId;				//skuId
	private String sku_no;				//skuNo
	private String rebateId;			//返利计划id
	private String couponType;			//cms配置的券类型，1为美券，2为POP券
	private Integer rebateType;          //返利类型：1-联营返利     2-自营返利
	
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getUkey() {
		return ukey;
	}
	public void setUkey(String ukey) {
		this.ukey = ukey;
	}
	public String getCoupon_id() {
		return coupon_id;
	}
	public void setCoupon_id(String coupon_id) {
		this.coupon_id = coupon_id;
	}
	public Double getCoupon_num() {
		return coupon_num;
	}
	public void setCoupon_num(Double coupon_num) {
		this.coupon_num = coupon_num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLink_name() {
		return link_name;
	}
	public void setLink_name(String link_name) {
		this.link_name = link_name;
	}
	public String getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(String plan_id) {
		this.plan_id = plan_id;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getRebateId() {
		return rebateId;
	}
	public void setRebateId(String rebateId) {
		this.rebateId = rebateId;
	}
	public String getCouponType() {
		return couponType;
	}
	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}
	public Integer getRebateType() {
		return rebateType;
	}
	public void setRebateType(Integer rebateType) {
		this.rebateType = rebateType;
	}
	public String getSku_no() {
		return sku_no;
	}
	public void setSku_no(String sku_no) {
		this.sku_no = sku_no;
	}
	
	
	
}
