package com.gome.meidian.grouporder.manager.collectFlow;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.gome.bg.interfaces.collectcustomer.bean.CollectCustomerInfoData;
import com.gome.bg.interfaces.collectcustomer.bean.CollectCustomerResult;
import com.gome.bg.interfaces.collectcustomer.bean.ReceiveActivityTicketParam;
import com.gome.bg.interfaces.collectcustomer.service.CollectCustomerTicketService;
import com.gome.loom.facade.ISendSmsFacade;
import com.gome.loom.facade.IVcodeFacade;
import com.gome.loom.model.TpModel;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.GroupOrderManager;
import com.gome.meidian.grouporder.manager.HomeProductsManager;
import com.gome.meidian.grouporder.manager.mshopUserManager.UserBasicInfoManager;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.DoubleUtils;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.ImageUtils;
import com.gome.meidian.grouporder.utils.RequestUtils;
import com.gome.meidian.grouporder.utils.StrUtils;
import com.gome.meidian.grouporder.vo.Product;
import com.gome.meidian.grouporder.vo.collectFlow.FlowActivity;
import com.gome.meidian.grouporder.vo.collectFlow.FlowCoupon;
import com.gome.meidian.grouporder.vo.collectFlow.MyCollectFlow;
import com.gome.meidian.grouporder.vo.grouporderVo.Activity;
import com.gome.meidian.grouporder.vo.grouporderVo.FlowGroup;
import com.gome.meidian.grouporder.vo.grouporderVo.Group;
import com.gome.meidian.grouporder.vo.product.MeidianPrice;
import com.gome.meidian.grouporder.vo.store.UserInfo;
import com.gome.memberCore.lang.MapResult;
import com.gome.memberCore.lang.model.Result;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.memberJikeCenter.facade.IGomeJikeOperationFacade;
import com.gome.memberJikeCenter.model.jike.GomeJikeUserBaseModel;
import com.gome.sum.client.ShortUrlDubboService;
import com.gome.sum.client.ShortUrlService;
import com.gome.sum.client.dto.BindShortUrlData;
import com.gome.sum.client.dto.BindShortUrlParam;
import com.gome.sum.client.dto.BindShortUrlResult;
import com.gome.userBase.facade.base.IUserBaseProfileFacade;
import com.gome.userCenter.facade.login.IQuickLoginFacade;
import com.gome.userCenter.model.RequestParams;
import com.gome.userCenter.model.UnifyUserInfoExt;
import com.gome.userCenter.model.UserLoginResult;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeplus.bs.interfaces.gorder.service.newGorder.GorderInfoForAppNewResource;
import com.gomeplus.bs.interfaces.gorder.vo.GroupJKInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.GroupJKOrderInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.MyGroupJKInfoVo;
import com.gomeplus.bs.interfaces.gorder.vo.MyGroupJKOrderInfoVo;

import cn.com.gome.user.service.QueryUserInfoFacade;

@Service
public class CollectFlowManager {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	private static final String tokenId = "62f42431c6dc4df7acc217ea028260e8";
	private static final int collectFlowChannel = 3;	// "1":"WAP,wap","2":"小程序,weApp","3":"美店,md_wap"
	private static final String invokeFrom = "mdWap";
	private static final String flowChannel = "md_wap";
	
	private static final String invoke = "collectCustomer";
	
	@Value("${meidian.image.agreement}")
	private String agreement;
	@Autowired
	private CollectCustomerTicketService collectCustomerTicketService;
	@Autowired
	private UserBasicInfoManager userBasicInfoManager;
	@Autowired
	private StoreManager storeManager;
	@Autowired
	private QueryUserInfoFacade queryUserInfoFacade;
	@Autowired
	private GorderInfoForAppNewResource gorderInfoForAppNewResource;
	@Autowired
	private IUserBaseProfileFacade iUserBaseProfileFacade;
	@Autowired
	private IGomeJikeOperationFacade iGomeJikeOperationFacade;
	@Autowired
	private ISendSmsFacade isendSmsFacade;
	@Autowired
	private IVcodeFacade iVcodeFacade;
	@Autowired
	private ShortUrlDubboService shortUrlDubboService;
	@Autowired
	private IQuickLoginFacade iQuickLoginFacade;
	@Autowired
	private ShortUrlService shortUrlService;
	@Value("${gome.collectFlow.couponUrl}")
	private String couponUrl;
	@Value("${gome.collectFlow.shor}")
	private String shor;
	@Value("${jike.collectFlow.redCouponPromoId}")
	private String redCouponPromoId;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private HomeProductsManager homeProductsManager;
	
	/**
	 * 获取集客信息
	 * @param flowActivityId
	 * @return
	 */
	public FlowActivity getCollectFlow(String flowActivityId){
		
		CollectCustomerInfoData collectCustomerInfoData = this.getActivityInfo(flowActivityId);
		if(null == collectCustomerInfoData) return null;
		
		String startDate = collectCustomerInfoData.getStartDate();
		String endDate = collectCustomerInfoData.getEndDate();
		long sysTime = DateUtils.currentTimeSecs(); 
		byte timeScope = 0;
		if(sysTime >= DateUtils.getLong(startDate)  && sysTime <= DateUtils.getLong(endDate))
			timeScope = 1;
		else 
			timeScope = 0;
		
		FlowActivity flowActivity = new FlowActivity(collectCustomerInfoData.getActivityId(), collectCustomerInfoData.getActivityName(), collectCustomerInfoData.getStartDate(), 
													collectCustomerInfoData.getEndDate(), collectCustomerInfoData.getCouponValue(), collectCustomerInfoData.getCouponUseDescribe(), 
													collectCustomerInfoData.getCouponUseLimit(), timeScope);
		
		return flowActivity;
	}
	
	/**
	 * 生成集客劵
	 * @param flowActivityId 集客活动id
	 * @param userId 用户id
	 * @param staffId 员工userId
	 * @return
	 */
	public byte collectFlowCoupon(String flowActivityId, String userId, String staffId, 
			String nickName, String pageCode, String mobile, 
			String vCode, String ip, Map<String, String> requestHeader){
		
		logger.info("collectFlowCoupon ==> flowActivityId=={} staffId=={} userId=={} ", flowActivityId, staffId, userId);
		byte status = 1;
		
		// 获取短信模板
		CollectCustomerInfoData collectCustomerInfoData = this.getActivityInfo(flowActivityId);
		if(null == collectCustomerInfoData) return 9;
		
		String newUserId = null;
		if(null != vCode && !vCode.equalsIgnoreCase("")){
			// 校验短信验证码
			String codeBusinessName = collectCustomerInfoData.getVerificateMsgInfo().getBusinessName();
			
			Result<Boolean> result = null;
			
			try{
				result = iVcodeFacade.checkVcode(codeBusinessName, mobile, vCode, true);
			}catch(Exception e){
				logger.error("collectFlowCoupon.iVcodeFacade.checkVcode Error ==> codeBusinessName=="+codeBusinessName+" mobile=="+mobile+" vCode=="+vCode+" userId=="+userId, e);
			    return 10;
			}
			if(result == null){
				 return 10;
			}
			// 验证码错误
			if(result.getCode() == -1003) return 10;
			// 超过验证次数
			if(result.getCode() == -1004) return 11;
			// 重新获取验证码
			if(result.getCode() == -1002) return 12;
			if(!result.isSuccess()) return 10;
			
			// 注册
			RequestParams requestParams = new RequestParams(invoke, ip, "9109", null, null, null);
			HashMap<String, Object> paramsMap = new HashMap<String, Object>();
			paramsMap.put("companyName", "gomeOnLine");
			
			UserLoginResult<UnifyUserInfoExt> userLoginResult = null;
			try{
			    userLoginResult = iQuickLoginFacade.quickLogin(mobile, invoke, requestParams, paramsMap);
			}catch(Exception e){
				logger.error("collectFlowCoupon.iQuickLoginFacade.quickLogin Error ==> mobile=="+mobile+" invoke=="+invoke+" userId=="+userId, e);
			    return 13;
			}
			
			if(null == userLoginResult) return 13;
			UnifyUserInfoExt unifyUserInfoExt = userLoginResult.getBuessObj();
			if(null == unifyUserInfoExt) return 13;
			newUserId = unifyUserInfoExt.getId();
			if(null == newUserId || newUserId.equalsIgnoreCase("")) return 13;
			logger.info("iQuickLoginFacade ==> staffId=={} userId=={} newUserId=={} mobile=={}", staffId, userId, newUserId, mobile);
		}
		
		// 2.员工编码
		// 处理组团集客发起者userId
		String jkUserId = staffId;
		
		if(null == staffId || staffId.equalsIgnoreCase("")){
			// 此人是发起者
			jkUserId = userId;
			staffId = userId;
			// 此人修改了手机号
			if(null != newUserId)
				staffId = newUserId;
		}
		
		
		long usId = Long.parseLong(staffId);
		UserInfo userInfo = this.getStaffInfo(usId);
		
		// 4.生成集客劵
		ReceiveActivityTicketParam ticketParam = new ReceiveActivityTicketParam();
		ticketParam.setActivityId(flowActivityId);
		ticketParam.setChannelType(collectFlowChannel);
		// 被集客者当前人信息
		ticketParam.setMobileNumber(mobile);
		if(null == newUserId){
			// 没有修改手机号
			ticketParam.setUserId(userId);
		}else{
			// 修改手机号
			ticketParam.setUserId(newUserId);
		}
		// 集客发起者的信息
		ticketParam.setEmployeeCode(userInfo.getStaffNo());
		ticketParam.setEmployeeName(userInfo.getStaffName());
		ticketParam.setEmployeeStoreCode(userInfo.getStoreCode());
		ticketParam.setEmployeeBranch1Code(userInfo.getStairDepartmentId());
		ticketParam.setEmployeeBranch2Code(userInfo.getSecondDepartmentId());
		ticketParam.setEmployeeRegionCode(userInfo.getBigAreaCode());
		
		CollectCustomerResult collectCustomerResult = null;
		try{
			collectCustomerResult = collectCustomerTicketService.receiveActivityTicket(tokenId, ticketParam);
		}catch(Exception e){
			logger.error("collectFlowCoupon.collectCustomerTicketService.receiveActivityTicket Error ==> tokenId=="+tokenId+" ticketParam=="+invoke+" userId=="+userId, e);
			return 4;
		}
		

		if(null == collectCustomerResult) return 4; 
		if(!collectCustomerResult.getSuccess()) return 4;
		String errCode = collectCustomerResult.getErrCode();
		if(!errCode.equalsIgnoreCase("success") && !errCode.equalsIgnoreCase("ticket_already_receive")){
			logger.error("receiveActivityTicket ==> errCode=={} errmsg={} ", errCode, collectCustomerResult.getErrMsg());
			return 4;
		}
		if(errCode.equalsIgnoreCase("ticket_already_receive")){
			logger.info("receiveActivityTicket repeatability ==> staffNo=={} userId=={} newUserId=={}", userInfo.getStaffNo(), userId, newUserId);
			status = 7;
		}
		
		// 添加到会员库
		GomeJikeUserBaseModel gomeJikeUserBaseModel = new GomeJikeUserBaseModel();
		// 被集客者
		if(null == newUserId){
			// 没有修改手机号
			gomeJikeUserBaseModel.setUserId(userId);
		}else{
			// 修改手机号
			gomeJikeUserBaseModel.setUserId(newUserId);
		}
		
		gomeJikeUserBaseModel.setMobile(mobile);
		gomeJikeUserBaseModel.setUserName(nickName);
		
		// 集客发起者
		gomeJikeUserBaseModel.setStoreCode(userInfo.getStoreCode());
		// 员工编号
		gomeJikeUserBaseModel.setStaffId(userInfo.getStaffNo());
		// 后续动态获取
		gomeJikeUserBaseModel.setJikeSrcType(3);
		gomeJikeUserBaseModel.setJikeSrcId(flowActivityId);
		gomeJikeUserBaseModel.setJikeChannel(flowChannel);
		// 后续动态获取
		gomeJikeUserBaseModel.setJikeWay(0);
		
		UserResult<String> re = null;
		try{
			re = iGomeJikeOperationFacade.saveJikeInfo(gomeJikeUserBaseModel, null, null, invokeFrom);
		}catch(Exception e ){
			logger.error("collectFlowCoupon.iGomeJikeOperationFacade.saveJikeInfo Error ==> userId=="+userId, e);
			return 4;
		}
		if(re == null ){
			return 4;
		}
		if(!re.isSuccess()) {
			logger.error("saveJikeInfo ==> errCode=={} errMsg=={} staffNo=={} userId=={} flowActivityId=={} newUserId=={}", re.getCode(), re.getMessage(), userInfo.getStaffNo(), userId, flowActivityId, newUserId);
			return 4;	
		}
		
		// 5.把集客劵信息添加到组团库第一张表
		GroupJKInfoVo groupJKInfoVo = new GroupJKInfoVo();
		groupJKInfoVo.setJkId(flowActivityId);
		// 集客发起者信息
		long jkUsId = Long.parseLong(jkUserId);
		groupJKInfoVo.setJkUserId(jkUsId);
		// 集客发起者员工编号
		UserInfo usInfo = this.getStaffInfo(jkUsId);
		groupJKInfoVo.setJkUserNum(usInfo.getStaffNo());
		
		// 被集客者
		groupJKInfoVo.setGuestUserId(Long.parseLong(userId));
		groupJKInfoVo.setGuestPhone(mobile);
		groupJKInfoVo.setGuestUserName(nickName);
		groupJKInfoVo.setPagecode(pageCode);
		
		CommonResultEntity<Boolean> commonResult = null;
		try{
			commonResult = gorderInfoForAppNewResource.insertJKInfo(groupJKInfoVo);
		}catch(Exception e){
			logger.error("collectFlowCoupon.gorderInfoForAppNewResource.insertJKInfo Error ==> userId=="+userId, e);
			return 6;
		}
		if(commonResult == null){
			return 6;
		}
		
		
		if(commonResult.getCode() == 500){
			status = 5;
			//return 5;
		} 
		
		if(commonResult.getBusinessObj() == null || !commonResult.getBusinessObj()){
			logger.error("insertJKInfo ==> flowActivityId=={} staffId=={} userId=={} newUserId=={}", flowActivityId, usId, userId, newUserId);
			return 6;
		} 
		
		//给用户领取红券
		logger.info("collectFlowCoupon.groupOrderManager.fetchRedBlueCoupon ==> redCouponPromoId=={} userId=={} ip=={} ", redCouponPromoId, userId, ip);
		Integer fetchStatus = groupOrderManager.fetchRedBlueCoupon(redCouponPromoId,userId,ip,requestHeader);
		logger.info("collectFlowCoupon.groupOrderManager.fetchRedBlueCoupon params==> redCouponPromoId=={} userId=={} ip=={} result==>  fetchStatus=={}", redCouponPromoId, userId, ip ,fetchStatus);
		if(fetchStatus != null && fetchStatus != 0){
			logger.info("collectFlowCoupon ==> after fetchRedBlueCoupon userId=={} status=={}", userId, status);
			if(status == 5 || status == 7 ){
				//上次用户已经领取过集客门票
				if(fetchStatus == 14){
					//系统异常
					//return 17;//上次用户已经领取过集客门票,自动发券异常
					status = 17;
				}else{
					//赠券失败
					//return 18;//上次用户已经领取过集客门票,自动发券失败
					status = 18;
				}
				
			}else{
				//用户之前没有领取过集客门票（本次领取成功）
				if(fetchStatus == 14){
					//系统异常
					//return 14;//用户之前没有领取过集客门票（本次领取成功,自动发券异常
					status = 14;
				}else{
					//赠券失败
					//return 16;//用户之前没有领取过集客门票（本次领取成功,自动发券失败
					status = 16;
				}
				
			}
			
		}
		

		// 发短信
        // 长url转换成短url
		Map shortUrlMap = null;
		String codeUrl = null;
		try{
			shortUrlMap = shortUrlService.bingNoQrCode(couponUrl, null, null);
	        String shortUrl = shortUrlMap.get("shortUrl").toString();
	        codeUrl = shor + "/" + shortUrl;
		}catch(Exception e){
			logger.error("collectFlowCoupon.shortUrlService.bingNoQrCode Error ==> userId=="+userId+" couponUrl=="+couponUrl, e);
			//return 15;
		}


        String receiveBusinessName = collectCustomerInfoData.getReceiveMsgInfo().getBusinessName();
        String receiveTemplateId = collectCustomerInfoData.getReceiveMsgInfo().getTemplateId();
//        if(null == receiveBusinessName || receiveBusinessName.equalsIgnoreCase("")
//        		|| null == receiveTemplateId || receiveTemplateId.equalsIgnoreCase("")) 
//        	return 9;
        
		Map<String, String> map = new HashMap<String, String>();
		map.put("ticket_url", codeUrl);
		// 发送成功返回null
		Result sendSmsResult = this.sendSmsPlatformVCode(mobile, receiveBusinessName, receiveTemplateId, map);
		if (!sendSmsResult.isSuccess()) {
			logger.error("sendSmsPlatformVCode ==> flowActivityId=={} staffId=={} userId=={} newUserId=={}",
					flowActivityId, usId, userId, newUserId);
			//return 8;
		}
		logger.info("collectFlowCoupon ==> result userId=={} status=={}", userId, status);
		return status;
	}
	
	public MyGroupJKInfoVo collectFlowCoupon(Integer pageNum, Integer pageSize, String userId, String flowActivityId){
		
		CommonResultEntity<MyGroupJKInfoVo> result = gorderInfoForAppNewResource.getJKInfoByUserIdAndJKId(pageNum, pageSize, userId, flowActivityId);
		MyGroupJKInfoVo myGroupJKInfoVo = result.getBusinessObj();
		
		return myGroupJKInfoVo;
	}
	
	/**
	 * 集客劵列表
	 * @param pageNum
	 * @param pageSize
	 * @param userId
	 * @return
	 */
	public List<FlowCoupon> collectFlowCoupons(Integer pageNum, Integer pageSize, String userId){
		
		// 1.调组团服务集客列表
		MyGroupJKInfoVo myGroupJKInfoVo = this.collectFlowCoupon(pageNum, pageSize, userId, null);
		if(null == myGroupJKInfoVo) return null;
		List<GroupJKInfoVo> groupJKInfoVos = myGroupJKInfoVo.getVoList();
		if(null == groupJKInfoVos || groupJKInfoVos.size() == 0) return null;
		List<FlowCoupon> flowCoupons = new ArrayList<FlowCoupon>();
		for (GroupJKInfoVo groupJKInfoVo : groupJKInfoVos) {
			// 2.调集客信息
			if(null == groupJKInfoVo) continue;
			String flowId = groupJKInfoVo.getJkId();
			Integer groupNum = groupJKInfoVo.getGuestAttendNum();
			if(null != groupNum){
				if(groupNum != 0) groupNum = 1;
			}else
				groupNum = 0;
			
			FlowActivity flowActivity = new FlowActivity();
			if(!StrUtils.indexContains(flowId, "vmjk", 4)){
				flowActivity = this.getCollectFlow(flowId);
				if(null == flowActivity) continue;
			}
			FlowCoupon flowCoupon = new FlowCoupon(flowId, flowActivity.getActivityName(), groupJKInfoVo.getCreateTime(), 
					(byte)groupNum.intValue(), groupJKInfoVo.getGuestPhone());
			
			flowCoupons.add(flowCoupon);
		}
		
		return flowCoupons;
	}
	
	/**
	 * 是否领取集客劵
	 * @param userId
	 * @param flowActivityId
	 * @return
	 */
	public Map<String, Object> collectFlowCoupon(String userId, String flowActivityId){
		Map<String, Object> resMap = new HashMap<String, Object>();
		MyGroupJKInfoVo myGroupJKInfoVo = this.collectFlowCoupon(1, 1, userId, flowActivityId);
		if(null == myGroupJKInfoVo 
				|| null == myGroupJKInfoVo.getVoList() 
				|| myGroupJKInfoVo.getVoList().size() == 0 
				|| null == myGroupJKInfoVo.getVoList().get(0)){
			
			resMap.put("flowGroup", 0);
			resMap.put("staffId", null);
			return resMap;
		}
		
		resMap.put("flowGroup", 1);
		GroupJKInfoVo groupJKInfoVo = myGroupJKInfoVo.getVoList().get(0);
		resMap.put("staffId", groupJKInfoVo.getJkUserId());
		return resMap;
	}
	
	/**
	 * 获取集客团
	 * @param userId
	 * @param flowActivityId
	 * @return
	 */
	public List<FlowGroup> flowGroup(String userId, String flowActivityId, String areaCode, String storeCode){
		
		CommonResultEntity<MyGroupJKOrderInfoVo> result = gorderInfoForAppNewResource.getMyGroupJKOrderInfoByUserIdAndJKId(userId, flowActivityId);
		MyGroupJKOrderInfoVo myGroupJKOrderInfoVo = result.getBusinessObj();
		if(null == myGroupJKOrderInfoVo) return null;
		List<GroupJKOrderInfoVo> groupJKOrderInfoVos = myGroupJKOrderInfoVo.getVoList();
		if(null == groupJKOrderInfoVos || groupJKOrderInfoVos.size() == 0) return null;
		
		List<FlowGroup> flowGroups = new ArrayList<FlowGroup>();
		for (GroupJKOrderInfoVo groupJKOrderInfoVo : groupJKOrderInfoVos) {
			if(null == groupJKOrderInfoVo) continue;
			
			Product product = new Product(groupJKOrderInfoVo.getProductId(), null, groupJKOrderInfoVo.getSkuImgUrl(), 
					groupJKOrderInfoVo.getSkuName(),  0L, 0, 
					groupJKOrderInfoVo.getSkuId(), null, groupJKOrderInfoVo.getWhereFrom(), 
					groupJKOrderInfoVo.getSkuNo(), null, null);
			
			if(StringUtils.isNotBlank(product.getMainImage())) {
				product.setMainImage(ImageUtils.replaceUrlProtocol(product.getMainImage(), agreement));
			}
			MeidianPrice meidianPrice = homeProductsManager.getMeidianPrice(groupJKOrderInfoVo.getProductId(), groupJKOrderInfoVo.getSkuId(), areaCode, GroupOrderConstants.MEIDIANPRICE_CHANNEL, storeCode, GroupOrderConstants.PRICE_POLICYID);
			if(null != meidianPrice) {
				Double price = Double.valueOf(meidianPrice.getMeidianPrice());
				product.setSalePrice(DoubleUtils.mul(price, 100D).longValue());
				product.setPriceKey(meidianPrice.getPriceKey());
				product.setPriceType(meidianPrice.getPriceType());
			}
			Group group = new Group(groupJKOrderInfoVo.getGroupId(), groupJKOrderInfoVo.getCurrentMemberNum(), groupJKOrderInfoVo.getIsSuccess(), 
					groupJKOrderInfoVo.getGroupStatus(), groupJKOrderInfoVo.getGroupBusType());
			
			
			Integer refund = groupJKOrderInfoVo.getFailGroupRefund();
			byte re = 0;
			if(null != refund)
				re = (byte)refund.intValue();
			
			Activity activity = new Activity();
			activity.setMaxDiscountNeedPeopleNum(groupJKOrderInfoVo.getMaxDiscountNeedPeopleNum());
			FlowGroup flowGroup = new FlowGroup(flowActivityId, groupJKOrderInfoVo.getJkUserId() == null ? null : String.valueOf(groupJKOrderInfoVo.getJkUserId()), groupJKOrderInfoVo.getBuyUserId() == null ? null : String.valueOf(groupJKOrderInfoVo.getBuyUserId()), 
					groupJKOrderInfoVo.getStId(), groupJKOrderInfoVo.getOrderId(), groupJKOrderInfoVo.getDeliveryOrderId(),
					product, group, activity,
					re, groupJKOrderInfoVo.getPagecode());
			flowGroups.add(flowGroup);
		}
		
		return flowGroups;
	}
	
	/**
	 * 我的集客
	 * @param userId
	 * @param flowActivityId
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	public List<MyCollectFlow> myCollectFlow(String userId, String flowActivityId, Integer pageNum, Integer pageSize){
		CommonResultEntity<MyGroupJKInfoVo> common = gorderInfoForAppNewResource.getMyJKInfoByJKId(pageNum, pageSize, userId, flowActivityId);
		MyGroupJKInfoVo myGroupJKInfoVo = common.getBusinessObj();
		if(null == myGroupJKInfoVo) return null;
		List<GroupJKInfoVo> groupJKInfoVos = myGroupJKInfoVo.getVoList();
		if(null == groupJKInfoVos || groupJKInfoVos.size() == 0) return null;
		
		List<MyCollectFlow> myCollectFlows = new ArrayList<MyCollectFlow>();
		for (GroupJKInfoVo groupJKInfoVo : groupJKInfoVos) {
			if(null == groupJKInfoVo) continue;
			Integer groupNum = groupJKInfoVo.getGuestAttendNum();
			if(null != groupNum){
				if(groupNum != 0) groupNum = 1;
			}else
				groupNum = 0;
			
			MyCollectFlow myCollectFlow = new MyCollectFlow(flowActivityId, groupJKInfoVo.getGuestUserName(), groupJKInfoVo.getImage(), 
					groupJKInfoVo.getGuestPhone(), (byte)groupNum.intValue(), groupJKInfoVo.getIsVerification());
			
			myCollectFlows.add(myCollectFlow);
		}
		
		return myCollectFlows;
	}
	
	/**
	 * 集客分享用户头像
	 * @param userId
	 * @return
	 */
	public String userImage(String userId){
		UserResult<String> result = iUserBaseProfileFacade.getMyHttpsImagePath(userId, "gomeShopMobile");
		if(null == result) return null;
		String userImage = result.getBuessObj();
		
		return userImage;
	}
	
	
	
	// 发送短信
	public Result sendSmsPlatformVCode(String mobileNumber, String businessName, String templateId, Map<String, String> params) {
	    TpModel tpModel = new TpModel(businessName, templateId);
	    tpModel.setPhone(mobileNumber);
	    
//        Iterator result = params.entrySet().iterator();
//        while(result.hasNext()) {
//            Entry entry = (Entry)result.next();
//            tpModel.putTempParams((String)entry.getKey(), (String)entry.getValue());
//        }
	    
	    if(null != params){
	    	for (Map.Entry<String, String> entry : params.entrySet()){
	    		tpModel.putTempParams(entry.getKey(), entry.getValue());
	    	}
	    }
	    Result res = null;
        try{
        	 res = isendSmsFacade.sendSms(tpModel);
        }catch(Exception e){
        	logger.error("sendSmsPlatformVCode.isendSmsFacade.sendSms Error ==> mobileNumber=="+mobileNumber, e);
        	res = new Result();
        	res.setSuccess(false); 
        }
	   
	
	    return res;
    }
	
	/**
	 * 获取短信模板
	 * @param activityId
	 * @return
	 */
	public CollectCustomerInfoData getActivityInfo(String activityId) {
		CollectCustomerResult<CollectCustomerInfoData> collectCustomerResult = null;
		try{
			collectCustomerResult = collectCustomerTicketService.queryActivityTicketInfo(tokenId, activityId);
		}catch (Exception e){
			logger.error("getActivityInfo.collectCustomerTicketService.queryActivityTicketInfo Error ==> tokenId=="+tokenId+" activityId=="+activityId, e);
		}
        if(null == collectCustomerResult) return null;
		if(!collectCustomerResult.getSuccess()) return null;
		CollectCustomerInfoData collectCustomerInfoData = collectCustomerResult.getData();
		if(null == collectCustomerInfoData) return null;
        
        return collectCustomerInfoData;
    }

	/**
	 * codeFlag:二维码-可为空，1-需要二维码图片，2-不需要二维码图片
	 * expireDate:过期时间-可为空,为空表示永久时间，不为空表示指定时间
	 * longUrl:需要生成短链接的源地址
	 * @param longUrl
	 * @param expireDate
	 * @param codeFlag
	 * @return
	 */
	public BindShortUrlData urlSwitch(String longUrl, Date expireDate, String codeFlag){
		BindShortUrlParam shortUrlParam = new BindShortUrlParam();
		// base64解码,java 8
		Base64.Decoder decoder = Base64.getDecoder();
		String url = null;
		try {
			url = new String(decoder.decode(longUrl), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error("urlSwitch UnsupportedEncoding == > longUrl=={}", longUrl);
		}
		shortUrlParam.setLongUrl(url);
		shortUrlParam.setExpireDate(expireDate);
		shortUrlParam.setQrCodeFlag(codeFlag);
		BindShortUrlResult<BindShortUrlData> result = shortUrlDubboService.bindShortUrl(shortUrlParam);
		if(null == result) return null;
		if(!result.getSuccess()){
			logger.error("bindShortUrl ==> errorMsg=={}", result.getErrMsg());
			return null;
		}
		
		return result.getData();
	}
	
	/**
	 * 发送验证码
	 * @param mobile
	 * @param vCode
	 * @param flowActivityId
	 * @return
	 */
	public byte sendCode(String mobile, String flowActivityId){
		byte status = 1;
		// 获取短信模板
        CollectCustomerInfoData collectCustomerInfoData = this.getActivityInfo(flowActivityId);
        if(null == collectCustomerInfoData) return 2;
        // 修改手机号验证码
        String codeBusinessName = collectCustomerInfoData.getVerificateMsgInfo().getBusinessName();
        String codeTemplateId = collectCustomerInfoData.getVerificateMsgInfo().getTemplateId();
        if(null == codeBusinessName || codeBusinessName.equalsIgnoreCase("")
        		|| null == codeTemplateId || codeTemplateId.equalsIgnoreCase("")
        		) 
        	return 2;
		
        Result res = this.sendSmsPlatformVCode(mobile, codeBusinessName, codeTemplateId, null);
        if(!res.isSuccess()) return 2;
        	
        return 1;
	}
	
	/**
	 * 添加虚拟集客活动信息
	 * @param flowActivityId
	 * @param staffId
	 * @param userId
	 * @param pageCode
	 * @return
	 */
	public byte insertVMCollectFlow(String flowActivityId, String staffId, String userId, String pageCode){
		
		// 校验是否虚拟集客
		if(!StrUtils.indexContains(flowActivityId, "vmjk", 4)) return 4;
		
		// 获取用户手机号，昵称
		Map<String, String> usMap = userBasicInfoManager.getUserInfo(userId);
		
		GroupJKInfoVo groupJKInfoVo = new GroupJKInfoVo();
		groupJKInfoVo.setJkId(flowActivityId);
		if(null == staffId || staffId.equalsIgnoreCase("")) staffId = userId;
		long jkUsId = Long.valueOf(staffId);
		groupJKInfoVo.setJkUserId(jkUsId);
		// 集客发起者员工编号
		UserInfo usInfo = this.getStaffInfo(jkUsId);
		groupJKInfoVo.setJkUserNum(usInfo.getStaffNo());
		
		// 被集客者信息
		groupJKInfoVo.setGuestUserId(Long.parseLong(userId));
		groupJKInfoVo.setGuestPhone(usMap.get("mobile"));
		groupJKInfoVo.setGuestUserName(usMap.get("nickName"));
		groupJKInfoVo.setPagecode(pageCode);
		CommonResultEntity<Boolean> commonResult = gorderInfoForAppNewResource.insertJKInfo(groupJKInfoVo);
		if(commonResult.getCode() == 500) return 2;
		if(commonResult.getBusinessObj() == null || !commonResult.getBusinessObj()){
			logger.error("insertJKInfo ==> flowActivityId=={} staffId=={} userId=={}", flowActivityId, staffId, userId);
			return 3;
		} 
		
		return 1;
	}
	
	/**
	 * 集客发起者信息
	 * @param staffId
	 * @return
	 */
	public UserInfo getStaffInfo(Long staffId){
		// 集客发起者员工编号
		UserInfo usInfo = null;
		try{
			usInfo = storeManager.getUserInfo(staffId);
		}catch(Exception e){
			logger.error("getStaffInfo.oreManager.getUserInfo Error ==> staffId=="+staffId, e);
		}
		if(null == usInfo 
				|| null == usInfo.getStaffNo() 
				|| usInfo.getStaffNo().equals("")
				){
			
			logger.info("userInfo ==> staffId=={} no staffNo", staffId);
			// 默认
			usInfo = new UserInfo();
			usInfo.setUserId(72714031977L);
			usInfo.setStaffNo("00001118");
			usInfo.setStaffName("齐鹤飞");
		}
		
		return usInfo;
	}
}
