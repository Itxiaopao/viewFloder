package com.gome.meidian.grouporder.controller.app;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.manager.app.MinProgramManager;
import com.gome.meidian.grouporder.manager.app.MinTokenManager;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@RequestMapping("/test")
public class TestToken {
	@Autowired
	private MinProgramManager minProgramManager;
	@Autowired
	private MinTokenManager minTokenManager;
	 
//	@GetMapping("/getToken")
//	public ResponseJson getToken()throws MeidianException {
//		ResponseJson response = new ResponseJson();
//		response.setData(minTokenManager.getToken());
//		return response;
//	}
//	
//	@GetMapping("/getshareCode")
//	public ResponseJson getshareCode(HttpServletRequest request,
//			HttpServletResponse response) throws ServiceException{
//		ResponseJson responseJson = new ResponseJson();
//		byte[] inputStream = minProgramManager.getshareCode("a", "",minTokenManager.getToken());
//    	try {
//	    	response.setContentType("image/png");
//	        OutputStream os = response.getOutputStream();
//	        os.write(inputStream);
//	        os.flush();
//	        os.close();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//        responseJson.setData("true");
//        return responseJson;
//	}
}
