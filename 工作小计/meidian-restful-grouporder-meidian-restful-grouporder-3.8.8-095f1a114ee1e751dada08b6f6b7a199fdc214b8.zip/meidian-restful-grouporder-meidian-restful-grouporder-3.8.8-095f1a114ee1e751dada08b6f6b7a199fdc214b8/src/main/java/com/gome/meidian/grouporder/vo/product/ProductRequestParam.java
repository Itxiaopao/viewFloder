package com.gome.meidian.grouporder.vo.product;

import java.io.Serializable;

public class ProductRequestParam implements Serializable{

	private static final long serialVersionUID = -2948308343570840724L;

	private String productId;
	private String skuId;
	
	public ProductRequestParam() {
		super();
	}
	public ProductRequestParam(String productId, String skuId) {
		super();
		this.productId = productId;
		this.skuId = skuId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	
	
}
