package com.gome.meidian.grouporder.vo.shopkeeper;

public interface ShopKeeperConf {

	boolean snapshot = true;
	
	Long userId = 100049055702L;
	
	Long bigData = 76734960055L;
	
	boolean use_gcache = false;
	
	
}
