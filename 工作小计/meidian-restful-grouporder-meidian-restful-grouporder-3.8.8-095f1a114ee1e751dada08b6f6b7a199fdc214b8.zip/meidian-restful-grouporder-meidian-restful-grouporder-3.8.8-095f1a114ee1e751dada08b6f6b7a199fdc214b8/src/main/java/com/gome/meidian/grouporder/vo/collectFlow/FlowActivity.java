package com.gome.meidian.grouporder.vo.collectFlow;

import java.io.Serializable;

/**
 * 集客活动信息
 * @author shichangjian
 *
 */
public class FlowActivity implements Serializable{

	private static final long serialVersionUID = -630935577691049658L;

	
	private String activityId;			// 活动id
	private String activityName;		// 活动名称
	private String startDate;			// 开始时间
	private String endDate;				// 结束时间
	private byte timeScope;				// 活动时间范围0：不在活动范围，1：在
	private Double couponValue;			// 优惠券面值
	private String couponUseDescribe;	// 优惠券使用描述
	private String couponUseLimit;		// 优惠券限制条件
	
	public FlowActivity() {
		super();
	}
	public FlowActivity(String activityId, String activityName, String startDate, 
						String endDate, Double couponValue, String couponUseDescribe, 
						String couponUseLimit, byte timeScope) {
		super();
		this.activityId = activityId;
		this.activityName = activityName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.couponValue = couponValue;
		this.couponUseDescribe = couponUseDescribe;
		this.couponUseLimit = couponUseLimit;
		this.timeScope = timeScope;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Double getCouponValue() {
		return couponValue;
	}
	public void setCouponValue(Double couponValue) {
		this.couponValue = couponValue;
	}
	public String getCouponUseDescribe() {
		return couponUseDescribe;
	}
	public void setCouponUseDescribe(String couponUseDescribe) {
		this.couponUseDescribe = couponUseDescribe;
	}
	public String getCouponUseLimit() {
		return couponUseLimit;
	}
	public void setCouponUseLimit(String couponUseLimit) {
		this.couponUseLimit = couponUseLimit;
	}
	public byte getTimeScope() {
		return timeScope;
	}
	public void setTimeScope(byte timeScope) {
		this.timeScope = timeScope;
	}
		
		
		
}
