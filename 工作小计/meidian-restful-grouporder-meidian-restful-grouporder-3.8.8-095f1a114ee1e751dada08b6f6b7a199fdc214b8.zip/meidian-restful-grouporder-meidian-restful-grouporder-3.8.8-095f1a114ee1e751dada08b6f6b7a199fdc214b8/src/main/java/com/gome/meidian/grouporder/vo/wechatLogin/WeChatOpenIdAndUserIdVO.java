package com.gome.meidian.grouporder.vo.wechatLogin;

import java.io.Serializable;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/10 16:19
 * @Description
 */
public class WeChatOpenIdAndUserIdVO implements Serializable {

    private static final long serialVersionUID = -2681888600870066977L;

    private String  openid;//微信号-服务号对应关系
    private String  unionid;//会员unionId对应关系
    private String  user_id;//用户id
    private String  user_name;//用户名称
    private  Long   dyn_user_id;//用户id
    private String  dyn_user_confirm;//
    private String  platForm;//ServiceMshop


    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getUnionid() {
        return unionid;
    }

    public void setUnionid(String unionid) {
        this.unionid = unionid;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public Long getDyn_user_id() {
        return dyn_user_id;
    }

    public void setDyn_user_id(Long dyn_user_id) {
        this.dyn_user_id = dyn_user_id;
    }

    public String getDyn_user_confirm() {
        return dyn_user_confirm;
    }

    public void setDyn_user_confirm(String dyn_user_confirm) {
        this.dyn_user_confirm = dyn_user_confirm;
    }

    public String getPlatForm() {
        return platForm;
    }

    public void setPlatForm(String platForm) {
        this.platForm = platForm;
    }


    @Override
    public String toString() {
        return "WeChatOpenIdAndUserIdVO{" +
                "openId='" + openid + '\'' +
                ", unionid='" + unionid + '\'' +
                ", user_id='" + user_id + '\'' +
                ", user_name='" + user_name + '\'' +
                ", dyn_user_id='" + dyn_user_id + '\'' +
                ", dyn_user_confirm='" + dyn_user_confirm + '\'' +
                ", platForm='" + platForm + '\'' +
                '}';
    }
}
