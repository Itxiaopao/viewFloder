package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;
import com.gomeplus.bs.interfaces.gorder.vo.ProductInfoVo;

/**
 * 团信息
 * @author shichangjian
 *
 */
public class GroupInfomationVo implements Serializable  {

	private static final long serialVersionUID = -2283388403693463819L;
	private Long id; 
	private Long activityId; 
	private Integer status;
	private Date startTime; 
	private Date endTime; 
	private String productId; 
	private Long  headerUserId;
	private Float  currentDiscount;
	private Float  nextDiscount;
	private Integer  nextDtNeedPeopleNum;
	private Float maxDiscount=(float) 0;
	private Float miniDiscount=(float) 0;
	private Integer miniDiscountNeedPeopleNum;
	private Integer maxDiscountNeedPeopleNum;
	private Double  totalSave;
	private Integer stepsNum; 
	private List<StepsConfig> stepsConfigs; 
	private Integer buyNumber; 
	private List<GroupUserInfo> groupUser; 
	private ProductInfoVo  ProductInfo;
	private Integer currentMemberNum; 	//团成员人数
	private Integer groupBusType; 		//组团业务类型：1:常规返利,2:团长免单,3:0元团,4:开团有奖,5:官方多人团,6:5折开团,7:定金团,8:阶梯优惠团,9:新人团,10:秒杀团
	private Integer modeType;			//模式类型  0:参团,1:开团
	
	public GroupInfomationVo() {
		super();
	}
	public GroupInfomationVo(Long id, Long activityId, Integer status, Date startTime, Date endTime, String productId,
			Long headerUserId, Float currentDiscount, Float nextDiscount, Integer nextDtNeedPeopleNum,
			Float maxDiscount, Float miniDiscount, Integer miniDiscountNeedPeopleNum, Integer maxDiscountNeedPeopleNum,
			Double totalSave, Integer stepsNum, List<StepsConfig> stepsConfigs, Integer buyNumber,
			List<GroupUserInfo> groupUser, ProductInfoVo productInfo, Integer currentMemberNum, Integer groupBusType,
			Integer modeType
			) {
		super();
		this.id = id;
		this.activityId = activityId;
		this.status = status;
		this.startTime = startTime;
		this.endTime = endTime;
		this.productId = productId;
		this.headerUserId = headerUserId;
		this.currentDiscount = currentDiscount;
		this.nextDiscount = nextDiscount;
		this.nextDtNeedPeopleNum = nextDtNeedPeopleNum;
		this.maxDiscount = maxDiscount;
		this.miniDiscount = miniDiscount;
		this.miniDiscountNeedPeopleNum = miniDiscountNeedPeopleNum;
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
		this.totalSave = totalSave;
		this.stepsNum = stepsNum;
		this.stepsConfigs = stepsConfigs;
		this.buyNumber = buyNumber;
		this.groupUser = groupUser;
		this.currentMemberNum = currentMemberNum;
		this.groupBusType = groupBusType;
		ProductInfo = productInfo;
		this.modeType = modeType;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public Long getHeaderUserId() {
		return headerUserId;
	}
	public void setHeaderUserId(Long headerUserId) {
		this.headerUserId = headerUserId;
	}
	public Float getCurrentDiscount() {
		return currentDiscount;
	}
	public void setCurrentDiscount(Float currentDiscount) {
		this.currentDiscount = currentDiscount;
	}
	public Float getNextDiscount() {
		return nextDiscount;
	}
	public void setNextDiscount(Float nextDiscount) {
		this.nextDiscount = nextDiscount;
	}
	public Integer getNextDtNeedPeopleNum() {
		return nextDtNeedPeopleNum;
	}
	public void setNextDtNeedPeopleNum(Integer nextDtNeedPeopleNum) {
		this.nextDtNeedPeopleNum = nextDtNeedPeopleNum;
	}
	public Float getMaxDiscount() {
		return maxDiscount;
	}
	public void setMaxDiscount(Float maxDiscount) {
		this.maxDiscount = maxDiscount;
	}
	public Float getMiniDiscount() {
		return miniDiscount;
	}
	public void setMiniDiscount(Float miniDiscount) {
		this.miniDiscount = miniDiscount;
	}
	public Integer getMiniDiscountNeedPeopleNum() {
		return miniDiscountNeedPeopleNum;
	}
	public void setMiniDiscountNeedPeopleNum(Integer miniDiscountNeedPeopleNum) {
		this.miniDiscountNeedPeopleNum = miniDiscountNeedPeopleNum;
	}
	public Integer getMaxDiscountNeedPeopleNum() {
		return maxDiscountNeedPeopleNum;
	}
	public void setMaxDiscountNeedPeopleNum(Integer maxDiscountNeedPeopleNum) {
		this.maxDiscountNeedPeopleNum = maxDiscountNeedPeopleNum;
	}
	public Double getTotalSave() {
		return totalSave;
	}
	public void setTotalSave(Double totalSave) {
		this.totalSave = totalSave;
	}
	public Integer getStepsNum() {
		return stepsNum;
	}
	public void setStepsNum(Integer stepsNum) {
		this.stepsNum = stepsNum;
	}
	public List<StepsConfig> getStepsConfigs() {
		return stepsConfigs;
	}
	public void setStepsConfigs(List<StepsConfig> stepsConfigs) {
		this.stepsConfigs = stepsConfigs;
	}
	public Integer getBuyNumber() {
		return buyNumber;
	}
	public void setBuyNumber(Integer buyNumber) {
		this.buyNumber = buyNumber;
	}
	public List<GroupUserInfo> getGroupUser() {
		return groupUser;
	}
	public void setGroupUser(List<GroupUserInfo> groupUser) {
		this.groupUser = groupUser;
	}
	public ProductInfoVo getProductInfo() {
		return ProductInfo;
	}
	public void setProductInfo(ProductInfoVo productInfo) {
		ProductInfo = productInfo;
	}
	public Integer getCurrentMemberNum() {
		return currentMemberNum;
	}
	public void setCurrentMemberNum(Integer currentMemberNum) {
		this.currentMemberNum = currentMemberNum;
	}
	public Integer getGroupBusType() {
		return groupBusType;
	}
	public void setGroupBusType(Integer groupBusType) {
		this.groupBusType = groupBusType;
	}
	public Integer getModeType() {
		return modeType;
	}
	public void setModeType(Integer modeType) {
		this.modeType = modeType;
	} 
	
	
}
