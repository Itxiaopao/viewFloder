package com.gome.meidian.grouporder.manager;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gome.meidian.grouporder.vo.PriceConditionVo;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.rpc.base.RequestDTO;
import com.gome.rpc.base.ResponseDTO;
import com.gome.stage.bean.price.Condition;
import com.gome.stage.bean.price.GomeUnifiedPrice;
import com.gome.stage.bean.price.PriceParam;
import com.gome.stage.interfaces.price.IGomeUnifiedPriceService;

/**
 * 价格统一封装
 * @Description 
 *
 * @author 
 *
 */
@Service
public class PriceManager {
	private static final Logger logger = LoggerFactory.getLogger(PriceManager.class);
	@Autowired
	private IGomeUnifiedPriceService iGomeUnifiedPriceService;
	
	
	/**
	 * @Description 单个sku价格
	 * @version 
	 *
	 * @param areaCode  区域码
	 * @param mOrg 经营组织，可以是销售组织，也可以是门店
	 * @param policyId 策略ID
	 * @param skuId 
	 * @param num 请求数量，默认1
	 * @return
	 */
	public GomeUnifiedPrice getPrice(PriceConditionVo condition){
		GomeUnifiedPrice priceResult = null;
		if(null == condition || StringUtils.isBlank(condition.getSkuId())) {
			return priceResult;
		}
		
		RequestDTO<PriceParam> dtoParam = new RequestDTO<>();
		dtoParam.setBody(this.convert(condition));
		
		try {

			ResponseDTO<GomeUnifiedPrice> priceRes = iGomeUnifiedPriceService.getPrice(dtoParam);
			if(null != priceRes && priceRes.getSuccess()) {
				priceResult = priceRes.getBody();
			}
		}catch(Exception e) {
			logger.error("Getting an exception during querying product price, skuId:{}  exception:{}", condition.getSkuId(), e);
			if(logger.isDebugEnabled()) {
				logger.debug("Getting an exception during querying product price, skuId:{}  exception:{}", condition.getSkuId(), e);
			}
			return priceResult;
		}
		return priceResult;
	}

	/**
	 * 
	 * @Description 多个sku价格(带请求数量)
	 * @version 
	 *
	 * @param areaCode  区域码
	 * @param mOrg 经营组织，可以是销售组织，也可以是门店
	 * @param policyId 策略ID
	 * @param skus  key为skuId，value为请求数量，默认1
	 * @return
	 */
	public List<GomeUnifiedPrice> getPrice(List<PriceConditionVo> conditionList){
		List<GomeUnifiedPrice> priceResultList = new ArrayList<>();
		if(null == conditionList || conditionList.isEmpty()) {
			return priceResultList;
		}
		
		RequestDTO<List<PriceParam>> dtoParam = new RequestDTO<>();
		List<PriceParam> priceParamList = new ArrayList<>();
		
		for(PriceConditionVo condition: conditionList) {
			if(null != condition) {
				priceParamList.add(this.convert(condition));
			}
		}
		
		if(priceParamList.isEmpty()) {
			return priceResultList;
		}
		
		dtoParam.setBody(priceParamList);
		
		try {

			ResponseDTO<List<GomeUnifiedPrice>> priceRes = iGomeUnifiedPriceService.listPrice(dtoParam);
			if(null != priceRes && priceRes.getSuccess()) {
				priceResultList = priceRes.getBody();
			}
		}catch(Exception e) {
			logger.error("Getting an exception during querying product prices, exception:{}", e);
			if(logger.isDebugEnabled()) {
				logger.debug("Getting an exception during querying product prices, exception:{}", e);
			}
			return priceResultList;
		}
		return priceResultList;
	}

	
	private PriceParam convert(PriceConditionVo condition) {
		PriceParam priceParam = new PriceParam();
		Condition conParam = new Condition();
		//取出价格所用storeCode  areaCode
		conParam.setAreaCode(MeidianEnvironment.getKey("priceReqAreaCode"));
		conParam.setmOrg(MeidianEnvironment.getKey("priceReqStoreCode"));
		
		conParam.setChannel(condition.getChannel());
		conParam.setProductId(condition.getProductId());
		
		if(null == condition.getNum() || condition.getNum() < 1) {
			conParam.setNum(1);
		}else {
			conParam.setNum(condition.getNum());
		}
		
		priceParam.setCondition(conParam);
		priceParam.setSkuId(condition.getSkuId());
		priceParam.setPolicyId(condition.getPolicyId());
		
		return priceParam;
	}
}
