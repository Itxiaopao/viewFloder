package com.gome.meidian.grouporder.vo.coupon;

import java.io.Serializable;

import com.gome.meidian.grouporder.vo.Coupon;
import com.gome.meidian.grouporder.vo.grouporderVo.SkuEnergyAllowanceVo;

/**
 * 单品领劵中间页
 * @author shichangjian
 *
 */
public class CouponMiddleOne implements Serializable{

	private static final long serialVersionUID = 2147956086238430844L;

	private String productId;		// 商品productId
	private String skuId;			// 商品skuId
	private String skuNo;			// 商品skuNo
	private String name;			// 商品名称
	private String productImage;	// 商品图
	private Integer productTag;		// 自营联营标识  1自营  2联营
	private Double price;			// 价格
	private Integer productStatus;	// 商品状态  1上架  -1 下架
	private String shopId;			// 联营pop商铺id
	private Double brokerage;		// 佣金
	private Double couponPrice;		// 券后价
	private Coupon coupon;			// 优惠券信息
	private Integer warranty;		// 延保
	
	public CouponMiddleOne() {
		super();
	}
	public CouponMiddleOne(
			String productId, String skuId, String name, 
			String productImage, Integer productTag, Double price, 
			Integer productStatus, String shopId
			) {
		super();
		this.productId = productId;
		this.skuId = skuId;
		this.name = name;
		this.productImage = productImage;
		this.productTag = productTag;
		this.price = price;
		this.productStatus = productStatus;
		this.shopId = shopId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getSkuNo() {
		return skuNo;
	}
	public void setSkuNo(String skuNo) {
		this.skuNo = skuNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public Integer getProductTag() {
		return productTag;
	}
	public void setProductTag(Integer productTag) {
		this.productTag = productTag;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Integer getProductStatus() {
		return productStatus;
	}
	public void setProductStatus(Integer productStatus) {
		this.productStatus = productStatus;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}
	public Double getBrokerage() {
		return brokerage;
	}
	public void setBrokerage(Double brokerage) {
		this.brokerage = brokerage;
	}
	public Double getCouponPrice() {
		return couponPrice;
	}
	public void setCouponPrice(Double couponPrice) {
		this.couponPrice = couponPrice;
	}
	public Coupon getCoupon() {
		return coupon;
	}
	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}
	public Integer getWarranty() {
		return warranty;
	}
	public void setWarranty(Integer warranty) {
		this.warranty = warranty;
	}
	
	
}
