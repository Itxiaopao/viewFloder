package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

public class CmsAvtivityPage implements Serializable{

	private static final long serialVersionUID = 27376100899475757L;

	private Slot slot;
	private List<CmsStoreVo> list;
	
	public Slot getSlot() {
		return slot;
	}
	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	public List<CmsStoreVo> getList() {
		return list;
	}
	public void setList(List<CmsStoreVo> list) {
		this.list = list;
	}
	
	
}
