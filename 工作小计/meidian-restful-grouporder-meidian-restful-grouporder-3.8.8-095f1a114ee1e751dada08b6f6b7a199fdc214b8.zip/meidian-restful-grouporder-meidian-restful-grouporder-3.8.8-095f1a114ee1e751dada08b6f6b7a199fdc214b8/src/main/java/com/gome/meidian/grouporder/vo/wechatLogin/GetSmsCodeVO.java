package com.gome.meidian.grouporder.vo.wechatLogin;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.constraints.Pattern;
import java.io.Serializable;

/**
 * @Author yuliang-ds1
 * @Date 2018/12/12 11:21
 * @Description
 */
public class GetSmsCodeVO  implements Serializable {

    private static final long serialVersionUID = -2681888600870066977L;

    @NotBlank(message = "{param.error}")
    @Pattern(regexp = "^1[0-9][0-9]{9}$", message = "手机号码格式错误")
    private  String mobile;


    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }


    @Override
    public String toString() {
        return "GetSmsCodeVO{" +
                "mobile='" + mobile + '\'' +
                '}';
    }
}
