package com.gome.meidian.grouporder.common;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dingxianginc.ctu.client.CaptchaClient;
import com.dingxianginc.ctu.client.model.CaptchaResponse;
import com.gome.architect.risk.dto.ExtKeyEnum;
import com.gome.architect.risk.dto.RequestV2;
import com.gome.architect.risk.dto.ResponseV2;
import com.gome.architect.risk.dto.ResultV2;
import com.gome.architect.risk.service.IRiskService;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.RequestUtils;
import com.gome.meidian.grouporder.vo.mshopUserVo.CommonVariableVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.meidian.restfulcommon.utils.StringUtils;

/**
 * 风控相关
 */
@Service
public class MeidianRiskService {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private IRiskService riskService;

	//wap美店登录
	public static final String BIZNO_LOGIN="WapMeidianLogin";
	//wap美店注册
	public static final String BIZNO_REGISTER="WapMeidianRegister";
	//wap美店短信防刷--弃用
	public static final String BIZNO_SMS="WapMeidianSmsRisk";
	//wap美店登录短信防刷
	public static final String BIZNO_SMS_LOGIN="WapMeidianLoginSms";
	//wap美店注册短信防刷
	public static final String BIZNO_SMS_REGISTER="WapMeidianRegisterSms";
	//  wap美店手机号
	public static final String BIZNO_SMS_MOBILE="WapMeidianMobileSms";




	//请求头 Referer
	public static final String REQUEST_HEADER_REFER="Referer";
	//请求头 Cookie
	public static final String REQUEST_HEADER_COOKIE="Cookie";
	//请求头 UA
	public static final String REQUEST_HEADER_UA="User-Agent";




	//风控统一接口
	/**
	 *  bizNo 必填 业务场景号 每一个场景（活动、注册、哦登录）都单独分配一个bizNo 并区分pc端wap端app
	 *  场景号
	 *  WapMeidianLogin     wap美店登录
	 *  WapMeidianRegister  wap美店注册
	 *  WapMeidianSmsRisk   wap美店短信防刷
	 *  userId必填 用户ID
	 *  ufpd  必填 设备指纹
	 *  ip    必填 需要客户端外网ip
	 *  phone 选填 电话
	 *  bizNo 必传
	 *  userId必传
	 *  ufpd必传
	 *  ip必传
	 *  phone注册必传、登录有则传，没有可以不传
	 *  Map<ExtKeyEnum, String> extensionField 扩展字段需要填写字段
	 *  EMAIL("email"), // 用户邮箱
	 *  REFER("refer"), // http请求中上一跳地址 必传
	 *  UA("ua"), // http请求中userAgent 必传
	 *  COOKIE("cookie"), // http请求中cookie信息 必传
	 *  PROMOTION_ID("promotionId"), // 促销id
	 *  COUPON_TYPE("couponType"), // 券类型 eg:99-10
	 *  COUPON_FACE_VALUE("couponFaceValue"), // 券面值  eg:10
	 *  ORDER("order"), // 下单信息，json格式
	 *  RECEIVER_INFO("receiverInfo"), // 下单收货人信息，json格式
	 *  PRODUCTS("products"), // 下单商品信息，json格式（json数组）
	 *  LOGIN_NAME("loginName"),//登录名称 必传
	 *  NICK_NAME("nickName"),//用户昵称 必传
	 *  NOTE("note");//风控v1接口中parameters字段内容 必传
	 *
	 */
	public ResultV2<ResponseV2> predict(RequestV2 requestV2) throws MeidianException {
		return riskService.predict(requestV2);
	}




	/**
	 * 获取IP
	 * @param request
	 * @return
	 */
	public static String getIP(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (!StringUtils.isEmpty(ip) && ip.indexOf(",") != -1) {
			String[] ips = ip.split(",");
			if (ips.length > 1) {
				return ips[0];
			}
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}

	/**
	 * 获取请求端口
	 * @param request
	 * @return
	 */
	public static String getPort(HttpServletRequest request) {
		Integer port = request.getLocalPort();
		return port.toString();
	}

    @Autowired
    private IRiskService iriskService;

    /**
     * 风控统一接口
     * bizNo 必填 业务场景号 每一个场景（活动、注册、哦登录）都单独分配一个bizNo 并区分pc端wap端app
     * 场景号
     * WapMeidianLogin     wap美店登录
     * WapMeidianRegister  wap美店注册
     * WapMeidianSmsRisk   wap美店短信防刷
     * userId必填 用户ID
     * ufpd  必填 设备指纹
     * ip    必填 需要客户端外网ip
     * phone 选填 电话
     * bizNo 必传
     * userId必传
     * ufpd必传
     * ip必传
     * phone注册必传、登录有则传，没有可以不传
     * Map<ExtKeyEnum, String> extensionField 扩展字段需要填写字段
     * EMAIL("email"), // 用户邮箱
     * REFER("refer"), // http请求中上一跳地址 必传
     * UA("ua"), // http请求中userAgent 必传
     * COOKIE("cookie"), // http请求中cookie信息 必传
     * PROMOTION_ID("promotionId"), // 促销id
     * COUPON_TYPE("couponType"), // 券类型 eg:99-10
     * COUPON_FACE_VALUE("couponFaceValue"), // 券面值  eg:10
     * ORDER("order"), // 下单信息，json格式
     * RECEIVER_INFO("receiverInfo"), // 下单收货人信息，json格式
     * PRODUCTS("products"), // 下单商品信息，json格式（json数组）
     * LOGIN_NAME("loginName"),//登录名称 必传
     * NICK_NAME("nickName"),//用户昵称 必传
     * NOTE("note");//风控v1接口中parameters字段内容 必传
     */
    public void predict(RequestV2 requestV2,HttpServletRequest request) throws MeidianException {
    	// 获取UFPD设备指纹信息
		String ufpd = null;
		Cookie[] cookies = request.getCookies();
		if(cookies!=null){
			for (Cookie ck : cookies) {
				if ("ufpd".equals(ck.getName())) {
					ufpd = ck.getValue();
				}
			}
		}
		String ip = RequestUtils.getIP(request);
		//扩展字段
		Map<ExtKeyEnum, String> extensionField = new HashMap<>();
		String refer = request.getHeader("Referer");
		String userAgent = request.getHeader("User-Agent");
		String cookie = request.getHeader("cookie");
		//参数排空
		if (StringUtils.isBlank(requestV2.getBizNo()) || 
				StringUtils.isBlank(ufpd) || StringUtils.isBlank(ip) || 
				StringUtils.isBlank(refer) || StringUtils.isBlank(userAgent) || StringUtils.isBlank(cookie)) {
			logger.info("领券风控验证请求参数不能为空-ip:{},ufpd:{},bizNo:{},cookie:{}",ip,ufpd,requestV2.getBizNo(),cookie);
			throw new ServiceException("base.risk.param.notBlank");
		}
		//封装参数
		requestV2.setUfpd(ufpd);
		requestV2.setIp(ip);
		extensionField.put(ExtKeyEnum.REFER, refer);
		extensionField.put(ExtKeyEnum.UA, userAgent);
		extensionField.put(ExtKeyEnum.COOKIE, cookie);
		requestV2.setExtensionField(extensionField);
		//请求风控接口
		ResultV2<ResponseV2> resultV2=null;
		try {
			 resultV2 = iriskService.predict(requestV2);
		} catch (Exception e) {
			throw new ServiceException("base.risk.exception");
		}
		if (resultV2 != null) {
			switch (resultV2.getCode()) {
				case 200:
					logger.info("风控验证通过---userId:{}", requestV2.getUserId());
					break;
				case 400:
					logger.info("风控验证参数错误---userId:{}，message:{}", requestV2.getUserId(), resultV2.getDescription());
					throw new ServiceException("base.risk.result.values");
				case 201:
					logger.info("风控验证拦截---userId:{}，message:{}", requestV2.getUserId(), resultV2.getDescription());
					throw new ServiceException("base.risk.result.fail");
				case 500:
					logger.info("风控验证异常---userId:{}，message:{}", requestV2.getUserId(), resultV2.getDescription());
					break;
			}
		}

    }

    /**
     * 滑块验证
     * 构造入参为appId和appSecret
     * appId和前端验证码的appId保持一致，appId可公开
     * appSecret为秘钥，请勿公开
     * token在前端完成验证后可以获取到，随业务请求发送到后台，token有效期为两分钟
     * @param token 前端生成token
     * @return
     */
    @SuppressWarnings("rawtypes")
	public ResponseJson sliderVal(String token) throws MeidianException{
        ResponseJson responseJson = new ResponseJson();
        String appId = CommonVariableVo.appid;
        String appSecret = CommonVariableVo.appsecret;
        CaptchaClient captchaClient = new CaptchaClient(appId, appSecret);
        //captchaClient.setCaptchaUrl(captchaUrl);
        //特殊情况需要额外指定服务器,可以在这个指定，默认情况下不需要设置
        //确保验证状态是SERVER_SUCCESS，SDK中有容错机制，在网络出现异常的情况会返回通过
		try {
			CaptchaResponse response = captchaClient.verifyToken(token);
			if (response.getResult()) {
				/**token验证通过，继续其他流程**/
				responseJson.setCode(0);
				responseJson.setMsg("验证通过");
			} else {
				responseJson.setCode(70201);
				responseJson.setMsg("滑块验证失败");
			}
		} catch (Exception e) {
			throw new ServiceException("base.risk.slider.exception");
		}
        return responseJson;
    }
    
}
