package com.gome.meidian.grouporder.aop;


import java.util.List;


import org.apache.commons.lang3.ArrayUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.config.PropertiesConfig;
import com.gome.meidian.grouporder.manager.store.StoreManager;
import com.gome.meidian.grouporder.utils.GroupOrderConstants;
import com.gome.meidian.grouporder.utils.LogUtils;
import com.gome.meidian.grouporder.utils.PriceReqUtils;
import com.gome.meidian.grouporder.vo.store.Store;
import com.gome.meidian.restfulcommon.utils.JSONUtils;
import com.gome.meidian.restfulcommon.utils.MeidianEnvironment;
import com.gome.memberCore.lang.model.UserResult;
import com.gome.userBase.facade.staff.IGomeStaffInfoFacade;
import com.gome.userBase.model.staff.GomeStaffInfo;



@Aspect
@Component
@Order(2)  
public class StorePriceAOP {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private final static Integer storeType = 0;

	@Autowired
	private IGomeStaffInfoFacade iGomeStaffInfoFacade;
	@Autowired
	private StoreManager storeManager;
	@Autowired
	private PropertiesConfig propertiesConfig;

	
	// 切入点
	@Pointcut("execution(* com.gome.meidian.grouporder.controller..*.*(..)) && @annotation(com.gome.meidian.grouporder.aop.MDStorePriceAnnotation)")
    public void franchised(){}  
    
	// 前置增强
	@Before("franchised()")
    public void franchisedShopInfo(JoinPoint joinPoint) throws MeidianException{
		
        // 端(cookie取值)
        String channel = MeidianEnvironment.getChannel();
		// 被分享人当前定位二级区域或手动选择门店(cookie取值)
        String areaCode = MeidianEnvironment.getAeaCode();
		// 被分享人当前定位三级区域(cookie取值)
        String countyAreaCode = MeidianEnvironment.getCountyAreaCode();
		// 被分享人当前定位门店或手动切换门店(cookie取值)
        String storeCode = MeidianEnvironment.getStoreCode();
		// 被分享人经度(cookie取值)
        String log = MeidianEnvironment.getLongitude();
		// 被分享人纬度(cookie取值)
        String lat = MeidianEnvironment.getLaitude();
		// 分享人userId
        String shareUserId = MeidianEnvironment.getShareUserId();
		// 当前用户切换门店
        String switchingStore = MeidianEnvironment.getSwitchingStore();
		  
		Object retVal = null;
        MethodSignature methodSignature = (MethodSignature) joinPoint.getSignature();
        String[] parameterNames = methodSignature.getParameterNames();

        // 1.获取参数的下标
        int urlAreaIndex = ArrayUtils.indexOf(parameterNames, "areaCode");
//        // 取价入参封装
//        int priceReqUtilsIndex = ArrayUtils.indexOf(parameterNames, "priceReqUtils");
        
        // 2.处理参数
        Object[] args = joinPoint.getArgs();
        PriceReqUtils priceReqUtils = null;
        String urlArea = null;	
        if(urlAreaIndex >= 0 && null != args[urlAreaIndex])
        	urlArea = String.valueOf(args[urlAreaIndex]);
        
        
        
        
        String countyCode = null;
        // 3.加盟店价格只在wap端展示，不是wap端取美店专享价逻辑
        if(null != channel && channel.equals(GroupOrderConstants.CHANNEL_WAP)){
    		// 通过shareUserId是否空值判断是否分享
    		if(null != shareUserId && !shareUserId.equals("")){
    			// 判断是否切换门店，null和！= 1是没有切换，等于1是切换门店
    			if(null == switchingStore || !switchingStore.equals("1")){
    				// 判断被分享人是否开启定位权限
    	        	if(null != countyAreaCode && !countyAreaCode.equals("")){
        				// 获取分享人门店缓存信息
        				Store cacheStore = JSONObject.parseObject(propertiesConfig.getGcache().hget("shareStoreDetail", shareUserId), Store.class);
        				if(null != cacheStore){
        					countyCode = cacheStore.getCountyCode();
    						if(null != countyCode){
    							// 6. 匹配分享人和被分享人的三级区域
    							if(countyAreaCode.equals(countyCode)){
    								priceReqUtils = new PriceReqUtils(cacheStore.getStoreCode(), cacheStore.getCityCode());
    							}else{
    								// 自然流量，判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
    								priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
    							}
    						}else{
    							// 自然流量，判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
								priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
    						}
        				}else{
        					// 4.根据分享人userId获取门店信息，判断是否是门店员工,如果是，获取门店归属三级区域码
        					UserResult<GomeStaffInfo> userResult = iGomeStaffInfoFacade.getStaffInfoByUserId(shareUserId, GroupOrderConstants.USER_SHOP_INVOKEFROM);
        					if(null != userResult && null != userResult.getBuessObj()){
        						GomeStaffInfo gomeStaffInfo = userResult.getBuessObj();
        						String shareStoreCode = gomeStaffInfo.getStoreNo();
        						boolean shareStoreStaff = gomeStaffInfo.isStoreStaff();
        						// 是门店员工取门店价，不是门店员工取美店专享价
        						if(shareStoreStaff){
        							// 5.获取分享人门店归属三级区域
        							Store store = null;
        							try {
        								store = storeManager.getStoreInfo(shareStoreCode, storeType, null, null);
        							} catch (ServiceException e) {
        								// TODO Auto-generated catch block
        								e.printStackTrace();
        							}
        							countyCode = store.getCountyCode();
        							if(null != countyCode){
        								// 6. 匹配分享人和被分享人的三级区域
        								if(countyAreaCode.equals(countyCode)){
        									priceReqUtils = new PriceReqUtils(shareStoreCode, store.getCityCode());
        									
        									// 缓存分享人的归属门店信息
        									propertiesConfig.getGcache().hset("shareStoreDetail", shareUserId, JSONUtils.toJSONString(store).getBytes());
        								}else{
        									// 自然流量，先判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
        									priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
        								}
        							}else{
        								// 走自然流量，先判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
            							priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
        							}
        						}else{
        							// 分享人不是门店员工，走自然流量，先判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
        							priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
        						}
        					}else{
        						// 不能获取分享人信息，走自然流量，先判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
        						priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
        					}
        				}
        				
        			}else{
        				// 默认
        				priceReqUtils = new PriceReqUtils(propertiesConfig.getDefaultStoreCode(), propertiesConfig.getDefaultAreaCode());
        			}
        		}else{
        			// 使用前端传的门店和二级区域,注意：避免用户手动选择门店与区域不匹配
					Store store = storeManager.getStoreInfo(storeCode, storeType, null, null);
					if(null != store)
						priceReqUtils = new PriceReqUtils(storeCode, store.getCityCode());
					else
						// 默认
        				priceReqUtils = new PriceReqUtils(propertiesConfig.getDefaultStoreCode(), propertiesConfig.getDefaultAreaCode());
        		}
        	}else{
        		// 先判断是否切换门店，再判断是否开启定位，没有走默认。
        		if(null != switchingStore && switchingStore.equals("1")){
        			// 使用前端传的门店和二级区域,注意：避免用户手动选择门店与区域不匹配,要查询门店所在区域。
					Store store = storeManager.getStoreInfo(storeCode, storeType, null, null);
					if(null != store)
						priceReqUtils = new PriceReqUtils(storeCode, store.getCityCode());
					else
						// 默认
        				priceReqUtils = new PriceReqUtils(propertiesConfig.getDefaultStoreCode(), propertiesConfig.getDefaultAreaCode());
        		}else{
        			// 判断是否开启定位权限，如果开启，根据经纬度获取最近一家门店和二级区域，没有开启走默认
        			priceReqUtils = this.priceParamInfo(log, lat, priceReqUtils);
        		}
        	}
        }else {
        	// 小程序端，IOS，Android，处理, 和没有传channel处理
        	if(null == areaCode){
        		areaCode = urlArea;
        		if(null == areaCode) areaCode = propertiesConfig.getDefaultAreaCode();
        	}
            priceReqUtils = new PriceReqUtils(null, areaCode);
        }
        
        MeidianEnvironment.put("priceReqStoreCode", priceReqUtils.getStoreCode());
        MeidianEnvironment.put("priceReqAreaCode", priceReqUtils.getAreaCode());
        LogUtils.logInfo(StorePriceAOP.class);
        
    }
	
	/**
	 * 根据经纬度获取最近的一家实体门店
	 * @param log
	 * @param lat
	 * @param priceReqUtils
	 * @return
	 */
	public PriceReqUtils priceParamInfo(String longitude, String latitude, PriceReqUtils priceReqUtils){
		if(null != longitude && !longitude.equals("")
				&& null != latitude && !latitude.equals("")){
			List<Store> stores = storeManager.storeDetail(longitude, latitude, 1);
			Store store = stores.get(0);
			if(store.getPoolFlag().intValue() == 2){
				int num = 3;
				stores = storeManager.storeDetail(longitude, latitude, num);
				store = stores.get(1);
				if(store.getPoolFlag().intValue() == 2){
					store = stores.get(2);
					if(store.getPoolFlag().intValue() == 2){
						store = stores.get(0);
					}
				}
			}
			
			priceReqUtils = new PriceReqUtils(store.getStoreCode(), store.getCityCode());
			
		}else{
			// 没有开启定位权限，走默认。
    		priceReqUtils = new PriceReqUtils(propertiesConfig.getDefaultStoreCode(), propertiesConfig.getDefaultAreaCode());
		}
		
		return priceReqUtils;
	}
}