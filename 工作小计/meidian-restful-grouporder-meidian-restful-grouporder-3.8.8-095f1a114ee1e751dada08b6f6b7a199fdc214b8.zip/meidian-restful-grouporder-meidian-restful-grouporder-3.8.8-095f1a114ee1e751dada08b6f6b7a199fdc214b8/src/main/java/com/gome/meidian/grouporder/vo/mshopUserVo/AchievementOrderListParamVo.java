package com.gome.meidian.grouporder.vo.mshopUserVo;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

public class AchievementOrderListParamVo implements Serializable{

	private static final long serialVersionUID = 565473873952596641L;
	private String filter;
	@NotBlank(message = "{param.error}")
	private String dateState;
	@NotNull(message = "{param.error}")
	private Integer pageNo;
	@NotNull(message = "{param.error}")
	private Integer pageSize;
	public String getFilter() {
		return filter;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public String getDateState() {
		return dateState;
	}
	public void setDateState(String dateState) {
		this.dateState = dateState;
	}
	public Integer getPageNo() {
		return pageNo;
	}
	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	
	
	

}
