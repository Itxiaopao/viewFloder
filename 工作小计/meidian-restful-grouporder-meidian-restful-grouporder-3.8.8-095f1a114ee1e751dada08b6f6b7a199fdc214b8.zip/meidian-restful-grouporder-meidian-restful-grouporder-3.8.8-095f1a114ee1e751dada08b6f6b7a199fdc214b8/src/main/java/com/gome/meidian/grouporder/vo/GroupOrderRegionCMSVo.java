package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

import com.gome.mobile.datainfo.model.templet.DataTempletInfo;

public class GroupOrderRegionCMSVo implements Serializable{

	private static final long serialVersionUID = 1107789695493614788L;
	
	private String serverTime;
	private List<DataTempletInfo> dataTempletInfos;
	
	public String getServerTime() {
		return serverTime;
	}
	public void setServerTime(String serverTime) {
		this.serverTime = serverTime;
	}
	public List<DataTempletInfo> getDataTempletInfos() {
		return dataTempletInfos;
	}
	public void setDataTempletInfos(List<DataTempletInfo> dataTempletInfos) {
		this.dataTempletInfos = dataTempletInfos;
	}

}
