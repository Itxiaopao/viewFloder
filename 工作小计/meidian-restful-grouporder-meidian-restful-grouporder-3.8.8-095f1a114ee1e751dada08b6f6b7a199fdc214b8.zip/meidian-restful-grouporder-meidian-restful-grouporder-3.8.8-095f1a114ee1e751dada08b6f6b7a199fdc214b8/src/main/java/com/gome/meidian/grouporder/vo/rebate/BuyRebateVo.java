package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

/**
 * 购买返入参
 * @author shichangjian
 *
 */
public class BuyRebateVo implements Serializable{

	private static final long serialVersionUID = -6132157374779732171L;

	@Valid
	private List<BuyRebate> buyRebates;

	public List<BuyRebate> getBuyRebates() {
		return buyRebates;
	}

	public void setBuyRebates(List<BuyRebate> buyRebates) {
		this.buyRebates = buyRebates;
	}

	
	
}
