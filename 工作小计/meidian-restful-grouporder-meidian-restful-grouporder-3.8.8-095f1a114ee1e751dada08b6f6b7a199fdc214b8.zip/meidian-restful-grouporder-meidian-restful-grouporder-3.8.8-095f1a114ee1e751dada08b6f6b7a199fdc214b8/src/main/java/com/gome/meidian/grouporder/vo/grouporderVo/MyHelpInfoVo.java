package com.gome.meidian.grouporder.vo.grouporderVo;


import com.gome.meidian.grouporder.vo.Coupon;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 我的助力列表信息
 * @author shigaopeng-ds
 */
public class MyHelpInfoVo implements Serializable {

    private static final long serialVersionUID = 2278833123935929975L;
    private Long groupId;              // 团id
    private String productId;          // 商品productId
    private String skuId;              // 商品skuId
    private Long activityId;           // 商品集id
    private Long headerUserId;         // 被助力者userId
    private Long userId;               // 助力者userID
    private String orderId;            // 被助力者订单ID
    private Long helpId;               // 助力id
    private String productImage;       // 商品图片
    private String productName;        // 商品标题
    private String gomePrice;          // 国美价
    private Integer productTag;        // 自联营标识  1：自营 2：联营
    private Date endTime;              // 助力结束时间
    private String rebateMoney;       // 用户本次助力，获得的奖励金额
    private Integer helpState;         // 助力奖金状态，0：待入账，1：待发放，2：已发放，3：已失效
    private List<HelpGroupCouponVo> couponList; //奖励的券信息
    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getGomePrice() {
        return gomePrice;
    }

    public void setGomePrice(String gomePrice) {
        this.gomePrice = gomePrice;
    }

    public Integer getProductTag() {
        return productTag;
    }

    public void setProductTag(Integer productTag) {
        this.productTag = productTag;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getRebateMoney() {
        return rebateMoney;
    }

    public void setRebateMoney(String rebateMoney) {
        this.rebateMoney = rebateMoney;
    }

    public Integer getHelpState() {
        return helpState;
    }

    public void setHelpState(Integer helpState) {
        this.helpState = helpState;
    }

    public List<HelpGroupCouponVo> getCouponList() {
        return couponList;
    }

    public void setCouponList(List<HelpGroupCouponVo> couponList) {
        this.couponList = couponList;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Long getHeaderUserId() {
        return headerUserId;
    }

    public void setHeaderUserId(Long headerUserId) {
        this.headerUserId = headerUserId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Long getHelpId() {
        return helpId;
    }

    public void setHelpId(Long helpId) {
        this.helpId = helpId;
    }
}
