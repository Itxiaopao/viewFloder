package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Data;

import java.io.Serializable;
@Data
public class GomeHelpCreatePromotionVo implements Serializable {
    private static final long serialVersionUID = -6329217529889144170L;
    /**
     * 员工来源
     */
    private Integer employeeOrigin;
    /**
     * 员工id
     */
    private String employeeId;
    /**
     * 业务id
     */
    private String businessId;
    /**
     * 推广内容
     */
    private String content;
    /**
     * 推广位置
     */
    private String locationId;

}
