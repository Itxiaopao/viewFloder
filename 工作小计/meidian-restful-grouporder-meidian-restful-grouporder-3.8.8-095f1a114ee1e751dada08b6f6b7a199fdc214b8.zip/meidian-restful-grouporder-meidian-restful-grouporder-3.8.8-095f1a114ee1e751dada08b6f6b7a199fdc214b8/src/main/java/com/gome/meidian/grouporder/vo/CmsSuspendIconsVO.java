package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 悬浮窗icon区域(没有业务转配, 只需要cms直接输出到前端, vo类名作废)
 * 
 * @author libinbin-ds
 *
 */
@Getter
@Setter
@Deprecated
public class CmsSuspendIconsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2505119767818832506L;
	
	
	private Long id;			// id	(not null)
	private String bsCode;		// 业务id	(not null)
	private String iconName;	// icon名称
	private String imgUrl;		//图片地址
	private String skipUrl;		// 跳珠路径
	private Integer iconLocal;	// icon位置	上 中 下	(not null)
	private String iconLocalStr;// icon位置	上 中 下	(not null)
	private Integer isMove;		// 是否移动 0;1	(not null)
	private String isMoveStr;	// 是否移动 0;1	(not null)
	private Integer isShow;		// 是否展示 1:都可见, 2: 登录可见, 3:登录不可见, 4:都不展示	(not null)
	private String isShowStr;	// 是否展示 1:都可见, 2: 登录可见, 3:登录不可见, 4:都不展示	(not null)
	private Integer showCount;	// 展示次数
	private Integer iconType;	// icon 类型 0:无类型, 1:弹窗	// by:libinbin-ds 2018-12-12 
	private Integer iconTypeStr;	// icon 类型 0:无类型, 1:弹窗	// by:libinbin-ds 2018-12-12 
	
}
