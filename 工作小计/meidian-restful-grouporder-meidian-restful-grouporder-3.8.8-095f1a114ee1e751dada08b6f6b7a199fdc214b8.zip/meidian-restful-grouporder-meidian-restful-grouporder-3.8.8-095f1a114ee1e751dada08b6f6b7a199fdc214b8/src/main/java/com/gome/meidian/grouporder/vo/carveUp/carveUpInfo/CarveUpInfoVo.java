package com.gome.meidian.grouporder.vo.carveUp.carveUpInfo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.gomeplus.bs.interfaces.gorder.vo.GroupUserInfo;

/**
 * 瓜分团详情信息
 */
public class CarveUpInfoVo implements Serializable {

	private static final long serialVersionUID = -3901395716881881464L;
	private Long id; //id
	private Long carveId; //瓜分活动id
	private Integer status; //瓜分团状态： 0：初始值；1：已开始；2：已结束
	private Long userId;
	private Long headerUserId; //瓜分团长userId
	private String image; //团长头像
	private String nickName;//团长昵称
	private Long startTime; //活动开始时间
	private Long endTime; //活动结束时间
	private Long groupStartTime; //团开始时间
	private Long groupEndTime; //团结束时间
	private Integer currentMemberNum; //当前成员人数
	private Integer isSucess; //是否达标 0 未达标  1 已达标（判断条件--新人数达到标准且总人数达到标准）
	private Integer carveGroupType; //瓜分团类型：1：基础团，2：排名团--奖励定额，3：排名团--奖励瓜分
	private Integer oldUserNum; //老用户参与团人数
	private Integer newUserNum; //新用户参与团人数
	
	private String hyperLinks; //图片跳转链接
	private String imageUrl; //图片地址
	private List<GroupUserInfo> memberList;//团成员列表	private Integer timeOfDuration; //团持续时间（单位：小时）
	private Integer carveMinNewNum; //最低新用户人数
	private Integer carveBaseNum; //达标人数',--团
	
//	private Integer carveNum;  //瓜分团成功数
//	private Double carveMoney; //瓜分团成功瓜分金额

	private List<CarveUpRewardVo> rewards;  //奖励信息
	private Boolean helped;  //是否已助力参团 true:已助力  false:未助力
	private Long surplusTime;  //距团结束时间

	private Integer userUnusedAttendNum;//当前用户在当前活动已用参与次数
	private List<String> marquee; //跑马灯
	
	private Integer nowUserFlag; //0-老客户   1-新客户
	private Integer carveStatus;  //0-未开始   1-进行中   2-已结束

	private String appletImageUrl; //小程序card图片
	private String friendImageUrl; //好友朋友圈图片
	private String friendSubImageUrl; //好友朋友圈配图
	public Long getSurplusTime() {
		return surplusTime;
	}
	public void setSurplusTime(Long surplusTime) {
		this.surplusTime = surplusTime;
	}
	public Long getCarveId() {
		return carveId;
	}
	public void setCarveId(Long carveId) {
		this.carveId = carveId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getHeaderUserId() {
		return headerUserId;
	}
	public void setHeaderUserId(Long headerUserId) {
		this.headerUserId = headerUserId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public Long getStartTime() {
		return startTime;
	}
	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}
	public Long getEndTime() {
		return endTime;
	}
	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}
	public Integer getCurrentMemberNum() {
		return currentMemberNum;
	}
	public void setCurrentMemberNum(Integer currentMemberNum) {
		this.currentMemberNum = currentMemberNum;
	}
	public Integer getIsSucess() {
		return isSucess;
	}
	public void setIsSucess(Integer isSucess) {
		this.isSucess = isSucess;
	}
	public Integer getCarveGroupType() {
		return carveGroupType;
	}
	public void setCarveGroupType(Integer carveGroupType) {
		this.carveGroupType = carveGroupType;
	}
	public Integer getOldUserNum() {
		return oldUserNum;
	}
	public void setOldUserNum(Integer oldUserNum) {
		this.oldUserNum = oldUserNum;
	}
	public Integer getNewUserNum() {
		return newUserNum;
	}
	public void setNewUserNum(Integer newUserNum) {
		this.newUserNum = newUserNum;
	}
	public String getHyperLinks() {
		return hyperLinks;
	}
	public void setHyperLinks(String hyperLinks) {
		this.hyperLinks = hyperLinks;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public List<GroupUserInfo> getMemberList() {
		return memberList;
	}
	public void setMemberList(List<GroupUserInfo> memberList) {
		this.memberList = memberList;
	}
	public Integer getCarveMinNewNum() {
		return carveMinNewNum;
	}
	public void setCarveMinNewNum(Integer carveMinNewNum) {
		this.carveMinNewNum = carveMinNewNum;
	}
	public Integer getCarveBaseNum() {
		return carveBaseNum;
	}
	public void setCarveBaseNum(Integer carveBaseNum) {
		this.carveBaseNum = carveBaseNum;
	}
//	public Integer getCarveNum() {
//		return carveNum;
//	}
//	public void setCarveNum(Integer carveNum) {
//		this.carveNum = carveNum;
//	}
//	public Double getCarveMoney() {
//		return carveMoney;
//	}
//	public void setCarveMoney(Double carveMoney) {
//		this.carveMoney = carveMoney;
//	}
	public Boolean getHelped() {
		return helped;
	}
	public void setHelped(Boolean helped) {
		this.helped = helped;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<CarveUpRewardVo> getRewards() {
		return rewards;
	}

	public void setRewards(List<CarveUpRewardVo> rewards) {
		this.rewards = rewards;
	}
	public List<String> getMarquee() {
		return marquee;
	}
	public void setMarquee(List<String> marquee) {
		this.marquee = marquee;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getGroupStartTime() {
		return groupStartTime;
	}
	public void setGroupStartTime(Long groupStartTime) {
		this.groupStartTime = groupStartTime;
	}
	public Long getGroupEndTime() {
		return groupEndTime;
	}
	public void setGroupEndTime(Long groupEndTime) {
		this.groupEndTime = groupEndTime;
	}
	public Integer getUserUnusedAttendNum() {
		return userUnusedAttendNum;
	}
	public void setUserUnusedAttendNum(Integer userUnusedAttendNum) {
		this.userUnusedAttendNum = userUnusedAttendNum;
	}
	public Integer getNowUserFlag() {
		return nowUserFlag;
	}
	public void setNowUserFlag(Integer nowUserFlag) {
		this.nowUserFlag = nowUserFlag;
	}
	public Integer getCarveStatus() {
		return carveStatus;
	}
	public void setCarveStatus(Integer carveStatus) {
		this.carveStatus = carveStatus;
	}
	public String getAppletImageUrl() {
		return appletImageUrl;
	}
	public void setAppletImageUrl(String appletImageUrl) {
		this.appletImageUrl = appletImageUrl;
	}
	public String getFriendImageUrl() {
		return friendImageUrl;
	}
	public void setFriendImageUrl(String friendImageUrl) {
		this.friendImageUrl = friendImageUrl;
	}
	public String getFriendSubImageUrl() {
		return friendSubImageUrl;
	}
	public void setFriendSubImageUrl(String friendSubImageUrl) {
		this.friendSubImageUrl = friendSubImageUrl;
	}
	
	
	
}
