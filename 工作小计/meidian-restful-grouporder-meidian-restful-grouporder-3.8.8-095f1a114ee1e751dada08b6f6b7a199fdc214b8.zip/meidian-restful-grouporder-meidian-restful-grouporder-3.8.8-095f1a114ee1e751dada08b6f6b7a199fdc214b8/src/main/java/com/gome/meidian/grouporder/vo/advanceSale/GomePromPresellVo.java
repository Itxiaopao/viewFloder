package com.gome.meidian.grouporder.vo.advanceSale;

import com.gome.pangu.promotiondata.client.dto.presellprom.GomePromPresellStepPrice;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * @Author yuliang-ds1
 * @Date 2019/2/15 14:31
 * @Description
 */
public class GomePromPresellVo implements Serializable {


    private static final long serialVersionUID = 1L;


    /**
     * 促销编码
     */
    private String promId;
    /**
     * 促销状态 1-待提审 2-审核中 3-调价待提审 4-调价审核中 5-审核通过 6-审核不通过 7-已终止
     */
    private String promStatus;

    /**
     * 阶梯价格列表
     */
    private List<GomePromPresellStepPrice> stepPrices;

    /**
     * 商品skuNo编码
     */
    private String skuNo;

    /**
     * 门店id
     */
    private String storeId;

    /**
     * 预售定金定金
     */
    private Double deposit;

    /**
     * 方案开始时间
     */
    private Timestamp startDate;
    /**
     * 方案结束时间
     */
    private Timestamp endDate;

    /**
     * 尾款开始时间
     */
    private Timestamp residueStartDate;
    /**
     * 尾款结束时间
     */
    private Timestamp residueEndDate;

    /**
     * 尾款金额
     */
    private Double residue;

    /**
     * 定金翻倍定金抵扣金额(定金+资源金额)
     */
    private String deductibleDeposit;

    /**
     * 是否定金膨胀 0否1是
     */
    private String depositExpand;

    /**
     * 预售类型
     */
    private String presaleType;

    /**
     * 预售砖头 是否 可正常销售 0正常 1不正常
     */
    private int preSaleStatus;

    /**
     * 预售是否锁库存 0不锁 1锁
     */
    private int lockStock;

    /**
     * 预计发货时间
     */
    private Timestamp shipmentsDate;

    /**
     * 商品productID
     */
    private String spuId;
    /**
     * 商品skuId
     */
    private String skuId;

    /**
     * 商品属性 1-G3PP,2-3PP,3-SMI,4-SMI百货 多个以逗号分隔
     */
    private String productAttributes;
    /**
     * 单用户限购数量
     */
    private Integer limitNum;
    /**
     * 预售灌水人数
     */
    private Integer presellVirtualNumber;
    /**
     * 来源
     */
    private String source;
    /**
     * 展示终端 1-线上专享 2-扫码专享 3-POS专享  多个以逗号分隔
     */
    private String showTerminal;
    /**
     * 可预售数量
     */
    private Integer presellNum;
    /**
     * 付款方式 0-定金，1-全款
     */
    private Boolean payType;
    /**
     * 初始预售价
     */
    private Double presellPrice;


    /*新增 阶梯标识： 1 阶梯/ 0 非阶梯*/
    private Integer stepFlag;
    /**
     * 实际购买人数
     */
    private Integer realSellNum;

    public Integer getRealSellNum() {
        return realSellNum;
    }

    public void setRealSellNum(Integer realSellNum) {
        this.realSellNum = realSellNum;
    }

    public Integer getStepFlag() {
        return stepFlag;
    }

    public void setStepFlag(Integer stepFlag) {
        this.stepFlag = stepFlag;
    }

    public String getPromId() {
        return promId;
    }

    public void setPromId(String promId) {
        this.promId = promId;
    }

    public String getPromStatus() {
        return promStatus;
    }

    public void setPromStatus(String promStatus) {
        this.promStatus = promStatus;
    }

    public List<GomePromPresellStepPrice> getStepPrices() {
        return stepPrices;
    }

    public void setStepPrices(List<GomePromPresellStepPrice> stepPrices) {
        this.stepPrices = stepPrices;
    }

    public String getSkuNo() {
        return skuNo;
    }

    public void setSkuNo(String skuNo) {
        this.skuNo = skuNo;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public Double getDeposit() {
        return deposit;
    }

    public void setDeposit(Double deposit) {
        this.deposit = deposit;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public Timestamp getResidueStartDate() {
        return residueStartDate;
    }

    public void setResidueStartDate(Timestamp residueStartDate) {
        this.residueStartDate = residueStartDate;
    }

    public Timestamp getResidueEndDate() {
        return residueEndDate;
    }

    public void setResidueEndDate(Timestamp residueEndDate) {
        this.residueEndDate = residueEndDate;
    }

    public Double getResidue() {
        return residue;
    }

    public void setResidue(Double residue) {
        this.residue = residue;
    }

    public String getDeductibleDeposit() {
        return deductibleDeposit;
    }

    public void setDeductibleDeposit(String deductibleDeposit) {
        this.deductibleDeposit = deductibleDeposit;
    }

    public String getDepositExpand() {
        return depositExpand;
    }

    public void setDepositExpand(String depositExpand) {
        this.depositExpand = depositExpand;
    }

    public String getPresaleType() {
        return presaleType;
    }

    public void setPresaleType(String presaleType) {
        this.presaleType = presaleType;
    }

    public int getPreSaleStatus() {
        return preSaleStatus;
    }

    public void setPreSaleStatus(int preSaleStatus) {
        this.preSaleStatus = preSaleStatus;
    }

    public int getLockStock() {
        return lockStock;
    }

    public void setLockStock(int lockStock) {
        this.lockStock = lockStock;
    }

    public Timestamp getShipmentsDate() {
        return shipmentsDate;
    }

    public void setShipmentsDate(Timestamp shipmentsDate) {
        this.shipmentsDate = shipmentsDate;
    }

    public String getSpuId() {
        return spuId;
    }

    public void setSpuId(String spuId) {
        this.spuId = spuId;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getProductAttributes() {
        return productAttributes;
    }

    public void setProductAttributes(String productAttributes) {
        this.productAttributes = productAttributes;
    }

    public Integer getLimitNum() {
        return limitNum;
    }

    public void setLimitNum(Integer limitNum) {
        this.limitNum = limitNum;
    }

    public Integer getPresellVirtualNumber() {
        return presellVirtualNumber;
    }

    public void setPresellVirtualNumber(Integer presellVirtualNumber) {
        this.presellVirtualNumber = presellVirtualNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getShowTerminal() {
        return showTerminal;
    }

    public void setShowTerminal(String showTerminal) {
        this.showTerminal = showTerminal;
    }

    public Integer getPresellNum() {
        return presellNum;
    }

    public void setPresellNum(Integer presellNum) {
        this.presellNum = presellNum;
    }

    public Boolean getPayType() {
        return payType;
    }

    public void setPayType(Boolean payType) {
        this.payType = payType;
    }

    public Double getPresellPrice() {
        return presellPrice;
    }

    public void setPresellPrice(Double presellPrice) {
        this.presellPrice = presellPrice;
    }
}

