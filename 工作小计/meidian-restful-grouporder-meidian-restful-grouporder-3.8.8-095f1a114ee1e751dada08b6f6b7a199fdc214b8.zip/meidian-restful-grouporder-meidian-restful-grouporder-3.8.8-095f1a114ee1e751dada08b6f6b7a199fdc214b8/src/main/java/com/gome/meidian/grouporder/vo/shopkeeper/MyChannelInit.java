package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;
import java.util.List;

/**
 * 渠道页面初始化\
 * 
 * @author libinbin-ds
 *
 */
public class MyChannelInit implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6215433250227064981L;
	
	private ChannelUserInfo myInfo;
	
	private List<ChannelUserInfo> mshopOwners;

	public ChannelUserInfo getMyInfo() {
		return myInfo;
	}

	public void setMyInfo(ChannelUserInfo myInfo) {
		this.myInfo = myInfo;
	}

	public List<ChannelUserInfo> getMshopOwners() {
		return mshopOwners;
	}

	public void setMshopOwners(List<ChannelUserInfo> mshopOwners) {
		this.mshopOwners = mshopOwners;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public MyChannelInit() {
		super();
	}

	public MyChannelInit(ChannelUserInfo myInfo, List<ChannelUserInfo> mshopOwners) {
		this.myInfo = myInfo;
		this.mshopOwners = mshopOwners;
	}
	
	
	
}
