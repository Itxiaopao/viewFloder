package com.gome.meidian.grouporder.vo.search;

import java.io.Serializable;

public class FilterValInfo implements Serializable{
	private static final long serialVersionUID = 9145842773121270895L;
	private String index;//位置
	private String count;//数量
	private String filterValName;//名称
	//private String isHot;
	private String pinyin;//拼音首字母
	private String filterVal;//过滤条件ID
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getFilterValName() {
		return filterValName;
	}
	public void setFilterValName(String filterValName) {
		this.filterValName = filterValName;
	}
	public String getFilterVal() {
		return filterVal;
	}
	public void setFilterVal(String filterVal) {
		this.filterVal = filterVal;
	}
	public String getPinyin() {
		return pinyin;
	}
	public void setPinyin(String pinyin) {
		this.pinyin = pinyin;
	}

	
}
