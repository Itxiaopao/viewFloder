package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;
import java.util.Date;

public class AppraiseVo implements Serializable{

	private static final long serialVersionUID = 6540173851154904958L;
	private String id;
	private String productId;
	private String productName;
	private String postUserId;
	private String postUserName;
	private String content;
	private Date postTime;
	private String postDay;
//	private String topFlag;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getPostUserId() {
		return postUserId;
	}
	public void setPostUserId(String postUserId) {
		this.postUserId = postUserId;
	}
	public String getPostUserName() {
		return postUserName;
	}
	public void setPostUserName(String postUserName) {
		this.postUserName = postUserName;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getPostTime() {
		return postTime;
	}
	public void setPostTime(Date postTime) {
		this.postTime = postTime;
	}
	public String getPostDay() {
		return postDay;
	}
	public void setPostDay(String postDay) {
		this.postDay = postDay;
	}
//	public String getTopFlag() {
//		return topFlag;
//	}
//	public void setTopFlag(String topFlag) {
//		this.topFlag = topFlag;
//	}
	
}
