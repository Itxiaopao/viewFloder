package com.gome.meidian.grouporder.vo.rebate;

import java.io.Serializable;
import java.util.List;

import javax.validation.Valid;

public class ProductBuyRebateReq implements Serializable{

	private static final long serialVersionUID = 1443377569548763955L;
	
	@Valid
	private List<ProductBuyRebate> productBuyRebates;

	public List<ProductBuyRebate> getProductBuyRebates() {
		return productBuyRebates;
	}

	public void setProductBuyRebates(List<ProductBuyRebate> productBuyRebates) {
		this.productBuyRebates = productBuyRebates;
	}
	
	
}
