package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class OrderInfoVo implements Serializable{

	private static final long serialVersionUID = -2326672997613504803L;
	private Long orderId;//订单id
	private String deliveryId;//配送id
	private Long userId;//下单人用户id
	private String orderTimeStr;//订单时间
	private Integer orderStatus;//订单状态0:待支付 1:待发货 2:已取消 3:待收货 5:已收货 6:售后
	private Long priceTotal;//订单总价值（实付价）（分）
	private List<SkuInfoVo> goodsList;//商品列表
	private String userWeixin;//微信昵称
	private Long awardMoney;//提奖金额
	private Long commMoney;//佣金金额
	private int authorization;//授权状态 0:未授权,1:授权
	private Integer isPickGoods;//是否提货，null:无权限操作，0:未提货，1已提货
	private Long parentUserId;//上级id
}
