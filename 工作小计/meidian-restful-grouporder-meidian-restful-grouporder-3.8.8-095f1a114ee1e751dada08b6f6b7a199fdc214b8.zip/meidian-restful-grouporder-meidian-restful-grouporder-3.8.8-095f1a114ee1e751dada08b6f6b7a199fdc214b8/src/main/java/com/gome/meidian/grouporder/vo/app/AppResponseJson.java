package com.gome.meidian.grouporder.vo.app;

import java.util.List;

import com.gome.meidian.restfulcommon.reponse.StatusCode;
import com.gome.meidian.restfulcommon.utils.JSONUtils;

/**
 * 返回的json 对象
 * @author lishuxu
 *
 * @param <T>
 */
public class AppResponseJson<T> {
	
	private int code = StatusCode.SUCCESS.getCode();
	private String msg = StatusCode.SUCCESS.getMsg();
	private T data;
	private String isSessionExpired;

	private transient static AppResponseJson successResponse = new AppResponseJson(StatusCode.SUCCESS, true);

	public AppResponseJson() {
	}

	public AppResponseJson(int code) {
		super();
		this.code = code;
	}

	public AppResponseJson(int code, String msg) {
		super();
		this.code = code;
		this.msg = msg;
	}

	public AppResponseJson(StatusCode statusCode, boolean success) {
		code = statusCode.getCode();
		msg = statusCode.getMsg();
	}
	public AppResponseJson(StatusCode statusCode) {
		code = statusCode.getCode();
		msg = statusCode.getMsg();
	}

	public AppResponseJson(T data) {
		this.data = data;
	}


	public static AppResponseJson getValidationErrorResponse(List<ValidationError> errorList) {
		AppResponseJson<List<ValidationError>> AppResponseJson = new AppResponseJson<>();
		AppResponseJson.setData(errorList);
		return AppResponseJson;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public T getData() {
		return data == null ? (T) new Object() : data;
	}

	public void setData(T data) {
		this.data = data;
	}
	
	
	

	public String getIsSessionExpired() {
		return isSessionExpired;
	}

	public void setIsSessionExpired(String isSessionExpired) {
		this.isSessionExpired = isSessionExpired;
	}

	@Override
	public String toString() {
		return String.format("AppResponseJson [code=%d, msg=%s, data=%s ,isSessionExpired=%s]",code, msg, isSessionExpired,JSONUtils.toJSONString(data));
	}

	public static AppResponseJson getSuccessResponse() {
		return AppResponseJson.successResponse;
	}

	public static AppResponseJson getFailedResponse() {
		return new AppResponseJson(StatusCode.SYSTEM_ERROR, false);
	}

	public static AppResponseJson getFailedResponse(String msg) {
		AppResponseJson response = new AppResponseJson(StatusCode.SYSTEM_ERROR, false);
		response.setMsg(msg);
		return response;
	}

	public static class ValidationError {
		private String param;
		private String msg;

		public ValidationError(String param, String msg) {
			this.param = param;
			this.msg = msg;
		}

		public String getParam() {
			return param;
		}

		public void setParam(String param) {
			this.param = param;
		}

		public String getMsg() {
			return msg;
		}

		public void setMsg(String msg) {
			this.msg = msg;
		}
	}

}
