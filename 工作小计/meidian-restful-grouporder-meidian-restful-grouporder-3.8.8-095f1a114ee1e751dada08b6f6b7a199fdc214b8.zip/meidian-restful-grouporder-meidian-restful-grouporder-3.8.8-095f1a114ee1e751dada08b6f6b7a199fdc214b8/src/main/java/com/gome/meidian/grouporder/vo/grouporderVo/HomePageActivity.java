package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

/**
 * 首页列表活动信息
 * @author shichangjian
 *
 */
public class HomePageActivity implements Serializable{

	private static final long serialVersionUID = 7732195618876593872L;

	private Long activityId; 				// id
	private Integer irrigationNumber;     	// 灌水倍数
	private Float maxDiscount;				// 最大折扣
	private Integer maxDiscountPeopleNum;	// 最大折扣 需要的人数
	private String discountRebate;			// 折扣返
	private Integer totalBuyNum;			// 已买件数
	private Long groupId;					// 团id
	private Integer groupBusType;			// 团类型
	private Integer modeType;				//模式类型  0:参团,1:开团
	
	public HomePageActivity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HomePageActivity(
			Long activityId,   Integer irrigationNumber, 
			Float maxDiscount, Integer maxDiscountPeopleNum,
			Integer groupBusType, Integer modeType) {
		super();
		this.activityId = activityId;
		this.irrigationNumber = irrigationNumber;
		this.maxDiscount = maxDiscount;
		this.maxDiscountPeopleNum = maxDiscountPeopleNum;
		this.groupBusType = groupBusType;
		this.modeType = modeType;
	}
	
	public Long getActivityId() {
		return activityId;
	}
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}
	public Integer getIrrigationNumber() {
		return irrigationNumber;
	}
	public void setIrrigationNumber(Integer irrigationNumber) {
		this.irrigationNumber = irrigationNumber;
	}
	public Integer getMaxDiscountPeopleNum() {
		return maxDiscountPeopleNum;
	}
	public void setMaxDiscountPeopleNum(Integer maxDiscountPeopleNum) {
		this.maxDiscountPeopleNum = maxDiscountPeopleNum;
	}
	public Float getMaxDiscount() {
		return maxDiscount;
	}
	public void setMaxDiscount(Float maxDiscount) {
		this.maxDiscount = maxDiscount;
	}
	public String getDiscountRebate() {
		return discountRebate;
	}
	public void setDiscountRebate(String discountRebate) {
		this.discountRebate = discountRebate;
	}

	public Integer getTotalBuyNum() {
		return totalBuyNum;
	}

	public void setTotalBuyNum(Integer totalBuyNum) {
		this.totalBuyNum = totalBuyNum;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Integer getGroupBusType() {
		return groupBusType;
	}

	public void setGroupBusType(Integer groupBusType) {
		this.groupBusType = groupBusType;
	}

	public Integer getModeType() {
		return modeType;
	}

	public void setModeType(Integer modeType) {
		this.modeType = modeType;
	}
	
	
	
}
