package com.gome.meidian.grouporder.vo.app;

import java.io.Serializable;
/**
 * 分享卡片信息接口
 * @author lishouxu-ds
 *
 */
public class ShareCardVo implements Serializable{
	private static final long serialVersionUID = 1888924999345795870L;
	private Integer pageType;// 分享页面类型（守旭）
	private Long rebate;// 分享返 
	private String desc;// 商品名称
	private String imgUrl;// 商品图片
	private Long totalBuyNum;// 已团件数
	private Double price; //国美价
	private Long maxDiscountPeopleNum;// 几人团
	private Double buyRebate; //购买返
	private String productTag; //自营非自营
	private Double couponPrice; //券后价
	private Double meidianPrice;// 成团价
	private Double couponNum;// 券面额
	private String shareUrl;// 活动页类型的图片
	private String key;//缓存参数key
	private String shareCodedata;//二进制分享码
	private String friendSubImageUrl;// 活动页图片logo
	

	public Integer getPageType() {
		return pageType;
	}
	public void setPageType(Integer pageType) {
		this.pageType = pageType;
	}
	public Long getRebate() {
		return rebate;
	}
	public void setRebate(Long rebate) {
		this.rebate = rebate;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getImgUrl() {
		return imgUrl;
	}
	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}
	public Long getTotalBuyNum() {
		return totalBuyNum;
	}
	public void setTotalBuyNum(Long totalBuyNum) {
		this.totalBuyNum = totalBuyNum;
	}

	public Long getMaxDiscountPeopleNum() {
		return maxDiscountPeopleNum;
	}
	public void setMaxDiscountPeopleNum(Long maxDiscountPeopleNum) {
		this.maxDiscountPeopleNum = maxDiscountPeopleNum;
	}

	public String getProductTag() {
		return productTag;
	}
	public void setProductTag(String productTag) {
		this.productTag = productTag;
	}
	public String getShareUrl() {
		return shareUrl;
	}
	public void setShareUrl(String shareUrl) {
		this.shareUrl = shareUrl;
	}
	public String getShareCodedata() {
		return shareCodedata;
	}
	public void setShareCodedata(String shareCodedata) {
		this.shareCodedata = shareCodedata;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getBuyRebate() {
		return buyRebate;
	}
	public void setBuyRebate(Double buyRebate) {
		this.buyRebate = buyRebate;
	}
	public Double getCouponPrice() {
		return couponPrice;
	}
	public void setCouponPrice(Double couponPrice) {
		this.couponPrice = couponPrice;
	}


	public Double getMeidianPrice() {
		return meidianPrice;
	}
	public void setMeidianPrice(Double meidianPrice) {
		this.meidianPrice = meidianPrice;
	}
	public Double getCouponNum() {
		return couponNum;
	}
	public void setCouponNum(Double couponNum) {
		this.couponNum = couponNum;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getFriendSubImageUrl() {
		return friendSubImageUrl;
	}
	public void setFriendSubImageUrl(String friendSubImageUrl) {
		this.friendSubImageUrl = friendSubImageUrl;
	}


	
	
}
