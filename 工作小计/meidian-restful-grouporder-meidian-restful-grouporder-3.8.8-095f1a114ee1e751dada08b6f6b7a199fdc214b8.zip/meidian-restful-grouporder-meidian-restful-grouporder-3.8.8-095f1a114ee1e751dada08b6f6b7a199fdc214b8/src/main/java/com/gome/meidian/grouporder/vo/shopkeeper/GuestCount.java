package com.gome.meidian.grouporder.vo.shopkeeper;

import java.io.Serializable;

public class GuestCount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1113953207179628359L;
	
	private Integer type; //类型
	private Integer count;	// 统计
	
	
	public GuestCount(Integer type, Integer count) {
		this.type = type;
		this.count = count;
	}
	public GuestCount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
