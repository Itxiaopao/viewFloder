package com.gome.meidian.grouporder.vo.homePage;

import java.io.Serializable;


public class CollectionProductInfoVo implements Serializable {

	private static final long serialVersionUID = -3745427152131552784L;
	
	// 分享次数
	private Long shareNum;
	
	// 点赞次数
	private Long thumbsUpNum;
	
	//收藏次数
	private Long collectionNum;
	
	//是否点赞过，0-未点赞  1-已点赞
	private Integer thumbsUped;
	
	//是否收藏过,0-未收藏  1-已收藏
	private Integer collected;
	//商品评论
	private AppraiseListVo appraiseList;
	public Long getShareNum() {
		return shareNum;
	}

	public void setShareNum(Long shareNum) {
		this.shareNum = shareNum;
	}

	public Long getThumbsUpNum() {
		return thumbsUpNum;
	}

	public void setThumbsUpNum(Long thumbsUpNum) {
		this.thumbsUpNum = thumbsUpNum;
	}

	public Long getCollectionNum() {
		return collectionNum;
	}

	public void setCollectionNum(Long collectionNum) {
		this.collectionNum = collectionNum;
	}

	public Integer getCollected() {
		return collected;
	}

	public void setCollected(Integer collected) {
		this.collected = collected;
	}

	public Integer getThumbsUped() {
		return thumbsUped;
	}

	public void setThumbsUped(Integer thumbsUped) {
		this.thumbsUped = thumbsUped;
	}

	public AppraiseListVo getAppraiseList() {
		return appraiseList;
	}

	public void setAppraiseList(AppraiseListVo appraiseList) {
		this.appraiseList = appraiseList;
	}

}
