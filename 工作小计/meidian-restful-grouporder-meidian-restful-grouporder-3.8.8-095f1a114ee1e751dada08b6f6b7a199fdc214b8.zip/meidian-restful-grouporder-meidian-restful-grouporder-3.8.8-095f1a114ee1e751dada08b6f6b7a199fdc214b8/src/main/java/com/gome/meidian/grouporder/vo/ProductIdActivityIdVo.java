package com.gome.meidian.grouporder.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 618
 * 数字门店首页
 * 一级分类和类型下的商品id，活动id
 * @author shichangjian
 *
 */
public class ProductIdActivityIdVo implements Serializable{

	private static final long serialVersionUID = 3401720489463501177L;
	
	private String productTypeName;							//一级商品分类名称
	private List<ProductIdActivityId> productIdActivityIds;	//类型下的商品id和活动id
	
	public String getProductTypeName() {
		return productTypeName;
	}
	public void setProductTypeName(String productTypeName) {
		this.productTypeName = productTypeName;
	}
	public List<ProductIdActivityId> getProductIdActivityIds() {
		return productIdActivityIds;
	}
	public void setProductIdActivityIds(List<ProductIdActivityId> productIdActivityIds) {
		this.productIdActivityIds = productIdActivityIds;
	}
	
	
	
	
}
