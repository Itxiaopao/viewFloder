package com.gome.meidian.grouporder.vo.materialVo;

import java.io.Serializable;
/**
 * 商品（返利or组团）
 * @author lishouxu-ds
 *
 */
public class ActivityMaterialProductVo extends ActivityMaterialVo implements Serializable{
	private static final long serialVersionUID = -2979630029100566917L;
	private String skuId;//skuId;
	private String activityId;//活动Id
	private String groupId;//组团Id
	private String productId;//商品id
	
	public ActivityMaterialProductVo(){
		skuId = "";
		activityId = "";
		groupId = "";
		productId = "";
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	

}
