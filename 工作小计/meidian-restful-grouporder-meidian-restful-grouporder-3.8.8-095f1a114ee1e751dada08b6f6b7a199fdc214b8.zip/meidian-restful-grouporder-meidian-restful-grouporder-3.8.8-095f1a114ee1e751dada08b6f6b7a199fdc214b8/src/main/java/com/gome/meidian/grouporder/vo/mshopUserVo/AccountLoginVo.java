package com.gome.meidian.grouporder.vo.mshopUserVo;

import lombok.Data;

import java.io.Serializable;

/**
 * @author sunxueyan-ds
 * @Title: AccountLoginVo
 * @ProjectName meidian-restful-grouporder
 * @Description: 美店账号密码登录
 * @date 2018/11/29 15:03
 */
@Data
public class AccountLoginVo implements Serializable {
    private static final long serialVersionUID = -1127833320604164175L;
    private String login;
    private String password;
    private String userId;
    private String newMobile;
    private String isMobileActivated;//手机激活标识Y：激活手机 N：释放手机
    private String loginName;//登录名称
    private String nickName;//用户昵称
    private String phone;
    private String token;
    private String code;//验证码
    private String distinctId;//灯塔埋码
    private String createType;//渠道来源：描述红包  签到  等等的业务埋的参数

}
