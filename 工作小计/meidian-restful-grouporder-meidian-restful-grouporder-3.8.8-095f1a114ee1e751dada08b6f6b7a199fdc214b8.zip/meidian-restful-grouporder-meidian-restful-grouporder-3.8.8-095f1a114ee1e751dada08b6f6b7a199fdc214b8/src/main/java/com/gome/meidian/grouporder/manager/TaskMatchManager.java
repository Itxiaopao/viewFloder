package com.gome.meidian.grouporder.manager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.common.exception.ServiceException;
import com.gome.meidian.grouporder.utils.DateUtils;
import com.gome.meidian.grouporder.utils.UserConstants;
import com.gome.meidian.grouporder.vo.register.TaskMatchPageVo;
import com.gome.meidian.grouporder.vo.register.TaskMatchVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;
import com.gome.sso.model.UserInfoCache;
import com.gomeo2o.common.entity.CommonResultEntity;
import com.gomeo2o.facade.vshop.entity.VshopInfo;
import com.gomeo2o.facade.vshop.service.VshopInfoExternalFacade;
import com.gomeplus.bs.interfaces.mshop.task.entity.MshopRaceOrderData;
import com.gomeplus.bs.interfaces.mshop.task.entity.ResponseApiDto;
import com.gomeplus.bs.interfaces.mshop.task.service.MshopRaceOrderDataService;
import com.gomeplus.bs.interfaces.mshop.task.service.MshopTaskInfoResource;
import com.gomeplus.bs.interfaces.mshop.task.service.TaskJoinResource;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskInfoVo;
import com.gomeplus.bs.interfaces.mshop.task.vo.TaskJoinVo;

import redis.Gcache;

@SuppressWarnings({"rawtypes","unchecked"})
@Service
public class TaskMatchManager {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private MshopTaskInfoResource mshopTaskInfoResource;
	@Autowired
	private GroupOrderManager groupOrderManager;
	@Autowired
	private VshopInfoExternalFacade vshopInfoExternalFacade;
	@Autowired
	private TaskJoinResource taskJoinResource;
	@Autowired
	private MshopRaceOrderDataService mshopRaceOrderDataServiceImpl;
	@Resource(name = "gcache")
	private Gcache gcache;
	
	//缓存常量
	private final String MSHOPTASKMATCH="mshop_task_match:";//店主竞赛活动信息
	private final String MSHOPTASKMATCHPAYORDER="mshop_task_match_pay_order:";//店主竞赛活动订单销量数据信息
	
	/**
	 * 获取奖赛活动信息
	 * @param taskMatchVo
	 * @return
	 * @throws MeidianException
	 */
	public Map<String,Object> getTaskMatchInfo(TaskMatchVo taskMatchVo) throws MeidianException {
		long curTime = DateUtils.currentTimeSecs();
		//缓存信息数据常量
		Map<String,Object> map = new HashMap<String,Object>();
		String taskMatchKey = MSHOPTASKMATCH + taskMatchVo.getTaskId();
		//获取缓存数据
		String gacheTMK = gcache.get(taskMatchKey);
		if(StringUtils.isBlank(gacheTMK)){
			map = this.checkTaskStatus(taskMatchVo.getTaskId(),curTime);
			try{
				String resultJson = JSON.toJSONString(map);
				gcache.setex(taskMatchKey, 60, resultJson);
			}catch (Exception e){
				logger.info("店主竞赛活动信息,缓存异常{}",e);
			}
		}else{
			map = JSON.parseObject(gacheTMK,HashMap.class);
		}
		return map;
	}
	
	/**
	 * 用户是否已经报名该活动
	 * @param taskMatchVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	public Map<String,Object> checkUserSignUp(TaskMatchVo taskMatchVo,String scn) throws MeidianException {
		Map<String,Object> map = new HashMap<String, Object>();
		//获取登录人信息
		long userId = this.getUserToScn(scn);
		//用户是否报名
		TaskJoinVo taskJoin = new TaskJoinVo();
		taskJoin.setTaskId(taskMatchVo.getTaskId());
		taskJoin.setUserId(userId);
		List<TaskJoinVo> list = taskJoinResource.selectByExample(taskJoin);
		if(list!=null&&list.size()>0){
			map.put("joinStatus", UserConstants.RANK_TRUE);
		}else{
			map.put("joinStatus", UserConstants.RANK_FALSE);
		}
		return map;
	}
	
	/**
	 * 店主奖赛活动报名
	 * @param taskMatchVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	public ResponseJson signUpTaskMatch(TaskMatchVo taskMatchVo,String scn) throws MeidianException {
		long curTime = DateUtils.currentTimeSecs();
		//获取登录人信息
		long userId = this.getUserToScn(scn);
		//校验开店信息并获取店铺
		ResponseJson result = this.checkVshopToUserId(userId);
		if(result.getCode()!=0){ return result;}
		VshopInfo vshopInfo = (VshopInfo) result.getData();
		//校验当前活动状态
		TaskInfoVo taskInfo = new TaskInfoVo();
		Map<String, Object> map = this.checkTaskStatus(taskMatchVo.getTaskId(),curTime);
		if(!map.get("taskStauts").equals(UserConstants.RANK_NOEXIT)){
			taskInfo = (TaskInfoVo) map.get("taskInfo");
		}else{
			throw new ServiceException("base.shop.task.outAct");
		}
		//用户是否已经报名
		TaskJoinVo taskJoinVo = new TaskJoinVo();
		taskJoinVo.setTaskId(taskInfo.getId());
		taskJoinVo.setUserId(userId);
		List<TaskJoinVo> list = taskJoinResource.selectByExample(taskJoinVo);
		if(list!=null&&list.size()>0){
			throw new ServiceException("base.match.task.joinOn");
		}else{
			//用户报名并同步数据
			logger.info("店主奖赛报名信息,用户id:{},活动id:{}",userId,taskInfo.getId());
			this.saveTaskJoinInfo(taskInfo, vshopInfo, userId, curTime);
		}
		return ResponseJson.getSuccessResponse();
	}
	
	/**
	 * 个人销售额排行数据
	 * @param taskMatchVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	public ResponseJson getOwnTaskPaySort(TaskMatchVo taskMatchVo,String scn) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		//获取登录人信息
		long userId = this.getUserToScn(scn);
		//校验开店信息并获取店铺
		responseJson = this.checkVshopToUserId(userId);
		if(responseJson.getCode()!=0){ return responseJson;}
		VshopInfo vshopInfo = (VshopInfo) responseJson.getData();
		//缓存数据-获取店主奖赛订单销售额数据-个人活动范围
		ResponseApiDto response = this.getOwnMshopRaceData(taskMatchVo.getTaskId(),String.valueOf(vshopInfo.getVshopId()),UserConstants.SORT_PAY);
		//处理数据
		if(!response.getCode().equals(0)){
			responseJson.setCode(response.getCode());
			responseJson.setMsg(response.getMsg());
		}
		MshopRaceOrderData mshopRaceOrderData = new MshopRaceOrderData();
		if(response.getDatas()!=null){
			mshopRaceOrderData = (com.gomeplus.bs.interfaces.mshop.task.entity.MshopRaceOrderData) response.getDatas();
		}
		responseJson.setData(mshopRaceOrderData);
		return responseJson;
	}
	
	/**
	 * 获取各类型奖赛排行数据
	 * @param taskMatchVo
	 * @return
	 * @throws MeidianException
	 */
	public ResponseJson getTaskSortData(TaskMatchPageVo taskMatchPageVo) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		//缓存信息数据常量
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		String taskMatchPayOrderKey = MSHOPTASKMATCHPAYORDER+taskMatchPageVo.getTaskId()+taskMatchPageVo.getType()+taskMatchPageVo.getPageSize();
		//缓存数据
		String gacheTMPOK = gcache.get(taskMatchPayOrderKey);
		if(StringUtils.isBlank(gacheTMPOK)){
			list = this.getTaskPaySortData(taskMatchPageVo);
			try{
				String resultJson = JSON.toJSONString(list);
				gcache.setex(taskMatchPayOrderKey, 60, resultJson);
			}catch (Exception e){
				logger.info("店主竞赛活动订单销量信息,缓存异常{}",e);
			}
		}else{
			list = JSON.parseObject(gacheTMPOK,ArrayList.class);
		}
		responseJson.setData(list);
		return responseJson;
	}
	
	//获取不同类型订单销量数据信息
	private List<Map<String,Object>> getTaskPaySortData(TaskMatchPageVo taskMatchPageVo) throws MeidianException {
		//1:当天销售排行 2:当天订单排行 3:活动区间销售排行 4:活动区间订单排行 5:历史天数销售排行 6:历史天数订单排行
		Integer type = taskMatchPageVo.getType();
		List<Map<String,Object>> list = new ArrayList<Map<String,Object>>();
		ResponseApiDto response = new ResponseApiDto();
		Map<String,Object> map = new HashMap<>();
		if(type.equals(UserConstants.DAY_SORT_PAY)){
			response = this.getDayMshopRaceData(taskMatchPageVo.getTaskId(),taskMatchPageVo.getPageSize(),UserConstants.SORT_PAY);
			//正常返回数据
			map.put("mshopRaceData", this.pageResponeData(response));
			list.add(map);
		}else if(type.equals(UserConstants.DAY_SORT_ORDER)){
			response = this.getDayMshopRaceData(taskMatchPageVo.getTaskId(),taskMatchPageVo.getPageSize(),UserConstants.SORT_ORDER);
			//正常返回数据
			map.put("mshopRaceData", this.pageResponeData(response));
			list.add(map);
		}else if(type.equals(UserConstants.TASK_SORT_PAY)){
			response = this.getMshopRaceData(taskMatchPageVo.getTaskId(),taskMatchPageVo.getPageSize(),UserConstants.SORT_PAY);
			//正常返回数据
			map.put("mshopRaceData", this.pageResponeData(response));
			list.add(map);
		}else if(type.equals(UserConstants.TASK_SORT_ORDER)){
			response = this.getMshopRaceData(taskMatchPageVo.getTaskId(),taskMatchPageVo.getPageSize(),UserConstants.SORT_ORDER);
			//正常返回数据
			map.put("mshopRaceData", this.pageResponeData(response));
			list.add(map);
		}else if(type.equals(UserConstants.CUM_SORT_PAY)||type.equals(UserConstants.CUM_SORT_ORDER)){
			TaskInfoVo taskInfo = mshopTaskInfoResource.doGet(taskMatchPageVo.getTaskId());
			if(taskInfo!=null&&(taskInfo.getType()!=null)&&(taskInfo.getType().equals(5))){
				//获取时间差
				Date startTime = taskInfo.getStartTime();
				long curTimeSecs = DateUtils.getDayEndTime(0).getTime();
				int count = (int) Math.ceil((curTimeSecs-startTime.getTime())*1.0/(1000*60*60*24));
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				if(type.equals(UserConstants.CUM_SORT_PAY)){
					for (int i = 0; i < count; i++) {
						Map<String,Object> mapCum = new HashMap<>();
						ResponseApiDto responseDto = this.getCumDayMshopRaceData(taskMatchPageVo.getPageSize(),UserConstants.SORT_PAY,-i);
						//正常返回数据
						mapCum.put("vitalTime", sdf.format(DateUtils.getDayStartTime(-i)));
						mapCum.put("mshopRaceData", this.pageResponeData(responseDto));
						list.add(mapCum);
					}
				}else{
					for (int i = 0; i < count; i++) {
						Map<String,Object> mapCum = new HashMap<>();
						ResponseApiDto responseDto = this.getCumDayMshopRaceData(taskMatchPageVo.getPageSize(),UserConstants.SORT_ORDER,-i);
						//正常返回数据
						mapCum.put("vitalTime", sdf.format(DateUtils.getDayStartTime(-i)));
						mapCum.put("mshopRaceData", this.pageResponeData(responseDto));
						list.add(mapCum);
					}
				}
			}
		}else{
			throw new ServiceException("base.match.rank.type");
		}
		return list;
	}
	
	
	//返回数据进行过滤
	private List<MshopRaceOrderData> pageResponeData(ResponseApiDto response) throws MeidianException {
		List<MshopRaceOrderData> listData = new ArrayList<>();
		if(response.getDatas()!=null){
			listData = (List<MshopRaceOrderData>) response.getDatas();
		}
		return listData;
	}
	
	//获取店主奖赛订单销售额数据-活动范围
	private ResponseApiDto getMshopRaceData(long taskId,int pageSize,int sortType) throws MeidianException {
		ResponseApiDto responseApiDto = new ResponseApiDto();
		TaskInfoVo taskInfo = mshopTaskInfoResource.doGet(taskId);
		if(taskInfo!=null&&(taskInfo.getType()!=null)&&(taskInfo.getType().equals(5))){
			MshopRaceOrderData mshopRaceOrderData = new MshopRaceOrderData();
			mshopRaceOrderData.setStartTime(taskInfo.getStartTime());
			mshopRaceOrderData.setEndTime(taskInfo.getEndTime());
			mshopRaceOrderData.setPageSize(pageSize);
			responseApiDto = mshopRaceOrderDataServiceImpl.getMshopRaceRankData(mshopRaceOrderData,sortType);
		}
		return responseApiDto;
	}
	
	//获取店主奖赛订单销售额数据-当天范围
	private ResponseApiDto getDayMshopRaceData(long taskId,int pageSize,int sortType) throws MeidianException {
		ResponseApiDto responseApiDto = new ResponseApiDto();
		TaskInfoVo taskInfo = mshopTaskInfoResource.doGet(taskId);
		if(taskInfo!=null&&(taskInfo.getType()!=null)&&(taskInfo.getType().equals(5))){
			MshopRaceOrderData mshopRaceOrderData = new MshopRaceOrderData();
			mshopRaceOrderData.setStartTime(DateUtils.getDayStartTime(0));
			mshopRaceOrderData.setEndTime(DateUtils.getDayStartTime(1));
			mshopRaceOrderData.setPageSize(pageSize);
			responseApiDto = mshopRaceOrderDataServiceImpl.getMshopRaceRankData(mshopRaceOrderData,sortType);
		}
		return responseApiDto;
	}
	
	//获取店主奖赛订单销售额数据-累计天数范围
	private ResponseApiDto getCumDayMshopRaceData(int pageSize,int sortType,int day) throws MeidianException {
		MshopRaceOrderData mshopRaceOrderData = new MshopRaceOrderData();
		mshopRaceOrderData.setStartTime(DateUtils.getDayStartTime(day));
		mshopRaceOrderData.setEndTime(DateUtils.getDayStartTime(day+1));
		mshopRaceOrderData.setPageSize(pageSize);
		return mshopRaceOrderDataServiceImpl.getMshopRaceRankData(mshopRaceOrderData,sortType);
	}
	
	//获取店主奖赛订单销售额数据-个人活动范围
	private ResponseApiDto getOwnMshopRaceData(long taskId,String mid,int sortType) throws MeidianException {
		ResponseApiDto responseApiDto = new ResponseApiDto();
		TaskInfoVo taskInfo = mshopTaskInfoResource.doGet(taskId);
		if(taskInfo!=null&&(taskInfo.getType()!=null)&&(taskInfo.getType().equals(5))){
			MshopRaceOrderData mshopRaceOrderData = new MshopRaceOrderData();
			mshopRaceOrderData.setStartTime(taskInfo.getStartTime());
			mshopRaceOrderData.setEndTime(taskInfo.getEndTime());
			mshopRaceOrderData.setShopId(mid);
			mshopRaceOrderData.setPageSize(1);
			responseApiDto = mshopRaceOrderDataServiceImpl.getCurrentRaceRank(mshopRaceOrderData,sortType);
		}
		return responseApiDto;
	}
	
	//校验当前活动状态
	private Map<String,Object> checkTaskStatus(long taskId,long curTime) throws MeidianException {
		Map<String,Object> map = new HashMap<String,Object>();
		TaskInfoVo taskInfo = mshopTaskInfoResource.doGet(taskId);
		if(taskInfo!=null&&(taskInfo.getType()!=null)&&(taskInfo.getType().equals(5))){
			if(!taskInfo.getStatus().equals(4)){
				map.put("taskStauts", UserConstants.RANK_NOEXIT);
			}else{
				if(curTime<(taskInfo.getStartTime().getTime())){
					map.put("taskStauts", UserConstants.RANK_EXIT);
				}else{
					map.put("taskStauts", UserConstants.RANK_INGEXIT);
				}
			}
			map.put("taskInfo", taskInfo);
		}else{
			throw new ServiceException("base.shop.task.outAct");
		}
		return map;
	}
	
	//用户报名并同步数据
	@Transactional
	private void saveTaskJoinInfo(TaskInfoVo taskInfo,VshopInfo vshopInfo,long userId,long curTime) throws MeidianException {
		TaskJoinVo taskJoin = new TaskJoinVo();
		taskJoin.setTaskId(taskInfo.getId());
		taskJoin.setUserId(userId);
		if(vshopInfo!=null){
			taskJoin.setUserMid(vshopInfo.getVshopId());
		}
		taskJoin.setJoinTime(curTime);
		taskJoin.setStartTime(taskInfo.getStartTime().getTime());
		taskJoin.setEndTime(taskInfo.getEndTime().getTime());
		taskJoin.setCreateTime(curTime);
		taskJoin.setUpdateTime(curTime);
		taskJoinResource.insert(taskJoin);
		//同步信息
		MshopRaceOrderData mshopRaceOrderData = new MshopRaceOrderData();
		mshopRaceOrderData.setUserId(String.valueOf(userId));
		mshopRaceOrderData.setShopId(String.valueOf(vshopInfo.getVshopId()));
		mshopRaceOrderData.setActivityId(taskInfo.getId());
		mshopRaceOrderData.setEnjoyTime(DateUtils.transDateForNum(curTime));
		mshopRaceOrderDataServiceImpl.insertMshopRaceData(mshopRaceOrderData);
	}
	
	//scn获取用户信息
	private long getUserToScn(String scn) throws MeidianException {
		//获取登录人信息
		UserInfoCache userInfo = groupOrderManager.checkScnByDubbo(scn);
		if(userInfo==null || userInfo.getId()==null || userInfo.getId().equals("")) {
			throw new ServiceException("group.operation.notLoggin");
		}
		return Long.parseLong(userInfo.getId());
	}
	
	//校验用户是否开店
	private ResponseJson checkVshopToUserId(long userId) throws MeidianException {
		ResponseJson responseJson = new ResponseJson();
		VshopInfo vshopInfo = null;
		CommonResultEntity<VshopInfo> vshop = vshopInfoExternalFacade.queryVshopInfoByUserId(userId);
		if(vshop!=null&&vshop.getCode()==0){
			vshopInfo = vshop.getBusinessObj();
			if(vshopInfo==null){//未开通店铺
				throw new ServiceException("base.shop.initUser.noExit");
			}
			responseJson.setData(vshopInfo);
			return responseJson;
		}else{
			responseJson.setCode(vshop.getCode());
			responseJson.setMsg(vshop.getMessage());
			return responseJson;
		}
	}
	
}
