package com.gome.meidian.grouporder.controller.mshopUser;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.rocketmq.client.exception.MQBrokerException;
import com.alibaba.rocketmq.client.exception.MQClientException;
import com.alibaba.rocketmq.remoting.exception.RemotingException;
import com.gome.meidian.common.exception.MeidianException;
import com.gome.meidian.grouporder.manager.mshopUserManager.MshopUserManager;
import com.gome.meidian.grouporder.vo.register.MshopUserDepositVo;
import com.gome.meidian.grouporder.vo.register.MshopUserRegistVo;
import com.gome.meidian.grouporder.vo.register.VshopInfoVo;
import com.gome.meidian.restfulcommon.reponse.ResponseJson;

@RestController
@Validated
@RequestMapping("/mshopUser")
@SuppressWarnings({ "rawtypes"})
public class MshopUserController {
	
	@Autowired
	private MshopUserManager mshopUserManager;
	
	/**
	 * 店主认证开店
	 * @param shopInfoVo
	 * @return
	 * @throws MeidianException
	 */
	@PostMapping(value = "/openVshopInfo")
	public ResponseJson openVshopInfo(@Valid @RequestBody VshopInfoVo vshopInfoVo,@CookieValue(value="SCN",required=true) String scn) throws MeidianException {
		ResponseJson responseJson = mshopUserManager.openVshopInfo(vshopInfoVo,scn);
		return responseJson;
	}
	
	/**
	 * 校验用户是否开店
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping(value = "/checkUserVshop")
	public ResponseJson checkUserVshop(@CookieValue(value="SCN",required=true) String scn) throws MeidianException {
		return mshopUserManager.checkUserVshop(scn);
	}
	
	/**
	 * 校验mid是否开店
	 * @param scn
	 * @return
	 * @throws MeidianException
	 */
	@GetMapping(value = "/checkMidVshop")
	public ResponseJson checkMidVshop(@NotNull(message = "{param.error}") @RequestParam("mid") Long mid) throws MeidianException {
		return mshopUserManager.checkMidVshop(mid);
	}
	
	/**
	 * 邀请mid校验+注册风控+短信验证码校验+注册接口+登录返scn+异步同步信息
	 * @param mshopUserRegistVo
	 * @param request
	 * @param response
	 * @return
	 * @throws MeidianException
	 * @throws MQClientException
	 * @throws RemotingException
	 * @throws MQBrokerException
	 * @throws InterruptedException
	 */
	@PostMapping(value = "/registerUser")
	public ResponseJson registerUser(@Valid @RequestBody MshopUserRegistVo mshopUserRegistVo,HttpServletRequest request,HttpServletResponse response) throws MeidianException, MQClientException, RemotingException, MQBrokerException, InterruptedException {
		//邀请mid校验+注册风控+短信验证码校验+注册接口+登录返scn+异步同步信息
		return mshopUserManager.registerUser(mshopUserRegistVo,request,response);
	}
	
	/**
	 * 寄存用户信息数据
	 * @param mshopUserRegistVo
	 * @param scn
	 * @return
	 * @throws MeidianException
	 * @throws MQClientException
	 * @throws RemotingException
	 * @throws MQBrokerException
	 * @throws InterruptedException
	 */
	@PostMapping(value = "/mshopUserDeposit")
	public ResponseJson mshopUserDeposit(@Valid @RequestBody MshopUserDepositVo mshopUserDepositVo) throws MeidianException {
		//寄存用户信息哈邀请人信息
		return mshopUserManager.mshopUserDeposit(mshopUserDepositVo);
	}
	
}
