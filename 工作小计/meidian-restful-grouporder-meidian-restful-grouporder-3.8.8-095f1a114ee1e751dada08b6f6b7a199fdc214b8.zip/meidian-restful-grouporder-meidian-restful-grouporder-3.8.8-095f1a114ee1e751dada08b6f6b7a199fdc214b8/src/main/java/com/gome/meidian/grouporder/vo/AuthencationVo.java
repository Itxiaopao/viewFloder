package com.gome.meidian.grouporder.vo;

import java.io.Serializable;

/**
 * 验证登录返回值
 * @author shichangjian
 *
 */
public class AuthencationVo implements Serializable{

	private String userId;		// userId
	private String loginUrl;	// 登录主站链接
	private Byte login;			// 0:未登录，1：登录
	private String storeNo;		// 门店编码stId
	private String staffNo;		// 员工编号
	private String nickName;	// 用户昵称
	private Long shopId;		// 美店id
	private String currentEnv;	// 环境
	private String loginChoice;	// 登录选择，null：美店登录，2：楼上无线登录
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getLoginUrl() {
		return loginUrl;
	}
	public void setLoginUrl(String loginUrl) {
		this.loginUrl = loginUrl;
	}
	public Byte getLogin() {
		return login;
	}
	public void setLogin(Byte login) {
		this.login = login;
	}
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public Long getShopId() {
		return shopId;
	}
	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}
	public String getCurrentEnv() {
		return currentEnv;
	}
	public void setCurrentEnv(String currentEnv) {
		this.currentEnv = currentEnv;
	}
	public String getStaffNo() {
		return staffNo;
	}
	public void setStaffNo(String staffNo) {
		this.staffNo = staffNo;
	}
	public String getLoginChoice() {
		return loginChoice;
	}
	public void setLoginChoice(String loginChoice) {
		this.loginChoice = loginChoice;
	}
	
	
	
}
