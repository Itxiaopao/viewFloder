package com.gome.meidian.grouporder.vo.carveUp;

import com.gome.meidian.grouporder.vo.Coupon;

/**
 * 瓜分团券信息
 */
public class CarveUpCouponVo extends Coupon {

	private static final long serialVersionUID = -5210150706267901798L;
	private String couponPageCode;  //与券对应的活动页pageCode
    public String getCouponPageCode() {
        return couponPageCode;
    }
    public void setCouponPageCode(String couponPageCode) {
        this.couponPageCode = couponPageCode;
    }

}
