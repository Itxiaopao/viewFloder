package com.gome.meidian.grouporder.vo.grouporderVo;

import java.io.Serializable;

public class ProductCouponReq implements Serializable{

	private static final long serialVersionUID = -2785520243566272788L;

	private String productId;		// 商品id
	private String skuId;			// 商品skuId
	private String activityUkey;	// 活动页ukey
	
	public ProductCouponReq() {
		super();
	}
	public ProductCouponReq(String productId, String skuId) {
		super();
		this.productId = productId;
		this.skuId = skuId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getActivityUkey() {
		return activityUkey;
	}
	public void setActivityUkey(String activityUkey) {
		this.activityUkey = activityUkey;
	}
	public String getSkuId() {
		return skuId;
	}
	public void setSkuId(String skuId) {
		this.skuId = skuId;
	}
	
	
	
}
